import { QueryClientProvider } from "@tanstack/react-query";
import { Suspense, lazy, useEffect, useRef } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import { Navigate, Outlet, Route, BrowserRouter as Router, Routes, useLocation, useNavigate } from 'react-router-dom';
import { DEV_BYPASS_LOGIN, DEV_MOCK_SESSION } from './config/devSession';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { PersistGate } from 'redux-persist/integration/react';
import AppLayout from './components/AppLayout';
import EncryptedRedirect from './components/EncryptedRedirect';
import BackdropLoader from './components/Loader/BackdropLoader';
import ProtectedRoute from './components/ProtectedRoute';
import { setLogin } from './redux/slices/userSlice';
import store, { persistor } from './redux/store';
import { containsBlockedSpecialCharacter } from './clientApp/utils/securityValidation';
import { encodedRoutePath } from './clientApp/config/routes.js';
import { queryClient } from './clientApp/lib/queryClient';
import { logout } from './services/api';
import { clearSessionState, SESSION_LOGOUT_EVENT_KEY } from './utils/sessionManager';
const Login = lazy(() => import('./pages/Login'));
const Forgot = lazy(() => import('./pages/ForgotPassword'));
const UserProfile = lazy(() => import('./pages/UserProfile'));
const Faq = lazy(() => import('./pages/Faq'));

const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));
const ManagerDashboard = lazy(() => import('./pages/ManagerDashboard'));
const RenewalDashboard = lazy(() => import('./pages/RenewalDashboard'));
const MISPOutlet = lazy(() => import('./pages/MISPOutlet'));
const EditMISPOutlet = lazy(() => import('./pages/EditMISPOutlet'));
const MISPsetup = lazy(() => import('./pages/Setup'));
const CreateDealer = lazy(() => import('./pages/CreateDealer'));
const LeadPoolList = lazy(() => import('./pages/LeadpoolList'));
const LeadPoolForm = lazy(() => import('./pages/NewLeadpool'));
const UserTable = lazy(() => import('./pages/UserManagement'));
const CreateUser = lazy(() => import('./pages/CreateUser'));
const RoleList = lazy(() => import('./pages/RoleList'));
const CreateRole = lazy(() => import('./pages/CreateRole'));
const CallQueue = lazy(() => import('./pages/CallQueue'));
const CustomerDetailsPage = lazy(() => import('./pages/DealerDetail360'));
const AssignReassignLeads = lazy(() => import('./pages/AssignReassignLeads'));
const CustomerSearch = lazy(() => import('./pages/CustomerSearch'));
const DataUpload = lazy(() => import('./pages/DataUpload'));
const SystemConfiguration = lazy(() => import('./pages/SystemConfiguration'));
const CorporateReports = lazy(() => import('./clientApp/pages/Reports.jsx'));
const KpiDashboard = lazy(() => import('./clientApp/pages/KpiDashboard.jsx'));
const ClientPerformanceDashboard = lazy(() => import('./clientApp/pages/PerformanceDashboard.jsx'));

const TATMonitoring = lazy(() => import('./pages/TATMonitoring'));
const AgentTATPerformance = lazy(() => import('./pages/AgentTATPerformance'));
const TeamLeadsTATPerformance = lazy(() => import('./pages/TeamLeadsTATPerformance'));
const LeadMovementReport = lazy(() => import('./pages/AdminDashboard/LeadMovementReport'));
const LeaderBoard = lazy(() => import('./pages/LeaderBoard'));
const PerformanceDashboard = lazy(() => import('./pages/PerformanceDashboard'));
const Target = lazy(() => import('./pages/Target'));
const ViewCharts = lazy(() => import('./pages/ViewCharts'));

// Embedded corporate-qms "Client" flow (mounted as real routes; see ClientApp.jsx)
const ClientApp = lazy(() => import('./clientApp/ClientApp'));
const RfqDashboard = lazy(() => import('./clientApp/pages/Dashboard.jsx'));
const Clients = lazy(() => import('./clientApp/pages/Clients.jsx'));
const ClientsCreate = lazy(() => import('./clientApp/pages/ClientsCreate.jsx'));
const PortfolioForm = lazy(() => import('./clientApp/pages/PortfolioForm.jsx'));
const ClientDetail = lazy(() => import('./clientApp/pages/ClientDetail.jsx'));
const Opportunities = lazy(() => import('./clientApp/pages/Opportunities.jsx'));
const Portfolios = lazy(() => import('./clientApp/pages/Portfolios.jsx'));
const Renewals = lazy(() => import('./clientApp/pages/Renewals.jsx'));
const Activities = lazy(() => import('./clientApp/pages/Activities.jsx'));
const CRM = lazy(() => import('./clientApp/pages/CRM.jsx'));
const CRMConvert = lazy(() => import('./clientApp/pages/CRMConvert.jsx'));
const ActivityForm = lazy(() => import('./clientApp/pages/ActivityForm.jsx'));
const RenewalConvert = lazy(() => import('./clientApp/pages/RenewalConvert.jsx'));
const OpportunityCreate = lazy(() => import('./clientApp/pages/OpportunityCreate.jsx'));
const OpportunityWorkflow = lazy(() => import('./clientApp/pages/OpportunityWorkflow.jsx'));
const AesJsonCipher = lazy(() => import('./clientApp/pages/AesJsonCipher.jsx'));
const PageNotFound = lazy(() => import('./clientApp/pages/PageNotFound.jsx'));

const INACTIVITY_LOGOUT_MS = 24 * 60 * 1000;
const ACTIVITY_EVENTS = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'click'];

// DEV ONLY: seed a mock session so the app skips the login screen and lands on the dashboard.
// See config/devSession.js. Disable by setting DEV_BYPASS_LOGIN to false.
function DevAutoLogin() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const loggedIn = useSelector((state) => state.user.loggedIn);

  useEffect(() => {
    if (!DEV_BYPASS_LOGIN || loggedIn) return;
    dispatch(setLogin(DEV_MOCK_SESSION));
  }, [dispatch, loggedIn]);

  useEffect(() => {
    if (DEV_BYPASS_LOGIN && loggedIn && location.pathname === '/') {
      navigate(encodedRoutePath('/dashboard'), { replace: true });
    }
  }, [loggedIn, location.pathname, navigate]);

  return null;
}

function SessionLifecycle() {
  const navigate = useNavigate();
  const loggedIn = useSelector((state) => state.user.loggedIn);
  const email = useSelector((state) => state.user.loggedData?.email);
  const timerRef = useRef(null);

  useEffect(() => {
    if (!loggedIn) return undefined;

    let cancelled = false;

    const logoutForInactivity = async () => {
      if (cancelled || !store.getState()?.user?.loggedIn) return;

      try {
        await logout(email);
      } catch (error) {
        console.error('Idle logout failed', error);
      }

      await clearSessionState({ broadcast: true });
      navigate('/', { replace: true });
    };

    const resetInactivityTimer = () => {
      window.clearTimeout(timerRef.current);
      timerRef.current = window.setTimeout(logoutForInactivity, INACTIVITY_LOGOUT_MS);
    };

    ACTIVITY_EVENTS.forEach((eventName) => {
      window.addEventListener(eventName, resetInactivityTimer, true);
    });
    resetInactivityTimer();

    return () => {
      cancelled = true;
      window.clearTimeout(timerRef.current);
      ACTIVITY_EVENTS.forEach((eventName) => {
        window.removeEventListener(eventName, resetInactivityTimer, true);
      });
    };
  }, [email, loggedIn, navigate]);

  useEffect(() => {
    const handleSessionLogout = async (event) => {
      if (event.key !== SESSION_LOGOUT_EVENT_KEY || !event.newValue) return;

      await clearSessionState({ broadcast: false });
      navigate('/', { replace: true });
    };

    window.addEventListener('storage', handleSessionLogout);
    return () => window.removeEventListener('storage', handleSessionLogout);
  }, [navigate]);

  return null;
}

function NavigationWatcher() {
  const loggedIn = useSelector((state) => state.user.loggedIn);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (
      !loggedIn &&
      location.pathname !== "/" &&
      location.pathname !== "/forgot" &&
      location.pathname !== "/page-not-found"
    ) {
      navigate("/");
      // toast.error("Unauthorized - Invalid or Expired Token");
    }
  }, [loggedIn, location.pathname, navigate]);

  return;
}

const decodeUrlPart = (value = '') => {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
};

function UrlSecurityGuard() {
  const location = useLocation();
  const blockedUrlPart = `${location.pathname}${location.search}${location.hash}`;
  const decodedBlockedUrlPart = decodeUrlPart(blockedUrlPart);
  const hasBlockedCharacter =
    containsBlockedSpecialCharacter(blockedUrlPart) || containsBlockedSpecialCharacter(decodedBlockedUrlPart);

  if (location.pathname !== '/page-not-found' && hasBlockedCharacter) {
    return <Navigate to="/page-not-found" replace />;
  }

  return null;
}

function GlobalShortcuts() {
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (event) => {
      const isKpiShortcut =
        event.ctrlKey &&
        event.altKey &&
        (event.code === 'KeyO' || event.key?.toLowerCase() === 'o');
      const isPerformanceShortcut =
        event.ctrlKey &&
        event.altKey &&
        (event.code === 'KeyP' || event.key?.toLowerCase() === 'p');
      const isEncryptionShortcut =
        event.ctrlKey &&
        event.altKey &&
        (event.code === 'KeyE' || event.key?.toLowerCase() === 'e');
      if (!isKpiShortcut && !isPerformanceShortcut && !isEncryptionShortcut) return;
      event.preventDefault();
      event.stopPropagation();
      navigate(encodedRoutePath(
        isEncryptionShortcut
          ? '/aes-json-cipher'
          : isPerformanceShortcut
            ? '/performance-dashboard'
            : '/kpi-dashboard',
      ));
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [navigate]);

  return null;
}

function App() {
  // SetupAxiosInterceptors();
  const isAuthenticated = useSelector((state) => state.user.loggedIn);
  // const token = useSelector((state) => state.user.token);
  // const navigate = useNavigate();

  // useEffect(() => {
  //   if (token === "") {
  //     // history.push("/");
  //     navigate("/")
  //   }
  // }, [token])

  return (
    <>
      <QueryClientProvider client={queryClient}>
        <Provider store={store}>
          <PersistGate loading={null} persistor={persistor}>
            <Router>
              <DevAutoLogin />
              <NavigationWatcher />
              <UrlSecurityGuard />
              <GlobalShortcuts />
              <SessionLifecycle />
              {/* <HistoryRouter history={history}> */}
              <Suspense fallback={<BackdropLoader loading={true} />}>
                <Routes>
                  {/* Public Route */}
                  <Route path="/" element={<Login />} />
                  <Route path="/forgot" element={<Forgot />} />
                  <Route path="/page-not-found" element={<PageNotFound />} />

                  {/* Protected Routes with Layout */}
                  <Route
                    element={
                      <ProtectedRoute isAuthenticated={isAuthenticated}>
                        <AppLayout />
                      </ProtectedRoute>
                    }
                  >
                    {/* Profile */}
                    <Route path="/profile" element={<UserProfile />} />
                    <Route path="/faq" element={<Faq />} />

                    <Route path="/admindashboard" element={<AdminDashboard />} />
                    <Route path="/admindashboard/viewAll" element={<LeadMovementReport />} />
                    <Route path="/managerdashboard" element={<ManagerDashboard />} />
                    <Route path="/renewalDashboard" element={<RenewalDashboard />} />

                    {/* Setup */}
                    <Route path="/mispoutlet" element={<MISPOutlet />} />
                    <Route path="/editmispoutlet" element={<EditMISPOutlet />} />
                    <Route path="/mispoutlet/create" element={<MISPsetup />} />
                    <Route path="/editmispoutlet/create" element={<CreateDealer />} />
                    <Route path="/editmispoutlet/edit" element={<MISPsetup />} />

                    {/* Lead Pool */}
                    <Route path="/leadpool" element={<LeadPoolList />} />
                    <Route path="/leadpool/create" element={<LeadPoolForm />} />
                    <Route path="/leadpool/edit" element={<LeadPoolForm />} />

                    {/* Users */}
                    <Route path="/userManagement" element={<UserTable />} />
                    <Route path="/userManagement/create" element={<CreateUser />} />
                    <Route path="/userManagement/edit" element={<CreateUser />} />

                    {/* Roles */}
                    <Route path="/role" element={<RoleList />} />
                    <Route path="/role/create" element={<CreateRole />} />
                    <Route path="/role/edit" element={<CreateRole />} />

                    {/* Other Pages */}
                    <Route path="/callqueue" element={<CallQueue />} />
                    <Route path="/callqueue/customerdetails" element={<CustomerDetailsPage />} />
                    <Route path="/assignLeads" element={<AssignReassignLeads />} />
                    <Route path="/customerSearch" element={<CustomerSearch />} />
                    <Route path="/dataupload" element={<DataUpload />} />
                    <Route path="/systemconfiguration" element={<SystemConfiguration />} />
                    {/* TAT Monitoring */}
                    <Route path="/tatMonitoring" element={<TATMonitoring />} />
                    <Route path="/tatMonitoring/tatviewAll" element={<AgentTATPerformance />} />
                    <Route path="/tatMonitoring/teamleadviewAll" element={<TeamLeadsTATPerformance />} />

                    {/* LeaderBoard */}
                    <Route path="/leaderBoard" element={<LeaderBoard />} />

                    {/* Performance dashboard */}
                    <Route path="/performanceDashboard" element={<PerformanceDashboard />} />

                    {/* Target */}
                    <Route path="/target" element={<Target />} />
                    <Route path="/viewcharts" element={<ViewCharts />} />
                    <Route path="/reports" element={<CorporateReports />} />

                    {/* Embedded corporate-qms Client flow (kept on its own absolute paths) */}
                    <Route element={<ClientApp />}>
                      <Route path="/dashboard" element={<RfqDashboard />} />
                      <Route path="/clients" element={<Clients />} />
                      <Route path="/clients/create" element={<ClientsCreate />} />
                      <Route path="/clients/edit/:clientUUID" element={<ClientsCreate />} />
                      <Route path="/clients/create/portfolio" element={<PortfolioForm />} />
                      <Route path="/clients/:clientUUID" element={<ClientDetail />} />
                      <Route path="/opportunities" element={<Opportunities />} />
                      <Route path="/portfolios" element={<Portfolios />} />
                      <Route path="/renewals" element={<Renewals />} />
                      <Route path="/activities" element={<Activities />} />
                      <Route path="/crm" element={<CRM />} />
                      <Route path="/crm/convert/:migrationRowId" element={<CRMConvert />} />
                      <Route path="/activities/create" element={<ActivityForm mode="create" />} />
                      <Route path="/activities/edit/:activity_uuid" element={<ActivityForm mode="update" />} />
                      <Route path="/kpi-dashboard" element={<KpiDashboard />} />
                      <Route path="/performance-dashboard" element={<ClientPerformanceDashboard />} />
                      <Route path="/aes-json-cipher" element={<AesJsonCipher />} />
                      <Route path="/renewals/convert/:renewalLeadUUID" element={<RenewalConvert />} />
                      <Route path="/opportunities/create" element={<OpportunityCreate />} />
                      <Route path="/opportunities/:opportunityUUID/portfolio/contacts" element={<PortfolioForm />} />
                      <Route path="/opportunities/:opportunityUUID" element={<OpportunityWorkflow />} />
                    </Route>
                  </Route>

                  {/* Fallback */}
                  <Route path="/:encrypted" element={<EncryptedRedirect />} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </Suspense>
              {/* </HistoryRouter> */}
            </Router>
          </PersistGate>
        </Provider>
      </QueryClientProvider>

      <ToastContainer
        position="top-right"
        autoClose={1000}
        hideProgressBar={false}
        newestOnTop={true}
        closeOnClick
        pauseOnHover
        draggable
      />
    </>
  );
};

export default App;
