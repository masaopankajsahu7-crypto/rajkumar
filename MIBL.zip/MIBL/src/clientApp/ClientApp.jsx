import { Outlet } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './lib/queryClient';

/**
 * Provider wrapper for the embedded corporate-qms "Client" flow.
 *
 * The corporate-qms client pages (list -> detail -> create -> portfolio) are mounted as real
 * routes inside MIBL's existing BrowserRouter (see App.jsx), so their internal navigation
 * (which uses corporate-qms's own absolute paths like /clients/:uuid) works unchanged WITHOUT a
 * nested <Router> (React Router forbids a Router inside another Router).
 *
 * This layout route only supplies corporate-qms's own QueryClient so the client pages'
 * useQuery / useQueryClient / cache-invalidation all share one consistent client. MIBL's own
 * header + sidenav (from AppLayout) stay as the outer chrome.
 */
export default function ClientApp({ children }) {
  return (
    <QueryClientProvider client={queryClient}>
      {children ?? <Outlet />}
    </QueryClientProvider>
  );
}
