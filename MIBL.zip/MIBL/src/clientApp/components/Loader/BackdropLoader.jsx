import { CircularProgress, Backdrop, Box, Typography } from "@mui/material";
import "./BackdropLoader.css";

const BackdropLoader = ({ loading }) => {
    return (
            <Backdrop
                className="app-backdrop-loader"
                open={loading}
            >
                <Box
                    className="app-backdrop-loader__content"
                >
                    <CircularProgress color="inherit" />
                    <Typography variant="h6" className="app-backdrop-loader__text">
                        Loading...
                    </Typography>
                </Box>
            </Backdrop>
    )
}

export default BackdropLoader
