import { useState } from 'react';
import { AppBar, Avatar, Box, Menu, MenuItem, Tab, Tabs, Toolbar, Typography } from '@mui/material';
import { encodedRoutePath, ROUTES, NAV_ITEMS } from '../config/routes.js';
import { useLocation, useNavigate } from 'react-router-dom';
import logo from '../assets/images/logo.svg';
import './LoggedInHeader.css';

const HARD_CODED_USER = {
  name: 'Pankaj Sahu',
  role: 'Admin',
  initials: 'PS',
};

const LoggedInHeader = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [anchorEl, setAnchorEl] = useState(null);

  const currentTab = location.pathname === ROUTES.dashboard ? 'Dashboard' : 'Others';

  const handleOpenOthers = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleCloseOthers = () => {
    setAnchorEl(null);
  };

  const handleNavigateDashboard = () => {
    navigate(encodedRoutePath(ROUTES.dashboard));
  };

  const handleNavigateUserManagement = () => {
    navigate(encodedRoutePath(NAV_ITEMS[0].path));
    handleCloseOthers();
  };

  const handleNavigateClients = () => {
    navigate(encodedRoutePath(NAV_ITEMS[1].path));
    handleCloseOthers();
  };

  return (
    <AppBar className="header-p logged-in-header" position="fixed" elevation={0}>
      <Toolbar>
        <Box display="flex" alignItems="center" width="100%" justifyContent="space-between">
          <Box display="flex" alignItems="center" gap={1}>
            <img
              src={logo}
              alt="logo"
              className="logged-in-header-logo"
              onClick={handleNavigateDashboard}
            />
          </Box>

          <Tabs value={currentTab} className="nav-text logged-in-header-tabs" centered>
            <Tab
              className="nav-text logged-in-header-tab"
              label="Dashboard"
              value="Dashboard"
              onClick={handleNavigateDashboard}
            />
            <Tab
              className="nav-text logged-in-header-tab"
              label="Others"
              value="Others"
              onClick={handleOpenOthers}
            />
          </Tabs>

          <Box display="flex" alignItems="center" gap={1}>
            <Avatar className="secondary-light logged-in-header-avatar">
              <Typography className="text-gray georama-SemiBold fs-12">
                {HARD_CODED_USER.initials}
              </Typography>
            </Avatar>
            <Box>
              <Typography className="georama-Regular fs-12">{HARD_CODED_USER.name}</Typography>
              <Typography className="georama-Regular fs-10 text-gray">{HARD_CODED_USER.role}</Typography>
            </Box>
          </Box>
        </Box>
      </Toolbar>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleCloseOthers}
      >
        <MenuItem onClick={handleNavigateUserManagement}>{NAV_ITEMS[0].label}</MenuItem>
        <MenuItem onClick={handleNavigateClients}>{NAV_ITEMS[1].label}</MenuItem>
      </Menu>
    </AppBar>
  );
};

export default LoggedInHeader;
