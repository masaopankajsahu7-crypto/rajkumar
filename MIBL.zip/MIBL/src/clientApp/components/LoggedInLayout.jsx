import { Box, Toolbar } from '@mui/material';
import { Outlet } from 'react-router-dom';
import LoggedInHeader from './LoggedInHeader.jsx';

const LoggedInLayout = () => {
  return (
    <Box className="body-formbg" minHeight="100vh">
      <LoggedInHeader />
      <Toolbar className="logged-in-layout-spacer" />
      <Box p={2}>
        <Outlet />
      </Box>
    </Box>
  );
};

export default LoggedInLayout;
