import { useEffect, useMemo, useRef, useState } from 'react';
import { Box, Button, IconButton, Stack, TextField, Typography } from '@mui/material';
import ChevronLeftRoundedIcon from '@mui/icons-material/ChevronLeftRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import './ClientOtpDialog.css';

const OTP_LENGTH = 6;
const RESEND_SECONDS = 120;

const formatTime = (seconds) => {
  const safeSeconds = Math.max(Number(seconds) || 0, 0);
  const minutes = String(Math.floor(safeSeconds / 60)).padStart(2, '0');
  const remainingSeconds = String(safeSeconds % 60).padStart(2, '0');
  return `${minutes}:${remainingSeconds}`;
};

const maskEmail = (email = '') => {
  const [name = '', domain = ''] = String(email).split('@');
  if (!name || !domain) return email ? '***' : 'your registered email';
  const visibleStart = name.slice(0, Math.min(2, name.length));
  const visibleEnd = name.length > 4 ? name.slice(-1) : '';
  return `${visibleStart}${'*'.repeat(Math.max(name.length - visibleStart.length - visibleEnd.length, 3))}${visibleEnd}@${domain}`;
};

const ClientOtpDialog = ({
  open,
  email,
  attemptsLeft,
  loading = false,
  error = '',
  onVerify,
  onResend,
  onClose,
}) => {
  const [otp, setOtp] = useState(Array(OTP_LENGTH).fill(''));
  const [timeLeft, setTimeLeft] = useState(RESEND_SECONDS);
  const [showEmail, setShowEmail] = useState(false);
  const inputRefs = useRef([]);

  const otpValue = useMemo(() => otp.join(''), [otp]);
  const canVerify = otpValue.length === OTP_LENGTH && !loading;
  const canResend = timeLeft <= 0 && !loading;

  useEffect(() => {
    if (!open) return;
    setOtp(Array(OTP_LENGTH).fill(''));
    setTimeLeft(RESEND_SECONDS);
    setShowEmail(false);
    window.setTimeout(() => inputRefs.current[0]?.focus(), 150);
  }, [open]);

  useEffect(() => {
    if (!open || timeLeft <= 0) return undefined;
    const timer = window.setTimeout(() => {
      setTimeLeft((prev) => Math.max(prev - 1, 0));
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [open, timeLeft]);

  const handleDigitChange = (index, value) => {
    const digit = String(value ?? '').replace(/\D/g, '').slice(-1);
    setOtp((prev) => {
      const next = [...prev];
      next[index] = digit;
      return next;
    });
    if (digit && index < OTP_LENGTH - 1) inputRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index, event) => {
    if (event.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
      return;
    }
    if (event.key === 'Enter' && canVerify) onVerify(otpValue);
  };

  const handlePaste = (event) => {
    const pastedValue = event.clipboardData.getData('text').replace(/\D/g, '').slice(0, OTP_LENGTH);
    if (!pastedValue) return;
    event.preventDefault();
    const nextOtp = Array(OTP_LENGTH).fill('');
    pastedValue.split('').forEach((digit, index) => {
      nextOtp[index] = digit;
    });
    setOtp(nextOtp);
    inputRefs.current[Math.min(pastedValue.length, OTP_LENGTH) - 1]?.focus();
  };

  const handleResend = async () => {
    await onResend?.();
    setOtp(Array(OTP_LENGTH).fill(''));
    setTimeLeft(RESEND_SECONDS);
    inputRefs.current[0]?.focus();
  };

  if (!open) return null;

  return (
    <Stack className="client-otp-inline-stack">
      <Button
        className="client-otp-back-btn"
        startIcon={<ChevronLeftRoundedIcon />}
        onClick={onClose}
        disabled={loading}
      >
        Back to login
      </Button>

      <Box className="client-otp-heading">
        <Typography className="client-otp-title">Verify Email OTP</Typography>
        <Typography className="client-otp-copy">
          Enter the 6 digit code sent to your registered email.
        </Typography>
        <Box className="client-otp-email-row">
          <Typography className="client-otp-email">
            {showEmail ? (email || 'your registered email') : maskEmail(email)}
          </Typography>
          <IconButton
            className="client-otp-email-toggle"
            size="small"
            onClick={() => setShowEmail((prev) => !prev)}
            aria-label={showEmail ? 'Hide email' : 'Show email'}
          >
            {showEmail ? <VisibilityOffOutlinedIcon fontSize="small" /> : <VisibilityOutlinedIcon fontSize="small" />}
          </IconButton>
        </Box>
      </Box>

      <Box>
        <Box className="client-otp-input-row" onPaste={handlePaste}>
          {otp.map((digit, index) => (
            <TextField
              key={index}
              inputRef={(node) => {
                inputRefs.current[index] = node;
              }}
              value={digit}
              onChange={(event) => handleDigitChange(index, event.target.value)}
              onKeyDown={(event) => handleKeyDown(index, event)}
              disabled={loading}
              inputProps={{
                maxLength: 1,
                inputMode: 'numeric',
                className: 'client-otp-input',
                'aria-label': `OTP digit ${index + 1}`,
              }}
            />
          ))}
        </Box>

        <Box className="client-otp-meta-row">
          <Typography className="client-otp-attempts">
            {Math.max(attemptsLeft, 0)} attempt{attemptsLeft === 1 ? '' : 's'} left
          </Typography>
          {canResend ? (
            <Button className="client-otp-resend-btn" startIcon={<RefreshRoundedIcon />} onClick={handleResend}>
              Resend OTP
            </Button>
          ) : (
            <Typography className="client-otp-timer">Resend in {formatTime(timeLeft)}</Typography>
          )}
        </Box>
      </Box>

      {error ? <Typography className="client-otp-error">{error}</Typography> : null}

      <Button
        className="btn-common-red border-radius-32 client-otp-verify-btn"
        onClick={() => onVerify(otpValue)}
        disabled={!canVerify}
      >
        Verify OTP
      </Button>
    </Stack>
  );
};

export default ClientOtpDialog;
