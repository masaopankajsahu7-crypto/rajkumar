import { useMemo, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  FormControlLabel,
  Radio,
  RadioGroup,
  TextField,
  Typography,
} from '@mui/material';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import CancelRoundedIcon from '@mui/icons-material/Cancel';
import FormatListBulletedRoundedIcon from '@mui/icons-material/FormatListBulletedRounded';
import PersonOutlineRoundedIcon from '@mui/icons-material/PersonOutlineRounded';
import { useSimilarClients } from '../../hooks/useFetchQueries.js';
import { CLIENT_APPROVAL_MESSAGES as MSG } from '../../config/messages/clientApproval.js';
import { CLIENT_KDS_FIELDS } from '../../config/kdsFields.js';
import { clientsDetailPath, encodedRoutePath, ROUTES } from '../../config/routes.js';
import { approveClient } from '../../services/api.jsx';
import { invalidateClientQueries } from '../../lib/queryClient.js';
import KdsSelect from '../common/KdsSelect.jsx';
import './ClientApproval.css';

const APPROVAL_STATUS_CODES = {
  approve: 'casa',
  reject: 'casr',
};

/**
 * Approval view shown when a client's status is Pending. Lists potential
 * duplicates from /clients/check and an Approve/Reject action.
 */
const ClientApproval = ({ clientUUID, clientName, checkSimilarClients = false }) => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { data: matches = [] } = useSimilarClients(clientName, {
    enabled: checkSimilarClients,
    clientUUID,
    source: 'approval',
  });
  const [decision, setDecision] = useState('approve');
  const [reasonCode, setReasonCode] = useState('');
  const [remarks, setRemarks] = useState('');
  const [submitError, setSubmitError] = useState('');
  const [approvalResult, setApprovalResult] = useState({ decision: 'approve' });
  const [dialogOpen, setDialogOpen] = useState(false);

  const similar = useMemo(
    () => (matches || []).filter((m) => m.clientUUID !== clientUUID),
    [matches, clientUUID],
  );

  const isApprove = decision === 'approve';

  const mutation = useMutation({
    mutationFn: approveClient,
    onSuccess: (_response, variables) => {
      setSubmitError('');
      setApprovalResult({
        decision: variables.statusCode === APPROVAL_STATUS_CODES.reject ? 'reject' : 'approve',
      });
      setDialogOpen(true);
    },
    onError: (error) => {
      setSubmitError(error?.message || MSG.errors.submitFailed);
    },
  });

  const refreshClientData = () => {
    setDialogOpen(false);
    invalidateClientQueries(queryClient);
  };

  const handleDialogViewProfile = () => {
    refreshClientData();
    navigate(clientsDetailPath(clientUUID));
  };

  const handleDialogReturnToList = () => {
    refreshClientData();
    navigate(encodedRoutePath(ROUTES.clients));
  };

  const handleDecisionChange = (value) => {
    setDecision(value);
    setSubmitError('');
    if (value === 'approve') {
      setReasonCode('');
    }
  };

  const handleSubmit = () => {
    mutation.mutate({
      clientUUID,
      statusCode: APPROVAL_STATUS_CODES[decision],
      reasonCode: isApprove ? '' : reasonCode,
      remarks: remarks.trim(),
    });
  };

  const isApprovedResult = approvalResult.decision === 'approve';
  const dialogMessage = isApprovedResult ? MSG.dialog.approvedMessage : MSG.dialog.rejectedMessage;

  return (
    <Box className="client-approval">
      {similar.length > 0 && (
        <Box className="client-approval__similar">
          <Box className="client-approval__similar-head">
            <WarningAmberRoundedIcon className="client-approval__warn-icon" />
            <Typography className="client-approval__similar-title georama-SemiBold">
              {MSG.similarTitle}
            </Typography>
          </Box>
          <Typography className="client-approval__similar-sub georama-Regular">
            {MSG.similarSubtitle}
          </Typography>
          <ul className="client-approval__similar-list">
            {similar.map((m) => (
              <li key={m.clientUUID} className="client-approval__similar-item georama-Regular">
                <span className="client-approval__similar-name">{m.clientName}</span>
                {m.owner ? (
                  <span className="client-approval__similar-owner">
                    {' '}
                    ({MSG.ownerPrefix}
                    {m.owner})
                  </span>
                ) : null}
              </li>
            ))}
          </ul>
        </Box>
      )}

      <Box className="client-approval__action">
        <Typography className="client-approval__action-title georama-SemiBold">
          {MSG.actionTitle}
        </Typography>

        <RadioGroup
          row
          className="client-approval__radios"
          value={decision}
          onChange={(e) => handleDecisionChange(e.target.value)}
        >
          <FormControlLabel
            value="approve"
            control={<Radio className="client-approval__radio" />}
            label={
              <span className="client-approval__radio-label client-approval__radio-label--approve">
                <CheckCircleRoundedIcon className="client-approval__radio-icon" />
                {MSG.approve}
              </span>
            }
          />
          <FormControlLabel
            value="reject"
            control={<Radio className="client-approval__radio" />}
            label={
              <span className="client-approval__radio-label client-approval__radio-label--reject">
                <CancelRoundedIcon className="client-approval__radio-icon" />
                {MSG.reject}
              </span>
            }
          />
        </RadioGroup>

        {!isApprove && (
          <Box className="client-approval__reason">
            <KdsSelect
              {...CLIENT_KDS_FIELDS.approvalReason}
              label={MSG.rejectionReasonLabel}
              value={reasonCode}
              onChange={setReasonCode}
              placeholder={MSG.rejectionReasonPlaceholder}
            />
          </Box>
        )}

        <Typography className="client-approval__field-label georama-Regular">
          {MSG.remarksLabel}
        </Typography>
        <TextField
          className="client-approval__remarks"
          multiline
          minRows={4}
          fullWidth
          placeholder={MSG.remarksPlaceholder}
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
        />

        {submitError && (
          <Typography className="client-approval__error georama-Regular" role="alert">
            {submitError}
          </Typography>
        )}

        <Button
          className="btn-common-red client-approval__submit"
          onClick={handleSubmit}
          disabled={mutation.isPending}
        >
          {mutation.isPending ? MSG.submitting : MSG.submit}
        </Button>
      </Box>

      <Dialog open={dialogOpen} className="client-approval-dialog">
        <div className="client-approval-dialog__content">
          {isApprovedResult ? (
            <span className="client-approval-dialog__icon-wrap client-approval-dialog__icon-wrap--approve">
              <CheckCircleRoundedIcon className="client-approval-dialog__icon" />
            </span>
          ) : (
            <span className="client-approval-dialog__icon-wrap client-approval-dialog__icon-wrap--reject">
              <CancelRoundedIcon className="client-approval-dialog__icon" />
            </span>
          )}
          <Typography className="client-approval-dialog__title georama-SemiBold">
            {isApprovedResult ? MSG.dialog.approvedTitle : MSG.dialog.rejectedTitle}
          </Typography>
          <Typography className="client-approval-dialog__message georama-Regular">
            {dialogMessage}
          </Typography>
          <Button className="client-approval-dialog__btn client-approval-dialog__btn--primary" onClick={handleDialogViewProfile}>
            <PersonOutlineRoundedIcon fontSize="small" />
            {MSG.dialog.viewProfile}
          </Button>
          <Button className="client-approval-dialog__btn client-approval-dialog__btn--secondary" onClick={handleDialogReturnToList}>
            <FormatListBulletedRoundedIcon fontSize="small" />
            {MSG.dialog.returnToList}
          </Button>
        </div>
      </Dialog>
    </Box>
  );
};

export default ClientApproval;
