import { useCallback, useEffect, useId, useRef, useState } from 'react';
import {
  Box,
  CircularProgress,
  FormHelperText,
  InputAdornment,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { useNavigate } from 'react-router-dom';
import { CLIENT_CREATE_MESSAGES as MSG } from '../../config/messages/client.js';
import { clientsDetailPath } from '../../config/routes.js';
import { searchClientsByName } from '../../services/api.jsx';

const ClientNameSearchField = ({
  label,
  value,
  onChange,
  placeholder = '',
  required = false,
  error = false,
  errorMessage = '',
  onClearError,
  searchEnabled = true,
  onSelectExistingClient,
  showAvailabilityStatus = true,
}) => {
  const navigate = useNavigate();
  const listId = useId();
  const wrapperRef = useRef(null);
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);

  const query = value.trim();
  const hasMatches = hasSearched && !loading && query.length > 0 && results.length > 0;
  const isAvailable = showAvailabilityStatus && searchEnabled && hasSearched && !loading && query.length > 0 && results.length === 0;

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!wrapperRef.current?.contains(event.target)) {
        setOpen(false);
        setActiveIndex(-1);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const runSearch = useCallback(async (searchValue) => {
    const trimmed = String(searchValue ?? '').trim();
    if (!searchEnabled || !trimmed) {
      setResults([]);
      setOpen(false);
      setHasSearched(false);
      setActiveIndex(-1);
      return;
    }

    setLoading(true);
    setHasSearched(false);
    try {
      const list = await searchClientsByName(trimmed, { source: 'add' });
      setResults(list);
      setHasSearched(true);
      setOpen(list.length > 0);
      setActiveIndex(-1);
    } finally {
      setLoading(false);
    }
  }, [searchEnabled]);

  // Debounced as-you-type trigger (same behaviour as the client-list search box).
  // Skip the initial mount so a pre-filled name (edit mode) doesn't auto-search.
  const didMountRef = useRef(false);
  useEffect(() => {
    if (!didMountRef.current) {
      didMountRef.current = true;
      return;
    }
    if (!searchEnabled || !value.trim()) return;

    const timer = window.setTimeout(() => {
      void runSearch(value);
    }, 300);

    return () => window.clearTimeout(timer);
  }, [searchEnabled, value, runSearch]);

  const handleExistingClientSelect = (item) => {
    if (!item?.clientUUID) return;
    setOpen(false);
    setActiveIndex(-1);
    if (onSelectExistingClient) {
      onSelectExistingClient(item);
      return;
    }
    navigate(clientsDetailPath(item.clientUUID));
  };

  const handleInputChange = (event) => {
    onChange(event.target.value);
    onClearError?.();
    setHasSearched(false);
    setResults([]);
    setOpen(false);
    setActiveIndex(-1);
  };

  const handleKeyDown = (event) => {
    if (!open || !results.length) return;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setActiveIndex((prev) => (prev + 1) % results.length);
      return;
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault();
      setActiveIndex((prev) => (prev <= 0 ? results.length - 1 : prev - 1));
      return;
    }

    if (event.key === 'Enter' && activeIndex >= 0) {
      event.preventDefault();
      handleExistingClientSelect(results[activeIndex]);
      return;
    }

    if (event.key === 'Escape') {
      setOpen(false);
      setActiveIndex(-1);
    }
  };

  const renderStatusAdornment = () => {
    if (loading) {
      return <CircularProgress className="client-form-name-search-spinner" size={18} />;
    }

    if (isAvailable) {
      return <CheckCircleIcon className="client-form-name-search-status client-form-name-search-status--ok" />;
    }

    if (hasMatches) {
      return (
        <Tooltip title={MSG.clientNameSearch.similarExists} arrow placement="top">
          <InfoOutlinedIcon className="client-form-name-search-status client-form-name-search-status--info" />
        </Tooltip>
      );
    }

    return null;
  };

  const showResults = open && results.length > 0;

  return (
    <Box ref={wrapperRef} className="client-form-field client-form-name-search">
      <Typography className="text-labels client-form-label">
        {label} {required && <span className="important-fields">*</span>}
      </Typography>

      <Box
        className={`client-form-name-search-input-wrap${
          hasMatches ? ' client-form-name-search-input-wrap--matches' : ''
        }${isAvailable ? ' client-form-name-search-input-wrap--available' : ''}`}
      >
        <TextField
          className="form-control-input border-radius-8 client-form-name-search-input"
          size="small"
          fullWidth
          value={value}
          placeholder={placeholder}
          error={error}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => {
            if (results.length > 0) setOpen(true);
          }}
          autoComplete="off"
          role="combobox"
          aria-expanded={showResults}
          aria-controls={showResults ? listId : undefined}
          aria-autocomplete="list"
          InputProps={{
            endAdornment: (
              <InputAdornment position="end" className="client-form-name-search-adornment">
                {renderStatusAdornment()}
              </InputAdornment>
            ),
          }}
        />

        {showResults && (
          <Box id={listId} className="client-form-name-search-results" role="listbox">
            <Box className="client-form-name-search-results-head">
              <Typography className="client-form-name-search-results-title georama-Medium">
                {MSG.clientNameSearch.resultsTitle}
              </Typography>
              <Typography className="client-form-name-search-results-subtitle georama-Regular">
                {MSG.clientNameSearch.resultsSubtitle}
              </Typography>
            </Box>
            {results.map((item, index) => (
              <Box
                key={item.clientUUID || `${item.clientName}-${index}`}
                className={`client-form-name-search-item${
                  index === activeIndex ? ' client-form-name-search-item--active' : ''
                }`}
                role="option"
                aria-selected={index === activeIndex}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => handleExistingClientSelect(item)}
              >
                <Box className="client-form-name-search-item-content">
                  <Typography className="client-form-name-search-item-title georama-Medium">
                    {item.clientName}
                  </Typography>
                  {item.owner ? (
                    <Typography className="client-form-name-search-item-owner georama-Regular">
                      {MSG.clientNameSearch.ownerLabel}: {item.owner}
                    </Typography>
                  ) : null}
                  {item.city ? (
                    <Typography className="client-form-name-search-item-meta georama-Regular">
                      {item.city}
                    </Typography>
                  ) : null}
                </Box>
                <ChevronRightIcon className="client-form-name-search-item-arrow" fontSize="small" />
              </Box>
            ))}
          </Box>
        )}
      </Box>

      {errorMessage && <FormHelperText className="important-fields">{errorMessage}</FormHelperText>}
    </Box>
  );
};

export default ClientNameSearchField;
