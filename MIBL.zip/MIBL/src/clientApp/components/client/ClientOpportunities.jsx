import {
  Box,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import { CLIENT_DETAIL_MESSAGES as MSG } from '../../config/messages/clientDetail.js';
import { useClientOpportunities } from '../../hooks/useFetchQueries.js';
import { isListActionAllowed } from '../../utils/listPermissions.js';

const getDealStatusClass = (status) => {
  const normalized = String(status ?? '').toLowerCase();
  if (normalized === 'completed' || normalized === 'won' || normalized.includes('policy')) {
    return 'client-detail-deal-badge--policy-issued';
  }
  if (normalized === 'in progress') return 'client-detail-deal-badge--in-progress';
  if (normalized === 'lost') return 'client-detail-deal-badge--lost';
  return 'client-detail-deal-badge--rfq';
};

const DISPLAY_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];

const formatRenewalDate = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '';

  const isoDateMatch = rawValue.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (isoDateMatch) {
    const [, year, month, day] = isoDateMatch;
    return `${Number(day)} ${DISPLAY_MONTHS[Number(month) - 1] ?? month} ${year}`;
  }

  const parsedDate = new Date(rawValue);
  if (Number.isNaN(parsedDate.getTime())) return rawValue;
  return `${parsedDate.getDate()} ${DISPLAY_MONTHS[parsedDate.getMonth()]} ${parsedDate.getFullYear()}`;
};

/**
 * Client "Opportunities & Pipeline Tracker" section — fetches its own data
 * (POST /clients/opportunities) and falls back to dummy rows until that endpoint exists.
 */
const ClientOpportunities = ({ clientUUID, onAddOpportunity }) => {
  const { data: opportunities = [] } = useClientOpportunities(clientUUID);
  const canAddOpportunity = Boolean(onAddOpportunity) && isListActionAllowed(opportunities?.isAdd);

  return (
    <Box className="client-detail-card">
      <Box className="client-detail-card-head">
        <Typography className="client-detail-card-title georama-SemiBold">
          {MSG.opportunitiesTitle(opportunities.length)}
        </Typography>
        {canAddOpportunity ? (
          <Button
            className="client-detail-add-btn client-detail-add-btn--green"
            onClick={onAddOpportunity}
          >
            {MSG.addNewOpportunity}
          </Button>
        ) : null}
      </Box>
      <TableContainer className="client-detail-table-wrap">
        <Table size="small" className="client-detail-table">
          <TableHead>
            <TableRow>
              {Object.values(MSG.opportunityColumns).map((label) => (
                <TableCell key={label}>{label}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {opportunities.length > 0 ? (
              opportunities.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{row.id}</TableCell>
                  <TableCell>{row.businessType}</TableCell>
                  <TableCell>{row.product}</TableCell>
                  <TableCell>{row.subProduct}</TableCell>
                  <TableCell>{row.owner}</TableCell>
                  <TableCell>{row.placementRm}</TableCell>
                  <TableCell>{formatRenewalDate(row.renewalDate)}</TableCell>
                  <TableCell>
                    <span className={`client-detail-deal-badge ${getDealStatusClass(row.status)}`}>
                      {row.status}
                    </span>
                  </TableCell>
                  <TableCell>{row.stage}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={9} className="client-detail-empty">
                  {MSG.noOpportunities}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default ClientOpportunities;
