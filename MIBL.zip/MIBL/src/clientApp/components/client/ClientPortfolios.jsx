import {
  Box,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import { CLIENT_DETAIL_MESSAGES as MSG } from '../../config/messages/clientDetail.js';
import { OPPORTUNITY_KDS_FIELDS } from '../../config/kdsFields.js';
import { useClientPortfolios, useKdsOptions } from '../../hooks/useFetchQueries.js';
import { isListActionAllowed } from '../../utils/listPermissions.js';

const buildOptionLabelMap = (options = []) =>
  new Map(options.map((option) => [option.code, option.value]).filter(([code]) => Boolean(code)));

const resolveOptionLabel = (value, optionMap) => optionMap.get(value) ?? value ?? '';
const mergeOptions = (...optionSets) => optionSets.flat().filter(Boolean);

/**
 * Client "Portfolios (Active)" section — fetches its own data (POST /clients/portfolios)
 * and falls back to dummy rows while that endpoint doesn't exist yet.
 */
const ClientPortfolios = ({
  clientUUID,
  initialPortfolios = [],
  fetchEnabled = true,
  showAddPortfolio = true,
  onAddPortfolio,
}) => {
  const { data: fetchedPortfolios = [] } = useClientPortfolios(clientUUID, {
    enabled: fetchEnabled,
  });
  const { data: productOptions = [] } = useKdsOptions(OPPORTUNITY_KDS_FIELDS.product);
  const portfolios = fetchEnabled ? fetchedPortfolios : initialPortfolios;
  const firstProductCode = portfolios.find((row) => row?.productCode)?.productCode ?? '';
  const { data: subProductOptions = [] } = useKdsOptions(OPPORTUNITY_KDS_FIELDS.subProduct);
  const { data: linkedSubProductOptions = [] } = useKdsOptions({
    ...OPPORTUNITY_KDS_FIELDS.subProduct,
    parentCode: firstProductCode,
    enabled: Boolean(firstProductCode),
  });
  const canAddPortfolio = showAddPortfolio && isListActionAllowed(fetchedPortfolios?.isAdd);
  const productLabelMap = buildOptionLabelMap(productOptions);
  const subProductLabelMap = buildOptionLabelMap(mergeOptions(subProductOptions, linkedSubProductOptions));
  const getPortfolioIdLabel = (row) => (fetchEnabled ? row.id : '---');

  return (
    <Box className="client-detail-card">
      <Box className="client-detail-card-head">
        <Typography className="client-detail-card-title georama-SemiBold">
          {MSG.portfoliosTitle(portfolios.length)}
        </Typography>
        {canAddPortfolio ? (
          <Button
            className="client-detail-add-btn client-detail-add-btn--green"
            onClick={onAddPortfolio}
          >
            {MSG.addNewPortfolio}
          </Button>
        ) : null}
      </Box>
      <TableContainer className="client-detail-table-wrap">
        <Table size="small" className="client-detail-table">
          <TableHead>
            <TableRow>
              {Object.values(MSG.portfolioColumns).map((label) => (
                <TableCell key={label}>{label}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {portfolios.length > 0 ? (
              portfolios.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{getPortfolioIdLabel(row)}</TableCell>
                  <TableCell>{resolveOptionLabel(row.product, productLabelMap)}</TableCell>
                  <TableCell>{resolveOptionLabel(row.subProductCode || row.subProduct, subProductLabelMap)}</TableCell>
                  <TableCell>{row.owner}</TableCell>
                  <TableCell>
                    <span className="client-detail-active-opps">{row.activeOpps}</span>
                  </TableCell>
                  <TableCell>{row.totalOpps}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="client-detail-empty">
                  {MSG.noPortfolios}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default ClientPortfolios;
