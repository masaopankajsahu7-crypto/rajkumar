import { Button, Dialog, Typography } from '@mui/material';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import FormatListBulletedRoundedIcon from '@mui/icons-material/FormatListBulletedRounded';
import PersonOutlineRoundedIcon from '@mui/icons-material/PersonOutlineRounded';
import DashboardRoundedIcon from '@mui/icons-material/DashboardRounded';
import { CLIENT_CREATE_MESSAGES as MSG } from '../../config/messages/client.js';
import './ClientSaveSuccessDialog.css';

/**
 * Success popup shown after a client is created/updated. Closing it (X, backdrop,
 * Escape, or the button) triggers onClose — the parent then routes to the client list.
 */
const ClientSaveSuccessDialog = ({
  open,
  isUpdate = false,
  onViewProfile,
  onReturnToList,
  title,
  message,
  primaryLabel,
  secondaryLabel,
  tertiaryLabel,
  showPrimary = true,
  showSecondary = true,
  showTertiary = false,
  onTertiary,
}) => {
  const D = MSG.saveDialog;
  const dialogTitle = title ?? (isUpdate ? D.updatedTitle : D.savedTitle);
  const dialogMessage = message ?? (isUpdate ? D.updatedMessage : D.savedMessage);
  const viewLabel = primaryLabel ?? D.viewProfile;
  const listLabel = secondaryLabel ?? D.returnToList;

  return (
    <Dialog open={open} className="client-save-dialog">
      <div className="client-save-dialog__content">
        <span className="client-save-dialog__icon-wrap">
          <CheckCircleRoundedIcon className="client-save-dialog__icon" />
        </span>
        <Typography className="client-save-dialog__title georama-SemiBold">{dialogTitle}</Typography>
        <Typography className="client-save-dialog__message georama-Regular">{dialogMessage}</Typography>
        {showPrimary ? (
          <Button className="client-save-dialog__btn client-save-dialog__btn--primary" onClick={onViewProfile}>
            <PersonOutlineRoundedIcon fontSize="small" />
            {viewLabel}
          </Button>
        ) : null}
        {showSecondary ? (
          <Button className="client-save-dialog__btn client-save-dialog__btn--secondary" onClick={onReturnToList}>
            <FormatListBulletedRoundedIcon fontSize="small" />
            {listLabel}
          </Button>
        ) : null}
        {showTertiary ? (
          <Button className="client-save-dialog__btn client-save-dialog__btn--secondary" onClick={onTertiary}>
            <DashboardRoundedIcon fontSize="small" />
            {tertiaryLabel}
          </Button>
        ) : null}
      </div>
    </Dialog>
  );
};

export default ClientSaveSuccessDialog;
