import { Accordion, AccordionDetails, AccordionSummary, Box, Typography } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const FormAccordionSection = ({ sectionId, title, expanded, onToggle, highlight, children }) => (
  <Accordion
    expanded={expanded}
    onChange={(_, isExpanded) => onToggle(sectionId, isExpanded)}
    className={`custom-accordion client-form-accordion${highlight ? ' client-form-accordion--highlight' : ''}${
      expanded ? ' client-form-accordion--expanded' : ''
    }`}
    disableGutters
    elevation={0}
  >
    <AccordionSummary
      expandIcon={
        <Box className="client-form-accordion-chevron-wrap">
          <ExpandMoreIcon className="client-form-accordion-chevron" />
        </Box>
      }
      className="client-form-accordion-summary"
    >
      <Box className="client-form-accordion-title-block">
        <Box className="client-form-accordion-title-bar" />
        <Typography className="georama-SemiBold client-form-accordion-title">{title}</Typography>
      </Box>
    </AccordionSummary>
    <AccordionDetails className="client-form-accordion-details">
      <Box className="client-form-section-body">{children}</Box>
    </AccordionDetails>
  </Accordion>
);

export default FormAccordionSection;
