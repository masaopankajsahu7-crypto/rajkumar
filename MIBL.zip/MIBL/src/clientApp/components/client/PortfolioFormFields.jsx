import { useEffect } from 'react';
import { Box, Button, FormControl, FormHelperText, MenuItem, Select, TextField, Typography } from '@mui/material';
import { PORTFOLIO_MESSAGES as MSG } from '../../config/messages/portfolio.js';
import { COMMON_MESSAGES } from '../../config/messages/common.js';
import { PORTFOLIO_FORM_VALIDATION as CFG } from '../../config/validation/portfolioForm.js';
import {
  emptyOtherContact,
  MAX_PORTFOLIO_OTHER_CONTACTS,
  showExpiringPolicyDetails,
} from '../../utils/portfolioFormState.js';
import { sanitizeByField } from '../../utils/fieldUtils.js';
import KdsSelect from '../common/KdsSelect.jsx';
import { OPPORTUNITY_KDS_FIELDS } from '../../config/kdsFields.js';

const PortfolioFormFields = ({
  portfolio,
  errors = {},
  onChange,
  disabled = false,
  lockedFields = [],
  hideContacts = false,
}) => {
  // Contacts still auto-populate from the client, but are now editable (nothing locked read-only).
  const readOnlyFields = new Set();
  const lockedFieldSet = new Set(lockedFields);
  const otherContacts = portfolio.other_contacts ?? [];
  const showExpiringPolicy = showExpiringPolicyDetails(portfolio.business_type);
  const formatDateForInput = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };
  const getRenewalDateRange = () => {
    const min = new Date();
    const max = new Date();
    min.setFullYear(min.getFullYear() - 5);
    max.setFullYear(max.getFullYear() + 5);
    return { min: formatDateForInput(min), max: formatDateForInput(max) };
  };
  const renewalDateRange = getRenewalDateRange();

  useEffect(() => {
    if (!portfolio.product && portfolio.sub_product) {
      onChange('sub_product', '');
    }
  }, [onChange, portfolio.product, portfolio.sub_product]);

  const handleProductChange = (code) => {
    if (lockedFieldSet.has('product')) return;
    onChange('product', code);
    onChange('sub_product', '');
  };

  const handleFieldChange = (field) => (event) => {
    const fieldType = CFG.fieldTypes[field];
    let value = event.target.value;

    if (fieldType) {
      value = sanitizeByField(fieldType, value);
    }

    onChange(field, value);
  };

  const handleOtherContactChange = (index, field) => (event) => {
    let value = event.target.value;
    if (field === 'mobile') value = sanitizeByField('mobile', value);
    if (field === 'email') value = sanitizeByField('email', value);

    const nextContacts = otherContacts.map((item, itemIndex) =>
      itemIndex === index ? { ...item, [field]: value } : item,
    );
    onChange('other_contacts', nextContacts);
  };

  const handleAddOtherContact = () => {
    if (otherContacts.length >= MAX_PORTFOLIO_OTHER_CONTACTS) return;
    onChange('other_contacts', [...otherContacts, emptyOtherContact()]);
  };

  const handleRemoveOtherContact = (index) => {
    onChange(
      'other_contacts',
      otherContacts.filter((_, itemIndex) => itemIndex !== index),
    );
  };

  const isRequired = (field) =>
    CFG.required.includes(field) ||
    (showExpiringPolicy &&
      ['policy_start_date', 'policy_expiry_date', 'previous_insurer', 'previous_policy_number'].includes(field));

  const isOtherFieldReadOnly = (index, field) =>
    readOnlyFields.has(`other_contact_${index}_${field}`);

  const renderSection = (title, children, isFirst = false, wrapGrid = true) => (
    <Box className={`client-form-portfolio-section${isFirst ? '' : ' client-form-portfolio-section--spaced'}`}>
      <Typography className="client-form-portfolio-section-title georama-SemiBold">{title}</Typography>
      {wrapGrid ? <Box className="client-form-portfolio-grid">{children}</Box> : children}
    </Box>
  );

  const renderLabel = (label, field) => (
    <Typography className="text-labels client-form-label">
      {label} {isRequired(field) && <span className="important-fields">*</span>}
    </Typography>
  );

  const renderTextField = ({ field, label, type = 'text', readOnly = false, placeholder }) => (
    <Box className="client-form-field">
      {renderLabel(label, field)}
      <TextField
        className={`form-control-input border-radius-8${readOnly || disabled || lockedFieldSet.has(field) ? ' disabled-input' : ''}`}
        size="small"
        fullWidth
        type={type}
        value={portfolio[field] ?? ''}
        placeholder={type === 'date' ? undefined : placeholder}
        error={!!errors[field]}
        onChange={handleFieldChange(field)}
        disabled={disabled || lockedFieldSet.has(field)}
        InputProps={{ readOnly: readOnly || readOnlyFields.has(field) || lockedFieldSet.has(field) }}
        InputLabelProps={type === 'date' ? { shrink: true } : undefined}
        inputProps={type === 'date' && field === 'renewal_date' ? renewalDateRange : undefined}
      />
      {errors[field] && <FormHelperText className="important-fields">{errors[field]}</FormHelperText>}
    </Box>
  );

  const renderOtherContactField = ({ index, field, label, type = 'text', placeholder }) => {
    const errorKey = `other_contact_${field}_${index}`;
    const readOnly = isOtherFieldReadOnly(index, field);

    return (
      <Box className="client-form-field">
        {renderLabel(label, null)}
        <TextField
          className={`form-control-input border-radius-8${readOnly ? ' disabled-input' : ''}`}
          size="small"
          fullWidth
          type={type}
          value={otherContacts[index]?.[field] ?? ''}
          placeholder={placeholder}
          error={!!errors[errorKey]}
          onChange={handleOtherContactChange(index, field)}
          disabled={disabled}
          InputProps={{ readOnly }}
        />
        {errors[errorKey] && <FormHelperText className="important-fields">{errors[errorKey]}</FormHelperText>}
      </Box>
    );
  };

  const renderSelect = ({ field, label, options, placeholder = COMMON_MESSAGES.select, changeHandler }) => (
    <Box className="client-form-field">
      {renderLabel(label, field)}
      <FormControl size="small" fullWidth error={!!errors[field]}>
        <Select
          className={`form-control-input border-radius-8${lockedFieldSet.has(field) ? ' disabled-input' : ''}`}
          displayEmpty
          value={portfolio[field] ?? ''}
          onChange={changeHandler ?? handleFieldChange(field)}
          disabled={disabled || lockedFieldSet.has(field)}
          renderValue={(selected) => selected || placeholder}
        >
          <MenuItem value="" disabled>
            {placeholder}
          </MenuItem>
          {options.map((option) => (
            <MenuItem key={option} value={option}>
              {option}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      {errors[field] && <FormHelperText className="important-fields">{errors[field]}</FormHelperText>}
    </Box>
  );

  const renderExpiringPolicySection = () => (
    <>
      <Typography className="client-form-portfolio-subsection-title georama-SemiBold">
        {MSG.sections.expiringPolicyDetails}
      </Typography>
      <Box className="client-form-portfolio-grid">
        {renderTextField({
          field: 'policy_start_date',
          label: MSG.labels.policyStartDate,
          type: 'date',
        })}
        {renderTextField({
          field: 'policy_expiry_date',
          label: MSG.labels.policyExpiryDate,
          type: 'date',
        })}
        <KdsSelect
          {...OPPORTUNITY_KDS_FIELDS.previousInsurer}
          label={MSG.labels.previousInsurer}
          value={portfolio.previous_insurer}
          onChange={(code) => onChange('previous_insurer', code)}
          required={isRequired('previous_insurer')}
          placeholder={MSG.placeholders.previousInsurer}
          error={errors.previous_insurer}
          disabled={disabled || lockedFieldSet.has('previous_insurer')}
        />
        {renderTextField({
          field: 'previous_policy_number',
          label: MSG.labels.previousPolicyNumber,
          placeholder: MSG.placeholders.previousPolicyNumber,
        })}
      </Box>
    </>
  );

  const renderPortfolioSection = () => (
    <Box className="client-form-portfolio-section-body">
      <Box className="client-form-portfolio-grid">
        <KdsSelect
          {...OPPORTUNITY_KDS_FIELDS.product}
          label={MSG.labels.product}
          value={portfolio.product}
          onChange={handleProductChange}
          required={isRequired('product')}
          placeholder={MSG.placeholders.product}
          error={errors.product}
          disabled={disabled || lockedFieldSet.has('product')}
        />
        <KdsSelect
          {...OPPORTUNITY_KDS_FIELDS.subProduct}
          label={MSG.labels.subProduct}
          value={portfolio.sub_product}
          parentCode={portfolio.product}
          cascade
          onChange={(code) => onChange('sub_product', code)}
          required={isRequired('sub_product')}
          placeholder={MSG.placeholders.subProduct}
          error={errors.sub_product}
          disabled={disabled || lockedFieldSet.has('sub_product') || !portfolio.product}
        />
      </Box>

      <Box className="client-form-portfolio-grid client-form-portfolio-grid--single">
        <KdsSelect
          {...OPPORTUNITY_KDS_FIELDS.businessType}
          label={MSG.labels.businessType}
          value={portfolio.business_type}
          onChange={(code) => onChange('business_type', code)}
          required={isRequired('business_type')}
          placeholder={MSG.placeholders.businessType}
          error={errors.business_type}
          disabled={disabled || lockedFieldSet.has('business_type')}
        />
      </Box>

      <Box className="client-form-portfolio-group-divider" aria-hidden="true" />

      {showExpiringPolicy && (
        <>
          {renderExpiringPolicySection()}
          <Box className="client-form-portfolio-group-divider" aria-hidden="true" />
        </>
      )}

      <Box className="client-form-portfolio-grid">
        {renderTextField({
          field: 'sum_insured',
          label: MSG.labels.sumInsured,
          placeholder: MSG.placeholders.sumInsured,
        })}
        {renderTextField({
          field: 'expected_premium',
          label: MSG.labels.expectedPremium,
          placeholder: MSG.placeholders.expectedPremium,
        })}
        {renderTextField({
          field: 'brokerage_consultancy',
          label: MSG.labels.brokerageConsultancy,
          placeholder: MSG.placeholders.brokerageConsultancy,
        })}
        {renderTextField({
          field: 'renewal_date',
          label: MSG.labels.renewalDate,
          type: 'date',
        })}
      </Box>

      {!hideContacts && (
        <>
          <Box className="client-form-portfolio-group-divider" aria-hidden="true" />

          <Typography className="client-form-portfolio-subsection-title georama-SemiBold">
            {MSG.sections.portfolioOwnerDetails}
          </Typography>
          <Box className="client-form-portfolio-grid">
            {renderTextField({
              field: 'primary_contact_person',
              label: MSG.labels.primaryContactPerson,
              placeholder: MSG.placeholders.primaryContactPerson,
            })}
            {renderTextField({
              field: 'primary_contact_mobile',
              label: MSG.labels.primaryContactMobile,
              placeholder: MSG.placeholders.primaryContactMobile,
            })}
            {renderTextField({
              field: 'primary_contact_email',
              label: MSG.labels.primaryContactEmail,
              placeholder: MSG.placeholders.primaryContactEmail,
            })}
          </Box>

          {otherContacts.map((_, index) => (
            <Box key={index} className="client-form-portfolio-other-contact-block">
              <Box className="client-form-portfolio-other-contact-head">
                <Typography className="client-form-portfolio-other-contact-title georama-Medium">
                  {MSG.otherContactTitle(index)}
                </Typography>
                <Button
                  className="client-form-add-contact-btn important-fields"
                  onClick={() => handleRemoveOtherContact(index)}
                  disabled={disabled || isOtherFieldReadOnly(index, 'name')}
                >
                  {MSG.buttons.remove}
                </Button>
              </Box>
              <Box className="client-form-portfolio-grid">
                {renderOtherContactField({
                  index,
                  field: 'name',
                  label: MSG.labels.otherContact,
                  placeholder: MSG.placeholders.otherContact,
                })}
                {renderOtherContactField({
                  index,
                  field: 'mobile',
                  label: MSG.labels.otherContactMobile,
                  placeholder: MSG.placeholders.otherContactMobile,
                })}
                {renderOtherContactField({
                  index,
                  field: 'email',
                  label: MSG.labels.otherContactEmail,
                  placeholder: MSG.placeholders.otherContactEmail,
                })}
              </Box>
            </Box>
          ))}

          {otherContacts.length < MAX_PORTFOLIO_OTHER_CONTACTS && (
            <Box className="client-form-portfolio-add-action">
              <Button className="client-form-add-contact-btn text-sky" onClick={handleAddOtherContact} disabled={disabled}>
                {MSG.buttons.addOtherContact}
              </Button>
            </Box>
          )}
        </>
      )}
    </Box>
  );

  return renderPortfolioSection();
};

export default PortfolioFormFields;
