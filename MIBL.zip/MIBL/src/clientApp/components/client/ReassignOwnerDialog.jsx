import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Chip,
  Dialog,
  DialogContent,
  DialogTitle,
  TextField,
  Typography,
} from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import WarningAmberOutlinedIcon from '@mui/icons-material/WarningAmberOutlined';
import { REASSIGN_OWNER_MESSAGES as MSG } from '../../config/messages/reassignOwner.js';
import { searchAssignableOwners } from '../../services/api.jsx';
import './ReassignOwnerDialog.css';

const normalizeOwnerName = (owner) =>
  String(
    owner?.owner_name ??
      owner?.key_value ??
      owner?.full_name ??
      owner?.name ??
      owner?.value ??
      owner?.user_name ??
      owner?.username ??
      '',
  ).trim();

const normalizeOwnerCode = (owner) =>
  String(
    owner?.owner_id ??
      owner?.userid ??
      owner?.key_code ??
      owner?.id ??
      owner?.code ??
      owner?.user_id ??
      '',
  ).trim();

const ReassignOwnerDialog = ({
  open,
  onClose,
  onCommit,
  primaryOwner = '',
  coOwners = [],
  mode = 'dialog',
  showCoOwners = true,
  infoContent = MSG.info,
  ownerOptionsOverride = null,
  ownerOptionsLoading = false,
}) => {
  const [ownerOptions, setOwnerOptions] = useState([]);
  const [selectedPrimaryOwner, setSelectedPrimaryOwner] = useState(null);
  const [selectedCoOwners, setSelectedCoOwners] = useState([]);
  const [coOwnerSearch, setCoOwnerSearch] = useState('');
  const [ownerSearch, setOwnerSearch] = useState('');
  const [reason, setReason] = useState('');
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const normalizedOwnerOptionsOverride = useMemo(() => {
    if (!Array.isArray(ownerOptionsOverride)) return null;
    return ownerOptionsOverride
      .map((owner) => ({
        ...owner,
        code: normalizeOwnerCode(owner),
        value: normalizeOwnerName(owner),
      }))
      .filter((owner) => owner.code && owner.value);
  }, [ownerOptionsOverride]);

  useEffect(() => {
    if (!open) return undefined;

    let ignoreResult = false;
    setSelectedCoOwners(
      coOwners
        .map((owner) => ({
          code: normalizeOwnerCode(owner),
          value: normalizeOwnerName(owner),
        }))
        .filter((owner) => owner.value),
    );
    setSelectedPrimaryOwner({
      code: normalizeOwnerCode(primaryOwner),
      value: normalizeOwnerName(primaryOwner) || String(primaryOwner || '').trim(),
    });
    setCoOwnerSearch('');
    setOwnerSearch('');
    setReason('');
    setErrorMessage('');

    return () => {
      ignoreResult = true;
    };
  }, [coOwners, open, primaryOwner]);

  useEffect(() => {
    if (normalizedOwnerOptionsOverride) {
      setOwnerOptions(normalizedOwnerOptionsOverride);
      setLoadingOptions(false);
      return undefined;
    }
    if (!open) return undefined;
    const normalizedSearch = String(ownerSearch ?? '').trim();
    if (normalizedSearch.length < 2) {
      setOwnerOptions([]);
      setLoadingOptions(false);
      return undefined;
    }

    let ignoreResult = false;
    setLoadingOptions(true);
    const timer = window.setTimeout(() => {
      searchAssignableOwners(normalizedSearch)
        .then((options) => {
          if (!ignoreResult) setOwnerOptions(options);
        })
        .catch(() => {
          if (!ignoreResult) setErrorMessage(MSG.ownerOptionsError);
        })
        .finally(() => {
          if (!ignoreResult) setLoadingOptions(false);
        });
    }, 350);

    return () => {
      ignoreResult = true;
      window.clearTimeout(timer);
    };
  }, [normalizedOwnerOptionsOverride, open, ownerSearch]);

  const selectedCoOwnerCodes = useMemo(
    () => new Set(selectedCoOwners.map((owner) => String(owner.code))),
    [selectedCoOwners],
  );

  const overrideOwnerCodes = useMemo(
    () => new Set((normalizedOwnerOptionsOverride ?? []).map((owner) => String(owner.code))),
    [normalizedOwnerOptionsOverride],
  );

  const availableCoOwnerOptions = useMemo(
    () => ownerOptions.filter((owner) => !selectedCoOwnerCodes.has(String(owner.code))),
    [ownerOptions, selectedCoOwnerCodes],
  );

  const hasSelectedPrimaryOwnerId = Boolean(selectedPrimaryOwner?.code);
  const hasEligiblePrimaryOwnerId =
    !normalizedOwnerOptionsOverride ||
    overrideOwnerCodes.has(String(selectedPrimaryOwner?.code ?? ''));
  const hasSelectedCoOwnerId = selectedCoOwners.some((owner) => Boolean(owner?.code));
  const canCommitAssignment =
    Boolean(String(reason).trim()) &&
    (normalizedOwnerOptionsOverride ? hasEligiblePrimaryOwnerId : hasSelectedPrimaryOwnerId || Boolean(String(selectedPrimaryOwner?.value ?? '').trim())) &&
    (showCoOwners ? hasSelectedPrimaryOwnerId || hasSelectedCoOwnerId : true) &&
    !ownerOptionsLoading &&
    !submitting;
  const ownershipInfo = infoContent ?? MSG.info;
  const ownershipInfoBullets = Array.isArray(ownershipInfo?.bullets) ? ownershipInfo.bullets : [];

  const handleAppendCoOwner = (owner) => {
    if (!owner) return;
    setSelectedCoOwners((prev) => [...prev, owner]);
    setCoOwnerSearch('');
  };

  const handleDeleteCoOwner = (ownerCode) => {
    setSelectedCoOwners((prev) => prev.filter((owner) => String(owner.code) !== String(ownerCode)));
  };

  const handleCommit = async () => {
    const normalizedReason = String(reason ?? '').trim();
    if (
      (normalizedOwnerOptionsOverride && !hasEligiblePrimaryOwnerId) ||
      (!normalizedOwnerOptionsOverride && !hasSelectedPrimaryOwnerId && !String(selectedPrimaryOwner?.value ?? '').trim())
    ) {
      setErrorMessage('Select a valid Primary Account Owner');
      return;
    }
    if (!normalizedReason) {
      setErrorMessage(MSG.reasonRequired);
      return;
    }

    setSubmitting(true);
    setErrorMessage('');
    try {
      await onCommit?.({
        owner: selectedPrimaryOwner,
        coOwners: selectedCoOwners,
        remarks: normalizedReason,
      });
    } catch (error) {
      setErrorMessage(error?.message ?? MSG.commitError);
    } finally {
      setSubmitting(false);
    }
  };

  const content = (
    <>
      <Box className="reassign-owner-info">
        <InfoOutlinedIcon className="reassign-owner-info-icon" />
        <Box>
          <Typography className="reassign-owner-info-title">{ownershipInfo.title}</Typography>
          <Typography className="reassign-owner-info-text">{ownershipInfo.description}</Typography>
          {ownershipInfoBullets.length > 0 ? (
            <Box component="ul" className="reassign-owner-info-list">
              {ownershipInfoBullets.map((bullet) => (
                <li key={bullet}>{bullet}</li>
              ))}
            </Box>
          ) : null}
        </Box>
      </Box>

      <Box className="reassign-owner-field-block">
        <Typography className="reassign-owner-label">{MSG.primaryOwnerLabel}</Typography>
        <Autocomplete
          className="reassign-owner-select"
          options={ownerOptions}
          value={selectedPrimaryOwner}
          getOptionLabel={(option) => String(option?.value ?? '')}
          isOptionEqualToValue={(option, value) => String(option.code) === String(value.code)}
          onChange={(_, option) => setSelectedPrimaryOwner(option)}
          onInputChange={(_, value, reason) => {
            if (reason === 'input' && !normalizedOwnerOptionsOverride) setOwnerSearch(value);
          }}
          loading={loadingOptions || ownerOptionsLoading}
          disabled={submitting}
          noOptionsText="No matching owner found"
          renderInput={(params) => (
            <TextField {...params} placeholder={MSG.primaryOwnerPlaceholder} size="small" />
          )}
          fullWidth
        />
      </Box>

      {showCoOwners ? (
        <>
          <Box className="reassign-owner-field-block">
            <Typography className="reassign-owner-label">{MSG.coOwnerLabel}</Typography>
            <Autocomplete
              className="reassign-owner-select reassign-owner-coowner-search"
              multiple
              options={availableCoOwnerOptions}
              value={selectedCoOwners}
              inputValue={coOwnerSearch}
              getOptionLabel={(option) => String(option?.value ?? '')}
              isOptionEqualToValue={(option, value) => String(option.code) === String(value.code)}
              onChange={(_, value, reason, details) => {
                if (reason === 'selectOption') handleAppendCoOwner(details?.option);
                if (reason === 'removeOption' || reason === 'clear') setSelectedCoOwners(value);
              }}
              onInputChange={(_, value, reason) => {
                if (reason === 'input') {
                  setCoOwnerSearch(value);
                  setOwnerSearch(value);
                }
                if (reason === 'clear') setCoOwnerSearch('');
              }}
              loading={loadingOptions}
              disabled={submitting}
              noOptionsText="No matching owner found"
              renderTags={(value, getTagProps) =>
                value.map((option, index) => {
                  const { key, ...tagProps } = getTagProps({ index });
                  return (
                    <Chip
                      key={key}
                      {...tagProps}
                      label={option.value}
                      onDelete={() => handleDeleteCoOwner(option.code)}
                      className="reassign-owner-chip"
                      size="small"
                    />
                  );
                })
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  placeholder={selectedCoOwners.length > 0 ? '' : MSG.coOwnerPlaceholder}
                  size="small"
                />
              )}
              fullWidth
            />
          </Box>
        </>
      ) : null}

      <Box className="reassign-owner-field-block">
        <Typography className="reassign-owner-label">{MSG.reasonLabel}</Typography>
        <TextField
          className="reassign-owner-input reassign-owner-reason"
          placeholder={MSG.reasonPlaceholder}
          value={reason}
          onChange={(event) => setReason(event.target.value)}
          disabled={submitting}
          multiline
          minRows={3}
          fullWidth
        />
      </Box>

      {errorMessage ? <Alert severity="error">{errorMessage}</Alert> : null}

      <Box className="reassign-owner-actions">
        <Button
          className="btn-common-red reassign-owner-commit-btn"
          onClick={handleCommit}
          disabled={!canCommitAssignment}
        >
          {submitting ? MSG.committing : MSG.commit}
        </Button>
        <Button className="reassign-owner-cancel-btn" onClick={onClose} disabled={submitting}>
          {MSG.cancel}
        </Button>
      </Box>

      <Box className="reassign-owner-warning">
        <WarningAmberOutlinedIcon className="reassign-owner-warning-icon" />
        <Box>
          <Typography className="reassign-owner-warning-title">{MSG.warning.title}</Typography>
          <Typography className="reassign-owner-warning-text">{MSG.warning.description}</Typography>
        </Box>
      </Box>
    </>
  );

  if (mode === 'section') {
    if (!open) return null;
    return (
      <Box className="reassign-owner-section">
        <Typography className="reassign-owner-dialog-title reassign-owner-section-title">
          {MSG.title}
        </Typography>
        <Box className="reassign-owner-dialog-content reassign-owner-section-content">
          {content}
        </Box>
      </Box>
    );
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{ className: 'reassign-owner-dialog-paper' }}
    >
      <DialogTitle className="reassign-owner-dialog-title">{MSG.title}</DialogTitle>
      <DialogContent className="reassign-owner-dialog-content">
        {content}
      </DialogContent>
    </Dialog>
  );
};

export default ReassignOwnerDialog;
