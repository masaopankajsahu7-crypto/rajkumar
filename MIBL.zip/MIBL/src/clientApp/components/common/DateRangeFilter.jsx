import { useState } from 'react';
import { Badge, Box, Button, FormControl, MenuItem, Popover, Select, TextField, Typography } from '@mui/material';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import CloseIcon from '@mui/icons-material/Close';
import SwapVertRoundedIcon from '@mui/icons-material/SwapVertRounded';
import {
  DATE_FILTER_TYPES,
  DATE_RANGE_OPTIONS,
  countActiveDateFilters,
  getDateRangeForPreset,
} from '../../utils/dateRangeFilters.js';

const DateRangeFilter = ({
  filters,
  appliedFilters = filters,
  dateFromField,
  dateToField,
  onChange,
  onApply,
  labels,
  showDateFilterType = true,
  sortOptions = [],
}) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const activeCount = countActiveDateFilters(appliedFilters, { includeDateType: showDateFilterType });
  const hasSortOptions = sortOptions.length > 0;
  const controlLabel = hasSortOptions ? labels.sortAndRange ?? 'Sort & Range' : labels.dateRangePreset;

  const handlePresetChange = (event) => {
    const preset = event.target.value;
    onChange('dateRangePreset', preset);
    const range = getDateRangeForPreset(preset);
    if (range) {
      onChange(dateFromField, range.fromDate);
      onChange(dateToField, range.toDate);
    }
  };

  const renderSelect = (field, placeholder, options, onSelect) => (
    <FormControl size="small" fullWidth className="client-mgmt-filter-control">
      <Select
        className="client-mgmt-filter-select form-control-input border-radius-8"
        displayEmpty
        value={filters[field] ?? ''}
        onChange={onSelect ?? ((event) => onChange(field, event.target.value))}
        renderValue={(selected) => options.find((option) => option.code === selected)?.value ?? placeholder}
      >
        {options.map((option) => (
          <MenuItem key={option.code} value={option.code}>{option.value}</MenuItem>
        ))}
      </Select>
    </FormControl>
  );

  const handleApply = () => {
    onApply();
    setAnchorEl(null);
  };

  return (
    <>
      <Badge
        badgeContent={activeCount}
        color="error"
        invisible={activeCount === 0}
        className="client-mgmt-filter-badge"
      >
        <Button
          className="client-mgmt-date-range-btn client-mgmt-icon-btn"
          onClick={(event) => setAnchorEl(event.currentTarget)}
          aria-label={controlLabel}
        >
          {hasSortOptions ? <SwapVertRoundedIcon fontSize="small" /> : <CalendarMonthOutlinedIcon fontSize="small" />}
        </Button>
      </Badge>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        className="client-mgmt-date-range-popover"
        slotProps={{ paper: { className: 'client-mgmt-date-range-paper' } }}
      >
        <Box className="client-mgmt-filter-popover-head">
          <Typography className="georama-SemiBold client-mgmt-filter-popover-title">
            {controlLabel}
          </Typography>
          <Button
            className="client-mgmt-filter-popover-close"
            onClick={() => setAnchorEl(null)}
            aria-label={labels.clear}
          >
            <CloseIcon fontSize="small" />
          </Button>
        </Box>
        <Box className="client-mgmt-date-range-body">
          {renderSelect('dateRangePreset', labels.dateRangePreset, DATE_RANGE_OPTIONS, handlePresetChange)}
          {showDateFilterType
            ? renderSelect('dateFilterType', labels.dateFilterType, DATE_FILTER_TYPES)
            : null}
          {hasSortOptions
            ? renderSelect('sortColumn', labels.sortBy ?? 'Sort By', sortOptions)
            : null}
          {filters.dateRangePreset === 'CUSTOM' && (
            <Box className="client-mgmt-filter-popover-row">
              <TextField
                className="client-mgmt-filter-input"
                size="small"
                fullWidth
                type="date"
                value={filters[dateFromField] ?? ''}
                onChange={(event) => onChange(dateFromField, event.target.value)}
              />
              <TextField
                className="client-mgmt-filter-input"
                size="small"
                fullWidth
                type="date"
                value={filters[dateToField] ?? ''}
                onChange={(event) => onChange(dateToField, event.target.value)}
              />
            </Box>
          )}
        </Box>
        <Box className="client-mgmt-filter-popover-actions">
          <Button className="btn-common-red client-mgmt-filter-apply-btn" onClick={handleApply}>
            {labels.apply}
          </Button>
        </Box>
      </Popover>
    </>
  );
};

export default DateRangeFilter;
