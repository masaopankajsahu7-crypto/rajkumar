import { useEffect, useMemo } from 'react';
import { Autocomplete, Box, FormControl, FormHelperText, Popper, TextField, Typography } from '@mui/material';
import { useKdsOptions } from '../../hooks/useFetchQueries.js';
import { COMMON_MESSAGES } from '../../config/messages/common.js';

const KdsPopper = (props) => (
  <Popper
    {...props}
    placement="bottom-start"
    modifiers={[
      { name: 'flip', enabled: false },
      { name: 'preventOverflow', enabled: false },
    ]}
  />
);

/**
 * Reusable dropdown backed by the master-service `kds` endpoint.
 *
 * Contract: stores the option `code` (key_code) as its value and shows the option `value`
 * (key_value) as the label. Every dropdown flows through this one component, so wiring a new
 * one is just <KdsSelect {...KDS_FIELD} ... />.
 *
 * Dependent (cascading) dropdowns: pass `parentCode` = the selected parent's code. The request
 * sends parent_code, and rows with parent metadata are also filtered client-side.
 */
const KdsSelect = ({
  label,
  module = 'client',
  source,
  name,
  value,
  onChange,
  required = false,
  placeholder = COMMON_MESSAGES.select,
  error,
  onClearError,
  parentCode = '',
  cascade = false,
  disabled = false,
  onResolvedOption,
  menuPaperClassName = '',
  menuListClassName = '',
  menuItemClassName = '',
}) => {
  const { data: allOptions = [], isLoading } = useKdsOptions({
    module,
    source,
    name,
    parentCode,
  });

  const options = useMemo(() => {
    if (!cascade) return allOptions;
    if (!parentCode) return [];

    const hasParentLinks = allOptions.some((option) => option.parentCode || option.parentValue);
    if (!hasParentLinks) return allOptions;

    return allOptions.filter(
      (option) => option.parentCode === parentCode || option.parentValue === parentCode,
    );
  }, [allOptions, cascade, parentCode]);

  const normalizedValue = String(value ?? '').trim();
  const selectedOption =
    options.find(
      (option) =>
        String(option.code ?? '').trim() === normalizedValue ||
        String(option.value ?? '').trim() === normalizedValue,
    ) ?? null;

  useEffect(() => {
    if (selectedOption) onResolvedOption?.(selectedOption);
  }, [selectedOption, onResolvedOption]);

  return (
    <Box className="client-form-field">
      <Typography className="text-labels client-form-label">
        {label} {required && <span className="important-fields">*</span>}
      </Typography>
      <FormControl size="small" fullWidth error={!!error}>
        <Autocomplete
          className="client-kds-autocomplete form-control-input border-radius-8"
          options={options}
          value={selectedOption}
          loading={isLoading}
          disabled={disabled}
          autoHighlight
          openOnFocus
          PopperComponent={KdsPopper}
          getOptionLabel={(option) => option?.value ?? ''}
          isOptionEqualToValue={(option, selected) => option.code === selected.code || option.value === selected.value}
          noOptionsText={isLoading ? COMMON_MESSAGES.loading : COMMON_MESSAGES.noDataFound}
          onChange={(_, selected) => {
            onChange(selected?.code ?? '');
            onClearError?.();
          }}
          slotProps={{
            paper: { className: `client-kds-menu-paper ${menuPaperClassName}`.trim() },
            listbox: { className: `client-kds-menu-list ${menuListClassName}`.trim() },
          }}
          renderInput={(params) => (
            <TextField
              {...params}
              size="small"
              placeholder={placeholder}
              error={!!error}
            />
          )}
          renderOption={(props, option) => {
            const { key, className, ...optionProps } = props;
            return (
              <li
                key={key}
                {...optionProps}
                className={`${className ?? ''} client-kds-menu-item client-kds-menu-item--simple ${menuItemClassName}`.trim()}
              >
                {option.value}
              </li>
            );
          }}
        />
      </FormControl>
      {error && <FormHelperText className="important-fields">{error}</FormHelperText>}
    </Box>
  );
};

export default KdsSelect;
