import { Box, Typography } from '@mui/material';
import { formatClockTime } from '../../utils/datetime.js';
import './LastUpdatedLabel.css';

/**
 * Presentational, page-agnostic "cache freshness" indicator.
 * Shows when the currently displayed (cached) data was last fetched,
 * and optionally that a background refresh is in flight.
 *
 * Props:
 *  - updatedAt:       epoch ms of when the data was cached (e.g. React Query's dataUpdatedAt)
 *  - isRefreshing:    whether a background refetch is currently running
 *  - label:           prefix text (defaults provided so the component is reusable as-is)
 *  - refreshingLabel: suffix text shown while refreshing
 */
const LastUpdatedLabel = ({
  updatedAt,
  isRefreshing = false,
  label = 'Last updated',
  refreshingLabel = 'refreshing…',
}) => {
  const time = formatClockTime(updatedAt);
  if (!time) return null;

  return (
    <Box className="last-updated-label-row">
      <Typography className="last-updated-label georama-Regular">
        {`${label} ${time}`}
        {isRefreshing && (
          <span className="last-updated-label-refreshing">{` • ${refreshingLabel}`}</span>
        )}
      </Typography>
    </Box>
  );
};

export default LastUpdatedLabel;
