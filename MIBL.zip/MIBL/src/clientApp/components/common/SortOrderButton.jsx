import { Button, Tooltip } from '@mui/material';
import ArrowDownwardRoundedIcon from '@mui/icons-material/ArrowDownwardRounded';
import ArrowUpwardRoundedIcon from '@mui/icons-material/ArrowUpwardRounded';

const SortOrderButton = ({ value, onToggle }) => {
  const isAscending = String(value ?? '').toUpperCase() === 'ASC';
  const label = isAscending ? 'Order ascending' : 'Order descending';

  return (
    <Tooltip title={label} arrow>
      <Button
        className="client-mgmt-sort-order-btn client-mgmt-icon-btn"
        onClick={onToggle}
        aria-label={label}
        aria-pressed={isAscending}
      >
        {isAscending ? <ArrowUpwardRoundedIcon fontSize="small" /> : <ArrowDownwardRoundedIcon fontSize="small" />}
      </Button>
    </Tooltip>
  );
};

export default SortOrderButton;
