import { useEffect, useRef, useState } from 'react';
import { IconButton, InputAdornment, TextField, Tooltip, Typography } from '@mui/material';
import MicNoneOutlinedIcon from '@mui/icons-material/MicNoneOutlined';
import MicOutlinedIcon from '@mui/icons-material/MicOutlined';
import './VoiceTextField.css';

const getSpeechRecognition = () => {
  if (typeof window === 'undefined') return null;
  return window.SpeechRecognition || window.webkitSpeechRecognition || null;
};

const VoiceTextField = ({ InputProps = {}, inputRef, onChange, onListeningChange, value = '', className = '', ...textFieldProps }) => {
  const [isListening, setIsListening] = useState(false);
  const [speechMessage, setSpeechMessage] = useState('');
  const textInputRef = useRef(null);
  const recognitionRef = useRef(null);
  const pauseTimerRef = useRef(null);
  const baseTextRef = useRef('');
  const finalTranscriptRef = useRef('');
  const interimTranscriptRef = useRef('');
  const SpeechRecognition = getSpeechRecognition();

  const assignInputRef = (node) => {
    textInputRef.current = node;
    if (typeof inputRef === 'function') inputRef(node);
    else if (inputRef) inputRef.current = node;
  };

  const emitValue = (nextValue) => {
    onChange?.({ target: { value: nextValue, name: textFieldProps.name ?? '' } });
  };

  const handleInputChange = (event) => {
    const nextValue = event.target.value;
    if (recognitionRef.current) {
      baseTextRef.current = nextValue;
      finalTranscriptRef.current = '';
      interimTranscriptRef.current = '';
      recognitionRef.current.stop();
    }
    onChange?.(event);
  };

  const handleVoiceInput = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      return;
    }
    if (!SpeechRecognition) return;

    const input = textInputRef.current;
    const currentText = String(value ?? '');
    if (input) {
      input.focus();
      input.setSelectionRange(currentText.length, currentText.length);
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = navigator.language || 'en-IN';

    const resetPauseTimer = () => {
      window.clearTimeout(pauseTimerRef.current);
      pauseTimerRef.current = window.setTimeout(() => {
        if (recognitionRef.current === recognition) recognition.stop();
      }, 3000);
    };

    const appendToBase = (transcript) => {
      const base = baseTextRef.current;
      if (!transcript) return base;
      return `${base}${base && !/\s$/.test(base) ? ' ' : ''}${transcript}`;
    };

    baseTextRef.current = currentText;
    finalTranscriptRef.current = '';
    interimTranscriptRef.current = '';
    recognition.onstart = () => {
      setIsListening(true);
      onListeningChange?.(true);
      setSpeechMessage('');
      resetPauseTimer();
    };
    recognition.onresult = (event) => {
      const finalParts = [];
      const interimParts = [];
      Array.from(event.results).forEach((result) => {
        const transcript = String(result[0]?.transcript ?? '').trim();
        if (!transcript) return;
        (result.isFinal ? finalParts : interimParts).push(transcript);
      });

      finalTranscriptRef.current = finalParts.join(' ').trim();
      interimTranscriptRef.current = interimParts.join(' ').trim();
      const visibleTranscript = [finalTranscriptRef.current, interimTranscriptRef.current]
        .filter(Boolean)
        .join(' ');
      const nextValue = appendToBase(visibleTranscript);
      emitValue(nextValue);
      window.requestAnimationFrame(() => {
        textInputRef.current?.setSelectionRange(nextValue.length, nextValue.length);
      });
      resetPauseTimer();
    };
    recognition.onerror = (event) => {
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        setSpeechMessage('Allow microphone access in your browser to use voice typing.');
      } else if (event.error === 'no-speech') {
        setSpeechMessage('No speech detected. Please try again.');
      } else if (event.error !== 'aborted') {
        setSpeechMessage('Voice typing is unavailable right now.');
      }
    };
    recognition.onend = () => {
      window.clearTimeout(pauseTimerRef.current);
      const transcript = [finalTranscriptRef.current, interimTranscriptRef.current]
        .filter(Boolean)
        .join(' ')
        .trim();
      const finalValue = appendToBase(transcript);
      emitValue(finalValue);
      window.requestAnimationFrame(() => {
        textInputRef.current?.setSelectionRange(finalValue.length, finalValue.length);
      });
      setIsListening(false);
      onListeningChange?.(false);
      if (recognitionRef.current === recognition) recognitionRef.current = null;
    };

    recognitionRef.current = recognition;
    setSpeechMessage('');
    try {
      recognition.start();
    } catch {
      window.clearTimeout(pauseTimerRef.current);
      recognitionRef.current = null;
      setIsListening(false);
      onListeningChange?.(false);
      setSpeechMessage('Voice typing is unavailable right now.');
    }
  };

  useEffect(() => () => {
    window.clearTimeout(pauseTimerRef.current);
    recognitionRef.current?.abort();
  }, []);

  const voiceAdornment = SpeechRecognition ? (
    <InputAdornment position="end" className="client-voice-text-field__adornment">
      <Tooltip title={isListening ? 'Stop voice typing' : 'Start voice typing'}>
        <span>
          <IconButton
            className={`client-voice-text-field__button${isListening ? ' is-listening' : ''}`}
            aria-label={isListening ? 'Stop voice typing' : 'Start voice typing'}
            aria-pressed={isListening}
            onMouseDown={(event) => event.preventDefault()}
            onClick={handleVoiceInput}
            disabled={textFieldProps.disabled || InputProps.readOnly}
            size="small"
          >
            {isListening ? <MicOutlinedIcon fontSize="small" /> : <MicNoneOutlinedIcon fontSize="small" />}
          </IconButton>
        </span>
      </Tooltip>
    </InputAdornment>
  ) : null;

  return (
    <>
      <TextField
        {...textFieldProps}
        className={`client-voice-text-field ${className}`.trim()}
        value={value}
        onChange={handleInputChange}
        inputRef={assignInputRef}
        InputProps={{
          ...InputProps,
          endAdornment: <>{InputProps.endAdornment}{voiceAdornment}</>,
        }}
      />
      {isListening && <Typography className="client-voice-text-field__status" aria-live="polite">Listening...</Typography>}
      {speechMessage && <Typography className="client-voice-text-field__message" role="status">{speechMessage}</Typography>}
    </>
  );
};

export default VoiceTextField;
