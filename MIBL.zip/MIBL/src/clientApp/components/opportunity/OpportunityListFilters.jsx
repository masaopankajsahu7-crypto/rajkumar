import { useEffect, useState } from 'react';
import {
  Badge,
  Box,
  Button,
  FormControl,
  IconButton,
  InputAdornment,
  MenuItem,
  Popover,
  Select,
  Switch,
  TextField,
  Typography,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { CLIENT_KDS_FIELDS, OPPORTUNITY_KDS_FIELDS } from '../../config/kdsFields.js';
import { OPPORTUNITY_LIST_MESSAGES as MSG } from '../../config/messages/opportunity.js';
import { getKdsOptions, getOpportunityKdsOptions, searchClientsByName } from '../../services/api.jsx';
import { countActiveOpportunityFilters } from '../../utils/opportunityListFilters.js';
import { sanitizeByField } from '../../utils/fieldUtils.js';

const OpportunityListFilters = ({
  filters,
  appliedFilters,
  onChange,
  onApply,
  onClear,
  hasActiveFilters,
}) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [focusedDateField, setFocusedDateField] = useState(null);
  const [activeTab, setActiveTab] = useState('basic');
  const [productOptions, setProductOptions] = useState([]);
  const [subProductOptions, setSubProductOptions] = useState([]);
  const [businessTypeOptions, setBusinessTypeOptions] = useState([]);
  const [verticalOptions, setVerticalOptions] = useState([]);
  const [statusOptions, setStatusOptions] = useState([]);
  const [stageOptions, setStageOptions] = useState([]);
  const [ownerOptions, setOwnerOptions] = useState([]);
  const [placementRmOptions, setPlacementRmOptions] = useState([]);
  const [ownerLoading, setOwnerLoading] = useState(false);
  const [placementRmLoading, setPlacementRmLoading] = useState(false);
  const [ownerSuggestionsOpen, setOwnerSuggestionsOpen] = useState(false);
  const [placementRmSuggestionsOpen, setPlacementRmSuggestionsOpen] = useState(false);
  const [clientOptions, setClientOptions] = useState([]);
  const [clientLoading, setClientLoading] = useState(false);
  const [clientSuggestionsOpen, setClientSuggestionsOpen] = useState(false);
  const popoverOpen = Boolean(anchorEl);
  const activeCount = countActiveOpportunityFilters(appliedFilters);
  const clientNameSearch = String(filters.clientName ?? '').trim();
  const ownerSearch = String(filters.owner ?? '').trim();
  const placementRmSearch = String(filters.placementRm ?? '').trim();
  const hasUnselectedClientName = Boolean(clientNameSearch && !filters.clientUUID);
  const hasUnselectedOwner = Boolean(ownerSearch && !filters.ownerId);
  const hasUnselectedPlacementRm = Boolean(placementRmSearch && !filters.placementRmId);
  const applyDisabled = hasUnselectedClientName || hasUnselectedOwner || hasUnselectedPlacementRm;
  const filteredOwnerOptions =
    ownerSearch && !filters.ownerId
      ? ownerOptions
          .filter((option) => option.value.toLowerCase().includes(ownerSearch.toLowerCase()))
      : [];
  const filteredPlacementRmOptions = placementRmSearch
    ? placementRmOptions
        .filter((option) => option.value.toLowerCase().includes(placementRmSearch.toLowerCase()))
    : [];

  useEffect(() => {
    if (
      !popoverOpen ||
      (
        productOptions.length &&
        businessTypeOptions.length &&
        verticalOptions.length &&
        statusOptions.length &&
        stageOptions.length
      )
    ) {
      return undefined;
    }

    let ignoreResult = false;
    Promise.all([
      getKdsOptions(OPPORTUNITY_KDS_FIELDS.product),
      getKdsOptions(OPPORTUNITY_KDS_FIELDS.businessType),
      getKdsOptions(CLIENT_KDS_FIELDS.vertical),
      getOpportunityKdsOptions(OPPORTUNITY_KDS_FIELDS.filterStatus),
      getOpportunityKdsOptions(OPPORTUNITY_KDS_FIELDS.workflowStage),
    ]).then(([products, businessTypes, verticals, statuses, stages]) => {
      if (ignoreResult) return;
      setProductOptions(products);
      setBusinessTypeOptions(businessTypes);
      setVerticalOptions(verticals);
      setStatusOptions(statuses);
      setStageOptions(stages);
    });

    return () => {
      ignoreResult = true;
    };
  }, [
    businessTypeOptions.length,
    popoverOpen,
    productOptions.length,
    stageOptions.length,
    statusOptions.length,
    verticalOptions.length,
  ]);

  useEffect(() => {
    if (!popoverOpen || !filters.product) {
      setSubProductOptions([]);
      return undefined;
    }

    let ignoreResult = false;
    setSubProductOptions([]);
    getKdsOptions({
      ...OPPORTUNITY_KDS_FIELDS.subProduct,
      parentCode: filters.product,
    }).then((loadedOptions) => {
      if (!ignoreResult) {
        setSubProductOptions(loadedOptions);
      }
    });

    return () => {
      ignoreResult = true;
    };
  }, [filters.product, popoverOpen]);

  useEffect(() => {
    if (!popoverOpen || ownerOptions.length > 0) {
      setOwnerLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    setOwnerLoading(true);
    getKdsOptions({
      ...CLIENT_KDS_FIELDS.filterOwner,
      search: '',
      limit: 100,
    }).then((loadedOptions) => {
      if (!ignoreResult) {
        setOwnerOptions(loadedOptions);
        setOwnerLoading(false);
      }
    });

    return () => {
      ignoreResult = true;
    };
  }, [ownerOptions.length, popoverOpen]);

  useEffect(() => {
    if (!popoverOpen || placementRmOptions.length > 0) {
      setPlacementRmLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    setPlacementRmLoading(true);
    getOpportunityKdsOptions({
      ...OPPORTUNITY_KDS_FIELDS.filterPlacementRm,
      search: '',
      limit: 100,
    }).then((loadedOptions) => {
      if (!ignoreResult) {
        setPlacementRmOptions(loadedOptions);
        setPlacementRmLoading(false);
      }
    });

    return () => {
      ignoreResult = true;
    };
  }, [placementRmOptions.length, popoverOpen]);

  useEffect(() => {
    if (!popoverOpen || activeTab !== 'basic' || !clientNameSearch || filters.clientUUID) {
      setClientOptions([]);
      setClientLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    setClientLoading(true);
    const timer = window.setTimeout(async () => {
      const loadedOptions = await searchClientsByName(clientNameSearch, { source: 'filter' });

      if (!ignoreResult) {
        setClientOptions(loadedOptions);
        setClientLoading(false);
        setClientSuggestionsOpen(true);
      }
    }, 300);

    return () => {
      ignoreResult = true;
      window.clearTimeout(timer);
    };
  }, [activeTab, clientNameSearch, filters.clientUUID, popoverOpen]);

  const getInitialTab = () => {
    const hasAdvancedFilter = [
      'owner',
      'ownerId',
      'placementRm',
      'placementRmId',
      'opportunityStatus',
      'opportunityStage',
    ].some((field) => String(filters[field] ?? '').trim());

    return hasAdvancedFilter ? 'advanced' : 'basic';
  };

  const handleOpen = (event) => {
    setActiveTab(getInitialTab());
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setClientSuggestionsOpen(false);
    setClientOptions([]);
    setOwnerSuggestionsOpen(false);
    setPlacementRmSuggestionsOpen(false);
  };

  const handleApply = () => {
    if (applyDisabled) return;
    onApply();
    handleClose();
  };

  const handleClear = () => {
    onClear();
    setClientSuggestionsOpen(false);
    setClientOptions([]);
    setOwnerSuggestionsOpen(false);
    setPlacementRmSuggestionsOpen(false);
    handleClose();
  };

  const handleTabClick = (event) => {
    setActiveTab(event.currentTarget.dataset.tab);
  };

  const handleTextChange = (field) => (event) => {
    const sanitizeType = field === 'owner' || field === 'placementRm' ? 'name' : 'search';
    onChange(field, sanitizeByField(sanitizeType, event.target.value));
    if (field === 'clientName') {
      onChange('clientUUID', '');
      setClientSuggestionsOpen(true);
    }
    if (field === 'owner') {
      onChange('ownerId', '');
      setOwnerSuggestionsOpen(true);
    }
    if (field === 'placementRm') {
      onChange('placementRmId', '');
      setPlacementRmSuggestionsOpen(true);
    }
  };

  const handleSearchClear = (field, idField, closeSuggestions) => (event) => {
    event.preventDefault();
    onChange(field, '');
    onChange(idField, '');
    closeSuggestions(false);
  };

  const handleSearchBlur = (field, idField, closeSuggestions) => () => {
    window.setTimeout(() => {
      if (String(filters[field] ?? '').trim() && !filters[idField]) {
        onChange(field, '');
        onChange(idField, '');
      }
      closeSuggestions(false);
    }, 150);
  };

  const getSearchInputProps = (field, idField, closeSuggestions) => ({
    endAdornment: filters[field] ? (
      <InputAdornment position="end">
        <IconButton
          className="client-mgmt-filter-input-clear"
          size="small"
          aria-label={`Clear ${field}`}
          onMouseDown={(event) => event.preventDefault()}
          onClick={handleSearchClear(field, idField, closeSuggestions)}
        >
          <CloseIcon fontSize="small" />
        </IconButton>
      </InputAdornment>
    ) : null,
  });

  const handleSelectChange = (field, fieldOptions = []) => (event) => {
    const selectedValue = event.target.value;
    const selectedOption = fieldOptions.find((option) => getOptionValue(option) === selectedValue);
    onChange(field, selectedValue);
    onChange(`${field}Label`, selectedOption ? getOptionLabel(selectedOption) : '');
    if (field === 'product') {
      onChange('subProduct', '');
      onChange('subProductLabel', '');
    }
  };

  const handleDateChange = (field) => (event) => {
    onChange(field, event.target.value);
  };

  const handleBreachedToggle = (event) => {
    onChange('breached', event.target.checked ? '1' : '');
  };

  const renderDateField = (field, placeholder) => {
    const showDatePicker = focusedDateField === field || Boolean(filters[field]);

    return (
      <TextField
        className="client-mgmt-filter-input"
        size="small"
        fullWidth
        type={showDatePicker ? 'date' : 'text'}
        placeholder={placeholder}
        value={filters[field]}
        onFocus={() => setFocusedDateField(field)}
        onBlur={() => setFocusedDateField(null)}
        onChange={handleDateChange(field)}
      />
    );
  };

  const getOptionValue = (option) => (typeof option === 'string' ? option : option.code);
  const getOptionLabel = (option) => (typeof option === 'string' ? option : option.value);
  const getSelectedLabel = (selected, fieldOptions, placeholder, field) => {
    if (!selected) return placeholder;
    const match = fieldOptions.find((option) => getOptionValue(option) === selected);
    return match ? getOptionLabel(match) : filters[`${field}Label`] || selected;
  };

  const getSubProductOptions = () => {
    if (!filters.product) return [];
    return subProductOptions;
  };

  const renderSelect = (field, placeholder, fieldOptions = [], selectProps = {}) => (
    <FormControl size="small" fullWidth className="client-mgmt-filter-control">
      <Select
        className="client-mgmt-filter-select form-control-input border-radius-8"
        displayEmpty
        value={filters[field]}
        onChange={handleSelectChange(field, fieldOptions)}
        renderValue={(selected) => getSelectedLabel(selected, fieldOptions, placeholder, field)}
        MenuProps={{ PaperProps: { className: 'client-mgmt-filter-select-menu' } }}
        disabled={selectProps.disabled}
      >
        {fieldOptions.map((option) => (
          <MenuItem key={getOptionValue(option)} value={getOptionValue(option)}>
            {getOptionLabel(option)}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );

  const renderPlacementRmSearch = () => (
    <Box className="client-mgmt-owner-search">
      <TextField
        className="client-mgmt-filter-input"
        size="small"
        fullWidth
        placeholder={MSG.filters.placementRm}
        value={filters.placementRm}
        onChange={handleTextChange('placementRm')}
        onFocus={() => setPlacementRmSuggestionsOpen(true)}
        onBlur={handleSearchBlur('placementRm', 'placementRmId', setPlacementRmSuggestionsOpen)}
        InputProps={getSearchInputProps('placementRm', 'placementRmId', setPlacementRmSuggestionsOpen)}
      />
      {placementRmSuggestionsOpen && placementRmSearch && !filters.placementRmId && (
        <Box className="client-mgmt-owner-suggestions">
          {placementRmLoading && (
            <Typography className="client-mgmt-owner-suggestion-note">
              {MSG.filters.searching}
            </Typography>
          )}
          {!placementRmLoading &&
            filteredPlacementRmOptions.map((option) => (
              <Button
                key={option.code}
                className="client-mgmt-owner-suggestion"
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => handlePlacementRmSelect(option)}
              >
                {option.value}
              </Button>
            ))}
          {!placementRmLoading && filteredPlacementRmOptions.length === 0 && (
            <Typography className="client-mgmt-owner-suggestion-note">
              {MSG.filters.noOwnerResults}
            </Typography>
          )}
        </Box>
      )}
    </Box>
  );

  const renderFilterSection = (title, children) => (
    <Box className="client-mgmt-filter-section">
      <Typography className="client-mgmt-filter-section-title">{title}</Typography>
      {children}
    </Box>
  );

  const renderTabButton = (tabKey, label) => (
    <Button
      className={`client-mgmt-filter-tab ${activeTab === tabKey ? 'client-mgmt-filter-tab-active' : ''}`}
      data-tab={tabKey}
      onClick={handleTabClick}
      aria-pressed={activeTab === tabKey}
    >
      {label}
    </Button>
  );

  const handleClientSelect = (option) => {
    onChange('clientName', option.clientName);
    onChange('clientUUID', option.clientUUID);
    setClientSuggestionsOpen(false);
    setClientOptions([]);
  };

  const handleOwnerSelect = (option) => {
    onChange('owner', option.value);
    onChange('ownerId', option.code);
    setOwnerSuggestionsOpen(false);
  };

  const handlePlacementRmSelect = (option) => {
    onChange('placementRm', option.value);
    onChange('placementRmId', option.code);
    setPlacementRmSuggestionsOpen(false);
  };

  return (
    <>
      <Badge
        badgeContent={activeCount}
        color="error"
        invisible={activeCount === 0}
        className="client-mgmt-filter-badge"
      >
        <Button
          className="client-mgmt-filter-toggle-btn opportunity-mgmt-icon-btn"
          startIcon={(
            <Box className="opportunity-mgmt-filter-lines-icon" aria-hidden="true">
              <span />
              <span />
              <span />
            </Box>
          )}
          onClick={handleOpen}
          aria-label={MSG.filters.openFilters}
        />
      </Badge>

      <Popover
        open={popoverOpen}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        className="client-mgmt-filter-popover opportunity-mgmt-filter-popover"
        slotProps={{
          paper: { className: 'client-mgmt-filter-popover-paper opportunity-mgmt-filter-popover-paper' },
        }}
      >
        <Box className="client-mgmt-filter-popover-head">
          <Typography className="georama-SemiBold client-mgmt-filter-popover-title">
            {MSG.filters.title}
          </Typography>
          <Button className="client-mgmt-filter-popover-close" onClick={handleClose} aria-label={MSG.filters.clear}>
            <CloseIcon fontSize="small" />
          </Button>
        </Box>

        <Box className="client-mgmt-filter-tabs">
          {renderTabButton('basic', MSG.filters.tabs.basic)}
          {renderTabButton('advanced', MSG.filters.tabs.advanced)}
        </Box>

        <Box className="client-mgmt-filter-popover-body">
          {activeTab === 'basic' && (
            <>
              {renderFilterSection(
                MSG.filters.sections.identity,
                <>
                  <Box className="client-mgmt-filter-popover-row">
                    {renderSelect('product', MSG.filters.product, productOptions)}
                    {renderSelect('subProduct', MSG.filters.subProduct, getSubProductOptions(), {
                      disabled: !filters.product,
                    })}
                  </Box>
                  <Box className="client-mgmt-filter-popover-row">
                    {renderSelect('businessType', MSG.filters.businessType, businessTypeOptions)}
                    {renderSelect('clientVertical', MSG.filters.clientVertical, verticalOptions)}
                  </Box>
                </>,
              )}

              {renderFilterSection(
                MSG.filters.sections.client,
                <Box className="client-mgmt-client-search">
                  <TextField
                    className="client-mgmt-filter-input"
                    size="small"
                    fullWidth
                    placeholder={MSG.filters.clientName}
                    value={filters.clientName}
                    onChange={handleTextChange('clientName')}
                    onFocus={() => setClientSuggestionsOpen(true)}
                    onBlur={handleSearchBlur('clientName', 'clientUUID', setClientSuggestionsOpen)}
                    InputProps={getSearchInputProps('clientName', 'clientUUID', setClientSuggestionsOpen)}
                  />
                  {clientSuggestionsOpen && clientNameSearch && !filters.clientUUID && (
                    <Box className="client-mgmt-client-suggestions">
                      {clientLoading && (
                        <Typography className="client-mgmt-client-suggestion-note">
                          {MSG.filters.searching}
                        </Typography>
                      )}
                      {!clientLoading &&
                        clientOptions.map((option) => (
                          <Button
                            key={option.clientUUID}
                            className="client-mgmt-client-suggestion"
                            onMouseDown={(event) => event.preventDefault()}
                            onClick={() => handleClientSelect(option)}
                          >
                            <span className="client-mgmt-client-suggestion-name">{option.clientName}</span>
                            {option.owner ? (
                              <span className="client-mgmt-client-suggestion-owner">
                                {MSG.filters.ownerPrefix}: {option.owner}
                              </span>
                            ) : null}
                          </Button>
                        ))}
                      {!clientLoading && clientOptions.length === 0 && (
                        <Typography className="client-mgmt-client-suggestion-note">
                          {MSG.filters.noClientResults}
                        </Typography>
                      )}
                    </Box>
                  )}
                </Box>,
              )}

              <Box className="opportunity-mgmt-breached-filter-row">
                <Typography className="opportunity-mgmt-breached-filter-title">
                  Breached
                </Typography>
                <Switch
                  size="small"
                  checked={String(filters.breached ?? '') === '1'}
                  onChange={handleBreachedToggle}
                  inputProps={{ 'aria-label': 'Show breached opportunities only' }}
                />
              </Box>
            </>
          )}

          {activeTab === 'advanced' && (
            <>
              {renderFilterSection(
                MSG.filters.sections.ownership,
                <>
                  <Box className="client-mgmt-owner-search">
                    <TextField
                      className="client-mgmt-filter-input"
                      size="small"
                      fullWidth
                      placeholder={MSG.filters.owner}
                      value={filters.owner}
                      onChange={handleTextChange('owner')}
                      onFocus={() => setOwnerSuggestionsOpen(true)}
                      onBlur={handleSearchBlur('owner', 'ownerId', setOwnerSuggestionsOpen)}
                      InputProps={getSearchInputProps('owner', 'ownerId', setOwnerSuggestionsOpen)}
                    />
                    {ownerSuggestionsOpen && ownerSearch && !filters.ownerId && (
                      <Box className="client-mgmt-owner-suggestions">
                        {ownerLoading && (
                          <Typography className="client-mgmt-owner-suggestion-note">
                            {MSG.filters.searching}
                          </Typography>
                        )}
                        {!ownerLoading &&
                          filteredOwnerOptions.map((option) => (
                            <Button
                              key={option.code}
                              className="client-mgmt-owner-suggestion"
                              onMouseDown={(event) => event.preventDefault()}
                              onClick={() => handleOwnerSelect(option)}
                            >
                              {option.value}
                            </Button>
                          ))}
                        {!ownerLoading && filteredOwnerOptions.length === 0 && (
                          <Typography className="client-mgmt-owner-suggestion-note">
                            {MSG.filters.noOwnerResults}
                          </Typography>
                        )}
                      </Box>
                    )}
                  </Box>
                  {renderPlacementRmSearch()}
                </>,
              )}

              {renderFilterSection(
                MSG.filters.sections.status,
                <>
                  <Box className="client-mgmt-filter-popover-row">
                    {renderSelect('opportunityStatus', MSG.filters.opportunityStatus, statusOptions)}
                    {renderSelect('opportunityStage', MSG.filters.opportunityStage, stageOptions)}
                  </Box>
                </>,
              )}

            </>
          )}

        </Box>

        <Box className="client-mgmt-filter-popover-actions">
          {applyDisabled ? (
            <Typography className="client-mgmt-filter-validation georama-Regular">
              Select a valid option.
            </Typography>
          ) : null}
          <Button
            className="client-mgmt-filter-clear-btn text-sky"
            onClick={handleClear}
            disabled={!hasActiveFilters}
          >
            {MSG.filters.clear}
          </Button>
          <Button className="btn-common-red client-mgmt-filter-apply-btn" onClick={handleApply} disabled={applyDisabled}>
            {MSG.filters.apply}
          </Button>
        </Box>
      </Popover>
    </>
  );
};

export default OpportunityListFilters;
