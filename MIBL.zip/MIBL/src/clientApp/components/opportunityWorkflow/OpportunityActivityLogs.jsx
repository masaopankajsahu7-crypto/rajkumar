import { Box, Typography } from '@mui/material';
import {
  formatWorkflowActivityDateTime,
  normalizeOpportunityActivityLogs,
} from '../../utils/opportunityWorkflow.js';

const getToneClass = (stageCode) => {
  const normalized = String(stageCode ?? '').toUpperCase();
  if (normalized.includes('BREACH')) return 'opportunity-workflow-activity--red';
  if (normalized.includes('NOTIFICATION')) return 'opportunity-workflow-activity--blue';
  if (normalized.includes('RFQ') || normalized.includes('QCR') || normalized.includes('REVIEW')) {
    return 'opportunity-workflow-activity--purple';
  }
  return 'opportunity-workflow-activity--green';
};

export default function OpportunityActivityLogs({ response }) {
  const logs = normalizeOpportunityActivityLogs(response);

  return (
    <Box className="opportunity-workflow-card opportunity-workflow-activity-card">
      <Typography className="opportunity-workflow-details-title">Activity Logs</Typography>

      {logs.length > 0 ? (
        <Box className="opportunity-workflow-activity-list">
          {logs.map((log) => (
            <Box className={`opportunity-workflow-activity-item ${getToneClass(log.stageCode)}`} key={log.id}>
              <span className="opportunity-workflow-activity-dot" />
              <Box className="opportunity-workflow-activity-main">
                <Box className="opportunity-workflow-activity-head">
                  <Box className="opportunity-workflow-activity-userline">
                    <Typography className="opportunity-workflow-activity-user">{log.userName}</Typography>
                    <span className="opportunity-workflow-activity-badge">{log.stageCode}</span>
                  </Box>
                  <Typography className="opportunity-workflow-activity-date">
                    {formatWorkflowActivityDateTime(log.createdOn)}
                  </Typography>
                </Box>
                <Typography className="opportunity-workflow-activity-message">{log.message}</Typography>
              </Box>
            </Box>
          ))}
        </Box>
      ) : (
        <Typography className="opportunity-workflow-muted">No activity logs found.</Typography>
      )}
    </Box>
  );
}
