import { useEffect, useState } from 'react';
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  MenuItem,
  TextField,
  Typography,
} from '@mui/material';
import { searchAssignableOwners } from '../../services/api.jsx';

const INFORMED_OPTIONS = ['Call', 'Email', 'SMS/WhatsApp', 'In Person', 'Other'];
const DELAY_REASON_OPTIONS = ['Leave', 'Holidays', 'Client Dependency', 'Internal Dependency'];

export default function OpportunityAssignmentDialog({
  open,
  onClose,
  onAssign,
  assigneeRows = [],
  canManageDelay = true,
}) {
  const [placementRmId, setPlacementRmId] = useState('');
  const [placementRmOptions, setPlacementRmOptions] = useState([]);
  const [placementRmSearch, setPlacementRmSearch] = useState('');
  const [delayReason, setDelayReason] = useState('');
  const [comments, setComments] = useState('');
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (!open) return undefined;

    setPlacementRmId('');
    setPlacementRmSearch('');
    setDelayReason('');
    setComments('');
    setErrorMessage('');
    setPlacementRmOptions([]);

    return () => {
      setPlacementRmOptions([]);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return undefined;

    const normalizedSearch = String(placementRmSearch ?? '').trim();
    if (normalizedSearch.length < 2) {
      setPlacementRmOptions([]);
      setLoadingOptions(false);
      return undefined;
    }

    let ignoreResult = false;
    setLoadingOptions(true);
    const timer = window.setTimeout(() => {
      searchAssignableOwners(normalizedSearch, { userType: 'PLACEMENT_RM', isHierarchy: 0 })
        .then((options) => {
          if (!ignoreResult) setPlacementRmOptions(options);
        })
        .catch(() => {
          if (!ignoreResult) setErrorMessage('Unable to load Placement RM list');
        })
        .finally(() => {
          if (!ignoreResult) setLoadingOptions(false);
        });
    }, 350);

    return () => {
      ignoreResult = true;
      window.clearTimeout(timer);
    };
  }, [open, placementRmSearch]);

  const handleAssign = async () => {
    if (!placementRmId || submitting) return;
    if (canManageDelay && !String(delayReason).trim()) {
      setErrorMessage('Delay Reason is required');
      return;
    }
    if (!String(comments).trim()) {
      setErrorMessage('Comments is required');
      return;
    }
    setSubmitting(true);
    setErrorMessage('');
    try {
      await onAssign(placementRmId);
    } catch (error) {
      setErrorMessage(error?.message ?? 'Placement RM assignment failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      PaperProps={{ className: 'opportunity-assignment-dialog-paper' }}
    >
      <DialogTitle className="opportunity-assignment-dialog-title">
        Assign to Placement RM
      </DialogTitle>
      <DialogContent className="opportunity-assignment-dialog-content">
        <Typography className="opportunity-assignment-dialog-subtitle">
          Reassign or confirm the placement owner for this opportunity.
        </Typography>

        {assigneeRows.length > 0 ? (
          <Box className="opportunity-assignment-current">
            {assigneeRows.map((row) => (
              <Box className="opportunity-assignment-current-row" key={row.label}>
                <Typography className="opportunity-assignment-current-label">{row.label}</Typography>
                <Typography className="opportunity-assignment-current-value">{row.value}</Typography>
              </Box>
            ))}
          </Box>
        ) : null}

        <Box className="opportunity-assignment-fields">
          <Autocomplete
            className="opportunity-assignment-field"
            options={placementRmOptions}
            value={placementRmOptions.find((option) => String(option.code) === String(placementRmId)) ?? null}
            getOptionLabel={(option) => String(option?.value ?? '')}
            isOptionEqualToValue={(option, value) => String(option.code) === String(value.code)}
            onChange={(_, option) => setPlacementRmId(option?.code ?? '')}
            onInputChange={(_, value, reason) => {
              if (reason === 'input') {
                setPlacementRmSearch(value);
                setPlacementRmId('');
              }
            }}
            loading={loadingOptions}
            disabled={submitting}
            noOptionsText="No matching Placement RM found"
            renderInput={(params) => (
              <TextField
                {...params}
                label="Placement RM *"
                placeholder="Type Placement RM name"
                size="small"
              />
            )}
          />
          <TextField
            className="opportunity-assignment-field"
            label="Informed"
            select
            defaultValue=""
            size="small"
          >
            <MenuItem value="">Select Informed Via</MenuItem>
            {INFORMED_OPTIONS.map((option) => (
              <MenuItem value={option} key={option}>
                {option}
              </MenuItem>
            ))}
          </TextField>
          {canManageDelay && (
            <TextField
              className="opportunity-assignment-field"
              label="Delay Reason"
              select
              value={delayReason}
              onChange={(event) => setDelayReason(event.target.value)}
              size="small"
            >
              <MenuItem value="">Select delay reason</MenuItem>
              {DELAY_REASON_OPTIONS.map((option) => (
                <MenuItem value={option} key={option}>
                  {option}
                </MenuItem>
              ))}
            </TextField>
          )}
          <TextField
            className="opportunity-assignment-field opportunity-assignment-comments"
            label="Comments *"
            placeholder="Add reassignment notes..."
            value={comments}
            onChange={(event) => setComments(event.target.value)}
            multiline
            minRows={3}
          />
        </Box>

        {errorMessage ? <Alert severity="error">{errorMessage}</Alert> : null}

        <Box className="opportunity-assignment-actions">
          <Button className="opportunity-assignment-back-btn" onClick={onClose} disabled={submitting}>
            Back
          </Button>
          <Button
            className="btn-common-red opportunity-assignment-submit-btn"
            onClick={handleAssign}
            disabled={
              !placementRmId ||
              (canManageDelay && !String(delayReason).trim()) ||
              !String(comments).trim() ||
              submitting
            }
          >
            {submitting ? 'Assigning...' : 'Assign Placement RM'}
          </Button>
        </Box>
      </DialogContent>
    </Dialog>
  );
}
