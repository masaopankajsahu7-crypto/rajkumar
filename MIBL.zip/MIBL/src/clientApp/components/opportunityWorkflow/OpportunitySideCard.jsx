import { Box, IconButton, Typography } from '@mui/material';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';

export default function OpportunitySideCard({ title, rows = [], contacts = [], editable = false, onEdit }) {
  return (
    <Box className="opportunity-workflow-card opportunity-workflow-side-card">
      <Box className="opportunity-workflow-card-head">
        <Typography className="opportunity-workflow-card-title">{title}</Typography>
        {editable && (
          <IconButton
            className="opportunity-workflow-edit-button"
            size="small"
            aria-label={`Edit ${title}`}
            onClick={onEdit}
          >
            <EditOutlinedIcon className="opportunity-workflow-edit-icon" />
          </IconButton>
        )}
      </Box>

      {contacts.length > 0 ? (
        <Box className="opportunity-workflow-contact-list">
          {contacts.map((contact, index) => (
            <Box className="opportunity-workflow-contact" key={`${contact.email}-${index}`}>
              <Typography className="opportunity-workflow-contact-name">{contact.name || '---'}</Typography>
              <Typography className="opportunity-workflow-contact-meta">M: {contact.mobile || '---'}</Typography>
              <Typography className="opportunity-workflow-contact-meta">Email: {contact.email || '---'}</Typography>
            </Box>
          ))}
        </Box>
      ) : (
        <Box className="opportunity-workflow-detail-list">
          {rows.map((row) => (
            <Box className="opportunity-workflow-detail-row" key={row.label}>
              <Typography className="opportunity-workflow-detail-label">{row.label}</Typography>
              <Typography className="opportunity-workflow-detail-value">{row.value}</Typography>
            </Box>
          ))}
        </Box>
      )}
    </Box>
  );
}
