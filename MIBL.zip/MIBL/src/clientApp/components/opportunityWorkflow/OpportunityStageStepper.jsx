import { Box, Typography } from '@mui/material';
import { formatWorkflowDateTime, formatWorkflowValue } from '../../utils/opportunityWorkflow.js';

export default function OpportunityStageStepper({ stages, status }) {
  const getTatClassName = (tatLabel) => {
    const normalized = String(tatLabel ?? '').trim().toLowerCase();
    if (normalized === 'within tat') return 'opportunity-workflow-step-tat--within';
    if (normalized === 'breached') return 'opportunity-workflow-step-tat--breached';
    if (normalized === 'pending') return 'opportunity-workflow-step-tat--pending';
    return '';
  };

  return (
    <Box className="opportunity-workflow-card opportunity-workflow-stepper-card">
      <Box className="opportunity-workflow-section-head">
        <Typography className="opportunity-workflow-section-title">Opportunity Workflow States</Typography>
        {status ? <span className="opportunity-workflow-soft-pill">{status}</span> : null}
      </Box>

      {stages.length > 0 ? (
        <Box className="opportunity-workflow-stepper">
          {stages.map((stage, index) => (
            <Box
              key={stage.code}
              className={`opportunity-workflow-step opportunity-workflow-step--${stage.status}`}
              tabIndex={0}
            >
              <Box className="opportunity-workflow-stage-hover-card">
                <Typography className="opportunity-workflow-stage-hover-title">
                  {stage.label}
                </Typography>
                <Box className="opportunity-workflow-stage-hover-row">
                  <span>Stage Start Date</span>
                  <strong>{formatWorkflowDateTime(stage.apiStage?.stage_start_at)}</strong>
                </Box>
                <Box className="opportunity-workflow-stage-hover-row">
                  <span>Stage End Date</span>
                  <strong>{formatWorkflowDateTime(stage.apiStage?.stage_end_at)}</strong>
                </Box>
                <Box className="opportunity-workflow-stage-hover-row">
                  <span>Actual TAT Days</span>
                  <strong>{formatWorkflowValue(stage.apiStage?.actual_tat_days)}</strong>
                </Box>
              </Box>
              <span className="opportunity-workflow-step-line" />
              <span className="opportunity-workflow-step-number">{index + 1}</span>
              <Typography className="opportunity-workflow-step-name">{stage.label}</Typography>
              <Typography className={`opportunity-workflow-step-tat ${getTatClassName(stage.tatLabel)}`}>
                {stage.tatLabel}
              </Typography>
            </Box>
          ))}
        </Box>
      ) : (
        <Typography className="opportunity-workflow-muted">Loading workflow stages...</Typography>
      )}
    </Box>
  );
}
