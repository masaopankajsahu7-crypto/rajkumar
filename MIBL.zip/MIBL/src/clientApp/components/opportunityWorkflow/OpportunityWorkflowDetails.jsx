import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import {
  formatWorkflowDate,
  formatWorkflowDateTime,
  formatWorkflowLabel,
  formatWorkflowValue,
} from '../../utils/opportunityWorkflow.js';

const renderPayloadDetails = (payload = {}) => {
  const entries = Object.entries(payload).filter(([, value]) => value !== null && value !== undefined && value !== '');
  if (!entries.length) return <Typography className="opportunity-workflow-muted">No additional details</Typography>;

  return (
    <Box className="opportunity-workflow-payload">
      {entries.map(([key, value]) => (
        <Typography className="opportunity-workflow-payload-line" key={key}>
          <span>{formatWorkflowLabel(key)}:</span> {formatWorkflowValue(value)}
        </Typography>
      ))}
    </Box>
  );
};

export default function OpportunityWorkflowDetails({ stages = [], canViewDelay = true }) {
  return (
    <Box className="opportunity-workflow-card opportunity-workflow-details-card">
      <Typography className="opportunity-workflow-details-title">Workflow Details</Typography>

      <TableContainer className="opportunity-workflow-details-table-wrap">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Date</TableCell>
              <TableCell>User</TableCell>
              <TableCell>Stage Or Process</TableCell>
              <TableCell>Workflow Details</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {stages.map((stage) => {
              const payload = stage?.latest_workflow_stage_data?.stage_payload ?? {};
              return (
                <TableRow key={`${stage.stage_code}-${stage.stage_sequence}`}>
                  <TableCell>{formatWorkflowDate(stage.stage_start_at)}</TableCell>
                  <TableCell>{formatWorkflowValue(stage.processed_by)}</TableCell>
                  <TableCell>
                    <span className="opportunity-workflow-process-pill">
                      {stage.stage_display_name || stage.stage_code}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Box className="opportunity-workflow-table-detail">
                      {renderPayloadDetails(payload)}
                      <Box className="opportunity-workflow-table-meta">
                        <span>TAT: {stage.sla_compliance === 'WITHIN_TAT' ? 'Within TAT' : formatWorkflowValue(stage.sla_compliance)}</span>
                        <span>Start: {formatWorkflowDateTime(stage.stage_start_at)}</span>
                        <span>End: {formatWorkflowDateTime(stage.stage_end_at)}</span>
                        {canViewDelay && stage.delay_reason && <span>Delay Reason: {stage.delay_reason}</span>}
                      </Box>
                    </Box>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}
