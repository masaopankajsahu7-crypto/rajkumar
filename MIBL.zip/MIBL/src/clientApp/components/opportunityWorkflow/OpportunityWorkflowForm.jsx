import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  MenuItem,
  Popper,
  TextField,
  Typography,
} from '@mui/material';
import CancelRoundedIcon from '@mui/icons-material/CancelRounded';
import { normalizeStageCode } from '../../utils/opportunityWorkflow.js';
import { markOpportunityAsLost, saveOpportunityWorkflow } from '../../services/api.jsx';
import ClientSaveSuccessDialog from '../client/ClientSaveSuccessDialog.jsx';
import { useKdsOptions, useOpportunityKdsOptions } from '../../hooks/useFetchQueries.js';
import { OPPORTUNITY_KDS_FIELDS, WORKFLOW_KDS_FIELDS } from '../../config/kdsFields.js';
import { COMMON_MESSAGES } from '../../config/messages/common.js';

const WorkflowKdsPopper = (props) => (
  <Popper
    {...props}
    placement="bottom-start"
    modifiers={[
      { name: 'flip', enabled: false },
      { name: 'preventOverflow', enabled: false },
    ]}
  />
);

const STAGE_FORM_CONFIG = {
  OPPORTUNITY: {
    title: 'Assign to Placement RM',
    fields: [
      { name: 'placement_rm', label: 'Select Placement RM', type: 'text', placeholder: 'Search and select Placement RM', required: true },
      { name: 'informed_by', label: 'Informed', type: 'select', placeholder: 'Select Informed Via', options: ['Call', 'Email', 'SMS/WhatsApp', 'In Person', 'Other'] },
      { name: 'delay_reason', label: 'Delay Reason', type: 'select', placeholder: 'Select delay reason', required: true, options: ['Leave', 'Holidays'] },
    ],
  },
  ASSIGN_TO_PLACEMENT: {
    title: 'Assign to Placement RM',
    fields: [
      { name: 'placement_rm', label: 'Select Placement RM', type: 'text', placeholder: 'Search and select Placement RM', required: true },
      { name: 'informed_by', label: 'Informed', type: 'select', placeholder: 'Select Informed Via', options: ['Call', 'Email', 'SMS/WhatsApp', 'In Person', 'Other'] },
      { name: 'delay_reason', label: 'Delay Reason', type: 'select', placeholder: 'Select delay reason', required: true, options: ['Leave', 'Holidays'] },
    ],
  },
  RFQ_STAGE: {
    title: 'RFQ Details',
    fields: [
      { name: 'rfq_status', label: 'RFQ Status', type: 'select', placeholder: 'RFQ In Process', required: true, optionsKey: 'stageStatus' },
      { name: 'delay_reason', label: 'Delay Reason', type: 'select', placeholder: 'Select delay reason', required: true, optionsKey: 'delayReason' },
    ],
  },
  QCR_STAGE: {
    title: 'QCR Details',
    fields: [
      { name: 'qcr_status', label: 'QCR Status', type: 'select', placeholder: 'QCR In Process', required: true, optionsKey: 'stageStatus' },
      { name: 'delay_reason', label: 'Delay Reason', type: 'select', placeholder: 'Select delay reason', required: true, optionsKey: 'delayReason' },
    ],
  },
  CLIENT_REVIEW: {
    title: 'Customer Review',
    fields: [
      { name: 'review_status', label: 'Review Status', type: 'select', placeholder: 'Review In Process', required: true, optionsKey: 'stageStatus' },
      { name: 'delay_reason', label: 'Delay Reason', type: 'select', placeholder: 'Select delay reason', required: true, optionsKey: 'delayReason' },
    ],
  },
  POLICY_INBOUND: {
    title: 'Policy Inbound Details',
    fields: [
      { name: 'policy_status', label: 'Policy Status', type: 'select', placeholder: 'Select Policy Status', required: true, optionsKey: 'stageStatus' },
      { name: 'policy_number', label: 'Policy Number', type: 'text', placeholder: 'Enter policy number', required: true },
      { name: 'policy_premium', label: 'Policy Premium', type: 'number', placeholder: 'Enter premium amount', required: true },
      { name: 'policy_sum_insured', label: 'Policy Sum Insured', type: 'number', placeholder: 'Enter SI', required: true },
      { name: 'policy_insurer', label: 'Policy Insurer', type: 'select', placeholder: 'Select insurer', required: true, options: ['Tata AIG', 'ICICI Lombard', 'HDFC ERGO', 'Bajaj Allianz', 'New India Assurance'] },
      { name: 'policy_start_date', label: 'Policy Start Date', type: 'date', required: true },
      { name: 'policy_end_date', label: 'Policy End Date', type: 'date', required: true },
      { name: 'broker_name', label: 'Broker Name', type: 'text', placeholder: 'Enter broker name', required: true },
      { name: 'brokerage_percentage', label: 'Brokerage %', type: 'number', placeholder: 'Enter brokerage percentage', required: true },
      { name: 'reward_percentage', label: 'Reward %', type: 'number', placeholder: 'Enter reward percentage', required: true },
    ],
  },
  POLICY_WON: {
    title: 'Policy Inbound Details',
    fields: [
      { name: 'policy_status', label: 'Policy Status', type: 'select', placeholder: 'Select Policy Status', required: true, optionsKey: 'stageStatus' },
      { name: 'policy_number', label: 'Policy Number', type: 'text', placeholder: 'Enter policy number', required: true },
      { name: 'policy_premium', label: 'Policy Premium', type: 'number', placeholder: 'Enter premium amount', required: true },
      { name: 'policy_sum_insured', label: 'Policy Sum Insured', type: 'number', placeholder: 'Enter SI', required: true },
      { name: 'policy_insurer', label: 'Policy Insurer', type: 'select', placeholder: 'Select insurer', required: true, options: ['Tata AIG', 'ICICI Lombard', 'HDFC ERGO', 'Bajaj Allianz', 'New India Assurance'] },
      { name: 'policy_start_date', label: 'Policy Start Date', type: 'date', required: true },
      { name: 'policy_end_date', label: 'Policy End Date', type: 'date', required: true },
      { name: 'broker_name', label: 'Broker Name', type: 'text', placeholder: 'Enter broker name', required: true },
      { name: 'brokerage_percentage', label: 'Brokerage %', type: 'number', placeholder: 'Enter brokerage percentage', required: true },
      { name: 'reward_percentage', label: 'Reward %', type: 'number', placeholder: 'Enter reward percentage', required: true },
    ],
  },
  COMPLETED: {
    title: 'Completed',
    fields: [],
  },
};

const getCurrentStageCode = (workflowPayload = {}, opportunity = {}) =>
  normalizeStageCode(
    workflowPayload.workflow_state?.current_stage_code ??
      opportunity?.opportunity_stage_code ??
      opportunity?.opportunity_stage,
  );

const getWorkflowKdsStageCode = (stageCode) =>
  normalizeStageCode(stageCode) === 'POLICY_INBOUND' ? 'POLICY_WON' : normalizeStageCode(stageCode);

const buildInitialValues = (fields = [], payload = {}) =>
  fields.reduce((values, field) => ({ ...values, [field.name]: payload?.[field.name] ?? '' }), {});

const getOptionValue = (option) => (typeof option === 'string' ? option : option?.code ?? '');

const getOptionLabel = (option) => (typeof option === 'string' ? option : option?.value ?? '');

const isPolicyInProgressValue = (value, options = []) => {
  const normalizedValue = String(value ?? '').trim();
  if (!normalizedValue) return false;

  const matchedOption = options.find(
    (option) =>
      String(getOptionValue(option)).trim() === normalizedValue ||
      String(getOptionLabel(option)).trim() === normalizedValue,
  );
  const comparable = `${normalizedValue} ${getOptionLabel(matchedOption)}`.toLowerCase();
  return (
    comparable.includes('policy in progress') ||
    comparable.includes('policy_in_progress') ||
    comparable.includes('policy in process') ||
    comparable.includes('policy_in_process') ||
    comparable.includes('in progress') ||
    comparable.includes('in_progress') ||
    comparable.includes('in process') ||
    comparable.includes('in_process')
  );
};

const isPolicyIssuedValue = (value, options = []) => {
  const normalizedValue = String(value ?? '').trim();
  if (!normalizedValue) return false;

  const matchedOption = options.find(
    (option) =>
      String(getOptionValue(option)).trim() === normalizedValue ||
      String(getOptionLabel(option)).trim() === normalizedValue,
  );
  const comparable = `${normalizedValue} ${getOptionLabel(matchedOption)}`.toLowerCase();
  return comparable.includes('policy issued') || comparable.includes('policy_issued') || comparable.includes('issued');
};

const toNumber = (value) => {
  const numberValue = Number(String(value ?? '').replace(/,/g, ''));
  return Number.isFinite(numberValue) ? numberValue : 0;
};

const formatCalculatedAmount = (value) => {
  if (!Number.isFinite(value) || value <= 0) return '';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(value);
};

const PERCENTAGE_FIELDS = new Set(['brokerage_percentage', 'reward_percentage']);

const normalizePercentageInput = (value) => {
  if (value === '' || value === null || value === undefined) return '';
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return '';
  if (numberValue > 100) return '100';
  if (numberValue < 0) return '0';
  return value;
};

const parseDateOnly = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return null;
  const parsedDate = new Date(`${rawValue}T00:00:00`);
  return Number.isNaN(parsedDate.getTime()) ? null : parsedDate;
};

const isAfterDate = (value, compareValue) => {
  const selectedDate = parseDateOnly(value);
  const compareDate = parseDateOnly(compareValue);
  if (!selectedDate || !compareDate) return true;
  return selectedDate > compareDate;
};

export default function OpportunityWorkflowForm({
  workflowPayload = {},
  opportunity = {},
  canManageDelay = true,
  onSaved,
}) {
  const currentStageCode = getCurrentStageCode(workflowPayload, opportunity);
  const [stageCode, setStageCode] = useState(currentStageCode);
  const config = STAGE_FORM_CONFIG[stageCode] ?? STAGE_FORM_CONFIG.OPPORTUNITY;
  const stageRecord = (workflowPayload.workflow_stages ?? []).find(
    (stage) => normalizeStageCode(stage?.stage_code) === stageCode,
  );
  const latestPayload = useMemo(
    () => stageRecord?.latest_workflow_stage_data?.stage_payload ?? {},
    [stageRecord],
  );
  const [reviewStatus, setReviewStatus] = useState(String(latestPayload.review_status ?? '').trim());
  const [values, setValues] = useState(() => buildInitialValues(config.fields, latestPayload));
  const [fieldErrors, setFieldErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [successDialog, setSuccessDialog] = useState({ open: false, actionCode: '' });
  const [markLostOpen, setMarkLostOpen] = useState(false);
  const [markLostValues, setMarkLostValues] = useState({ reason: '', comments: '' });
  const [markLostError, setMarkLostError] = useState('');
  const [markLostSaving, setMarkLostSaving] = useState(false);
  const workflowKdsStageCode = getWorkflowKdsStageCode(stageCode);
  const { data: stageStatusOptions = [] } = useOpportunityKdsOptions({
    ...WORKFLOW_KDS_FIELDS.stageStatus(workflowKdsStageCode),
    enabled: ['RFQ_STAGE', 'QCR_STAGE', 'CLIENT_REVIEW', 'POLICY_INBOUND', 'POLICY_WON'].includes(stageCode),
  });
  const { data: delayReasonOptions = [] } = useOpportunityKdsOptions({
    ...WORKFLOW_KDS_FIELDS.delayReason(workflowKdsStageCode),
    enabled: canManageDelay && stageCode !== 'COMPLETED',
  });
  const { data: clientReviewWonReasonOptions = [] } = useOpportunityKdsOptions({
    ...WORKFLOW_KDS_FIELDS.clientReviewWonReason,
    enabled: stageCode === 'CLIENT_REVIEW',
  });
  const { data: clientReviewLossReasonOptions = [] } = useOpportunityKdsOptions({
    ...WORKFLOW_KDS_FIELDS.clientReviewLossReason,
    enabled: stageCode === 'CLIENT_REVIEW' || markLostOpen,
  });
  const { data: insurerOptions = [], isLoading: insurersLoading } = useKdsOptions({
    ...OPPORTUNITY_KDS_FIELDS.previousInsurer,
    enabled: stageCode === 'POLICY_INBOUND' || stageCode === 'POLICY_WON',
  });

  const getWorkflowOptions = (field) => {
    if (field.optionsKey === 'stageStatus') return stageStatusOptions;
    if (field.optionsKey === 'delayReason') return delayReasonOptions;
    if (field.optionsKey === 'wonReason') return clientReviewWonReasonOptions;
    if (field.optionsKey === 'lostReason') return clientReviewLossReasonOptions;
    return field.options ?? [];
  };

  useEffect(() => {
    setStageCode(currentStageCode);
  }, [currentStageCode]);

  useEffect(() => {
    setValues(buildInitialValues(config.fields, latestPayload));
    setFieldErrors({});
    setReviewStatus(String(latestPayload.review_status ?? '').trim());
  }, [config.fields, latestPayload]);

  const isPolicyStage = stageCode === 'POLICY_INBOUND' || stageCode === 'POLICY_WON';
  const isPolicyInProgress = isPolicyStage && isPolicyInProgressValue(values.policy_status, stageStatusOptions);
  const showMarkLostButton = stageCode === 'RFQ_STAGE' || stageCode === 'QCR_STAGE';
  const policyPremium = toNumber(values.policy_premium);
  const calculatedBrokerage = (policyPremium * toNumber(values.brokerage_percentage)) / 100;
  const calculatedReward = (policyPremium * toNumber(values.reward_percentage)) / 100;

  const fields = useMemo(() => {
    const visibleConfigFields = canManageDelay
      ? config.fields
      : config.fields.filter((field) => field.name !== 'delay_reason');
    if (stageCode !== 'CLIENT_REVIEW') return visibleConfigFields;
    const status = reviewStatus.toLowerCase();
    const conditionalField =
      status === 'lost'
        ? { name: 'lost_reason', label: 'Lost Reason', type: 'select', placeholder: 'Select lost reason', required: true, optionsKey: 'lostReason' }
        : status === 'won'
          ? { name: 'won_reason', label: 'Won Reason', type: 'select', placeholder: 'Select won reason', required: true, optionsKey: 'wonReason' }
          : null;
    if (!conditionalField) return visibleConfigFields;
    const wonPaymentDateField = { name: 'payment_date', label: 'Payment Date', type: 'date', required: true };
    return status === 'won'
      ? [visibleConfigFields[0], conditionalField, wonPaymentDateField, ...visibleConfigFields.slice(1)]
      : [visibleConfigFields[0], conditionalField, ...visibleConfigFields.slice(1)];
  }, [canManageDelay, config.fields, reviewStatus, stageCode]);

  const handleChange = (fieldName) => (event) => {
    const nextValue = PERCENTAGE_FIELDS.has(fieldName)
      ? normalizePercentageInput(event.target.value)
      : event.target.value;
    setValues((prev) => ({ ...prev, [fieldName]: nextValue }));
    setFieldErrors((prev) => {
      if (!prev[fieldName]) return prev;
      const next = { ...prev };
      delete next[fieldName];
      return next;
    });
    setSaveError('');
    if (fieldName === 'review_status') setReviewStatus(nextValue);
  };

  const buildWorkflowData = () => {
    const data = {};
    fields.forEach((field) => {
      if (field.name === 'delay_reason') return;
      const rawValue = values[field.name];
      if (rawValue === '' || rawValue === null || rawValue === undefined) return;
      const targetName = field.name === 'won_reason' || field.name === 'lost_reason'
        ? 'review_reason'
        : field.name;
      data[targetName] = rawValue;
    });

    const comment = String(values.comment ?? '').trim();
    if (comment) data.comment = comment;

    if (stageCode === 'RFQ_STAGE' && data.rfq_status) data.status = data.rfq_status;
    if (stageCode === 'QCR_STAGE' && data.qcr_status) data.status = data.qcr_status;
    if (stageCode === 'CLIENT_REVIEW' && data.review_status) data.status = data.review_status;
    if ((stageCode === 'POLICY_INBOUND' || stageCode === 'POLICY_WON') && data.policy_status) {
      data.status = data.policy_status;
    }
    return data;
  };

  const handleSave = async (actionCode) => {
    if (
      isPolicyStage &&
      values.policy_start_date &&
      values.policy_end_date &&
      !isAfterDate(values.policy_end_date, values.policy_start_date)
    ) {
      const message = 'Policy End Date should be after Policy Start Date';
      setFieldErrors({ policy_end_date: message });
      setSaveError(message);
      return;
    }

    if (actionCode === 'SAVE' && isPolicyInProgress && !String(values.comment ?? '').trim()) {
      setFieldErrors({ comment: 'Comments is required' });
      setSaveError('Comments is required');
      return;
    }

    if (actionCode === 'SAVE_AND_NEXT') {
      if (isPolicyInProgress) {
        setSaveError('Policy in process can only be saved.');
        return;
      }

      const missingField = fields.find(
        (field) => field.required && !String(values[field.name] ?? '').trim(),
      );
      if (missingField) {
        const message = `${missingField.label} is required`;
        setFieldErrors({ [missingField.name]: message });
        setSaveError(message);
        return;
      }
      if (!String(values.comment ?? '').trim()) {
        setFieldErrors({ comment: 'Comments is required' });
        setSaveError('Comments is required');
        return;
      }
    }

    setIsSaving(true);
    setSaveError('');
    setFieldErrors({});
    try {
      await saveOpportunityWorkflow({
        opportunityUUID: opportunity.opportunity_uuid,
        opportunityStatusCode:
          opportunity.opportunity_status_code ??
          workflowPayload.opportunity?.opportunity_status_code,
        actionCode,
        stageCode,
        delayReason: values.delay_reason,
        workflowData: buildWorkflowData(),
      });
      setSuccessDialog({ open: true, actionCode });
    } catch (error) {
      setSaveError(error.message ?? 'Opportunity workflow save failed');
    } finally {
      setIsSaving(false);
    }
  };

  const handleViewOpportunity = async () => {
    setSuccessDialog({ open: false, actionCode: '' });
    await onSaved?.();
  };

  const handleOpenMarkLost = () => {
    setMarkLostValues({ reason: '', comments: '' });
    setMarkLostError('');
    setMarkLostOpen(true);
  };

  const handleCloseMarkLost = () => {
    setMarkLostOpen(false);
    setMarkLostError('');
  };

  const handleMarkLostChange = (fieldName) => (event) => {
    setMarkLostValues((previous) => ({
      ...previous,
      [fieldName]: event.target.value,
    }));
    setMarkLostError('');
  };

  const handleMarkLostSubmit = async () => {
    if (!String(markLostValues.reason ?? '').trim()) {
      setMarkLostError('Loss Reason is required');
      return;
    }
    if (!String(markLostValues.comments ?? '').trim()) {
      setMarkLostError('Comments is required');
      return;
    }
    setMarkLostSaving(true);
    setMarkLostError('');
    try {
      await markOpportunityAsLost({
        opportunityUUID: opportunity.opportunity_uuid,
        lostReason: markLostValues.reason,
        comments: markLostValues.comments,
      });
      setMarkLostOpen(false);
      setSuccessDialog({ open: true, actionCode: 'MARK_LOST' });
    } catch (error) {
      setMarkLostError(error.message ?? 'Mark as Lost failed');
    } finally {
      setMarkLostSaving(false);
    }
  };

  if (stageCode === 'COMPLETED') {
    return (
      <Box className="opportunity-workflow-stage-form">
        <Typography className="opportunity-workflow-details-title">Workflow</Typography>
        <Box className="opportunity-workflow-stage-complete">
          This opportunity is completed. No workflow action is available.
        </Box>
      </Box>
    );
  }

  return (
    <Box className="opportunity-workflow-stage-form">
      <Box className="opportunity-workflow-stage-form-head">
        <Box>
          <Typography className="opportunity-workflow-details-title">Workflow</Typography>
        </Box>
      </Box>

      <Box className="opportunity-workflow-stage-fields">
        <Typography className="opportunity-workflow-stage-fields-title">{config.title}</Typography>
        <Box className="opportunity-workflow-stage-form-grid">
          {fields.map((field) => {
            const selectOptions = getWorkflowOptions(field);
            const calculatedHelperText =
              isPolicyStage && field.name === 'brokerage_percentage'
                ? formatCalculatedAmount(calculatedBrokerage)
                  ? `Brokerage: ${formatCalculatedAmount(calculatedBrokerage)}`
                  : undefined
                : isPolicyStage && field.name === 'reward_percentage'
                  ? formatCalculatedAmount(calculatedReward)
                    ? `Reward Amount: ${formatCalculatedAmount(calculatedReward)}`
                    : undefined
                  : undefined;
            const helperText = fieldErrors[field.name] ?? calculatedHelperText;

            if (field.name === 'policy_insurer') {
              const normalizedValue = String(values.policy_insurer ?? '').trim();
              const selectedInsurer = insurerOptions.find(
                (option) =>
                  String(option.value ?? '').trim() === normalizedValue ||
                  String(option.code ?? '').trim() === normalizedValue,
              ) ?? null;

              return (
                <Autocomplete
                  key={field.name}
                  className="opportunity-workflow-stage-field client-kds-autocomplete"
                  options={insurerOptions}
                  value={selectedInsurer}
                  loading={insurersLoading}
                  autoHighlight
                  openOnFocus
                  PopperComponent={WorkflowKdsPopper}
                  getOptionLabel={(option) => option?.value ?? ''}
                  isOptionEqualToValue={(option, selected) => option.code === selected.code}
                  noOptionsText={insurersLoading ? COMMON_MESSAGES.loading : COMMON_MESSAGES.noDataFound}
                  onChange={(_, selected) => {
                    setValues((previous) => ({
                      ...previous,
                      policy_insurer: selected?.value ?? '',
                    }));
                    setFieldErrors((previous) => {
                      if (!previous.policy_insurer) return previous;
                      const next = { ...previous };
                      delete next.policy_insurer;
                      return next;
                    });
                    setSaveError('');
                  }}
                  slotProps={{
                    paper: { className: 'client-kds-menu-paper' },
                    listbox: { className: 'client-kds-menu-list' },
                  }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={`${field.label}${field.required ? ' *' : ''}`}
                      placeholder={field.placeholder}
                      size="small"
                      error={!!fieldErrors[field.name]}
                      helperText={fieldErrors[field.name]}
                    />
                  )}
                  renderOption={(props, option) => {
                    const { key, className, ...optionProps } = props;
                    return (
                      <li
                        key={key}
                        {...optionProps}
                        className={`${className ?? ''} client-kds-menu-item client-kds-menu-item--simple`}
                      >
                        {option.value}
                      </li>
                    );
                  }}
                />
              );
            }

            return (
              <TextField
                key={field.name}
                className="opportunity-workflow-stage-field"
                label={`${field.label}${field.required ? ' *' : ''}`}
                select={field.type === 'select'}
                type={field.type === 'select' ? undefined : field.type}
                value={values[field.name] ?? ''}
                onChange={handleChange(field.name)}
                placeholder={field.placeholder}
                size="small"
                error={!!fieldErrors[field.name]}
                helperText={helperText}
                FormHelperTextProps={{
                  className: fieldErrors[field.name] ? '' : 'opportunity-workflow-calculated-amount',
                }}
                InputLabelProps={field.type === 'date' ? { shrink: true } : undefined}
              >
                {field.type === 'select' &&
                  selectOptions.map((option) => (
                    <MenuItem value={getOptionValue(option)} key={getOptionValue(option)}>
                      {getOptionLabel(option)}
                    </MenuItem>
                  ))}
              </TextField>
            );
          })}
        </Box>
      </Box>

      <Box className="opportunity-workflow-comments-field">
        <Typography className="opportunity-workflow-stage-label">Comments *</Typography>
        <TextField
          className="opportunity-workflow-stage-comments"
          multiline
          minRows={3}
          placeholder="description about the stages ..."
          value={values.comment ?? ''}
          onChange={handleChange('comment')}
          error={!!fieldErrors.comment}
          helperText={fieldErrors.comment}
        />
      </Box>

      <Box className="opportunity-workflow-action-bar">
        <Box className="opportunity-workflow-actions">
          <Button
            className="opportunity-workflow-save-btn"
            disabled={isSaving}
            onClick={() => handleSave('SAVE')}
          >
            {isSaving ? 'Saving...' : 'Save'}
          </Button>
          <Button
            className="btn-common-red border-radius-32 opportunity-workflow-next-btn"
            disabled={isSaving || isPolicyInProgress}
            onClick={() => handleSave('SAVE_AND_NEXT')}
          >
            {isSaving ? 'Submitting...' : 'Submit & Next Stage'}
          </Button>
          {showMarkLostButton ? (
            <Button
              className="opportunity-workflow-mark-lost-btn"
              disabled={isSaving}
              startIcon={<CancelRoundedIcon />}
              onClick={handleOpenMarkLost}
            >
              Mark as Lost
            </Button>
          ) : null}
        </Box>
      </Box>
      {saveError ? <Alert severity="error">{saveError}</Alert> : null}
      <Dialog
        open={markLostOpen}
        onClose={markLostSaving ? undefined : handleCloseMarkLost}
        maxWidth="xs"
        fullWidth
        PaperProps={{ className: 'opportunity-mark-lost-dialog-paper' }}
      >
        <DialogTitle className="opportunity-mark-lost-dialog-title">
          Mark Opportunity as Lost
        </DialogTitle>
        <DialogContent className="opportunity-mark-lost-dialog-content">
          <TextField
            className="opportunity-mark-lost-field"
            label="Loss Reason *"
            select
            size="small"
            value={markLostValues.reason}
            onChange={handleMarkLostChange('reason')}
            placeholder="Select Reason"
          >
            {clientReviewLossReasonOptions.map((option) => (
              <MenuItem value={getOptionValue(option)} key={getOptionValue(option)}>
                {getOptionLabel(option)}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            className="opportunity-mark-lost-field opportunity-mark-lost-comments"
            label="Comments *"
            multiline
            minRows={3}
            value={markLostValues.comments}
            onChange={handleMarkLostChange('comments')}
          />
          {markLostError ? <Alert severity="error">{markLostError}</Alert> : null}
          <Box className="opportunity-mark-lost-actions">
            <Button
              className="opportunity-mark-lost-cancel-btn"
              onClick={handleCloseMarkLost}
              disabled={markLostSaving}
            >
              Cancel
            </Button>
            <Button
              className="btn-common-red opportunity-mark-lost-submit-btn"
              onClick={handleMarkLostSubmit}
              disabled={markLostSaving}
            >
              {markLostSaving ? 'Marking...' : 'Mark as Lost'}
            </Button>
          </Box>
        </DialogContent>
      </Dialog>
      <ClientSaveSuccessDialog
        open={successDialog.open}
        title={
          successDialog.actionCode === 'MARK_LOST'
            ? 'Opportunity Marked as Lost!'
            : successDialog.actionCode === 'SAVE'
              ? 'Workflow Saved Successfully!'
              : 'Workflow Submitted Successfully!'
        }
        message={
          successDialog.actionCode === 'MARK_LOST'
            ? 'The opportunity has been marked as lost successfully.'
            : 'The opportunity workflow has been updated successfully.'
        }
        primaryLabel="View Opportunity"
        showSecondary={false}
        onViewProfile={handleViewOpportunity}
      />
    </Box>
  );
}
