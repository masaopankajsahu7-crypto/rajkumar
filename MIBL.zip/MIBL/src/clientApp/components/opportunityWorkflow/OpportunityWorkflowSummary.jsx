import { Box, Button, Typography } from '@mui/material';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import {
  formatWorkflowCurrency,
  formatWorkflowDate,
  formatWorkflowValue,
} from '../../utils/opportunityWorkflow.js';

export default function OpportunityWorkflowSummary({ client, opportunity, currentStage, onBack }) {
  return (
    <>
      <Box className="opportunity-workflow-page-head">
        <Typography className="opportunity-workflow-page-title">Opportunity Workflow</Typography>
        <Button className="opportunity-workflow-back" onClick={onBack}>
          <ArrowBackIosNewIcon fontSize="inherit" />
          Back
        </Button>
      </Box>

      <Box className="opportunity-workflow-summary-card">
        <Box className="opportunity-workflow-summary-main">
          <Typography className="opportunity-workflow-client-name">
            {formatWorkflowValue(client?.client_name)}
          </Typography>
          <Box className="opportunity-workflow-code-row">
            <Typography className="opportunity-workflow-code-label">Opp Code</Typography>
            <Typography className="opportunity-workflow-code-value">
              {formatWorkflowValue(opportunity?.opportunity_code ?? opportunity?.opp_code)}
            </Typography>
          </Box>
        </Box>
        <Box className="opportunity-workflow-summary-grid">
          <Box className="opportunity-workflow-summary-metric">
            <Typography className="opportunity-workflow-label">Product</Typography>
            <Typography className="opportunity-workflow-value">
              {formatWorkflowValue(opportunity?.opportunity_product)}
            </Typography>
          </Box>
          <Box className="opportunity-workflow-summary-metric">
            <Typography className="opportunity-workflow-label">Sub-Product</Typography>
            <Typography className="opportunity-workflow-value">
              {formatWorkflowValue(opportunity?.opportunity_sub_product)}
            </Typography>
          </Box>
          <Box className="opportunity-workflow-summary-metric">
            <Typography className="opportunity-workflow-label">Premium</Typography>
            <Typography className="opportunity-workflow-value">
              {formatWorkflowCurrency(opportunity?.expected_premium)}
            </Typography>
          </Box>
          <Box className="opportunity-workflow-summary-metric">
            <Typography className="opportunity-workflow-label">Current Stage</Typography>
            <Typography className="opportunity-workflow-value">
              {formatWorkflowValue(currentStage)}
            </Typography>
          </Box>
          <Box className="opportunity-workflow-summary-metric">
            <Typography className="opportunity-workflow-label">Renewal Date</Typography>
            <Typography className="opportunity-workflow-value">
              {formatWorkflowDate(opportunity?.renewal_date)}
            </Typography>
          </Box>
        </Box>
      </Box>
    </>
  );
}
