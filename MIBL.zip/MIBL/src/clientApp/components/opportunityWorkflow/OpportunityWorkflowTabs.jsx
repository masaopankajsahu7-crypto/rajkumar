import { Box, Button } from '@mui/material';

const TAB_LABELS = [
  { key: 'workflow', label: 'Workflow' },
  { key: 'workflowDetails', label: 'Workflow Details' },
  { key: 'activityLogs', label: 'Activity Logs' },
];

export default function OpportunityWorkflowTabs({
  activeTab,
  onTabChange,
  showWorkflow = true,
  showWorkflowDetails = true,
  showActivityLogs = true,
}) {
  const handleTabClick = (event) => {
    const nextTab = event.currentTarget.dataset.tab;
    onTabChange(nextTab);
  };

  const visibleTabs = TAB_LABELS.filter((tab) => {
    if (tab.key === 'workflow') return showWorkflow;
    if (tab.key === 'workflowDetails') return showWorkflowDetails;
    if (tab.key === 'activityLogs') return showActivityLogs;
    return true;
  });

  return (
    <Box className="opportunity-workflow-tabs">
      {visibleTabs.map((tab) => (
        <Button
          className={`opportunity-workflow-tab ${
            activeTab === tab.key ? 'opportunity-workflow-tab--active' : 'opportunity-workflow-tab--muted'
          }`}
          data-tab={tab.key}
          key={tab.key}
          onClick={handleTabClick}
          disableRipple
        >
          {tab.label}
        </Button>
      ))}
    </Box>
  );
}
