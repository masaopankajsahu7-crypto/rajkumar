import { useEffect, useState } from 'react';
import {
  Badge,
  Box,
  Button,
  FormControl,
  IconButton,
  InputAdornment,
  MenuItem,
  Popover,
  Select,
  TextField,
  Typography,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { CLIENT_KDS_FIELDS, OPPORTUNITY_KDS_FIELDS } from '../../config/kdsFields.js';
import { PORTFOLIO_LIST_MESSAGES as MSG } from '../../config/messages/portfolioList.js';
import { getKdsOptions, searchClientsByName } from '../../services/api.jsx';
import { countActivePortfolioFilters } from '../../utils/portfolioListFilters.js';
import { sanitizeByField } from '../../utils/fieldUtils.js';

const STATUS_OPTIONS = [
  { code: '1', value: 'Active' },
  { code: '0', value: 'Inactive' },
];

const PortfolioListFilters = ({ filters, appliedFilters, onChange, onApply, onClear, hasActiveFilters }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [activeTab, setActiveTab] = useState('basic');
  const [clientOptions, setClientOptions] = useState([]);
  const [clientLoading, setClientLoading] = useState(false);
  const [clientSuggestionsOpen, setClientSuggestionsOpen] = useState(false);
  const [ownerOptions, setOwnerOptions] = useState([]);
  const [ownerLoading, setOwnerLoading] = useState(false);
  const [ownerSuggestionsOpen, setOwnerSuggestionsOpen] = useState(false);
  const [clientTypeOptions, setClientTypeOptions] = useState([]);
  const [verticalOptions, setVerticalOptions] = useState([]);
  const [portfolioTypeOptions, setPortfolioTypeOptions] = useState([]);
  const [productOptions, setProductOptions] = useState([]);
  const [subProductOptions, setSubProductOptions] = useState([]);
  const popoverOpen = Boolean(anchorEl);
  const activeCount = countActivePortfolioFilters(appliedFilters);
  const clientNameSearch = String(filters.clientName ?? '').trim();
  const ownerSearch = String(filters.owner ?? '').trim();
  const hasUnselectedClientName = Boolean(clientNameSearch && !filters.clientUUID);
  const hasUnselectedOwner = Boolean(ownerSearch && !filters.ownerId);
  const applyDisabled = hasUnselectedClientName || hasUnselectedOwner;
  const filteredOwnerOptions = ownerSearch && !filters.ownerId
    ? ownerOptions.filter((option) => option.value.toLowerCase().includes(ownerSearch.toLowerCase()))
    : [];

  useEffect(() => {
    if (!popoverOpen || (clientTypeOptions.length && verticalOptions.length && portfolioTypeOptions.length && productOptions.length)) {
      return undefined;
    }

    let ignoreResult = false;
    Promise.all([
      getKdsOptions(CLIENT_KDS_FIELDS.clientType),
      getKdsOptions(CLIENT_KDS_FIELDS.vertical),
      getKdsOptions(OPPORTUNITY_KDS_FIELDS.businessType),
      getKdsOptions(OPPORTUNITY_KDS_FIELDS.product),
    ]).then(([clientTypes, verticals, portfolioTypes, products]) => {
      if (ignoreResult) return;
      setClientTypeOptions(clientTypes);
      setVerticalOptions(verticals);
      setPortfolioTypeOptions(portfolioTypes);
      setProductOptions(products);
    });

    return () => {
      ignoreResult = true;
    };
  }, [clientTypeOptions.length, popoverOpen, portfolioTypeOptions.length, productOptions.length, verticalOptions.length]);

  useEffect(() => {
    if (!popoverOpen || !filters.product) {
      setSubProductOptions([]);
      return undefined;
    }

    let ignoreResult = false;
    getKdsOptions({ ...OPPORTUNITY_KDS_FIELDS.subProduct, parentCode: filters.product }).then((options) => {
      if (!ignoreResult) setSubProductOptions(options);
    });

    return () => {
      ignoreResult = true;
    };
  }, [filters.product, popoverOpen]);

  useEffect(() => {
    if (!popoverOpen || ownerOptions.length > 0) {
      setOwnerLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    setOwnerLoading(true);
    getKdsOptions({ ...CLIENT_KDS_FIELDS.filterOwner, search: '', limit: 100 }).then((options) => {
      if (!ignoreResult) {
        setOwnerOptions(options);
        setOwnerLoading(false);
      }
    });

    return () => {
      ignoreResult = true;
    };
  }, [ownerOptions.length, popoverOpen]);

  useEffect(() => {
    if (!popoverOpen || activeTab !== 'basic' || !clientNameSearch || filters.clientUUID) {
      setClientOptions([]);
      setClientLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    setClientLoading(true);
    const timer = window.setTimeout(async () => {
      const options = await searchClientsByName(clientNameSearch, { source: 'filter' });
      if (!ignoreResult) {
        setClientOptions(options);
        setClientLoading(false);
        setClientSuggestionsOpen(true);
      }
    }, 300);

    return () => {
      ignoreResult = true;
      window.clearTimeout(timer);
    };
  }, [activeTab, clientNameSearch, filters.clientUUID, popoverOpen]);

  const handleOpen = (event) => setAnchorEl(event.currentTarget);
  const handleClose = () => {
    setAnchorEl(null);
    setClientSuggestionsOpen(false);
    setOwnerSuggestionsOpen(false);
  };
  const handleApply = () => {
    if (applyDisabled) return;
    onApply();
    handleClose();
  };
  const handleClear = () => {
    onClear();
    setClientOptions([]);
    setClientSuggestionsOpen(false);
    setOwnerSuggestionsOpen(false);
    handleClose();
  };

  const getOptionValue = (option) => (typeof option === 'string' ? option : option.code);
  const getOptionLabel = (option) => (typeof option === 'string' ? option : option.value);
  const getSelectedLabel = (selected, options, placeholder) => {
    if (!selected) return placeholder;
    const match = options.find((option) => getOptionValue(option) === selected);
    return match ? getOptionLabel(match) : placeholder;
  };

  const handleSelectChange = (field, options = []) => (event) => {
    const selectedValue = event.target.value;
    const selectedOption = options.find((option) => getOptionValue(option) === selectedValue);
    onChange(field, selectedValue);
    onChange(`${field}Label`, selectedOption ? getOptionLabel(selectedOption) : '');
    if (field === 'product') {
      onChange('subProduct', '');
      onChange('subProductLabel', '');
    }
  };

  const handleTextChange = (field) => (event) => {
    const sanitizeType = field === 'owner' ? 'name' : 'search';
    onChange(field, sanitizeByField(sanitizeType, event.target.value));
    if (field === 'clientName') {
      onChange('clientUUID', '');
      setClientSuggestionsOpen(true);
    }
    if (field === 'owner') {
      onChange('ownerId', '');
      setOwnerSuggestionsOpen(true);
    }
  };

  const handleSearchClear = (field, idField, closeSuggestions) => (event) => {
    event.preventDefault();
    onChange(field, '');
    onChange(idField, '');
    closeSuggestions(false);
  };

  const handleSearchBlur = (field, idField, closeSuggestions) => () => {
    window.setTimeout(() => {
      if (String(filters[field] ?? '').trim() && !filters[idField]) {
        onChange(field, '');
        onChange(idField, '');
      }
      closeSuggestions(false);
    }, 150);
  };

  const getSearchInputProps = (field, idField, closeSuggestions) => ({
    endAdornment: filters[field] ? (
      <InputAdornment position="end">
        <IconButton
          className="client-mgmt-filter-input-clear"
          size="small"
          aria-label={`Clear ${field}`}
          onMouseDown={(event) => event.preventDefault()}
          onClick={handleSearchClear(field, idField, closeSuggestions)}
        >
          <CloseIcon fontSize="small" />
        </IconButton>
      </InputAdornment>
    ) : null,
  });

  const renderSelect = (field, placeholder, options = [], selectProps = {}) => (
    <FormControl size="small" fullWidth className="client-mgmt-filter-control">
      <Select
        className="client-mgmt-filter-select form-control-input border-radius-8"
        displayEmpty
        value={filters[field]}
        onChange={handleSelectChange(field, options)}
        renderValue={(selected) => getSelectedLabel(selected, options, placeholder)}
        MenuProps={{ PaperProps: { className: 'client-mgmt-filter-select-menu' } }}
        disabled={selectProps.disabled}
      >
        {options.map((option) => (
          <MenuItem key={getOptionValue(option)} value={getOptionValue(option)}>
            {getOptionLabel(option)}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );

  const renderTabButton = (tabKey, label) => (
    <Button
      className={`client-mgmt-filter-tab ${activeTab === tabKey ? 'client-mgmt-filter-tab-active' : ''}`}
      data-tab={tabKey}
      onClick={(event) => setActiveTab(event.currentTarget.dataset.tab)}
      aria-pressed={activeTab === tabKey}
    >
      {label}
    </Button>
  );

  const renderFilterSection = (title, children) => (
    <Box className="client-mgmt-filter-section">
      <Typography className="client-mgmt-filter-section-title">{title}</Typography>
      {children}
    </Box>
  );

  const handleClientSelect = (option) => {
    onChange('clientName', option.clientName);
    onChange('clientUUID', option.clientUUID);
    setClientSuggestionsOpen(false);
    setClientOptions([]);
  };

  const handleOwnerSelect = (option) => {
    onChange('owner', option.value);
    onChange('ownerId', option.code);
    setOwnerSuggestionsOpen(false);
  };

  return (
    <>
      <Badge badgeContent={activeCount} color="error" invisible={activeCount === 0} className="client-mgmt-filter-badge">
        <Button
          className="client-mgmt-filter-toggle-btn opportunity-mgmt-icon-btn"
          startIcon={<Box className="opportunity-mgmt-filter-lines-icon" aria-hidden="true"><span /><span /><span /></Box>}
          onClick={handleOpen}
          aria-label={MSG.filters.openFilters}
        />
      </Badge>

      <Popover
        open={popoverOpen}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        className="client-mgmt-filter-popover opportunity-mgmt-filter-popover"
        slotProps={{ paper: { className: 'client-mgmt-filter-popover-paper opportunity-mgmt-filter-popover-paper' } }}
      >
        <Box className="client-mgmt-filter-popover-head">
          <Typography className="georama-SemiBold client-mgmt-filter-popover-title">{MSG.filters.title}</Typography>
          <Button className="client-mgmt-filter-popover-close" onClick={handleClose} aria-label={MSG.filters.clear}>
            <CloseIcon fontSize="small" />
          </Button>
        </Box>

        <Box className="client-mgmt-filter-tabs">
          {renderTabButton('basic', MSG.filters.tabs.basic)}
          {renderTabButton('advanced', MSG.filters.tabs.advanced)}
        </Box>

        <Box className="client-mgmt-filter-popover-body">
          {activeTab === 'basic' && (
            <>
              {renderFilterSection(MSG.filters.sections.identity, (
                <>
                  <Box className="client-mgmt-filter-popover-row">
                    {renderSelect('product', MSG.filters.product, productOptions)}
                    {renderSelect('subProduct', MSG.filters.subProduct, subProductOptions, { disabled: !filters.product })}
                  </Box>
                  <Box className="client-mgmt-filter-popover-row">
                    {renderSelect('portfolioType', MSG.filters.portfolioType, portfolioTypeOptions)}
                    {renderSelect('isActive', MSG.filters.portfolioStatus, STATUS_OPTIONS)}
                  </Box>
                </>
              ))}

              {renderFilterSection(MSG.filters.sections.client, (
                <Box className="client-mgmt-client-search">
                  <TextField
                    className="client-mgmt-filter-input"
                    size="small"
                    fullWidth
                    placeholder={MSG.filters.clientName}
                    value={filters.clientName}
                    onChange={handleTextChange('clientName')}
                    onFocus={() => setClientSuggestionsOpen(true)}
                    onBlur={handleSearchBlur('clientName', 'clientUUID', setClientSuggestionsOpen)}
                    InputProps={getSearchInputProps('clientName', 'clientUUID', setClientSuggestionsOpen)}
                  />
                  {clientSuggestionsOpen && clientNameSearch && !filters.clientUUID && (
                    <Box className="client-mgmt-client-suggestions">
                      {clientLoading && <Typography className="client-mgmt-client-suggestion-note">{MSG.filters.searching}</Typography>}
                      {!clientLoading && clientOptions.map((option) => (
                        <Button
                          key={option.clientUUID}
                          className="client-mgmt-client-suggestion"
                          onMouseDown={(event) => event.preventDefault()}
                          onClick={() => handleClientSelect(option)}
                        >
                          <span className="client-mgmt-client-suggestion-name">{option.clientName}</span>
                          {option.owner ? <span className="client-mgmt-client-suggestion-owner">{MSG.filters.ownerPrefix}: {option.owner}</span> : null}
                        </Button>
                      ))}
                      {!clientLoading && clientOptions.length === 0 && (
                        <Typography className="client-mgmt-client-suggestion-note">{MSG.filters.noClientResults}</Typography>
                      )}
                    </Box>
                  )}
                </Box>
              ))}
            </>
          )}

          {activeTab === 'advanced' && (
            <>
              {renderFilterSection(MSG.filters.sections.ownership, (
                <Box className="client-mgmt-owner-search">
                  <TextField
                    className="client-mgmt-filter-input"
                    size="small"
                    fullWidth
                    placeholder={MSG.filters.owner}
                    value={filters.owner}
                    onChange={handleTextChange('owner')}
                    onFocus={() => setOwnerSuggestionsOpen(true)}
                    onBlur={handleSearchBlur('owner', 'ownerId', setOwnerSuggestionsOpen)}
                    InputProps={getSearchInputProps('owner', 'ownerId', setOwnerSuggestionsOpen)}
                  />
                  {ownerSuggestionsOpen && ownerSearch && !filters.ownerId && (
                    <Box className="client-mgmt-owner-suggestions">
                      {ownerLoading && <Typography className="client-mgmt-owner-suggestion-note">{MSG.filters.searching}</Typography>}
                      {!ownerLoading && filteredOwnerOptions.map((option) => (
                        <Button
                          key={option.code}
                          className="client-mgmt-owner-suggestion"
                          onMouseDown={(event) => event.preventDefault()}
                          onClick={() => handleOwnerSelect(option)}
                        >
                          {option.value}
                        </Button>
                      ))}
                      {!ownerLoading && filteredOwnerOptions.length === 0 && (
                        <Typography className="client-mgmt-owner-suggestion-note">{MSG.filters.noOwnerResults}</Typography>
                      )}
                    </Box>
                  )}
                </Box>
              ))}

              {renderFilterSection(MSG.filters.sections.client, (
                <Box className="client-mgmt-filter-popover-row">
                  {renderSelect('clientType', MSG.filters.clientType, clientTypeOptions)}
                  {renderSelect('clientVertical', MSG.filters.vertical, verticalOptions)}
                </Box>
              ))}
            </>
          )}
        </Box>

        <Box className="client-mgmt-filter-popover-actions">
          {applyDisabled ? (
            <Typography className="client-mgmt-filter-validation georama-Regular">
              Select a valid option.
            </Typography>
          ) : null}
          <Button className="client-mgmt-filter-clear-btn text-sky" onClick={handleClear} disabled={!hasActiveFilters}>
            {MSG.filters.clear}
          </Button>
          <Button className="btn-common-red client-mgmt-filter-apply-btn" onClick={handleApply} disabled={applyDisabled}>
            {MSG.filters.apply}
          </Button>
        </Box>
      </Popover>
    </>
  );
};

export default PortfolioListFilters;
