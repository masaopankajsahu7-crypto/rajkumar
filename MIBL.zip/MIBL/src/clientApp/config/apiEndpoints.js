export const API_ENDPOINTS = {
  authCheck: '/authCheck',
  otpVerification: '/otpVerification',
  sendOTP: '/sendOTP',
  verifyOTP: '/verifyOTP',
  resetPassword: '/resetPassword',
  changePassword: '/changePassword',
  getUserList: '/getUserList',
  fetchRole: '/fetchRole',

  /** REST client resource — base: {baseUrl}/clients (legacy, unused once wired to client-service) */
  clients: '/clients',
  clientById: (clientUUID) => `/clients/${clientUUID}`,
  clientPortfolios: (clientUUID) => `/clients/${clientUUID}/portfolios`,
};

/**
 * Client Service endpoints — all POST, served from {clientServiceBaseUrl}.
 *  - save:  create + update a client
 *  - check: smart-search / duplicate name check
 *  - list:  paginated + filtered client list
 *  - get:   single client by client_ID
 */
export const CLIENT_SERVICE_ENDPOINTS = {
  save: '/clients/save',
  check: '/clients/check',
  list: '/clients/list',
  get: '/clients/view',
  approve: '/clients/approve',
  // Client-detail sub-resources (endpoints TBD — dummy fallback until the real APIs exist).
  clientPortfolios: '/clients/portfolios',
  clientOpportunities: '/clients/opportunities',
};

/**
 * Master Service endpoints — served from {masterServiceBaseUrl}.
 *  - kds: common dropdown/master-data endpoint (POST). One call per (key_module, key_source, key_name).
 */
export const MASTER_SERVICE_ENDPOINTS = {
  kds: '/master/kds',
  pincode: '/master/pincode',
};

/**
 * App Service endpoints — opportunity workflow APIs.
 */
export const APP_SERVICE_ENDPOINTS = {
  kds: '/master/kds',
  masterUser: '/master/user',
  getReport: '/master/get-report',
  saveReport: '/master/save-report',
  clientsReassign: '/clients/reassign',
  clientActivitiesList: '/clients/activities/list',
  clientActivitiesSave: '/clients/activities/save',
  opportunityList: '/opportunity/opportunity/list',
  opportunityMigrationList: '/opportunity/opportunity/mgrn',
  opportunityMigrationConvert: '/opportunity/opportunity/mgrn/converter',
  opportunitySave: '/opportunity/opportunity/save',
  opportunityAssign: '/opportunity/opportunity/assign',
  opportunityLost: '/opportunity/opportunity/lost',
  opportunityView: '/opportunity/opportunity/view',
  opportunityPortfolioList: '/opportunity/portfolio/list',
  opportunityPortfolioSave: '/opportunity/portfolio/save',
  opportunityPortfolioReassign: '/opportunity/portfolio/reassign',
  opportunityWorkflowView: '/opportunity/workflow/view',
  opportunityWorkflowSave: '/opportunity/workflow/save',
  opportunityActivityLogs: '/opportunity/activity/get',
  opportunityDashboardView: '/opportunity/dashboard/view',
  renewalLeadList: '/opportunity/renewal/lead/list',
  renewalLeadOpportunity: '/opportunity/renewal/lead/opportunity',
  renewalLeadOwnerReassign: '/opportunity/renewal/lead/owner/reassign',
};
