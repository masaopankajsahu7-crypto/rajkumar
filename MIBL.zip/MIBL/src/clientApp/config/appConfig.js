/** App-wide constants and feature flags */
export const APP_CONFIG = {
  /** Skips real login/OTP when true (development only) */
  DEV_BYPASS_LOGIN: false,

  /**
   * OTP is used by the inherited auth flow when the backend requires it:
   * - Login: if userDetail.otp === "Yes"
   * - Forgot password: verify identity before reset
   * Not active while DEV_BYPASS_LOGIN is true.
   */
  OTP_LENGTH: 6,
  OTP_RESEND_TIMER_SECONDS: 120,
  OTP_VALIDITY_MINUTES: 10,

  TOAST_AUTO_CLOSE_MS: 1000,

  /**
   * When enabled, JSON API request bodies are sent as { payload: encryptedBase64 }
   * and encrypted API responses are decrypted centrally.
   */
  ENABLE_API_PAYLOAD_ENCRYPTION: true,

  LIST_PAGE_SIZE: 10,
  SEARCH_MAX_LENGTH: 50,
  PORTFOLIO_MAX_OTHER_CONTACTS: 10,

  PASSWORD_IDLE_RESET_DAYS: 15,
  SAP_DEBOUNCE_MS: 250,
};
