// Read the MAIN app store (src/redux/store.jsx) — that's the one mounted by main.jsx's <Provider>
// and the one login writes `loggedData` into. clientApp/redux/store.jsx is a leftover standalone
// store that nothing logs into, so reading it here missed the authenticated user data.
import store from '../../redux/store.jsx';

/**
 * Central place for the Client Service mappings that depend on backend master data.
 *
 * IMPORTANT: the API works in CODES / IDS, the UI works in DISPLAY LABELS.
 * These maps bridge the two. Fill them in from the backend master data
 * (the codes below are placeholders derived from the sample payload).
 */

/**
 * Best-effort resolver for the current numeric user id from the persisted auth state.
 * Uses only the logged-in auth response data; no hardcoded user id fallback.
 */
export const getCurrentUserId = () => {
  const logged = store.getState()?.user?.loggedData ?? {};
  return logged.userid ?? logged.user_id ?? logged.userId ?? logged.id ?? '';
};

export const getCurrentLastLoginDate = () => {
  const user = store.getState()?.user ?? {};
  const logged = user.loggeddate ?? user.loggedData ?? {};
  return logged.lastLoginDate ?? logged.last_login_date ?? '';
};

export const getCurrentLoggedInState = () => Boolean(store.getState()?.user?.loggedIn);

/**
 * Client type display label -> backend `kds` key_code.
 * Derived from the list response (which returns both code and label). Extend with the full
 * set from a master API when available.
 */
export const CLIENT_TYPE_CODE_MAP = {
  Corporate: 'cttc',
  Dealer: 'cttd',
};

/** Vertical display label -> backend `kds` key_code. */
export const VERTICAL_CODE_MAP = {
  SME: 'coos',
  CORPORATE: 'cvva',
  INDIVIDUAL: 'cooi',
};

/** Client approval/status display label -> backend status code. */
export const CLIENT_STATUS_CODE_MAP = {
  Approved: 'casa',
  Rejected: 'casr',
  Pending: 'casp',
};

/** Client active-state display label -> backend flag. */
export const CLIENT_ACTIVE_STATE_MAP = {
  Active: '1',
  Inactive: '0',
};

const invert = (map) =>
  Object.entries(map).reduce((acc, [label, code]) => {
    if (code) acc[code] = label;
    return acc;
  }, {});

/** Reverse maps (code -> label) for rendering API responses back into the UI. */
export const CLIENT_TYPE_LABEL_MAP = invert(CLIENT_TYPE_CODE_MAP);
export const VERTICAL_LABEL_MAP = invert(VERTICAL_CODE_MAP);
export const CLIENT_STATUS_LABEL_MAP = invert(CLIENT_STATUS_CODE_MAP);
export const CLIENT_ACTIVE_STATE_LABEL_MAP = invert(CLIENT_ACTIVE_STATE_MAP);

/**
 * Convert a display label to its backend code. If no mapping exists yet, the raw
 * value is passed through so the request still goes out (and is easy to spot/fix).
 */
export const toClientTypeCode = (label) => CLIENT_TYPE_CODE_MAP[label] ?? label ?? '';
export const toVerticalCode = (label) => VERTICAL_CODE_MAP[label] ?? label ?? '';
export const toClientStatusCode = (label) => CLIENT_STATUS_CODE_MAP[label] ?? label ?? '';
export const toClientActiveState = (label) => CLIENT_ACTIVE_STATE_MAP[label] ?? label ?? '';
