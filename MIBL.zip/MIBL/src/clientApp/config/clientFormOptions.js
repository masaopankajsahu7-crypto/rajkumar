// Client Type + Vertical options must match the backend `kds` master (FK on client_type_code /
// v_client_vertical_code). These are the values seen in the list response; replace with a
// master API later for the full set.
export const CLIENT_FORM_OPTIONS = {
  clientTypes: ['Corporate', 'Dealer'],
  verticals: ['SME', 'CORPORATE', 'INDIVIDUAL'],
};
