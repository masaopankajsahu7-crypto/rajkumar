import { CLIENT_CREATE_MESSAGES as MSG } from './messages/client.js';

export const SECTION_KEYS = {
  basic: 'basic',
  contact: 'contact',
  portfolio: 'portfolio',
};

export const CLIENT_FORM_STEPS = [
  {
    key: SECTION_KEYS.basic,
    titleKey: 'basicDetails',
    fields: ['client_name', 'client_type', 'vertical', 'pan', 'cin', 'gstin'],
    optionalFields: ['pan', 'cin', 'gstin'],
  },
  {
    key: SECTION_KEYS.contact,
    titleKey: 'clientContact',
    fields: [
      'address_line1',
      'address_line2',
      'city',
      'state',
      'pincode',
      'primary_contact_name',
      'primary_mobile',
      'primary_email',
    ],
    optionalFields: ['address_line1', 'address_line2'],
  },
  {
    key: SECTION_KEYS.portfolio,
    titleKey: 'portfolioDetails',
    fields: ['portfolios'],
  },
];

export const OPTIONAL_CLIENT_SECTIONS = new Set();

export const getClientFormSections = ({ includePortfolio = true } = {}) =>
  CLIENT_FORM_STEPS.filter((step) => includePortfolio || step.key !== SECTION_KEYS.portfolio).map((step) => ({
    key: step.key,
    title: MSG.sections[step.titleKey],
  }));
