/**
 * Client list table column management.
 *
 * Only the columns listed here are rendered, in this exact order.
 * Add/reorder/remove items here to change the client list table.
 */
export const CLIENT_LIST_COLUMNS = [
  { key: 'client_name', label: 'Name' },
  { key: 'client_owner', label: 'Owner' },
  { key: 'client_type', label: 'Type' },
  { key: 'client_vertical', label: 'Vertical' },
  { key: 'city_name', label: 'City' },
  { key: 'client_status', label: 'Approval Status' },
  { key: 'active', label: 'Client Status' },
];

export const CLIENT_LIST_COLUMN_KEYS = CLIENT_LIST_COLUMNS.map((column) => column.key);

export const CLIENT_LIST_COLUMN_LABELS = Object.fromEntries(
  CLIENT_LIST_COLUMNS.map((column) => [column.key, column.label]),
);
