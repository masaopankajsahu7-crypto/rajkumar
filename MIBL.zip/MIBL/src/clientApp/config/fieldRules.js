import { PATTERNS } from './patterns.js';

/** Field-centric rules — shared across all forms */
export const FIELD_RULES = {
  mobile: {
    maxLength: 10,
    pattern: PATTERNS.MOBILE,
    sanitize: 'mobile',
  },
  indianMobile: {
    maxLength: 10,
    pattern: PATTERNS.INDIAN_MOBILE,
  },
  email: {
    maxLength: 255,
    pattern: PATTERNS.EMAIL,
    sanitize: 'email',
  },
  emailOrMobile: {
    maxLength: 50,
  },
  password: {
    minLength: 9,
    maxLength: 50,
  },
  passwordForgot: {
    minLength: 9,
    maxLength: 20,
  },
  sap: {
    maxLength: 8,
    exactLength: 8,
    sanitize: 'digits',
  },
  sapLogin: {
    maxLength: 10,
    sanitize: 'digits',
  },
  pan: {
    maxLength: 10,
    pattern: PATTERNS.PAN,
    sanitize: 'pan',
  },
  gstin: {
    maxLength: 15,
    pattern: PATTERNS.GSTIN,
    sanitize: 'gstin',
  },
  cin: {
    maxLength: 21,
    pattern: PATTERNS.CIN,
    sanitize: 'cin',
  },
  pincode: {
    maxLength: 6,
    pattern: PATTERNS.PINCODE,
    sanitize: 'pincode',
  },
  name: {
    pattern: PATTERNS.NAME,
    sanitize: 'name',
  },
  cityState: {
    pattern: PATTERNS.NAME,
    sanitize: 'cityState',
  },
  address: {
    sanitize: 'address',
  },
  search: {
    maxLength: 50,
    sanitize: 'search',
  },
  otp: {
    maxLength: 6,
    exactLength: 6,
    sanitize: 'digits',
  },
  otpDigit: {
    maxLength: 1,
    sanitize: 'digits',
  },
  brokerage: {
    pattern: PATTERNS.DECIMAL_2,
    sanitize: 'brokerage',
    minExclusive: 0,
    maxExclusive: 100,
  },
  amount: {
    pattern: PATTERNS.DECIMAL_2,
    sanitize: 'decimal2',
  },
  policyNumber: {
    pattern: PATTERNS.POLICY_NUMBER,
    sanitize: 'policyNumber',
  },
  clientName: {
    maxLength: 255,
  },
  text: {},
};
