/**
 * Central registry of every master-service (kds) dropdown in the client module.
 *
 * This is the SINGLE SOURCE OF TRUTH for the (key_module, key_source, key_name) triple the
 * backend expects for each dropdown — the values map 1:1 to rows in `rfq_kds`. Nothing about
 * "what to send to the backend" is hardcoded in components: the form just spreads an entry:
 *
 *   <KdsSelect {...CLIENT_KDS_FIELDS.vertical} label={...} value={...} onChange={...} />
 *
 * Add / change a dropdown here and it flows everywhere. Keep the keys form-oriented
 * (what the field is), and the source/name backend-oriented (what the master expects).
 */
export const CLIENT_MODULE = 'client';
export const OPPORTUNITY_MODULE = 'opportunity';
export const RENEWAL_MODULE = 'renewal';
export const WORKFLOW_MODULE = 'workflow';
export const CLIENT_ACTIVITY_MODULE = 'client_activity';

export const CLIENT_KDS_FIELDS = {
  // --- wired into the Add/Edit Client form ---
  clientType: { module: CLIENT_MODULE, source: 'type', name: 'type' },
  vertical: { module: CLIENT_MODULE, source: 'vertical', name: 'vertical' },

  // --- available in kds, not yet placed in the form (kept here so the mapping is documented) ---
  ownerType: { module: CLIENT_MODULE, source: 'ownertype', name: 'owner' },
  filterOwner: { module: CLIENT_MODULE, source: 'filter', name: 'owner' },
  approvalStatus: { module: CLIENT_MODULE, source: 'approval', name: 'status' },
  approvalReason: { module: CLIENT_MODULE, source: 'rejection', name: 'reason' },
};

/**
 * Opportunity dropdowns (used by the Portfolio form fields). LOB -> Product -> Sub-Product is a
 * hierarchy: a child's parent_code equals its parent's `code`. KdsSelect filters children by the
 * selected parent's code. Until the master-service populates parent_code, KdsSelect falls back to
 * showing every option (flat) — so this works today and becomes a cascade automatically later.
 */
export const OPPORTUNITY_KDS_FIELDS = {
  product: { module: OPPORTUNITY_MODULE, source: 'product', name: 'product' },
  subProduct: { module: OPPORTUNITY_MODULE, source: 'sub_product', name: 'sub_product' },
  previousInsurer: { module: OPPORTUNITY_MODULE, source: 'insurer', name: 'insurer' },
  // Business Type (New / Renewal / Rollover) — not part of the LOB cascade.
  businessType: { module: OPPORTUNITY_MODULE, source: 'type', name: 'type' },
  filterStatus: { module: OPPORTUNITY_MODULE, source: 'status', name: 'status' },
  workflowStage: { module: OPPORTUNITY_MODULE, source: 'filter', name: 'stage' },
  filterPlacementRm: { module: OPPORTUNITY_MODULE, source: 'filter', name: 'placement_rm' },
};

export const WORKFLOW_KDS_FIELDS = {
  stageStatus: (stageCode) => ({ module: WORKFLOW_MODULE, source: 'stages', name: stageCode }),
  delayReason: (stageCode) => ({ module: WORKFLOW_MODULE, source: 'delay', name: stageCode }),
  clientReviewWonReason: { module: WORKFLOW_MODULE, source: 'won', name: 'CLIENT_REVIEW' },
  clientReviewLossReason: { module: WORKFLOW_MODULE, source: 'loss', name: 'CLIENT_REVIEW' },
};

export const RENEWAL_KDS_FIELDS = {
  leadStatus: { module: RENEWAL_MODULE, source: 'lead_status', name: 'status' },
  notRenewableReason: { module: RENEWAL_MODULE, source: 'rejection', name: 'reason' },
};

export const ACTIVITY_KDS_FIELDS = {
  meetingMode: { module: CLIENT_ACTIVITY_MODULE, source: 'meeting_mode', name: 'meeting_mode' },
  activityType: { module: CLIENT_ACTIVITY_MODULE, source: 'activity_type', name: 'activity_type' },
  meetingStatus: { module: CLIENT_ACTIVITY_MODULE, source: 'meeting_status', name: 'meeting_status' },
  clientInterest: { module: CLIENT_ACTIVITY_MODULE, source: 'interest', name: 'client_interest' },
};
