import { COMMON_MESSAGES } from './common.js';

export const CLIENT_LIST_MESSAGES = {
  title: 'Clients',
  addNewClient: 'Add New Client',
  sort: 'Sort',
  sortClients: 'Sort clients',
  search: 'Search clients...',
  edit: 'Edit',
  actions: 'Actions',
  moreActions: 'More actions',
  quickActions: 'Quick actions',
  view: 'View',
  addPortfolio: 'Add Portfolio',
  addOpportunity: 'Add Opportunity',
  reassignOwner: 'Reassign Owner',
  page: 'Page',
  pageOf: (total) => `of ${total}`,
  totalClients: (total) => `Total: ${total}`,
  previousPage: 'Previous page',
  nextPage: 'Next page',
  lastUpdated: 'Last updated',
  refreshing: 'refreshing…',

  // Column-header overrides for response keys where the auto-humanized label isn't ideal.
  // Any key not listed here is humanized automatically (client_name -> "Client Name").
  columnLabels: {
    client_name: 'Client Name',
    client_type: 'Client Type',
    client_vertical: 'Vertical',
    client_city: 'City',
    client_owner: 'Client Owner',
    client_status: 'Approval Status',
  },
  filters: {
    search: 'Search',
    clientName: 'Client Name',
    clientUUID: 'Client UUID',
    clientType: 'Client Type',
    primaryOwner: 'Primary Owner',
    ownerId: 'Owner ID',
    vertical: 'Vertical',
    pincode: 'Pincode',
    cityName: 'City',
    clientStatus: 'Approval Status',
    activeState: 'Client Status',
    fromDate: 'Created From',
    toDate: 'Created To',
    dateRangePreset: 'Date Range',
    dateFilterType: 'Date Type',
    sortOrder: 'Sort Order',
    renewalDate: 'Renewal Date',
    createdDate: 'Created Date',
    sections: {
      identity: 'Client Identity',
      ownership: 'Ownership',
      location: 'Location',
      status: 'Status',
      createdDate: 'Created Date',
      dateSort: 'Date & Sort',
    },
    tabs: {
      basic: 'Basic',
      advanced: 'Advanced',
      sort: 'Sort',
    },
    sortComingSoon: 'Sorting options will appear here.',
    apply: 'Apply',
    clear: 'Clear',
    all: 'All',
    title: 'Filters',
    openFilters: 'Open filters',
    clearAll: 'Clear all',
    searching: 'Searching...',
    noClientResults: 'No clients found',
    noOwnerResults: 'No owners found',
    ownerPrefix: 'Owner',
  },
  ...COMMON_MESSAGES,
};

export const CLIENT_CREATE_MESSAGES = {
  title: 'Add Client',
  editTitle: 'Edit Client',
  back: COMMON_MESSAGES.back,
  loadingClient: 'Loading client details...',

  clientNameSearch: {
    placeholder: 'Search client name',
    available: 'Name available — you are good to go',
    similarExists: 'Clients with similar name already linked with MIBL',
    ownerLabel: 'Owner',
    resultsTitle: 'Matching clients found',
    resultsSubtitle: 'Select a client to open the client list',
  },

  search: {
    sectionTitle: 'Search existing client',
    description: 'Check if your organisation already has a client with this name.',
    clientNameLabel: 'Client Name',
    placeholder: 'Enter client name',
    checking: 'Checking...',
    checkAndContinue: 'Check & Continue',
  },

  sections: {
    basicDetails: 'Basic Details',
    clientContact: 'Client Contact',
    addressDetails: 'Address Details',
    communicationDetails: 'Communication Details',
    portfolioDetails: 'Portfolio',
    approverDetails: 'Approver Details',
  },

  subsections: {
    address: 'Address',
    primary: 'Primary',
    secondary: 'Secondary',
  },

  labels: {
    clientName: 'Client Name',
    clientType: 'Client Type',
    vertical: 'Vertical',
    pan: 'PAN',
    cin: 'CIN',
    gstin: 'GSTIN',
    primaryOwner: 'Primary Owner',
    primaryOwnerMobile: 'Primary Owner Mobile No.',
    primaryOwnerEmail: 'Primary Owner Email',
    coOwner: 'Co-Owner',
    coOwnerMobile: 'Co-Owner Mobile No.',
    coOwnerEmail: 'Co-Owner Email',
    addressLine1: 'Address Line1',
    addressLine2: 'Address Line2',
    city: 'City',
    state: 'State',
    pinCode: 'Pin Code',
    contactPersonName: 'Contact Person Name',
    mobileNo: 'Mobile No.',
    email: 'Email',
    approverName: 'Approver Name',
  },

  placeholders: {
    clientName: 'Enter client name',
    clientType: 'Select Client Type',
    vertical: 'Select Vertical',
    pan: 'e.g. ABCDE1234F',
    cin: 'e.g. L12345MH2000PLC123456',
    gstin: 'e.g. 22ABCDE1234F1Z5',
    addressLine1: 'Flat / Building / Street',
    addressLine2: 'Area / Landmark (optional)',
    city: 'Enter city',
    state: 'Enter state',
    pinCode: 'e.g. 400001',
    contactPersonName: 'Enter contact person name',
    mobileNo: 'Enter 10-digit mobile no.',
    email: 'name@example.com',
    approverName: 'Enter approver name',
  },

  buttons: {
    addPortfolio: '+ Add Portfolio',
    addSecondaryContact: '+ Add Secondary Contact',
    remove: 'Remove',
    submitting: 'Submitting...',
    submitClient: 'Submit Client',
    updateClient: 'Update Client',
    updating: 'Updating...',
    previous: 'Previous',
    next: 'Next',
  },

  secondaryContactTitle: (index) => `Secondary Contact ${index + 1}`,

  stepNav: {
    stepOf: (current, total) => `Step ${current} / ${total}`,
  },

  portfolio: {
    requiredHint:
      'At least one portfolio is required before you can submit the client. Click "+ Add Portfolio" to get started.',
    addedSummary: (count) =>
      count === 1
        ? '1 portfolio added. You can add more or submit the client.'
        : `${count} portfolios added. You can add more or submit the client.`,
    listItem: (index, lob, product) => {
      const details = [lob, product].filter(Boolean).join(' / ');
      return details ? `Portfolio ${index + 1}: ${details}` : `Portfolio ${index + 1}`;
    },
  },

  duplicate: {
    title: 'Client already exists',
    body: (name) =>
      `A client named "${name}" already exists in your organisation. Please use a different name.`,
    ok: COMMON_MESSAGES.ok,
  },

  saveDialog: {
    savedTitle: 'Client Saved Successfully!',
    updatedTitle: 'Client Updated Successfully!',
    savedMessage: 'The new client profile and database entry have been compiled and updated in the ecosystem.',
    updatedMessage: 'The client profile and database entry have been updated in the ecosystem.',
    viewProfile: 'View Client Profile',
    returnToList: 'Return to List View',
    close: COMMON_MESSAGES.close,
  },

  saveError: {
    title: 'Save failed',
    fallback: 'Something went wrong while saving the client. Please try again.',
  },

  errors: {
    clientNameRequired: 'Client name is required',
    clientTypeRequired: 'Client type is required',
    verticalRequired: 'Vertical is required',
    primaryOwnerRequired: 'Primary owner is required',
    primaryOwnerMobileRequired: 'Primary owner mobile no. is required',
    primaryOwnerEmailRequired: 'Primary owner email is required',
    primaryContactNameRequired: 'Primary contact person name is required',
    primaryContactMobileRequired: 'Primary mobile no. is required',
    primaryContactEmailRequired: 'Primary email is required',
    pincodeRequired: 'Pin code is required',
    cityRequired: 'City is required',
    stateRequired: 'State is required',
    approverNameRequired: 'Approver name is required',
    portfolioRequired: 'At least one portfolio is required before submitting the client.',
    invalidMobile: 'Mobile no. must be exactly 10 digits',
    invalidEmail: 'Enter a valid email address',
    invalidPan: 'PAN must be 10 characters (e.g. ABCDE1234F)',
    invalidGstin: 'GSTIN must match the valid 15-character format (e.g. 22ABCDE1234F1Z5)',
    invalidCin: 'CIN must match the valid 21-character format (e.g. U72900MH2018PTC123456)',
    invalidPincode: 'Pin code must be 6 digits',
    invalidName: 'Only letters, spaces and dot are allowed',
    invalidCityState: 'Only letters and spaces are allowed',
    sectionIncomplete: 'Please fix the errors in this section before continuing',
  },
};
