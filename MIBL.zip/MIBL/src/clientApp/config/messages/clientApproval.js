export const CLIENT_APPROVAL_MESSAGES = {
  similarTitle: 'Similar Records Found (Potential Duplicates)',
  similarSubtitle:
    'We found existing active client accounts with high match similarity. Please review them carefully before approval.',
  noSimilar: 'No similar active records found.',
  ownerPrefix: 'Owner: ',

  actionTitle: 'Internal Approval Action Process',
  approve: 'Approve Client',
  reject: 'Reject Client',
  rejectionReasonLabel: 'Rejection Reason Category',
  rejectionReasonPlaceholder: '-- Select Rejection Reason --',
  remarksLabel: 'Reviewer Remarks / Notes',
  remarksPlaceholder: 'Type choice documentation or remarks notes here...',
  submit: 'Submit Decision',
  submitting: 'Submitting...',

  errors: {
    submitFailed: 'Unable to submit approval decision. Please try again.',
  },

  dialog: {
    approvedTitle: 'Client Approved Successfully!',
    rejectedTitle: 'Client Rejected Successfully!',
    approvedMessage: 'The approval decision has been submitted and the client is now approved.',
    rejectedMessage: 'The rejection decision has been submitted and the client is now rejected.',
    viewProfile: 'View Client Profile',
    returnToList: 'Return to List View',
    close: 'Close',
  },
};
