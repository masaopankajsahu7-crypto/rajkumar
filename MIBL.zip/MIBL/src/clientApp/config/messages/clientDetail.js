import { COMMON_MESSAGES } from './common.js';

export const CLIENT_DETAIL_MESSAGES = {
  title: 'Client Master Profile',
  approvalTitle: 'Client Master Profile Approval',
  back: COMMON_MESSAGES.back,
  viewOnly: 'View-Only',
  reviewMode: 'Review Mode',
  editAria: (name) => `Edit ${name}`,
  editableByMgr: '[Editable by Mgr+]',
  addContact: '+ Add Contact',
  edit: 'Edit',
  addNewPortfolio: '+ Add New Portfolio',
  addNewOpportunity: '+ Add Opportunity',
  portfoliosTitle: (count) => `Client Portfolios [${count}]`,
  opportunitiesTitle: (count) => `Opportunities & Pipeline Tracker [${count}]`,
  contactsTitle: (count) => `Contacts [${count}]`,
  noPortfolios: 'No portfolios added yet.',
  noOpportunities: 'No opportunities found.',
  ownerComingSoon: {
    title: 'Coming Soon',
    message: 'Owner and co-owner update will be available soon.',
    back: 'Back',
  },

  pendingNotice: {
    title: 'Client pending approval',
    message: 'Opportunities become available once this client is approved.',
  },
  rejectedNotice: {
    title: 'Client rejected',
    message: 'Portfolios and opportunities are not available for rejected clients.',
  },

  header: {
    client: 'Client',
    code: 'code',
    owner: 'Owner',
    approved: 'Approved By',
    coOwner: 'Co Owner',
  },

  sections: {
    coreDetails: 'Client Core Details',
    governance: 'Internal Governance',
    addressStatutory: 'Address & Statutory Details',
  },

  labels: {
    clientCode: 'Client Code',
    type: 'Type',
    vertical: 'Vertical',
    primaryOwner: 'Primary Owner',
    coOwners: 'Co-Owners',
    approvedBy: 'Approved By',
    mobile: 'M',
    email: 'Email',
    address: 'Address',
    pincode: 'Pincode',
    city: 'City',
    gstin: 'GSTIN',
    cin: 'CIN',
    pancard: 'PANCARD',
  },

  portfolioColumns: {
    portfolioId: 'Portfolio ID',
    product: 'Product',
    subProduct: 'Sub Product',
    owner: 'Owner',
    activeOpps: 'Active Opps',
    totalOpps: 'Total Opps',
  },

  opportunityColumns: {
    opportunityId: 'Opportunity ID',
    businessType: 'Business Type',
    product: 'Product',
    subProduct: 'Sub Product',
    owner: 'Owner',
    placementRm: 'Placement RM',
    renewalDate: 'Renewal Date',
    status: 'Status',
    stage: 'Stage',
  },

  actions: {
    view: 'View details',
    settings: 'Settings',
  },
};
