export const COMMON_MESSAGES = {
  back: 'Back',
  ok: 'OK',
  close: 'Close',
  noDataFound: 'No Data Found',
  search: 'Search',
  select: 'Select',
  loading: 'Loading…',
};
