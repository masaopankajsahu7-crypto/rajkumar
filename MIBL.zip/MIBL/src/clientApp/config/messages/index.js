export { COMMON_MESSAGES } from './common.js';
export { CLIENT_LIST_MESSAGES, CLIENT_CREATE_MESSAGES } from './client.js';
export { CLIENT_DETAIL_MESSAGES } from './clientDetail.js';
export { CLIENT_APPROVAL_MESSAGES } from './clientApproval.js';
export { PORTFOLIO_MESSAGES } from './portfolio.js';
export { USER_MESSAGES } from './user.js';
export { AUTH_MESSAGES } from './auth.js';
