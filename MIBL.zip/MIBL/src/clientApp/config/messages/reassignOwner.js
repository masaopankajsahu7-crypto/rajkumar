export const REASSIGN_OWNER_MESSAGES = {
  title: 'Reassign Ownership',
  primaryOwnerLabel: 'Primary Account Owner *',
  coOwnerLabel: 'Co-Owners & Delegated Account Managers',
  coOwnerPlaceholder: 'Type to search co-owner',
  primaryOwnerPlaceholder: 'Search primary owner',
  reasonLabel: 'Reason for Ownership Shift *',
  reasonPlaceholder: 'Enter justification for compliance logs...',
  commit: 'Commit Assignment',
  committing: 'Committing...',
  cancel: 'Cancel',
  noCoOwners: 'No co-owner access assigned',
  ownerOptionsError: 'Unable to load owner list',
  reasonRequired: 'Reason for Ownership Shift is required',
  commitError: 'Ownership reassignment failed',
  info: {
    title: 'Understanding Account Ownership Mapping Importance',
    description:
      'In the Mahindra Insurance Brokers architecture, data visibility permissions depend heavily on assignments:',
    bullets: [
      'Primary Owner: Owns primary accountability for the client master profile. By default, this individual inherits primary visibility, budget allocation credit, and tracking updates across all nested client assets.',
      'Co-Owners: Authorized shared delegates who have collaborative edit permissions and quote tracking capabilities on the shared accounts.',
    ],
  },
  portfolioInfo: {
    title: 'Understanding Account Ownership Mapping Importance',
    description: 'Portfolio owners must be selected from the active client owner/co-owner set.',
    bullets: [],
  },
  warning: {
    title: 'Critical: Ownership Modification Warning',
    description:
      'Modifying the assigned Primary Owner changes downstream portfolio access settings. Active pipeline opportunities, unsubmitted RFQs, and client portfolio entries under review will automatically inherit the updated manager mapping.',
  },
};
