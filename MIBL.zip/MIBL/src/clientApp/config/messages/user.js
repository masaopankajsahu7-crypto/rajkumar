import { COMMON_MESSAGES } from './common.js';

export const USER_MESSAGES = {
  title: 'User Management',
  addTitle: 'Add User',
  addNewUser: 'Add New User',
  back: COMMON_MESSAGES.back,
  submit: 'Submit',
  page: 'Page',
  pageOf: (total) => `of ${total}`,
  previousPage: 'Previous page',
  nextPage: 'Next page',
  fetchingUser: 'Fetching user details...',
  fetchingRoles: 'Fetching roles...',
  loadingRoles: 'Loading roles...',

  labels: {
    sap: 'SAP',
    name: 'Name',
    email: 'Email',
    mobile: 'Mobile',
    reportingManager: 'Reporting Manager',
    alternateMobile: 'Alternate Mobile',
    department: 'Department',
    role: 'Roles',
  },

  placeholders: {
    sap: 'Enter SAP Code',
    name: 'Name',
    email: 'Email',
    mobile: 'Mobile',
    reportingManager: 'Reporting Manager',
    alternateMobile: 'Enter Alternate Mobile',
    selectDepartment: 'Select Department',
    selectRole: 'Select Role',
  },

  departments: {
    sales: 'Sales',
    placement: 'Placement',
  },

  errors: {
    sapRequired: 'SAP is required',
    sapInvalid: 'SAP must be 8 digits',
    nameRequired: 'Name is required',
    mobileRequired: 'Mobile is required',
    emailRequired: 'Email is required',
    reportingManagerRequired: 'Reporting Manager is required',
    departmentRequired: 'Department is required',
    roleRequired: 'Role is required',
    invalidMobile: 'Invalid mobile number',
  },

  ...COMMON_MESSAGES,
};
