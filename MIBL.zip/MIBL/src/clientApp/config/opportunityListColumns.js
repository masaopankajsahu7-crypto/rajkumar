/**
 * Opportunity list table column management.
 *
 * Only the columns listed here are rendered, in this exact order.
 */
export const OPPORTUNITY_LIST_COLUMNS = [
  { key: 'client_name', label: 'Client Name' },
  { key: 'client_vertical', label: 'Vertical' },
  { key: 'biz_type', label: 'Business Type' },
  { key: 'product', label: 'Product' },
  { key: 'sub_product', label: 'Sub Product' },
  { key: 'owner', label: 'Owner' },
  { key: 'placement_head', label: 'Placement RM' },
  { key: 'brokerage_fee', label: 'Brokerage' },
  { key: 'premium', label: 'Premium' },
  { key: 'renewal_date', label: 'Renewal Date' },
  { key: 'opportunity_status', label: 'Status' },
  { key: 'opportunity_stage', label: 'Stage' },
];

export const OPPORTUNITY_LIST_COLUMN_KEYS = OPPORTUNITY_LIST_COLUMNS.map((column) => column.key);

export const OPPORTUNITY_LIST_COLUMN_LABELS = Object.fromEntries(
  OPPORTUNITY_LIST_COLUMNS.map((column) => [column.key, column.label]),
);
