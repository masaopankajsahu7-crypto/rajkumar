const normalizeStatusKey = (value) =>
  String(value ?? '')
    .trim()
    .toLowerCase();

export const OPPORTUNITY_STATUS_TONE_BY_VALUE = {
  open: 'yellow',
  quoted: 'blue',
  'in progress': 'blue',
  'in process': 'blue',
  won: 'green',
  completed: 'green',
  lost: 'red',
};

export const OPPORTUNITY_STAGE_TONE_BY_VALUE = {
  opportunity: 'yellow',
  rfq_stage: 'blue',
  qcr_stage: 'blue',
  client_review: 'blue',
  policy_insurance: 'blue',
  policy_won: 'blue',
  completed: 'green',
  fresh: 'yellow',
  'in review': 'blue',
  'awaiting quote': 'yellow',
  closed: 'green',
};

export const getOpportunityStatusToneClass = (value) => {
  const tone = OPPORTUNITY_STATUS_TONE_BY_VALUE[normalizeStatusKey(value)] ?? 'default';
  return `opportunity-mgmt-status-badge--${tone}`;
};

export const getOpportunityStageToneClass = (value) => {
  const tone = OPPORTUNITY_STAGE_TONE_BY_VALUE[normalizeStatusKey(value)] ?? 'default';
  return `opportunity-mgmt-stage-text--${tone}`;
};
