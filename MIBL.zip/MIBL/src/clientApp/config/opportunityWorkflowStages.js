export const OPPORTUNITY_WORKFLOW_STAGES = [
  { code: 'OPPORTUNITY', label: 'Opportunity' },
  { code: 'ASSIGN_TO_PLACEMENT', label: 'Assign to Placement' },
  { code: 'RFQ_STAGE', label: 'RFQ' },
  { code: 'QCR_STAGE', label: 'QCR' },
  { code: 'CLIENT_REVIEW', label: 'Customer Review' },
  { code: 'INTERIM_REVIEW', label: '--' },
  { code: 'POLICY_WON', label: 'Policy Inbound' },
  { code: 'COMPLETED', label: 'Completed' },
];

export const OPPORTUNITY_STAGE_ALIASES = {
  COMPLETED: 'COMPLETED',
  'Opportunity Assignment Pending': 'OPPORTUNITY',
  'RFQ in Progress': 'RFQ_STAGE',
  'QCR in Progress': 'QCR_STAGE',
  'Client Review': 'CLIENT_REVIEW',
  'Opportunity Won': 'POLICY_WON',
  'Opportunity Process Completed': 'COMPLETED',
};
