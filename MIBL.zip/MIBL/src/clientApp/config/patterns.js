export const PATTERNS = {
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  MOBILE: /^[1-9]\d{9}$/,
  INDIAN_MOBILE: /^[6-9]\d{9}$/,
  PAN: /^[A-Z]{5}\d{4}[A-Z]$/,
  GSTIN: /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/,
  CIN: /^[UL][0-9]{5}[A-Z]{2}[0-9]{4}[A-Z]{3}[0-9]{6}$/,
  PINCODE: /^\d{6}$/,
  NAME: /^[A-Za-z\s.]+$/,
  NAME_TRIMMED: /^[A-Za-z\s.]+$/,
  DIGITS_ONLY: /^\d+$/,
  DECIMAL_2: /^\d+(\.\d{1,2})?$/,
  POLICY_NUMBER: /^[A-Z0-9-]+$/,
  SEARCH: /[^a-zA-Z0-9.@\s]/g,
};

export const PATTERN_STRIP = {
  NON_DIGIT: /\D/g,
  NON_ALPHANUMERIC: /[^a-zA-Z0-9]/g,
  NAME_CHARS: /[^a-zA-Z\s.]/g,
  EMAIL_SPACES: /\s/g,
  ADDRESS_CHARS: /[^a-zA-Z0-9\s.,#/\-]/g,
  CITY_STATE_CHARS: /[^a-zA-Z\s]/g,
  DECIMAL_CHARS: /[^\d.]/g,
  POLICY_NUMBER_CHARS: /[^a-zA-Z0-9-]/g,
  MULTIPLE_SPACES: /\s+/g,
};
