/** Dropdown options for portfolio form — wire from API when available */
export const PORTFOLIO_FORM_OPTIONS = {
  previousInsurers: [],
};
