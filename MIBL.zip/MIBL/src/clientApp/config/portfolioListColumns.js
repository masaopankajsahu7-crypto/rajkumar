export const PORTFOLIO_LIST_COLUMNS = [
  { key: 'clientName', label: 'Client Name' },
  { key: 'portfolio', label: 'Portfolio' },
  { key: 'clientVertical', label: 'Vertical' },
  { key: 'product', label: 'Product' },
  { key: 'subProduct', label: 'Sub Product' },
  { key: 'owner', label: 'Owner' },
  { key: 'activeOpps', label: 'Active Opps' },
  { key: 'totalOpps', label: 'Total Opps' },
];

export const PORTFOLIO_LIST_COLUMN_KEYS = PORTFOLIO_LIST_COLUMNS.map((column) => column.key);

export const PORTFOLIO_LIST_COLUMN_LABELS = Object.fromEntries(
  PORTFOLIO_LIST_COLUMNS.map((column) => [column.key, column.label]),
);
