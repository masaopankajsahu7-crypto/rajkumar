import { encryptRoute } from '../../services/encrypt';

export const encodedRoutePath = (path) =>
  `/${encodeURIComponent(encryptRoute(String(path ?? '').trim()))}`;

export const ROUTES = {
  login: '/',
  forgot: '/forgot',
  dashboard: '/dashboard',
  kpiDashboard: '/kpi-dashboard',
  userManagement: '/userManagement',
  userManagementCreate: '/userManagement/create',
  clients: '/clients',
  clientsCreate: '/clients/create',
  clientsEdit: '/clients/edit/:clientUUID',
  clientsCreatePortfolio: '/clients/create/portfolio',
  clientsDetail: '/clients/:clientUUID',
  opportunities: '/opportunities',
  portfolios: '/portfolios',
  renewals: '/renewals',
  activities: '/activities',
  activitiesCreate: '/activities/create',
  activitiesEdit: '/activities/edit/:activity_uuid',
  crm: '/crm',
  crmConvert: '/crm/convert/:migrationRowId',
  renewalConvert: '/renewals/convert/:renewalLeadUUID',
  reports: '/reports',
  opportunitiesCreate: '/opportunities/create',
  opportunityPortfolioContacts: '/opportunities/:opportunityUUID/portfolio/contacts',
  opportunityWorkflow: '/opportunities/:opportunityUUID',
};

export const clientsEditPath = (clientUUID) =>
  encodedRoutePath(`/clients/edit/${encodeURIComponent(String(clientUUID ?? '').trim())}`);

export const clientsDetailPath = (clientUUID) =>
  encodedRoutePath(`/clients/${encodeURIComponent(String(clientUUID ?? '').trim())}`);

export const opportunityWorkflowPath = (opportunityUUID) =>
  encodedRoutePath(`/opportunities/${encodeURIComponent(String(opportunityUUID ?? '').trim())}`);

export const renewalConvertPath = (renewalLeadUUID) =>
  encodedRoutePath(`/renewals/convert/${encodeURIComponent(String(renewalLeadUUID ?? '').trim())}`);

export const crmConvertPath = (migrationRowId) =>
  encodedRoutePath(`/crm/convert/${encodeURIComponent(String(migrationRowId ?? '').trim())}`);

export const activityEditPath = (activityUUID) =>
  encodedRoutePath(`/activities/edit/${encodeURIComponent(String(activityUUID ?? '').trim())}`);

export const opportunityPortfolioContactsPath = (opportunityUUID) =>
  encodedRoutePath(`/opportunities/${encodeURIComponent(String(opportunityUUID ?? '').trim())}/portfolio/contacts`);

export const NAV_ITEMS = [
  { label: 'User Management', path: ROUTES.userManagement },
  { label: 'Clients', path: ROUTES.clients },
  { label: 'Portfolios', path: ROUTES.portfolios },
  { label: 'Opportunities', path: ROUTES.opportunities },
  { label: 'Renewals', path: ROUTES.renewals },
  { label: 'Activities', path: ROUTES.activities },
  { label: 'CRM', path: ROUTES.crm },
  { label: 'Reports', path: ROUTES.reports },
];
