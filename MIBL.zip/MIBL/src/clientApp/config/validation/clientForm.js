import { SECTION_KEYS } from '../clientFormSteps.js';

/** Maps form sections to field keys and validation message keys */
export const CLIENT_FORM_VALIDATION = {
  sections: {
    [SECTION_KEYS.basic]: {
      required: ['client_name', 'client_type', 'vertical'],
      optionalFormat: {
        pan: 'pan',
        gstin: 'gstin',
        cin: 'cin',
      },
    },
    [SECTION_KEYS.contact]: {
      required: ['pincode', 'city', 'state', 'primary_contact_name', 'primary_mobile', 'primary_email'],
      optionalFormat: {
        address_line1: 'address',
        address_line2: 'address',
      },
      primaryFormat: {
        primary_contact_name: 'name',
        primary_mobile: 'mobile',
        primary_email: 'email',
      },
    },
    [SECTION_KEYS.portfolio]: {
      minCount: 1,
    },
  },

  errorKeys: {
    client_name: 'clientNameRequired',
    client_type: 'clientTypeRequired',
    vertical: 'verticalRequired',
    primary_contact_name: 'primaryContactNameRequired',
    pincode: 'pincodeRequired',
    city: 'cityRequired',
    state: 'stateRequired',
    comm_primary_mobile: 'primaryContactMobileRequired',
    comm_primary_email: 'primaryContactEmailRequired',
    portfolio: 'portfolioRequired',
  },

  fieldTypeMap: {
    primary_mobile: 'mobile',
    comm_primary_mobile: 'mobile',
    primary_email: 'email',
    comm_primary_email: 'email',
    pan: 'pan',
    gstin: 'gstin',
    cin: 'cin',
    pincode: 'pincode',
    primary_contact_name: 'name',
    city: 'cityState',
    state: 'cityState',
  },
};
