/** Portfolio form field validation config */
export const PORTFOLIO_FORM_VALIDATION = {
  required: [
    'product',
    'sub_product',
    'primary_contact_person',
    'primary_contact_mobile',
    'primary_contact_email',
    'expected_premium',
    'brokerage_consultancy',
    'renewal_date',
    'business_type',
  ],

  fieldTypes: {
    primary_contact_mobile: 'mobile',
    primary_contact_email: 'email',
    sum_insured: 'amount',
    expected_premium: 'amount',
    brokerage_consultancy: 'brokerage',
    previous_policy_number: 'policyNumber',
  },

  errorKeys: {
    product: 'productRequired',
    sub_product: 'subProductRequired',
    primary_contact_person: 'primaryContactPersonRequired',
    primary_contact_mobile: 'primaryContactMobileRequired',
    primary_contact_email: 'primaryContactEmailRequired',
    expected_premium: 'expectedPremiumRequired',
    brokerage_consultancy: 'brokerageConsultancyRequired',
    renewal_date: 'renewalDateRequired',
    business_type: 'businessTypeRequired',
    policy_start_date: 'policyStartDateRequired',
    policy_expiry_date: 'policyExpiryDateRequired',
    previous_insurer: 'previousInsurerRequired',
    previous_policy_number: 'previousPolicyNumberRequired',
  },

  formatErrorKeys: {
    mobile: 'invalidMobile',
    email: 'invalidEmail',
    amount: 'invalidAmount',
    brokerage: 'invalidBrokerage',
    policyNumber: 'invalidPolicyNumber',
  },
};
