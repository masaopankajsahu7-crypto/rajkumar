/** User management form validation config */
export const USER_FORM_VALIDATION = {
  required: ['sap', 'name', 'mobile', 'email', 'reportingManager', 'department', 'role'],

  fieldTypes: {
    sap: 'sap',
    altMobile: 'mobile',
  },

  optionalFormat: {
    altMobile: 'mobile',
  },

  errorKeys: {
    sap: 'sapRequired',
    name: 'nameRequired',
    mobile: 'mobileRequired',
    email: 'emailRequired',
    reportingManager: 'reportingManagerRequired',
    department: 'departmentRequired',
    role: 'roleRequired',
    altMobile: 'invalidMobile',
  },

  departments: [
    { value: 'sales', labelKey: 'sales' },
    { value: 'placement', labelKey: 'placement' },
  ],
};
