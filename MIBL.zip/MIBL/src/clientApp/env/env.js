export const baseUrl = '/CRM/api/v1';
// export const baseUrl = 'http://10.56.245.35:8080/api/v1';
// export const baseUrl = 'https://umspcm.mahindrainsure.com/CRM/api/v1';
// export const baseUrl = 'https://mysaathi.mahindrainsure.com/CRM/api/v1';

/**
 * Client APIs are routed through app-service in deployed and local proxy flows.
 */
export const clientServiceBaseUrl = '/app-service';
export const encryptedClientServiceBaseUrl = '/app-service-v2';

/**
 * Master/KDS APIs are routed through app-service in deployed and local proxy flows.
 */
export const masterServiceBaseUrl = '/app-service';
export const encryptedMasterServiceBaseUrl = '/app-service-v2';

/**
 * App Service owns opportunity workflow APIs.
 * Relative path keeps local/UAT deployments on the current host.
 */
export const appServiceBaseUrl = '/app-service';
export const encryptedAppServiceBaseUrl = '/app-service-v2';
