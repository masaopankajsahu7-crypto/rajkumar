import { keepPreviousData, useQuery } from '@tanstack/react-query';
import {
  fetchRole,
  fetchUserBySap,
  getClientByUuid,
  getClientOpportunities,
  getClientActivities,
  getCrmMigrationList,
  getClientPortfolios,
  getOpportunityPortfoliosByClient,
  getClients,
  getKdsOptions,
  getOpportunities,
  getPortfolios,
  getReports,
  getRenewalLeads,
  getOpportunityActivityLogs,
  getOpportunityDashboardSection,
  getOpportunityKdsOptions,
  getOpportunityWorkflowStageOptions,
  getOpportunityWorkflowHierarchy,
  getOpportunityWorkflowRecords,
  getUserDetails,
  searchClientsByName,
} from '../services/api.jsx';
import { queryKeys } from '../lib/queryKeys';

export function useUserList(offset) {
  return useQuery({
    queryKey: queryKeys.users(offset),
    queryFn: () => getUserDetails({ offset }),
    enabled: Number(offset) >= 1,
    placeholderData: keepPreviousData,
  });
}

import { INITIAL_CLIENT_FILTERS, normalizeClientListFilters } from '../utils/clientListFilters.js';
import { INITIAL_OPPORTUNITY_FILTERS, normalizeOpportunityListFilters } from '../utils/opportunityListFilters.js';
import { INITIAL_PORTFOLIO_FILTERS, normalizePortfolioListFilters } from '../utils/portfolioListFilters.js';
import { INITIAL_RENEWAL_LEAD_FILTERS, normalizeRenewalLeadFilters } from '../utils/renewalLeadList.js';

export function useClientList(page = 1, filters = INITIAL_CLIENT_FILTERS) {
  const normalizedFilters = normalizeClientListFilters(filters);

  return useQuery({
    queryKey: queryKeys.clients(page, normalizedFilters),
    queryFn: () => getClients({ page, filters: normalizedFilters }),
    placeholderData: keepPreviousData,
  });
}

export function useClientActivities(page = 1, filters = {}) {
  return useQuery({
    queryKey: queryKeys.clientActivities(page, filters),
    queryFn: () => getClientActivities({ page, filters }),
    placeholderData: keepPreviousData,
  });
}

export function useCrmMigrationList(page = 1, search = '') {
  return useQuery({
    queryKey: queryKeys.crmMigration(page, search),
    queryFn: () => getCrmMigrationList({ page, search }),
    placeholderData: keepPreviousData,
  });
}

export function useOpportunityList(page = 1, filters = INITIAL_OPPORTUNITY_FILTERS) {
  const normalizedFilters = normalizeOpportunityListFilters(filters);

  return useQuery({
    queryKey: queryKeys.opportunities(page, normalizedFilters),
    queryFn: () => getOpportunities({ page, filters: normalizedFilters }),
    placeholderData: keepPreviousData,
  });
}

export function usePortfolioList(page = 1, filters = INITIAL_PORTFOLIO_FILTERS) {
  const normalizedFilters = normalizePortfolioListFilters(filters);

  return useQuery({
    queryKey: queryKeys.portfolios(page, normalizedFilters),
    queryFn: () => getPortfolios({ page, filters: normalizedFilters }),
    placeholderData: keepPreviousData,
  });
}

export function useReportList(page = 1, search = '', filters = {}) {
  return useQuery({
    queryKey: queryKeys.reports(page, { ...filters, search }),
    queryFn: () => getReports({ page, search, filters }),
    placeholderData: keepPreviousData,
  });
}

export function useRenewalLeadList(page = 1, filters = INITIAL_RENEWAL_LEAD_FILTERS, pageSize) {
  const normalizedFilters = normalizeRenewalLeadFilters(filters);

  return useQuery({
    queryKey: queryKeys.renewalLeads(page, normalizedFilters, pageSize),
    queryFn: () => getRenewalLeads({ page, filters: normalizedFilters, pageSize }),
    placeholderData: keepPreviousData,
  });
}

export function useOpportunityWorkflowHierarchy(opportunityUUID) {
  return useQuery({
    queryKey: queryKeys.opportunityWorkflowHierarchy(opportunityUUID),
    queryFn: () => getOpportunityWorkflowHierarchy(opportunityUUID),
    enabled: Boolean(opportunityUUID),
  });
}

export function useOpportunityWorkflowRecords(opportunityUUID) {
  return useQuery({
    queryKey: queryKeys.opportunityWorkflowRecords(opportunityUUID),
    queryFn: () => getOpportunityWorkflowRecords(opportunityUUID),
    enabled: Boolean(opportunityUUID),
  });
}

export function useOpportunityWorkflowStages() {
  return useQuery({
    queryKey: queryKeys.opportunityWorkflowStages(),
    queryFn: getOpportunityWorkflowStageOptions,
    staleTime: Infinity,
  });
}

export function useOpportunityActivityLogs(opportunityUUID, { enabled = true } = {}) {
  return useQuery({
    queryKey: queryKeys.opportunityActivityLogs(opportunityUUID),
    queryFn: () => getOpportunityActivityLogs(opportunityUUID),
    enabled: Boolean(enabled && opportunityUUID),
  });
}

export function useOpportunityDashboardSection(dashboardName, filters = {}) {
  return useQuery({
    queryKey: queryKeys.opportunityDashboard(dashboardName, filters),
    queryFn: () => getOpportunityDashboardSection({
      dashboardName,
      fromDate: filters.fromDate,
      toDate: filters.toDate,
    }),
    enabled: Boolean(dashboardName),
    placeholderData: keepPreviousData,
  });
}

export function useClientByUuid(clientUUID) {
  return useQuery({
    queryKey: queryKeys.client(clientUUID),
    queryFn: () => getClientByUuid(clientUUID),
    enabled: Boolean(clientUUID),
  });
}

export function useClientPortfolios(clientUUID, { enabled = true } = {}) {
  return useQuery({
    queryKey: queryKeys.clientPortfolios(clientUUID),
    queryFn: () => getClientPortfolios(clientUUID),
    enabled: Boolean(enabled && clientUUID),
  });
}

export function usePortfolioListByClient(clientUUID, { enabled = true } = {}) {
  return useQuery({
    queryKey: queryKeys.clientPortfolioList(clientUUID),
    queryFn: () => getOpportunityPortfoliosByClient(clientUUID),
    enabled: Boolean(enabled && clientUUID),
  });
}

export function useClientOpportunities(clientUUID) {
  return useQuery({
    queryKey: queryKeys.clientOpportunities(clientUUID),
    queryFn: () => getClientOpportunities(clientUUID),
    enabled: Boolean(clientUUID),
  });
}

/**
 * Fetch a single dropdown's options from the master-service.
 * Master data rarely changes within a session, so we cache it aggressively.
 * `parentCode` is threaded through for future dependent (hierarchical) dropdowns.
 */
export function useKdsOptions({ module = 'client', source, name, parentCode = '', enabled = true }) {
  return useQuery({
    queryKey: queryKeys.kdsOptions(module, source, name, parentCode),
    queryFn: () => getKdsOptions({ module, source, name, parentCode }),
    enabled: Boolean(enabled && source && name),
    staleTime: Infinity,
  });
}

export function useOpportunityKdsOptions({ module = 'opportunity', source, name, parentCode = '', enabled = true }) {
  return useQuery({
    queryKey: queryKeys.kdsOptions(module, source, name, parentCode),
    queryFn: () => getOpportunityKdsOptions({ module, source, name, parentCode }),
    enabled: Boolean(enabled && source && name),
    staleTime: Infinity,
  });
}

export function useSimilarClients(clientName, { enabled = true, clientUUID = '', source = 'approval' } = {}) {
  const name = String(clientName ?? '').trim();
  return useQuery({
    queryKey: [...queryKeys.similarClients(name), source, clientUUID],
    queryFn: () => searchClientsByName(name, { source, clientUUID }),
    enabled: Boolean(enabled && name.length > 0),
  });
}

export function useUserBySap(sapCode) {
  const normalizedSap = String(sapCode ?? '').replace(/\D/g, '');

  return useQuery({
    queryKey: queryKeys.userBySap(normalizedSap),
    queryFn: () => fetchUserBySap(normalizedSap),
    enabled: normalizedSap.length === 8,
  });
}

export function useRolesByDepartment(department) {
  return useQuery({
    queryKey: queryKeys.roles(department),
    queryFn: () => fetchRole(department),
    enabled: Boolean(department),
    select: (response) => {
      const list = response?.roles ?? response?.roleList ?? [];
      return Array.isArray(list) ? list : [];
    },
  });
}
