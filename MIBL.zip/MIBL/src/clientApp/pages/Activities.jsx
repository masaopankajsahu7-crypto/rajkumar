import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  FormControl,
  IconButton,
  InputAdornment,
  MenuItem,
  Select,
  TextField,
  Typography,
} from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import ArrowBackIosNewRoundedIcon from '@mui/icons-material/ArrowBackIosNewRounded';
import ArrowForwardIosRoundedIcon from '@mui/icons-material/ArrowForwardIosRounded';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import CheckCircleOutlineRoundedIcon from '@mui/icons-material/CheckCircleOutlineRounded';
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import ErrorOutlineRoundedIcon from '@mui/icons-material/ErrorOutlineRounded';
import EventAvailableRoundedIcon from '@mui/icons-material/EventAvailableRounded';
import FilterListRoundedIcon from '@mui/icons-material/FilterListRounded';
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined';
import ListAltRoundedIcon from '@mui/icons-material/ListAltRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import SearchIcon from '@mui/icons-material/Search';
import VideocamOutlinedIcon from '@mui/icons-material/VideocamOutlined';
import { ACTIVITY_KDS_FIELDS } from '../config/kdsFields.js';
import { activityEditPath, encodedRoutePath, ROUTES } from '../config/routes.js';
import { useClientActivities, useKdsOptions } from '../hooks/useFetchQueries.js';
import { getActivityBucket } from '../utils/clientActivities.js';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import './Clients.css';
import './Activities.css';

const VIEW_TABS = [
  { code: 'open', label: 'Open' },
  { code: 'breached', label: 'Breached' },
  { code: 'today', label: 'Today' },
  { code: 'upcoming', label: 'Upcoming' },
  { code: 'done', label: 'Completed' },
  { code: 'all', label: 'All' },
];

const GROUPS = {
  breached: { title: 'Breached', tone: 'breached', description: 'Past the scheduled time. Update or reschedule.' },
  today: { title: 'Today', tone: 'today', description: 'Your remaining conversations for today.' },
  upcoming: { title: 'Upcoming', tone: 'upcoming', description: 'Scheduled for the days ahead.' },
  done: { title: 'Completed & Closed', tone: 'done', description: 'Meeting outcomes already recorded.' },
  inactive: { title: 'Inactive', tone: 'inactive', description: 'Not included in your open to-do list.' },
};

const FALLBACK_ACTIVITY_TYPES = ['Policy Review', 'Client Meeting', 'Renewal Discussion', 'Follow Up', 'Document Collection'];
const FALLBACK_MEETING_MODES = ['Online', 'In Person', 'Phone Call', 'Email'];
const FALLBACK_MEETING_STATUSES = ['Completed', 'Closed', 'Rescheduled'];
const FALLBACK_CLIENT_INTERESTS = ['Yes, Interested', 'No, Not Interested', 'Maybe / Follow Up Required'];

const formatDate = (date) => {
  if (!date) return '-';
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

const formatTime = (date) => {
  if (!date) return '';
  return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
};

const startOfWeek = (value) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() - ((date.getDay() + 6) % 7));
  return date;
};

const addDays = (value, days) => {
  const date = new Date(value);
  date.setDate(date.getDate() + days);
  return date;
};

const toDateKey = (value) => {
  if (!value) return '';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, '0'),
    String(date.getDate()).padStart(2, '0'),
  ].join('-');
};

const toTimeValue = (value) => {
  if (!value) return '';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return [String(date.getHours()).padStart(2, '0'), String(date.getMinutes()).padStart(2, '0')].join(':');
};

const getDefaultSchedule = () => {
  const next = new Date();
  next.setHours(next.getHours() + 1, 0, 0, 0);
  return next;
};

const getActivityFormState = (activity = null) => {
  const scheduledAt = activity?.scheduledAt ?? getDefaultSchedule();
  return {
    clientName: activity?.clientName ?? '',
    clientUUID: activity?.clientUUID ?? '',
    portfolioName: activity?.portfolioName ?? '',
    activityName: activity?.title ?? '',
    activityType: activity?.type ?? '',
    meetingMode: activity?.mode ?? '',
    scheduleDate: toDateKey(scheduledAt),
    scheduleTime: toTimeValue(scheduledAt),
    jointUsers: activity?.jointUsers?.map((user) => user.name).filter(Boolean) ?? [],
    clientInterest: activity?.clientInterest && activity.clientInterest !== 'Not Recorded' ? activity.clientInterest : '',
    meetingStatus: activity?.meetingStatus ?? '',
    remarks: activity?.remarks ?? '',
    newScheduleDate: '',
    newScheduleTime: '',
  };
};

const getRelativeLabel = (activity, bucket) => {
  if (bucket === 'done') return 'Outcome recorded';
  if (bucket === 'inactive') return 'Inactive activity';
  if (activity.schedule) return bucket === 'breached' ? activity.schedule : `In ${activity.schedule}`;
  return bucket === 'today' ? 'Due today' : 'Scheduled';
};

const StatusBadge = ({ status }) => {
  const key = String(status ?? '').toLowerCase().replace(/\s+/g, '-');
  return <span className={`activity-status-badge activity-status-badge--${key || 'default'}`}>{status || '-'}</span>;
};

const getOptionList = (kdsOptions = [], fallback = []) => {
  if (kdsOptions.length) return kdsOptions;
  return fallback.map((value) => ({ code: value, value }));
};

const findOptionCode = (options, labelOrCode) => {
  const normalized = String(labelOrCode ?? '').trim().toLowerCase();
  if (!normalized) return '';
  return options.find((option) =>
    String(option.code ?? '').trim().toLowerCase() === normalized ||
    String(option.value ?? '').trim().toLowerCase() === normalized
  )?.code ?? labelOrCode;
};

const getOptionLabel = (options, codeOrLabel) => {
  const normalized = String(codeOrLabel ?? '').trim().toLowerCase();
  return options.find((option) =>
    String(option.code ?? '').trim().toLowerCase() === normalized ||
    String(option.value ?? '').trim().toLowerCase() === normalized
  )?.value ?? codeOrLabel;
};

const isActivityClosed = (activity = {}) => {
  const status = `${activity.meetingStatus ?? ''} ${activity.currentStatus ?? ''} ${activity.currentStatusCode ?? ''}`.toLowerCase();
  return status.includes('completed') || status.includes('closed');
};

const SummaryCard = ({ tone, icon: Icon, value, label, active, onClick }) => (
  <button
    type="button"
    className={`activity-summary-card activity-summary-card--${tone}`}
    aria-pressed={active}
    onClick={onClick}
  >
    <span className="activity-summary-icon">{Icon ? <Icon fontSize="small" /> : null}</span>
    <span>
      <strong>{value}</strong>
      <span>{label}</span>
    </span>
  </button>
);

const ActivityRow = ({ activity, onOpen }) => {
  const bucket = getActivityBucket(activity.raw);
  const jointNames = activity.jointUsers.map((user) => user.name).filter(Boolean).join(', ');
  return (
    <article className={`activity-row-card activity-row-card--${bucket}`}>
      <span className={`activity-row-check ${bucket === 'done' ? 'activity-row-check--done' : ''}`}>
        <CheckCircleOutlineRoundedIcon fontSize="small" />
      </span>
      <Box className="activity-row-main">
        <Box className="activity-client-line">
          <Typography component="strong">{activity.clientName || 'Client'}</Typography>
          <span>{activity.activityCode || activity.id} · {activity.portfolioName}</span>
        </Box>
        <Typography className="activity-row-title">{activity.title || 'Client activity'}</Typography>
        <Box className="activity-row-meta">
          <span><EventAvailableRoundedIcon fontSize="inherit" />{activity.type || 'Activity'}</span>
          <span><VideocamOutlinedIcon fontSize="inherit" />{activity.mode || 'Meeting'}</span>
          <span><GroupOutlinedIcon fontSize="inherit" />{jointNames ? `Joint: ${jointNames}` : 'Individual activity'}</span>
          {activity.rescheduleCount ? <span><RefreshRoundedIcon fontSize="inherit" />Rescheduled {activity.rescheduleCount}x</span> : null}
        </Box>
        {bucket === 'done' && activity.remarks ? (
          <Typography className="activity-row-comments">
            <strong>Comments:</strong> {activity.remarks}
          </Typography>
        ) : null}
      </Box>
      <Box className="activity-row-schedule">
        <span className="activity-row-date">{formatDate(activity.scheduledAt)}</span>
        <span>{formatTime(activity.scheduledAt)}</span>
        <em>{getRelativeLabel(activity, bucket)}</em>
      </Box>
      <Box className="activity-row-status">
        <StatusBadge status={activity.meetingStatus || activity.currentStatus} />
        {!activity.isCurrent ? <span className="activity-history-badge">Historical</span> : null}
        {activity.clientInterest && activity.clientInterest !== 'Not Recorded' ? <small>{activity.clientInterest}</small> : null}
      </Box>
      {isActivityClosed(activity) ? null : (
        <Button className="activity-row-action" aria-label="View activity" onClick={() => onOpen(activity)}>
          <ChevronRightRoundedIcon fontSize="small" />
        </Button>
      )}
    </article>
  );
};

const Activities = () => {
  const navigate = useNavigate();
  const [view, setView] = useState('open');
  const [layout, setLayout] = useState('list');
  const [calendarAnchor, setCalendarAnchor] = useState(() => startOfWeek(new Date()));
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({ search: '', client: '', type: '', mode: '', joint: '' });
  const [activityDialog, setActivityDialog] = useState({ open: false, mode: 'create', activity: null });
  const [activityForm, setActivityForm] = useState(() => getActivityFormState());
  const [activityFormError, setActivityFormError] = useState('');
  const [jointSearch, setJointSearch] = useState('');
  const [jointMenuOpen, setJointMenuOpen] = useState(false);
  const { data: activityTypeKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.activityType);
  const { data: meetingModeKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.meetingMode);
  const { data: meetingStatusKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.meetingStatus);
  const { data: clientInterestKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.clientInterest);
  const query = useClientActivities(1, { search: filters.search });
  const isActivitiesLoading = query.isLoading || query.isFetching;
  const activities = query.data?.list ?? [];
  const activityTypeOptions = useMemo(() => getOptionList(activityTypeKdsOptions, FALLBACK_ACTIVITY_TYPES), [activityTypeKdsOptions]);
  const meetingModeOptions = useMemo(() => getOptionList(meetingModeKdsOptions, FALLBACK_MEETING_MODES), [meetingModeKdsOptions]);
  const meetingStatusOptions = useMemo(() => getOptionList(meetingStatusKdsOptions, FALLBACK_MEETING_STATUSES), [meetingStatusKdsOptions]);
  const clientInterestOptions = useMemo(() => getOptionList(clientInterestKdsOptions, FALLBACK_CLIENT_INTERESTS), [clientInterestKdsOptions]);

  const options = useMemo(() => ({
    clients: [...new Set(activities.map((item) => item.clientName).filter(Boolean))],
    types: [...new Set(activities.map((item) => item.type).filter(Boolean))],
    modes: [...new Set(activities.map((item) => item.mode).filter(Boolean))],
  }), [activities]);
  const jointUserOptions = useMemo(() => {
    const map = new Map();
    activities.forEach((activity) => {
      activity.participants.forEach((participant) => {
        const name = String(participant?.name ?? '').trim();
        if (!name) return;
        const id = String(participant?.user_id ?? participant?.userid ?? participant?.id ?? name).trim();
        map.set(id || name, {
          id: id || name,
          name,
          email: participant?.email ?? '',
          role: participant?.participant_role_code === 'ORGANIZER' ? 'Organizer' : 'Joint user',
        });
      });
    });
    ['Sandeep Shar', 'Pankaj Shau', 'Raj Kumar', 'Amit'].forEach((name, index) => {
      if (![...map.values()].some((user) => user.name === name)) {
        map.set(`sample-${index}`, { id: `sample-${index}`, name, email: '', role: 'Joint user' });
      }
    });
    return [...map.values()];
  }, [activities]);
  const filteredJointUserOptions = useMemo(() => {
    const search = jointSearch.trim().toLowerCase();
    return jointUserOptions.filter((user) => {
      if (activityForm.jointUsers.includes(user.name)) return false;
      if (!search) return true;
      return `${user.name} ${user.email}`.toLowerCase().includes(search);
    });
  }, [activityForm.jointUsers, jointSearch, jointUserOptions]);

  const counts = useMemo(() => {
    const next = { breached: 0, today: 0, upcoming: 0, done: 0, inactive: 0, all: activities.length };
    activities.forEach((activity) => {
      next[getActivityBucket(activity.raw)] += 1;
    });
    next.open = next.breached + next.today + next.upcoming;
    return next;
  }, [activities]);

  const filteredActivities = useMemo(() => {
    const search = filters.search.trim().toLowerCase();
    return activities.filter((activity) => {
      const bucket = getActivityBucket(activity.raw);
      if (view === 'open' && !['breached', 'today', 'upcoming'].includes(bucket)) return false;
      if (!['open', 'all'].includes(view) && bucket !== view) return false;
      if (filters.client && activity.clientName !== filters.client) return false;
      if (filters.type && activity.type !== filters.type) return false;
      if (filters.mode && activity.mode !== filters.mode) return false;
      if (filters.joint === 'joint' && activity.jointUsers.length === 0) return false;
      if (filters.joint === 'individual' && activity.jointUsers.length > 0) return false;
      if (!search) return true;
      return [
        activity.clientName,
        activity.activityCode,
        activity.title,
        activity.type,
        activity.mode,
        activity.createdByName,
      ].some((value) => String(value ?? '').toLowerCase().includes(search));
    });
  }, [activities, filters, view]);

  const grouped = useMemo(() => {
    const next = { breached: [], today: [], upcoming: [], done: [], inactive: [] };
    filteredActivities.forEach((activity) => {
      next[getActivityBucket(activity.raw)].push(activity);
    });
    Object.values(next).forEach((rows) => rows.sort((a, b) => (a.scheduledAt?.getTime() ?? 0) - (b.scheduledAt?.getTime() ?? 0)));
    return next;
  }, [filteredActivities]);

  const calendarDays = useMemo(() => {
    const todayKey = toDateKey(new Date());
    return Array.from({ length: 7 }, (_, index) => {
      const date = addDays(calendarAnchor, index);
      const key = toDateKey(date);
      const rows = filteredActivities
        .filter((activity) => toDateKey(activity.scheduledAt) === key)
        .sort((a, b) => (a.scheduledAt?.getTime() ?? 0) - (b.scheduledAt?.getTime() ?? 0));
      return {
        date,
        key,
        isToday: key === todayKey,
        isWeekend: [0, 6].includes(date.getDay()),
        rows,
      };
    });
  }, [calendarAnchor, filteredActivities]);

  const handleFilter = (field) => (event) => setFilters((current) => ({ ...current, [field]: event.target.value }));
  const clearFilters = () => setFilters({ search: '', client: '', type: '', mode: '', joint: '' });
  const handleSummaryClick = (nextView) => {
    setView(nextView);
    setLayout('list');
  };
  const openCreateActivity = () => {
    navigate(encodedRoutePath(ROUTES.activitiesCreate));
  };
  const openUpdateActivity = (activity) => {
    if (isActivityClosed(activity)) return;
    navigate(activityEditPath(activity.activityUUID || activity.activity_uuid || activity.id), { state: { activity } });
  };
  const closeActivityDialog = () => {
    setActivityDialog((current) => ({ ...current, open: false }));
    setActivityFormError('');
  };
  const handleActivityFormChange = (field) => (event) => {
    setActivityForm((current) => ({ ...current, [field]: event.target.value }));
  };
  const handleAddJointUser = (user) => {
    setActivityForm((current) => ({
      ...current,
      jointUsers: current.jointUsers.includes(user.name) ? current.jointUsers : [...current.jointUsers, user.name],
    }));
    setJointSearch('');
  };
  const handleRemoveJointUser = (name) => {
    setActivityForm((current) => ({
      ...current,
      jointUsers: current.jointUsers.filter((item) => item !== name),
    }));
  };
  const handleActivityFormSubmit = (event) => {
    event.preventDefault();
    const requiredFields = ['clientName', 'portfolioName', 'activityName', 'activityType', 'meetingMode', 'scheduleDate', 'scheduleTime'];
    const missingBaseField = requiredFields.some((field) => !String(activityForm[field] ?? '').trim());
    if (missingBaseField) {
      setActivityFormError('Complete all mandatory Client & Activity fields.');
      return;
    }
    if (activityDialog.mode === 'update') {
      const missingOutcome = ['clientInterest', 'meetingStatus', 'remarks'].some((field) => !String(activityForm[field] ?? '').trim());
      if (missingOutcome) {
        setActivityFormError('Complete all mandatory Meeting Outcome fields.');
        return;
      }
      if (activityForm.meetingStatus === 'Rescheduled' && (!activityForm.newScheduleDate || !activityForm.newScheduleTime)) {
        setActivityFormError('Select the new schedule date and time.');
        return;
      }
    }
    closeActivityDialog();
  };
  const isUpdateMode = activityDialog.mode === 'update';
  const selectedActivity = activityDialog.activity;

  return (
    <Box className="activity-mgmt-page client-mgmt-page">
      <BackdropLoader loading={isActivitiesLoading} />
      <Box className="activity-page-head">
        <Box className="client-mgmt-page-title-wrap">
          <Typography className="client-mgmt-title">Client Activities</Typography>
          <Typography className="activity-page-subtitle">Plan your next conversation. Keep every follow-up on track.</Typography>
        </Box>
        <Box className="activity-page-actions">
          <span className="activity-layout-switch" role="group" aria-label="Activity view">
            <button type="button" aria-pressed={layout === 'list'} onClick={() => setLayout('list')}>
              <ListAltRoundedIcon fontSize="small" /> List
            </button>
            <button type="button" aria-pressed={layout === 'calendar'} onClick={() => setLayout('calendar')}>
              <CalendarMonthOutlinedIcon fontSize="small" /> Calendar
            </button>
          </span>
          <Button className="activity-add-btn" startIcon={<AddRoundedIcon />} onClick={openCreateActivity}>New Activity</Button>
        </Box>
      </Box>

      <Box className="activity-summary-grid">
        <SummaryCard tone="breached" icon={ErrorOutlineRoundedIcon} value={counts.breached} label="Breached" active={view === 'breached'} onClick={() => handleSummaryClick('breached')} />
        <SummaryCard tone="today" icon={EventAvailableRoundedIcon} value={counts.today} label="Today" active={view === 'today'} onClick={() => handleSummaryClick('today')} />
        <SummaryCard tone="upcoming" icon={CalendarMonthOutlinedIcon} value={counts.upcoming} label="Upcoming" active={view === 'upcoming'} onClick={() => handleSummaryClick('upcoming')} />
        <SummaryCard tone="done" icon={CheckCircleOutlineRoundedIcon} value={counts.done} label="Completed" active={view === 'done'} onClick={() => handleSummaryClick('done')} />
      </Box>

      <Box className="activity-list-panel">
        {layout === 'list' ? (
          <>
            <Box className="activity-toolbar">
              <Box className="activity-view-tabs">
                {VIEW_TABS.map((tab) => (
                  <button key={tab.code} type="button" className="activity-tab" aria-pressed={view === tab.code} onClick={() => setView(tab.code)}>
                    {tab.label}<span>{counts[tab.code] ?? 0}</span>
                  </button>
                ))}
              </Box>
              <Box className="activity-toolbar-actions">
                <TextField
                  className="activity-search"
                  size="small"
                  placeholder="Search activities..."
                  value={filters.search}
                  onChange={handleFilter('search')}
                  InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
                />
                <Button className="client-mgmt-filter-toggle-btn" onClick={() => setShowFilters((open) => !open)} startIcon={<FilterListRoundedIcon />}>
                  Filters
                </Button>
              </Box>
            </Box>

            {showFilters ? (
              <Box className="activity-filters">
                <FormControl size="small"><Select displayEmpty value={filters.client} onChange={handleFilter('client')}><MenuItem value="">All clients</MenuItem>{options.clients.map((item) => <MenuItem key={item} value={item}>{item}</MenuItem>)}</Select></FormControl>
                <FormControl size="small"><Select displayEmpty value={filters.type} onChange={handleFilter('type')}><MenuItem value="">All activity types</MenuItem>{options.types.map((item) => <MenuItem key={item} value={item}>{item}</MenuItem>)}</Select></FormControl>
                <FormControl size="small"><Select displayEmpty value={filters.mode} onChange={handleFilter('mode')}><MenuItem value="">All meeting modes</MenuItem>{options.modes.map((item) => <MenuItem key={item} value={item}>{item}</MenuItem>)}</Select></FormControl>
                <FormControl size="small"><Select displayEmpty value={filters.joint} onChange={handleFilter('joint')}><MenuItem value="">Joint / Individual</MenuItem><MenuItem value="joint">Joint activities</MenuItem><MenuItem value="individual">Individual activities</MenuItem></Select></FormControl>
                <Button className="activity-clear-btn" onClick={clearFilters}>Clear</Button>
              </Box>
            ) : null}

            {Object.entries(GROUPS).map(([groupKey, group]) => {
              const rows = grouped[groupKey] ?? [];
              if (!rows.length) return null;
              return (
                <section key={groupKey} className={`activity-group activity-group--${group.tone}`}>
                  <Box className="activity-group-head">
                    <span />
                    <Typography>{group.title}</Typography>
                    <strong>{rows.length}</strong>
                    <em>{group.description}</em>
                  </Box>
                  {rows.map((activity) => <ActivityRow key={activity.id} activity={activity} onOpen={openUpdateActivity} />)}
                </section>
              );
            })}
          </>
        ) : (
          <Box className="activity-calendar-panel">
            <Box className="activity-calendar-toolbar">
              <Box>
                <Typography>Weekly Calendar</Typography>
                <span>{formatDate(calendarDays[0]?.date)} - {formatDate(calendarDays[6]?.date)}</span>
              </Box>
              <Box className="activity-calendar-nav">
                <Button onClick={() => setCalendarAnchor((current) => addDays(current, -7))} aria-label="Previous week">
                  <ArrowBackIosNewRoundedIcon fontSize="small" />
                </Button>
                <Button onClick={() => setCalendarAnchor((current) => addDays(current, 7))} aria-label="Next week">
                  <ArrowForwardIosRoundedIcon fontSize="small" />
                </Button>
              </Box>
            </Box>
            <Box className="activity-calendar-scroll">
              <Box className="activity-week-grid">
                {calendarDays.map((day) => (
                  <section
                    key={day.key}
                    className={`activity-day-column ${day.isWeekend ? 'activity-day-column--weekend' : ''} ${day.isToday ? 'activity-day-column--today' : ''}`}
                  >
                    <Box className="activity-day-head">
                      <Box>
                        <span>{day.date.toLocaleDateString('en-GB', { weekday: 'short' })}</span>
                        <strong>{day.date.getDate()}</strong>
                      </Box>
                      <em>{day.rows.length || ''}</em>
                    </Box>
                    <Box className="activity-day-events">
                      {day.rows.length ? day.rows.map((activity) => {
                        const bucket = getActivityBucket(activity.raw);
                        return (
                          <button key={activity.id} type="button" className={`activity-calendar-event activity-calendar-event--${bucket}`} onClick={() => openUpdateActivity(activity)} disabled={isActivityClosed(activity)}>
                            <span className="activity-calendar-event-time">
                              {formatTime(activity.scheduledAt)}
                              <em>{activity.activityCode}</em>
                            </span>
                            <strong>{activity.clientName || 'Client'}</strong>
                            <span>{activity.title || 'Client activity'}</span>
                            <StatusBadge status={activity.meetingStatus || activity.currentStatus} />
                          </button>
                        );
                      }) : <span className="activity-day-empty">No activities</span>}
                    </Box>
                  </section>
                ))}
              </Box>
            </Box>
          </Box>
        )}

        {!isActivitiesLoading && !filteredActivities.length ? (
          <Box className="activity-empty">
            <EventAvailableRoundedIcon />
            <Typography>{query.isError ? 'Unable to load activities' : 'No activities in this view'}</Typography>
            <span>{query.isError ? query.error?.message || 'Please try again.' : 'Try another search or clear filters.'}</span>
          </Box>
        ) : null}
      </Box>

      <Dialog
        open={activityDialog.open}
        onClose={closeActivityDialog}
        maxWidth="md"
        fullWidth
        className="activity-form-dialog"
        PaperProps={{ className: 'activity-form-dialog-paper' }}
      >
        <DialogTitle className="activity-form-dialog-title">
          <Box>
            <Typography component="h2">{isUpdateMode ? 'Update Activity' : 'Create Activity'}</Typography>
            <span>{isUpdateMode ? 'Record the meeting outcome or reschedule the activity.' : 'Schedule a client interaction and add joint-call users.'}</span>
          </Box>
          <IconButton className="activity-form-close" onClick={closeActivityDialog} aria-label="Close activity form">
            <CloseRoundedIcon fontSize="small" />
          </IconButton>
        </DialogTitle>
        <DialogContent className="activity-form-dialog-content">
          {isUpdateMode ? (
            <Box className="activity-form-context">
              <div><span>Client</span><strong>{selectedActivity?.clientName || '-'}</strong></div>
              <div><span>Scheduled</span><strong>{formatDate(selectedActivity?.scheduledAt)} {formatTime(selectedActivity?.scheduledAt)}</strong></div>
              <div><span>Meeting Status</span><strong>{selectedActivity?.meetingStatus || selectedActivity?.currentStatus || '-'}</strong></div>
              <div><span>Organizer</span><strong>{selectedActivity?.organizer?.name || selectedActivity?.createdByName || '-'}</strong></div>
            </Box>
          ) : null}

          {activityFormError ? <Box className="activity-form-error">{activityFormError}</Box> : null}

          <Box component="form" className="activity-form" onSubmit={handleActivityFormSubmit}>
            <section className="activity-form-card">
              <Box className="activity-form-card-head">
                <EventAvailableRoundedIcon fontSize="small" />
                <Typography>Client & Activity</Typography>
              </Box>
              <Box className="activity-form-grid">
                <label className="activity-form-field activity-form-field--two">
                  <span>Client <em>*</em></span>
                  <TextField size="small" placeholder="Search and select client" value={activityForm.clientName} onChange={handleActivityFormChange('clientName')} disabled={isUpdateMode} />
                </label>
                <label className="activity-form-field">
                  <span>Portfolio <em>*</em></span>
                  <TextField size="small" placeholder="Portfolio" value={activityForm.portfolioName} onChange={handleActivityFormChange('portfolioName')} disabled={isUpdateMode} />
                </label>
                <label className="activity-form-field activity-form-field--full">
                  <span>Activity <em>*</em></span>
                  <TextField size="small" placeholder="Enter activity details" value={activityForm.activityName} onChange={handleActivityFormChange('activityName')} />
                </label>
                <label className="activity-form-field">
                  <span>Activity Type <em>*</em></span>
                  <TextField select size="small" value={activityForm.activityType} onChange={handleActivityFormChange('activityType')}>
                    {activityTypeOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                  </TextField>
                </label>
                <label className="activity-form-field">
                  <span>Meeting Mode <em>*</em></span>
                  <TextField select size="small" value={activityForm.meetingMode} onChange={handleActivityFormChange('meetingMode')}>
                    {meetingModeOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                  </TextField>
                </label>
                <label className="activity-form-field">
                  <span>Schedule Date <em>*</em></span>
                  <TextField size="small" type="date" value={activityForm.scheduleDate} onChange={handleActivityFormChange('scheduleDate')} disabled={isUpdateMode} />
                </label>
                <label className="activity-form-field">
                  <span>Schedule Time <em>*</em></span>
                  <TextField size="small" type="time" value={activityForm.scheduleTime} onChange={handleActivityFormChange('scheduleTime')} disabled={isUpdateMode} />
                </label>
                <label className="activity-form-field activity-form-field--two">
                  <span>Joint call with users</span>
                  <Box className="activity-joint-combobox">
                    <Box className="activity-joint-control">
                      {activityForm.jointUsers.length ? (
                        <Box className="activity-joint-chips">
                          {activityForm.jointUsers.map((name) => (
                            <span className="activity-joint-chip" key={name}>
                              <span>{name}</span>
                              <button type="button" onClick={() => handleRemoveJointUser(name)} aria-label={`Remove ${name}`}>
                                <CloseRoundedIcon fontSize="inherit" />
                              </button>
                            </span>
                          ))}
                        </Box>
                      ) : null}
                      <Box className="activity-joint-search-row">
                        <GroupOutlinedIcon fontSize="small" />
                        <input
                          type="search"
                          value={jointSearch}
                          onFocus={() => setJointMenuOpen(true)}
                          onChange={(event) => {
                            setJointSearch(event.target.value);
                            setJointMenuOpen(true);
                          }}
                          placeholder="Search and add users"
                        />
                        <button type="button" onClick={() => setJointMenuOpen((open) => !open)} aria-label="Show users">
                          ▾
                        </button>
                      </Box>
                    </Box>
                    {jointMenuOpen ? (
                      <Box className="activity-joint-menu">
                        <Box className="activity-joint-list">
                          {filteredJointUserOptions.length ? filteredJointUserOptions.map((user) => (
                            <button type="button" className="activity-joint-option" key={user.id} onClick={() => handleAddJointUser(user)}>
                              <span className="activity-joint-check" />
                              <span>
                                <strong>{user.name}</strong>
                                <small>{user.email || 'Email not available'}</small>
                              </span>
                              <em>{user.role}</em>
                            </button>
                          )) : <span className="activity-joint-empty">No users found.</span>}
                        </Box>
                        <Box className="activity-joint-foot">
                          <span>{activityForm.jointUsers.length ? `${activityForm.jointUsers.length} user${activityForm.jointUsers.length === 1 ? '' : 's'} selected` : 'No users selected'}</span>
                          {activityForm.jointUsers.length ? <button type="button" onClick={() => setActivityForm((current) => ({ ...current, jointUsers: [] }))}>Clear selection</button> : null}
                        </Box>
                      </Box>
                    ) : null}
                  </Box>
                </label>
              </Box>
            </section>

            {isUpdateMode ? (
              <section className="activity-form-card">
                <Box className="activity-form-card-head">
                  <CheckCircleOutlineRoundedIcon fontSize="small" />
                  <Typography>Meeting Outcome</Typography>
                </Box>
                <Box className="activity-outcome-note">All outcome fields are mandatory. Select Reschedule to provide the new meeting date and time.</Box>
                <Box className="activity-form-grid">
                  <label className="activity-form-field">
                    <span>Is Client Interested? <em>*</em></span>
                    <TextField select size="small" value={activityForm.clientInterest} onChange={handleActivityFormChange('clientInterest')}>
                      <MenuItem value="">Select client interest</MenuItem>
                      {clientInterestOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                    </TextField>
                  </label>
                  <label className="activity-form-field">
                    <span>Meeting Status <em>*</em></span>
                    <TextField select size="small" value={activityForm.meetingStatus} onChange={handleActivityFormChange('meetingStatus')}>
                      <MenuItem value="">Select meeting status</MenuItem>
                      {meetingStatusOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                    </TextField>
                  </label>
                  <label className="activity-form-field activity-form-field--full">
                    <span>Remarks by Client <em>*</em></span>
                    <TextField multiline minRows={4} placeholder="Record the client's feedback or reason for rescheduling" value={activityForm.remarks} onChange={handleActivityFormChange('remarks')} />
                  </label>
                  {String(getOptionLabel(meetingStatusOptions, activityForm.meetingStatus)).toLowerCase().includes('reschedule') ? (
                    <Box className="activity-reschedule-box activity-form-field--full">
                      <label className="activity-form-field">
                        <span>New Schedule Date <em>*</em></span>
                        <TextField size="small" type="date" value={activityForm.newScheduleDate} onChange={handleActivityFormChange('newScheduleDate')} />
                      </label>
                      <label className="activity-form-field">
                        <span>New Schedule Time <em>*</em></span>
                        <TextField size="small" type="time" value={activityForm.newScheduleTime} onChange={handleActivityFormChange('newScheduleTime')} />
                      </label>
                    </Box>
                  ) : null}
                </Box>
              </section>
            ) : null}

            <Box className="activity-form-actions">
              <Box>
                <Button className="client-mgmt-filter-clear-btn" onClick={closeActivityDialog}>Cancel</Button>
                <Button type="submit" className="btn-common-red activity-form-save-btn">
                  {isUpdateMode ? 'Save Update' : 'Schedule Activity'}
                </Button>
              </Box>
            </Box>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Activities;
