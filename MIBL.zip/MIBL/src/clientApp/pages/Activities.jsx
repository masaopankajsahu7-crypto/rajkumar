import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Autocomplete,
  Box,
  Button,
  Chip,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  InputAdornment,
  MenuItem,
  Popover,
  TextField,
  Typography,
} from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import ArrowBackIosNewRoundedIcon from '@mui/icons-material/ArrowBackIosNewRounded';
import ArrowForwardIosRoundedIcon from '@mui/icons-material/ArrowForwardIosRounded';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import CheckCircleOutlineRoundedIcon from '@mui/icons-material/CheckCircleOutlineRounded';
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import ErrorOutlineRoundedIcon from '@mui/icons-material/ErrorOutlineRounded';
import EventAvailableRoundedIcon from '@mui/icons-material/EventAvailableRounded';
import FilterListRoundedIcon from '@mui/icons-material/FilterListRounded';
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined';
import ListAltRoundedIcon from '@mui/icons-material/ListAltRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import SearchIcon from '@mui/icons-material/Search';
import VideocamOutlinedIcon from '@mui/icons-material/VideocamOutlined';
import { ACTIVITY_KDS_FIELDS } from '../config/kdsFields.js';
import { activityEditPath, encodedRoutePath, ROUTES } from '../config/routes.js';
import { useClientActivities, useKdsOptions } from '../hooks/useFetchQueries.js';
import { searchAssignableOwners, searchClientsByName } from '../services/api.jsx';
import { getActivityBucket } from '../utils/clientActivities.js';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import VoiceTextField from '../components/common/VoiceTextField.jsx';
import './Clients.css';
import './Activities.css';

const VIEW_TABS = [
  { code: 'open', label: 'Open' },
  { code: 'breached', label: 'Breached' },
  { code: 'today', label: 'Today' },
  { code: 'upcoming', label: 'Upcoming' },
  { code: 'done', label: 'Completed' },
  { code: 'all', label: 'All' },
];

const GROUPS = {
  breached: { title: 'Breached', tone: 'breached', description: 'Past the scheduled time. Update or reschedule.' },
  today: { title: 'Today', tone: 'today', description: 'Your remaining conversations for today.' },
  upcoming: { title: 'Upcoming', tone: 'upcoming', description: 'Scheduled for the days ahead.' },
  done: { title: 'Completed & Closed', tone: 'done', description: 'Meeting outcomes already recorded.' },
  inactive: { title: 'Inactive', tone: 'inactive', description: 'Not included in your open to-do list.' },
};

const FALLBACK_ACTIVITY_TYPES = ['Policy Review', 'Client Meeting', 'Renewal Discussion', 'Follow Up', 'Document Collection'];
const FALLBACK_MEETING_MODES = ['Online', 'In Person', 'Phone Call', 'Email'];
const FALLBACK_MEETING_STATUSES = ['Completed', 'Closed', 'Rescheduled'];
const FALLBACK_CLIENT_INTERESTS = ['Yes, Interested', 'No, Not Interested', 'Maybe / Follow Up Required'];
const INITIAL_ACTIVITY_FILTERS = {
  search: '',
  clientName: '',
  clientUUID: '',
  activityType: '',
  fromDate: '',
  toDate: '',
  userName: '',
  userId: '',
  sortOrder: 'ASC',
};

const ACTIVITY_VIEW_CODES = new Set(VIEW_TABS.map((tab) => tab.code));

const getInitialActivityRouteState = (state = {}) => {
  const routeFilters = state?.filters && typeof state.filters === 'object' ? state.filters : {};
  const routeView = String(state?.view ?? '').trim();
  return {
    filters: {
      ...INITIAL_ACTIVITY_FILTERS,
      ...routeFilters,
    },
    view: ACTIVITY_VIEW_CODES.has(routeView) ? routeView : 'open',
  };
};

const formatDate = (date) => {
  if (!date) return '-';
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

const formatTime = (date) => {
  if (!date) return '';
  return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
};

const startOfWeek = (value) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() - ((date.getDay() + 6) % 7));
  return date;
};

const addDays = (value, days) => {
  const date = new Date(value);
  date.setDate(date.getDate() + days);
  return date;
};

const toDateKey = (value) => {
  if (!value) return '';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, '0'),
    String(date.getDate()).padStart(2, '0'),
  ].join('-');
};

const toTimeValue = (value) => {
  if (!value) return '';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return [String(date.getHours()).padStart(2, '0'), String(date.getMinutes()).padStart(2, '0')].join(':');
};

const getDefaultSchedule = () => {
  const next = new Date();
  next.setHours(next.getHours() + 1, 0, 0, 0);
  return next;
};

const getActivityFormState = (activity = null) => {
  const scheduledAt = activity?.scheduledAt ?? getDefaultSchedule();
  return {
    clientName: activity?.clientName ?? '',
    clientUUID: activity?.clientUUID ?? '',
    portfolioName: activity?.portfolioName ?? '',
    activityName: activity?.title ?? '',
    activityType: activity?.type ?? '',
    meetingMode: activity?.mode ?? '',
    scheduleDate: toDateKey(scheduledAt),
    scheduleTime: toTimeValue(scheduledAt),
    jointUsers: activity?.jointUsers?.map((user) => user.name).filter(Boolean) ?? [],
    clientInterest: activity?.clientInterest && activity.clientInterest !== 'Not Recorded' ? activity.clientInterest : '',
    meetingStatus: activity?.meetingStatus ?? '',
    remarks: activity?.remarks ?? '',
    newScheduleDate: '',
    newScheduleTime: '',
  };
};

const getRelativeLabel = (activity, bucket) => {
  if (bucket === 'done') return 'Outcome recorded';
  if (bucket === 'inactive') return 'Inactive activity';
  if (activity.schedule) return bucket === 'breached' ? activity.schedule : `In ${activity.schedule}`;
  return bucket === 'today' ? 'Due today' : 'Scheduled';
};

const StatusBadge = ({ status }) => {
  const key = String(status ?? '').toLowerCase().replace(/\s+/g, '-');
  return <span className={`activity-status-badge activity-status-badge--${key || 'default'}`}>{status || '-'}</span>;
};

const getOptionList = (kdsOptions = [], fallback = []) => {
  if (kdsOptions.length) return kdsOptions;
  return fallback.map((value) => ({ code: value, value }));
};

const findOptionCode = (options, labelOrCode) => {
  const normalized = String(labelOrCode ?? '').trim().toLowerCase();
  if (!normalized) return '';
  return options.find((option) =>
    String(option.code ?? '').trim().toLowerCase() === normalized ||
    String(option.value ?? '').trim().toLowerCase() === normalized
  )?.code ?? labelOrCode;
};

const getOptionLabel = (options, codeOrLabel) => {
  const normalized = String(codeOrLabel ?? '').trim().toLowerCase();
  return options.find((option) =>
    String(option.code ?? '').trim().toLowerCase() === normalized ||
    String(option.value ?? '').trim().toLowerCase() === normalized
  )?.value ?? codeOrLabel;
};

const getClientOptionLabel = (option = {}) => {
  const item = option || {};
  return String(item.clientName ?? item.client_name ?? item.value ?? item.name ?? '').trim();
};

const getClientOptionUUID = (option = {}) => {
  const item = option || {};
  return String(item.clientUUID ?? item.client_uuid ?? item.code ?? item.uuid ?? '').trim();
};

const getUserOptionLabel = (option = {}) => {
  const item = option || {};
  return String(item.value ?? item.full_name ?? item.user_name ?? item.key_value ?? item.name ?? '').trim();
};

const getUserOptionId = (option = {}) => {
  const item = option || {};
  return String(item.code ?? item.userid ?? item.user_id ?? item.key_code ?? item.id ?? '').trim();
};

const getUserOptionMeta = (option = {}) => {
  const item = option || {};
  return [item.sap_code, item.email_id ?? item.email, item.branch_name ?? item.branch]
    .map((item) => String(item ?? '').trim())
    .filter(Boolean)
    .join(' | ');
};

const matchesText = (value, search) => String(value ?? '').toLowerCase().includes(search);

const isActivityClosed = (activity = {}) => {
  const status = `${activity.meetingStatus ?? ''} ${activity.currentStatus ?? ''} ${activity.currentStatusCode ?? ''}`.toLowerCase();
  return status.includes('completed') || status.includes('closed');
};

const SummaryCard = ({ tone, icon: Icon, value, label, active, onClick }) => (
  <button
    type="button"
    className={`activity-summary-card activity-summary-card--${tone}`}
    aria-pressed={active}
    onClick={onClick}
  >
    <span className="activity-summary-icon">{Icon ? <Icon fontSize="small" /> : null}</span>
    <span>
      <strong>{value}</strong>
      <span>{label}</span>
    </span>
  </button>
);

const ActivityRow = ({ activity, onOpen }) => {
  const bucket = getActivityBucket(activity.raw);
  const jointNames = activity.jointUsers.map((user) => user.name).filter(Boolean).join(', ');
  const canOpenActivity = !isActivityClosed(activity);
  return (
    <article className={`activity-row-card activity-row-card--${bucket}`}>
      <span className={`activity-row-check ${bucket === 'done' ? 'activity-row-check--done' : ''}`}>
        <CheckCircleOutlineRoundedIcon fontSize="small" />
      </span>
      <Box className="activity-row-main">
        <Box className="activity-client-line">
          <Typography
            component={canOpenActivity ? 'button' : 'strong'}
            className={canOpenActivity ? 'activity-client-name-action' : undefined}
            {...(canOpenActivity
              ? {
                  type: 'button',
                  onClick: () => onOpen(activity),
                  'aria-label': `Update activity for ${activity.clientName || 'Client'}`,
                }
              : {})}
          >
            {activity.clientName || 'Client'}
          </Typography>
          <span>{activity.activityCode || activity.id} · {activity.portfolioName}</span>
        </Box>
        <Typography className="activity-row-title">{activity.title || 'Client activity'}</Typography>
        <Box className="activity-row-meta">
          <span><EventAvailableRoundedIcon fontSize="inherit" />{activity.type || 'Activity'}</span>
          <span><VideocamOutlinedIcon fontSize="inherit" />{activity.mode || 'Meeting'}</span>
          <span><GroupOutlinedIcon fontSize="inherit" />{jointNames ? `Joint: ${jointNames}` : 'Individual activity'}</span>
          {activity.rescheduleCount ? <span><RefreshRoundedIcon fontSize="inherit" />Rescheduled {activity.rescheduleCount}x</span> : null}
        </Box>
        {bucket === 'done' && activity.remarks ? (
          <Typography className="activity-row-comments">
            <strong>Comments:</strong> {activity.remarks}
          </Typography>
        ) : null}
      </Box>
      <Box className="activity-row-schedule">
        <span className="activity-row-date">{formatDate(activity.scheduledAt)}</span>
        <span>{formatTime(activity.scheduledAt)}</span>
        <em>{getRelativeLabel(activity, bucket)}</em>
      </Box>
      <Box className="activity-row-status">
        <StatusBadge status={activity.meetingStatus || activity.currentStatus} />
        {!activity.isCurrent ? <span className="activity-history-badge">Historical</span> : null}
        {activity.clientInterest && activity.clientInterest !== 'Not Recorded' ? <small>{activity.clientInterest}</small> : null}
      </Box>
      {canOpenActivity ? (
        <Button className="activity-row-action" aria-label="View activity" onClick={() => onOpen(activity)}>
          <ChevronRightRoundedIcon fontSize="small" />
        </Button>
      ) : null}
    </article>
  );
};

const Activities = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const initialRouteState = useMemo(() => getInitialActivityRouteState(location.state), [location.state]);
  const [view, setView] = useState(initialRouteState.view);
  const [layout, setLayout] = useState('list');
  const [calendarAnchor, setCalendarAnchor] = useState(() => startOfWeek(new Date()));
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [activityFilters, setActivityFilters] = useState(initialRouteState.filters);
  const [appliedActivityFilters, setAppliedActivityFilters] = useState(initialRouteState.filters);
  const [filterError, setFilterError] = useState('');
  const [clientSearch, setClientSearch] = useState('');
  const [clientOptions, setClientOptions] = useState([]);
  const [clientsLoading, setClientsLoading] = useState(false);
  const [userSearch, setUserSearch] = useState('');
  const [userOptions, setUserOptions] = useState([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [activityDialog, setActivityDialog] = useState({ open: false, mode: 'create', activity: null });
  const [activityForm, setActivityForm] = useState(() => getActivityFormState());
  const [activityFormError, setActivityFormError] = useState('');
  const [jointSearch, setJointSearch] = useState('');
  const [jointMenuOpen, setJointMenuOpen] = useState(false);
  const { data: activityTypeKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.activityType);
  const { data: meetingModeKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.meetingMode);
  const { data: meetingStatusKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.meetingStatus);
  const { data: clientInterestKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.clientInterest);
  const query = useClientActivities(1, {
    search: appliedActivityFilters.search,
    clientUUID: appliedActivityFilters.clientUUID,
    activityType: appliedActivityFilters.activityType,
    fromDate: appliedActivityFilters.fromDate,
    toDate: appliedActivityFilters.toDate,
    userId: appliedActivityFilters.userId,
    sortColumn: 'scheduled_at',
    sortOrder: appliedActivityFilters.sortOrder,
  });
  const isActivitiesLoading = query.isLoading || query.isFetching;
  const activities = query.data?.list ?? [];
  const activityTypeOptions = useMemo(() => getOptionList(activityTypeKdsOptions, FALLBACK_ACTIVITY_TYPES), [activityTypeKdsOptions]);
  const meetingModeOptions = useMemo(() => getOptionList(meetingModeKdsOptions, FALLBACK_MEETING_MODES), [meetingModeKdsOptions]);
  const meetingStatusOptions = useMemo(() => getOptionList(meetingStatusKdsOptions, FALLBACK_MEETING_STATUSES), [meetingStatusKdsOptions]);
  const clientInterestOptions = useMemo(() => getOptionList(clientInterestKdsOptions, FALLBACK_CLIENT_INTERESTS), [clientInterestKdsOptions]);

  useEffect(() => {
    const search = clientSearch.trim();
    if (search.length < 2) {
      setClientOptions([]);
      setClientsLoading(false);
      return undefined;
    }
    let active = true;
    setClientsLoading(true);
    const timer = setTimeout(() => {
      searchClientsByName(search, { source: 'client' })
        .then((results) => {
          if (active) setClientOptions(results);
        })
        .catch((error) => {
          console.error('Activity client search failed:', error);
          if (active) setClientOptions([]);
        })
        .finally(() => {
          if (active) setClientsLoading(false);
        });
    }, 300);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [clientSearch]);

  useEffect(() => {
    const search = userSearch.trim();
    if (search.length < 2) {
      setUserOptions([]);
      setUsersLoading(false);
      return undefined;
    }
    let active = true;
    setUsersLoading(true);
    const timer = setTimeout(() => {
      searchAssignableOwners(search, { userType: 'common', isHierarchy: 0 })
        .then((results) => {
          if (active) setUserOptions(results);
        })
        .catch((error) => {
          console.error('Activity user search failed:', error);
          if (active) setUserOptions([]);
        })
        .finally(() => {
          if (active) setUsersLoading(false);
        });
    }, 300);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [userSearch]);

  const jointUserOptions = useMemo(() => {
    const map = new Map();
    activities.forEach((activity) => {
      activity.participants.forEach((participant) => {
        const name = String(participant?.name ?? '').trim();
        if (!name) return;
        const id = String(participant?.user_id ?? participant?.userid ?? participant?.id ?? name).trim();
        map.set(id || name, {
          id: id || name,
          name,
          email: participant?.email ?? '',
          role: participant?.participant_role_code === 'ORGANIZER' ? 'Organizer' : 'Joint user',
        });
      });
    });
    ['Sandeep Shar', 'Pankaj Shau', 'Raj Kumar', 'Amit'].forEach((name, index) => {
      if (![...map.values()].some((user) => user.name === name)) {
        map.set(`sample-${index}`, { id: `sample-${index}`, name, email: '', role: 'Joint user' });
      }
    });
    return [...map.values()];
  }, [activities]);
  const filteredJointUserOptions = useMemo(() => {
    const search = jointSearch.trim().toLowerCase();
    return jointUserOptions.filter((user) => {
      if (activityForm.jointUsers.includes(user.name)) return false;
      if (!search) return true;
      return `${user.name} ${user.email}`.toLowerCase().includes(search);
    });
  }, [activityForm.jointUsers, jointSearch, jointUserOptions]);

  const baseFilteredActivities = useMemo(() => {
    const search = appliedActivityFilters.search.trim().toLowerCase();
    const clientName = appliedActivityFilters.clientName.trim().toLowerCase();
    const clientUUID = appliedActivityFilters.clientUUID.trim().toLowerCase();
    const activityType = appliedActivityFilters.activityType.trim().toLowerCase();
    const fromDate = appliedActivityFilters.fromDate;
    const toDate = appliedActivityFilters.toDate;
    const userName = appliedActivityFilters.userName.trim().toLowerCase();
    const userId = appliedActivityFilters.userId.trim().toLowerCase();
    const sortMultiplier = appliedActivityFilters.sortOrder === 'DESC' ? -1 : 1;

    return activities
      .filter((activity) => {
        const rawActivityType = String(activity.raw?.activity_type_code ?? activity.raw?.activity_type ?? activity.type ?? '').trim().toLowerCase();
        const scheduledDate = toDateKey(activity.scheduledAt);
        const participantHaystack = [
          activity.createdByName,
          activity.modifiedByName,
          activity.organizer?.name,
          activity.organizer?.user_id,
          activity.organizer?.userid,
          ...activity.participants.flatMap((participant) => [
            participant?.name,
            participant?.user_id,
            participant?.userid,
            participant?.email,
            participant?.email_id,
          ]),
        ];

        if (clientUUID && String(activity.clientUUID ?? '').trim().toLowerCase() !== clientUUID) return false;
        if (!clientUUID && clientName && !matchesText(activity.clientName, clientName)) return false;
        if (activityType && rawActivityType !== activityType && !matchesText(activity.type, activityType)) return false;
        if (fromDate && scheduledDate && scheduledDate < fromDate) return false;
        if (toDate && scheduledDate && scheduledDate > toDate) return false;
        if (userId && !participantHaystack.some((value) => String(value ?? '').trim().toLowerCase() === userId)) return false;
        if (!userId && userName && !participantHaystack.some((value) => matchesText(value, userName))) return false;
        if (!search) return true;
        return [
          activity.clientName,
          activity.activityCode,
          activity.title,
          activity.type,
          activity.mode,
          activity.createdByName,
        ].some((value) => matchesText(value, search));
      })
      .sort((a, b) => sortMultiplier * ((a.scheduledAt?.getTime() ?? 0) - (b.scheduledAt?.getTime() ?? 0)));
  }, [activities, appliedActivityFilters]);

  const counts = useMemo(() => {
    const next = { breached: 0, today: 0, upcoming: 0, done: 0, inactive: 0, all: baseFilteredActivities.length };
    baseFilteredActivities.forEach((activity) => {
      next[getActivityBucket(activity.raw)] += 1;
    });
    next.open = next.breached + next.today + next.upcoming;
    return next;
  }, [baseFilteredActivities]);

  const filteredActivities = useMemo(() => baseFilteredActivities.filter((activity) => {
    const bucket = getActivityBucket(activity.raw);
    if (view === 'open') return ['breached', 'today', 'upcoming'].includes(bucket);
    if (view === 'all') return true;
    return bucket === view;
  }), [baseFilteredActivities, view]);

  const grouped = useMemo(() => {
    const next = { breached: [], today: [], upcoming: [], done: [], inactive: [] };
    filteredActivities.forEach((activity) => {
      next[getActivityBucket(activity.raw)].push(activity);
    });
    return next;
  }, [filteredActivities]);

  const calendarDays = useMemo(() => {
    const todayKey = toDateKey(new Date());
    return Array.from({ length: 7 }, (_, index) => {
      const date = addDays(calendarAnchor, index);
      const key = toDateKey(date);
      const rows = filteredActivities
        .filter((activity) => toDateKey(activity.scheduledAt) === key)
        .sort((a, b) => (appliedActivityFilters.sortOrder === 'DESC' ? -1 : 1) * ((a.scheduledAt?.getTime() ?? 0) - (b.scheduledAt?.getTime() ?? 0)));
      return {
        date,
        key,
        isToday: key === todayKey,
        isWeekend: [0, 6].includes(date.getDay()),
        rows,
      };
    });
  }, [appliedActivityFilters.sortOrder, calendarAnchor, filteredActivities]);

  const activeFilterChips = useMemo(() => {
    const chips = [];
    if (appliedActivityFilters.clientName) chips.push({ key: 'client', label: `Client: ${appliedActivityFilters.clientName}` });
    if (appliedActivityFilters.activityType) {
      chips.push({ key: 'activityType', label: `Activity Type: ${getOptionLabel(activityTypeOptions, appliedActivityFilters.activityType)}` });
    }
    if (appliedActivityFilters.fromDate) chips.push({ key: 'fromDate', label: `From: ${appliedActivityFilters.fromDate}` });
    if (appliedActivityFilters.toDate) chips.push({ key: 'toDate', label: `To: ${appliedActivityFilters.toDate}` });
    if (appliedActivityFilters.userName) chips.push({ key: 'user', label: `User: ${appliedActivityFilters.userName}` });
    if (appliedActivityFilters.sortOrder === 'DESC') chips.push({ key: 'sortOrder', label: 'Schedule Date: Descending' });
    return chips;
  }, [activityTypeOptions, appliedActivityFilters]);

  const handleSearchChange = (event) => {
    const search = event.target.value;
    setActivityFilters((current) => ({ ...current, search }));
    setAppliedActivityFilters((current) => ({ ...current, search }));
  };
  const handleDraftFilterChange = (field, value) => {
    setFilterError('');
    setActivityFilters((current) => ({ ...current, [field]: value }));
  };
  const handleApplyFilters = () => {
    if (activityFilters.fromDate && activityFilters.toDate && activityFilters.fromDate > activityFilters.toDate) {
      setFilterError('Scheduled From Date cannot be later than Scheduled To Date.');
      return;
    }
    setAppliedActivityFilters({ ...activityFilters, search: activityFilters.search.trim() });
    setFilterAnchorEl(null);
  };
  const handleClearFilters = () => {
    setActivityFilters(INITIAL_ACTIVITY_FILTERS);
    setAppliedActivityFilters(INITIAL_ACTIVITY_FILTERS);
    setClientSearch('');
    setUserSearch('');
    setFilterError('');
  };
  const handleRemoveFilterChip = (key) => {
    const next = { ...appliedActivityFilters };
    if (key === 'client') {
      next.clientName = '';
      next.clientUUID = '';
      setClientSearch('');
    } else if (key === 'user') {
      next.userName = '';
      next.userId = '';
      setUserSearch('');
    } else if (key === 'sortOrder') {
      next.sortOrder = 'ASC';
    } else {
      next[key] = '';
    }
    setAppliedActivityFilters(next);
    setActivityFilters(next);
  };
  const handleSummaryClick = (nextView) => {
    setView(nextView);
    setLayout('list');
  };
  const openCreateActivity = () => {
    navigate(encodedRoutePath(ROUTES.activitiesCreate));
  };
  const openUpdateActivity = (activity) => {
    if (isActivityClosed(activity)) return;
    navigate(activityEditPath(activity.activityUUID || activity.activity_uuid || activity.id), { state: { activity } });
  };
  const closeActivityDialog = () => {
    setActivityDialog((current) => ({ ...current, open: false }));
    setActivityFormError('');
  };
  const handleActivityFormChange = (field) => (event) => {
    setActivityForm((current) => ({ ...current, [field]: event.target.value }));
  };
  const handleAddJointUser = (user) => {
    setActivityForm((current) => ({
      ...current,
      jointUsers: current.jointUsers.includes(user.name) ? current.jointUsers : [...current.jointUsers, user.name],
    }));
    setJointSearch('');
  };
  const handleRemoveJointUser = (name) => {
    setActivityForm((current) => ({
      ...current,
      jointUsers: current.jointUsers.filter((item) => item !== name),
    }));
  };
  const handleActivityFormSubmit = (event) => {
    event.preventDefault();
    const requiredFields = ['clientName', 'portfolioName', 'activityName', 'activityType', 'meetingMode', 'scheduleDate', 'scheduleTime'];
    const missingBaseField = requiredFields.some((field) => !String(activityForm[field] ?? '').trim());
    if (missingBaseField) {
      setActivityFormError('Complete all mandatory Client & Activity fields.');
      return;
    }
    if (activityDialog.mode === 'update') {
      const missingOutcome = ['clientInterest', 'meetingStatus', 'remarks'].some((field) => !String(activityForm[field] ?? '').trim());
      if (missingOutcome) {
        setActivityFormError('Complete all mandatory Meeting Outcome fields.');
        return;
      }
      if (activityForm.meetingStatus === 'Rescheduled' && (!activityForm.newScheduleDate || !activityForm.newScheduleTime)) {
        setActivityFormError('Select the new schedule date and time.');
        return;
      }
    }
    closeActivityDialog();
  };
  const isUpdateMode = activityDialog.mode === 'update';
  const selectedActivity = activityDialog.activity;

  return (
    <Box className="activity-mgmt-page client-mgmt-page">
      <BackdropLoader loading={isActivitiesLoading} />
      <Box className="activity-page-head">
        <Box className="client-mgmt-page-title-wrap">
          <Typography className="client-mgmt-title">Client Activities</Typography>
          <Typography className="activity-page-subtitle">Plan your next conversation. Keep every follow-up on track.</Typography>
        </Box>
        <Box className="activity-page-actions">
          <span className="activity-layout-switch" role="group" aria-label="Activity view">
            <button type="button" aria-pressed={layout === 'list'} onClick={() => setLayout('list')}>
              <ListAltRoundedIcon fontSize="small" /> List
            </button>
            <button type="button" aria-pressed={layout === 'calendar'} onClick={() => setLayout('calendar')}>
              <CalendarMonthOutlinedIcon fontSize="small" /> Calendar
            </button>
          </span>
          <Button className="activity-add-btn" startIcon={<AddRoundedIcon />} onClick={openCreateActivity}>New Activity</Button>
        </Box>
      </Box>

      <Box className="activity-summary-grid">
        <SummaryCard tone="breached" icon={ErrorOutlineRoundedIcon} value={counts.breached} label="Breached" active={view === 'breached'} onClick={() => handleSummaryClick('breached')} />
        <SummaryCard tone="today" icon={EventAvailableRoundedIcon} value={counts.today} label="Today" active={view === 'today'} onClick={() => handleSummaryClick('today')} />
        <SummaryCard tone="upcoming" icon={CalendarMonthOutlinedIcon} value={counts.upcoming} label="Upcoming" active={view === 'upcoming'} onClick={() => handleSummaryClick('upcoming')} />
        <SummaryCard tone="done" icon={CheckCircleOutlineRoundedIcon} value={counts.done} label="Completed" active={view === 'done'} onClick={() => handleSummaryClick('done')} />
      </Box>

      <Box className="activity-list-panel">
        {layout === 'list' ? (
          <>
            <Box className="activity-toolbar">
              <Box className="activity-view-tabs">
                {VIEW_TABS.map((tab) => (
                  <button key={tab.code} type="button" className="activity-tab" aria-pressed={view === tab.code} onClick={() => setView(tab.code)}>
                    {tab.label}<span>{counts[tab.code] ?? 0}</span>
                  </button>
                ))}
              </Box>
              <Box className="activity-toolbar-actions">
                <TextField
                  className="activity-search"
                  size="small"
                  placeholder="Search activities..."
                  value={activityFilters.search}
                  onChange={handleSearchChange}
                  InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
                />
                <Button
                  className="client-mgmt-filter-toggle-btn"
                  onClick={(event) => setFilterAnchorEl(event.currentTarget)}
                  startIcon={<FilterListRoundedIcon />}
                >
                  Filters
                </Button>
              </Box>
            </Box>

            <Popover
              open={Boolean(filterAnchorEl)}
              anchorEl={filterAnchorEl}
              onClose={() => setFilterAnchorEl(null)}
              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
              transformOrigin={{ vertical: 'top', horizontal: 'right' }}
              className="client-mgmt-filter-popover activity-filter-popover"
              classes={{ paper: 'client-mgmt-filter-popover-paper activity-filter-popover-paper' }}
            >
              <Box className="activity-filter-panel">
                <Box className="client-mgmt-filter-popover-head activity-filter-head">
                  <Typography className="georama-SemiBold client-mgmt-filter-popover-title">Filters</Typography>
                  <IconButton className="client-mgmt-filter-popover-close" size="small" onClick={() => setFilterAnchorEl(null)} aria-label="Close filters">
                    <CloseRoundedIcon fontSize="small" />
                  </IconButton>
                </Box>
                <Box className="client-mgmt-filter-popover-body activity-filter-grid">
                  <Box className="activity-filter-field">
                    <Typography>Client Name</Typography>
                    <Autocomplete
                      size="small"
                      options={clientOptions}
                      loading={clientsLoading}
                      value={activityFilters.clientName ? { clientName: activityFilters.clientName, clientUUID: activityFilters.clientUUID } : null}
                      inputValue={clientSearch || activityFilters.clientName}
                      onInputChange={(_, value, reason) => {
                        if (reason === 'input') {
                          setClientSearch(value);
                          if (!value) {
                            setActivityFilters((current) => ({ ...current, clientName: '', clientUUID: '' }));
                          }
                        }
                      }}
                      onChange={(_, option) => {
                        handleDraftFilterChange('clientName', getClientOptionLabel(option));
                        handleDraftFilterChange('clientUUID', getClientOptionUUID(option));
                        setClientSearch(getClientOptionLabel(option));
                      }}
                      getOptionLabel={getClientOptionLabel}
                      isOptionEqualToValue={(option, value) => getClientOptionUUID(option) === getClientOptionUUID(value)}
                      noOptionsText={clientSearch.trim().length < 2 ? 'Type at least 2 characters' : 'No clients found'}
                      renderInput={(params) => <TextField {...params} className="client-mgmt-filter-input" placeholder="Search client" />}
                    />
                  </Box>
                  <Box className="activity-filter-field">
                    <Typography>Activity Type</Typography>
                    <TextField
                      className="client-mgmt-filter-input"
                      select
                      size="small"
                      value={activityFilters.activityType}
                      onChange={(event) => handleDraftFilterChange('activityType', event.target.value)}
                    >
                      <MenuItem value="">All activity types</MenuItem>
                      {activityTypeOptions.map((option) => (
                        <MenuItem key={option.code} value={option.code}>{option.value}</MenuItem>
                      ))}
                    </TextField>
                  </Box>
                  <Box className="activity-filter-field">
                    <Typography>Scheduled From Date</Typography>
                    <TextField
                      className="client-mgmt-filter-input"
                      type="date"
                      size="small"
                      value={activityFilters.fromDate}
                      onChange={(event) => handleDraftFilterChange('fromDate', event.target.value)}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Box>
                  <Box className="activity-filter-field">
                    <Typography>Scheduled To Date</Typography>
                    <TextField
                      className="client-mgmt-filter-input"
                      type="date"
                      size="small"
                      value={activityFilters.toDate}
                      onChange={(event) => handleDraftFilterChange('toDate', event.target.value)}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Box>
                  <Box className="activity-filter-field">
                    <Typography>User</Typography>
                    <Autocomplete
                      size="small"
                      options={userOptions}
                      loading={usersLoading}
                      value={activityFilters.userName ? { value: activityFilters.userName, code: activityFilters.userId } : null}
                      inputValue={userSearch || activityFilters.userName}
                      onInputChange={(_, value, reason) => {
                        if (reason === 'input') {
                          setUserSearch(value);
                          if (!value) {
                            setActivityFilters((current) => ({ ...current, userName: '', userId: '' }));
                          }
                        }
                      }}
                      onChange={(_, option) => {
                        handleDraftFilterChange('userName', getUserOptionLabel(option));
                        handleDraftFilterChange('userId', getUserOptionId(option));
                        setUserSearch(getUserOptionLabel(option));
                      }}
                      getOptionLabel={getUserOptionLabel}
                      isOptionEqualToValue={(option, value) => getUserOptionId(option) === getUserOptionId(value)}
                      noOptionsText={userSearch.trim().length < 2 ? 'Type at least 2 characters' : 'No users found'}
                      renderOption={(props, option) => (
                        <li {...props}>
                          <Box className="activity-user-option">
                            <strong>{getUserOptionLabel(option)}</strong>
                            {getUserOptionMeta(option) ? <span>{getUserOptionMeta(option)}</span> : null}
                          </Box>
                        </li>
                      )}
                      renderInput={(params) => <TextField {...params} className="client-mgmt-filter-input" placeholder="Search user" />}
                    />
                  </Box>
                  <Box className="activity-filter-field">
                    <Typography>Sort by Schedule Date</Typography>
                    <TextField
                      className="client-mgmt-filter-input"
                      select
                      size="small"
                      value={activityFilters.sortOrder}
                      onChange={(event) => handleDraftFilterChange('sortOrder', event.target.value)}
                    >
                      <MenuItem value="ASC">Ascending</MenuItem>
                      <MenuItem value="DESC">Descending</MenuItem>
                    </TextField>
                  </Box>
                </Box>
                {filterError ? <Typography className="activity-filter-error">{filterError}</Typography> : null}
                <Box className="client-mgmt-filter-popover-actions activity-filter-actions">
                  <Button className="client-mgmt-filter-clear-btn text-sky" onClick={handleClearFilters}>Clear All</Button>
                  <Button className="btn-common-red client-mgmt-filter-apply-btn" onClick={handleApplyFilters}>Apply</Button>
                </Box>
              </Box>
            </Popover>

            {activeFilterChips.length > 0 && (
              <Box className="client-mgmt-active-filters activity-active-filters">
                {activeFilterChips.map((chip) => (
                  <Chip
                    key={chip.key}
                    label={chip.label}
                    size="small"
                    onDelete={() => handleRemoveFilterChip(chip.key)}
                    className="client-mgmt-filter-chip"
                  />
                ))}
                <Button className="client-mgmt-filter-clear-all text-sky" onClick={handleClearFilters}>
                  Clear All
                </Button>
              </Box>
            )}

            {Object.entries(GROUPS).map(([groupKey, group]) => {
              const rows = grouped[groupKey] ?? [];
              if (!rows.length) return null;
              return (
                <section key={groupKey} className={`activity-group activity-group--${group.tone}`}>
                  <Box className="activity-group-head">
                    <span />
                    <Typography>{group.title}</Typography>
                    <strong>{rows.length}</strong>
                    <em>{group.description}</em>
                  </Box>
                  {rows.map((activity) => <ActivityRow key={activity.id} activity={activity} onOpen={openUpdateActivity} />)}
                </section>
              );
            })}
          </>
        ) : (
          <Box className="activity-calendar-panel">
            <Box className="activity-calendar-toolbar">
              <Box>
                <Typography>Weekly Calendar</Typography>
                <span>{formatDate(calendarDays[0]?.date)} - {formatDate(calendarDays[6]?.date)}</span>
              </Box>
              <Box className="activity-calendar-nav">
                <Button onClick={() => setCalendarAnchor((current) => addDays(current, -7))} aria-label="Previous week">
                  <ArrowBackIosNewRoundedIcon fontSize="small" />
                </Button>
                <Button onClick={() => setCalendarAnchor((current) => addDays(current, 7))} aria-label="Next week">
                  <ArrowForwardIosRoundedIcon fontSize="small" />
                </Button>
              </Box>
            </Box>
            <Box className="activity-calendar-scroll">
              <Box className="activity-week-grid">
                {calendarDays.map((day) => (
                  <section
                    key={day.key}
                    className={`activity-day-column ${day.isWeekend ? 'activity-day-column--weekend' : ''} ${day.isToday ? 'activity-day-column--today' : ''}`}
                  >
                    <Box className="activity-day-head">
                      <Box>
                        <span>{day.date.toLocaleDateString('en-GB', { weekday: 'short' })}</span>
                        <strong>{day.date.getDate()}</strong>
                      </Box>
                      <em>{day.rows.length || ''}</em>
                    </Box>
                    <Box className="activity-day-events">
                      {day.rows.length ? day.rows.map((activity) => {
                        const bucket = getActivityBucket(activity.raw);
                        return (
                          <button key={activity.id} type="button" className={`activity-calendar-event activity-calendar-event--${bucket}`} onClick={() => openUpdateActivity(activity)} disabled={isActivityClosed(activity)}>
                            <span className="activity-calendar-event-time">
                              {formatTime(activity.scheduledAt)}
                              <em>{activity.activityCode}</em>
                            </span>
                            <strong>{activity.clientName || 'Client'}</strong>
                            <span>{activity.title || 'Client activity'}</span>
                            <StatusBadge status={activity.meetingStatus || activity.currentStatus} />
                          </button>
                        );
                      }) : <span className="activity-day-empty">No activities</span>}
                    </Box>
                  </section>
                ))}
              </Box>
            </Box>
          </Box>
        )}

        {!isActivitiesLoading && !filteredActivities.length ? (
          <Box className="activity-empty">
            <EventAvailableRoundedIcon />
            <Typography>{query.isError ? 'Unable to load activities' : 'No activities in this view'}</Typography>
            <span>{query.isError ? query.error?.message || 'Please try again.' : 'Try another search or clear filters.'}</span>
          </Box>
        ) : null}
      </Box>

      <Dialog
        open={activityDialog.open}
        onClose={closeActivityDialog}
        maxWidth="md"
        fullWidth
        className="activity-form-dialog"
        PaperProps={{ className: 'activity-form-dialog-paper' }}
      >
        <DialogTitle className="activity-form-dialog-title">
          <Box>
            <Typography component="h2">{isUpdateMode ? 'Update Activity' : 'Create Activity'}</Typography>
            <span>{isUpdateMode ? 'Record the meeting outcome or reschedule the activity.' : 'Schedule a client interaction and add joint-call users.'}</span>
          </Box>
          <IconButton className="activity-form-close" onClick={closeActivityDialog} aria-label="Close activity form">
            <CloseRoundedIcon fontSize="small" />
          </IconButton>
        </DialogTitle>
        <DialogContent className="activity-form-dialog-content">
          {isUpdateMode ? (
            <Box className="activity-form-context">
              <div><span>Client</span><strong>{selectedActivity?.clientName || '-'}</strong></div>
              <div><span>Scheduled</span><strong>{formatDate(selectedActivity?.scheduledAt)} {formatTime(selectedActivity?.scheduledAt)}</strong></div>
              <div><span>Meeting Status</span><strong>{selectedActivity?.meetingStatus || selectedActivity?.currentStatus || '-'}</strong></div>
              <div><span>Organizer</span><strong>{selectedActivity?.organizer?.name || selectedActivity?.createdByName || '-'}</strong></div>
            </Box>
          ) : null}

          {activityFormError ? <Box className="activity-form-error">{activityFormError}</Box> : null}

          <Box component="form" className="activity-form" onSubmit={handleActivityFormSubmit}>
            <section className="activity-form-card">
              <Box className="activity-form-card-head">
                <EventAvailableRoundedIcon fontSize="small" />
                <Typography>Client & Activity</Typography>
              </Box>
              <Box className="activity-form-grid">
                <label className="activity-form-field activity-form-field--two">
                  <span>Client <em>*</em></span>
                  <TextField size="small" placeholder="Search and select client" value={activityForm.clientName} onChange={handleActivityFormChange('clientName')} disabled={isUpdateMode} />
                </label>
                <label className="activity-form-field">
                  <span>Portfolio <em>*</em></span>
                  <TextField size="small" placeholder="Portfolio" value={activityForm.portfolioName} onChange={handleActivityFormChange('portfolioName')} disabled={isUpdateMode} />
                </label>
                <label className="activity-form-field activity-form-field--full">
                  <span>Activity <em>*</em></span>
                  <TextField size="small" placeholder="Enter activity details" value={activityForm.activityName} onChange={handleActivityFormChange('activityName')} />
                </label>
                <label className="activity-form-field">
                  <span>Activity Type <em>*</em></span>
                  <TextField select size="small" value={activityForm.activityType} onChange={handleActivityFormChange('activityType')}>
                    {activityTypeOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                  </TextField>
                </label>
                <label className="activity-form-field">
                  <span>Meeting Mode <em>*</em></span>
                  <TextField select size="small" value={activityForm.meetingMode} onChange={handleActivityFormChange('meetingMode')}>
                    {meetingModeOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                  </TextField>
                </label>
                <label className="activity-form-field">
                  <span>Schedule Date <em>*</em></span>
                  <TextField size="small" type="date" value={activityForm.scheduleDate} onChange={handleActivityFormChange('scheduleDate')} disabled={isUpdateMode} />
                </label>
                <label className="activity-form-field">
                  <span>Schedule Time <em>*</em></span>
                  <TextField size="small" type="time" value={activityForm.scheduleTime} onChange={handleActivityFormChange('scheduleTime')} disabled={isUpdateMode} />
                </label>
                <label className="activity-form-field activity-form-field--two">
                  <span>Joint call with users</span>
                  <Box className="activity-joint-combobox">
                    <Box className="activity-joint-control">
                      {activityForm.jointUsers.length ? (
                        <Box className="activity-joint-chips">
                          {activityForm.jointUsers.map((name) => (
                            <span className="activity-joint-chip" key={name}>
                              <span>{name}</span>
                              <button type="button" onClick={() => handleRemoveJointUser(name)} aria-label={`Remove ${name}`}>
                                <CloseRoundedIcon fontSize="inherit" />
                              </button>
                            </span>
                          ))}
                        </Box>
                      ) : null}
                      <Box className="activity-joint-search-row">
                        <GroupOutlinedIcon fontSize="small" />
                        <input
                          type="search"
                          value={jointSearch}
                          onFocus={() => setJointMenuOpen(true)}
                          onChange={(event) => {
                            setJointSearch(event.target.value);
                            setJointMenuOpen(true);
                          }}
                          placeholder="Search and add users"
                        />
                        <button type="button" onClick={() => setJointMenuOpen((open) => !open)} aria-label="Show users">
                          ▾
                        </button>
                      </Box>
                    </Box>
                    {jointMenuOpen ? (
                      <Box className="activity-joint-menu">
                        <Box className="activity-joint-list">
                          {filteredJointUserOptions.length ? filteredJointUserOptions.map((user) => (
                            <button type="button" className="activity-joint-option" key={user.id} onClick={() => handleAddJointUser(user)}>
                              <span className="activity-joint-check" />
                              <span>
                                <strong>{user.name}</strong>
                                <small>{user.email || 'Email not available'}</small>
                              </span>
                              <em>{user.role}</em>
                            </button>
                          )) : <span className="activity-joint-empty">No users found.</span>}
                        </Box>
                        <Box className="activity-joint-foot">
                          <span>{activityForm.jointUsers.length ? `${activityForm.jointUsers.length} user${activityForm.jointUsers.length === 1 ? '' : 's'} selected` : 'No users selected'}</span>
                          {activityForm.jointUsers.length ? <button type="button" onClick={() => setActivityForm((current) => ({ ...current, jointUsers: [] }))}>Clear selection</button> : null}
                        </Box>
                      </Box>
                    ) : null}
                  </Box>
                </label>
              </Box>
            </section>

            {isUpdateMode ? (
              <section className="activity-form-card">
                <Box className="activity-form-card-head">
                  <CheckCircleOutlineRoundedIcon fontSize="small" />
                  <Typography>Meeting Outcome</Typography>
                </Box>
                <Box className="activity-outcome-note">All outcome fields are mandatory. Select Reschedule to provide the new meeting date and time.</Box>
                <Box className="activity-form-grid">
                  <label className="activity-form-field">
                    <span>Is Client Interested? <em>*</em></span>
                    <TextField select size="small" value={activityForm.clientInterest} onChange={handleActivityFormChange('clientInterest')}>
                      <MenuItem value="">Select client interest</MenuItem>
                      {clientInterestOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                    </TextField>
                  </label>
                  <label className="activity-form-field">
                    <span>Meeting Status <em>*</em></span>
                    <TextField select size="small" value={activityForm.meetingStatus} onChange={handleActivityFormChange('meetingStatus')}>
                      <MenuItem value="">Select meeting status</MenuItem>
                      {meetingStatusOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                    </TextField>
                  </label>
                  <label className="activity-form-field activity-form-field--full">
                    <span>Remarks by Client <em>*</em></span>
                    <VoiceTextField multiline minRows={4} placeholder="Record the client's feedback or reason for rescheduling" value={activityForm.remarks} onChange={handleActivityFormChange('remarks')} />
                  </label>
                  {String(getOptionLabel(meetingStatusOptions, activityForm.meetingStatus)).toLowerCase().includes('reschedule') ? (
                    <Box className="activity-reschedule-box activity-form-field--full">
                      <label className="activity-form-field">
                        <span>New Schedule Date <em>*</em></span>
                        <TextField size="small" type="date" value={activityForm.newScheduleDate} onChange={handleActivityFormChange('newScheduleDate')} />
                      </label>
                      <label className="activity-form-field">
                        <span>New Schedule Time <em>*</em></span>
                        <TextField size="small" type="time" value={activityForm.newScheduleTime} onChange={handleActivityFormChange('newScheduleTime')} />
                      </label>
                    </Box>
                  ) : null}
                </Box>
              </section>
            ) : null}

            <Box className="activity-form-actions">
              <Box>
                <Button className="client-mgmt-filter-clear-btn" onClick={closeActivityDialog}>Cancel</Button>
                <Button type="submit" className="btn-common-red activity-form-save-btn">
                  {isUpdateMode ? 'Save Update' : 'Schedule Activity'}
                </Button>
              </Box>
            </Box>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Activities;
