import { useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { Autocomplete, Box, Button, MenuItem, TextField, Typography } from '@mui/material';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import CheckCircleOutlineRoundedIcon from '@mui/icons-material/CheckCircleOutlineRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import EventAvailableRoundedIcon from '@mui/icons-material/EventAvailableRounded';
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined';
import { ACTIVITY_KDS_FIELDS } from '../config/kdsFields.js';
import { getCurrentUserId } from '../config/clientApiConfig.js';
import { encodedRoutePath, ROUTES } from '../config/routes.js';
import { useClientActivities, useKdsOptions, usePortfolioListByClient } from '../hooks/useFetchQueries.js';
import { invalidateClientActivitiesQueries } from '../lib/queryClient.js';
import { createClientActivity, searchClientsByName, searchCommonUsers } from '../services/api.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import './Clients.css';
import './Activities.css';

const FALLBACK_ACTIVITY_TYPES = ['Policy Review', 'Client Meeting', 'Renewal Discussion', 'Follow Up', 'Document Collection'];
const FALLBACK_MEETING_MODES = ['Online', 'In Person', 'Phone Call', 'Email'];
const FALLBACK_MEETING_STATUSES = ['Completed', 'Closed', 'Rescheduled'];
const FALLBACK_CLIENT_INTERESTS = ['Yes, Interested', 'No, Not Interested', 'Maybe / Follow Up Required'];
const DEFAULT_CREATE_CLIENT_INTEREST_CODE = 'CA_INT_NOT_RECORDED';
const DEFAULT_CREATE_MEETING_STATUS_CODE = 'CA_STATUS_SCHEDULED';

const toDateKey = (value) => {
  if (!value) return '';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, '0'),
    String(date.getDate()).padStart(2, '0'),
  ].join('-');
};

const addDays = (date, days) => {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
};

const addMonths = (date, months) => {
  const next = new Date(date);
  next.setMonth(next.getMonth() + months);
  return next;
};

const toTimeValue = (value) => {
  if (!value) return '';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return [String(date.getHours()).padStart(2, '0'), String(date.getMinutes()).padStart(2, '0')].join(':');
};

const getDefaultSchedule = () => {
  const next = new Date();
  next.setHours(next.getHours() + 1, 0, 0, 0);
  return next;
};

const formatDate = (date) => {
  if (!date) return '-';
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

const formatTime = (date) => {
  if (!date) return '';
  return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
};

const getOptionList = (kdsOptions = [], fallback = []) => {
  if (kdsOptions.length) return kdsOptions;
  return fallback.map((value) => ({ code: value, value }));
};

const findOptionCode = (options, labelOrCode) => {
  const normalized = String(labelOrCode ?? '').trim().toLowerCase();
  if (!normalized) return '';
  return options.find((option) =>
    String(option.code ?? '').trim().toLowerCase() === normalized ||
    String(option.value ?? '').trim().toLowerCase() === normalized
  )?.code ?? labelOrCode;
};

const getOptionLabel = (options, codeOrLabel) => {
  const normalized = String(codeOrLabel ?? '').trim().toLowerCase();
  return options.find((option) =>
    String(option.code ?? '').trim().toLowerCase() === normalized ||
    String(option.value ?? '').trim().toLowerCase() === normalized
  )?.value ?? codeOrLabel;
};

const getJointUserName = (user) => typeof user === 'string' ? user : user?.name ?? '';
const getJointUserId = (user) => typeof user === 'string' ? '' : user?.id ?? user?.user_id ?? user?.userid ?? '';
const mapUserOption = (user) => ({
  id: String(user?.code ?? user?.userid ?? user?.user_id ?? user?.id ?? '').trim(),
  name: String(user?.value ?? user?.username ?? user?.name ?? user?.user_name ?? '').trim(),
  email: user?.email_id ?? user?.email ?? user?.user_email ?? '',
  role: user?.role ?? user?.role_name ?? '',
});

const getActivityFormState = (activity = null) => {
  const scheduledAt = activity?.scheduledAt ?? getDefaultSchedule();
  return {
    clientName: activity?.clientName ?? '',
    clientUUID: activity?.clientUUID ?? '',
    portfolioName: activity?.portfolioName ?? '',
    portfolioUUID: activity?.portfolioUUID ?? activity?.portfolio_uuid ?? '',
    activityName: activity?.title ?? '',
    activityType: activity?.type ?? '',
    meetingMode: activity?.mode ?? '',
    scheduleDate: toDateKey(scheduledAt),
    scheduleTime: toTimeValue(scheduledAt),
    jointUsers: activity?.jointUsers?.map((user) => ({
      id: String(user?.user_id ?? user?.userid ?? user?.id ?? '').trim(),
      name: user?.name,
    })).filter((user) => user.name) ?? [],
    clientInterest: activity?.clientInterest && activity.clientInterest !== 'Not Recorded' ? activity.clientInterest : '',
    meetingStatus: activity?.meetingStatus ?? '',
    remarks: activity?.remarks ?? '',
    newScheduleDate: '',
    newScheduleTime: '',
  };
};

const getPortfolioIdentity = (portfolio = {}) =>
  String(portfolio?.uuid ?? portfolio?.id ?? portfolio?.portfolioUUID ?? portfolio?.portfolio_uuid ?? '').trim();

const getPortfolioLabel = (portfolio = {}) =>
  [
    portfolio?.portfolio,
    [portfolio?.product, portfolio?.subProduct].filter(Boolean).join(' - '),
    portfolio?.portfolioCode,
    portfolio?.id,
  ].find((value) => String(value ?? '').trim()) ?? '';

const formatScheduleForApi = (dateValue, timeValue) => {
  const date = String(dateValue ?? '').trim();
  const time = String(timeValue ?? '').trim();
  if (!date || !time) return '';
  return `${date} ${time.length === 5 ? `${time}:00` : time}`;
};

const isActivityClosed = (activity = {}) => {
  const status = `${activity.meetingStatus ?? ''} ${activity.currentStatus ?? ''} ${activity.currentStatusCode ?? ''}`.toLowerCase();
  return status.includes('completed') || status.includes('closed');
};

const FIELD_ERROR_MESSAGES = {
  clientUUID: 'Select a client.',
  activityName: 'Enter activity details.',
  activityType: 'Select activity type.',
  meetingMode: 'Select meeting mode.',
  scheduleDate: 'Select schedule date.',
  scheduleTime: 'Select schedule time.',
  clientInterest: 'Select client interest.',
  meetingStatus: 'Select meeting status.',
  remarks: 'Enter remarks by client.',
  newScheduleDate: 'Select new schedule date.',
  newScheduleTime: 'Select new schedule time.',
};

const focusActivityField = (fieldName) => {
  if (!fieldName) return;
  window.setTimeout(() => {
    const wrapper = document.querySelector(`[data-activity-field="${fieldName}"]`);
    const target = wrapper?.querySelector('input:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
    wrapper?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    target?.focus?.({ preventScroll: true });
  }, 0);
};

const ActivityForm = ({ mode: modeProp, activity_uuid: activityUUIDProp }) => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const location = useLocation();
  const params = useParams();
  const activityUUID = activityUUIDProp ?? params.activity_uuid ?? '';
  const mode = modeProp ?? (activityUUID ? 'update' : 'create');
  const isUpdateMode = mode === 'update';
  const listQuery = useClientActivities(1, isUpdateMode ? { activityUUID } : {});
  const activityFromList = useMemo(
    () => (listQuery.data?.list ?? []).find((item) =>
      String(item.activityUUID || item.activity_uuid || item.id) === String(activityUUID)
    ),
    [activityUUID, listQuery.data?.list],
  );
  const selectedActivity = location.state?.activity ?? activityFromList ?? null;
  const activityIsClosed = isUpdateMode && isActivityClosed(selectedActivity);
  const rescheduleDateBounds = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
      min: toDateKey(addDays(today, 1)),
      max: toDateKey(addMonths(today, 3)),
    };
  }, []);

  const { data: activityTypeKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.activityType);
  const { data: meetingModeKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.meetingMode);
  const { data: meetingStatusKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.meetingStatus);
  const { data: clientInterestKdsOptions = [] } = useKdsOptions(ACTIVITY_KDS_FIELDS.clientInterest);

  const activityTypeOptions = useMemo(() => getOptionList(activityTypeKdsOptions, FALLBACK_ACTIVITY_TYPES), [activityTypeKdsOptions]);
  const meetingModeOptions = useMemo(() => getOptionList(meetingModeKdsOptions, FALLBACK_MEETING_MODES), [meetingModeKdsOptions]);
  const meetingStatusOptions = useMemo(() => getOptionList(meetingStatusKdsOptions, FALLBACK_MEETING_STATUSES), [meetingStatusKdsOptions]);
  const clientInterestOptions = useMemo(() => getOptionList(clientInterestKdsOptions, FALLBACK_CLIENT_INTERESTS), [clientInterestKdsOptions]);

  const initialForm = useMemo(() => {
    const next = getActivityFormState(isUpdateMode ? selectedActivity : null);
    next.activityType = findOptionCode(activityTypeOptions, next.activityType);
    next.meetingMode = findOptionCode(meetingModeOptions, next.meetingMode);
    next.meetingStatus = findOptionCode(meetingStatusOptions, next.meetingStatus);
    next.clientInterest = findOptionCode(clientInterestOptions, next.clientInterest);
    return next;
  }, [activityTypeOptions, clientInterestOptions, isUpdateMode, meetingModeOptions, meetingStatusOptions, selectedActivity]);

  const [form, setForm] = useState(initialForm);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState({});
  const [jointSearch, setJointSearch] = useState('');
  const [jointMenuOpen, setJointMenuOpen] = useState(false);
  const [jointUserOptions, setJointUserOptions] = useState([]);
  const [jointUsersLoading, setJointUsersLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [clientQuery, setClientQuery] = useState(initialForm.clientName);
  const [clientOptions, setClientOptions] = useState([]);
  const [clientLoading, setClientLoading] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [selectedPortfolio, setSelectedPortfolio] = useState(null);
  const [successOpen, setSuccessOpen] = useState(false);

  useEffect(() => {
    if (!isUpdateMode) return;
    setForm(initialForm);
  }, [initialForm, isUpdateMode]);

  useEffect(() => {
    if (!isUpdateMode) {
      setClientQuery(initialForm.clientName);
    }
  }, [initialForm.clientName, isUpdateMode]);

  useEffect(() => {
    if (isUpdateMode) return undefined;
    const trimmedQuery = clientQuery.trim();
    if (!trimmedQuery || selectedClient?.clientName === trimmedQuery) {
      setClientOptions([]);
      setClientLoading(false);
      return undefined;
    }

    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setClientLoading(true);
      try {
        const results = await searchClientsByName(trimmedQuery, { source: 'client' });
        if (!cancelled) setClientOptions(results);
      } finally {
        if (!cancelled) setClientLoading(false);
      }
    }, 350);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [clientQuery, isUpdateMode, selectedClient?.clientName]);

  const selectedClientUUID = selectedClient?.clientUUID || form.clientUUID || '';
  const { data: clientPortfolioOptions = [], isFetching: portfolioLoading } = usePortfolioListByClient(selectedClientUUID, {
    enabled: !isUpdateMode && Boolean(selectedClientUUID),
  });

  useEffect(() => {
    if (isUpdateMode || !selectedPortfolio) return;
    setForm((current) => ({
      ...current,
      portfolioName: getPortfolioLabel(selectedPortfolio),
      portfolioUUID: selectedPortfolio.uuid || selectedPortfolio.id || '',
    }));
  }, [isUpdateMode, selectedPortfolio]);

  useEffect(() => {
    const normalizedSearch = jointSearch.trim();
    if (!jointMenuOpen || normalizedSearch.length < 2) {
      setJointUserOptions([]);
      setJointUsersLoading(false);
      return undefined;
    }

    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setJointUsersLoading(true);
      try {
        const users = await searchCommonUsers(normalizedSearch);
        if (!cancelled) {
          setJointUserOptions(users.map(mapUserOption).filter((user) => user.id && user.name));
        }
      } catch {
        if (!cancelled) setJointUserOptions([]);
      } finally {
        if (!cancelled) setJointUsersLoading(false);
      }
    }, 300);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [jointMenuOpen, jointSearch]);

  const filteredJointUserOptions = useMemo(() => {
    const search = jointSearch.trim().toLowerCase();
    return jointUserOptions.filter((user) => {
      if (form.jointUsers.some((item) => getJointUserName(item) === user.name || String(getJointUserId(item)) === String(user.id))) return false;
      if (!search) return true;
      return `${user.name} ${user.email}`.toLowerCase().includes(search);
    });
  }, [form.jointUsers, jointSearch, jointUserOptions]);
  const showJointMenu = jointMenuOpen && (jointUsersLoading || filteredJointUserOptions.length > 0);

  const clearFieldError = (field) => {
    setFieldErrors((current) => {
      if (!current[field]) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
  };

  const change = (field) => (event) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    clearFieldError(field);
    setError('');
  };

  const validateForm = () => {
    const nextErrors = {};
    const requiredFields = isUpdateMode
      ? ['clientName', 'activityName', 'activityType', 'meetingMode', 'scheduleDate', 'scheduleTime']
      : ['clientUUID', 'activityName', 'activityType', 'meetingMode', 'scheduleDate', 'scheduleTime'];

    requiredFields.forEach((field) => {
      if (!String(form[field] ?? '').trim()) {
        nextErrors[field] = FIELD_ERROR_MESSAGES[field] ?? 'This field is required.';
      }
    });

    if (isUpdateMode && !activityIsClosed) {
      ['clientInterest', 'meetingStatus', 'remarks'].forEach((field) => {
        if (!String(form[field] ?? '').trim()) {
          nextErrors[field] = FIELD_ERROR_MESSAGES[field] ?? 'This field is required.';
        }
      });

      if (String(getOptionLabel(meetingStatusOptions, form.meetingStatus)).toLowerCase().includes('reschedule')) {
        if (!form.newScheduleDate) {
          nextErrors.newScheduleDate = FIELD_ERROR_MESSAGES.newScheduleDate;
        } else if (form.newScheduleDate < rescheduleDateBounds.min || form.newScheduleDate > rescheduleDateBounds.max) {
          nextErrors.newScheduleDate = 'Select a future date within the next 3 months.';
        }

        if (!form.newScheduleTime) {
          nextErrors.newScheduleTime = FIELD_ERROR_MESSAGES.newScheduleTime;
        }
      }
    }

    return nextErrors;
  };

  const goBack = () => navigate(encodedRoutePath(ROUTES.activities));
  const handleClientSelect = (_, client) => {
    setSelectedClient(client);
    setSelectedPortfolio(null);
    setClientQuery(client?.clientName ?? '');
    setForm((current) => ({
      ...current,
      clientName: client?.clientName ?? '',
      clientUUID: client?.clientUUID ?? '',
      portfolioName: '',
      portfolioUUID: '',
    }));
    clearFieldError('clientUUID');
    setError('');
  };
  const handleClientInputChange = (_, value, reason) => {
    setClientQuery(value);
    if (reason === 'input') {
      setSelectedClient(null);
      setSelectedPortfolio(null);
      setForm((current) => ({
        ...current,
        clientName: value,
        clientUUID: '',
        portfolioName: '',
        portfolioUUID: '',
      }));
      clearFieldError('clientUUID');
    }
  };
  const handlePortfolioSelect = (_, portfolio) => {
    setSelectedPortfolio(portfolio);
    setForm((current) => ({
      ...current,
      portfolioName: portfolio ? getPortfolioLabel(portfolio) : '',
      portfolioUUID: portfolio?.uuid || portfolio?.id || '',
    }));
    clearFieldError('portfolioUUID');
    setError('');
  };
  const addJointUser = (user) => {
    setForm((current) => ({
      ...current,
      jointUsers: current.jointUsers.some((item) => getJointUserName(item) === user.name || String(getJointUserId(item)) === String(user.id))
        ? current.jointUsers
        : [...current.jointUsers, { id: user.id, name: user.name }],
    }));
    setJointSearch('');
  };
  const removeJointUser = (name) => setForm((current) => ({
    ...current,
    jointUsers: current.jointUsers.filter((item) => getJointUserName(item) !== name),
  }));

  const buildCreatePayload = () => ({
    userid: getCurrentUserId(),
    message: 'Schedule a new client activity',
    payload: {
      activity: {
        client_uuid: form.clientUUID,
        portfolio_uuid: form.portfolioUUID || '',
        activity_name: form.activityName,
        activity_type_code: form.activityType,
        meeting_mode_code: form.meetingMode,
        client_interest_code: DEFAULT_CREATE_CLIENT_INTEREST_CODE,
        meeting_status_code: DEFAULT_CREATE_MEETING_STATUS_CODE,
        scheduled_at: formatScheduleForApi(form.scheduleDate, form.scheduleTime),
        remarks_by_client: '',
      },
      joint_users: form.jointUsers
        .map((user) => getJointUserId(user))
        .filter(Boolean)
        .map((userId) => ({ user_id: Number(userId) || userId })),
    },
  });

  const buildUpdatePayload = () => {
    const isReschedule = String(getOptionLabel(meetingStatusOptions, form.meetingStatus)).toLowerCase().includes('reschedule');
    return {
      userid: getCurrentUserId(),
      message: 'Update client activity',
      payload: {
        activity: {
          activity_uuid: activityUUID,
          meeting_status_code: form.meetingStatus,
          scheduled_at: isReschedule
            ? formatScheduleForApi(form.newScheduleDate, form.newScheduleTime)
            : formatScheduleForApi(form.scheduleDate, form.scheduleTime),
          client_interest_code: form.clientInterest,
          remarks_by_client: form.remarks,
        },
        joint_users: form.jointUsers
          .map((user) => getJointUserId(user))
          .filter(Boolean)
          .map((userId) => ({ user_id: Number(userId) || userId })),
      },
    };
  };

  const submit = async (event) => {
    event.preventDefault();
    if (isUpdateMode) {
      if (activityIsClosed) {
        setError('Completed or closed activities cannot be updated.');
        return;
      }
    }

    const nextErrors = validateForm();
    if (Object.keys(nextErrors).length) {
      setFieldErrors(nextErrors);
      setError('');
      focusActivityField(Object.keys(nextErrors)[0]);
      return;
    }

    setFieldErrors({});
    setError('');
    setSaving(true);
    try {
      await createClientActivity(isUpdateMode ? buildUpdatePayload() : buildCreatePayload());
      await invalidateClientActivitiesQueries(queryClient);
      setSuccessOpen(true);
    } catch (saveError) {
      setError(saveError?.message || 'Activity save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleViewActivities = () => {
    setSuccessOpen(false);
    navigate(encodedRoutePath(ROUTES.activities));
  };

  const handleViewDashboard = () => {
    setSuccessOpen(false);
    navigate(encodedRoutePath(ROUTES.dashboard));
  };

  return (
    <Box className="activity-mgmt-page client-mgmt-page activity-form-page">
      <ClientSaveSuccessDialog
        open={successOpen}
        isUpdate={isUpdateMode}
        title={isUpdateMode ? 'Activity Updated Successfully!' : 'Activity Created Successfully!'}
        message={isUpdateMode ? 'The client activity has been updated.' : 'The client activity has been scheduled.'}
        primaryLabel="View Client Activities"
        secondaryLabel="View Dashboard"
        onViewProfile={handleViewActivities}
        onReturnToList={handleViewDashboard}
      />
      <Box className="activity-form-page-head">
        <Box className="activity-form-page-title">
          <Button className="activity-form-back" onClick={goBack} aria-label="Back to activities">
            <ArrowBackRoundedIcon fontSize="small" />
          </Button>
          <Box>
            <Typography className="client-mgmt-title">{isUpdateMode ? 'Update Activity' : 'Create Activity'}</Typography>
            <Typography className="activity-page-subtitle">
              {isUpdateMode ? 'Record the meeting outcome or reschedule the activity.' : 'Schedule a client interaction and add joint-call users.'}
            </Typography>
          </Box>
        </Box>
      </Box>

      {isUpdateMode ? (
        <Box className="activity-form-context">
          <div><span>Client</span><strong>{selectedActivity?.clientName || '-'}</strong></div>
          <div><span>Scheduled</span><strong>{formatDate(selectedActivity?.scheduledAt)} {formatTime(selectedActivity?.scheduledAt)}</strong></div>
          <div><span>Meeting Status</span><strong>{selectedActivity?.meetingStatus || selectedActivity?.currentStatus || '-'}</strong></div>
          <div><span>Organizer</span><strong>{selectedActivity?.organizer?.name || selectedActivity?.createdByName || '-'}</strong></div>
        </Box>
      ) : null}

      {error ? <Box className="activity-form-error">{error}</Box> : null}

      <Box component="form" className="activity-form" onSubmit={submit}>
        <section className="activity-form-card">
          <Box className="activity-form-card-head">
            <EventAvailableRoundedIcon fontSize="small" />
            <Typography>Client & Activity</Typography>
          </Box>
          <Box className="activity-form-grid">
            <label className="activity-form-field activity-form-field--two" data-activity-field="clientUUID">
              <span>Client <em>*</em></span>
              {isUpdateMode ? (
                <TextField size="small" placeholder="Search and select client" value={form.clientName} onChange={change('clientName')} disabled />
              ) : (
                <Autocomplete
                  className="client-kds-autocomplete form-control-input border-radius-8"
                  options={clientOptions}
                  value={selectedClient}
                  inputValue={clientQuery}
                  loading={clientLoading}
                  autoHighlight
                  filterOptions={(options) => options}
                  getOptionLabel={(option) => option?.clientName ?? ''}
                  isOptionEqualToValue={(option, selected) => option.clientUUID === selected.clientUUID}
                  noOptionsText={clientLoading ? 'Searching clients...' : 'Type client name to search'}
                  onChange={handleClientSelect}
                  onInputChange={handleClientInputChange}
                  slotProps={{
                    paper: { className: 'client-kds-menu-paper' },
                    listbox: { className: 'client-kds-menu-list' },
                  }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      size="small"
                      placeholder="Search and select client"
                      error={!!fieldErrors.clientUUID}
                      helperText={fieldErrors.clientUUID}
                    />
                  )}
                  renderOption={(props, option) => {
                    const { key, className, ...optionProps } = props;
                    return (
                      <li key={key} {...optionProps} className={`${className ?? ''} client-kds-menu-item client-kds-menu-item--rich`}>
                        <Box className="activity-client-option">
                          <strong>{option.clientName}</strong>
                          <span>Owner: {option.primaryOwner || option.owner || '-'}</span>
                        </Box>
                      </li>
                    );
                  }}
                />
              )}
            </label>
            <label className="activity-form-field" data-activity-field="portfolioUUID">
              <span>Portfolio</span>
              {isUpdateMode ? (
                <TextField size="small" placeholder="Portfolio" value={form.portfolioName} onChange={change('portfolioName')} disabled />
              ) : (
                <Autocomplete
                  className="client-kds-autocomplete form-control-input border-radius-8"
                  options={clientPortfolioOptions}
                  value={selectedPortfolio}
                  loading={portfolioLoading}
                  disabled={!selectedClientUUID}
                  autoHighlight
                  getOptionLabel={getPortfolioLabel}
                  isOptionEqualToValue={(option, selected) => getPortfolioIdentity(option) === getPortfolioIdentity(selected)}
                  noOptionsText={portfolioLoading ? 'Loading portfolios...' : selectedClientUUID ? 'No portfolio found' : 'Select client first'}
                  onChange={handlePortfolioSelect}
                  slotProps={{
                    paper: { className: 'client-kds-menu-paper' },
                    listbox: { className: 'client-kds-menu-list' },
                  }}
                  renderInput={(params) => (
                    <TextField {...params} size="small" placeholder={selectedClientUUID ? 'Select portfolio' : 'Select client first'} />
                  )}
                  renderOption={(props, option) => {
                    const { key, className, ...optionProps } = props;
                    return (
                      <li key={key} {...optionProps} className={`${className ?? ''} client-kds-menu-item client-kds-menu-item--rich`}>
                        <Box className="activity-client-option">
                          <strong>{getPortfolioLabel(option)}</strong>
                          <span>Renewal: {option.renewalDate || '-'} | Owner: {option.owner || '-'}</span>
                        </Box>
                      </li>
                    );
                  }}
                />
              )}
            </label>
            <label className="activity-form-field activity-form-field--full" data-activity-field="activityName">
              <span>Activity <em>*</em></span>
              <TextField
                size="small"
                placeholder="Enter activity details"
                value={form.activityName}
                onChange={change('activityName')}
                disabled={isUpdateMode}
                error={!!fieldErrors.activityName}
                helperText={fieldErrors.activityName}
              />
            </label>
            <label className="activity-form-field" data-activity-field="activityType">
              <span>Activity Type <em>*</em></span>
              <TextField
                select
                size="small"
                value={form.activityType}
                onChange={change('activityType')}
                disabled={isUpdateMode}
                error={!!fieldErrors.activityType}
                helperText={fieldErrors.activityType}
              >
                {activityTypeOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
              </TextField>
            </label>
            <label className="activity-form-field" data-activity-field="meetingMode">
              <span>Meeting Mode <em>*</em></span>
              <TextField
                select
                size="small"
                value={form.meetingMode}
                onChange={change('meetingMode')}
                disabled={isUpdateMode}
                error={!!fieldErrors.meetingMode}
                helperText={fieldErrors.meetingMode}
              >
                {meetingModeOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
              </TextField>
            </label>
            <label className="activity-form-field" data-activity-field="scheduleDate">
              <span>Schedule Date <em>*</em></span>
              <TextField
                size="small"
                type="date"
                value={form.scheduleDate}
                onChange={change('scheduleDate')}
                disabled={isUpdateMode}
                error={!!fieldErrors.scheduleDate}
                helperText={fieldErrors.scheduleDate}
              />
            </label>
            <label className="activity-form-field" data-activity-field="scheduleTime">
              <span>Schedule Time <em>*</em></span>
              <TextField
                size="small"
                type="time"
                value={form.scheduleTime}
                onChange={change('scheduleTime')}
                disabled={isUpdateMode}
                error={!!fieldErrors.scheduleTime}
                helperText={fieldErrors.scheduleTime}
              />
            </label>
            <label className="activity-form-field activity-form-field--two">
              <span>Joint call with users</span>
              <Box className="activity-joint-combobox">
                <Box className="activity-joint-control">
                  {form.jointUsers.length ? (
                    <Box className="activity-joint-chips">
                      {form.jointUsers.map((user) => {
                        const name = getJointUserName(user);
                        return (
                        <span className="activity-joint-chip" key={name}>
                          <span>{name}</span>
                          <button type="button" onClick={() => removeJointUser(name)} aria-label={`Remove ${name}`}>
                            <CloseRoundedIcon fontSize="inherit" />
                          </button>
                        </span>
                      );
                      })}
                    </Box>
                  ) : null}
                  <Box className="activity-joint-search-row">
                    <GroupOutlinedIcon fontSize="small" />
                    <input
                      type="search"
                      value={jointSearch}
                      onChange={(event) => {
                        const nextValue = event.target.value;
                        setJointSearch(nextValue);
                        setJointMenuOpen(nextValue.trim().length >= 2);
                      }}
                      placeholder="Search and add users"
                    />
                    <button type="button" onClick={() => setJointMenuOpen((open) => !open)} aria-label="Show users">▾</button>
                  </Box>
                </Box>
                {showJointMenu ? (
                  <Box className="activity-joint-menu">
                    <Box className="activity-joint-list">
                      {jointUsersLoading ? <span className="activity-joint-empty">Searching users...</span> : filteredJointUserOptions.length ? filteredJointUserOptions.map((user) => (
                        <button type="button" className="activity-joint-option" key={user.id} onClick={() => addJointUser(user)}>
                          <span className="activity-joint-check" />
                          <span><strong>{user.name}</strong><small>{user.email || 'Email not available'}</small></span>
                          {user.role ? <em>{user.role}</em> : null}
                        </button>
                      )) : null}
                    </Box>
                  </Box>
                ) : null}
              </Box>
            </label>
          </Box>
        </section>

        {isUpdateMode && !activityIsClosed ? (
          <section className="activity-form-card">
            <Box className="activity-form-card-head">
              <CheckCircleOutlineRoundedIcon fontSize="small" />
              <Typography>Meeting Outcome</Typography>
            </Box>
            <Box className="activity-outcome-note">All outcome fields are mandatory. Select Reschedule to provide the new meeting date and time.</Box>
            <Box className="activity-form-grid">
              <label className="activity-form-field" data-activity-field="clientInterest">
                <span>Is Client Interested? <em>*</em></span>
                <TextField
                  select
                  size="small"
                  value={form.clientInterest}
                  onChange={change('clientInterest')}
                  error={!!fieldErrors.clientInterest}
                  helperText={fieldErrors.clientInterest}
                >
                  <MenuItem value="">Select client interest</MenuItem>
                  {clientInterestOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                </TextField>
              </label>
              <label className="activity-form-field" data-activity-field="meetingStatus">
                <span>Meeting Status <em>*</em></span>
                <TextField
                  select
                  size="small"
                  value={form.meetingStatus}
                  onChange={change('meetingStatus')}
                  error={!!fieldErrors.meetingStatus}
                  helperText={fieldErrors.meetingStatus}
                >
                  <MenuItem value="">Select meeting status</MenuItem>
                  {meetingStatusOptions.map((item) => <MenuItem key={item.code} value={item.code}>{item.value}</MenuItem>)}
                </TextField>
              </label>
              {String(getOptionLabel(meetingStatusOptions, form.meetingStatus)).toLowerCase().includes('reschedule') ? (
                <Box className="activity-reschedule-box activity-form-field--left-two">
                  <label className="activity-form-field" data-activity-field="newScheduleDate">
                    <span>New Schedule Date <em>*</em></span>
                    <TextField
                      size="small"
                      type="date"
                      value={form.newScheduleDate}
                      onChange={change('newScheduleDate')}
                      error={!!fieldErrors.newScheduleDate}
                      helperText={fieldErrors.newScheduleDate}
                      inputProps={{
                        min: rescheduleDateBounds.min,
                        max: rescheduleDateBounds.max,
                      }}
                    />
                  </label>
                  <label className="activity-form-field" data-activity-field="newScheduleTime">
                    <span>New Schedule Time <em>*</em></span>
                    <TextField
                      size="small"
                      type="time"
                      value={form.newScheduleTime}
                      onChange={change('newScheduleTime')}
                      error={!!fieldErrors.newScheduleTime}
                      helperText={fieldErrors.newScheduleTime}
                    />
                  </label>
                </Box>
              ) : null}
              <label className="activity-form-field activity-form-field--full" data-activity-field="remarks">
                <span>Remarks by Client <em>*</em></span>
                <TextField
                  multiline
                  minRows={4}
                  placeholder="Record the client's feedback or reason for rescheduling"
                  value={form.remarks}
                  onChange={change('remarks')}
                  error={!!fieldErrors.remarks}
                  helperText={fieldErrors.remarks}
                />
              </label>
            </Box>
          </section>
        ) : null}

        <Box className="activity-form-actions activity-form-page-actions">
          <Box>
            <Button className="client-mgmt-filter-clear-btn" onClick={goBack}>Cancel</Button>
            {!activityIsClosed ? (
              <Button type="submit" className="btn-common-red activity-form-save-btn" disabled={saving}>
                {saving ? 'Saving...' : isUpdateMode ? 'Save Update' : 'Schedule Activity'}
              </Button>
            ) : null}
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default ActivityForm;
