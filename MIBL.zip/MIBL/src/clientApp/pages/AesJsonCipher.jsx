import './AesJsonCipher.css';

const AesJsonCipher = () => (
  <div className="aes-json-cipher-page">
    <iframe
      className="aes-json-cipher-frame"
      src="/aes-json-cipher.html"
      title="AES-256 JSON Cipher"
    />
  </div>
);

export default AesJsonCipher;
