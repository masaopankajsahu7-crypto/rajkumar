import { useEffect, useMemo, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogContent,
  IconButton,
  InputAdornment,
  Paper,
  Popover,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import SyncAltOutlinedIcon from '@mui/icons-material/SyncAltOutlined';
import HighlightOffOutlinedIcon from '@mui/icons-material/HighlightOffOutlined';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import { crmConvertPath } from '../config/routes.js';
import { useCrmMigrationList } from '../hooks/useFetchQueries.js';
import { queryKeys } from '../lib/queryKeys.js';
import { rejectCrmMigrationOpportunity } from '../services/api.jsx';
import {
  CRM_MIGRATION_COLUMN_KEYS,
  CRM_MIGRATION_COLUMN_LABELS,
  getCrmMigrationTotalPages,
} from '../utils/crmMigration.js';
import { sanitizeByField } from '../utils/fieldUtils.js';
import { formatColumnLabel } from '../utils/labelFormat.js';
import { getOpportunityStatusToneClass } from '../config/opportunityStatusConfig.js';
import './Clients.css';
import './Renewals.css';
import './Opportunities.css';

const CRM_TABLE_COLUMNS = [...CRM_MIGRATION_COLUMN_KEYS, 'actions'];

const CRM_MESSAGES = {
  title: 'CRM Old Data Migration',
  search: 'Search CRM records...',
  noDataFound: 'No CRM records found',
  previousPage: 'Previous page',
  nextPage: 'Next page',
  totalRecords: (count) => `Total Records: ${count}`,
  pageOf: (totalPages) => `of ${totalPages}`,
};

const getPaginationItems = (page, totalPages) => {
  if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);

  const pages = new Set([1, totalPages, page - 1, page, page + 1]);
  const visiblePages = [...pages]
    .filter((pageNumber) => pageNumber >= 1 && pageNumber <= totalPages)
    .sort((first, second) => first - second);

  return visiblePages.reduce((items, pageNumber, index) => {
    const previousPage = visiblePages[index - 1];
    if (index > 0 && pageNumber - previousPage > 1) {
      items.push(`ellipsis-${previousPage}-${pageNumber}`);
    }
    items.push(pageNumber);
    return items;
  }, []);
};

const EllipsizedTooltipText = ({ value }) => {
  const text = String(value ?? '').trim();
  return (
    <Tooltip title={text} placement="top" arrow disableInteractive>
      <span className="opportunity-mgmt-tooltip-text">{text || '---'}</span>
    </Tooltip>
  );
};

const CrmStatus = ({ value }) => {
  const text = String(value ?? '').trim() || '---';
  return (
    <span className={`opportunity-mgmt-status-badge crm-migration-status ${getOpportunityStatusToneClass(text)}`}>
      {text}
    </span>
  );
};

const renderCrmCell = (header, row) => {
  const value = row?.[header];
  if (header === 'opportunity_status') return <CrmStatus value={value} />;
  if (header === 'client') {
    const client = String(row?.client ?? '').trim() || '---';
    const branch = String(row?.branch ?? '').trim();
    const tooltipText = branch ? `${client} · ${branch}` : client;

    return (
      <Tooltip title={tooltipText} placement="top" arrow disableInteractive>
        <span className="crm-migration-stack-cell">
          <span className="crm-migration-client-name">{client}</span>
          {branch ? <span className="crm-migration-stack-secondary">{branch}</span> : null}
        </span>
      </Tooltip>
    );
  }
  return <EllipsizedTooltipText value={value} />;
};

const CRM = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [searchInput, setSearchInput] = useState('');
  const [appliedSearch, setAppliedSearch] = useState('');
  const [actionAnchorEl, setActionAnchorEl] = useState(null);
  const [actionRow, setActionRow] = useState(null);
  const [rejectRow, setRejectRow] = useState(null);
  const [rejectSuccessOpen, setRejectSuccessOpen] = useState(false);
  const { data, isLoading, isFetching, isError, error } = useCrmMigrationList(page, appliedSearch);

  const records = data?.list ?? [];
  const totalCount = data?.totalCount ?? 0;
  const totalPages = useMemo(() => getCrmMigrationTotalPages(totalCount), [totalCount]);
  const paginationItems = useMemo(() => getPaginationItems(page, totalPages), [page, totalPages]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const nextSearch = searchInput.trim();
      setAppliedSearch((current) => (current === nextSearch ? current : nextSearch));
    }, 300);

    return () => window.clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    setPage(1);
  }, [appliedSearch]);

  const handlePageChange = (nextPage) => {
    if (nextPage === page || nextPage < 1 || nextPage > totalPages) return;
    setPage(nextPage);
  };

  const handleOpenActions = (row) => (event) => {
    setActionAnchorEl(event.currentTarget);
    setActionRow(row);
  };

  const handleCloseActions = () => {
    setActionAnchorEl(null);
    setActionRow(null);
  };

  const handleConvert = () => {
    const migrationRowId = actionRow?.migration_row_id;
    handleCloseActions();
    if (!migrationRowId) return;
    navigate(crmConvertPath(migrationRowId));
  };

  const handleDiscard = () => {
    setRejectRow(actionRow);
    handleCloseActions();
  };

  const rejectMutation = useMutation({
    mutationFn: () =>
      rejectCrmMigrationOpportunity({
        migrationRowId: rejectRow?.migration_row_id,
        ownerId: rejectRow?.user_id || undefined,
        convertRemarks: 'Rejected by business user',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.crmMigrationRoot() });
      setRejectRow(null);
      setRejectSuccessOpen(true);
    },
    onError: (mutationError) => {
      toast.error(mutationError?.message ?? 'CRM migration rejection failed');
    },
  });

  const handleCancelReject = () => {
    if (rejectMutation.isPending) return;
    setRejectRow(null);
  };

  const handleConfirmReject = () => {
    if (!rejectRow?.migration_row_id) return;
    rejectMutation.mutate();
  };

  return (
    <Box className="client-mgmt-page opportunity-mgmt-page crm-migration-page">
      <BackdropLoader loading={isLoading || isFetching || rejectMutation.isPending} />
      <ClientSaveSuccessDialog
        open={rejectSuccessOpen}
        title="CRM Record Rejected"
        message="CRM migration record has been rejected successfully."
        primaryLabel="Back to CRM"
        showSecondary={false}
        onViewProfile={() => setRejectSuccessOpen(false)}
      />
      <Paper className="client-mgmt-paper table-auto-width">
        <Box className="client-mgmt-head-block table-body-bg border-radius-top-8">
          <Box className="client-mgmt-toolbar client-mgmt-toolbar-head">
            <Box className="client-mgmt-toolbar-left">
              <Box className="client-mgmt-page-title-wrap">
                <Typography className="georama-SemiBold fs-24 client-mgmt-title">{CRM_MESSAGES.title}</Typography>
              </Box>
            </Box>
            <Box className="client-mgmt-toolbar-right">
              <TextField
                className="client-mgmt-search form-control-input"
                size="small"
                placeholder={CRM_MESSAGES.search}
                value={searchInput}
                onChange={(event) => setSearchInput(sanitizeByField('search', event.target.value))}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon fontSize="small" className="client-mgmt-search-icon" />
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
          </Box>
        </Box>

        <Popover
          open={Boolean(actionAnchorEl)}
          anchorEl={actionAnchorEl}
          onClose={handleCloseActions}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          className="renewals-actions-popover"
          slotProps={{ paper: { className: 'renewals-actions-paper crm-migration-actions-paper' } }}
        >
          <Box className="renewals-actions-title">CRM Actions</Box>
          <Button className="renewals-actions-item" onClick={handleConvert}>
            <SyncAltOutlinedIcon fontSize="small" />
            Convert
          </Button>
          <Button className="renewals-actions-item renewals-actions-item--danger" onClick={handleDiscard}>
            <HighlightOffOutlinedIcon fontSize="small" />
            Discard
          </Button>
        </Popover>

        <Dialog
          open={Boolean(rejectRow)}
          onClose={handleCancelReject}
          className="crm-reject-dialog"
          maxWidth="xs"
          fullWidth
        >
          <DialogContent className="crm-reject-dialog-content">
            <Box className="crm-reject-dialog-head">
              <Box className="crm-reject-dialog-icon">
                <WarningAmberRoundedIcon fontSize="small" />
              </Box>
              <Box className="crm-reject-dialog-title-block">
                <Typography className="crm-reject-dialog-title georama-SemiBold">
                  Reject CRM Record?
                </Typography>
                <Typography className="crm-reject-dialog-subtitle georama-Regular">
                  Please confirm before removing this migration record from pending conversion.
                </Typography>
              </Box>
              <IconButton className="crm-reject-dialog-close" onClick={handleCancelReject} disabled={rejectMutation.isPending}>
                <CloseIcon fontSize="small" />
              </IconButton>
            </Box>
            <Box className="crm-reject-dialog-summary">
              <span>Client</span>
              <strong>{rejectRow?.client || '---'}</strong>
              <span>Migration Row</span>
              <strong>{rejectRow?.migration_row_id || '---'}</strong>
            </Box>
            <Box className="crm-reject-dialog-alert">
              This action will mark the selected CRM migration record as rejected.
            </Box>
            <Box className="crm-reject-dialog-actions">
              <Button className="crm-reject-dialog-submit" onClick={handleConfirmReject} disabled={rejectMutation.isPending}>
                Reject
              </Button>
            </Box>
          </DialogContent>
        </Dialog>

        <TableContainer component={Box} className="client-mgmt-table-wrap opportunity-mgmt-table-wrap">
          <Table>
            <TableHead>
              <TableRow>
                {CRM_TABLE_COLUMNS.map((header) => (
                  <TableCell
                    key={header}
                    className={`client-mgmt-head-cell opportunity-mgmt-col-${header} georama-Medium fw-none`}
                  >
                    {header === 'actions' ? '' : formatColumnLabel(header, CRM_MIGRATION_COLUMN_LABELS)}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody className="table-body-bg">
              {records.length > 0 ? (
                records.map((row, rowIndex) => (
                  <TableRow key={row.migration_row_id ?? `${row.sr_no}-${rowIndex}`}>
                    {CRM_TABLE_COLUMNS.map((header) => (
                      <TableCell
                        key={`${rowIndex}-${header}`}
                        className={`p-4 georama-Regular fs-14 opportunity-mgmt-col-${header}`}
                      >
                        {header === 'actions' ? (
                          <Button className="renewals-action-btn" aria-label="CRM actions" onClick={handleOpenActions(row)}>
                            <MoreVertIcon fontSize="small" />
                          </Button>
                        ) : renderCrmCell(header, row)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={CRM_TABLE_COLUMNS.length} className="client-mgmt-no-data">
                    {isError ? error?.message ?? CRM_MESSAGES.noDataFound : CRM_MESSAGES.noDataFound}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {totalPages > 1 && (
          <Box className="client-mgmt-pagination-wrap table-body-bg border-radius-bottom-8">
            <Typography className="client-mgmt-total-count georama-Medium">
              {CRM_MESSAGES.totalRecords(totalCount)}
            </Typography>
            <Box className="client-mgmt-pagination">
              <Button
                className="client-mgmt-pagination-nav"
                disabled={page <= 1}
                onClick={() => handlePageChange(page - 1)}
                aria-label={CRM_MESSAGES.previousPage}
              >
                <ChevronLeftIcon fontSize="small" />
              </Button>

              <Box className="client-mgmt-pagination-pages">
                {paginationItems.map((item) =>
                  typeof item === 'number' ? (
                    <Button
                      key={item}
                      className={`client-mgmt-pagination-page ${
                        item === page ? 'client-mgmt-pagination-page-active' : ''
                      }`}
                      onClick={() => handlePageChange(item)}
                      aria-current={item === page ? 'page' : undefined}
                    >
                      {item}
                    </Button>
                  ) : (
                    <Typography key={item} className="client-mgmt-pagination-ellipsis">
                      ...
                    </Typography>
                  ),
                )}
              </Box>

              <Typography className="client-mgmt-pagination-label">{CRM_MESSAGES.pageOf(totalPages)}</Typography>

              <Button
                className="client-mgmt-pagination-nav"
                disabled={page >= totalPages}
                onClick={() => handlePageChange(page + 1)}
                aria-label={CRM_MESSAGES.nextPage}
              >
                <ChevronRightIcon fontSize="small" />
              </Button>
            </Box>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default CRM;
