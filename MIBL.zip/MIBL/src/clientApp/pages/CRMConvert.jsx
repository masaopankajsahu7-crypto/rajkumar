import { useEffect, useMemo, useState } from 'react';
import { Autocomplete, Box, Button, CircularProgress, FormHelperText, Paper, TextField, Typography } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import ClientNameSearchField from '../components/client/ClientNameSearchField.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import KdsSelect from '../components/common/KdsSelect.jsx';
import { queryKeys } from '../lib/queryKeys.js';
import { encodedRoutePath, ROUTES } from '../config/routes.js';
import { CLIENT_KDS_FIELDS, OPPORTUNITY_KDS_FIELDS } from '../config/kdsFields.js';
import { convertCrmMigrationOpportunity, getCrmMigrationRecord, getPincodeDetails, searchAssignableOwners } from '../services/api.jsx';
import { isSmeVertical } from '../utils/clientFormValidation.js';
import { getFieldMaxLength, isValidByField, sanitizeByField } from '../utils/fieldUtils.js';
import { getEncryptedRouteParam } from '../utils/encryptedRouteParams.js';
import './ClientsForm.css';
import './RenewalConvert.css';

const formatDateInput = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '';
  const ddMmYyyy = rawValue.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (ddMmYyyy) {
    const [, day, month, year] = ddMmYyyy;
    return `${year}-${month}-${day}`;
  }
  return rawValue.slice(0, 10);
};

const formatNumberInput = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '';
  const numberValue = Number(rawValue.replace(/[^\d.-]/g, ''));
  if (!Number.isFinite(numberValue)) return '';
  return String(numberValue);
};

const toNumber = (value) => {
  const numberValue = Number(String(value ?? '').replace(/[^\d.-]/g, ''));
  return Number.isFinite(numberValue) ? numberValue : 0;
};

const FINANCIAL_FIELD_LABELS = {
  sumInsured: 'Sum Insured',
  netPremium: 'Net Premium',
  brokerage: 'Brokerage Amount',
  reward: 'Reward Amount',
  totalIncome: 'Total Income',
};

const sanitizeDecimalInput = (value) => {
  const normalized = String(value ?? '').replace(/[^\d.]/g, '');
  const [whole, ...decimalParts] = normalized.split('.');
  return decimalParts.length ? `${whole}.${decimalParts.join('')}` : whole;
};

const isValidDecimalInput = (value) => /^\d+(\.\d+)?$/.test(String(value ?? '').trim());

const emptyForm = {
  clientUUID: '',
  clientName: '',
  vertical: '',
  clientType: 'CORPORATE',
  pincode: '',
  contactName: '',
  contactEmail: '',
  contactMobile: '',
  ownerId: '',
  ownerName: '',
  ownerCode: '',
  ownerEmail: '',
  ownerMobile: '',
  ownerBranch: '',
  product: '',
  subproduct: '',
  businessType: 'Renewal',
  previousPolicy: '',
  previousInsurer: '',
  policyStart: '',
  policyEnd: '',
  renewalDate: '',
  renewalDays: '',
  sumInsured: '',
  netPremium: '',
  brokerage: '',
  reward: '',
  totalIncome: '',
};

const mapRecordToForm = (lead = {}) => ({
  clientUUID: '',
  clientName: lead.client || '',
  vertical: lead.corporate_vertical || '',
  clientType: 'CORPORATE',
  pincode: '',
  contactName: '',
  contactEmail: '',
  contactMobile: '',
  ownerId: '',
  ownerName: lead.user_name || lead.owner || lead.created_by || '',
  ownerCode: '',
  ownerEmail: '',
  ownerMobile: '',
  ownerBranch: '',
  product: lead.product || '',
  subproduct: lead.sub_product || '',
  businessType: lead.type_of_business || 'Renewal',
  previousPolicy: lead.policy_number || lead.previous_policy_number || '',
  previousInsurer: lead.existing_lead_insurer || lead.insurer || '',
  policyStart: formatDateInput(lead.policy_start_date),
  policyEnd: formatDateInput(lead.policy_end_date),
  renewalDate: formatDateInput(lead.renewal_date),
  renewalDays: '',
  sumInsured: formatNumberInput(lead.sum_insured_limit),
  netPremium: formatNumberInput(lead.premium),
  brokerage: formatNumberInput(lead.brokerage),
  reward: formatNumberInput(lead.rewards),
  totalIncome: formatNumberInput(lead.total_income),
});

const CRMConvert = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { migrationRowId, encrypted } = useParams();
  const routeMigrationRowId =
    migrationRowId || getEncryptedRouteParam(encrypted, /^\/crm\/convert\/([^/]+)$/);
  const [form, setForm] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});
  const [pincodeInfo, setPincodeInfo] = useState({ city: '', state: '' });
  const [ownerOptions, setOwnerOptions] = useState([]);
  const [ownerSearch, setOwnerSearch] = useState('');
  const [ownersLoading, setOwnersLoading] = useState(false);
  const [successOpen, setSuccessOpen] = useState(false);
  const isSmeSelected = isSmeVertical(form.vertical);

  const { data: lead, isLoading, isFetching } = useQuery({
    queryKey: queryKeys.crmMigrationRecord(routeMigrationRowId),
    queryFn: () => getCrmMigrationRecord(routeMigrationRowId),
    enabled: Boolean(routeMigrationRowId),
  });

  useEffect(() => {
    if (!lead) return;
    const mappedForm = mapRecordToForm(lead);
    setForm(mappedForm);
    setOwnerSearch(mappedForm.ownerName);
  }, [lead]);

  useEffect(() => {
    if (form.vertical && !isSmeSelected && form.clientType !== 'CORPORATE') {
      setForm((prev) => ({ ...prev, clientType: 'CORPORATE' }));
    }
  }, [form.clientType, form.vertical, isSmeSelected]);

  useEffect(() => {
    if (!form.product && form.subproduct) {
      setForm((prev) => ({ ...prev, subproduct: '' }));
    }
  }, [form.product, form.subproduct]);

  useEffect(() => {
    const search = String(ownerSearch ?? '').trim();
    if (search.length < 2) {
      setOwnerOptions([]);
      setOwnersLoading(false);
      return undefined;
    }

    let cancelled = false;
    setOwnersLoading(true);
    const timer = window.setTimeout(async () => {
      try {
        const users = await searchAssignableOwners(search, { userType: 'SALES_RM', isHierarchy: 0 });
        if (!cancelled) setOwnerOptions(users);
      } catch (error) {
        if (!cancelled) {
          setOwnerOptions([]);
          toast.error(error?.message ?? 'Unable to load owner list');
        }
      } finally {
        if (!cancelled) setOwnersLoading(false);
      }
    }, 300);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [ownerSearch]);

  useEffect(() => {
    const pincode = String(form.pincode ?? '').trim();
    if (pincode.length !== 6) {
      setPincodeInfo({ city: '', state: '' });
      return undefined;
    }

    let cancelled = false;
    const loadPincodeDetails = async () => {
      const details = await getPincodeDetails(pincode);
      if (cancelled) return;
      setPincodeInfo({
        city: details?.city_name ?? '',
        state: details?.state_name ?? '',
      });
    };

    loadPincodeDetails();
    return () => {
      cancelled = true;
    };
  }, [form.pincode]);

  const summary = useMemo(() => ({
    code: lead?.migration_row_id ? `Migration Row ${lead.migration_row_id}` : 'Migration Record',
    client: lead?.client || '---',
    policy: lead?.policy_number || lead?.previous_policy_number || '---',
    renewal: form.renewalDate || '---',
    stage: String(lead?.opportunity_status || '---').replace(/_/g, ' '),
  }), [form.renewalDate, lead]);

  const handleChange = (field) => (event) => {
    const rawValue = event.target.value;
    const value = field === 'contactMobile'
      ? sanitizeByField('mobile', rawValue)
      : field === 'contactEmail'
        ? sanitizeByField('email', rawValue)
        : field === 'pincode'
          ? String(rawValue ?? '').replace(/\D/g, '').slice(0, 6)
          : Object.prototype.hasOwnProperty.call(FINANCIAL_FIELD_LABELS, field)
            ? sanitizeDecimalInput(rawValue)
            : rawValue;

    setForm((prev) => ({
      ...prev,
      [field]: value,
      ...(field === 'clientName' ? { clientUUID: '' } : {}),
    }));
    setFormErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const handleClientNameChange = (value) => {
    setForm((prev) => ({ ...prev, clientName: value, clientUUID: '' }));
    setFormErrors((prev) => ({ ...prev, clientName: '', clientUUID: '' }));
  };

  const handleClientSelect = (client) => {
    setForm((prev) => ({
      ...prev,
      clientName: client.clientName || prev.clientName,
      clientUUID: client.clientUUID || '',
    }));
    setFormErrors((prev) => ({ ...prev, clientName: '', clientUUID: '' }));
  };

  const handleSelectChange = (field) => (value) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
      ...(field === 'vertical' ? { clientType: isSmeVertical(value) ? prev.clientType : 'CORPORATE' } : {}),
      ...(field === 'product' ? { subproduct: '' } : {}),
    }));
    setFormErrors((prev) => ({
      ...prev,
      [field]: '',
      ...(field === 'vertical' ? { clientType: '' } : {}),
      ...(field === 'product' ? { subproduct: '' } : {}),
    }));
  };

  const validateForm = () => {
    const nextErrors = {};
    const requiredFields = [
      ['clientName', 'Client Name is required'],
      ['vertical', 'Vertical is required'],
      ['pincode', 'Pincode is required'],
      ['contactName', 'Contact Person Name is required'],
      ['contactMobile', 'Mobile is required'],
      ['contactEmail', 'Email is required'],
      ['product', 'Product is required'],
      ['subproduct', 'Sub-product is required'],
      ['businessType', 'Business Type is required'],
    ];
    if (isSmeSelected) requiredFields.push(['clientType', 'Client Type is required']);

    requiredFields.forEach(([field, message]) => {
      if (!String(form[field] ?? '').trim()) nextErrors[field] = message;
    });

    if (!String(form.ownerId ?? '').trim()) nextErrors.ownerName = 'Select an active owner from search';
    if (String(form.pincode ?? '').trim() && !/^\d{6}$/.test(String(form.pincode).trim())) {
      nextErrors.pincode = 'Pincode must be 6 digits';
    }
    if (String(form.contactMobile ?? '').trim() && !isValidByField('mobile', form.contactMobile)) {
      nextErrors.contactMobile = 'Mobile must be 10 digits';
    }
    if (String(form.contactEmail ?? '').trim() && !isValidByField('email', form.contactEmail)) {
      nextErrors.contactEmail = 'Enter a valid email address';
    }
    Object.entries(FINANCIAL_FIELD_LABELS).forEach(([field, label]) => {
      const rawValue = String(form[field] ?? '').trim();
      if (rawValue && !isValidDecimalInput(rawValue)) {
        nextErrors[field] = `${label} must be a valid number`;
      }
    });
    return nextErrors;
  };

  const convertMutation = useMutation({
    mutationFn: () =>
      convertCrmMigrationOpportunity({
        migrationRowId: routeMigrationRowId,
        ownerId: form.ownerId || form.ownerCode,
        convertRemarks: 'Converted by business user',
        client: {
          clientUUID: form.clientUUID,
          clientName: form.clientName,
          clientVerticalCode: form.vertical,
          clientTypeCode: isSmeSelected ? form.clientType : 'CORPORATE',
          pincode: form.pincode,
          branchName: '',
          contactName: form.contactName,
          contactMobile: form.contactMobile,
          contactEmail: form.contactEmail,
        },
        portfolio: {
          portfolioTypeCode: 'NEW',
          portfolioLobCode: 'CORPORATE',
          portfolioProductCode: form.product,
          portfolioSubProductCode: form.subproduct,
          expectedPremium: toNumber(form.netPremium),
          brokerageFee: toNumber(form.brokerage),
          rewardFee: toNumber(form.reward),
          renewalDate: form.renewalDate,
        },
        opportunity: {
          opportunityTypeCode: 'NEW_BUSINESS',
          opportunityStatusCode: 'OPEN',
          opportunityStageCode: 'OPPORTUNITY',
          allowedSlaDays: 7,
        },
        opportunityRemarks: 'Opportunity created from migration data entry',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.crmMigrationRoot() });
      queryClient.invalidateQueries({ queryKey: queryKeys.opportunitiesRoot() });
      setSuccessOpen(true);
    },
    onError: (error) => {
      const message = error?.message ?? 'CRM migration conversion failed';
      setFormErrors((prev) => ({ ...prev, submit: message }));
      toast.error(message);
    },
  });

  const handleConvert = () => {
    const nextErrors = validateForm();
    setFormErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    convertMutation.mutate();
  };

  const renderField = (field, label, { type = 'text', required = false, readOnly = false, className = '' } = {}) => (
    <Box className={`renewal-convert-field${className ? ` ${className}` : ''}`}>
      <Typography className="renewal-convert-label">
        {label} {required && <span>*</span>}
      </Typography>
      <TextField
        className={`form-control-input border-radius-8 renewal-convert-input${readOnly ? ' renewal-convert-input-readonly disabled-input' : ''}`}
        size="small"
        fullWidth
        type={type}
        value={form[field] ?? ''}
        onChange={handleChange(field)}
        error={!!formErrors[field]}
        InputProps={{ readOnly }}
        InputLabelProps={type === 'date' ? { shrink: true } : undefined}
        inputProps={{
          ...(field === 'contactMobile' ? { maxLength: getFieldMaxLength('mobile'), inputMode: 'numeric' } : {}),
          ...(field === 'contactEmail' ? { maxLength: getFieldMaxLength('email') } : {}),
          ...(field === 'pincode' ? { maxLength: 6, inputMode: 'numeric' } : {}),
          ...(Object.prototype.hasOwnProperty.call(FINANCIAL_FIELD_LABELS, field) ? { inputMode: 'decimal' } : {}),
        }}
      />
      {formErrors[field] && <FormHelperText className="important-fields">{formErrors[field]}</FormHelperText>}
    </Box>
  );

  const renderPincodeField = () => (
    <Box
      className={`renewal-convert-pincode-row renewal-convert-field-full${
        pincodeInfo.city || pincodeInfo.state ? ' renewal-convert-pincode-row--with-meta' : ''
      }`}
    >
      {renderField('pincode', 'Pincode', { required: true })}
      {pincodeInfo.city || pincodeInfo.state ? (
        <>
          <Box className="renewal-convert-pincode-meta">
            <Typography className="renewal-convert-pincode-meta-label">City</Typography>
            <Typography className="renewal-convert-pincode-meta-value">{pincodeInfo.city}</Typography>
          </Box>
          <Box className="renewal-convert-pincode-meta">
            <Typography className="renewal-convert-pincode-meta-label">State</Typography>
            <Typography className="renewal-convert-pincode-meta-value">{pincodeInfo.state}</Typography>
          </Box>
        </>
      ) : null}
    </Box>
  );

  const renderKdsField = (
    field,
    label,
    config,
    {
      required = false,
      className = '',
      parentCode = '',
      cascade = false,
      disabled = false,
      placeholder,
      onResolvedOption,
    } = {},
  ) => (
    <Box className={`renewal-convert-field${className ? ` ${className}` : ''}`}>
      <KdsSelect
        {...config}
        label={label}
        value={form[field] ?? ''}
        onChange={handleSelectChange(field)}
        required={required}
        parentCode={parentCode}
        cascade={cascade}
        disabled={disabled}
        placeholder={placeholder}
        error={formErrors[field]}
        onResolvedOption={onResolvedOption}
      />
    </Box>
  );

  const selectedOwnerOption = ownerOptions.find((option) => String(option.code) === String(form.ownerId)) ?? null;

  const handleOwnerSelect = (_, selected) => {
    const ownerName = selected?.full_name ?? selected?.key_value ?? selected?.value ?? '';
    setOwnerSearch(ownerName);
    setForm((prev) => ({
      ...prev,
      ownerId: selected?.userid ?? selected?.key_code ?? selected?.code ?? '',
      ownerName,
      ownerCode: selected?.sap_code ?? '',
      ownerEmail: selected?.email_id ?? '',
      ownerMobile: selected?.mobile_no ?? '',
      ownerBranch: '',
    }));
    setFormErrors((prev) => ({ ...prev, ownerName: '' }));
  };

  const renderOwnerSearchField = () => (
    <Box className="renewal-convert-field renewal-convert-field-full">
      <Typography className="renewal-convert-label">
        Owner Name <span>*</span>
      </Typography>
      <Autocomplete
        className="client-kds-autocomplete form-control-input border-radius-8"
        options={ownerOptions}
        value={selectedOwnerOption}
        inputValue={ownerSearch}
        loading={ownersLoading}
        autoHighlight
        filterOptions={(options) => options}
        getOptionLabel={(option) => option?.full_name ?? option?.key_value ?? option?.value ?? ''}
        isOptionEqualToValue={(option, selected) => String(option.code) === String(selected.code)}
        noOptionsText={ownerSearch.trim().length < 2 ? 'Search by name or SAP' : 'No users found'}
        onInputChange={(_, value, reason) => {
          if (reason === 'reset') return;
          setOwnerSearch(value);
          if (form.ownerId) {
            setForm((prev) => ({
              ...prev,
              ownerId: '',
              ownerName: value,
              ownerCode: '',
              ownerEmail: '',
              ownerMobile: '',
              ownerBranch: '',
            }));
          }
          setFormErrors((prev) => ({ ...prev, ownerName: '' }));
        }}
        onChange={handleOwnerSelect}
        renderInput={(params) => (
          <TextField
            {...params}
            size="small"
            placeholder="Search by name or SAP"
            error={!!formErrors.ownerName}
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <>
                  {ownersLoading ? <CircularProgress color="inherit" size={16} /> : null}
                  {params.InputProps.endAdornment}
                </>
              ),
            }}
          />
        )}
        renderOption={(props, option) => {
          const { key, ...optionProps } = props;
          return (
            <li key={key} {...optionProps} className="client-kds-menu-item client-kds-menu-item--simple">
              <Box>
                <Typography className="georama-Medium fs-14">
                  {option?.full_name ?? option?.key_value ?? option?.value}
                </Typography>
                <Typography className="georama-Regular fs-12 color-light">
                  {option?.sap_code ? `${option.sap_code} · ` : ''}{option?.email_id ?? ''}
                </Typography>
              </Box>
            </li>
          );
        }}
      />
      {formErrors.ownerName ? (
        <FormHelperText className="important-fields">{formErrors.ownerName}</FormHelperText>
      ) : (
        <FormHelperText className="renewal-convert-action-note">
          Search by name or SAP.
        </FormHelperText>
      )}
    </Box>
  );

  return (
    <Box className="client-form-page renewal-convert-page">
      <BackdropLoader loading={isLoading || isFetching || convertMutation.isPending} />
      <ClientSaveSuccessDialog
        open={successOpen}
        title="CRM Record Converted Successfully"
        message="CRM migration record has been converted to opportunity successfully."
        primaryLabel="Back to CRM"
        showSecondary={false}
        onViewProfile={() => navigate(encodedRoutePath(ROUTES.crm))}
      />
      <Paper className="client-form-paper table-auto-width renewal-convert-paper">
        <Box className="client-form-body">
          <Box className="client-form-header renewal-convert-head">
            <Box>
              <Typography className="georama-SemiBold fs-24 client-form-title renewal-convert-title">
                CRM Old Data Migration
              </Typography>
              <Typography className="renewal-convert-subtitle">
                Review CRM migration information and complete the opportunity details.
              </Typography>
            </Box>
            <Box className="renewal-convert-head-actions">
              <Button
                className="text-capitalize georama-medium-selected custom-starticon client-form-back-btn"
                startIcon={<ArrowBackIcon />}
                onClick={() => navigate(encodedRoutePath(ROUTES.crm))}
              >
                Back
              </Button>
            </Box>
          </Box>
          <Box className="client-form-header-divider" />

          {!isLoading && !lead ? (
            <Paper className="renewal-convert-empty">
              <Typography className="renewal-convert-title">No CRM record selected</Typography>
              <Button className="btn-common-red border-radius-32" onClick={() => navigate(encodedRoutePath(ROUTES.crm))}>
                Back to CRM
              </Button>
            </Paper>
          ) : (
            <>
              <Box className="renewal-convert-source-strip">
                <Box><span>Renewal Client</span><strong>{summary.client}</strong></Box>
                <Box><span>Previous Policy</span><strong>{summary.policy}</strong></Box>
                <Box><span>Renewal Date</span><strong>{summary.renewal}</strong></Box>
                <Box><span>Renewal Stage</span><strong>{summary.stage}</strong></Box>
              </Box>

              <Box className="renewal-convert-grid">
                <Box className="renewal-convert-card-row">
                  <Paper className="renewal-convert-card">
                    <Typography className="renewal-convert-card-title">Client Details</Typography>
                    <Box className="renewal-convert-form-grid renewal-convert-client-grid">
                      <Box className="renewal-convert-field renewal-convert-field-full">
                        <ClientNameSearchField
                          label="Client Name"
                          value={form.clientName}
                          onChange={handleClientNameChange}
                          onSelectExistingClient={handleClientSelect}
                          placeholder="Type client name"
                          required
                          error={!!formErrors.clientName}
                          errorMessage={formErrors.clientName}
                          searchEnabled
                          showAvailabilityStatus={false}
                        />
                      </Box>
                      {renderKdsField('vertical', 'Vertical', CLIENT_KDS_FIELDS.vertical, { required: true })}
                      {renderKdsField('clientType', 'Client Type', CLIENT_KDS_FIELDS.clientType, {
                        required: isSmeSelected,
                        disabled: !isSmeSelected,
                        placeholder: isSmeSelected ? 'Select Client Type' : 'Select SME vertical first',
                      })}
                      {renderPincodeField()}
                      {renderField('contactName', 'Contact Person Name', { required: true, className: 'renewal-convert-field-full' })}
                      {renderField('contactMobile', 'Mobile', { required: true })}
                      {renderField('contactEmail', 'Email', { required: true })}
                    </Box>
                  </Paper>

                  <Paper className="renewal-convert-card">
                    <Typography className="renewal-convert-card-title">Owner Details</Typography>
                    <Box className="renewal-convert-form-grid">
                      {renderOwnerSearchField()}
                      {renderField('ownerCode', 'Employee Code', { readOnly: true })}
                      {renderField('ownerEmail', 'Email', { readOnly: true })}
                      {renderField('ownerMobile', 'Mobile', { readOnly: true })}
                    </Box>
                  </Paper>
                </Box>

                <Box className="renewal-convert-card-row">
                  <Paper className="renewal-convert-card">
                    <Typography className="renewal-convert-card-title">Opportunity Details</Typography>
                    <Box className="renewal-convert-form-grid">
                      {renderKdsField('product', 'Product', OPPORTUNITY_KDS_FIELDS.product, {
                        required: true,
                        onResolvedOption: (option) => {
                          if (option?.code && form.product !== option.code) {
                            setForm((prev) => ({ ...prev, product: option.code }));
                          }
                        },
                      })}
                      {renderKdsField('subproduct', 'Sub-product', OPPORTUNITY_KDS_FIELDS.subProduct, {
                        required: true,
                        parentCode: form.product,
                        cascade: true,
                        disabled: !form.product,
                        onResolvedOption: (option) => {
                          if (option?.code && form.subproduct !== option.code) {
                            setForm((prev) => ({ ...prev, subproduct: option.code }));
                          }
                        },
                      })}
                      {renderKdsField('businessType', 'Business Type', OPPORTUNITY_KDS_FIELDS.businessType, { required: true })}
                    </Box>
                  </Paper>

                  <Paper className="renewal-convert-card">
                    <Typography className="renewal-convert-card-title">Previous Policy Details</Typography>
                    <Box className="renewal-convert-form-grid">
                      {renderField('previousPolicy', 'Previous Policy No.')}
                      {renderKdsField('previousInsurer', 'Previous Insurer', OPPORTUNITY_KDS_FIELDS.previousInsurer)}
                      {renderField('policyStart', 'Policy Start Date', { type: 'date' })}
                      {renderField('policyEnd', 'Policy End Date', { type: 'date' })}
                      {renderField('renewalDate', 'Renewal Date', { type: 'date' })}
                      {renderField('renewalDays', 'Renewal Days')}
                    </Box>
                  </Paper>
                </Box>

                <Paper className="renewal-convert-card renewal-convert-card-full">
                  <Typography className="renewal-convert-card-title">Previous Policy Financials</Typography>
                  <Box className="renewal-convert-form-grid renewal-convert-form-grid-five">
                    {renderField('sumInsured', 'Sum Insured')}
                    {renderField('netPremium', 'Net Premium')}
                    {renderField('brokerage', 'Brokerage Amount')}
                    {renderField('reward', 'Reward Amount')}
                    {renderField('totalIncome', 'Total Income')}
                  </Box>
                </Paper>
              </Box>

              <Box className="renewal-convert-actions">
                <Typography className={`renewal-convert-action-note${formErrors.submit ? ' important-fields' : ''}`}>
                  {formErrors.submit || 'Fields marked with * are required before conversion.'}
                </Typography>
                <Box className="renewal-convert-action-buttons">
                  <Button className="renewal-convert-cancel" onClick={() => navigate(encodedRoutePath(ROUTES.crm))}>Cancel</Button>
                  <Button
                    className="btn-common-red border-radius-32 renewal-convert-submit"
                    onClick={handleConvert}
                    disabled={convertMutation.isPending}
                  >
                    <SwapHorizIcon fontSize="small" />
                    Convert to Opportunity
                  </Button>
                </Box>
              </Box>
            </>
          )}
        </Box>
      </Paper>
    </Box>
  );
};

export default CRMConvert;
