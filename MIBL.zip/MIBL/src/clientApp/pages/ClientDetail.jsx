import { useEffect, useRef, useState } from 'react';
import { Box, Button, CircularProgress, Dialog, IconButton, Paper, Switch, Typography } from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import { useQueryClient } from '@tanstack/react-query';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { CLIENT_DETAIL_MESSAGES as MSG } from '../config/messages/clientDetail.js';
import { ROUTES, clientsEditPath, encodedRoutePath } from '../config/routes.js';
import { mapClientDetailFromApi } from '../utils/clientDetailMock.js';
import { mapClientRecordToFormDraft } from '../utils/clientFormState.js';
import { useClientByUuid } from '../hooks/useFetchQueries.js';
import { invalidateBusinessDataQueries, invalidateClientQueries } from '../lib/queryClient.js';
import { reassignClientOwners, updateClient } from '../services/api.jsx';
import { queryKeys } from '../lib/queryKeys.js';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import ClientPortfolios from '../components/client/ClientPortfolios.jsx';
import ClientOpportunities from '../components/client/ClientOpportunities.jsx';
import ClientApproval from '../components/client/ClientApproval.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import ReassignOwnerDialog from '../components/client/ReassignOwnerDialog.jsx';
import { isClientApproved } from '../utils/clientStatus.js';
import { getEncryptedRouteParam } from '../utils/encryptedRouteParams.js';
import './ClientDetail.css';

const HeaderField = ({ label, value, meta, editable = false, onEdit }) => (
  <Box className="client-detail-header-row">
    <Typography className="client-detail-header-label georama-Regular">{label}</Typography>
    <Box>
      <Typography className="client-detail-header-value georama-Medium">{value}</Typography>
      {meta && (
        <Typography className="client-detail-header-meta georama-Regular">{meta}</Typography>
      )}
    </Box>
    {editable ? (
      <IconButton
        size="small"
        className="client-detail-header-edit"
        aria-label={`Edit ${label}`}
        onClick={onEdit}
      >
        <EditOutlinedIcon fontSize="inherit" />
      </IconButton>
    ) : (
      <Box />
    )}
  </Box>
);

const DetailField = ({ label, value, note }) => (
  <Box className="client-detail-field">
    <Typography className="client-detail-field-label georama-Regular">{label}</Typography>
    <Box>
      <Typography className="client-detail-field-value georama-Regular">{value || '—'}</Typography>
      {note && (
        <Typography component="span" className="client-detail-field-note georama-Regular">
          {note}
        </Typography>
      )}
    </Box>
  </Box>
);

const formatOwnerList = (owners = []) => {
  if (!Array.isArray(owners)) return String(owners || '').trim();
  return owners
    .map((owner) =>
      String(
        owner?.username ??
          owner?.owner_name ??
          owner?.key_value ??
          owner?.full_name ??
          owner?.name ??
          owner?.value ??
          owner?.user_name ??
          owner ??
          '',
      ).trim(),
    )
    .filter(Boolean)
    .join(', ');
};

const formatClientName = (name) =>
  String(name ?? '')
    .trim()
    .split(/\s+/)
    .map((word) => {
      if (/^[A-Z0-9&.-]+$/.test(word) && word.length > 1) return word;
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    })
    .join(' ');

const ClientDetail = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();
  const { clientUUID, encrypted } = useParams();
  const routeClientUUID = clientUUID || getEncryptedRouteParam(encrypted, /^\/clients\/([^/]+)$/);
  const reassignOwnerSectionRef = useRef(null);
  const listRow = location.state?.listRow;
  const activeMenu = location.state?.activeMenu ?? 'Clients';
  const showReassignOwnerSection = Boolean(location.state?.showReassignOwner);
  const [reassignOwnerOpen, setReassignOwnerOpen] = useState(showReassignOwnerSection);
  const [activeUpdating, setActiveUpdating] = useState(false);
  const [activeOverride, setActiveOverride] = useState(null);
  const [activeError, setActiveError] = useState('');
  const [deactivateConfirmOpen, setDeactivateConfirmOpen] = useState(false);
  const [reassignSuccessOpen, setReassignSuccessOpen] = useState(false);

  // Real client data from /clients/get. Portfolios & Opportunities stay dummy (mapper handles it).
  const { data: clientResponse, isLoading, isFetching } = useClientByUuid(routeClientUUID);
  const profile = mapClientDetailFromApi(clientResponse, routeClientUUID, listRow);
  const displayClientName = formatClientName(profile.clientName);

  const canApprove = Boolean(profile.canApprove);
  const canEdit = Boolean(profile.canEdit);
  const canEditOwner = Boolean(profile.canEditOwner);
  const canView = Boolean(profile.canView);
  const canToggleActive = Boolean(profile.canToggleActive);
  const isPending = String(profile.status || '').toLowerCase() === 'pending';
  const isRejected = String(profile.status || '').toLowerCase() === 'rejected';
  const canReviewPendingClient = isPending && canApprove;
  const isApproved = isClientApproved(profile.status);
  const shouldCheckSimilarClients = canReviewPendingClient;
  const notice = isRejected ? MSG.rejectedNotice : MSG.pendingNotice;
  const isActiveChecked = activeOverride ?? (String(profile.isActive) === '1');
  const canCreateClientChildren = isApproved && isActiveChecked;

  useEffect(() => {
    if (!showReassignOwnerSection) return;
    setReassignOwnerOpen(true);
    window.setTimeout(() => {
      reassignOwnerSectionRef.current?.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }, 100);
  }, [showReassignOwnerSection]);

  const handleBack = () => {
    navigate(encodedRoutePath(ROUTES.clients));
  };

  const handleEditClient = () => {
    navigate(clientsEditPath(routeClientUUID), { state: { listRow } });
  };

  const handleEditContacts = () => {
    navigate(clientsEditPath(routeClientUUID), { state: { listRow, focusContact: true } });
  };

  const handleOwnerEditClick = () => {
    setReassignOwnerOpen(true);
    window.setTimeout(() => {
      reassignOwnerSectionRef.current?.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }, 100);
  };

  const handleCloseReassignOwnerSection = () => {
    setReassignOwnerOpen(false);
    navigate(location.pathname, {
      replace: true,
      state: { listRow, activeMenu },
    });
  };

  const handleCommitClientOwnerReassign = async ({ owner, coOwners, remarks }) => {
    await reassignClientOwners({
      clientUUID: routeClientUUID,
      owner,
      coOwners,
      remarks,
    });
    await invalidateBusinessDataQueries(queryClient);
    handleCloseReassignOwnerSection();
    setReassignSuccessOpen(true);
  };

  const handleAddOpportunity = () => {
    navigate(encodedRoutePath(ROUTES.opportunitiesCreate), {
      state: {
        source: 'clientDashboard',
        activeMenu,
        selectedClient: {
          clientUUID: routeClientUUID,
          clientName: profile.clientName,
          primaryOwner: profile.primaryOwner,
        },
      },
    });
  };

  const handleAddPortfolio = () => {
    const mappedDraft = mapClientRecordToFormDraft(clientResponse, listRow);
    if (!mappedDraft) return;

    navigate(encodedRoutePath(ROUTES.clientsCreatePortfolio), {
      state: {
        clientDraft: mappedDraft,
        fromClientList: true,
        returnPath: location.pathname,
        activeMenu,
      },
    });
  };

  const updateActiveStatus = async (nextIsActive) => {
    const draft = mapClientRecordToFormDraft(clientResponse, listRow);
    if (!draft || activeUpdating) return;

    setActiveUpdating(true);
    setActiveError('');
    try {
      await updateClient(routeClientUUID, {
        ...draft,
        active: nextIsActive ? 1 : 0,
      });

      setActiveOverride(nextIsActive);
      queryClient.setQueryData(queryKeys.client(routeClientUUID), (current) => {
        if (!current?.payload) return current;
        return {
          ...current,
          payload: {
            ...current.payload,
            client: {
              ...current?.payload?.client,
              active: nextIsActive ? 1 : 0,
            },
          },
        };
      });
      invalidateClientQueries(queryClient);
    } catch (error) {
      setActiveError(error?.message || 'Active status update failed');
    } finally {
      setActiveUpdating(false);
    }
  };

  const handleActiveToggle = (event) => {
    if (!canToggleActive) return;
    const nextIsActive = event.target.checked;
    if (!nextIsActive) {
      setDeactivateConfirmOpen(true);
      return;
    }

    updateActiveStatus(true);
  };

  const handleDeactivateCancel = () => {
    setDeactivateConfirmOpen(false);
  };

  const handleDeactivateConfirm = () => {
    if (!canToggleActive) return;
    setDeactivateConfirmOpen(false);
    updateActiveStatus(false);
  };

  return (
    <Box className="client-detail-page">
      <BackdropLoader loading={isLoading || isFetching} />
      <Dialog
        open={deactivateConfirmOpen}
        onClose={activeUpdating ? undefined : handleDeactivateCancel}
        className="client-detail-confirm-dialog"
      >
        <div className="client-detail-confirm-dialog__content">
          <span className="client-detail-confirm-dialog__icon-wrap">
            <WarningAmberRoundedIcon className="client-detail-confirm-dialog__icon" />
          </span>
          <Typography className="client-detail-confirm-dialog__title georama-SemiBold">
            Deactivate Client?
          </Typography>
          <Typography className="client-detail-confirm-dialog__message georama-Regular">
            This client will be marked inactive and may not be available for new business actions.
            You can activate it again later from this profile.
          </Typography>
          <Button
            className="client-detail-confirm-dialog__btn client-detail-confirm-dialog__btn--primary"
            onClick={handleDeactivateConfirm}
            disabled={activeUpdating}
          >
            Yes, Deactivate
          </Button>
          <Button
            className="client-detail-confirm-dialog__btn client-detail-confirm-dialog__btn--secondary"
            onClick={handleDeactivateCancel}
            disabled={activeUpdating}
          >
            Cancel
          </Button>
        </div>
      </Dialog>
      <Paper className="client-detail-paper table-auto-width">
        <Box className="client-detail-body">
          <Box className="client-detail-topbar">
            <Typography className="client-detail-title georama-SemiBold">
              {canApprove ? MSG.approvalTitle : MSG.title}
            </Typography>
            <Button
              className="text-capitalize georama-medium-selected custom-starticon client-detail-back-btn"
              startIcon={<ChevronLeftIcon />}
              onClick={handleBack}
            >
              {MSG.back}
            </Button>
          </Box>

          <Box className="client-detail-header">
            <Box className="client-detail-header-grid">
              <Box className="client-detail-header-client-highlight">
                <Box className="client-detail-header-client-name-row">
                  <Typography className="client-detail-header-client-name georama-SemiBold">
                    {displayClientName}
                  </Typography>
                  <Box className="client-detail-header-client-actions">
                    <Box className="client-detail-active-control">
                      <Typography className="client-detail-active-label georama-Regular">
                        Active
                      </Typography>
                      {activeUpdating ? (
                        <CircularProgress className="client-detail-active-loader" size={18} />
                      ) : (
                        <Switch
                          checked={isActiveChecked}
                          onChange={handleActiveToggle}
                          color="success"
                          size="small"
                          disabled={!canToggleActive}
                          inputProps={{ 'aria-label': 'Active' }}
                        />
                      )}
                    </Box>
                    {canEdit ? (
                      <Button
                        size="small"
                        className="client-detail-header-client-edit"
                        aria-label={MSG.editAria(profile.clientName)}
                        startIcon={<EditOutlinedIcon />}
                        onClick={handleEditClient}
                      >
                        {MSG.edit}
                      </Button>
                    ) : null}
                  </Box>
                </Box>
                {activeError ? (
                  <Typography className="client-detail-active-error georama-Regular">
                    {activeError}
                  </Typography>
                ) : null}
                <Typography className="client-detail-header-client-meta georama-Regular">
                  {profile.clientCode}{profile.codeDate ? ` (${profile.codeDate})` : ''}
                </Typography>
              </Box>

              <Box className="client-detail-header-col client-detail-header-col--meta">
                <HeaderField
                  label={MSG.header.owner}
                  value={profile.primaryOwner}
                  editable={canEditOwner}
                  onEdit={handleOwnerEditClick}
                />
                <HeaderField
                  label={MSG.header.coOwner}
                  value={formatOwnerList(profile.coOwners)}
                  editable={canEditOwner}
                  onEdit={handleOwnerEditClick}
                />
                <HeaderField
                  label={MSG.header.approved}
                  value={profile.approvedBy}
                  meta={profile.approvedDate ? `(${profile.approvedDate})` : ''}
                />
              </Box>
            </Box>
          </Box>

          {canView ? (
            <Box className="client-detail-layout">
              <Box className="client-detail-left">
                <Box className="client-detail-card">
                  <Box className="client-detail-card-head">
                    <Typography className="client-detail-card-title georama-SemiBold">
                      {displayClientName}
                    </Typography>
                    <span className="client-detail-status-badge client-detail-status-badge--approved">
                      {canApprove ? MSG.reviewMode : MSG.viewOnly}
                    </span>
                  </Box>
                  <Box className="client-detail-card-body">
                    <DetailField label={MSG.labels.clientCode} value={profile.clientCode} />
                    <DetailField label={MSG.labels.type} value={profile.clientType} />
                    <DetailField label={MSG.labels.vertical} value={profile.vertical} />
                  </Box>
                </Box>

                <Box className="client-detail-card">
                  <Box className="client-detail-card-head">
                    <Typography className="client-detail-card-title georama-SemiBold">
                      {MSG.contactsTitle(profile.contacts.length)}
                    </Typography>
                    {canEdit ? (
                      <Box className="client-detail-card-actions">
                        <Button
                          className="client-detail-add-btn client-detail-add-btn--green"
                          onClick={handleEditContacts}
                        >
                          {MSG.addContact}
                        </Button>
                        <Button
                          className="client-detail-edit-btn"
                          startIcon={<EditOutlinedIcon />}
                          onClick={handleEditContacts}
                        >
                          {MSG.edit}
                        </Button>
                      </Box>
                    ) : null}
                  </Box>
                  <Box className="client-detail-card-body">
                    <Box className="client-detail-contacts-list">
                      {profile.contacts.map((contact) => (
                        <Box key={`${contact.email}-${contact.mobile}`} className="client-detail-contact-item">
                          <Typography className="client-detail-contact-name georama-Medium">
                            {contact.name}
                          </Typography>
                          <Typography className="client-detail-contact-line georama-Regular">
                            {MSG.labels.mobile}: {contact.mobile}
                          </Typography>
                          <Typography className="client-detail-contact-line georama-Regular">
                            {MSG.labels.email}: {contact.email}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  </Box>
                </Box>

                <Box className="client-detail-card">
                  <Box className="client-detail-card-head">
                    <Typography className="client-detail-card-title georama-SemiBold">
                      {MSG.sections.addressStatutory}
                    </Typography>
                  </Box>
                  <Box className="client-detail-card-body">
                    <DetailField label={MSG.labels.address} value={profile.address.line} />
                    <DetailField label={MSG.labels.pincode} value={profile.address.pincode} />
                    <DetailField label={MSG.labels.city} value={profile.address.city} />
                    <DetailField label={MSG.labels.gstin} value={profile.statutory.gstin} />
                    <DetailField label={MSG.labels.cin} value={profile.statutory.cin} />
                    <DetailField label={MSG.labels.pancard} value={profile.statutory.pan} />
                  </Box>
                </Box>
              </Box>

              <Box className="client-detail-right">
                {reassignOwnerOpen ? (
                  <Box ref={reassignOwnerSectionRef}>
                    <ReassignOwnerDialog
                      mode="section"
                      open
                      onClose={handleCloseReassignOwnerSection}
                      onCommit={handleCommitClientOwnerReassign}
                      primaryOwner={profile.primaryOwnerRecord?.value ? profile.primaryOwnerRecord : profile.primaryOwner}
                      coOwners={profile.coOwners}
                    />
                  </Box>
                ) : isPending ? (
                  <>
                    <ClientPortfolios
                      clientUUID={routeClientUUID}
                      initialPortfolios={profile.portfolios}
                      fetchEnabled={false}
                      showAddPortfolio={false}
                    />
                    {canReviewPendingClient ? (
                      <ClientApproval
                        clientUUID={routeClientUUID}
                        clientName={profile.clientName}
                        checkSimilarClients={shouldCheckSimilarClients}
                      />
                    ) : (
                      <Box className="client-detail-pending-notice" role="status">
                        <Typography className="client-detail-pending-notice-title georama-SemiBold">
                          {notice.title}
                        </Typography>
                        <Typography className="client-detail-pending-notice-text georama-Regular">
                          {notice.message}
                        </Typography>
                      </Box>
                    )}
                  </>
                ) : isApproved ? (
                  <>
                    <ClientPortfolios
                      clientUUID={routeClientUUID}
                      showAddPortfolio={canCreateClientChildren}
                      onAddPortfolio={handleAddPortfolio}
                    />
                    <ClientOpportunities
                      clientUUID={routeClientUUID}
                      onAddOpportunity={canCreateClientChildren ? handleAddOpportunity : undefined}
                    />
                  </>
                ) : isRejected ? (
                  <>
                    <ClientPortfolios
                      clientUUID={routeClientUUID}
                      initialPortfolios={profile.portfolios}
                      fetchEnabled={false}
                      showAddPortfolio={false}
                    />
                    <Box
                      className="client-detail-pending-notice client-detail-pending-notice--rejected"
                      role="status"
                    >
                      <Typography className="client-detail-pending-notice-title georama-SemiBold">
                        {notice.title}
                      </Typography>
                      <Typography className="client-detail-pending-notice-text georama-Regular">
                        {notice.message}
                      </Typography>
                    </Box>
                  </>
                ) : (
                  <Box className="client-detail-pending-notice" role="status">
                    <Typography className="client-detail-pending-notice-title georama-SemiBold">
                      {notice.title}
                    </Typography>
                    <Typography className="client-detail-pending-notice-text georama-Regular">
                      {notice.message}
                    </Typography>
                  </Box>
                )}
              </Box>
            </Box>
          ) : null}
        </Box>
      </Paper>
      <ClientSaveSuccessDialog
        open={reassignSuccessOpen}
        title="Ownership Reassigned Successfully!"
        message="The client owner and co-owner assignment has been updated successfully."
        primaryLabel="View Client Profile"
        showSecondary={false}
        onViewProfile={() => setReassignSuccessOpen(false)}
      />
    </Box>
  );
};

export default ClientDetail;
