import { useEffect, useMemo, useState } from 'react';
import {
  Box,
  Button,
  Chip,
  Divider,
  IconButton,
  InputAdornment,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import FolderOutlinedIcon from '@mui/icons-material/FolderOutlined';
import TrendingUpOutlinedIcon from '@mui/icons-material/TrendingUpOutlined';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import ManageAccountsOutlinedIcon from '@mui/icons-material/ManageAccountsOutlined';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import ClientListFilters from '../components/client/ClientListFilters.jsx';
import DateRangeFilter from '../components/common/DateRangeFilter.jsx';
import SortOrderButton from '../components/common/SortOrderButton.jsx';
import { useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useClientList } from '../hooks/useFetchQueries.js';
import { getClientTotalPages } from '../utils/clientList.js';
import {
  getActiveClientFilterChips,
  hasActiveClientFilters,
  INITIAL_CLIENT_FILTERS,
} from '../utils/clientListFilters.js';
import { sanitizeByField } from '../utils/fieldUtils.js';
import { getClientStatusClass, isClientApproved } from '../utils/clientStatus.js';
import { formatColumnLabel } from '../utils/labelFormat.js';
import { sortRowsByDate } from '../utils/dateRangeFilters.js';
import { isListActionAllowed } from '../utils/listPermissions.js';
import {
  CLIENT_LIST_COLUMN_KEYS,
  CLIENT_LIST_COLUMN_LABELS,
} from '../config/clientListColumns.js';
import { CLIENT_LIST_MESSAGES as MSG } from '../config/messages.js';
import { clientsDetailPath, encodedRoutePath, ROUTES } from '../config/routes.js';
import './Clients.css';

/** Resolve a client's UUID from either the raw API row or the legacy mapped shape. */
const getRowUuid = (row) => row?.client_UUID ?? row?.clientUUID ?? '';

const isClientActiveValue = (value) => {
  const normalized = String(value ?? '').trim().toLowerCase();
  return normalized === '1' || normalized === 'true' || normalized === 'active';
};

const Clients = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Client permissions come from the logged-in MIBL user's role (Redux featureAccess).
  // The Client row's AccessName is a comma list like "Create, Edit, View".
  const clientAccessName = useSelector(
    (s) => (s?.user?.featureAccess || []).find((f) => f?.Url === '/clients')?.AccessName || '',
  );
  const canCreateClient = /create/i.test(clientAccessName);

  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState(INITIAL_CLIENT_FILTERS);
  const [appliedFilters, setAppliedFilters] = useState(INITIAL_CLIENT_FILTERS);
  const [searchInput, setSearchInput] = useState('');
  const [actionMenu, setActionMenu] = useState({ anchorEl: null, row: null });
  const { data: clientListResponse, isLoading, isFetching } = useClientList(page, appliedFilters);

  const clientData = clientListResponse?.list ?? [];
  const canShowAddClient = canCreateClient && isListActionAllowed(clientListResponse?.isAdd);
  const canShowReassignClient = isListActionAllowed(clientListResponse?.isReassign);
  const totalCount = clientListResponse?.totalCount ?? 0;
  const totalPages = useMemo(() => getClientTotalPages(totalCount), [totalCount]);
  const paginationItems = useMemo(() => {
    if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);

    const pages = new Set([1, totalPages, page - 1, page, page + 1]);
    const visiblePages = [...pages]
      .filter((pageNumber) => pageNumber >= 1 && pageNumber <= totalPages)
      .sort((first, second) => first - second);

    return visiblePages.reduce((items, pageNumber, index) => {
      const previousPage = visiblePages[index - 1];
      if (index > 0 && pageNumber - previousPage > 1) {
        items.push(`ellipsis-${previousPage}-${pageNumber}`);
      }
      items.push(pageNumber);
      return items;
    }, []);
  }, [page, totalPages]);

  useEffect(() => {
    const routeFilters = location.state?.filters;
    if (!routeFilters) return;

    const nextFilters = { ...INITIAL_CLIENT_FILTERS, ...routeFilters };
    setFilters(nextFilters);
    setAppliedFilters(nextFilters);
    setSearchInput(nextFilters.search ?? '');
    setPage(1);
    navigate(encodedRoutePath(ROUTES.clients), { replace: true, state: null });
  }, [location.state, navigate]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const nextSearch = searchInput.trim();
      setAppliedFilters((prev) => {
        if (prev.search === nextSearch) return prev;
        return { ...prev, search: nextSearch };
      });
    }, 300);

    return () => window.clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    setPage(1);
  }, [appliedFilters.search]);

  // Filtering + search are applied server-side via the list request, so the rows
  // returned for the current page are shown as-is.
  const filteredData = useMemo(
    () =>
      sortRowsByDate(
        clientData,
        (row) => row.created_on ?? row.createdDate ?? row.created_at,
        appliedFilters.sortOrder,
      ),
    [appliedFilters.sortOrder, clientData],
  );

  const tableHeaders = CLIENT_LIST_COLUMN_KEYS;

  const handleFilterChange = (field, value) => {
    setFilters((prev) => ({ ...prev, [field]: value }));
  };

  const handleApplyFilters = () => {
    setAppliedFilters({ ...filters, search: searchInput.trim() });
    setPage(1);
  };

  const handleToggleSortOrder = () => {
    const nextSortOrder = String(appliedFilters.sortOrder).toUpperCase() === 'ASC' ? 'DESC' : 'ASC';
    setFilters((prev) => ({ ...prev, sortOrder: nextSortOrder }));
    setAppliedFilters((prev) => ({ ...prev, sortOrder: nextSortOrder }));
    setPage(1);
  };

  const handleClearFilters = () => {
    setFilters(INITIAL_CLIENT_FILTERS);
    setAppliedFilters(INITIAL_CLIENT_FILTERS);
    setSearchInput('');
    setPage(1);
  };

  const handleRemoveFilterChip = (field) => {
    const nextFilters = {
      ...appliedFilters,
      [field]: '',
      ...(field === 'clientName' ? { clientUUID: '' } : {}),
      ...(field === 'primaryOwner' ? { ownerId: '' } : {}),
      ...(field === 'clientType' ? { clientTypeLabel: '' } : {}),
      ...(field === 'vertical' ? { verticalLabel: '' } : {}),
      ...(field === 'clientStatus' ? { clientStatusLabel: '' } : {}),
      ...(field === 'dateRangePreset' ? { fromDate: '', toDate: '' } : {}),
    };
    setFilters(nextFilters);
    setAppliedFilters(nextFilters);
    if (field === 'search') {
      setSearchInput('');
    }
    setPage(1);
  };

  const filtersActive =
    hasActiveClientFilters(filters) || hasActiveClientFilters(appliedFilters);

  const activeFilterChips = useMemo(
    () => getActiveClientFilterChips(appliedFilters, MSG.filters),
    [appliedFilters],
  );

  const handleActionMenuOpen = (row) => (event) => {
    setActionMenu({ anchorEl: event.currentTarget, row });
  };

  const handleActionMenuClose = () => {
    setActionMenu({ anchorEl: null, row: null });
  };

  const buildClientDraftFromRow = (row) => ({
    clientUUID: getRowUuid(row),
    status: row.client_status ?? row.status ?? '',
    basicDetails: {
      client_name: row.client_name ?? row.clientName ?? '',
      client_type: row.client_type ?? row.clientType ?? '',
      vertical: row.vertical ?? '',
    },
    address: {
      city: row.city ?? '',
      state: row.state ?? '',
    },
    communication: {
      primary_contact_name: row.primaryContactName ?? '',
      primary_email: row.email ?? '',
      primary_mobile: row.mobile ?? '',
    },
    accountOwner: {
      primary_owner: row.primaryOwner ?? '',
    },
    owners: Array.isArray(row.owners) ? row.owners : [],
    portfolios: [],
  });

  const handleAddPortfolioFromList = () => {
    const row = actionMenu.row;
    if (!row) return;
    handleActionMenuClose();
    navigate(encodedRoutePath(ROUTES.clientsCreatePortfolio), {
      state: {
        clientDraft: buildClientDraftFromRow(row),
        fromClientList: true,
        returnPath: encodedRoutePath(ROUTES.clients),
      },
    });
  };

  const handleViewFromList = () => {
    const row = actionMenu.row;
    if (!row) return;
    handleActionMenuClose();
    handleClientNameClick(row);
  };

  const handleAddOpportunityFromList = () => {
    const row = actionMenu.row;
    if (!row) return;
    handleActionMenuClose();
    const rowUuid = getRowUuid(row);
    navigate(encodedRoutePath(ROUTES.opportunitiesCreate), {
      state: {
        source: 'clientList',
        selectedClient: {
          clientUUID: rowUuid,
          clientName: row.client_name ?? row.clientName ?? '',
          primaryOwner: row.client_owner ?? row.primaryOwner ?? '',
        },
        clientDraft: buildClientDraftFromRow(row),
      },
    });
  };

  const handleReassignFromList = () => {
    const row = actionMenu.row;
    if (!row) return;
    handleActionMenuClose();
    const rowUuid = getRowUuid(row);
    if (!rowUuid) return;
    navigate(clientsDetailPath(rowUuid), {
      state: {
        listRow: row,
        showReassignOwner: true,
      },
    });
  };

  const selectedActionRowStatus = actionMenu.row?.client_status ?? actionMenu.row?.status ?? '';
  const selectedActionRowActive = actionMenu.row?.active ?? actionMenu.row?.activeState;
  const canShowCreateActions =
    isClientApproved(selectedActionRowStatus) && isClientActiveValue(selectedActionRowActive);

  const handlePageChange = (nextPage) => {
    if (nextPage === page || nextPage < 1 || nextPage > totalPages) return;
    setPage(nextPage);
  };

  const handleAddClient = () => {
    navigate(encodedRoutePath(ROUTES.clientsCreate));
  };

  const handlePrevPage = () => {
    handlePageChange(page - 1);
  };

  const handleNextPage = () => {
    handlePageChange(page + 1);
  };

  const handleClientNameClick = (row) => {
    const rowUuid = getRowUuid(row);
    if (!rowUuid) return;
    navigate(clientsDetailPath(rowUuid), { state: { listRow: row } });
  };

  const formatClientName = (name) =>
    String(name ?? '')
      .trim()
      .split(/\s+/)
      .map((word) => {
        if (/^[A-Z0-9&.-]+$/.test(word) && word.length > 1) return word;
        return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
      })
      .join(' ');

  const renderCellValue = (header, row) => {
    const rawValue = header === 'active' ? (row?.active ?? row?.activeState) : row?.[header];
    const value = String(rawValue ?? '');
    if ((header === 'client_name' || header === 'clientName') && value) {
      const formattedName = formatClientName(value);
      return (
        <Tooltip title={formattedName}>
          <Button
            className="client-mgmt-name-link"
            onClick={() => handleClientNameClick(row)}
          >
            <span className="client-mgmt-name-link-text">{formattedName}</span>
          </Button>
        </Tooltip>
      );
    }
    if (header === 'active') {
      if (value === '') return '';
      const isActive = isClientActiveValue(rawValue);
      const label = isActive ? 'Active' : 'Inactive';
      return (
        <span
          className={`client-mgmt-active-state-badge${
            isActive ? ' client-mgmt-active-state-badge--active' : ' client-mgmt-active-state-badge--inactive'
          }`}
          role="status"
          aria-label={label}
        >
          {label}
        </span>
      );
    }
    const headerLower = header.toLowerCase();
    const isStatusColumn = headerLower.includes('status') && !headerLower.includes('code');
    if (!isStatusColumn) return value;

    if (!value) return '';

    return (
      <span
        className={`client-mgmt-status-badge ${getClientStatusClass(value)}`}
        role="status"
        aria-label={value}
      >
        {value}
      </span>
    );
  };

  return (
    <Box className="client-mgmt-page">
      <BackdropLoader loading={isLoading || isFetching} />
      <Paper className="client-mgmt-paper table-auto-width">
        <Box className="client-mgmt-head-block table-body-bg border-radius-top-8">
          <Box className="client-mgmt-toolbar client-mgmt-toolbar-head">
            <Box className="client-mgmt-toolbar-left">
              <Box className="client-mgmt-page-title-wrap">
                <Typography className="georama-SemiBold fs-24 client-mgmt-title">{MSG.title}</Typography>
              </Box>
            </Box>
            <Box className="client-mgmt-toolbar-right">
              <TextField
                className="client-mgmt-search form-control-input"
                size="small"
                placeholder={MSG.search}
                value={searchInput}
                onChange={(event) => setSearchInput(sanitizeByField('search', event.target.value))}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon fontSize="small" className="client-mgmt-search-icon" />
                    </InputAdornment>
                  ),
                }}
              />
              <ClientListFilters
                filters={filters}
                appliedFilters={appliedFilters}
                onChange={handleFilterChange}
                onApply={handleApplyFilters}
                onClear={handleClearFilters}
                hasActiveFilters={filtersActive}
              />
              <DateRangeFilter
                filters={filters}
                appliedFilters={appliedFilters}
                dateFromField="fromDate"
                dateToField="toDate"
                onChange={handleFilterChange}
                onApply={handleApplyFilters}
                labels={MSG.filters}
                showDateFilterType={false}
              />
              <SortOrderButton value={appliedFilters.sortOrder} onToggle={handleToggleSortOrder} />
              {canShowAddClient && (
                <Button className="btn-common-red client-mgmt-btn-add" onClick={handleAddClient}>
                  {MSG.addNewClient}
                </Button>
              )}
            </Box>
          </Box>

          {activeFilterChips.length > 0 && (
            <Box className="client-mgmt-active-filters">
              {activeFilterChips.map((chip) => (
                <Chip
                  key={chip.key}
                  label={chip.label}
                  size="small"
                  onDelete={() => handleRemoveFilterChip(chip.key)}
                  className="client-mgmt-filter-chip"
                />
              ))}
              <Button className="client-mgmt-filter-clear-all text-sky" onClick={handleClearFilters}>
                {MSG.filters.clearAll}
              </Button>
            </Box>
          )}
        </Box>

        <TableContainer component={Box} className="client-mgmt-table-wrap">
          <Table>
            <TableHead>
              <TableRow>
                {tableHeaders.map((header) => (
                  <TableCell
                    key={header}
                    className={`client-mgmt-head-cell client-mgmt-col-${header} georama-Medium fw-none`}
                  >
                    {formatColumnLabel(header, CLIENT_LIST_COLUMN_LABELS)}
                  </TableCell>
                ))}
                <TableCell className="client-mgmt-head-cell georama-Medium fw-none client-mgmt-actions-col">
                  {MSG.actions}
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody className="table-body-bg">
              {filteredData.length > 0 ? (
                filteredData.map((row, idx) => (
                  <TableRow key={row.clientUUID || idx}>
                    {tableHeaders.map((header) => (
                      <TableCell key={`${idx}-${header}`} className={`p-4 georama-Regular fs-14 client-mgmt-col-${header}`}>
                        {renderCellValue(header, row)}
                      </TableCell>
                    ))}
                    <TableCell className="p-4 georama-Regular fs-14 client-mgmt-actions-col">
                      <Box className="client-mgmt-actions-wrap">
                        <Tooltip title={MSG.moreActions}>
                          <IconButton
                            size="small"
                            className="client-mgmt-more-btn"
                            onClick={handleActionMenuOpen(row)}
                            aria-label={MSG.moreActions}
                          >
                            <MoreHorizIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={Math.max(tableHeaders.length + 1, 1)} className="client-mgmt-no-data">
                    {MSG.noDataFound}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Menu
          anchorEl={actionMenu.anchorEl}
          open={Boolean(actionMenu.anchorEl)}
          onClose={handleActionMenuClose}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
          transformOrigin={{ vertical: 'top', horizontal: 'center' }}
          className="client-mgmt-action-menu"
          slotProps={{
            paper: {
              className: 'client-mgmt-action-menu-paper',
              elevation: 8,
            },
          }}
        >
          <Box className="client-mgmt-action-menu-header">
            <Typography className="client-mgmt-action-menu-title georama-SemiBold">
              {MSG.quickActions}
            </Typography>
          </Box>
          <Divider className="client-mgmt-action-menu-divider" />
          <MenuItem className="client-mgmt-action-menu-item" onClick={handleViewFromList}>
            <ListItemIcon className="client-mgmt-action-menu-icon">
              <VisibilityOutlinedIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText
              primary={MSG.view}
              primaryTypographyProps={{ className: 'client-mgmt-action-menu-label georama-Medium' }}
            />
          </MenuItem>
          {canShowCreateActions ? (
            <MenuItem className="client-mgmt-action-menu-item" onClick={handleAddPortfolioFromList}>
              <ListItemIcon className="client-mgmt-action-menu-icon client-mgmt-action-menu-icon--portfolio">
                <FolderOutlinedIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText
                primary={MSG.addPortfolio}
                primaryTypographyProps={{ className: 'client-mgmt-action-menu-label georama-Medium' }}
              />
            </MenuItem>
          ) : null}
          {canShowCreateActions ? (
            <MenuItem className="client-mgmt-action-menu-item" onClick={handleAddOpportunityFromList}>
              <ListItemIcon className="client-mgmt-action-menu-icon client-mgmt-action-menu-icon--opportunity">
                <TrendingUpOutlinedIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText
                primary={MSG.addOpportunity}
                primaryTypographyProps={{ className: 'client-mgmt-action-menu-label georama-Medium' }}
              />
            </MenuItem>
          ) : null}
          {canShowReassignClient ? (
            <MenuItem className="client-mgmt-action-menu-item" onClick={handleReassignFromList}>
              <ListItemIcon className="client-mgmt-action-menu-icon client-mgmt-action-menu-icon--owner">
                <ManageAccountsOutlinedIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText
                primary={MSG.reassignOwner}
                primaryTypographyProps={{ className: 'client-mgmt-action-menu-label georama-Medium' }}
              />
            </MenuItem>
          ) : null}
        </Menu>

        {totalPages > 1 && (
          <Box className="client-mgmt-pagination-wrap table-body-bg border-radius-bottom-8">
            <Typography className="client-mgmt-total-count georama-Medium">
              {MSG.totalClients(totalCount)}
            </Typography>
            <Box className="client-mgmt-pagination">
              <Button
                className="client-mgmt-pagination-nav"
                disabled={page <= 1}
                onClick={handlePrevPage}
                aria-label={MSG.previousPage}
              >
                <ChevronLeftIcon fontSize="small" />
              </Button>

              <Box className="client-mgmt-pagination-pages">
                {paginationItems.map((item) =>
                  typeof item === 'number' ? (
                    <Button
                      key={item}
                      className={`client-mgmt-pagination-page ${
                        item === page ? 'client-mgmt-pagination-page-active' : ''
                      }`}
                      onClick={() => handlePageChange(item)}
                      aria-current={item === page ? 'page' : undefined}
                    >
                      {item}
                    </Button>
                  ) : (
                    <Typography key={item} className="client-mgmt-pagination-ellipsis">
                      ...
                    </Typography>
                  ),
                )}
              </Box>

              <Typography className="client-mgmt-pagination-label">{MSG.pageOf(totalPages)}</Typography>

              <Button
                className="client-mgmt-pagination-nav"
                disabled={page >= totalPages}
                onClick={handleNextPage}
                aria-label={MSG.nextPage}
              >
                <ChevronRightIcon fontSize="small" />
              </Button>
            </Box>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default Clients;
