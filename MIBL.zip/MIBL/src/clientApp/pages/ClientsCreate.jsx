import { useEffect, useMemo, useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormHelperText,
  Paper,
  TextField,
  Typography,
} from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import { queryKeys } from '../lib/queryKeys';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import ClientNameSearchField from '../components/client/ClientNameSearchField.jsx';
import PortfolioFormFields from '../components/client/PortfolioFormFields.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import KdsSelect from '../components/common/KdsSelect.jsx';
import { CLIENT_KDS_FIELDS } from '../config/kdsFields.js';
import { CLIENT_CREATE_MESSAGES as MSG, COMMON_MESSAGES } from '../config/messages.js';
import { clientsDetailPath, clientsEditPath, encodedRoutePath, ROUTES } from '../config/routes.js';
import { createClient, getClientByUuid, getPincodeDetails, updateClient } from '../services/api.jsx';
import { invalidateClientQueries, STALE_TIME_MS } from '../lib/queryClient.js';
import { mapClientRecordToFormDraft, mapSecondariesFromRecord } from '../utils/clientFormState.js';
import { isClientApproved } from '../utils/clientStatus.js';
import {
  buildInitialPortfolioFromClient,
  buildPortfolioData,
  initialPortfolio,
  isNewBusinessType,
  mergePortfolioWithClientDraft,
} from '../utils/portfolioFormState.js';
import './ClientsForm.css';

import {
  isSmeVertical,
  sanitizeFieldValue,
  SECTION_KEYS,
  validateSection,
} from '../utils/clientFormValidation.js';

import { getClientFormSections } from '../config/clientFormSteps.js';
import { getEncryptedRouteParam } from '../utils/encryptedRouteParams.js';

const initialBasicDetails = () => ({
  client_name: '',
  client_type: '',
  vertical: '',
  pan: '',
  cin: '',
  gstin: '',
});

const initialAddress = () => ({
  address_line1: '',
  address_line2: '',
  city: '',
  state: '',
  pincode: '',
});

const emptySecondaryContact = () => ({
  name: '',
  mobile: '',
  email: '',
});

const initialCommunication = () => ({
  primary_contact_name: '',
  primary_mobile: '',
  primary_email: '',
  secondaries: [],
});

const ClientsCreate = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { clientUUID, encrypted } = useParams();
  const routeClientUUID = clientUUID || getEncryptedRouteParam(encrypted, /^\/clients\/edit\/([^/]+)$/);
  const isEditMode = Boolean(routeClientUUID);
  const queryClient = useQueryClient();

  const [formErrors, setFormErrors] = useState({});
  const [portfolioDraft, setPortfolioDraft] = useState(initialPortfolio);
  const [activeSection, setActiveSection] = useState(SECTION_KEYS.basic);
  const [loadingClient, setLoadingClient] = useState(false);
  const [clientLoaded, setClientLoaded] = useState(false);
  const [clientStatus, setClientStatus] = useState('');
  const [clientActive, setClientActive] = useState(1);

  const hidePortfolioForApprovedEdit = isEditMode && isClientApproved(clientStatus);
  const formSections = getClientFormSections({ includePortfolio: !hidePortfolioForApprovedEdit });
  const activeSectionIndex = formSections.findIndex((section) => section.key === activeSection);
  const activeSectionMeta = formSections[activeSectionIndex] ?? formSections[0];
  const isFirstSection = activeSectionIndex <= 0;
  const isLastSection = activeSectionIndex >= formSections.length - 1;

  const [basicDetails, setBasicDetails] = useState(initialBasicDetails);
  const [address, setAddress] = useState(initialAddress);
  const [cityStateReadOnly, setCityStateReadOnly] = useState(false);
  const [communication, setCommunication] = useState(() => initialCommunication());
  const isSmeSelected = isSmeVertical(basicDetails.vertical);

  const formData = useMemo(
    () => ({ basicDetails, address, communication }),
    [basicDetails, address, communication],
  );

  const clientDraftForPortfolio = useMemo(
    () => ({ basicDetails, address, communication }),
    [basicDetails, address, communication],
  );

  useEffect(() => {
    if (activeSection !== SECTION_KEYS.portfolio) return;
    setPortfolioDraft((prev) => mergePortfolioWithClientDraft(prev, clientDraftForPortfolio));
  }, [activeSection, clientDraftForPortfolio]);

  useEffect(() => {
    if (hidePortfolioForApprovedEdit && activeSection === SECTION_KEYS.portfolio) {
      setActiveSection(SECTION_KEYS.basic);
    }
  }, [activeSection, hidePortfolioForApprovedEdit]);

  const goToSection = (sectionKey) => {
    setActiveSection(sectionKey);
  };

  const applyClientRecord = (client) => {
    // location.state.listRow carries list-only fields (e.g. vertical) missing from the get API.
    const record = mapClientRecordToFormDraft(client, location.state?.listRow);
    if (!record) return;

    setBasicDetails({ ...initialBasicDetails(), ...record.basicDetails });
    setClientStatus(record.status ?? '');
    setClientActive(record.is_active ?? 1);
    const nextAddress = { ...initialAddress(), ...record.address };
    setAddress(nextAddress);
    setCityStateReadOnly(Boolean(nextAddress.pincode && nextAddress.city && nextAddress.state));
    setCommunication({
      ...initialCommunication(),
      ...record.communication,
      secondaries: mapSecondariesFromRecord(record.communication?.secondaries),
    });

    const portfolioList = record.portfolios ?? [];
    setPortfolioDraft(
      buildInitialPortfolioFromClient(
        record,
        portfolioList.length > 0 ? portfolioList[portfolioList.length - 1] : null,
      ),
    );
  };

  useEffect(() => {
    const restored = location.state;
    if (!restored?.clientDraft) return;

    applyClientRecord(restored.clientDraft);
    setClientLoaded(true);

    if (restored.focusPortfolio && !isClientApproved(restored.clientDraft.status)) {
      setActiveSection(SECTION_KEYS.portfolio);
    } else if (restored.focusContact) {
      setActiveSection(SECTION_KEYS.contact);
    }

    const returnPath =
      restored.returnPath ??
      (restored.clientDraft?.clientUUID
        ? clientsEditPath(restored.clientDraft.clientUUID)
        : encodedRoutePath(ROUTES.clientsCreate));

    navigate(returnPath, { replace: true, state: null });
  }, [location.state, navigate]);

  useEffect(() => {
    if (!isEditMode || clientLoaded || location.state?.clientDraft) return;

    let cancelled = false;

    const loadClient = async () => {
      setLoadingClient(true);
      try {
        const client = await queryClient.fetchQuery({
          queryKey: queryKeys.client(routeClientUUID),
          queryFn: () => getClientByUuid(routeClientUUID),
          staleTime: STALE_TIME_MS,
        });
        if (cancelled) return;
        applyClientRecord(client);
        if (location.state?.focusContact) {
          setActiveSection(SECTION_KEYS.contact);
        }
        setClientLoaded(true);
      } finally {
        if (!cancelled) setLoadingClient(false);
      }
    };

    loadClient();
    return () => {
      cancelled = true;
    };
  }, [routeClientUUID, isEditMode, clientLoaded, location.state?.clientDraft]);

  const [successOpen, setSuccessOpen] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [savedClientUUID, setSavedClientUUID] = useState('');

  const getSavedClientUUID = (response) =>
    response?.payload?.client?.client_UUID ??
    response?.payload?.client?.client_uuid ??
    response?.payload?.client_UUID ??
    response?.payload?.client_uuid ??
    response?.client_UUID ??
    response?.client_uuid ??
    '';

  const onSaveSuccess = (response) => {
    setSaveError('');
    invalidateClientQueries(queryClient);
    setSavedClientUUID(getSavedClientUUID(response) || routeClientUUID || '');
    setSuccessOpen(true);
  };

  const onSaveError = (error) => {
    setSaveError(error?.message || MSG.saveError.fallback);
  };

  const createMutation = useMutation({
    mutationFn: createClient,
    onSuccess: onSaveSuccess,
    onError: onSaveError,
  });

  const updateMutation = useMutation({
    mutationFn: ({ clientUUID: uuid, payload }) => updateClient(uuid, payload),
    onSuccess: onSaveSuccess,
    onError: onSaveError,
  });

  const handleSuccessReturnToList = () => {
    setSuccessOpen(false);
    navigate(encodedRoutePath(ROUTES.clients));
  };

  const handleSuccessViewProfile = () => {
    setSuccessOpen(false);
    const nextClientUUID = savedClientUUID || routeClientUUID;
    navigate(nextClientUUID ? clientsDetailPath(nextClientUUID) : encodedRoutePath(ROUTES.clients));
  };

  const isSubmitting = createMutation.isPending || updateMutation.isPending;

  const clearError = (key) => {
    if (formErrors[key]) {
      setFormErrors((prev) => ({ ...prev, [key]: '' }));
    }
  };

  // City + State are auto-filled from pincode when master data exists; otherwise they stay editable.
  const handlePincodeChange = async (value) => {
    setAddress((prev) => ({ ...prev, pincode: value }));
    if (value.length !== 6) {
      setCityStateReadOnly(false);
      setAddress((prev) => ({ ...prev, city: '', state: '' }));
      return;
    }
    const details = await getPincodeDetails(value);
    const hasCityState = Boolean(details?.city_name && details?.state_name);
    setCityStateReadOnly(hasCityState);
    setAddress((prev) => ({
      ...prev,
      city: details?.city_name ?? '',
      state: details?.state_name ?? '',
    }));
  };

  const handleVerticalChange = (value) => {
    setBasicDetails((prev) => ({
      ...prev,
      vertical: value,
      client_type: isSmeVertical(value) ? prev.client_type : '',
    }));
    clearError('vertical');
    if (!isSmeVertical(value)) clearError('client_type');
  };

  const goToPrevSection = () => {
    if (isFirstSection) return;
    goToSection(formSections[activeSectionIndex - 1].key);
  };

  const goToNextSection = () => {
    if (isLastSection) return;

    const sectionErrors = validateSection(activeSection, formData, portfolioDraft);
    if (Object.keys(sectionErrors).length > 0) {
      setFormErrors((prev) => ({ ...prev, ...sectionErrors }));
      return;
    }

    goToSection(formSections[activeSectionIndex + 1].key);
  };

  const trimValue = (value) => (typeof value === 'string' ? value.trim() : value);

  const buildClientPayload = () => {
    const payload = {
      basicDetails: {
        client_name: trimValue(basicDetails.client_name),
        client_type: basicDetails.client_type,
        vertical: basicDetails.vertical,
        pan: trimValue(basicDetails.pan),
        cin: trimValue(basicDetails.cin),
        gstin: trimValue(basicDetails.gstin),
      },
      address: {
        address_line1: trimValue(address.address_line1),
        address_line2: trimValue(address.address_line2),
        city: trimValue(address.city),
        state: trimValue(address.state),
        pincode: trimValue(address.pincode),
      },
      communication: {
        primary_contact_name: trimValue(communication.primary_contact_name),
        primary_mobile: trimValue(communication.primary_mobile),
        primary_email: trimValue(communication.primary_email),
        secondaries: communication.secondaries
          .map((item) => ({
            name: trimValue(item.name),
            mobile: trimValue(item.mobile),
            email: trimValue(item.email),
          }))
          .filter((item) => item.name || item.mobile || item.email),
      },
      portfolios: [buildPortfolioData(portfolioDraft)],
      active: isEditMode ? clientActive : 1,
    };

    if (routeClientUUID) {
      payload.clientUUID = routeClientUUID;
    }

    return payload;
  };

  const validateForm = () =>
    formSections.reduce(
      (errors, section) => ({
        ...errors,
        ...validateSection(section.key, formData, portfolioDraft),
      }),
      {},
    );

  const handlePortfolioChange = (field, value) => {
    setPortfolioDraft((prev) => {
      const next = { ...prev, [field]: value };
      if (field === 'business_type' && isNewBusinessType(value)) {
        next.policy_start_date = '';
        next.policy_expiry_date = '';
        next.previous_insurer = '';
        next.previous_policy_number = '';
      }
      return next;
    });
    setFormErrors((prev) => {
      const next = { ...prev };
      if (next[field]) delete next[field];
      if (field === 'business_type' && isNewBusinessType(value)) {
        ['policy_start_date', 'policy_expiry_date', 'previous_insurer', 'previous_policy_number'].forEach(
          (policyField) => {
            if (next[policyField]) delete next[policyField];
          },
        );
      }
      if (field === 'other_contacts') {
        Object.keys(next).forEach((key) => {
          if (key.startsWith('other_contact_')) delete next[key];
        });
      }
      return next;
    });
  };

  const handleSubmit = async () => {
    const nextErrors = validateForm();
    setFormErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      const firstErrorSection = formSections.find(
        (section) => Object.keys(validateSection(section.key, formData, portfolioDraft)).length > 0,
      );
      if (firstErrorSection) setActiveSection(firstErrorSection.key);
      return;
    }
    const payload = buildClientPayload();
    setSaveError('');
    if (isEditMode) {
      updateMutation.mutate({ clientUUID: routeClientUUID, payload });
      return;
    }
    createMutation.mutate(payload);
  };

  const handleBack = () => {
    navigate(-1);
  };

  const handleAddSecondaryContact = () => {
    setCommunication((prev) => ({
      ...prev,
      secondaries: [...prev.secondaries, emptySecondaryContact()],
    }));
  };

  const removeSecondaryContact = (index) => {
    setCommunication((prev) => ({
      ...prev,
      secondaries: prev.secondaries.filter((_, i) => i !== index),
    }));
    setFormErrors((prev) => {
      const next = { ...prev };
      Object.keys(next).forEach((key) => {
        if (key.startsWith('secondary_')) delete next[key];
      });
      return next;
    });
  };

  const updateSecondaryContact = (index, field, value) => {
    setCommunication((prev) => ({
      ...prev,
      secondaries: prev.secondaries.map((item, i) => (i === index ? { ...item, [field]: value } : item)),
    }));
  };

  const getSecondaryRemoveHandler = (index) => () => {
    removeSecondaryContact(index);
  };

  const renderTextField = ({
    label,
    value,
    errorKey,
    onChange,
    required = false,
    inputType,
    placeholder,
    readOnly = false,
  }) => (
    <Box className="client-form-field">
      <Typography className="text-labels client-form-label">
        {label} {required && <span className="important-fields">*</span>}
      </Typography>
      <TextField
        className={`form-control-input border-radius-8${readOnly ? ' disabled-input' : ''}`}
        size="small"
        fullWidth
        value={value}
        placeholder={placeholder}
        error={!!formErrors[errorKey]}
        InputProps={{ readOnly }}
        onChange={(e) => {
          const nextValue = inputType ? sanitizeFieldValue(inputType, e.target.value) : e.target.value;
          onChange(nextValue);
          clearError(errorKey);
        }}
      />
      {formErrors[errorKey] && <FormHelperText className="important-fields">{formErrors[errorKey]}</FormHelperText>}
    </Box>
  );

  return (
    <Box className="client-form-page">
      <BackdropLoader loading={loadingClient || isSubmitting} />
      <ClientSaveSuccessDialog
        open={successOpen}
        isUpdate={isEditMode}
        onViewProfile={handleSuccessViewProfile}
        onReturnToList={handleSuccessReturnToList}
      />
      <Paper className="client-form-paper table-auto-width">
        <Box className="client-form-body">
          <Box className="client-form-header">
            <Typography className="georama-SemiBold fs-24 client-form-title">
              {isEditMode ? MSG.editTitle : MSG.title}
            </Typography>
            <Button
              className="text-capitalize georama-medium-selected custom-starticon client-form-back-btn"
              startIcon={<ChevronLeftIcon />}
              onClick={handleBack}
            >
              {MSG.back}
            </Button>
          </Box>
          <Box className="client-form-header-divider" />

          <Box className="client-form-wizard">
            <Box className="client-form-step-panel">
              <Box className="client-form-step-panel-head">
                <Typography className="client-form-step-indicator georama-Regular">
                  {MSG.stepNav.stepOf(activeSectionIndex + 1, formSections.length)}
                </Typography>
                <Typography className="client-form-step-title georama-SemiBold">
                  {activeSectionMeta.title}
                </Typography>
              </Box>

              <Box className="client-form-section-body client-form-section-body--panel">
                {activeSection === SECTION_KEYS.basic && (
                  <>
                    <Box className="client-form-basic-lead">
                      <ClientNameSearchField
                        label={MSG.labels.clientName}
                        value={basicDetails.client_name}
                        placeholder={MSG.clientNameSearch.placeholder}
                        required
                        error={!!formErrors.client_name}
                        errorMessage={formErrors.client_name}
                        searchEnabled={!isEditMode}
                        onChange={(value) => setBasicDetails((prev) => ({ ...prev, client_name: value }))}
                        onClearError={() => clearError('client_name')}
                      />
                    </Box>
                    <Box className="client-form-grid">
                      <KdsSelect
                        {...CLIENT_KDS_FIELDS.vertical}
                        label={MSG.labels.vertical}
                        value={basicDetails.vertical}
                        onChange={handleVerticalChange}
                        required
                        placeholder={MSG.placeholders.vertical}
                        error={formErrors.vertical}
                        onClearError={() => clearError('vertical')}
                      />
                      <KdsSelect
                        {...CLIENT_KDS_FIELDS.clientType}
                        label={MSG.labels.clientType}
                        value={basicDetails.client_type}
                        onChange={(value) => setBasicDetails((prev) => ({ ...prev, client_type: value }))}
                        required={isSmeSelected}
                        placeholder={isSmeSelected ? MSG.placeholders.clientType : 'Select SME vertical first'}
                        error={formErrors.client_type}
                        onClearError={() => clearError('client_type')}
                        disabled={!isSmeSelected}
                      />
                      {renderTextField({
                        label: MSG.labels.pan,
                        value: basicDetails.pan,
                        errorKey: 'pan',
                        onChange: (value) => setBasicDetails((prev) => ({ ...prev, pan: value })),
                        inputType: 'pan',
                        placeholder: MSG.placeholders.pan,
                      })}
                      {renderTextField({
                        label: MSG.labels.cin,
                        value: basicDetails.cin,
                        errorKey: 'cin',
                        onChange: (value) => setBasicDetails((prev) => ({ ...prev, cin: value })),
                        inputType: 'cin',
                        placeholder: MSG.placeholders.cin,
                      })}
                      {renderTextField({
                        label: MSG.labels.gstin,
                        value: basicDetails.gstin,
                        errorKey: 'gstin',
                        onChange: (value) => setBasicDetails((prev) => ({ ...prev, gstin: value })),
                        inputType: 'gstin',
                        placeholder: MSG.placeholders.gstin,
                      })}
                    </Box>
                  </>
                )}

                {activeSection === SECTION_KEYS.contact && (
                  <>
                    <Typography className="georama-Medium client-form-subsection-title">
                      {MSG.subsections.address}
                    </Typography>
                    <Box className="client-form-grid">
                      {renderTextField({
                        label: MSG.labels.pinCode,
                        value: address.pincode,
                        errorKey: 'pincode',
                        onChange: handlePincodeChange,
                        required: true,
                        inputType: 'pincode',
                        placeholder: MSG.placeholders.pinCode,
                      })}
                      {renderTextField({
                        label: MSG.labels.city,
                        value: address.city,
                        errorKey: 'city',
                        onChange: (value) => setAddress((prev) => ({ ...prev, city: value })),
                        required: true,
                        inputType: 'cityState',
                        placeholder: MSG.placeholders.city,
                        readOnly: cityStateReadOnly,
                      })}
                      {renderTextField({
                        label: MSG.labels.state,
                        value: address.state,
                        errorKey: 'state',
                        onChange: (value) => setAddress((prev) => ({ ...prev, state: value })),
                        required: true,
                        inputType: 'cityState',
                        placeholder: MSG.placeholders.state,
                        readOnly: cityStateReadOnly,
                      })}
                      {renderTextField({
                        label: MSG.labels.addressLine1,
                        value: address.address_line1,
                        errorKey: 'address_line1',
                        onChange: (value) => setAddress((prev) => ({ ...prev, address_line1: value })),
                        inputType: 'address',
                        placeholder: MSG.placeholders.addressLine1,
                      })}
                      {renderTextField({
                        label: MSG.labels.addressLine2,
                        value: address.address_line2,
                        errorKey: 'address_line2',
                        onChange: (value) => setAddress((prev) => ({ ...prev, address_line2: value })),
                        inputType: 'address',
                        placeholder: MSG.placeholders.addressLine2,
                      })}
                    </Box>

                    <Typography className="georama-Medium client-form-subsection-title client-form-subsection-title--spaced client-form-primary-contact-title">
                      {MSG.subsections.primary}
                    </Typography>
                    <Box className="client-form-grid">
                      {renderTextField({
                        label: MSG.labels.contactPersonName,
                        value: communication.primary_contact_name,
                        errorKey: 'primary_contact_name',
                        onChange: (value) =>
                          setCommunication((prev) => ({ ...prev, primary_contact_name: value })),
                        required: true,
                        inputType: 'name',
                        placeholder: MSG.placeholders.contactPersonName,
                      })}
                      {renderTextField({
                        label: MSG.labels.mobileNo,
                        value: communication.primary_mobile,
                        errorKey: 'comm_primary_mobile',
                        onChange: (value) => setCommunication((prev) => ({ ...prev, primary_mobile: value })),
                        required: true,
                        inputType: 'mobile',
                        placeholder: MSG.placeholders.mobileNo,
                      })}
                      {renderTextField({
                        label: MSG.labels.email,
                        value: communication.primary_email,
                        errorKey: 'comm_primary_email',
                        onChange: (value) => setCommunication((prev) => ({ ...prev, primary_email: value })),
                        required: true,
                        inputType: 'email',
                        placeholder: MSG.placeholders.email,
                      })}
                    </Box>

                    {communication.secondaries.map((secondaryItem, index) => (
                      <Box key={index} className="client-form-contact-block">
                        <Box className="client-form-contact-head">
                          <Typography className="client-form-secondary-item-title georama-Medium">
                            {MSG.secondaryContactTitle(index)}
                          </Typography>
                          <Button
                            className="client-form-add-contact-btn important-fields"
                            onClick={getSecondaryRemoveHandler(index)}
                          >
                            {MSG.buttons.remove}
                          </Button>
                        </Box>
                        <Box className="client-form-grid">
                          {renderTextField({
                            label: MSG.labels.contactPersonName,
                            value: secondaryItem.name,
                            errorKey: `secondary_name_${index}`,
                            onChange: (value) => updateSecondaryContact(index, 'name', value),
                            inputType: 'name',
                            placeholder: MSG.placeholders.contactPersonName,
                          })}
                          {renderTextField({
                            label: MSG.labels.mobileNo,
                            value: secondaryItem.mobile,
                            errorKey: `secondary_mobile_${index}`,
                            onChange: (value) => updateSecondaryContact(index, 'mobile', value),
                            inputType: 'mobile',
                            placeholder: MSG.placeholders.mobileNo,
                          })}
                          {renderTextField({
                            label: MSG.labels.email,
                            value: secondaryItem.email,
                            errorKey: `secondary_email_${index}`,
                            onChange: (value) => updateSecondaryContact(index, 'email', value),
                            inputType: 'email',
                            placeholder: MSG.placeholders.email,
                          })}
                        </Box>
                      </Box>
                    ))}

                    <Box className="client-form-add-secondary-action">
                      <Button className="client-form-add-contact-btn text-sky" onClick={handleAddSecondaryContact}>
                        {MSG.buttons.addSecondaryContact}
                      </Button>
                    </Box>
                  </>
                )}

                {activeSection === SECTION_KEYS.portfolio && (
                  <PortfolioFormFields
                    portfolio={portfolioDraft}
                    errors={formErrors}
                    onChange={handlePortfolioChange}
                    clientDraft={clientDraftForPortfolio}
                  />
                )}
              </Box>

              {saveError && (
                <Box className="client-form-save-error" role="alert">
                  <Typography className="client-form-save-error-title georama-SemiBold">
                    {MSG.saveError.title}
                  </Typography>
                  <Typography className="client-form-save-error-text georama-Regular">
                    {saveError}
                  </Typography>
                </Box>
              )}

              <Box className="client-form-step-footer">
                <Button
                  className="client-form-step-nav-btn text-sky"
                  onClick={goToPrevSection}
                  disabled={isFirstSection}
                >
                  {MSG.buttons.previous}
                </Button>
                <Box className="client-form-step-footer-right">
                  {!isLastSection ? (
                    <Button className="btn-common-red border-radius-32 client-form-submit-btn" onClick={goToNextSection}>
                      {MSG.buttons.next}
                    </Button>
                  ) : (
                    <Button
                      className="btn-common-red border-radius-32 client-form-submit-btn"
                      onClick={handleSubmit}
                      disabled={isSubmitting}
                    >
                      {isEditMode
                        ? isSubmitting
                          ? MSG.buttons.updating
                          : MSG.buttons.updateClient
                        : isSubmitting
                          ? MSG.buttons.submitting
                          : MSG.buttons.submitClient}
                    </Button>
                  )}
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default ClientsCreate;
