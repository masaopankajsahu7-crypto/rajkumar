import { useMemo, useState } from 'react';
import AccountTreeRoundedIcon from '@mui/icons-material/AccountTreeRounded';
import BadgeRoundedIcon from '@mui/icons-material/BadgeRounded';
import BarChartRoundedIcon from '@mui/icons-material/BarChartRounded';
import BusinessCenterRoundedIcon from '@mui/icons-material/BusinessCenterRounded';
import AutorenewRoundedIcon from '@mui/icons-material/AutorenewRounded';
import EventAvailableRoundedIcon from '@mui/icons-material/EventAvailableRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import TimerRoundedIcon from '@mui/icons-material/TimerRounded';
import { Box, FormControl, IconButton, MenuItem, Select, TextField, Tooltip, Typography } from '@mui/material';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useOpportunityDashboardSection } from '../hooks/useFetchQueries.js';
import { ROUTES, encodedRoutePath } from '../config/routes.js';
import './Dashboard.css';

const DASHBOARD_SECTIONS = {
  clients: 'client_active_summary',
  clientStatus: 'client_status_summary',
  opportunitySummary: 'opportunity_status_summary',
  opportunityTat: 'opportunity_breached_summary',
  opportunityStages: 'opportunity_stage_summary',
  activitySummary: 'activity_summary',
  renewalSummary: 'renewal_kpi_summary',
};

const RANGE_OPTIONS = [
  { code: 'today60', label: 'Today (±60 Days)' },
  { code: 'today30', label: 'Today (±30 Days)' },
  { code: 'currentMonth', label: 'Current Month' },
  { code: 'previousMonth', label: 'Previous Month' },
  { code: 'last3Months', label: 'Last 3 Months' },
  { code: 'nextMonth', label: 'Next Month' },
  { code: 'next3Months', label: 'Next 3 Months' },
  { code: 'custom', label: 'Custom' },
];

const SECTION_CARD_LIMITS = {
  clients: 2,
  clientStatus: 4,
  opportunitySummary: 4,
  opportunityStages: 6,
  activitySummary: 4,
  renewalSummary: 4,
};

const CARD_TONES = ['blue', 'red', 'green', 'amber', 'slate'];

const DASHBOARD_STATUS_TONES = {
  green: [
    'active',
    'approved',
    'won',
    'within tat',
    'within tat target',
    'completed',
    'converted',
    'converted to opportunity',
  ],
  red: [
    'inactive',
    'rejected',
    'lost',
    'breached',
    'breached today',
  ],
  amber: [
    'pending',
    'sendback',
    'send back',
    'in process',
    'upcoming',
  ],
  blue: [
    'open',
    'today',
  ],
};

const pad = (value) => String(value).padStart(2, '0');

const formatDate = (date) =>
  `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;

const formatDisplayDate = (value) => {
  if (!value) return '--';
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return '--';
  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

const startOfMonth = (date) => new Date(date.getFullYear(), date.getMonth(), 1);

const endOfMonth = (date) => new Date(date.getFullYear(), date.getMonth() + 1, 0);

const addDays = (date, days) => {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
};

const getDateRange = (rangeCode) => {
  const today = new Date();
  switch (rangeCode) {
    case 'currentMonth':
      return { fromDate: formatDate(startOfMonth(today)), toDate: formatDate(endOfMonth(today)) };
    case 'previousMonth': {
      const previous = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      return { fromDate: formatDate(startOfMonth(previous)), toDate: formatDate(endOfMonth(previous)) };
    }
    case 'last3Months': {
      const from = new Date(today.getFullYear(), today.getMonth() - 2, 1);
      return { fromDate: formatDate(startOfMonth(from)), toDate: formatDate(endOfMonth(today)) };
    }
    case 'nextMonth': {
      const next = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      return { fromDate: formatDate(startOfMonth(next)), toDate: formatDate(endOfMonth(next)) };
    }
    case 'next3Months': {
      const from = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 3, 1);
      return { fromDate: formatDate(startOfMonth(from)), toDate: formatDate(endOfMonth(to)) };
    }
    case 'today60':
      return { fromDate: formatDate(addDays(today, -60)), toDate: formatDate(addDays(today, 60)) };
    case 'today30':
    default:
      return { fromDate: formatDate(addDays(today, -30)), toDate: formatDate(addDays(today, 30)) };
  }
};

const getGreeting = () => {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good Morning';
  if (hour < 17) return 'Good Afternoon';
  if (hour < 21) return 'Good Evening';
  return 'Good Night';
};

const humanize = (value) =>
  String(value ?? '')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (char) => char.toUpperCase());

const firstValue = (...values) =>
  values.find((value) => value !== null && value !== undefined && String(value).trim() !== '');

const normalizeStatusToneLabel = (value) =>
  String(value ?? '')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

const escapeRegExp = (value) => String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const getDashboardStatusTone = (label, fallback = 'blue') => {
  const normalized = normalizeStatusToneLabel(label);
  if (!normalized) return fallback;

  const exactMatch = Object.entries(DASHBOARD_STATUS_TONES).find(([, labels]) =>
    labels.some((statusLabel) => normalized === statusLabel),
  );
  if (exactMatch) return exactMatch[0];

  const match = Object.entries(DASHBOARD_STATUS_TONES).find(([, labels]) =>
    labels.some((statusLabel) => new RegExp(`(^|\\s)${escapeRegExp(statusLabel)}($|\\s)`).test(normalized)),
  );

  return match?.[0] ?? fallback;
};

const getSectionTotalCount = (response) => {
  const payload = response?.payload ?? response;
  return firstValue(payload?.total_count, payload?.total_records);
};

const shouldShowDashboardSection = (response) => {
  const totalCount = getSectionTotalCount(response);
  if (totalCount === undefined) return true;
  const numericTotal = Number(totalCount);
  return !Number.isFinite(numericTotal) || numericTotal !== 0;
};

const getRecordLabel = (record = {}) =>
  firstValue(
    record.label,
    record.name,
    record.title,
    record.status,
    record.stage,
    record.key,
    record.code,
    record.dashboard_label,
    record.dashboard_name,
  );

const getRecordValue = (record = {}) =>
  firstValue(
    record.value,
    record.count,
    record.total,
    record.total_count,
    record.record_count,
    record.no_of_records,
    record.summary_count,
  );

const normalizeDashboardRecords = (response, limit) => {
  const payload = response?.payload ?? response;
  const candidates = [
    payload?.records,
    payload?.summary,
    payload?.data,
    payload?.list,
    payload?.dashboard,
    payload?.dashboard_data,
    payload?.master,
    payload,
  ];
  const list = candidates.find((candidate) => Array.isArray(candidate));

  if (Array.isArray(list)) {
    return list.slice(0, limit).map((record, index) => ({
      label: humanize(getRecordLabel(record) ?? `Item ${index + 1}`),
      value: getRecordValue(record) ?? 0,
    }));
  }

  if (payload && typeof payload === 'object') {
    return Object.entries(payload)
      .filter(([, value]) => typeof value !== 'object' || value === null)
      .slice(0, limit)
      .map(([key, value]) => ({
        label: humanize(key),
        value: value ?? 0,
      }));
  }

  return [];
};

const normalizeOpportunityStageRecords = (response, limit) => {
  const payload = response?.payload ?? response;
  const candidates = [
    payload?.records,
    payload?.summary,
    payload?.data,
    payload?.list,
    payload?.dashboard,
    payload?.dashboard_data,
    payload?.master,
    payload,
  ];
  const list = candidates.find((candidate) => Array.isArray(candidate));

  if (!Array.isArray(list)) {
    return [];
  }

  return [...list]
    .sort((a, b) => Number(a?.stage_sequence ?? 0) - Number(b?.stage_sequence ?? 0))
    .slice(0, limit)
    .map((stage, index) => ({
      label: humanize(stage?.stage_name ?? stage?.stage_code ?? `Stage ${index + 1}`),
      title: humanize(stage?.display_name ?? stage?.stage_name ?? stage?.stage_code ?? `Stage ${index + 1}`),
      filterValue: firstValue(stage?.stage_code, stage?.code, stage?.stage_name),
      value: stage?.count ?? 0,
      meta: humanize(stage?.stage_code ?? stage?.stage_name ?? ''),
    }));
};

const getTatLabel = (record = {}, index) => {
  const statusCode = String(record.status_code ?? '').trim().toUpperCase();
  const statusLabels = {
    WITHIN_TAT: 'Within TAT Target',
    BREACHED: 'Breached',
    BREACHED_TODAY: 'Breached Today',
  };

  if (statusLabels[statusCode]) {
    return statusLabels[statusCode];
  }

  const explicitLabel = firstValue(
    record.display_name,
    record.label,
    record.name,
    record.title,
    record.status,
    record.tat_status,
    record.sla_compliance,
    record.breached_status,
  );

  if (explicitLabel) {
    return humanize(explicitLabel);
  }

  if (record.breached !== null && record.breached !== undefined) {
    return Number(record.breached) === 1 ? 'Breached' : 'Within Tat Target';
  }

  return `Item ${index + 1}`;
};

const normalizeOpportunityTatRecords = (response, limit) => {
  const payload = response?.payload ?? response;
  const candidates = [
    payload?.records,
    payload?.summary,
    payload?.data,
    payload?.list,
    payload?.dashboard,
    payload?.dashboard_data,
    payload?.master,
    payload,
  ];
  const list = candidates.find((candidate) => Array.isArray(candidate));
  const endIndex = Number.isFinite(limit) ? limit : undefined;

  if (Array.isArray(list)) {
    return list.slice(0, endIndex).map((record, index) => ({
      label: getTatLabel(record, index),
      value: getRecordValue(record) ?? 0,
    }));
  }

  if (payload && typeof payload === 'object') {
    return Object.entries(payload)
      .filter(([, value]) => typeof value !== 'object' || value === null)
      .slice(0, endIndex)
      .map(([key, value]) => ({
        label: humanize(key),
        value: value ?? 0,
      }));
  }

  return [];
};

const getClickableHandler = (item, handler) =>
  Number(item?.value ?? 0) > 0 ? () => handler(item) : undefined;

const getNormalizedSummaryLabel = (label) =>
  String(label ?? '')
    .trim()
    .toLowerCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');

const getActivitySummaryView = (label) => {
  const normalized = getNormalizedSummaryLabel(label);
  if (normalized.includes('breach')) return 'breached';
  if (normalized === 'today' || normalized.includes('today')) return 'today';
  if (normalized.includes('upcoming')) return 'upcoming';
  return '';
};

const getRenewalSummaryAction = (label) => {
  const normalized = getNormalizedSummaryLabel(label);
  if (normalized.includes('breach')) return 'breached';
  if (normalized === 'today' || normalized.includes('today')) return 'today';
  if (normalized.includes('upcoming')) return 'upcoming';
  if (normalized.includes('converted') || normalized.includes('opportunity')) return 'converted';
  return '';
};

const SummaryCard = ({ item, tone = 'blue', compact = false, onClick }) => (
  <Box
    className={`rfq-dashboard-stat rfq-dashboard-stat--${tone}${compact ? ' rfq-dashboard-stat--compact' : ''}${onClick ? ' rfq-dashboard-stat--clickable' : ''}`}
    onClick={onClick}
    role={onClick ? 'button' : undefined}
    tabIndex={onClick ? 0 : undefined}
    onKeyDown={(event) => {
      if (!onClick || (event.key !== 'Enter' && event.key !== ' ')) return;
      event.preventDefault();
      onClick();
    }}
  >
    <Typography className="rfq-dashboard-stat-value">{item.value}</Typography>
    <Typography className="rfq-dashboard-stat-label">{item.label}</Typography>
  </Box>
);

const StageCard = ({ item, tone = 'blue', onClick }) => (
  <Box
    className={`rfq-dashboard-stage rfq-dashboard-stage--${tone}${onClick ? ' rfq-dashboard-stage--clickable' : ''}`}
    onClick={onClick}
    role={onClick ? 'button' : undefined}
    tabIndex={onClick ? 0 : undefined}
    onKeyDown={(event) => {
      if (!onClick || (event.key !== 'Enter' && event.key !== ' ')) return;
      event.preventDefault();
      onClick();
    }}
  >
    <Typography className="rfq-dashboard-stage-state">{item.label}</Typography>
    <Typography className="rfq-dashboard-stage-title">{item.title ?? item.label}</Typography>
    <Box className="rfq-dashboard-stage-bottom">
      <Typography className="rfq-dashboard-stage-value">{item.value}</Typography>
      <Typography className="rfq-dashboard-stage-meta">{item.meta ?? item.label}</Typography>
    </Box>
  </Box>
);

const SECTION_ICONS = {
  clients: BadgeRoundedIcon,
  clientStatus: BusinessCenterRoundedIcon,
  opportunityTat: TimerRoundedIcon,
  opportunitySummary: BarChartRoundedIcon,
  opportunityStages: AccountTreeRoundedIcon,
  activitySummary: EventAvailableRoundedIcon,
  renewalSummary: AutorenewRoundedIcon,
};

const DashboardSection = ({ title, icon: Icon, className = '', children }) => (
  <Box className={`rfq-dashboard-section ${className}`}>
    <Typography className="rfq-dashboard-section-title">
      {Icon ? <Icon className="rfq-dashboard-section-icon" fontSize="small" /> : null}
      <span>{title}</span>
    </Typography>
    <Box className="rfq-dashboard-section-divider" />
    {children}
  </Box>
);

const Dashboard = () => {
  const navigate = useNavigate();
  const [rangeCode, setRangeCode] = useState('today60');
  const [customRange, setCustomRange] = useState(() => getDateRange('today60'));
  const [lastRefreshedAt, setLastRefreshedAt] = useState(() => new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);
  const userName = useSelector((state) => state.user.userName);
  const loggedData = useSelector((state) => state.user.loggedData);
  const displayName = userName || loggedData?.UserName || loggedData?.name || 'User';
  const dateFilters = useMemo(
    () => (rangeCode === 'custom' ? customRange : getDateRange(rangeCode)),
    [customRange, rangeCode],
  );
  const resolvedDateRangeLabel = useMemo(
    () => `From: ${formatDisplayDate(dateFilters.fromDate)} · To: ${formatDisplayDate(dateFilters.toDate)}`,
    [dateFilters.fromDate, dateFilters.toDate],
  );

  const clientsQuery = useOpportunityDashboardSection(DASHBOARD_SECTIONS.clients, dateFilters);
  const clientStatusQuery = useOpportunityDashboardSection(DASHBOARD_SECTIONS.clientStatus, dateFilters);
  const opportunitySummaryQuery = useOpportunityDashboardSection(DASHBOARD_SECTIONS.opportunitySummary, dateFilters);
  const opportunityTatQuery = useOpportunityDashboardSection(DASHBOARD_SECTIONS.opportunityTat, dateFilters);
  const opportunityStagesQuery = useOpportunityDashboardSection(DASHBOARD_SECTIONS.opportunityStages, dateFilters);
  const activitySummaryQuery = useOpportunityDashboardSection(DASHBOARD_SECTIONS.activitySummary, dateFilters);
  const renewalSummaryQuery = useOpportunityDashboardSection(DASHBOARD_SECTIONS.renewalSummary, dateFilters);

  const clients = normalizeDashboardRecords(clientsQuery.data, SECTION_CARD_LIMITS.clients);
  const clientStatus = normalizeDashboardRecords(clientStatusQuery.data, SECTION_CARD_LIMITS.clientStatus);
  const opportunitySummary = normalizeDashboardRecords(opportunitySummaryQuery.data, SECTION_CARD_LIMITS.opportunitySummary);
  const opportunityTat = normalizeOpportunityTatRecords(opportunityTatQuery.data);
  const opportunityStages = normalizeOpportunityStageRecords(
    opportunityStagesQuery.data,
    SECTION_CARD_LIMITS.opportunityStages,
  );
  const activitySummary = normalizeDashboardRecords(activitySummaryQuery.data, SECTION_CARD_LIMITS.activitySummary);
  const renewalSummary = normalizeDashboardRecords(renewalSummaryQuery.data, SECTION_CARD_LIMITS.renewalSummary);
  const lastUpdated = lastRefreshedAt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  const showClientsSection = shouldShowDashboardSection(clientsQuery.data);
  const showClientStatusSection = shouldShowDashboardSection(clientStatusQuery.data);
  const showActivitySummarySection = shouldShowDashboardSection(activitySummaryQuery.data);
  const showRenewalSummarySection = shouldShowDashboardSection(renewalSummaryQuery.data);

  const clientRouteFilters = (extraFilters = {}) => ({
    fromDate: dateFilters.fromDate,
    toDate: dateFilters.toDate,
    dateRangePreset: 'CUSTOM',
    ...extraFilters,
  });

  const opportunityRouteFilters = (extraFilters = {}) => ({
    renewalFrom: dateFilters.fromDate,
    renewalTo: dateFilters.toDate,
    dateRangePreset: 'CUSTOM',
    dateFilterType: 'created_on',
    sortColumn: 'created_on',
    ...extraFilters,
  });

  const navigateToClients = (filters) => {
    navigate(encodedRoutePath(ROUTES.clients), { state: { filters } });
  };

  const navigateToOpportunities = (filters) => {
    navigate(encodedRoutePath(ROUTES.opportunities), { state: { filters } });
  };

  const navigateToActivities = (view, filters) => {
    navigate(encodedRoutePath(ROUTES.activities), { state: { view, filters } });
  };

  const navigateToRenewals = (filters) => {
    navigate(encodedRoutePath(ROUTES.renewals), { state: { filters } });
  };

  const getRelativeActivityFilters = (view) => {
    const today = new Date();
    const todayDate = formatDate(today);
    if (view === 'breached') {
      return {
        fromDate: dateFilters.fromDate,
        toDate: formatDate(addDays(today, -1)),
      };
    }
    if (view === 'today') {
      return {
        fromDate: todayDate,
        toDate: todayDate,
      };
    }
    if (view === 'upcoming') {
      return {
        fromDate: formatDate(addDays(today, 1)),
        toDate: dateFilters.toDate,
      };
    }
    return null;
  };

  const getRelativeRenewalFilters = (action) => {
    const today = new Date();
    const todayDate = formatDate(today);
    if (action === 'breached') {
      return {
        fromDate: dateFilters.fromDate,
        toDate: formatDate(addDays(today, -1)),
        dateRangePreset: 'CUSTOM',
      };
    }
    if (action === 'today') {
      return {
        fromDate: todayDate,
        toDate: todayDate,
        dateRangePreset: 'CUSTOM',
      };
    }
    if (action === 'upcoming') {
      return {
        fromDate: formatDate(addDays(today, 1)),
        toDate: dateFilters.toDate,
        dateRangePreset: 'CUSTOM',
      };
    }
    if (action === 'converted') {
      return {
        fromDate: dateFilters.fromDate,
        toDate: dateFilters.toDate,
        dateRangePreset: 'CUSTOM',
        renewalStatus: 'RLS_OPPORTUNITY',
      };
    }
    return null;
  };

  const handleClientActiveClick = (item) => {
    navigateToClients(clientRouteFilters({ activeState: item.label }));
  };

  const handleClientStatusClick = (item) => {
    navigateToClients(clientRouteFilters({ clientStatus: item.label, clientStatusLabel: item.label }));
  };

  const handleOpportunityTatClick = (item) => {
    const label = String(item.label ?? '').toLowerCase();
    const filters = opportunityRouteFilters({
      breached: label.includes('within') ? '0' : '1',
    });

    navigateToOpportunities(filters);
  };

  const handleOpportunitySummaryClick = (item) => {
    navigateToOpportunities(opportunityRouteFilters({
      opportunityStatus: item.label,
      opportunityStatusLabel: item.label,
    }));
  };

  const handleOpportunityStageClick = (item) => {
    navigateToOpportunities(opportunityRouteFilters({
      opportunityStage: item.filterValue || item.label,
      opportunityStageLabel: item.label,
    }));
  };

  const handleActivitySummaryClick = (item) => {
    const view = getActivitySummaryView(item.label);
    const filters = getRelativeActivityFilters(view);
    if (!view || !filters) return;
    navigateToActivities(view, filters);
  };

  const handleRenewalSummaryClick = (item) => {
    const action = getRenewalSummaryAction(item.label);
    const filters = getRelativeRenewalFilters(action);
    if (!action || !filters) return;
    navigateToRenewals(filters);
  };

  const getActivitySummaryClickHandler = (item) =>
    getActivitySummaryView(item.label) ? () => handleActivitySummaryClick(item) : undefined;

  const getRenewalSummaryClickHandler = (item) =>
    getRenewalSummaryAction(item.label) ? () => handleRenewalSummaryClick(item) : undefined;

  const handleRefreshDashboard = async () => {
    setIsRefreshing(true);
    await Promise.allSettled([
      clientsQuery.refetch(),
      clientStatusQuery.refetch(),
      opportunitySummaryQuery.refetch(),
      opportunityTatQuery.refetch(),
      opportunityStagesQuery.refetch(),
      activitySummaryQuery.refetch(),
      renewalSummaryQuery.refetch(),
    ]);
    setLastRefreshedAt(new Date());
    setIsRefreshing(false);
  };

  return (
    <Box className="rfq-dashboard-page">
      <Box className="rfq-dashboard-header">
        <Box>
          <Typography className="rfq-dashboard-greeting">
            {getGreeting()}, {displayName}
          </Typography>
          <Box className="rfq-dashboard-updated-row">
            <Typography className="rfq-dashboard-updated">Last Updated: {lastUpdated}</Typography>
            <Tooltip title="Refresh dashboard">
              <span>
                <IconButton
                  className="rfq-dashboard-refresh"
                  size="small"
                  onClick={handleRefreshDashboard}
                  disabled={isRefreshing}
                  aria-label="Refresh dashboard"
                >
                  <RefreshRoundedIcon fontSize="small" />
                </IconButton>
              </span>
            </Tooltip>
          </Box>
        </Box>
        <Box className="rfq-dashboard-range-wrap">
          <Box className="rfq-dashboard-range-controls">
            <FormControl className="rfq-dashboard-range-control" size="small">
              <Select
                value={rangeCode}
                onChange={(event) => {
                  const nextRangeCode = event.target.value;
                  setRangeCode(nextRangeCode);
                  if (nextRangeCode !== 'custom') {
                    setCustomRange(getDateRange(nextRangeCode));
                  }
                  setLastRefreshedAt(new Date());
                }}
                displayEmpty
              >
                {RANGE_OPTIONS.map((option) => (
                  <MenuItem key={option.code} value={option.code}>
                    {option.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {rangeCode === 'custom' ? (
              <Box className="rfq-dashboard-custom-range">
                <Box className="rfq-dashboard-custom-date-field">
                  <Typography className="rfq-dashboard-custom-date-label">From</Typography>
                  <TextField
                    size="small"
                    type="date"
                    value={customRange.fromDate}
                    onChange={(event) => {
                      setCustomRange((current) => ({ ...current, fromDate: event.target.value }));
                      setLastRefreshedAt(new Date());
                    }}
                    inputProps={{ max: customRange.toDate || undefined }}
                  />
                </Box>
                <Box className="rfq-dashboard-custom-date-field">
                  <Typography className="rfq-dashboard-custom-date-label">To</Typography>
                  <TextField
                    size="small"
                    type="date"
                    value={customRange.toDate}
                    onChange={(event) => {
                      setCustomRange((current) => ({ ...current, toDate: event.target.value }));
                      setLastRefreshedAt(new Date());
                    }}
                    inputProps={{ min: customRange.fromDate || undefined }}
                  />
                </Box>
              </Box>
            ) : null}
          </Box>
          <Typography className="rfq-dashboard-range-resolved">{resolvedDateRangeLabel}</Typography>
        </Box>
      </Box>

      <Box className="rfq-dashboard-grid">
        {showClientsSection ? (
          <DashboardSection title="Clients" icon={SECTION_ICONS.clients} className="rfq-dashboard-section--clients">
            <Box className="rfq-dashboard-stat-grid rfq-dashboard-stat-grid--two">
              {clients.map((item) => (
                <SummaryCard key={item.label} item={item} tone={getDashboardStatusTone(item.label)} onClick={getClickableHandler(item, handleClientActiveClick)} />
              ))}
            </Box>
          </DashboardSection>
        ) : null}

        {showClientStatusSection ? (
          <DashboardSection
            title="Client's Status Summary"
            icon={SECTION_ICONS.clientStatus}
            className="rfq-dashboard-section--client-status"
          >
            <Box className="rfq-dashboard-stat-grid rfq-dashboard-stat-grid--four">
              {clientStatus.map((item) => (
                <SummaryCard key={item.label} item={item} tone={getDashboardStatusTone(item.label)} compact onClick={getClickableHandler(item, handleClientStatusClick)} />
              ))}
            </Box>
          </DashboardSection>
        ) : null}

        <DashboardSection
          title="In Progress Opportunity TAT"
          icon={SECTION_ICONS.opportunityTat}
          className="rfq-dashboard-section--tat"
        >
          <Box className="rfq-dashboard-stat-grid rfq-dashboard-stat-grid--tat">
            {opportunityTat.map((item) => (
              <SummaryCard key={item.label} item={item} tone={getDashboardStatusTone(item.label)} onClick={getClickableHandler(item, handleOpportunityTatClick)} />
            ))}
          </Box>
        </DashboardSection>

        <DashboardSection
          title="Opportunity Summary"
          icon={SECTION_ICONS.opportunitySummary}
          className="rfq-dashboard-section--opportunity-summary"
        >
          <Box className="rfq-dashboard-stat-grid rfq-dashboard-stat-grid--four">
            {opportunitySummary.map((item) => (
              <SummaryCard key={item.label} item={item} tone={getDashboardStatusTone(item.label)} onClick={getClickableHandler(item, handleOpportunitySummaryClick)} />
            ))}
          </Box>
        </DashboardSection>

        {showActivitySummarySection ? (
          <DashboardSection
            title="Activity Summary"
            icon={SECTION_ICONS.activitySummary}
            className="rfq-dashboard-section--activity-summary"
          >
            <Box className="rfq-dashboard-stat-grid rfq-dashboard-stat-grid--four">
              {activitySummary.map((item) => (
                <SummaryCard
                  key={item.label}
                  item={item}
                  tone={getDashboardStatusTone(item.label)}
                  compact
                  onClick={getActivitySummaryClickHandler(item)}
                />
              ))}
            </Box>
          </DashboardSection>
        ) : null}

        {showRenewalSummarySection ? (
          <DashboardSection
            title="Renewal Summary"
            icon={SECTION_ICONS.renewalSummary}
            className="rfq-dashboard-section--renewal-summary"
          >
            <Box className="rfq-dashboard-stat-grid rfq-dashboard-stat-grid--four">
              {renewalSummary.map((item) => (
                <SummaryCard
                  key={item.label}
                  item={item}
                  tone={getDashboardStatusTone(item.label)}
                  compact
                  onClick={getRenewalSummaryClickHandler(item)}
                />
              ))}
            </Box>
          </DashboardSection>
        ) : null}

        <DashboardSection
          title="Opportunity Stage"
          icon={SECTION_ICONS.opportunityStages}
          className="rfq-dashboard-section--stages"
        >
          <Box className="rfq-dashboard-stage-grid">
            {opportunityStages.map((item, index) => (
              <StageCard
                key={item.label}
                item={item}
                tone={index === opportunityStages.length - 1 ? 'slate' : CARD_TONES[index] ?? 'blue'}
                onClick={getClickableHandler(item, handleOpportunityStageClick)}
              />
            ))}
          </Box>
        </DashboardSection>
      </Box>
    </Box>
  );
};

export default Dashboard;
