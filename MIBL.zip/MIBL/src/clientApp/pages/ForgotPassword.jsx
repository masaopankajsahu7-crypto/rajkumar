import { useState, useEffect, useRef } from 'react';
import insurance from '../assets/images/insurance.svg'
// import logo from '../assets/images/logo.svg'
import logo from '../assets/images/logoMySaathi.svg'
import { Container, Paper, Box, Stack, TextField, Typography, Button, IconButton, Grid, FormHelperText } from '@mui/material';
import { VisibilityOffOutlined, VisibilityOutlined } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { sendOTP, verifyOTP } from '../services/api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import passwordReset from "../assets/images/passwordReset.svg";
import useMediaQuery from '@mui/material/useMediaQuery';
import BackdropLoader from '../components/Loader/BackdropLoader';
import { APP_CONFIG } from '../config/appConfig.js';
import { AUTH_MESSAGES as MSG } from '../config/messages/auth.js';
import { ROUTES } from '../config/routes.js';
import {
  truncateAuthField,
  validateLoginEmailOrMobile,
  validateLoginPassword,
  validateOtp,
  validatePasswordMatch,
} from '../utils/authFormValidation.js';
import './ForgotPassword.css';

const Forgot = () => {
  const isDesktop = useMediaQuery('(min-width:626px)');
  const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState({ otp: "" });
  const [isEmailSent, setIsEmailSent] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const prevEmail = useRef('');
  const navigate = useNavigate();
  const [forgotScreen, setForgotScreen] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [rePassword, setRePassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [otpTouched, setOtpTouched] = useState(false);

  const [timeLeft, setTimeLeft] = useState(APP_CONFIG.OTP_RESEND_TIMER_SECONDS);
  const [isResendEnabled, setIsResendEnabled] = useState(false);

  // const handleOtpChange = (e) => {
  //   setOtp(e.target.value.slice(0, 6));
  //   setOtpTouched(false); // Reset error display while typing
  // };

  useEffect(() => {
    if (timeLeft <= 0) {
      setIsResendEnabled(true);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const formatTime = (seconds) => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };


  const handleResend = () => {
    setTimeLeft(APP_CONFIG.OTP_RESEND_TIMER_SECONDS);
    setIsResendEnabled(false);
    handleSendOtp();
  };

  const handlePasswordChange = (e) => {
    setPassword(truncateAuthField('passwordForgot', e.target.value));
  };

  const handleRePasswordChange = (e) => {
    setRePassword(truncateAuthField('passwordForgot', e.target.value));
  };

  const validateEmail = () => validateLoginEmailOrMobile(email);

  const validatePassword = () => validateLoginPassword(password, 'passwordForgot');

  const handleSendOtp = async () => {
    const emailError = validateEmail();
    if (emailError) {
      setErrors({ email: emailError });
      return;
    }
    try {
      setLoading(true);
      const data = await sendOTP(email);
      if (data.data?.success) {
        setTimeLeft(APP_CONFIG.OTP_RESEND_TIMER_SECONDS);
        setTimeout(() => {
          toast.success(MSG.toast.otpSentForgot);
          setIsResendEnabled(false);
        }, 1000);
      } else if (data.status === 401) {
        toast.error(data.msg || MSG.toast.invalidCredentials);
        return;
      }
      setIsEmailSent(true);
      setStep(2);

    } catch (error) {
      toast.error(`${MSG.toast.otpSendError} ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    setOtpTouched(true);

    // if (timeLeft <= 0) {
    //   toast.info("OTP expired. Please request a new one.");
    //   return;
    // }

    const passwordError = validatePassword();
    const otpError = validateOtp(otp);
    const rePasswordError = validatePasswordMatch(password, rePassword);

    const currentErrors = {
      otp: otpError,
      password: passwordError,
      rePassword: rePasswordError,
    };

    setErrors(currentErrors);

    const hasErrors = Object.values(currentErrors).some(Boolean);
    if (hasErrors) {
      // // 🔓 Temporarily show both passwords if there are errors
      // setShowPassword(true);
      // setShowRePassword(true);

      // // Optional: Hide passwords again after a delay
      // setTimeout(() => {
      //   setShowPassword(false);
      //   setShowRePassword(false);
      // }, 5000); // 5 seconds
      return;
    }

    // Proceed with actual password reset logic here

    try {
      setLoading(true);
      const response = await verifyOTP({ email, otp, password });
      if (response.status_message === MSG.toast.otpInvalid) {
        toast.error(response.status_message);
      } else if (response.status_code === "200" || response.message === "OTP verified and your password changed Successfully") {
        setStep(3);
        setTimeout(() => {
          toast.success(MSG.toast.otpVerified);
        }, 1000);
      } else {
        toast.error(response.status_message);
        return;
      }
    } catch (error) {
      toast.error(MSG.toast.otpVerifyError);
    } finally {
      setLoading(false);
    }
  };

  // const handleResetPassword = async () => {
  //   const pwdError = validatePassword();
  //   const confirmError = password !== confirmPassword ? 'Passwords do not match.' : '';

  //   if (pwdError || confirmError) {
  //     setErrors({ password: pwdError, confirmPassword: confirmError });
  //     return;
  //   }

  //   try {
  //     const data = await resetPasswordUser(email, password, confirmPassword);
  //     if (data.status === 400) {
  //       toast.error('Password reset failed. Try Again.');
  //       return;
  //     } else {
  //       toast.success('Password changed successfully for:', email);
  //       navigate('/');
  //     }
  //   } catch (error) {
  //     toast.error('An error occurred during Password Reset. Please try again.');
  //   }
  // };

  useEffect(() => {
    const emailChanged = email != prevEmail.current;

    if (isEmailSent && emailChanged && validateEmail() == '') {
      prevEmail.current = email;
      setIsEmailSent(false);
    }
    if (errors.email) {
      let tempErrors = errors;
      tempErrors.email = validateEmail();
      setErrors(tempErrors)
    }
  }, [email]);

  useEffect(() => {
    if (!!errors.password || !!errors.confirmPassword || errors.password == '') {
      let tempErrors = {
        password: validatePassword(),
        confirmPassword: password !== confirmPassword ? 'Passwords do not match.' : ''
      };
      setErrors(tempErrors);
    }
  }, [password, confirmPassword]);

  const handleBackToLogin = () => {
    navigate(ROUTES.login);
  };

  const handleToggleShowPassword = () => {
    setShowPassword((prev) => !prev);
  };

  const handleToggleShowRePassword = () => {
    setShowRePassword((prev) => !prev);
  };

  return (
    <>
      <BackdropLoader loading={loading} />

      <Container className={`forgot-page ${isDesktop ? 'forgot-page--desktop' : ''}`}>
        <Paper elevation={0} className="forgot-outer-paper">
          <Grid container>
            {/* Screen left */}

            <Grid size={{ xs: 12, sm: 6.2, md: 5.5 }} className="forgot-brand-col">
              <Paper elevation={0} className="forgot-brand-panel">
                <Stack className="forgot-brand-stack">
                  <Box className="forgot-logo-box">
                    <img src={logo} width="70%" className="center-image" alt="MySaathi logo" />
                  </Box>

                  <Box className="forgot-illustration-box">
                    <img
                      src={insurance}
                      width={isMobile ? '65%' : '100%'}
                      className="center-image"
                      alt=""
                    />
                  </Box>
                </Stack>
              </Paper>
            </Grid>

            {step == 1 && <Grid size={{ xs: 12, sm: 5.8, md: 6.5 }} className="forgot-form-col">
              <Stack className="forgot-form-stack">
                <Box className="forgot-heading-box">
                  <Typography className={`georama-SemiBold text-dark forgot-h1 forgot-h1--step1 ${isMobile ? 'fs-24' : 'fs-32'}`}>{MSG.forgot.title}</Typography>
                  <Typography className="georama-Medium font-size-16 text-gray forgot-h2">
                    {MSG.forgot.subtitle}
                  </Typography>
                </Box>

                <Box className="forgot-form-outer">
                  <Box>
                    <Typography className="text-labels forgot-lbl-mb">
                      {MSG.forgot.emailLabel} <span className="important-fields">*</span>
                    </Typography>

                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      value={email}
                      placeholder={MSG.forgot.emailPlaceholder}
                      disabled={step > 2}
                      onChange={(e) => setEmail(truncateAuthField('emailOrMobile', e.target.value))}
                    />

                    {errors.email && (
                      <FormHelperText className="important-fields">{errors.email}</FormHelperText>
                    )}

                    <Button className="btn-common-red border-radius-32 forgot-btn-reset" onClick={handleSendOtp}>
                      {MSG.forgot.resetPassword}
                    </Button>
                  </Box>

                  <Button
                    className="text-capitalize georama-medium-selected custom-starticon forgot-btn-back"
                    startIcon={<ChevronLeftIcon />}
                    onClick={handleBackToLogin}>
                    {MSG.forgot.backToLogin}
                  </Button>
                </Box>
              </Stack>
            </Grid>
            }

            {step == 2 && <Grid size={{ xs: 12, sm: 5.8, md: 6.5 }} className="forgot-form-col">
              <Stack className="forgot-form-stack">
                <Box className="forgot-heading-box">
                  <Typography className={`georama-SemiBold forgot-h1 ${isMobile ? 'fs-24' : 'fs-32'} text-dark`}>Check your email</Typography>
                  <Typography className="georama-Medium font-size-16 text-gray center-text forgot-h2">
                    Please enter your 6-digit code. Then create and
                    confirm your new password.
                  </Typography>
                </Box>

                <>
                  <Box>
                    <Typography className="text-labels forgot-lbl-mb">
                      6 Digit Code <span className="important-fields">*</span>
                    </Typography>

                    <Box className="forgot-field-row">
                      <TextField
                        className="form-control-input border-radius-8"
                        size="small"
                        fullWidth
                        required
                        placeholder="Enter 6 Digit OTP"
                        value={otp}
                        onChange={(e) => {
                          const value = e.target.value;
                          // Allow only numbers and max 6 digits
                          if (/^\d{0,6}$/.test(value)) {
                            setOtp(value);
                          }
                        }}
                        inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}
                        type="text"
                        InputProps={{ disableUnderline: true }}
                      />
                    </Box>

                    {otpTouched && errors.otp && <FormHelperText className="important-fields">{errors.otp}</FormHelperText>}

                    {/* Timer & Resend */}
                    <Box className="forgot-otp-meta">
                      <Typography className="highlight-red fs-10 forgot-otp-validity">
                        OTP is valid for 10 minutes
                      </Typography>
                      {isResendEnabled ? (
                        <Button className="highlight-red fs-12" onClick={handleResend}>
                          Resend OTP
                        </Button>
                      ) : (
                        <Typography className="highlight-red fs-12">
                          Resend in {formatTime(timeLeft)}
                        </Typography>
                      )}
                    </Box>
                  </Box>

                  <Box>
                    <Typography className="text-labels forgot-lbl-mb">
                      New Password <span className="important-fields">*</span>
                    </Typography>

                    <Box className="forgot-field-row">
                      <TextField
                        className="form-control-input border-radius-8"
                        size="small"
                        fullWidth
                        required
                        placeholder="Enter New Password"
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={handlePasswordChange}
                        InputProps={{
                          endAdornment: (
                            <IconButton onClick={handleToggleShowPassword} edge="end">
                              {showPassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                            </IconButton>
                          ),
                          disableUnderline: true,
                        }}
                      />
                    </Box>

                    {errors.password && otpTouched && (
                      <FormHelperText className="important-fields">{errors.password}</FormHelperText>
                    )}
                  </Box>

                  <Box>
                    <Typography className="text-labels forgot-lbl-mb">
                      Re-Enter New Password <span className="important-fields">*</span>
                    </Typography>

                    <Box className="forgot-field-row">
                      <TextField
                        className="form-control-input border-radius-8"
                        size="small"
                        fullWidth
                        required
                        placeholder="Re-Enter New Password"
                        type={showRePassword ? 'text' : 'password'}
                        value={rePassword}
                        onChange={handleRePasswordChange}
                        InputProps={{
                          endAdornment: (
                            <IconButton onClick={handleToggleShowRePassword} edge="end">
                              {showRePassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                            </IconButton>
                          ),
                          disableUnderline: true,
                        }}
                      />
                    </Box>

                    {errors.rePassword && otpTouched && (
                      <FormHelperText className="important-fields">{errors.rePassword}</FormHelperText>
                    )}
                  </Box>

                  <Button
                    className="btn-common-red border-radius-32 forgot-btn-reset forgot-btn-reset--sm"
                    onClick={handleVerifyOtp}>
                    Reset Password
                  </Button>

                  <Button
                    className="text-capitalize georama-medium-selected custom-starticon forgot-btn-back"
                    startIcon={<ChevronLeftIcon />}
                    onClick={handleBackToLogin}>
                    {MSG.forgot.backToLogin}
                  </Button>
                </>
              </Stack>
            </Grid>
            }

            {step == 3 && <Grid size={{ xs: 12, sm: 5.8, md: 6.5 }} className="forgot-form-col">
              <Stack className="forgot-form-stack">
                <Box className="forgot-step3-box">
                  <img src={passwordReset} className="password-reset-image" width="280px" height="96px" alt="" />

                  <Box className="forgot-step3-inner">
                    <Typography className="georama-SemiBold text-dark fs-32 forgot-h1">Password Reset</Typography>
                    <Typography className="georama-Medium font-size-16 text-gray center-text forgot-h2">
                      Your password has been successfully reset. <br />
                      Click below to log in.
                    </Typography>
                  </Box>

                  <Button className="btn-common-red border-radius-32 forgot-step3-btn" onClick={handleBackToLogin}>
                    {MSG.forgot.backToLogin}
                  </Button>
                </Box>
              </Stack>
            </Grid>
            }

          </Grid>

        </Paper >
        <ToastContainer autoClose={1000} />
      </Container >

    </>
  );
};

export default Forgot;
