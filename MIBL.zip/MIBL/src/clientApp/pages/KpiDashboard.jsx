import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import {
  Box,
  Button,
  FormControl,
  IconButton,
  MenuItem,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import DownloadOutlinedIcon from '@mui/icons-material/DownloadOutlined';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import GroupsRoundedIcon from '@mui/icons-material/GroupsRounded';
import TrendingUpRoundedIcon from '@mui/icons-material/TrendingUpRounded';
import AutorenewRoundedIcon from '@mui/icons-material/AutorenewRounded';
import EventAvailableRoundedIcon from '@mui/icons-material/EventAvailableRounded';
import CurrencyRupeeRoundedIcon from '@mui/icons-material/CurrencyRupeeRounded';
import { toast } from 'react-toastify';
import { useOpportunityDashboardSection } from '../hooks/useFetchQueries.js';
import './KpiDashboard.css';

const DOMAINS = ['clients', 'opportunities', 'renewals', 'activities'];
const DOMAIN_LABELS = { clients: 'Clients', opportunities: 'Opportunities', renewals: 'Renewals', activities: 'Activities' };
const DOMAIN_ICONS = {
  clients: GroupsRoundedIcon,
  opportunities: TrendingUpRoundedIcon,
  renewals: AutorenewRoundedIcon,
  activities: EventAvailableRoundedIcon,
};
const RANGE_OPTIONS = [
  { code: 'today30', label: 'Today (+/-30 Days)' },
  { code: 'currentMonth', label: 'Current Month' },
  { code: 'previousMonth', label: 'Previous Month' },
  { code: 'last3Months', label: 'Last 3 Months' },
  { code: 'nextMonth', label: 'Next Month' },
  { code: 'next3Months', label: 'Next 3 Months' },
];

const numberFmt = new Intl.NumberFormat('en-IN');
const moneyFmt = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });
const dateFmt = new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
const dateTimeFmt = new Intl.DateTimeFormat('en-GB', {
  day: '2-digit',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hour12: true,
});

const pad = (value) => String(value).padStart(2, '0');
const inputDate = (date) => `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
const startOfMonth = (date) => new Date(date.getFullYear(), date.getMonth(), 1);
const endOfMonth = (date) => new Date(date.getFullYear(), date.getMonth() + 1, 0);
const addDays = (date, days) => {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
};

const getDateRange = (rangeCode) => {
  const today = new Date();
  switch (rangeCode) {
    case 'currentMonth':
      return { fromDate: inputDate(startOfMonth(today)), toDate: inputDate(endOfMonth(today)) };
    case 'previousMonth': {
      const previous = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      return { fromDate: inputDate(startOfMonth(previous)), toDate: inputDate(endOfMonth(previous)) };
    }
    case 'last3Months': {
      const from = new Date(today.getFullYear(), today.getMonth() - 2, 1);
      return { fromDate: inputDate(startOfMonth(from)), toDate: inputDate(endOfMonth(today)) };
    }
    case 'nextMonth': {
      const next = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      return { fromDate: inputDate(startOfMonth(next)), toDate: inputDate(endOfMonth(next)) };
    }
    case 'next3Months': {
      const from = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 3, 1);
      return { fromDate: inputDate(startOfMonth(from)), toDate: inputDate(endOfMonth(to)) };
    }
    case 'today30':
    default:
      return { fromDate: inputDate(addDays(today, -30)), toDate: inputDate(addDays(today, 30)) };
  }
};

const num = (value) => numberFmt.format(Number(value || 0));
const money = (value) => moneyFmt.format(Number(value || 0));
const shortMoney = (value) => {
  const amount = Number(value || 0);
  const absolute = Math.abs(amount);
  if (absolute >= 1e7) return `INR ${(amount / 1e7).toFixed(2)} Cr`;
  if (absolute >= 1e5) return `INR ${(amount / 1e5).toFixed(2)} L`;
  if (absolute >= 1e3) return `INR ${(amount / 1e3).toFixed(1)} K`;
  return money(amount);
};
const showDate = (value) => (value ? dateFmt.format(new Date(String(value).replace(' ', 'T'))) : '--');
const showDateTime = (value) => (value ? dateTimeFmt.format(new Date(String(value).replace(' ', 'T'))) : '--');
const humanize = (field) => String(field ?? '').replaceAll('_', ' ').replace(/\b\w/g, (char) => char.toUpperCase());

const normalizeKpiInput = (input) => {
  const payload = input?.payload ?? input;
  const normalizeScope = (scope = {}) => ({
    summary: scope.summary ?? {},
    team_summary: Array.isArray(scope.team_summary) ? scope.team_summary : [],
    clients: Array.isArray(scope.clients) ? scope.clients : [],
    renewals: Array.isArray(scope.renewals) ? scope.renewals : [],
    opportunities: Array.isArray(scope.opportunities) ? scope.opportunities : [],
    activities: Array.isArray(scope.activities) ? scope.activities : [],
  });

  if (!payload || typeof payload !== 'object') {
    return {
      filters: {},
      attention: normalizeScope(),
      period_work: normalizeScope(),
      hierarchy_users: [],
    };
  }

  return {
    ...payload,
    filters: payload.filters ?? {},
    attention: normalizeScope(payload.attention),
    period_work: normalizeScope(payload.period_work),
    hierarchy_users: Array.isArray(payload.hierarchy_users) ? payload.hierarchy_users : [],
  };
};

const teamKey = (row) => (row?.bucket_type === 'UNASSIGNED' ? 'unassigned' : String(row?.team_user_id ?? ''));
const workDomain = (summary, domain) => summary?.[domain] ?? {};
const recordOwner = (domain, row) => {
  if (domain === 'clients') return row.owner_id;
  if (domain === 'renewals') return row.assigned_owner_id;
  if (domain === 'opportunities') return row.primary_owner_id;
  return row.responsible_user_id;
};

const belongsToTeam = (payload, selectedTeam, userId) => {
  if (selectedTeam === 'all') return true;
  if (selectedTeam === 'unassigned') return userId === null || userId === undefined || userId === '';
  const id = Number(userId);
  const team = Number(selectedTeam);
  return payload.hierarchy_users.some(
    (user) => Number(user.user_id) === id && (Number(user.team_user_id) === team || Number(user.user_id) === team),
  );
};

const recordsFor = (payload, scope, domain, selectedTeam) =>
  (payload[scope]?.[domain] ?? []).filter((row) => belongsToTeam(payload, selectedTeam, recordOwner(domain, row)));

const teamDisplayName = (payload, teamId) => {
  if (teamId === 'unassigned') return 'Unassigned';
  const user = payload.hierarchy_users.find((item) => String(item.team_user_id ?? item.user_id ?? '') === String(teamId));
  return user?.team_user_name || user?.user_name || `Team ${teamId}`;
};

const attentionDomainCount = (summary, domain) =>
  Number({
    clients: summary?.clients_not_approved,
    opportunities: summary?.opportunities_breached,
    renewals: summary?.renewals_pending,
    activities: summary?.activities_breached,
  }[domain] || 0);

const periodDomainCount = (summary, domain) => {
  const values = workDomain(summary, domain);
  if (domain === 'clients') return Number(values.new || 0);
  if (domain === 'opportunities') return Number(values.new || 0);
  if (domain === 'renewals') return Number(values.due || 0);
  return Number(values.scheduled_total || 0);
};

const searchable = (row) =>
  Object.values(row ?? {})
    .flatMap((value) => {
      if (Array.isArray(value)) return value.map((item) => (typeof item === 'object' ? Object.values(item).join(' ') : item));
      if (value && typeof value === 'object') return Object.values(value);
      return value;
    })
    .join(' ')
    .toLowerCase();

const sortRows = (domain, rows) => {
  const copy = [...rows];
  if (domain === 'renewals') return copy.sort((a, b) => Number(b.breached_days || 0) - Number(a.breached_days || 0) || Number(a.renewal_days || 0) - Number(b.renewal_days || 0));
  if (domain === 'opportunities') return copy.sort((a, b) => Number(b.is_attention || 0) - Number(a.is_attention || 0) || Number(b.breached_days || 0) - Number(a.breached_days || 0));
  if (domain === 'clients') return copy.sort((a, b) => Number(b.is_over_threshold || 0) - Number(a.is_over_threshold || 0) || String(b.created_on || '').localeCompare(String(a.created_on || '')));
  return copy.sort((a, b) => Number(b.breached_days || 0) - Number(a.breached_days || 0) || String(b.scheduled_at || '').localeCompare(String(a.scheduled_at || '')));
};

const statusTone = (value) => {
  const normalized = String(value ?? '').toLowerCase();
  if (normalized.includes('reject') || normalized.includes('breach') || normalized.includes('lost')) return 'red';
  if (normalized.includes('pending') || normalized.includes('open') || normalized.includes('scheduled')) return 'amber';
  if (normalized.includes('approved') || normalized.includes('completed') || normalized.includes('won')) return 'green';
  return 'slate';
};

const detailShape = (scope, domain, row) => {
  if (domain === 'clients') {
    return {
      heads: scope === 'attention'
        ? ['Client', 'Owner', 'Status', 'Created On', 'Pending', 'Threshold']
        : ['Client', 'Owner', 'Status', 'Created On', 'Approved On', 'Period Status'],
      cells: scope === 'attention'
        ? [
            { primary: row.client_name, secondary: `Client #${row.client_id ?? ''}` },
            row.owner_name || 'Unassigned',
            { badge: row.client_status, tone: statusTone(row.client_status) },
            showDateTime(row.created_on),
            `${num(row.pending_working_days)} days`,
            row.is_over_threshold ? { badge: `${num(row.over_threshold_days)} days over`, tone: 'red' } : { badge: 'Within threshold', tone: 'green' },
          ]
        : [
            { primary: row.client_name, secondary: `Client #${row.client_id ?? ''}` },
            row.owner_name || 'Unassigned',
            { badge: row.client_status, tone: statusTone(row.client_status) },
            showDateTime(row.created_on),
            showDateTime(row.approved_on),
            { badge: String(row.period_status || '').replaceAll('_', ' '), tone: statusTone(row.period_status) },
          ],
    };
  }

  if (domain === 'renewals') {
    return {
      heads: ['Customer', 'Owner', 'Policy', 'Expiry', 'Renewal Days', 'Premium', 'Brokerage', 'Status'],
      cells: [
        { primary: row.customer_name, secondary: row.product || row.sub_product || '' },
        row.assigned_owner_name || 'Unassigned',
        row.policy_no,
        showDate(row.policy_expiry_date),
        `${num(row.renewal_days)} days`,
        shortMoney(row.net_premium),
        shortMoney(row.brokerage_amount),
        { badge: row.renewal_status || row.period_status, tone: statusTone(row.renewal_status || row.period_status) },
      ],
    };
  }

  if (domain === 'opportunities') {
    return {
      heads: ['Client', 'Owner', 'Product', 'Status', 'Created/Breached', 'Premium', 'Brokerage', 'Renewal Date'],
      cells: [
        { primary: row.client_name, secondary: `Opportunity #${row.opportunity_id ?? ''}` },
        row.primary_owner_name || 'Unassigned',
        row.product || row.sub_product || '',
        { badge: row.opportunity_status || row.period_status, tone: statusTone(row.opportunity_status || row.period_status) },
        scope === 'attention' ? showDateTime(row.breached_date) : showDateTime(row.created_on),
        shortMoney(row.expected_premium),
        shortMoney(row.brokerage_amount),
        showDate(row.renewal_date),
      ],
    };
  }

  return {
    heads: ['Activity', 'Client', 'Responsible User', 'Scheduled At', 'Type', 'Mode', 'Status', 'Breach'],
    cells: [
      { primary: row.activity_name, secondary: row.activity_code },
      row.client_name,
      row.responsible_user_name || 'Unassigned',
      showDateTime(row.scheduled_at),
      row.activity_type,
      row.meeting_mode,
      { badge: row.meeting_status || row.period_status, tone: statusTone(row.meeting_status || row.period_status) },
      row.breached_days ? `${num(row.breached_days)} days` : '--',
    ],
  };
};

const flatten = (row) => {
  const output = {};
  Object.entries(row ?? {}).forEach(([key, value]) => {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      Object.entries(value).forEach(([child, childValue]) => {
        output[`${humanize(key)} - ${humanize(child)}`] = childValue ?? '';
      });
      return;
    }
    output[humanize(key)] = Array.isArray(value) ? JSON.stringify(value) : value ?? '';
  });
  return output;
};

const makeSheet = (rows) => {
  const flattened = rows.length ? rows.map(flatten) : [{ Message: 'No records available' }];
  const headers = [...new Set(flattened.flatMap((row) => Object.keys(row)))];
  const safeRows = flattened.map((row) => Object.fromEntries(headers.map((header) => [header, row[header] ?? ''])));
  const sheet = XLSX.utils.json_to_sheet(safeRows, { header: headers });
  sheet['!cols'] = headers.map((header) => ({
    wch: Math.min(42, Math.max(12, header.length + 2, ...safeRows.slice(0, 100).map((row) => String(row[header] ?? '').length + 2))),
  }));
  if (rows.length) sheet['!autofilter'] = { ref: `A1:${XLSX.utils.encode_col(headers.length - 1)}${safeRows.length + 1}` };
  return sheet;
};

const appendSheet = (workbook, name, rows) => XLSX.utils.book_append_sheet(workbook, makeSheet(rows), name);

const getSummaryRows = (payload) => {
  const attention = payload.attention.summary;
  const work = payload.period_work.summary;
  return [
    { Section: 'Attention', Metric: 'Pending Renewals', Value: attention.renewals_pending },
    { Section: 'Attention', Metric: 'Breached Opportunities', Value: attention.opportunities_breached },
    { Section: 'Attention', Metric: 'Clients Not Approved', Value: attention.clients_not_approved },
    { Section: 'Attention', Metric: 'Breached Activities', Value: attention.activities_breached },
    { Section: 'Attention', Metric: 'Renewal Premium Amount', Value: attention.renewal_premium_amount },
    { Section: 'Attention', Metric: 'Renewal Brokerage Amount', Value: attention.renewal_brokerage_amount },
    { Section: 'Attention', Metric: 'Opportunity Premium Amount', Value: attention.opportunity_premium_amount },
    { Section: 'Attention', Metric: 'Opportunity Brokerage Amount', Value: attention.opportunity_brokerage_amount },
    { Section: 'Actual Work', Metric: 'Total Records', Value: work.total_records },
    ...DOMAINS.flatMap((domain) =>
      Object.entries(work[domain] || {}).map(([metric, value]) => ({
        Section: `Actual Work - ${DOMAIN_LABELS[domain]}`,
        Metric: humanize(metric),
        Value: value,
      })),
    ),
  ];
};

const exportKpiWorkbook = (payload) => {
  const exportedAt = new Date();
  const workbook = XLSX.utils.book_new();
  appendSheet(workbook, 'KPI Summary', getSummaryRows(payload));
  appendSheet(workbook, 'Team Attention', payload.attention.team_summary);
  appendSheet(workbook, 'Team Actual Work', payload.period_work.team_summary);
  DOMAINS.forEach((domain) => {
    appendSheet(workbook, `Attention ${DOMAIN_LABELS[domain]}`, payload.attention[domain]);
    appendSheet(workbook, `Actual Work ${DOMAIN_LABELS[domain]}`, payload.period_work[domain]);
  });
  XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([
    ['Report Note'],
    [`Export date and time: ${exportedAt.toLocaleString('en-IN')}`],
    ['Export source: Opportunity dashboard API dashboard_name=kpi'],
    [`Period: ${payload.filters?.from_date || ''} to ${payload.filters?.to_date || ''}`],
    [`Actual Work records exported: ${payload.period_work.summary.total_records || 0}`],
    [`API as of: ${payload.as_of || ''}`],
  ]), 'Report Notes');
  XLSX.writeFile(workbook, `kpi-attention-actual-work-report-${exportedAt.toISOString().slice(0, 10)}.xlsx`, { compression: true });
};

const Badge = ({ children, tone = 'slate' }) => <span className={`kpi-badge kpi-badge--${tone}`}>{children || '--'}</span>;

const CellValue = ({ value }) => {
  if (value && typeof value === 'object' && 'badge' in value) return <Badge tone={value.tone}>{value.badge}</Badge>;
  if (value && typeof value === 'object' && 'primary' in value) {
    return (
      <>
        <span className="kpi-primary">{value.primary || '--'}</span>
        {value.secondary ? <span className="kpi-secondary">{value.secondary}</span> : null}
      </>
    );
  }
  return <>{value || '--'}</>;
};

const BarRow = ({ label, attention, work, max }) => (
  <Box className="kpi-bar-row">
    <Typography className="kpi-bar-label" title={label}>{label}</Typography>
    <Box className="kpi-bar-pair">
      <Box className="kpi-bar-line">
        <span className="kpi-bar-track"><span className="kpi-bar-fill kpi-bar-fill--attention" style={{ width: `${max ? (attention / max) * 100 : 0}%` }} /></span>
        <span className="kpi-bar-value">{num(attention)}</span>
      </Box>
      <Box className="kpi-bar-line">
        <span className="kpi-bar-track"><span className="kpi-bar-fill kpi-bar-fill--work" style={{ width: `${max ? (work / max) * 100 : 0}%` }} /></span>
        <span className="kpi-bar-value">{num(work)}</span>
      </Box>
    </Box>
  </Box>
);

const KpiDashboard = () => {
  const detailSectionRef = useRef(null);
  const [rangeCode, setRangeCode] = useState('today30');
  const [teamMode, setTeamMode] = useState('attention');
  const [scope, setScope] = useState('attention');
  const [domain, setDomain] = useState('renewals');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const dateFilters = useMemo(() => getDateRange(rangeCode), [rangeCode]);
  const kpiQuery = useOpportunityDashboardSection('kpi', dateFilters);
  const payload = useMemo(() => normalizeKpiInput(kpiQuery.data), [kpiQuery.data]);
  const team = 'all';

  const attentionSummary = useMemo(() => (
    team === 'all' ? payload.attention.summary : payload.attention.team_summary.find((row) => teamKey(row) === team) ?? payload.attention.summary
  ), [payload, team]);
  const workSummary = useMemo(() => (
    team === 'all' ? payload.period_work.summary : payload.period_work.team_summary.find((row) => teamKey(row) === team) ?? payload.period_work.summary
  ), [payload, team]);
  const moduleRows = useMemo(() => DOMAINS.map((item) => ({
    key: item,
    label: DOMAIN_LABELS[item],
    attention: attentionDomainCount(attentionSummary, item),
    work: periodDomainCount(workSummary, item),
  })).filter((row) => row.attention || row.work), [attentionSummary, workSummary]);
  const domainTiles = useMemo(() => DOMAINS.map((item) => {
    const work = workDomain(workSummary, item);
    const values = {
      clients: { attention: attentionSummary.clients_not_approved, work: work.new, note: `${num(work.approved)} approved - ${num(work.rejected)} rejected` },
      opportunities: { attention: attentionSummary.opportunities_breached, work: work.new, note: `${num(work.completed_or_won)} completed/won - ${num(work.lost)} lost` },
      renewals: { attention: attentionSummary.renewals_pending, work: work.due, note: `${num(work.opportunity)} opportunities - ${num(work.pending)} pending` },
      activities: { attention: attentionSummary.activities_breached, work: work.scheduled_total, note: `${num(work.completed)} completed - ${num(work.rescheduled)} rescheduled` },
    }[item];

    return {
      key: item,
      values,
      isVisible: Boolean(Number(values.attention || 0) || Number(values.work || 0)),
    };
  }).filter((item) => item.isVisible), [attentionSummary, workSummary]);
  const moduleMax = Math.max(0, ...moduleRows.flatMap((row) => [row.attention, row.work]));
  const teamChartRows = useMemo(() => {
    const attentionTeams = new Map(payload.attention.team_summary.filter((row) => row.bucket_type !== 'HIERARCHY_TOTAL').map((row) => [teamKey(row), row]));
    const workTeams = new Map(payload.period_work.team_summary.filter((row) => row.bucket_type !== 'HIERARCHY_TOTAL').map((row) => [teamKey(row), row]));
    const summaryRows = [...new Set([...attentionTeams.keys(), ...workTeams.keys()])].map((key) => {
      const attentionRow = attentionTeams.get(key);
      const workRow = workTeams.get(key);
      return {
        key,
        label: attentionRow?.team_user_name || workRow?.team_user_name || teamDisplayName(payload, key),
        attention: Number(attentionRow?.attention_action_count || 0),
        work: Number(workRow?.total_records || 0),
      };
    }).filter((row) => row.attention || row.work);

    if (summaryRows.length) return summaryRows;

    const ownerTotals = new Map();
    DOMAINS.forEach((item) => {
      payload.attention[item].forEach((row) => {
        const key = String(recordOwner(item, row) ?? 'unassigned');
        ownerTotals.set(key, { key, label: teamDisplayName(payload, key), attention: (ownerTotals.get(key)?.attention || 0) + 1, work: ownerTotals.get(key)?.work || 0 });
      });
      payload.period_work[item].forEach((row) => {
        const key = String(recordOwner(item, row) ?? 'unassigned');
        ownerTotals.set(key, { key, label: teamDisplayName(payload, key), attention: ownerTotals.get(key)?.attention || 0, work: (ownerTotals.get(key)?.work || 0) + 1 });
      });
    });
    return [...ownerTotals.values()].filter((row) => row.attention || row.work);
  }, [payload]);
  const teamChartMax = Math.max(0, ...teamChartRows.flatMap((row) => [row.attention, row.work]));
  const detailDomainTabs = useMemo(() => DOMAINS.map((item) => ({
    key: item,
    count: recordsFor(payload, scope, item, team).length,
  })).filter((item) => item.count > 0), [payload, scope, team]);

  const detailRows = useMemo(() => {
    const rows = sortRows(domain, recordsFor(payload, scope, domain, team));
    const query = search.trim().toLowerCase();
    return query ? rows.filter((row) => searchable(row).includes(query)) : rows;
  }, [payload, scope, domain, team, search]);
  const totalPages = Math.max(1, Math.ceil(detailRows.length / pageSize));
  const boundedPage = Math.min(page, totalPages);
  const pageRows = detailRows.slice((boundedPage - 1) * pageSize, boundedPage * pageSize);
  const detail = pageRows[0] ? detailShape(scope, domain, pageRows[0]) : null;
  const teamRows = payload[teamMode].team_summary;

  const handleRefresh = async () => {
    await kpiQuery.refetch();
  };

  const handleExport = () => {
    try {
      exportKpiWorkbook(payload);
      toast.success('KPI Excel report downloaded');
    } catch (error) {
      console.error('KPI Excel export failed:', error);
      toast.error('KPI Excel report could not be generated');
    }
  };

  const selectDomain = useCallback((nextDomain, shouldFocusDetails = false) => {
    const nextScope = payload.attention[nextDomain].length ? 'attention' : 'period_work';
    setDomain(nextDomain);
    setScope(nextScope);
    setSearch('');
    setPage(1);

    if (shouldFocusDetails) {
      window.setTimeout(() => {
        detailSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        detailSectionRef.current?.focus({ preventScroll: true });
      }, 0);
    }
  }, [payload]);

  useEffect(() => {
    if (!domainTiles.length || domainTiles.some((item) => item.key === domain)) return;
    selectDomain(domainTiles[0].key);
  }, [domain, domainTiles, selectDomain]);

  useEffect(() => {
    if (!detailDomainTabs.length || detailDomainTabs.some((item) => item.key === domain)) return;
    setDomain(detailDomainTabs[0].key);
    setPage(1);
  }, [detailDomainTabs, domain]);

  return (
    <Box className="kpi-dashboard-page">
      <Box className="kpi-dashboard-header">
        <Box>
          <Typography className="kpi-dashboard-title">KPI Dashboard</Typography>
          <Typography className="kpi-dashboard-subtitle">
            Attention required compared with work recorded from {showDate(payload.filters?.from_date || dateFilters.fromDate)} to {showDate(payload.filters?.to_date || dateFilters.toDate)}.
          </Typography>
        </Box>
        <Box className="kpi-dashboard-actions">
          <FormControl className="kpi-range-control kpi-action-pill" size="small">
            <Select
              value={rangeCode}
              renderValue={() => `${showDate(payload.filters?.from_date || dateFilters.fromDate)} - ${showDate(payload.filters?.to_date || dateFilters.toDate)}`}
              onChange={(event) => { setRangeCode(event.target.value); setPage(1); }}
            >
              {RANGE_OPTIONS.map((option) => <MenuItem key={option.code} value={option.code}>{option.label}</MenuItem>)}
            </Select>
          </FormControl>
          <Tooltip
            title="Refresh dashboard"
            slotProps={{ tooltip: { className: 'kpi-light-tooltip' } }}
          >
            <span>
              <IconButton className="kpi-icon-btn" onClick={handleRefresh} disabled={kpiQuery.isFetching} aria-label="Refresh KPI dashboard">
                <RefreshRoundedIcon fontSize="small" />
              </IconButton>
            </span>
          </Tooltip>
          <Button className="kpi-download-btn" startIcon={<DownloadOutlinedIcon />} onClick={handleExport} disabled={!kpiQuery.data}>Download</Button>
        </Box>
      </Box>

      <Box className="kpi-section-row">
        <Typography className="kpi-section-label">Attention vs Actual Work</Typography>
        <Typography className="kpi-section-hint">Choose a category to view its records</Typography>
      </Box>

      <Box className="kpi-comparison-grid">
        {domainTiles.map(({ key: item, values }) => {
          const Icon = DOMAIN_ICONS[item];
          return (
            <Button key={item} className={`kpi-domain-card kpi-domain-card--${item} ${domain === item ? 'kpi-domain-card--active' : ''}`} onClick={() => selectDomain(item, true)}>
              <span className="kpi-domain-head">
                <span className="kpi-domain-icon"><Icon fontSize="inherit" /></span>
                <span className="kpi-domain-name">{DOMAIN_LABELS[item]}</span>
              </span>
              <span className="kpi-domain-values">
                <span><small>Needs Attention</small><strong>{num(values.attention)}</strong></span>
                <span><small>Actual Work</small><strong>{num(values.work)}</strong></span>
              </span>
              <span className="kpi-domain-note">{values.note}</span>
            </Button>
          );
        })}
      </Box>

      <Box className="kpi-financial-grid">
        <Box className="kpi-panel kpi-financial-card kpi-financial-card--renewals">
          <Box className="kpi-financial-title">
            <span className="kpi-financial-icon"><CurrencyRupeeRoundedIcon fontSize="inherit" /></span>
            <span><strong>Renewal Financials</strong><small>Premium and brokerage</small></span>
          </Box>
          <Box className="kpi-financial-scope">
            <small>Attention Exposure</small>
            <strong>{shortMoney(attentionSummary.renewal_premium_amount)}</strong>
            <span>Brokerage {shortMoney(attentionSummary.renewal_brokerage_amount)}</span>
          </Box>
          <Box className="kpi-financial-scope">
            <small>Actual Work</small>
            <strong>{shortMoney(workDomain(workSummary, 'renewals').premium_amount)}</strong>
            <span>Brokerage {shortMoney(workDomain(workSummary, 'renewals').brokerage_amount)}</span>
          </Box>
        </Box>
        <Box className="kpi-panel kpi-financial-card kpi-financial-card--opportunities">
          <Box className="kpi-financial-title">
            <span className="kpi-financial-icon"><CurrencyRupeeRoundedIcon fontSize="inherit" /></span>
            <span><strong>Opportunity Financials</strong><small>Expected premium and brokerage</small></span>
          </Box>
          <Box className="kpi-financial-scope">
            <small>Attention Exposure</small>
            <strong>{shortMoney(attentionSummary.opportunity_premium_amount)}</strong>
            <span>Brokerage {shortMoney(attentionSummary.opportunity_brokerage_amount)}</span>
          </Box>
          <Box className="kpi-financial-scope">
            <small>Actual Work</small>
            <strong>{shortMoney(workDomain(workSummary, 'opportunities').premium_amount)}</strong>
            <span>Brokerage {shortMoney(workDomain(workSummary, 'opportunities').brokerage_amount)}</span>
          </Box>
        </Box>
      </Box>

      <Box className="kpi-graphs-grid">
        <Box className="kpi-panel">
          <Box className="kpi-panel-head">
            <Box>
              <Typography className="kpi-panel-title">Attention vs Actual Work</Typography>
              <Typography className="kpi-panel-subtitle">Work requiring action compared with records handled</Typography>
            </Box>
            <Box className="kpi-legend"><span><i className="kpi-dot kpi-dot--attention" />Attention</span><span><i className="kpi-dot kpi-dot--work" />Actual Work</span></Box>
          </Box>
          <Box className="kpi-bar-chart">
            {moduleRows.length ? moduleRows.map((row) => <BarRow key={row.key} label={row.label} attention={row.attention} work={row.work} max={moduleMax} />) : <Box className="kpi-empty">No KPI activity available.</Box>}
          </Box>
        </Box>
        <Box className="kpi-panel">
          <Box className="kpi-panel-head">
            <Box>
              <Typography className="kpi-panel-title">Team Workload</Typography>
              <Typography className="kpi-panel-subtitle">Attention actions compared with total actual work</Typography>
            </Box>
            <Box className="kpi-legend"><span><i className="kpi-dot kpi-dot--attention" />Attention</span><span><i className="kpi-dot kpi-dot--work" />Actual Work</span></Box>
          </Box>
          <Box className="kpi-bar-chart">
            {teamChartRows.length ? teamChartRows.map((row) => <BarRow key={row.key} label={row.label} attention={row.attention} work={row.work} max={teamChartMax} />) : <Box className="kpi-empty">No team workload available.</Box>}
          </Box>
        </Box>
      </Box>

      <Box className="kpi-panel">
        <Box className="kpi-panel-head">
          <Box>
            <Typography className="kpi-panel-title">{teamMode === 'attention' ? 'Team Attention Summary' : 'Team Actual Work Summary'}</Typography>
            <Typography className="kpi-panel-subtitle">{num(teamRows.length)} teams / buckets</Typography>
          </Box>
          <Box className="kpi-segment">
            <Button className={teamMode === 'attention' ? 'active' : ''} onClick={() => setTeamMode('attention')}>Attention</Button>
            <Button className={teamMode === 'period_work' ? 'active' : ''} onClick={() => setTeamMode('period_work')}>Actual Work</Button>
          </Box>
        </Box>
        <TableContainer className="kpi-table-wrap">
          <Table className="kpi-table">
            <TableHead><TableRow><TableCell>Team / Bucket</TableCell><TableCell align="right">{teamMode === 'attention' ? 'Actions' : 'Total Work'}</TableCell><TableCell align="right">Clients</TableCell><TableCell align="right">Opportunities</TableCell><TableCell align="right">Renewals</TableCell><TableCell align="right">Activities</TableCell><TableCell align="right">Financial Value</TableCell></TableRow></TableHead>
            <TableBody>
              {teamRows.length ? teamRows.map((row, index) => {
                const renewals = row.renewals || {};
                const opportunities = row.opportunities || {};
                const premium = Number(renewals.premium_amount || row.renewal_premium_amount || 0) + Number(opportunities.premium_amount || row.opportunity_premium_amount || 0);
                return (
                  <TableRow key={`${row.team_user_id || row.bucket_type}-${index}`} className={row.bucket_type === 'HIERARCHY_TOTAL' ? 'kpi-total-row' : ''}>
                    <TableCell><CellValue value={{ primary: row.team_user_name, secondary: String(row.bucket_type || '').replaceAll('_', ' ') }} /></TableCell>
                    <TableCell align="right">{num(row.attention_action_count ?? row.total_records)}</TableCell>
                    <TableCell align="right">{num(row.clients_not_approved ?? row.clients?.new)}</TableCell>
                    <TableCell align="right">{num(row.opportunities_breached ?? row.opportunities?.new)}</TableCell>
                    <TableCell align="right">{num(row.renewals_pending ?? row.renewals?.due)}</TableCell>
                    <TableCell align="right">{num(row.activities_breached ?? row.activities?.scheduled_total)}</TableCell>
                    <TableCell align="right">{shortMoney(premium)}</TableCell>
                  </TableRow>
                );
              }) : <TableRow><TableCell colSpan={7} className="kpi-empty">No team summary available.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      <Box className="kpi-panel" ref={detailSectionRef} tabIndex={-1}>
        <Box className="kpi-detail-toolbar">
          <Box className="kpi-segment">
            <Button className={scope === 'attention' ? 'active' : ''} onClick={() => { setScope('attention'); setPage(1); }}>Attention</Button>
            <Button className={scope === 'period_work' ? 'active' : ''} onClick={() => { setScope('period_work'); setPage(1); }}>Actual Work</Button>
          </Box>
          <Box className="kpi-domain-tabs">
            {detailDomainTabs.map(({ key: item, count }) => <Button key={item} className={domain === item ? 'active' : ''} onClick={() => { setDomain(item); setPage(1); }}>{DOMAIN_LABELS[item]} <span>{num(count)}</span></Button>)}
          </Box>
          <TextField className="kpi-search" size="small" placeholder="Search records" value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} />
          <FormControl className="kpi-page-size" size="small">
            <Select value={pageSize} onChange={(event) => { setPageSize(Number(event.target.value)); setPage(1); }}>{[10, 25, 50].map((value) => <MenuItem key={value} value={value}>{value}</MenuItem>)}</Select>
          </FormControl>
        </Box>
        <TableContainer className="kpi-detail-table-wrap">
          <Table className="kpi-table">
            <TableHead><TableRow>{(detail?.heads ?? [DOMAIN_LABELS[domain]]).map((head) => <TableCell key={head}>{head}</TableCell>)}</TableRow></TableHead>
            <TableBody>
              {pageRows.length ? pageRows.map((row, index) => {
                const shape = detailShape(scope, domain, row);
                return <TableRow key={`${domain}-${index}`}>{shape.cells.map((cell, cellIndex) => <TableCell key={shape.heads[cellIndex]}><CellValue value={cell} /></TableCell>)}</TableRow>;
              }) : <TableRow><TableCell colSpan={detail?.heads.length || 1} className="kpi-empty">No matching records found.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </TableContainer>
        <Box className="kpi-footer">
          <Typography className="kpi-footer-text">{detailRows.length ? `Showing ${num((boundedPage - 1) * pageSize + 1)} to ${num(Math.min(boundedPage * pageSize, detailRows.length))} of ${num(detailRows.length)} records` : 'Showing 0 records'}</Typography>
          <Box className="kpi-pagination">
            <Button className="kpi-page-btn" disabled={boundedPage <= 1} onClick={() => setPage((value) => Math.max(1, value - 1))} aria-label="Previous page"><ChevronLeftIcon fontSize="small" /></Button>
            <Typography className="kpi-footer-text">Page {boundedPage} of {totalPages}</Typography>
            <Button className="kpi-page-btn" disabled={boundedPage >= totalPages} onClick={() => setPage((value) => value + 1)} aria-label="Next page"><ChevronRightIcon fontSize="small" /></Button>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default KpiDashboard;
