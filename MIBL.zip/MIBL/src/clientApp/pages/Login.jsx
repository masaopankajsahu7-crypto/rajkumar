import { useEffect, useState, useRef } from 'react';
import logo from '../assets/images/M-BizDesk-logo.png';
import policyImg from '../assets/images/M-BizDesk-banner.jpg';
import { Box, Grid, Paper, Stack, Typography, TextField, Button, IconButton, FormHelperText, Dialog, DialogContent } from '@mui/material';
import { VisibilityOffOutlined, VisibilityOutlined } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { login, changePasswordUser, resetPasswordUser, otpVerification, sendOTP } from '../services/api';
import { useDispatch, useSelector } from 'react-redux'
import { setCredFlag, setFetchUserByManager, setInputUser, setIsCaller, setLogin } from "../redux/slices/userSlice"
import { encryptRoute } from '../services/encrypt';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import BackdropLoader from "../components/Loader/BackdropLoader";
import useMediaQuery from '@mui/material/useMediaQuery';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';

import { APP_CONFIG } from '../config/appConfig.js';
import { AUTH_MESSAGES as MSG } from '../config/messages/auth.js';
import { encodedRoutePath, ROUTES } from '../config/routes.js';
import {
  truncateAuthField,
  validateLoginEmail,
  validateLoginPassword,
  validateLoginSap,
  validatePasswordMatch,
} from '../utils/authFormValidation.js';

const Login = () => {
  const isMobile = useMediaQuery('(min-width:600px)');
  const isMobileView = useMediaQuery('(min-width:320px) and (max-width:625px)');
  const isTabView = useMediaQuery('(min-width:626px) and (max-width:900px)');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({ email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [resetPassword, setResetPassword] = useState(false);
  const [changePassword, setChangePassword] = useState(false);
  const [otpShow, setOtpShow] = useState(false);
  const [rePassword, setRePassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const [forgotScreen, setForgotScreen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [openBox, setopenBox] = useState(false);
  const [loginType, setLoginType] = useState("Dealer");
  const [token, setToken] = useState("");

  const navigate = useNavigate();

  const user = useSelector((state) => state.user.loggedData);
  const isLoggedIn = useSelector((state) => state.user.loggedIn);
  // const token = useSelector((state) => state.user.token);
  const dispatch = useDispatch();

  const prevEmail = useRef('');
  const prevPassword = useRef('');

  const [timeLeft, setTimeLeft] = useState(APP_CONFIG.OTP_RESEND_TIMER_SECONDS);
  const [isResendEnabled, setIsResendEnabled] = useState(false);

  useEffect(() => {
    dispatch({ type: 'RESET_ALL_STATE' });
  }, []);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft((prev) => prev - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setIsResendEnabled(true);
    }
  }, [timeLeft]);

  // useEffect(() => {
  //   if (timeLeft <= 0) {
  //     setIsResendEnabled(true);
  //     return;
  //   }

  //   const timer = setInterval(() => {
  //     setTimeLeft((prev) => prev - 1);
  //   }, 1000);

  //   return () => clearInterval(timer);
  // }, [timeLeft]);

  // const handleResend = () => {
  //   setTimeLeft(120); // reset timer
  //   setIsResendEnabled(false);
  //   handleSendOtp(); // your API call
  // };

  const formatTime = (seconds) => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };

  const handlePasswordChange = (e) => {
    const value = truncateAuthField('password', e.target.value);
    setPassword(value);

    const error = validateLoginPassword(value);
    setErrors((prev) => ({ ...prev, password: error }));

    if (rePassword && value !== rePassword) {
      setErrors((prev) => ({ ...prev, rePassword: MSG.errors.passwordMismatch }));
    } else {
      setErrors((prev) => ({ ...prev, rePassword: '' }));
    }
  };

  const handleRePasswordChange = (e) => {
    const value = truncateAuthField('password', e.target.value);
    setRePassword(value);

    setErrors((prev) => ({
      ...prev,
      rePassword: validatePasswordMatch(password, value),
    }));
  };

  const validateEmail = () => validateLoginEmail(email);

  const validateSAPCode = (sapCode = '') => validateLoginSap(sapCode || email);

  const validatePassword = () => validateLoginPassword(password);

  const validate = () => {
    let tempErrors;
    if (loginType === "Dealer") {
      tempErrors = {
        email: validateEmail(),
        password: validatePassword()
      };
    }
    if (loginType === "MIBL") {
      tempErrors = {
        email: validateSAPCode(email),
        password: validatePassword()
      };
    }
    setErrors(tempErrors);
    return Object.values(tempErrors).every(x => x === '');
  };

  useEffect(() => {
    if (Object.values(errors).join('')) {
      const emailChanged = email != prevEmail.current;
      const passwordChanged = password != prevPassword.current;

      if (emailChanged && passwordChanged) {
        validate();
      } else if (emailChanged) {
        setErrors({ email: validateEmail(), password: errors.password });
      } else if (passwordChanged) {
        setErrors({ email: errors.email, password: validatePassword() });
      }
      prevEmail.current = email;
      prevPassword.current = password;
    }
  }, [email, password]);

  const handleLogin = async (event, forceLogin = false) => {
    if (APP_CONFIG.DEV_BYPASS_LOGIN) {
      navigate(encodedRoutePath(ROUTES.dashboard));
      return;
    }

    if (!validate()) return;

    try {
      setLoading(true);
      const response = await login(
        {
          // checkLoginType: loginType,
          checkLoginType: "Dealer",
          email,
          password,
          forceLogin,
        });
      if (response.status == "401") {
        toast.error(response.msg || MSG.toast.invalidCredentials);
        return;
      }
      // response.msg == "User already logged in. Do you want to logout previous session?"
      if (response.status == 409 && !forceLogin) {
        setopenBox(true);
        return;
      }

      if (response.status == "200") {
        if (response.userDetail?.lastLoginDate === null) {
          setPassword('');
          setErrors({});
          setChangePassword(true);
        }
        else if (response.userDetail.otp === "Yes") {
          setTimeLeft(120);
          dispatch({ type: 'RESET_ALL_STATE' });
          setToken(response.token);
          // dispatch(setLogin({
          //   user: response.userDetail,
          //   token: response.token,
          //   loggedIn: true,
          //   featureAccess: response.FeatureAccess
          // }));
          // dispatch(setInputUser(email));
          setErrors({});
          setOtpShow(true);
        }
        else {
          const lastLoginDateStr = response.userDetail?.lastLoginDate;

          if (lastLoginDateStr !== null) {
            const lastLoginDate = new Date(lastLoginDateStr);
            const currentDate = new Date();

            const diffInTime = currentDate.getTime() - lastLoginDate.getTime();
            const diffInDays = diffInTime / (1000 * 3600 * 24);

            if (diffInDays > 15) {
              setPassword('');
              setErrors({});
              setResetPassword(true);
            } else {
              dispatch({ type: 'RESET_ALL_STATE' });
              dispatch(setInputUser(email));
              dispatch(setLogin({
                user: response.userDetail,
                token: response.token,
                loggedIn: true,
                featureAccess: response.FeatureAccess
              }));
              dispatch(setFetchUserByManager(response.fetchUserByManager));
              dispatch(setIsCaller(response.userDetail.callingFlag === 'Y' ? 'caller' : 'noncaller'));
              sessionStorage.removeItem("dashboard_last_fetch_time");
              if (response.userDetail.roleType === "MIBL") {
                navigate(`/${encodeURIComponent(encryptRoute('/admindashboard'))}`);
              }
              else if (response.userDetail.roleType === "DEALER") {
                navigate(`/${encodeURIComponent(encryptRoute('/managerdashboard'))}`);
              }
            }
          }
        }
      }
      else {
        toast.error(response.msg || MSG.toast.invalidCredentials);
      }
    } catch (err) {
      console.log(err);
      toast.error(MSG.toast.loginError, err);
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async () => {
    const passwordError = validateLoginPassword(password);
    const rePasswordError = validatePasswordMatch(password, rePassword);

    setErrors({ password: passwordError, rePassword: rePasswordError });

    if (passwordError || rePasswordError) return;

    try {
      setLoading(true);
      if (changePassword) {
        const res = await changePasswordUser({ email: email, password: password, confirmPassword: rePassword });
        if (res.status_code === "200") {
          toast.success(MSG.toast.passwordUpdated);
          setChangePassword(false);
          setEmail('');
          setPassword('');
          setErrors({});
        } else if (res.status_code !== "200") toast.error(res.status_message);
      } else if (resetPassword) {
        const res = await resetPasswordUser({ email: email, password: password, confirmPassword: rePassword });
        if (res.status_code === "200") {
          toast.success(MSG.toast.passwordUpdated);
          setResetPassword(false);
          setEmail('');
          setPassword('');
          setErrors({});
        } else if (res.status_code !== "200") toast.error(res.status_message);
      }
    } catch (error) {
      toast.error('An error occurred during login. Please try again.', error);
    } finally {
      setLoading(false);
    }
  };

  const [otp, setOtp] = useState(new Array(6).fill(""));

  // --- OTP handlers ---
  const handleOtpChange = (value, index) => {
    if (/^[0-9]?$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // auto-focus next
      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-input-${index + 1}`);
        if (nextInput) nextInput.focus();
      }
    }
  };

  const handleResend = () => {
    setIsResendEnabled(false);
    handleResendCode();
  };

  const handleOtpKeyDown = (e, index) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-input-${index - 1}`);
      if (prevInput) prevInput.focus();
    }

    if (e.key === "Enter") {
      const otpValue = otp.join("");
      if (otpValue.length === 6) {
        handleVerifyOtp();
      }
    }
  };

  const handleVerifyOtp = async () => {

    // if (timeLeft <= 0) {
    //   toast.info("OTP expired. Please request a new one.");
    //   return;
    // }

    const otpValue = otp.join("");
    const payload = { email: email, password: password, otp: otpValue, token: token }
    if (otpValue.length !== 6) {
      toast.error(MSG.toast.otpRequired);
      return;
    }
    try {
      setLoading(true);
      const response = await otpVerification(payload);
      if (response.status === "200") {
        dispatch({ type: 'RESET_ALL_STATE' });
        dispatch(setLogin({
          user: response.userDetail,
          token: response.token,
          loggedIn: true,
          featureAccess: response.FeatureAccess
        }));
        dispatch(setInputUser(email));
        dispatch(setFetchUserByManager(response.fetchUserByManager));
        dispatch(setIsCaller(response.userDetail.callingFlag === 'Y' ? 'caller' : 'noncaller'));
        if (response.userDetail.roleType === "MIBL") {
          navigate(`/${encodeURIComponent(encryptRoute('/admindashboard'))}`);
        }
        else if (response.userDetail.roleType === "DEALER") {
          navigate(`/${encodeURIComponent(encryptRoute('/managerdashboard'))}`);
        }
      } else {
        toast.error(response.msg || MSG.toast.otpExpired);
      }
    } catch (error) {
      console.log("error", error)
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    try {
      setOtp(Array(6).fill(""));
      setLoading(true);
      const data = await sendOTP(email, token);
      if (data.data.success === "OTP Sent Sucessful") {
        setTimeout(() => {
          toast.success(MSG.toast.otpSent);
          setTimeLeft(APP_CONFIG.OTP_RESEND_TIMER_SECONDS);
        }, 1000);
      }
    } catch (error) {
      toast.error(`${MSG.toast.otpSendError} ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleChange = (event, newValue) => {
    if (!newValue) return;

    setLoginType(newValue);

    if (newValue === "Dealer") {
      // fetchDealerData();
    } else if (newValue === "MIBL") {
      // fetchMiblData();
    }
  };

  const handleToggleShowPass = () => {
    setShowPass((prev) => !prev);
  };

  const handleNavigateForgot = () => {
    navigate(ROUTES.forgot);
  };

  const handleOtpBack = () => {
    setOtpShow(false);
    setOtp(new Array(6).fill(''));
  };

  const handleToggleShowPassword = () => {
    setShowPassword((prev) => !prev);
  };

  const handleToggleShowRePassword = () => {
    setShowRePassword((prev) => !prev);
  };

  const handleCloseOpenBox = () => {
    setopenBox(false);
  };

  const handleForceLoginConfirm = (event) => {
    dispatch(setCredFlag(true));
    setopenBox(false);
    handleLogin(event, true);
  };


  return (
    <>
      <BackdropLoader loading={loading} />

      <Paper elevation={0} >
        <Grid container >
          {/* Screen left */}
          <Grid size={{ xs: 12, sm: 12, md: 4 }}>
            <Box
              //  elevation={0} 
              className={`login-side-panel ${isMobileView || isTabView ? 'login-side-panel--centered' : ''}`}>
              <Box className="login-policy-wrap">
                <img src={policyImg} className={`center-image login-policy-img ${isTabView ? 'login-policy-img--tab' : ''}`} alt="Commercial Lines Insurance" />
              </Box>
            </Box>
          </Grid>

          {/* Screen right */}
          {!(resetPassword || changePassword || otpShow) &&
            <Grid size={{ xs: 12, sm: 12, md: 7 }} className="login-form-grid">
              <Box className="login-brand-desktop-shell">
                <img src={logo} className="login-brand-floating-img" alt="M-BizDesk logo" />
              </Box>
              <Stack className={`login-form-stack ${isMobileView ? '' : 'login-form-stack--offset'}`}>
                <Box className="login-header-block">
                  <Typography className='georama-SemiBold fs-32 login-welcome-title'>Welcome</Typography>

                  <Typography className='nav-text text-gray login-subtitle'>Please Log in to your account</Typography>
                </Box>

                {loginType === "Dealer" &&
                  <Box className="login-field-group">
                    <Typography className="text-labels field-label">
                      Username <span className="important-fields">*</span>
                    </Typography>

                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter Username"
                      value={email}
                      onChange={(e) => setEmail(truncateAuthField('emailOrMobile', e.target.value.trim()))}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                    // InputProps={{
                    //   disableUnderline: true,
                    //   sx: { fontWeight: 'bold' },
                    // }}
                    />

                    {errors.email && (
                      <FormHelperText className="important-fields">{errors.email}</FormHelperText>
                    )}
                  </Box>}


                {loginType === "MIBL" &&
                  <Box className="login-field-group">
                    <Typography className="text-labels field-label">
                      SAP Code <span className="important-fields">*</span>
                    </Typography>

                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter SAP Code"
                      value={email}
                      onChange={(e) => setEmail(truncateAuthField('sapLogin', e.target.value.trim()))}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                    />

                    {errors.email && (
                      <FormHelperText className="important-fields">{errors.email}</FormHelperText>
                    )}
                  </Box>}

                <Box className="login-password-field">
                  <Typography className="text-labels field-label">
                    Password <span className="important-fields">*</span>
                  </Typography>

                  <Box className="field-inline">
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter Password"
                      type={showPass ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(truncateAuthField('password', e.target.value))}
                      onKeyDown={(e) => e.key === 'Enter' && !resetPassword && !changePassword && !otpShow && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={handleToggleShowPass} edge="end">
                            {showPass ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  {errors.password && (
                    <FormHelperText className="important-fields">{errors.password}</FormHelperText>
                  )}

                </Box>

                <Box className="login-submit-wrap">
                  <Button className="btn-common-red border-radius-32 login-submit-button"
                    onClick={handleLogin} disabled={loading}>
                    Log In
                  </Button>
                </Box>
              </Stack>
            </Grid>}

          {/* -----------------  OTP Flag Yes then show this  -----------------  */}
          {otpShow &&
            <Grid size={{ xs: 12, sm: 12, md: 6.8 }}>
              <Button className={`text-capitalize georama-medium-selected custom-starticon login-back-button ${isMobile ? 'login-back-button--wide' : 'login-back-button--compact'}`}
                startIcon={<ChevronLeftIcon />}
                onClick={handleOtpBack}>
                Back
              </Button>
              <Grid size={{ xs: 12, sm: 12, md: 12 }} className="auth-content-grid">
                <Stack className={`auth-form-stack auth-form-stack--wide ${isMobile ? 'auth-form-stack--vertical-gap' : ''}`}>
                  <Box>
                    <Typography className={`georama-SemiBold ${isMobile ? 'fs-32' : 'fs-24'} center-text otp-title`} >Check your email</Typography>
                    <Typography className={`georama-Regular ${isMobile ? 'fs-16' : 'fs-12'} center-text login-otp-copy ${isMobile ? 'login-otp-copy--spaced' : ''}`} >
                      Enter the verification code sent your
                    </Typography>
                    <Typography className={`georama-SemiBold ${isMobile ? 'fs-16' : 'fs-12'} center-text login-otp-email ${isMobile ? 'login-otp-email--spaced' : ''}`} >
                      {email}
                    </Typography>
                  </Box>

                  <Box>
                    <Box className="otp-input-row">
                      {otp.map((digit, i) => (
                        <TextField
                          className="form-control-input border-radius-8"
                          key={i}
                          id={`otp-input-${i}`}
                          value={digit}
                          onChange={(e) => handleOtpChange(e.target.value, i)}
                          onKeyDown={(e) => handleOtpKeyDown(e, i)}
                          inputProps={{
                            maxLength: 1,
                            inputMode: "numeric",
                            className: "otp-digit-input",
                          }}
                        />
                      ))}
                    </Box>
                    {/* Resend Section */}
                    <Box className="auth-timer-row">
                      <Typography className='highlight-red fs-10 otp-validity-text'>
                        OTP is valid for 10 minutes
                      </Typography>
                      {isResendEnabled ? (
                        <Typography variant="body2" className="georama-Regular fs-12 otp-resend-copy">
                          Didn’t get a code?{" "}
                          <Typography
                            component="span"
                            className="georama-Medium fs-12 resend-inline-action"
                            onClick={handleResend}
                          >
                            Resend
                          </Typography>
                        </Typography>
                        // <Button className='highlight-red fs-12' onClick={handleResend}>
                        //   Didn’t get a code?{" "} Resend OTP
                        // </Button>
                      ) : (
                        <Typography className='highlight-red fs-12'>
                          Resend in {formatTime(timeLeft)}
                        </Typography>
                      )}
                    </Box>
                    {/* <Box mt={2} textAlign="center">
                        <Typography variant="body2" className="georama-Regular fs-12">
                          Didn’t get a code?{" "}
                          <Typography
                            component="span"
                            className="georama-Medium fs-12"
                            onClick={handleResendCode}
                          >
                            Resend
                          </Typography>
                        </Typography>
                      </Box> */}
                  </Box>

                  <Button
                    className='btn-common-red'
                    onClick={handleVerifyOtp}
                    disabled={otp.join("").length !== 6}
                  >
                    Verify Email
                  </Button>
                </Stack>
              </Grid>
            </Grid>}
          {/* -----------------  OTP Flag Yes then show this  ----------------- */}


          {/* ------------------ Change Password Screen --------- */}
          {(resetPassword || changePassword) &&
            <Grid size={{ xs: 12, sm: 12, md: 6.8 }} className="auth-content-grid">
              <Stack className="auth-form-stack auth-form-stack--wide auth-form-stack--change-password">
                <Box>
                  <Typography className='georama-SemiBold fs-32 center-text change-password-title' >Change Password</Typography>
                </Box>

                <Box className="login-field-group">
                  <Typography className='text-labels field-label'>
                    New Password <span className="important-fields">*</span>
                  </Typography>

                  <Box className="field-inline">
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter New Password"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={handlePasswordChange}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={handleToggleShowPassword} edge="end">
                            {showPassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  <FormHelperText className="important-fields">{errors.password}</FormHelperText>
                </Box>

                <Box className="login-field-group">
                  <Typography className='text-labels field-label'>
                    Re-Enter New Password <span className="important-fields">*</span>
                  </Typography>

                  <Box className="field-inline">
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Re-Enter New Password"
                      type={showRePassword ? 'text' : 'password'}
                      value={rePassword}
                      onChange={handleRePasswordChange}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={handleToggleShowRePassword} edge="end">
                            {showRePassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  <FormHelperText className="important-fields">{errors.rePassword}</FormHelperText>
                </Box>

                <Button className="btn-common-red border-radius-32" onClick={handleChangePassword}>
                  Reset password
                </Button>
              </Stack>
            </Grid>}
        </Grid>
      </Paper>

      <Dialog className="login-confirm-dialog" open={openBox} onClose={handleCloseOpenBox}>
        <DialogContent className="login-confirm-dialog-content">
          <>
            <Typography className="login-confirm-dialog-message">
              An account with this email is already logged in. Do you want to continue and log in anyway?
            </Typography>
            <Box className="dialog-actions-row">
              <Button
                variant="contained"
                color="success"
                startIcon={<CheckCircleIcon />}
                onClick={handleForceLoginConfirm}
              >
                Yes
              </Button>
              <Button
                variant="outlined"
                color="error"
                startIcon={<CancelIcon />}
                onClick={handleCloseOpenBox}
              >
                No
              </Button>
            </Box>
          </>
        </DialogContent>
      </Dialog>
      <ToastContainer autoClose={1000} />
    </>
  )
};

export default Login;
