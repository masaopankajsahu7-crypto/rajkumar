import { useEffect, useState, useRef } from 'react';
import logo from '../assets/images/M-BizDesk-logo.png';
import policyImg from '../assets/images/M-BizDesk-banner.jpg';
import { Box, Grid, Paper, Stack, Typography, TextField, Button, IconButton, FormHelperText, Dialog, DialogContent } from '@mui/material';
import { VisibilityOffOutlined, VisibilityOutlined } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { generateClientLoginOtp, login, changePasswordUser, resetPasswordUser, verifyClientLoginOtp } from '../services/api';
import { useDispatch, useSelector } from 'react-redux'
import { setCredFlag, setFetchUserByManager, setInputUser, setIsCaller, setLogin } from "../redux/slices/userSlice"
import { encryptRoute } from '../services/encrypt';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import BackdropLoader from "../components/Loader/BackdropLoader";
import useMediaQuery from '@mui/material/useMediaQuery';
import ClientOtpDialog from '../components/auth/ClientOtpDialog.jsx';
import { logout } from '../../services/api';
import { clearSessionState } from '../../utils/sessionManager.js';

import { APP_CONFIG } from '../config/appConfig.js';
import { AUTH_MESSAGES as MSG } from '../config/messages/auth.js';
import { encodedRoutePath, ROUTES } from '../config/routes.js';
import {
  truncateAuthField,
  validateLoginEmail,
  validateLoginPassword,
  validateLoginSap,
  validatePasswordMatch,
} from '../utils/authFormValidation.js';

const Login = () => {
  const MAX_OTP_ATTEMPTS = 3;
  const isMobile = useMediaQuery('(min-width:600px)');
  const isMobileView = useMediaQuery('(min-width:320px) and (max-width:625px)');
  const isTabView = useMediaQuery('(min-width:626px) and (max-width:900px)');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({ email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [resetPassword, setResetPassword] = useState(false);
  const [changePassword, setChangePassword] = useState(false);
  const [otpShow, setOtpShow] = useState(false);
  const [rePassword, setRePassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const [forgotScreen, setForgotScreen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [openBox, setopenBox] = useState(false);
  const [loginType, setLoginType] = useState("Dealer");
  const [pendingLoginResponse, setPendingLoginResponse] = useState(null);
  const [otpAttempts, setOtpAttempts] = useState(0);
  const [otpError, setOtpError] = useState('');

  const navigate = useNavigate();

  const user = useSelector((state) => state.user.loggedData);
  const isLoggedIn = useSelector((state) => state.user.loggedIn);
  // const token = useSelector((state) => state.user.token);
  const dispatch = useDispatch();

  const prevEmail = useRef('');
  const prevPassword = useRef('');

  useEffect(() => {
    dispatch({ type: 'RESET_ALL_STATE' });
  }, []);

  const handlePasswordChange = (e) => {
    const value = truncateAuthField('password', e.target.value);
    setPassword(value);

    const error = validateLoginPassword(value);
    setErrors((prev) => ({ ...prev, password: error }));

    if (rePassword && value !== rePassword) {
      setErrors((prev) => ({ ...prev, rePassword: MSG.errors.passwordMismatch }));
    } else {
      setErrors((prev) => ({ ...prev, rePassword: '' }));
    }
  };

  const handleRePasswordChange = (e) => {
    const value = truncateAuthField('password', e.target.value);
    setRePassword(value);

    setErrors((prev) => ({
      ...prev,
      rePassword: validatePasswordMatch(password, value),
    }));
  };

  const validateEmail = () => validateLoginEmail(email);

  const validateSAPCode = (sapCode = '') => validateLoginSap(sapCode || email);

  const validatePassword = () => validateLoginPassword(password);

  const validate = () => {
    let tempErrors;
    if (loginType === "Dealer") {
      tempErrors = {
        email: validateEmail(),
        password: validatePassword()
      };
    }
    if (loginType === "MIBL") {
      tempErrors = {
        email: validateSAPCode(email),
        password: validatePassword()
      };
    }
    setErrors(tempErrors);
    return Object.values(tempErrors).every(x => x === '');
  };

  useEffect(() => {
    if (Object.values(errors).join('')) {
      const emailChanged = email != prevEmail.current;
      const passwordChanged = password != prevPassword.current;

      if (emailChanged && passwordChanged) {
        validate();
      } else if (emailChanged) {
        setErrors({ email: validateEmail(), password: errors.password });
      } else if (passwordChanged) {
        setErrors({ email: errors.email, password: validatePassword() });
      }
      prevEmail.current = email;
      prevPassword.current = password;
    }
  }, [email, password]);

  const isOtpEnabled = (userDetail = {}) => {
    const otpFlag = userDetail?.otp;
    return otpFlag === 1 || otpFlag === '1' || String(otpFlag ?? '').toLowerCase() === 'yes';
  };

  const establishLoginSession = (response) => {
    dispatch({ type: 'RESET_ALL_STATE' });
    dispatch(setInputUser(email));
    dispatch(setLogin({
      user: response.userDetail,
      token: response.token,
      loggedIn: true,
      featureAccess: response.FeatureAccess
    }));
    dispatch(setFetchUserByManager(response.fetchUserByManager));
    dispatch(setIsCaller(response.userDetail.callingFlag === 'Y' ? 'caller' : 'noncaller'));
    sessionStorage.removeItem("dashboard_last_fetch_time");
  };

  const navigateAfterLogin = (response) => {
    if (response.userDetail.roleType === "MIBL") {
      navigate(`/${encodeURIComponent(encryptRoute('/admindashboard'))}`);
    }
    else if (response.userDetail.roleType === "DEALER") {
      navigate(`/${encodeURIComponent(encryptRoute('/managerdashboard'))}`);
    }
  };

  const completeLogin = (response) => {
    establishLoginSession(response);
    navigateAfterLogin(response);
  };

  const startClientOtpFlow = async (response) => {
    const userDetail = response?.userDetail ?? {};
    const otpEmail = userDetail.email ?? email;
    const otpUserId = userDetail.user_id ?? userDetail.userId ?? userDetail.userid;
    const otpLastLoginDate = userDetail.lastLoginDate ?? userDetail.last_login_date ?? '';

    if (!otpUserId || !otpEmail) {
      toast.error('Unable to generate OTP. User email or user id is missing.');
      return;
    }

    establishLoginSession(response);

    const otpResponse = await generateClientLoginOtp({
      userId: otpUserId,
      email: otpEmail,
      lastLoginDate: otpLastLoginDate,
    });

    if (otpResponse?.status && Number(otpResponse.status) >= 400) {
      toast.error(otpResponse?.message || 'Unable to generate OTP. Please try again.');
      return;
    }

    setPendingLoginResponse(response);
    setOtpAttempts(0);
    setOtpError('');
    setOtpShow(true);
  };

  const handleLogin = async (event, forceLogin = false) => {
    if (APP_CONFIG.DEV_BYPASS_LOGIN) {
      navigate(encodedRoutePath(ROUTES.dashboard));
      return;
    }

    if (!validate()) return;

    try {
      setLoading(true);
      const response = await login(
        {
          // checkLoginType: loginType,
          checkLoginType: "Dealer",
          email,
          password,
          forceLogin,
        });
      if (response.status == "401") {
        toast.error(response.msg || MSG.toast.invalidCredentials);
        return;
      }
      // response.msg == "User already logged in. Do you want to logout previous session?"
      if (response.status == 409 && !forceLogin) {
        setopenBox(true);
        return;
      }

      if (response.status == "200") {
        if (response.userDetail?.lastLoginDate === null) {
          setPassword('');
          setErrors({});
          setChangePassword(true);
        }
        else if (isOtpEnabled(response.userDetail)) {
          setErrors({});
          await startClientOtpFlow(response);
        }
        else {
          const lastLoginDateStr = response.userDetail?.lastLoginDate;

          if (lastLoginDateStr !== null) {
            const lastLoginDate = new Date(lastLoginDateStr);
            const currentDate = new Date();

            const diffInTime = currentDate.getTime() - lastLoginDate.getTime();
            const diffInDays = diffInTime / (1000 * 3600 * 24);

            if (diffInDays > 15) {
              setPassword('');
              setErrors({});
              setResetPassword(true);
            } else {
              completeLogin(response);
            }
          }
        }
      }
      else {
        toast.error(response.msg || MSG.toast.invalidCredentials);
      }
    } catch (err) {
      console.log(err);
      toast.error(MSG.toast.loginError, err);
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async () => {
    const passwordError = validateLoginPassword(password);
    const rePasswordError = validatePasswordMatch(password, rePassword);

    setErrors({ password: passwordError, rePassword: rePasswordError });

    if (passwordError || rePasswordError) return;

    try {
      setLoading(true);
      if (changePassword) {
        const res = await changePasswordUser({ email: email, password: password, confirmPassword: rePassword });
        if (res.status_code === "200") {
          toast.success(MSG.toast.passwordUpdated);
          setChangePassword(false);
          setEmail('');
          setPassword('');
          setErrors({});
        } else if (res.status_code !== "200") toast.error(res.status_message);
      } else if (resetPassword) {
        const res = await resetPasswordUser({ email: email, password: password, confirmPassword: rePassword });
        if (res.status_code === "200") {
          toast.success(MSG.toast.passwordUpdated);
          setResetPassword(false);
          setEmail('');
          setPassword('');
          setErrors({});
        } else if (res.status_code !== "200") toast.error(res.status_message);
      }
    } catch (error) {
      toast.error('An error occurred during login. Please try again.', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (otpValue) => {
    const pendingUserDetail = pendingLoginResponse?.userDetail ?? {};
    const otpEmail = pendingUserDetail.email ?? email;
    const otpUserId = pendingUserDetail.user_id ?? pendingUserDetail.userId ?? pendingUserDetail.userid;
    const otpLastLoginDate = pendingUserDetail.lastLoginDate ?? pendingUserDetail.last_login_date ?? '';

    if (String(otpValue ?? '').length !== 6) {
      toast.error(MSG.toast.otpRequired);
      return;
    }

    try {
      setLoading(true);
      const response = await verifyClientLoginOtp({
        userId: otpUserId,
        email: otpEmail,
        otp: otpValue,
        lastLoginDate: otpLastLoginDate,
      });

      if (response?.verified === true) {
        setOtpError('');
        navigateAfterLogin(pendingLoginResponse);
      } else {
        const nextAttempts = otpAttempts + 1;
        setOtpAttempts(nextAttempts);

        if (nextAttempts >= MAX_OTP_ATTEMPTS) {
          toast.error('OTP verification failed. Please login again.');
          try {
            await logout(email);
          } catch (logoutError) {
            console.error('OTP failure logout failed', logoutError);
          }
          await clearSessionState({ broadcast: true });
          setOtpShow(false);
          setPendingLoginResponse(null);
          navigate('/', { replace: true });
          return;
        }

        setOtpError(response?.message || `Invalid OTP. ${MAX_OTP_ATTEMPTS - nextAttempts} attempt(s) left.`);
      }
    } catch (error) {
      console.log("error", error);
      toast.error(MSG.toast.otpVerifyError);
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    const pendingUserDetail = pendingLoginResponse?.userDetail ?? {};
    const otpEmail = pendingUserDetail.email ?? email;
    const otpUserId = pendingUserDetail.user_id ?? pendingUserDetail.userId ?? pendingUserDetail.userid;
    const otpLastLoginDate = pendingUserDetail.lastLoginDate ?? pendingUserDetail.last_login_date ?? '';

    try {
      setLoading(true);
      const data = await generateClientLoginOtp({
        userId: otpUserId,
        email: otpEmail,
        lastLoginDate: otpLastLoginDate,
      });
      if (data?.status && Number(data.status) >= 400) {
        toast.error(data?.message || 'Unable to resend OTP. Please try again.');
        return;
      }
      setOtpError('');
      toast.success(MSG.toast.otpSent);
    } catch (error) {
      toast.error(`${MSG.toast.otpSendError} ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleChange = (event, newValue) => {
    if (!newValue) return;

    setLoginType(newValue);

    if (newValue === "Dealer") {
      // fetchDealerData();
    } else if (newValue === "MIBL") {
      // fetchMiblData();
    }
  };

  const handleToggleShowPass = () => {
    setShowPass((prev) => !prev);
  };

  const handleNavigateForgot = () => {
    navigate(ROUTES.forgot);
  };

  const handleOtpBack = () => {
    setOtpShow(false);
    setPendingLoginResponse(null);
    setOtpAttempts(0);
    setOtpError('');
  };

  const handleToggleShowPassword = () => {
    setShowPassword((prev) => !prev);
  };

  const handleToggleShowRePassword = () => {
    setShowRePassword((prev) => !prev);
  };

  const handleCloseOpenBox = () => {
    setopenBox(false);
  };

  const handleForceLoginConfirm = (event) => {
    dispatch(setCredFlag(true));
    setopenBox(false);
    handleLogin(event, true);
  };


  return (
    <>
      <BackdropLoader loading={loading} />

      <Paper elevation={0} >
        <Grid container >
          {/* Screen left */}
          <Grid size={{ xs: 12, sm: 12, md: 4 }}>
            <Box
              //  elevation={0} 
              className={`login-side-panel ${isMobileView || isTabView ? 'login-side-panel--centered' : ''}`}>
              <Box className="login-policy-wrap">
                <img src={policyImg} className={`center-image login-policy-img ${isTabView ? 'login-policy-img--tab' : ''}`} alt="Commercial Lines Insurance" />
              </Box>
            </Box>
          </Grid>

          {/* Screen right */}
          {!(resetPassword || changePassword || otpShow) &&
            <Grid size={{ xs: 12, sm: 12, md: 7 }} className="login-form-grid">
              <Box className="login-brand-desktop-shell">
                <img src={logo} className="login-brand-floating-img" alt="M-BizDesk logo" />
              </Box>
              <Stack className={`login-form-stack ${isMobileView ? '' : 'login-form-stack--offset'}`}>
                <Box className="login-header-block">
                  <Typography className='georama-SemiBold fs-32 login-welcome-title'>Welcome</Typography>

                  <Typography className='nav-text text-gray login-subtitle'>Please Log in to your account</Typography>
                </Box>

                {loginType === "Dealer" &&
                  <Box className="login-field-group">
                    <Typography className="text-labels field-label">
                      Username <span className="important-fields">*</span>
                    </Typography>

                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter Username"
                      value={email}
                      onChange={(e) => setEmail(truncateAuthField('emailOrMobile', e.target.value.trim()))}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                    // InputProps={{
                    //   disableUnderline: true,
                    //   sx: { fontWeight: 'bold' },
                    // }}
                    />

                    {errors.email && (
                      <FormHelperText className="important-fields">{errors.email}</FormHelperText>
                    )}
                  </Box>}


                {loginType === "MIBL" &&
                  <Box className="login-field-group">
                    <Typography className="text-labels field-label">
                      SAP Code <span className="important-fields">*</span>
                    </Typography>

                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter SAP Code"
                      value={email}
                      onChange={(e) => setEmail(truncateAuthField('sapLogin', e.target.value.trim()))}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                    />

                    {errors.email && (
                      <FormHelperText className="important-fields">{errors.email}</FormHelperText>
                    )}
                  </Box>}

                <Box className="login-password-field">
                  <Typography className="text-labels field-label">
                    Password <span className="important-fields">*</span>
                  </Typography>

                  <Box className="field-inline">
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter Password"
                      type={showPass ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(truncateAuthField('password', e.target.value))}
                      onKeyDown={(e) => e.key === 'Enter' && !resetPassword && !changePassword && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={handleToggleShowPass} edge="end">
                            {showPass ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  {errors.password && (
                    <FormHelperText className="important-fields">{errors.password}</FormHelperText>
                  )}

                </Box>

                <Box className="login-submit-wrap">
                  <Button className="btn-common-red border-radius-32 login-submit-button"
                    onClick={handleLogin} disabled={loading}>
                    Log In
                  </Button>
                </Box>
              </Stack>
            </Grid>}

          {otpShow &&
            <Grid size={{ xs: 12, sm: 12, md: 7 }} className="login-form-grid">
              <Box className="login-brand-desktop-shell">
                <img src={logo} className="login-brand-floating-img" alt="M-BizDesk logo" />
              </Box>
              <Stack className={`login-form-stack ${isMobileView ? '' : 'login-form-stack--offset'}`}>
                <ClientOtpDialog
                  open={otpShow}
                  email={pendingLoginResponse?.userDetail?.email ?? email}
                  attemptsLeft={MAX_OTP_ATTEMPTS - otpAttempts}
                  loading={loading}
                  error={otpError}
                  onVerify={handleVerifyOtp}
                  onResend={handleResendCode}
                  onClose={handleOtpBack}
                />
              </Stack>
            </Grid>}

          {/* ------------------ Change Password Screen --------- */}
          {(resetPassword || changePassword) &&
            <Grid size={{ xs: 12, sm: 12, md: 6.8 }} className="auth-content-grid">
              <Stack className="auth-form-stack auth-form-stack--wide auth-form-stack--change-password">
                <Box>
                  <Typography className='georama-SemiBold fs-32 center-text change-password-title' >Change Password</Typography>
                </Box>

                <Box className="login-field-group">
                  <Typography className='text-labels field-label'>
                    New Password <span className="important-fields">*</span>
                  </Typography>

                  <Box className="field-inline">
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter New Password"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={handlePasswordChange}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={handleToggleShowPassword} edge="end">
                            {showPassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  <FormHelperText className="important-fields">{errors.password}</FormHelperText>
                </Box>

                <Box className="login-field-group">
                  <Typography className='text-labels field-label'>
                    Re-Enter New Password <span className="important-fields">*</span>
                  </Typography>

                  <Box className="field-inline">
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Re-Enter New Password"
                      type={showRePassword ? 'text' : 'password'}
                      value={rePassword}
                      onChange={handleRePasswordChange}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={handleToggleShowRePassword} edge="end">
                            {showRePassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  <FormHelperText className="important-fields">{errors.rePassword}</FormHelperText>
                </Box>

                <Button className="btn-common-red border-radius-32" onClick={handleChangePassword}>
                  Reset password
                </Button>
              </Stack>
            </Grid>}
        </Grid>
      </Paper>

      <Dialog className="login-confirm-dialog" open={openBox} onClose={handleCloseOpenBox}>
        <DialogContent className="login-confirm-dialog-content">
          <>
            <Typography className="login-confirm-dialog-message">
              An account with this email is already logged in. Do you want to continue and log in anyway?
            </Typography>
            <Box className="dialog-actions-row">
              <Button
                variant="contained"
                color="success"
                startIcon={<CheckCircleIcon />}
                onClick={handleForceLoginConfirm}
              >
                Yes
              </Button>
              <Button
                variant="outlined"
                color="error"
                startIcon={<CancelIcon />}
                onClick={handleCloseOpenBox}
              >
                No
              </Button>
            </Box>
          </>
        </DialogContent>
      </Dialog>
      <ToastContainer autoClose={1000} />
    </>
  )
};

export default Login;
