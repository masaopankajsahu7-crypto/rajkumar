import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box,
  Button,
  Chip,
  InputAdornment,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import { useLocation, useNavigate } from 'react-router-dom';
import SearchIcon from '@mui/icons-material/Search';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import OpportunityListFilters from '../components/opportunity/OpportunityListFilters.jsx';
import DateRangeFilter from '../components/common/DateRangeFilter.jsx';
import SortOrderButton from '../components/common/SortOrderButton.jsx';
import { OPPORTUNITY_LIST_MESSAGES as MSG } from '../config/messages/opportunity.js';
import {
  OPPORTUNITY_LIST_COLUMN_KEYS,
  OPPORTUNITY_LIST_COLUMN_LABELS,
} from '../config/opportunityListColumns.js';
import {
  getOpportunityStageToneClass,
  getOpportunityStatusToneClass,
} from '../config/opportunityStatusConfig.js';
import { useOpportunityList } from '../hooks/useFetchQueries.js';
import {
  getActiveOpportunityFilterChips,
  hasActiveOpportunityFilters,
  INITIAL_OPPORTUNITY_FILTERS,
} from '../utils/opportunityListFilters.js';
import {
  getOpportunityTotalPages,
  normalizeOpportunityStatus,
} from '../utils/opportunityList.js';
import { formatColumnLabel } from '../utils/labelFormat.js';
import { sanitizeByField } from '../utils/fieldUtils.js';
import { isListActionAllowed } from '../utils/listPermissions.js';
import { encodedRoutePath, opportunityWorkflowPath, ROUTES } from '../config/routes.js';
import './Clients.css';
import './Opportunities.css';

const DISPLAY_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];

const OPPORTUNITY_SORT_OPTIONS = [
  { code: 'created_on', value: 'Created Date' },
  { code: 'renewal_date', value: 'Renewal Date' },
  { code: 'brokerage_fee', value: 'Brokerage' },
  { code: 'expected_premium', value: 'Premium' },
];

const formatOpportunityPremium = (value) => {
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return '';

  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(numberValue);
};

const formatOpportunityBrokerageFee = (value) => {
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return '';

  return new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(numberValue);
};

const formatOpportunityDisplayDate = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '';

  const isoDateMatch = rawValue.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (isoDateMatch) {
    const [, year, month, day] = isoDateMatch;
    return `${Number(day)} ${DISPLAY_MONTHS[Number(month) - 1] ?? month} ${year}`;
  }

  const parsedDate = new Date(rawValue);
  if (Number.isNaN(parsedDate.getTime())) return rawValue;

  return `${parsedDate.getDate()} ${DISPLAY_MONTHS[parsedDate.getMonth()]} ${parsedDate.getFullYear()}`;
};

const getOpportunitySortValue = (row, sortColumn) => {
  if (sortColumn === 'expected_premium') return Number(row?.premium ?? row?.expected_premium ?? 0);
  if (sortColumn === 'brokerage_fee') return Number(row?.brokerage_fee ?? 0);
  if (sortColumn === 'renewal_date') return Date.parse(row?.renewal_date ?? '') || 0;
  return Date.parse(row?.created_on ?? '') || 0;
};

const sortOpportunityRows = (rows, sortColumn, sortOrder) => {
  const direction = String(sortOrder).toUpperCase() === 'ASC' ? 1 : -1;
  const column = sortColumn || 'created_on';

  return [...(rows ?? [])].sort((first, second) => {
    const firstValue = getOpportunitySortValue(first, column);
    const secondValue = getOpportunitySortValue(second, column);
    if (firstValue === secondValue) return 0;
    return (firstValue > secondValue ? 1 : -1) * direction;
  });
};

const EllipsizedTooltipText = ({ value, className = '' }) => {
  const textRef = useRef(null);
  const [isEllipsized, setIsEllipsized] = useState(false);

  const handleMouseEnter = () => {
    const element = textRef.current;
    setIsEllipsized(Boolean(element && element.scrollWidth > element.clientWidth));
  };

  return (
    <Tooltip title={isEllipsized ? value : ''} placement="top" arrow disableInteractive>
      <span ref={textRef} className={className} onMouseEnter={handleMouseEnter}>
        {value}
      </span>
    </Tooltip>
  );
};

const renderTooltipText = (value, className = '') => (
  <EllipsizedTooltipText value={value} className={className} />
);

const Opportunities = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState(INITIAL_OPPORTUNITY_FILTERS);
  const [appliedFilters, setAppliedFilters] = useState(INITIAL_OPPORTUNITY_FILTERS);
  const [searchInput, setSearchInput] = useState('');
  const { data: opportunityListResponse, isLoading, isFetching } = useOpportunityList(page, appliedFilters);

  const opportunityData = opportunityListResponse?.list ?? [];
  const canShowAddOpportunity = isListActionAllowed(opportunityListResponse?.isAdd);
  const sortedOpportunityData = useMemo(
    () => sortOpportunityRows(opportunityData, appliedFilters.sortColumn, appliedFilters.sortOrder),
    [appliedFilters.sortColumn, appliedFilters.sortOrder, opportunityData],
  );
  const totalCount = opportunityListResponse?.totalCount ?? 0;
  const totalPages = useMemo(() => getOpportunityTotalPages(totalCount), [totalCount]);
  const tableHeaders = OPPORTUNITY_LIST_COLUMN_KEYS;

  useEffect(() => {
    const routeFilters = location.state?.filters;
    if (!routeFilters) return;

    const nextFilters = { ...INITIAL_OPPORTUNITY_FILTERS, ...routeFilters };
    setFilters(nextFilters);
    setAppliedFilters(nextFilters);
    setSearchInput(nextFilters.search ?? '');
    setPage(1);
    navigate(encodedRoutePath(ROUTES.opportunities), { replace: true, state: null });
  }, [location.state, navigate]);

  const paginationItems = useMemo(() => {
    if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);

    const pages = new Set([1, totalPages, page - 1, page, page + 1]);
    const visiblePages = [...pages]
      .filter((pageNumber) => pageNumber >= 1 && pageNumber <= totalPages)
      .sort((first, second) => first - second);

    return visiblePages.reduce((items, pageNumber, index) => {
      const previousPage = visiblePages[index - 1];
      if (index > 0 && pageNumber - previousPage > 1) {
        items.push(`ellipsis-${previousPage}-${pageNumber}`);
      }
      items.push(pageNumber);
      return items;
    }, []);
  }, [page, totalPages]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const nextSearch = searchInput.trim();
      setAppliedFilters((prev) => {
        if (prev.search === nextSearch) return prev;
        return { ...prev, search: nextSearch };
      });
    }, 300);

    return () => window.clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    setPage(1);
  }, [appliedFilters]);

  const handleFilterChange = (field, value) => {
    setFilters((prev) => ({ ...prev, [field]: value }));
  };

  const handleApplyFilters = () => {
    setAppliedFilters({ ...filters, search: searchInput.trim() });
    setPage(1);
  };

  const handleToggleSortOrder = () => {
    const nextSortOrder = String(appliedFilters.sortOrder).toUpperCase() === 'ASC' ? 'DESC' : 'ASC';
    setFilters((prev) => ({ ...prev, sortOrder: nextSortOrder }));
    setAppliedFilters((prev) => ({ ...prev, sortOrder: nextSortOrder }));
    setPage(1);
  };

  const handleClearFilters = () => {
    setFilters(INITIAL_OPPORTUNITY_FILTERS);
    setAppliedFilters(INITIAL_OPPORTUNITY_FILTERS);
    setSearchInput('');
    setPage(1);
  };

  const handleRemoveFilterChip = (field) => {
    const nextFilters = {
      ...appliedFilters,
      [field]: '',
      ...(field === 'product' ? { productLabel: '', subProduct: '', subProductLabel: '' } : {}),
      ...(field === 'subProduct' ? { subProductLabel: '' } : {}),
      ...(field === 'businessType' ? { businessTypeLabel: '' } : {}),
      ...(field === 'owner' ? { ownerId: '' } : {}),
      ...(field === 'placementRm' ? { placementRmId: '' } : {}),
      ...(field === 'clientName' ? { clientUUID: '' } : {}),
      ...(field === 'portfolioUUID' ? { portfolioLabel: '' } : {}),
      ...(field === 'clientVertical' ? { clientVerticalLabel: '' } : {}),
      ...(field === 'dateRangePreset' ? { renewalFrom: '', renewalTo: '' } : {}),
      ...(field === 'breached' ? { breached: '' } : {}),
    };
    setFilters(nextFilters);
    setAppliedFilters(nextFilters);
    if (field === 'search') setSearchInput('');
    setPage(1);
  };

  const handlePageButtonClick = (event) => {
    handlePageChange(Number(event.currentTarget.dataset.page));
  };

  const handlePageChange = (nextPage) => {
    if (nextPage === page || nextPage < 1 || nextPage > totalPages) return;
    setPage(nextPage);
  };

  const handlePrevPage = () => {
    handlePageChange(page - 1);
  };

  const handleNextPage = () => {
    handlePageChange(page + 1);
  };

  const handleOpportunityOpen = (event) => {
    const opportunityUUID = event.currentTarget.dataset.opportunityUuid;
    if (!opportunityUUID) return;
    navigate(opportunityWorkflowPath(opportunityUUID));
  };

  const handleAddOpportunity = () => {
    navigate(encodedRoutePath(ROUTES.opportunitiesCreate));
  };

  const filtersActive =
    hasActiveOpportunityFilters(filters) || hasActiveOpportunityFilters(appliedFilters);

  const activeFilterChips = useMemo(
    () => getActiveOpportunityFilterChips(appliedFilters, MSG.filters),
    [appliedFilters],
  );

  const renderCellValue = (header, row) => {
    const value = String(row?.[header] ?? '');

    if (!value) return '';

    if (header === 'renewal_date') {
      return formatOpportunityDisplayDate(value);
    }

    if (header === 'product') {
      return renderTooltipText(value, 'opportunity-mgmt-tooltip-text');
    }

    if (header === 'brokerage_fee') {
      const displayValue = formatOpportunityBrokerageFee(value);
      return renderTooltipText(displayValue, 'opportunity-mgmt-tooltip-text');
    }

    if (header === 'premium') {
      const displayValue = formatOpportunityPremium(value);
      return renderTooltipText(displayValue, 'opportunity-mgmt-tooltip-text');
    }

    if (header === 'client_name') {
      return (
        <Tooltip title={value}>
          <Button
            className="client-mgmt-name-link opportunity-mgmt-client-link"
            data-opportunity-uuid={row?.opportunity_uuid}
            onClick={handleOpportunityOpen}
          >
            <span className="client-mgmt-name-link-text opportunity-mgmt-client-name">{value}</span>
          </Button>
        </Tooltip>
      );
    }

    if (header === 'opportunity_status') {
      const displayValue = normalizeOpportunityStatus(value);
      return (
        <span
          className={`opportunity-mgmt-status-badge ${getOpportunityStatusToneClass(displayValue)}`}
          role="status"
          aria-label={displayValue}
        >
          {displayValue}
        </span>
      );
    }

    if (header === 'opportunity_stage') {
      const displayValue = String(value ?? '').trim();
      return (
        <span
          className={`opportunity-mgmt-stage-indicator ${getOpportunityStageToneClass(value)}`}
          role="status"
          aria-label={displayValue}
        >
          <EllipsizedTooltipText value={displayValue} className="opportunity-mgmt-stage-label" />
        </span>
      );
    }

    return value;
  };

  return (
    <Box className="client-mgmt-page opportunity-mgmt-page">
      <BackdropLoader loading={isLoading || isFetching} />
      <Paper className="client-mgmt-paper table-auto-width">
        <Box className="client-mgmt-head-block table-body-bg border-radius-top-8">
          <Box className="client-mgmt-toolbar client-mgmt-toolbar-head">
            <Box className="client-mgmt-toolbar-left">
              <Box className="client-mgmt-page-title-wrap">
                <Typography className="georama-SemiBold fs-24 client-mgmt-title">{MSG.title}</Typography>
              </Box>
            </Box>
            <Box className="client-mgmt-toolbar-right">
              <TextField
                className="client-mgmt-search form-control-input"
                size="small"
                placeholder={MSG.search}
                value={searchInput}
                onChange={(event) => setSearchInput(sanitizeByField('search', event.target.value))}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon fontSize="small" className="client-mgmt-search-icon" />
                    </InputAdornment>
                  ),
                }}
              />
              <OpportunityListFilters
                filters={filters}
                appliedFilters={appliedFilters}
                onChange={handleFilterChange}
                onApply={handleApplyFilters}
                onClear={handleClearFilters}
                hasActiveFilters={filtersActive}
              />
              <DateRangeFilter
                filters={filters}
                appliedFilters={appliedFilters}
                dateFromField="renewalFrom"
                dateToField="renewalTo"
                onChange={handleFilterChange}
                onApply={handleApplyFilters}
                labels={MSG.filters}
                showDateFilterType={false}
                sortOptions={OPPORTUNITY_SORT_OPTIONS}
              />
              <SortOrderButton value={appliedFilters.sortOrder} onToggle={handleToggleSortOrder} />
              {canShowAddOpportunity && (
                <Button className="btn-common-red border-radius-32 opportunity-mgmt-add-btn" onClick={handleAddOpportunity}>
                  {MSG.addNewOpportunity}
                </Button>
              )}
            </Box>
          </Box>

          {activeFilterChips.length > 0 && (
            <Box className="client-mgmt-active-filters">
              {activeFilterChips.map((chip) => (
                <Chip
                  key={chip.key}
                  label={chip.label}
                  size="small"
                  onDelete={() => handleRemoveFilterChip(chip.key)}
                  className="client-mgmt-filter-chip"
                />
              ))}
              <Button className="client-mgmt-filter-clear-all text-sky" onClick={handleClearFilters}>
                {MSG.filters.clearAll}
              </Button>
            </Box>
          )}
        </Box>

        <TableContainer component={Box} className="client-mgmt-table-wrap opportunity-mgmt-table-wrap">
          <Table>
            <TableHead>
              <TableRow>
                {tableHeaders.map((header) => (
                  <TableCell
                    key={header}
                    className={`client-mgmt-head-cell opportunity-mgmt-col-${header} georama-Medium fw-none`}
                  >
                    {formatColumnLabel(header, OPPORTUNITY_LIST_COLUMN_LABELS)}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody className="table-body-bg">
              {sortedOpportunityData.length > 0 ? (
                sortedOpportunityData.map((row, idx) => (
                  <TableRow key={row.opportunity_uuid || idx}>
                    {tableHeaders.map((header) => (
                      <TableCell
                        key={`${idx}-${header}`}
                        className={`p-4 georama-Regular fs-14 opportunity-mgmt-col-${header}`}
                      >
                        {renderCellValue(header, row)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={Math.max(tableHeaders.length, 1)} className="client-mgmt-no-data">
                    {MSG.noDataFound}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Box className="client-mgmt-pagination-wrap table-body-bg border-radius-bottom-8">
          <Typography className="client-mgmt-total-count georama-Medium">
            {MSG.totalOpportunities(totalCount)}
          </Typography>
          {totalPages > 1 && (
            <Box className="client-mgmt-pagination">
              <Button
                className="client-mgmt-pagination-nav"
                disabled={page <= 1}
                onClick={handlePrevPage}
                aria-label={MSG.previousPage}
              >
                <ChevronLeftIcon fontSize="small" />
              </Button>

              <Box className="client-mgmt-pagination-pages">
                {paginationItems.map((item) =>
                  typeof item === 'number' ? (
                    <Button
                      key={item}
                      className={`client-mgmt-pagination-page ${
                        item === page ? 'client-mgmt-pagination-page-active' : ''
                      }`}
                      data-page={item}
                      onClick={handlePageButtonClick}
                      aria-current={item === page ? 'page' : undefined}
                    >
                      {item}
                    </Button>
                  ) : (
                    <Typography key={item} className="client-mgmt-pagination-ellipsis">
                      ...
                    </Typography>
                  ),
                )}
              </Box>

              <Typography className="client-mgmt-pagination-label">{MSG.pageOf(totalPages)}</Typography>

              <Button
                className="client-mgmt-pagination-nav"
                disabled={page >= totalPages}
                onClick={handleNextPage}
                aria-label={MSG.nextPage}
              >
                <ChevronRightIcon fontSize="small" />
              </Button>
            </Box>
          )}
        </Box>
      </Paper>
    </Box>
  );
};

export default Opportunities;
