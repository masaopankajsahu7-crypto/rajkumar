import { useEffect, useState } from 'react';
import { Autocomplete, Box, Button, FormHelperText, Paper, TextField, Typography } from '@mui/material';
import { useQueryClient } from '@tanstack/react-query';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { useLocation, useNavigate } from 'react-router-dom';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import PortfolioFormFields from '../components/client/PortfolioFormFields.jsx';
import { ROUTES, clientsDetailPath, encodedRoutePath, opportunityWorkflowPath } from '../config/routes.js';
import {
  createOpportunity,
  getOpportunityPortfoliosByClient,
  getOpportunityWorkflowHierarchy,
  searchClientsByName,
} from '../services/api.jsx';
import { initialPortfolio } from '../utils/portfolioFormState.js';
import { validatePortfolioForm } from '../utils/portfolioFormValidation.js';
import { getCurrentUserId } from '../config/clientApiConfig.js';
import { invalidateBusinessDataQueries } from '../lib/queryClient.js';
import { getOpportunityFromHierarchy } from '../utils/opportunityWorkflow.js';
import './ClientsForm.css';

const getPrimaryOwnerName = (owners = []) => {
  const owner = Array.isArray(owners)
    ? owners.find((item) => item?.owner_type_code === 'PRIMARY') ?? owners[0]
    : null;
  return owner?.owner_name ?? owner?.name ?? '';
};

const OPPORTUNITY_SAVE_DIALOG = {
  savedTitle: 'Opportunity Saved Successfully!',
  savedMessage: 'The opportunity details have been captured and are ready for workflow tracking.',
  updatedTitle: 'Opportunity Updated Successfully!',
  updatedMessage: 'The opportunity details have been updated successfully.',
  viewOpportunity: 'View Opportunity',
  returnToList: 'Return to List View',
};

const OpportunityCreate = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();
  const routeClient = location.state?.selectedClient;
  const routePortfolio = location.state?.selectedPortfolio;
  const routeOpportunity = location.state?.selectedOpportunity;
  const routeOpportunityUUID = location.state?.opportunityUUID ?? routeOpportunity?.opportunity_uuid;
  const returnPath = location.state?.returnPath;
  const source = location.state?.source;
  const activeMenu = location.state?.activeMenu;
  const isEditMode = source === 'opportunityWorkflowEdit';
  const clientLockedFromRoute = Boolean(routeClient?.clientUUID) && !isEditMode;
  const [opportunity, setOpportunity] = useState(() => initialPortfolio());
  const [errors, setErrors] = useState({});
  const [clientQuery, setClientQuery] = useState('');
  const [clientOptions, setClientOptions] = useState([]);
  const [selectedClient, setSelectedClient] = useState(null);
  const [clientLoading, setClientLoading] = useState(false);
  const [portfolioOptions, setPortfolioOptions] = useState([]);
  const [selectedPortfolio, setSelectedPortfolio] = useState(null);
  const [portfolioLoading, setPortfolioLoading] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [editDataLoading, setEditDataLoading] = useState(false);
  const [successOpen, setSuccessOpen] = useState(false);
  const [savedOpportunityUUID, setSavedOpportunityUUID] = useState('');

  const mapRoutePortfolioOption = (portfolio) => {
    if (!portfolio) return null;
    const portfolioUUID =
      portfolio.portfolio_uuid ??
      portfolio.portfolio_UUID ??
      portfolio.uuid ??
      portfolio.raw?.portfolio_uuid ??
      portfolio.raw?.portfolio_UUID ??
      '';
    return {
      raw: portfolio,
      id: portfolioUUID || portfolio.portfolio_id || portfolio.id || portfolio.portfolioCode || '',
      uuid: portfolioUUID,
      product: portfolio.portfolio_product ?? portfolio.product ?? '',
      productCode:
        portfolio.portfolio_product_code ??
        portfolio.productCode ??
        portfolio.product_code ??
        portfolio.portfolio_data?.product_code ??
        '',
      subProduct: portfolio.portfolio_sub_product ?? portfolio.subProduct ?? portfolio.sub_product ?? '',
      subProductCode:
        portfolio.portfolio_sub_product_code ??
        portfolio.subProductCode ??
        portfolio.sub_product_code ??
        portfolio.portfolio_data?.sub_product ??
        '',
      renewalDate: portfolio.renewal_date ?? portfolio.renewalDate ?? '',
      totalOpps: portfolio.total_opportunities ?? portfolio.totalOpps ?? 0,
      owners: Array.isArray(portfolio.owners) ? portfolio.owners : [],
    };
  };

  const getPortfolioIdentity = (portfolio) =>
    String(portfolio?.uuid ?? portfolio?.portfolio_uuid ?? portfolio?.portfolio_UUID ?? portfolio?.id ?? '').trim();

  const mapRouteOpportunityToForm = (opportunityItem, portfolioItem) => {
    const data = opportunityItem?.opportunity_data ?? {};
    const brokeragePercentage =
      data.brokerage_percentage ?? data.brokerage ?? data.brokerage_consultancy ?? '';

    return {
      ...initialPortfolio(),
      product:
        data.product_code ??
        opportunityItem?.opportunity_product_code ??
        portfolioItem?.productCode ??
        '',
      sub_product:
        data.sub_product ??
        opportunityItem?.opportunity_sub_product_code ??
        portfolioItem?.subProductCode ??
        '',
      business_type:
        opportunityItem?.opportunity_type_code ??
        data.biz_type ??
        data.business_type ??
        '',
      sum_insured: data.sum_insured != null ? String(data.sum_insured) : '',
      expected_premium:
        opportunityItem?.expected_premium != null
          ? String(opportunityItem.expected_premium)
          : data.expected_premium != null
            ? String(data.expected_premium)
            : '',
      brokerage_consultancy: brokeragePercentage != null ? String(brokeragePercentage) : '',
      renewal_date: opportunityItem?.renewal_date ?? data.renewal_date ?? portfolioItem?.renewalDate ?? '',
      policy_start_date: data.policy_start_date ?? '',
      policy_expiry_date: data.policy_expiry_date ?? '',
      previous_insurer: data.previous_insurer ?? data.previous_insuere ?? '',
      previous_policy_number: data.previous_policy_number ?? '',
    };
  };

  useEffect(() => {
    if (!routeClient?.clientUUID) return;

    const nextClient = {
      clientUUID: routeClient.clientUUID,
      clientName: routeClient.clientName ?? '',
      primaryOwner: routeClient.primaryOwner ?? '',
    };

    setSelectedClient(nextClient);
    setClientQuery(nextClient.clientName);
    setClientOptions([]);
  }, [routeClient?.clientName, routeClient?.clientUUID, routeClient?.primaryOwner]);

  useEffect(() => {
    const nextPortfolio = mapRoutePortfolioOption(routePortfolio);
    if (!nextPortfolio) return;

    setSelectedPortfolio(nextPortfolio);
    setPortfolioOptions((prev) => {
      const exists = prev.some((item) => item.id === nextPortfolio.id);
      return exists ? prev : [nextPortfolio, ...prev];
    });
    setOpportunity(mapRouteOpportunityToForm(routeOpportunity, nextPortfolio));
    setErrors((prev) => {
      const next = { ...prev };
      delete next.portfolio;
      return next;
    });
  }, [routeOpportunity, routePortfolio]);

  useEffect(() => {
    if (!isEditMode || !routeOpportunityUUID) return undefined;

    let cancelled = false;
    const loadOpportunityForEdit = async () => {
      setEditDataLoading(true);
      setSaveError('');

      try {
        const response = await getOpportunityWorkflowHierarchy(routeOpportunityUUID);
        if (cancelled) return;

        const payload = response?.payload ?? {};
        const { portfolio: apiPortfolio, opportunity: apiOpportunity } = getOpportunityFromHierarchy(
          payload,
          routeOpportunityUUID,
        );
        const nextPortfolio = mapRoutePortfolioOption(apiPortfolio);
        const client = payload.client ?? {};
        const nextClient = {
          clientUUID: client.client_uuid ?? client.client_UUID ?? '',
          clientName: client.client_name ?? '',
          primaryOwner: getPrimaryOwnerName(apiPortfolio?.owners),
        };

        setSelectedClient(nextClient);
        setClientQuery(nextClient.clientName);
        setClientOptions([]);

        if (nextPortfolio) {
          setSelectedPortfolio(nextPortfolio);
          setPortfolioOptions([nextPortfolio]);
          setOpportunity(mapRouteOpportunityToForm(apiOpportunity, nextPortfolio));
        }

        setErrors({});
      } catch (error) {
        if (!cancelled) {
          setSaveError(error?.message || 'Opportunity details could not be loaded');
        }
      } finally {
        if (!cancelled) setEditDataLoading(false);
      }
    };

    loadOpportunityForEdit();

    return () => {
      cancelled = true;
    };
  }, [isEditMode, routeOpportunityUUID]);

  const renderDropdownEmpty = (title, subtitle) => (
    <Box className="client-kds-empty-state">
      <Typography className="client-kds-empty-title">{title}</Typography>
      <Typography className="client-kds-empty-subtitle">{subtitle}</Typography>
    </Box>
  );

  useEffect(() => {
    const trimmedQuery = clientQuery.trim();
    if (!trimmedQuery || selectedClient?.clientName === trimmedQuery) {
      setClientOptions([]);
      return undefined;
    }

    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setClientLoading(true);
      const results = await searchClientsByName(trimmedQuery, { source: 'client' });
      if (!cancelled) {
        setClientOptions(results);
        setClientLoading(false);
      }
    }, 350);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [clientQuery, selectedClient?.clientName]);

  useEffect(() => {
    const clientUUID = selectedClient?.clientUUID;
    if (!clientUUID) {
      setPortfolioOptions([]);
      setSelectedPortfolio(null);
      return undefined;
    }

    let cancelled = false;
    const loadPortfolios = async () => {
      setPortfolioLoading(true);
      const results = await getOpportunityPortfoliosByClient(clientUUID);
      if (!cancelled) {
        const routePortfolioOption = mapRoutePortfolioOption(routePortfolio);
        const selectedPortfolioUUID = getPortfolioIdentity(routePortfolioOption);
        const matchedRoutePortfolio = selectedPortfolioUUID
          ? results.find((portfolio) => getPortfolioIdentity(portfolio) === selectedPortfolioUUID)
          : null;
        const nextSelectedPortfolio = matchedRoutePortfolio ?? routePortfolioOption;
        const nextOptions =
          nextSelectedPortfolio && !results.some((portfolio) => getPortfolioIdentity(portfolio) === getPortfolioIdentity(nextSelectedPortfolio))
            ? [nextSelectedPortfolio, ...results]
            : results;

        setPortfolioOptions(nextOptions);
        if (routePortfolioOption) {
          setSelectedPortfolio(nextSelectedPortfolio);
          setOpportunity((prev) => ({
            ...prev,
            product: nextSelectedPortfolio?.productCode || prev.product,
            sub_product: nextSelectedPortfolio?.subProductCode || prev.sub_product,
            renewal_date: prev.renewal_date || nextSelectedPortfolio?.renewalDate || '',
          }));
        }
        setPortfolioLoading(false);
      }
    };

    loadPortfolios();

    return () => {
      cancelled = true;
    };
  }, [routePortfolio, selectedClient?.clientUUID]);

  const handleBack = () => {
    if (returnPath) {
      navigate(returnPath, activeMenu ? { state: { activeMenu } } : undefined);
      return;
    }

    if (source === 'clientDashboard' && routeClient?.clientUUID) {
      navigate(clientsDetailPath(routeClient.clientUUID), {
        state: { selectedClient: routeClient, activeMenu },
      });
      return;
    }

    if (source === 'clientList') {
      navigate(encodedRoutePath(ROUTES.clients));
      return;
    }

    navigate(encodedRoutePath(ROUTES.opportunities));
  };

  const handleClientSelect = (_, client) => {
    if (clientLockedFromRoute) return;
    setSelectedClient(client);
    setClientQuery(client?.clientName ?? '');
    setSelectedPortfolio(null);
    setPortfolioOptions([]);
    setOpportunity(initialPortfolio());
    setErrors((prev) => {
      const next = { ...prev };
      delete next.client;
      delete next.portfolio;
      return next;
    });
  };

  const handleClientInputChange = (_, value, reason) => {
    if (clientLockedFromRoute) return;
    setClientQuery(value);
    if (reason === 'input') {
      setSelectedClient(null);
      setSelectedPortfolio(null);
      setPortfolioOptions([]);
      setOpportunity(initialPortfolio());
    }
  };

  const handleOpportunityChange = (field, value) => {
    setOpportunity((prev) => ({
      ...prev,
      [field]: value,
    }));
    setErrors((prev) => {
      const next = { ...prev };
      delete next[field];
      return next;
    });
    setSaveError('');
  };

  const handlePortfolioSelect = (_, portfolio) => {
    setSelectedPortfolio(portfolio);
    if (portfolio) {
      setOpportunity((prev) => ({
        ...prev,
        product: portfolio.productCode || prev.product,
        sub_product: portfolio.subProductCode || prev.sub_product,
      }));
    }
    setErrors((prev) => {
      const next = { ...prev };
      delete next.portfolio;
      return next;
    });
    setSaveError('');
  };

  const withoutContactErrors = (nextErrors) => {
    const cleaned = { ...nextErrors };
    delete cleaned.primary_contact_person;
    delete cleaned.primary_contact_mobile;
    delete cleaned.primary_contact_email;
    Object.keys(cleaned).forEach((key) => {
      if (key.startsWith('other_contact_')) delete cleaned[key];
    });
    return cleaned;
  };

  const toNumber = (value) => {
    const num = Number(value);
    return Number.isFinite(num) ? num : 0;
  };

  const buildOwnersPayload = () => {
    const owners = selectedPortfolio?.owners?.length
      ? selectedPortfolio.owners
      : selectedPortfolio?.raw?.owners;

    if (!Array.isArray(owners)) return [];

    return owners
      .map((owner) => ({
        owner_id: owner?.owner_id ?? owner?.ownerId ?? owner?.id,
        owner_type_code: owner?.owner_type_code ?? owner?.ownerTypeCode ?? owner?.type,
      }))
      .filter((owner) => owner.owner_id && owner.owner_type_code);
  };

  const buildOpportunitySavePayload = () => {
    const expectedPremium = toNumber(opportunity.expected_premium);
    const brokeragePercentage = toNumber(opportunity.brokerage_consultancy);
    const brokerageFee = Number(((expectedPremium * brokeragePercentage) / 100).toFixed(2));
    const opportunityUUID = String(routeOpportunityUUID ?? '').trim();

    return {
      userid: getCurrentUserId(),
      message: isEditMode ? 'Updating corporate opportunity' : 'Creating a new corporate opportunity',
      payload: {
        opportunity: {
          ...(isEditMode && opportunityUUID ? { opportunity_uuid: opportunityUUID } : {}),
          client_uuid: selectedClient?.clientUUID ?? '',
          portfolio_uuid: selectedPortfolio?.uuid ?? selectedPortfolio?.id ?? '',
          opportunity_type_code: opportunity.business_type,
          opportunity_status_code: 'OPEN',
          opportunity_stage_code: 'OPPORTUNITY',
          expected_premium: expectedPremium,
          brokerage_fee: brokerageFee,
          reward_fee: 0,
          renewal_date: opportunity.renewal_date,
        },
        opportunity_data: {
          risk_profile: '',
          previous_insurer: opportunity.previous_insurer,
          brokerage_percentage: String(opportunity.brokerage_consultancy ?? ''),
          reward_percentage: '',
          corporate_tier: '',
          exclusions_applied: [],
          sum_insured: toNumber(opportunity.sum_insured),
          product_code: opportunity.product,
          sub_product: opportunity.sub_product,
          previous_policy_number: opportunity.previous_policy_number,
          policy_start_date: opportunity.policy_start_date,
          policy_expiry_date: opportunity.policy_expiry_date,
        },
        owners: buildOwnersPayload(),
      },
    };
  };

  const getSavedOpportunityUUID = (response) =>
    response?.payload?.opportunity?.opportunity_uuid ??
    response?.payload?.opportunity_uuid ??
    response?.opportunity_uuid ??
    '';

  const handleSuccessReturnToList = () => {
    setSuccessOpen(false);
    navigate(encodedRoutePath(ROUTES.opportunities), activeMenu ? { state: { activeMenu } } : undefined);
  };

  const handleSuccessViewOpportunity = () => {
    setSuccessOpen(false);
    const nextOpportunityUUID = savedOpportunityUUID || routeOpportunityUUID;
    navigate(
      nextOpportunityUUID ? opportunityWorkflowPath(nextOpportunityUUID) : encodedRoutePath(ROUTES.opportunities),
      activeMenu ? { state: { activeMenu } } : undefined,
    );
  };

  const handleSubmit = async () => {
    const nextErrors = {
      ...(!selectedClient ? { client: 'Client selection is required' } : {}),
      ...(!selectedPortfolio ? { portfolio: 'Portfolio selection is required' } : {}),
      ...(selectedPortfolio ? withoutContactErrors(validatePortfolioForm(opportunity)) : {}),
    };
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSaveError('');

    setIsSaving(true);
    try {
      const response = await createOpportunity(buildOpportunitySavePayload());
      await invalidateBusinessDataQueries(queryClient);
      setSavedOpportunityUUID(getSavedOpportunityUUID(response));
      setSuccessOpen(true);
    } catch (error) {
      setSaveError(error?.message || 'Opportunity save failed');
    } finally {
      setIsSaving(false);
    }
  };

  const canSubmitOpportunity = Boolean(selectedClient && selectedPortfolio) && !isSaving;

  return (
    <Box className="client-form-page">
      <ClientSaveSuccessDialog
        open={successOpen}
        isUpdate={isEditMode}
        title={isEditMode ? OPPORTUNITY_SAVE_DIALOG.updatedTitle : OPPORTUNITY_SAVE_DIALOG.savedTitle}
        message={isEditMode ? OPPORTUNITY_SAVE_DIALOG.updatedMessage : OPPORTUNITY_SAVE_DIALOG.savedMessage}
        primaryLabel={OPPORTUNITY_SAVE_DIALOG.viewOpportunity}
        secondaryLabel={OPPORTUNITY_SAVE_DIALOG.returnToList}
        onViewProfile={handleSuccessViewOpportunity}
        onReturnToList={handleSuccessReturnToList}
      />
      <Paper className="client-form-paper table-auto-width">
        <Box className="client-form-body">
          <Box className="client-form-header">
            <Typography className="georama-SemiBold fs-24 client-form-title">
              {isEditMode ? 'Edit Opportunity' : 'Add Opportunity'}
            </Typography>
            <Button
              className="text-capitalize georama-medium-selected custom-starticon client-form-back-btn"
              startIcon={<ChevronLeftIcon />}
              onClick={handleBack}
            >
              Back
            </Button>
          </Box>
          <Box className="client-form-header-divider" />

          <Box className="client-form-wizard">
            <Box className="client-form-step-panel">
              <Box className="client-form-step-panel-head">
                <Typography className="client-form-step-indicator georama-Regular">OPPORTUNITY</Typography>
                <Typography className="client-form-step-title georama-SemiBold">Opportunity</Typography>
              </Box>

              <Box className="client-form-section-body client-form-section-body--panel opportunity-create-section-body">
                <Box className="opportunity-create-context opportunity-create-selection-card">
                  <Box className="opportunity-create-context-head">
                    <Typography className="client-form-portfolio-subsection-title georama-SemiBold">
                      Select Client & Portfolio
                    </Typography>
                    <Typography className="opportunity-create-context-note">
                      Choose a client and one of its portfolios to proceed.
                    </Typography>
                  </Box>
                  <Box className="client-form-portfolio-grid opportunity-create-context-grid">
                    <Box className="client-form-field">
                      <Typography className="text-labels client-form-label">
                        Client <span className="important-fields">*</span>
                      </Typography>
                      <Autocomplete
                        className="client-kds-autocomplete form-control-input border-radius-8"
                        options={clientOptions}
                        value={selectedClient}
                        inputValue={clientQuery}
                        loading={clientLoading}
                        disabled={clientLockedFromRoute}
                        autoHighlight
                        filterOptions={(options) => options}
                        getOptionLabel={(option) => option?.clientName ?? ''}
                        isOptionEqualToValue={(option, selected) => option.clientUUID === selected.clientUUID}
                        noOptionsText={
                          clientLoading
                            ? renderDropdownEmpty('Searching clients', 'Please wait while we check matching records.')
                            : renderDropdownEmpty('No client found', 'Try another client name or refine your search.')
                        }
                        onChange={handleClientSelect}
                        onInputChange={handleClientInputChange}
                        slotProps={{
                          paper: { className: 'client-kds-menu-paper' },
                          listbox: { className: 'client-kds-menu-list' },
                        }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            size="small"
                            placeholder="Type client name"
                            error={!!errors.client}
                          />
                        )}
                        renderOption={(props, option) => {
                          const { key, className, ...optionProps } = props;
                          return (
                            <li
                              key={key}
                              {...optionProps}
                              className={`${className ?? ''} client-kds-menu-item client-kds-menu-item--rich`}
                            >
                              <Box className="opportunity-create-option">
                                <Typography className="opportunity-create-option-title">{option.clientName}</Typography>
                                <Typography className="opportunity-create-option-meta">
                                  Owner: {option.primaryOwner || option.owner || '---'}
                                </Typography>
                              </Box>
                            </li>
                          );
                        }}
                      />
                      {errors.client && <FormHelperText className="important-fields">{errors.client}</FormHelperText>}
                    </Box>

                    <Box className="client-form-field">
                      <Typography className="text-labels client-form-label">
                        Portfolio <span className="important-fields">*</span>
                      </Typography>
                      <Autocomplete
                        className="client-kds-autocomplete form-control-input border-radius-8"
                        options={portfolioOptions}
                        value={selectedPortfolio}
                        loading={portfolioLoading}
                        disabled={!selectedClient}
                        autoHighlight
                        getOptionLabel={(option) =>
                          [option?.product, option?.subProduct].filter(Boolean).join(' - ') || option?.id || ''
                        }
                        isOptionEqualToValue={(option, selected) =>
                          getPortfolioIdentity(option) === getPortfolioIdentity(selected)
                        }
                        noOptionsText={
                          portfolioLoading
                            ? renderDropdownEmpty('Loading portfolios', 'Please wait while portfolios are fetched.')
                            : renderDropdownEmpty('No portfolio found', 'This client does not have a selectable portfolio yet.')
                        }
                        onChange={handlePortfolioSelect}
                        slotProps={{
                          paper: { className: 'client-kds-menu-paper' },
                          listbox: { className: 'client-kds-menu-list' },
                        }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            size="small"
                            placeholder={selectedClient ? 'Select portfolio' : 'Select client first'}
                            error={!!errors.portfolio}
                          />
                        )}
                        renderOption={(props, option) => {
                          const { key, className, ...optionProps } = props;
                          return (
                            <li
                              key={key}
                              {...optionProps}
                              className={`${className ?? ''} client-kds-menu-item client-kds-menu-item--rich`}
                            >
                              <Box className="opportunity-create-option">
                                <Typography className="opportunity-create-option-title">
                                  {[option.product, option.subProduct].filter(Boolean).join(' - ') || option.id}
                                </Typography>
                                <Typography className="opportunity-create-option-meta">
                                  Renewal: {option.renewalDate || '---'} | Total Opps: {option.totalOpps ?? 0}
                                </Typography>
                              </Box>
                            </li>
                          );
                        }}
                      />
                      {errors.portfolio && <FormHelperText className="important-fields">{errors.portfolio}</FormHelperText>}
                    </Box>
                  </Box>
                </Box>

                {selectedPortfolio && (
                  <Box className="opportunity-create-form-panel">
                    <PortfolioFormFields
                      portfolio={opportunity}
                      errors={errors}
                      onChange={handleOpportunityChange}
                      lockedFields={isEditMode ? [] : ['product', 'sub_product']}
                      hideContacts
                    />
                  </Box>
                )}

                {saveError && (
                  <Box className="client-form-save-error" role="alert">
                    <Typography className="client-form-save-error-title georama-SemiBold">
                      Opportunity could not be saved
                    </Typography>
                    <Typography className="client-form-save-error-text georama-Regular">
                      {saveError}
                    </Typography>
                  </Box>
                )}
              </Box>

              <Box className="client-form-step-footer">
                <Box className="client-form-step-footer-right">
                  <Button
                    className="btn-common-red border-radius-32 client-form-submit-btn"
                    onClick={handleSubmit}
                    disabled={!canSubmitOpportunity}
                  >
                    {isSaving ? 'Saving...' : isEditMode ? 'Update Opportunity' : 'Submit Opportunity'}
                  </Button>
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default OpportunityCreate;
