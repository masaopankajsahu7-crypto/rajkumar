import { useEffect, useMemo, useState } from 'react';
import { Box, Button, Typography } from '@mui/material';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams } from 'react-router-dom';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import OpportunityActivityLogs from '../components/opportunityWorkflow/OpportunityActivityLogs.jsx';
import OpportunityAssignmentDialog from '../components/opportunityWorkflow/OpportunityAssignmentDialog.jsx';
import OpportunityStageStepper from '../components/opportunityWorkflow/OpportunityStageStepper.jsx';
import OpportunitySideCard from '../components/opportunityWorkflow/OpportunitySideCard.jsx';
import OpportunityWorkflowDetails from '../components/opportunityWorkflow/OpportunityWorkflowDetails.jsx';
import OpportunityWorkflowForm from '../components/opportunityWorkflow/OpportunityWorkflowForm.jsx';
import OpportunityWorkflowSummary from '../components/opportunityWorkflow/OpportunityWorkflowSummary.jsx';
import OpportunityWorkflowTabs from '../components/opportunityWorkflow/OpportunityWorkflowTabs.jsx';
import {
  useOpportunityActivityLogs,
  useKdsOptions,
  useOpportunityWorkflowHierarchy,
  useOpportunityWorkflowRecords,
  useOpportunityWorkflowStages,
} from '../hooks/useFetchQueries.js';
import { OPPORTUNITY_KDS_FIELDS } from '../config/kdsFields.js';
import { encodedRoutePath, opportunityPortfolioContactsPath, opportunityWorkflowPath } from '../config/routes.js';
import { invalidateBusinessDataQueries } from '../lib/queryClient.js';
import { assignOpportunityPlacementRm } from '../services/api.jsx';
import { getEncryptedRouteParam } from '../utils/encryptedRouteParams.js';
import {
  buildWorkflowStages,
  formatWorkflowCurrency,
  formatWorkflowDate,
  formatWorkflowDateTime,
  formatWorkflowValue,
  getOpportunityFromHierarchy,
  normalizeStageCode,
  normalizeOpportunityContacts,
} from '../utils/opportunityWorkflow.js';
import './OpportunityWorkflow.css';

const getPrimaryOwnerName = (owners = []) => {
  const owner = owners.find((item) => item.owner_type_code === 'PRIMARY') ?? owners[0];
  return owner?.owner_name ?? '---';
};

const getAssigneeName = (assignee) => {
  if (!assignee) return '';
  if (typeof assignee === 'string' || typeof assignee === 'number') return String(assignee);

  return (
    assignee.owner_name ??
    assignee.name ??
    assignee.user_name ??
    assignee.placement_rm_name ??
    ''
  );
};

const isEnabledFlag = (value) => String(value ?? '').trim() === '1';

export default function OpportunityWorkflow() {
  const { opportunityUUID, encrypted } = useParams();
  const routeOpportunityUUID =
    opportunityUUID || getEncryptedRouteParam(encrypted, /^\/opportunities\/([^/]+)$/);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('workflow');
  const [assignmentDialogOpen, setAssignmentDialogOpen] = useState(false);
  const [assignmentSuccessOpen, setAssignmentSuccessOpen] = useState(false);
  const hierarchyQuery = useOpportunityWorkflowHierarchy(routeOpportunityUUID);
  const workflowQuery = useOpportunityWorkflowRecords(routeOpportunityUUID);
  const workflowStagesQuery = useOpportunityWorkflowStages();
  const { data: insurerOptions = [] } = useKdsOptions(OPPORTUNITY_KDS_FIELDS.previousInsurer);

  const hierarchyPayload = hierarchyQuery.data?.payload ?? {};
  const workflowPayload = workflowQuery.data?.payload ?? {};
  const canViewDetails = isEnabledFlag(hierarchyPayload.is_view);
  const canEdit = isEnabledFlag(hierarchyPayload.is_edit);
  const canAssignPlacementRm = isEnabledFlag(hierarchyPayload.is_placementrm);
  const canViewWorkflow = isEnabledFlag(hierarchyPayload.is_workflow);
  const canViewWorkflowDetails = isEnabledFlag(hierarchyPayload.is_workflow_log);
  const canViewActivityLogs = isEnabledFlag(hierarchyPayload.is_activity_log);
  const canManageDelay = isEnabledFlag(hierarchyPayload.is_delay);
  const visibleActiveTab = useMemo(() => {
    if (activeTab === 'workflow' && canViewWorkflow) return 'workflow';
    if (activeTab === 'activityLogs' && canViewActivityLogs) return 'activityLogs';
    if (activeTab === 'workflowDetails' && canViewWorkflowDetails) return 'workflowDetails';
    if (canViewWorkflow) return 'workflow';
    if (canViewWorkflowDetails) return 'workflowDetails';
    if (canViewActivityLogs) return 'activityLogs';
    return '';
  }, [activeTab, canViewActivityLogs, canViewWorkflow, canViewWorkflowDetails]);
  const activityLogsQuery = useOpportunityActivityLogs(routeOpportunityUUID, {
    enabled: visibleActiveTab === 'activityLogs' && canViewActivityLogs,
  });
  const { portfolio, opportunity } = useMemo(
    () => getOpportunityFromHierarchy(hierarchyPayload, routeOpportunityUUID),
    [hierarchyPayload, routeOpportunityUUID],
  );
  const summaryOpportunityStage = Array.isArray(portfolio?.opportunities)
    ? portfolio.opportunities[0]?.opportunity_stage
    : '';
  const workflowStages = Array.isArray(workflowPayload.workflow_stages) ? workflowPayload.workflow_stages : [];
  const opportunityContacts = useMemo(
    () => normalizeOpportunityContacts(portfolio?.contacts),
    [portfolio?.contacts],
  );
  const stepperStages = useMemo(
    () => buildWorkflowStages(workflowPayload, workflowStagesQuery.data, {
      useFallback: !workflowStagesQuery.isLoading && !workflowStagesQuery.isFetching,
    }),
    [workflowPayload, workflowStagesQuery.data, workflowStagesQuery.isFetching, workflowStagesQuery.isLoading],
  );
  const currentStageCode = normalizeStageCode(
    workflowPayload.workflow_state?.current_stage_code ??
      opportunity?.opportunity_stage_code ??
      opportunity?.opportunity_stage,
  );
  const shouldShowAssignmentPanel =
    visibleActiveTab === 'workflow' && currentStageCode === 'OPPORTUNITY' && canViewWorkflow;

  const getInsurerLabel = (value) => {
    const normalizedValue = String(value ?? '').trim();
    if (!normalizedValue) return '';
    const matched = insurerOptions.find(
      (option) =>
        String(option.code ?? '').trim() === normalizedValue ||
        String(option.value ?? '').trim() === normalizedValue,
    );
    return matched?.value ?? normalizedValue;
  };

  const handleOpenAssignmentDialog = () => {
    if (!canAssignPlacementRm) return;
    setAssignmentDialogOpen(true);
  };

  const handleCloseAssignmentDialog = () => {
    setAssignmentDialogOpen(false);
  };

  const handleAssignPlacementRm = async (placementRmId) => {
    await assignOpportunityPlacementRm({ opportunityUUID: routeOpportunityUUID, placementRmId });
    await invalidateBusinessDataQueries(queryClient);
    await Promise.all([hierarchyQuery.refetch(), workflowQuery.refetch()]);
    setAssignmentDialogOpen(false);
    setAssignmentSuccessOpen(true);
  };

  const handleCloseAssignmentSuccess = () => {
    setAssignmentSuccessOpen(false);
  };

  const handleEditOpportunityForm = () => {
    navigate(encodedRoutePath('/opportunities/create'), {
      state: {
        source: 'opportunityWorkflowEdit',
        returnPath: opportunityWorkflowPath(routeOpportunityUUID),
        opportunityUUID: routeOpportunityUUID,
        selectedClient: {
          clientUUID: hierarchyPayload.client?.client_uuid,
          clientName: hierarchyPayload.client?.client_name,
          primaryOwner: getPrimaryOwnerName(portfolio?.owners),
        },
        selectedPortfolio: portfolio,
        selectedOpportunity: opportunity,
      },
    });
  };

  const handleEditPortfolioContacts = () => {
    navigate(opportunityPortfolioContactsPath(routeOpportunityUUID), {
      state: {
        source: 'opportunityWorkflowContactsEdit',
        contactOnlyFromOpportunity: true,
        fromClientList: true,
        returnPath: opportunityWorkflowPath(routeOpportunityUUID),
        clientDraft: {
          clientUUID: hierarchyPayload.client?.client_uuid,
          basicDetails: {
            client_name: hierarchyPayload.client?.client_name,
          },
          communication: {},
          accountOwner: {},
          portfolios: [portfolio],
        },
        portfolioIndex: 0,
        selectedPortfolio: portfolio,
        selectedOpportunity: opportunity,
      },
    });
  };

  useEffect(() => {
    if (shouldShowAssignmentPanel && canAssignPlacementRm) {
      setAssignmentDialogOpen(true);
    }
    if (!canAssignPlacementRm) {
      setAssignmentDialogOpen(false);
    }
  }, [canAssignPlacementRm, shouldShowAssignmentPanel]);

  const assigneeRows = [
    { label: 'Opportunity Owner', value: getPrimaryOwnerName(opportunity?.owners) },
    {
      label: 'Placement RM',
      value: formatWorkflowValue(
        getAssigneeName(opportunity?.placement_rm) || getAssigneeName(workflowPayload.placement_rm),
      ),
    },
    { label: 'Assigned by', value: getPrimaryOwnerName(portfolio?.owners) },
    { label: 'Assigned on', value: formatWorkflowDateTime(opportunity?.created_on) },
  ];

  const opportunityRows = [
    { label: 'Business', value: formatWorkflowValue(opportunity?.opportunity_type) },
    { label: 'Premium', value: formatWorkflowCurrency(opportunity?.expected_premium) },
    { label: 'Brokerage Fee', value: formatWorkflowCurrency(opportunity?.brokerage_fee) },
    { label: 'Renewal Date', value: formatWorkflowDate(opportunity?.renewal_date) },
  ];

  const previousPolicyRows = [
    {
      label: 'Previous Policy',
      value: formatWorkflowValue(opportunity?.opportunity_data?.previous_policy_number),
    },
    {
      label: 'Insurer',
      value: formatWorkflowValue(getInsurerLabel(opportunity?.opportunity_data?.previous_insurer)),
    },
    {
      label: 'Renewal Date',
      value: formatWorkflowDate(opportunity?.opportunity_data?.renewal_date ?? opportunity?.renewal_date),
    },
  ];

  return (
    <Box className="opportunity-workflow-page">
      <BackdropLoader
        loading={
          hierarchyQuery.isLoading ||
          workflowQuery.isLoading ||
          workflowStagesQuery.isLoading ||
          activityLogsQuery.isLoading
        }
      />
      <OpportunityWorkflowSummary
        client={hierarchyPayload.client}
        opportunity={opportunity}
        currentStage={summaryOpportunityStage}
        onBack={() => navigate(encodedRoutePath('/opportunities'))}
      />
      <OpportunityStageStepper stages={stepperStages} status={opportunity?.opportunity_status} />

      {canViewDetails && (
        <Box className="opportunity-workflow-main-grid">
        <Box className="opportunity-workflow-left-rail">
          <OpportunitySideCard
            title="Assignee Details"
            rows={assigneeRows}
            editable={canAssignPlacementRm}
            onEdit={handleOpenAssignmentDialog}
          />
          <OpportunitySideCard
            title="Opportunity Details"
            rows={opportunityRows}
            editable={canEdit}
            onEdit={handleEditOpportunityForm}
          />
          <OpportunitySideCard
            title="Previous Policy Details"
            rows={previousPolicyRows}
            editable={canEdit}
            onEdit={handleEditOpportunityForm}
          />
          <OpportunitySideCard
            title={`Contacts [${opportunityContacts.length}]`}
            contacts={opportunityContacts}
            editable={canEdit}
            onEdit={handleEditPortfolioContacts}
          />
        </Box>

        {(canViewWorkflow || canViewWorkflowDetails || canViewActivityLogs) && (
          <Box className="opportunity-workflow-content-card">
            <OpportunityWorkflowTabs
              activeTab={visibleActiveTab}
              onTabChange={setActiveTab}
              showWorkflow={canViewWorkflow}
              showWorkflowDetails={canViewWorkflowDetails}
              showActivityLogs={canViewActivityLogs}
            />
            {visibleActiveTab === 'workflow' && canViewWorkflow ? (
              currentStageCode === 'OPPORTUNITY' ? (
                <Box className="opportunity-workflow-assignment-panel">
                  <Typography className="opportunity-workflow-assignment-panel-title">
                    Assign to Placement RM
                  </Typography>
                  <Typography className="opportunity-workflow-assignment-panel-text">
                    Select the Placement RM who will take this opportunity forward.
                  </Typography>
                  {canAssignPlacementRm && (
                    <Button
                      className="btn-common-red border-radius-32 opportunity-workflow-assignment-panel-btn"
                      onClick={handleOpenAssignmentDialog}
                    >
                      Assign to Placement RM
                    </Button>
                  )}
                </Box>
              ) : (
                <OpportunityWorkflowForm
                  workflowPayload={workflowPayload}
                  opportunity={opportunity}
                  canManageDelay={canManageDelay}
                  onSaved={() =>
                    Promise.all([
                      invalidateBusinessDataQueries(queryClient),
                      hierarchyQuery.refetch(),
                      workflowQuery.refetch(),
                    ])
                  }
                />
              )
            ) : null}
            {visibleActiveTab === 'activityLogs' && canViewActivityLogs ? (
              <OpportunityActivityLogs response={activityLogsQuery.data} />
            ) : null}
            {visibleActiveTab === 'workflowDetails' && canViewWorkflowDetails ? (
              <OpportunityWorkflowDetails stages={workflowStages} canViewDelay={canManageDelay} />
            ) : null}
          </Box>
        )}
        </Box>
      )}
      <OpportunityAssignmentDialog
        open={assignmentDialogOpen}
        onClose={handleCloseAssignmentDialog}
        onAssign={handleAssignPlacementRm}
        assigneeRows={assigneeRows}
        canManageDelay={canManageDelay}
      />
      <ClientSaveSuccessDialog
        open={assignmentSuccessOpen}
        title="Placement RM Assigned Successfully!"
        message="The opportunity assignment has been updated successfully."
        primaryLabel="View Opportunity"
        showSecondary={false}
        onViewProfile={handleCloseAssignmentSuccess}
      />
    </Box>
  );
}
