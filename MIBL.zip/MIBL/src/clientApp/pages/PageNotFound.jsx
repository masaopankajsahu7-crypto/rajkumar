import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import SearchOffRoundedIcon from '@mui/icons-material/SearchOffRounded';
import { Box, Button, Paper, Typography } from '@mui/material';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { encodedRoutePath } from '../config/routes.js';
import logo from '../assets/images/logo.svg';
import './PageNotFound.css';

const PageNotFound = () => {
  const navigate = useNavigate();
  const loggedIn = useSelector((state) => state.user.loggedIn);

  const handleHomepage = () => {
    navigate(loggedIn ? encodedRoutePath('/dashboard') : '/', { replace: true });
  };

  return (
    <Box className="page-not-found">
      <Box className="page-not-found__shell">
        <Box className="page-not-found__brand">
          <img src={logo} alt="Mahindra Insurance Brokers" className="page-not-found__logo" />
        </Box>

        <Paper className="page-not-found__card" elevation={0}>
          <Box className="page-not-found__visual" aria-hidden="true">
            <Box className="page-not-found__pulse" />
            <SearchOffRoundedIcon className="page-not-found__icon" />
          </Box>

          <Typography className="page-not-found__eyebrow">404</Typography>
          <Typography component="h1" className="page-not-found__title">
            Page Not Found
          </Typography>
          <Typography className="page-not-found__copy">
            This link is unavailable or contains restricted characters. Please return to a safe page and continue.
          </Typography>

          <Box className="page-not-found__actions">
            <Button className="page-not-found__primary" onClick={handleHomepage}>
              <HomeRoundedIcon fontSize="small" />
              Homepage
            </Button>
          </Box>
        </Paper>
      </Box>
    </Box>
  );
};

export default PageNotFound;
