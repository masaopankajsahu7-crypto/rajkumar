import { useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import {
  Box,
  Button,
  FormControl,
  IconButton,
  MenuItem,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import DownloadOutlinedIcon from '@mui/icons-material/DownloadOutlined';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import TrendingUpRoundedIcon from '@mui/icons-material/TrendingUpRounded';
import TimelineRoundedIcon from '@mui/icons-material/TimelineRounded';
import SpeedRoundedIcon from '@mui/icons-material/SpeedRounded';
import CurrencyRupeeRoundedIcon from '@mui/icons-material/CurrencyRupeeRounded';
import { toast } from 'react-toastify';
import { useOpportunityDashboardSection } from '../hooks/useFetchQueries.js';
import './KpiDashboard.css';

const RANGE_OPTIONS = [
  { code: 'today30', label: 'Today (+/-30 Days)' },
  { code: 'currentMonth', label: 'Current Month' },
  { code: 'previousMonth', label: 'Previous Month' },
  { code: 'last3Months', label: 'Last 3 Months' },
  { code: 'nextMonth', label: 'Next Month' },
  { code: 'next3Months', label: 'Next 3 Months' },
];

const DIMENSIONS = [
  { code: 'placement_rm', label: 'Placement RM', keys: ['placement_rm_name', 'placement_rm', 'placementRmName'] },
  { code: 'sales_rm', label: 'Sales RM', keys: ['sales_rm_name', 'primary_owner_name', 'owner_name', 'salesRmName'] },
  { code: 'branch', label: 'Branch', keys: ['branch', 'branch_name', 'rm_location'] },
  { code: 'client', label: 'Client', keys: ['client_name', 'cust_name', 'customer_name'] },
  { code: 'product', label: 'Product', keys: ['product_name', 'product', 'opportunity_product'] },
];

const SLA_FIELDS = [
  { key: 'qcr_sla_compliance', label: 'QCR' },
  { key: 'rfq_sla_compliance', label: 'RFQ' },
  { key: 'review_sla_compliance', label: 'Customer Review' },
  { key: 'policy_sla_compliance', label: 'Policy Issued' },
];

const numberFmt = new Intl.NumberFormat('en-IN');
const moneyFmt = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });
const dateFmt = new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

const pad = (value) => String(value).padStart(2, '0');
const inputDate = (date) => `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
const startOfMonth = (date) => new Date(date.getFullYear(), date.getMonth(), 1);
const endOfMonth = (date) => new Date(date.getFullYear(), date.getMonth() + 1, 0);
const addDays = (date, days) => {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
};

const getDateRange = (rangeCode) => {
  const today = new Date();
  switch (rangeCode) {
    case 'currentMonth':
      return { fromDate: inputDate(startOfMonth(today)), toDate: inputDate(endOfMonth(today)) };
    case 'previousMonth': {
      const previous = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      return { fromDate: inputDate(startOfMonth(previous)), toDate: inputDate(endOfMonth(previous)) };
    }
    case 'last3Months': {
      const from = new Date(today.getFullYear(), today.getMonth() - 2, 1);
      return { fromDate: inputDate(startOfMonth(from)), toDate: inputDate(endOfMonth(today)) };
    }
    case 'nextMonth': {
      const next = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      return { fromDate: inputDate(startOfMonth(next)), toDate: inputDate(endOfMonth(next)) };
    }
    case 'next3Months': {
      const from = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 3, 1);
      return { fromDate: inputDate(startOfMonth(from)), toDate: inputDate(endOfMonth(to)) };
    }
    case 'today30':
    default:
      return { fromDate: inputDate(addDays(today, -30)), toDate: inputDate(addDays(today, 30)) };
  }
};

const num = (value) => numberFmt.format(Number(value || 0));
const money = (value) => moneyFmt.format(Number(value || 0));
const shortMoney = (value) => {
  const amount = Number(value || 0);
  const absolute = Math.abs(amount);
  if (absolute >= 1e7) return `INR ${(amount / 1e7).toFixed(2)} Cr`;
  if (absolute >= 1e5) return `INR ${(amount / 1e5).toFixed(2)} L`;
  if (absolute >= 1e3) return `INR ${(amount / 1e3).toFixed(1)} K`;
  return money(amount);
};
const showDate = (value) => (value ? dateFmt.format(new Date(String(value).replace(' ', 'T'))) : '--');
const humanize = (value) => String(value ?? '').replaceAll('_', ' ').replace(/\b\w/g, (char) => char.toUpperCase());
const normalizeStatus = (value) => String(value ?? '').trim().replace(/\s+/g, ' ') || 'Unspecified';
const isObject = (value) => value && typeof value === 'object' && !Array.isArray(value);

const flattenRecords = (value) => {
  if (Array.isArray(value)) return value.filter(isObject);
  if (!isObject(value)) return [];

  return Object.values(value).flatMap((child) => {
    if (Array.isArray(child)) return child.filter(isObject);
    if (isObject(child)) return flattenRecords(child);
    return [];
  });
};

const readFirst = (row, keys) => {
  for (const key of keys) {
    const value = row?.[key];
    if (value !== undefined && value !== null && String(value).trim() !== '') return value;
  }
  return '';
};

const readCount = (row) => Number(readFirst(row, ['count', 'total_count', 'total', 'value', 'opportunity_count']) || 0);

const toTiles = (source, fallbackRecords, labelKeys, countKeys = ['count', 'total_count', 'total', 'value']) => {
  if (Array.isArray(source)) {
    return source.map((row) => ({
      label: normalizeStatus(readFirst(row, labelKeys)),
      count: Number(readFirst(row, countKeys) || 0),
    })).filter((item) => item.label || item.count);
  }

  if (isObject(source)) {
    return Object.entries(source).map(([label, count]) => ({
      label: normalizeStatus(label),
      count: Number(isObject(count) ? readCount(count) : count || 0),
    })).filter((item) => item.label || item.count);
  }

  const totals = new Map();
  fallbackRecords.forEach((row) => {
    const label = normalizeStatus(readFirst(row, labelKeys));
    totals.set(label, (totals.get(label) || 0) + 1);
  });
  return [...totals.entries()].map(([label, count]) => ({ label, count }));
};

const countSla = (records, field) => {
  const counts = { within: 0, breached: 0 };
  records.forEach((row) => {
    const value = String(row?.[field] ?? '').toUpperCase();
    if (value === 'WITHIN_TAT') counts.within += 1;
    if (value === 'BREACHED' || value === 'BREACH') counts.breached += 1;
  });
  return counts;
};

const BarRow = ({ label, attention, work, max }) => (
  <Box className="kpi-bar-row">
    <Typography className="kpi-bar-label" title={label}>{label}</Typography>
    <Box className="kpi-bar-pair">
      <Box className="kpi-bar-line">
        <span className="kpi-bar-track"><span className="kpi-bar-fill kpi-bar-fill--attention" style={{ width: `${max ? (attention / max) * 100 : 0}%` }} /></span>
        <span className="kpi-bar-value">{num(attention)}</span>
      </Box>
      <Box className="kpi-bar-line">
        <span className="kpi-bar-track"><span className="kpi-bar-fill kpi-bar-fill--work" style={{ width: `${max ? (work / max) * 100 : 0}%` }} /></span>
        <span className="kpi-bar-value">{num(work)}</span>
      </Box>
    </Box>
  </Box>
);

const getDimensionLabel = (row, dimension) => normalizeStatus(readFirst(row, dimension.keys));

const normalizePerformancePayload = (input) => {
  const payload = input?.payload ?? input ?? {};
  const records = flattenRecords(payload.records ?? payload.data ?? payload.opportunities ?? payload.performance_data ?? payload);
  const statusSource = payload.opportunity_status ?? payload.opportunity_status_count ?? payload.status_count ?? payload.status;
  const stageSource = payload.opportunity_stage ?? payload.opportunity_stage_count ?? payload.stage_count ?? payload.stages;

  return {
    filters: payload.filters ?? {},
    asOf: payload.as_of ?? payload.asOf ?? '',
    records,
    statusTiles: toTiles(statusSource, records, ['opportunity_status', 'opportunity_status_code', 'status', 'status_name']),
    stageTiles: toTiles(stageSource, records, ['opportunity_stage', 'opportunity_stage_code', 'stage', 'stage_name']),
  };
};

const summarizeByDimension = (records, dimension) => {
  const grouped = new Map();

  records.forEach((row) => {
    const key = getDimensionLabel(row, dimension);
    const current = grouped.get(key) ?? {
      label: key,
      total: 0,
      breached: 0,
      netPremium: 0,
      brokerage: 0,
      statuses: new Map(),
    };
    const status = normalizeStatus(readFirst(row, ['opportunity_status', 'opportunity_status_code', 'status', 'status_name']));
    current.total += 1;
    current.breached += Number(row?.breached ?? row?.is_breached ?? row?.is_attention ?? 0) === 1 ? 1 : 0;
    current.netPremium += Number(readFirst(row, ['net_premium', 'net_premium_amount', 'expected_premium', 'premium']) || 0);
    current.brokerage += Number(readFirst(row, ['brokerage_amount', 'total_brokerage_amount', 'brokerage']) || 0);
    current.statuses.set(status, (current.statuses.get(status) || 0) + 1);
    grouped.set(key, current);
  });

  return [...grouped.values()].sort((a, b) => b.total - a.total);
};

const makeSheet = (rows) => {
  const safeRows = rows.length ? rows : [{ Message: 'No records available' }];
  return XLSX.utils.json_to_sheet(safeRows);
};

const flattenForExcel = (row, prefix = '') => {
  if (!isObject(row)) return { [prefix || 'Value']: row ?? '' };

  return Object.entries(row).reduce((acc, [key, value]) => {
    const nextKey = prefix ? `${prefix}.${key}` : key;
    if (Array.isArray(value)) {
      acc[nextKey] = JSON.stringify(value);
      return acc;
    }
    if (isObject(value)) {
      return { ...acc, ...flattenForExcel(value, nextKey) };
    }
    acc[nextKey] = value ?? '';
    return acc;
  }, {});
};

const exportPerformanceWorkbook = ({ payload, statusTiles, stageTiles, slaTiles, dimensionRows, dimension }) => {
  const workbook = XLSX.utils.book_new();
  const exportedAt = new Date();
  const rawRows = payload.records.length
    ? payload.records.map((row) => flattenForExcel(row))
    : [flattenForExcel(payload)];

  XLSX.utils.book_append_sheet(workbook, makeSheet(statusTiles.map((row) => ({ Status: row.label, Count: row.count }))), 'Opportunity Status');
  XLSX.utils.book_append_sheet(workbook, makeSheet(stageTiles.map((row) => ({ Stage: row.label, Count: row.count }))), 'Opportunity Stages');
  XLSX.utils.book_append_sheet(workbook, makeSheet(slaTiles.map((row) => ({ SLA: row.label, Within_TAT: row.within, Breached: row.breached }))), 'SLA Compliance');
  XLSX.utils.book_append_sheet(workbook, makeSheet(dimensionRows.map((row) => ({
    [dimension.label]: row.label,
    Total_Opportunities: row.total,
    Breached_Count: row.breached,
    Net_Premium_Amount: row.netPremium,
    Brokerage_Amount: row.brokerage,
    Status_Count: [...row.statuses.entries()].map(([key, value]) => `${key}: ${value}`).join(', '),
  }))), 'Performance Data');
  XLSX.utils.book_append_sheet(workbook, makeSheet(rawRows), 'Raw Data');
  XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([
    ['Report Note'],
    [`Export date and time: ${exportedAt.toLocaleString('en-IN')}`],
    ['Export source: Opportunity dashboard API dashboard_name=performance'],
    [`Period: ${payload.filters?.from_date || ''} to ${payload.filters?.to_date || ''}`],
    [`API as of: ${payload.asOf || ''}`],
  ]), 'Report Notes');
  XLSX.writeFile(workbook, `performance-dashboard-${exportedAt.toISOString().slice(0, 10)}.xlsx`, { compression: true });
};

const MetricTile = ({ icon: Icon, label, value, tone = 'default' }) => (
  <Box className={`kpi-domain-card performance-tile performance-tile--${tone}`}>
    <span className="kpi-domain-head">
      <span className="kpi-domain-icon"><Icon fontSize="inherit" /></span>
      <span className="kpi-domain-name">{label}</span>
    </span>
    <span className="kpi-domain-values">
      <span><small>Total Count</small><strong>{num(value)}</strong></span>
    </span>
  </Box>
);

const PerformanceDashboard = () => {
  const detailSectionRef = useRef(null);
  const [rangeCode, setRangeCode] = useState('today30');
  const [dimensionCode, setDimensionCode] = useState('placement_rm');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const dateFilters = useMemo(() => getDateRange(rangeCode), [rangeCode]);
  const performanceQuery = useOpportunityDashboardSection('performance', dateFilters);
  const payload = useMemo(() => normalizePerformancePayload(performanceQuery.data), [performanceQuery.data]);
  const dimension = DIMENSIONS.find((item) => item.code === dimensionCode) ?? DIMENSIONS[0];
  const slaTiles = useMemo(() => SLA_FIELDS.map((field) => ({
    ...field,
    ...countSla(payload.records, field.key),
  })), [payload.records]);
  const dimensionRows = useMemo(() => summarizeByDimension(payload.records, dimension), [payload.records, dimension]);
  const filteredRows = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return dimensionRows;
    return dimensionRows.filter((row) => row.label.toLowerCase().includes(query));
  }, [dimensionRows, search]);
  const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
  const boundedPage = Math.min(page, totalPages);
  const pageRows = filteredRows.slice((boundedPage - 1) * pageSize, boundedPage * pageSize);
  const totalOpportunities = payload.statusTiles.reduce((sum, item) => sum + Number(item.count || 0), 0) || payload.records.length;
  const totalBreached = dimensionRows.reduce((sum, row) => sum + row.breached, 0);
  const totalNetPremium = dimensionRows.reduce((sum, row) => sum + row.netPremium, 0);
  const totalBrokerage = dimensionRows.reduce((sum, row) => sum + row.brokerage, 0);
  const statusMax = Math.max(0, ...payload.statusTiles.map((row) => row.count));
  const stageMax = Math.max(0, ...payload.stageTiles.map((row) => row.count));
  const dimensionMax = Math.max(0, ...dimensionRows.flatMap((row) => [row.total, row.breached]));

  const handleExport = () => {
    try {
      exportPerformanceWorkbook({
        payload,
        statusTiles: payload.statusTiles,
        stageTiles: payload.stageTiles,
        slaTiles,
        dimensionRows: filteredRows,
        dimension,
      });
      toast.success('Performance Excel report downloaded');
    } catch (error) {
      console.error('Performance Excel export failed:', error);
      toast.error('Performance Excel report could not be generated');
    }
  };

  return (
    <Box className="kpi-dashboard-page performance-dashboard-page">
      <Box className="kpi-dashboard-header">
        <Box>
          <Typography className="kpi-dashboard-title">Performance Dashboard</Typography>
          <Typography className="kpi-dashboard-subtitle">
            Opportunity performance from {showDate(payload.filters?.from_date || dateFilters.fromDate)} to {showDate(payload.filters?.to_date || dateFilters.toDate)}.
          </Typography>
        </Box>
        <Box className="kpi-dashboard-actions">
          <FormControl className="kpi-range-control kpi-action-pill" size="small">
            <Select
              value={rangeCode}
              renderValue={() => `${showDate(payload.filters?.from_date || dateFilters.fromDate)} - ${showDate(payload.filters?.to_date || dateFilters.toDate)}`}
              onChange={(event) => setRangeCode(event.target.value)}
            >
              {RANGE_OPTIONS.map((option) => <MenuItem key={option.code} value={option.code}>{option.label}</MenuItem>)}
            </Select>
          </FormControl>
          <Tooltip title="Refresh dashboard" slotProps={{ tooltip: { className: 'kpi-light-tooltip' } }}>
            <span>
              <IconButton className="kpi-icon-btn" onClick={() => performanceQuery.refetch()} disabled={performanceQuery.isFetching} aria-label="Refresh Performance dashboard">
                <RefreshRoundedIcon fontSize="small" />
              </IconButton>
            </span>
          </Tooltip>
          <Button className="kpi-download-btn" startIcon={<DownloadOutlinedIcon />} onClick={handleExport} disabled={!performanceQuery.data}>Download</Button>
        </Box>
      </Box>

      <Box className="kpi-section-row">
        <Typography className="kpi-section-label">Performance Overview</Typography>
        <Typography className="kpi-section-hint">Opportunity status, stage and SLA movement</Typography>
      </Box>
      <Box className="kpi-comparison-grid">
        <MetricTile icon={TrendingUpRoundedIcon} label="Total Opportunities" value={totalOpportunities} tone="status" />
        <MetricTile icon={SpeedRoundedIcon} label="Breached Opportunities" value={totalBreached} tone="sla" />
        <Box className="kpi-domain-card performance-tile performance-tile--finance">
          <span className="kpi-domain-head">
            <span className="kpi-domain-icon"><CurrencyRupeeRoundedIcon fontSize="inherit" /></span>
            <span className="kpi-domain-name">Net Premium</span>
          </span>
          <span className="kpi-domain-values">
            <span><small>Total Value</small><strong>{shortMoney(totalNetPremium)}</strong></span>
          </span>
          <span className="kpi-domain-note">Brokerage {shortMoney(totalBrokerage)}</span>
        </Box>
        <Box className="kpi-domain-card performance-tile performance-tile--finance">
          <span className="kpi-domain-head">
            <span className="kpi-domain-icon"><CurrencyRupeeRoundedIcon fontSize="inherit" /></span>
            <span className="kpi-domain-name">Brokerage Amount</span>
          </span>
          <span className="kpi-domain-values">
            <span><small>Total Value</small><strong>{shortMoney(totalBrokerage)}</strong></span>
          </span>
          <span className="kpi-domain-note">Across selected period</span>
        </Box>
      </Box>

      <Box className="kpi-financial-grid">
        <Box className="kpi-panel kpi-financial-card kpi-financial-card--opportunities">
          <Box className="kpi-financial-title">
            <span className="kpi-financial-icon"><TrendingUpRoundedIcon fontSize="inherit" /></span>
            <span><strong>Opportunity Status</strong><small>Open, In Progress, Won and other statuses</small></span>
          </Box>
          <Box className="kpi-financial-scope">
            <small>Total Status Count</small>
            <strong>{num(totalOpportunities)}</strong>
            <span>{num(payload.statusTiles.length)} statuses tracked</span>
          </Box>
          <Box className="kpi-financial-scope">
            <small>Breached Count</small>
            <strong>{num(totalBreached)}</strong>
            <span>Flag based opportunity breaches</span>
          </Box>
        </Box>
        <Box className="kpi-panel kpi-financial-card kpi-financial-card--renewals">
          <Box className="kpi-financial-title">
            <span className="kpi-financial-icon"><CurrencyRupeeRoundedIcon fontSize="inherit" /></span>
            <span><strong>Opportunity Financials</strong><small>Net premium and brokerage amount</small></span>
          </Box>
          <Box className="kpi-financial-scope">
            <small>Net Premium</small>
            <strong>{shortMoney(totalNetPremium)}</strong>
            <span>{money(totalNetPremium)}</span>
          </Box>
          <Box className="kpi-financial-scope">
            <small>Brokerage</small>
            <strong>{shortMoney(totalBrokerage)}</strong>
            <span>{money(totalBrokerage)}</span>
          </Box>
        </Box>
      </Box>

      <Box className="kpi-graphs-grid">
        <Box className="kpi-panel">
          <Box className="kpi-panel-head">
            <Box>
              <Typography className="kpi-panel-title">Opportunity Status</Typography>
              <Typography className="kpi-panel-subtitle">Status-wise opportunity count</Typography>
            </Box>
            <Box className="kpi-legend"><span><i className="kpi-dot kpi-dot--attention" />Count</span></Box>
          </Box>
          <Box className="kpi-bar-chart">
            {payload.statusTiles.length ? payload.statusTiles.map((row) => (
              <BarRow key={row.label} label={humanize(row.label)} attention={row.count} work={0} max={statusMax} />
            )) : <Box className="kpi-empty">No opportunity status data available.</Box>}
          </Box>
        </Box>
        <Box className="kpi-panel">
          <Box className="kpi-panel-head">
            <Box>
              <Typography className="kpi-panel-title">Opportunity Stages</Typography>
              <Typography className="kpi-panel-subtitle">Stage-wise opportunity count</Typography>
            </Box>
            <Box className="kpi-legend"><span><i className="kpi-dot kpi-dot--work" />Count</span></Box>
          </Box>
          <Box className="kpi-bar-chart">
            {payload.stageTiles.length ? payload.stageTiles.map((row) => (
              <BarRow key={row.label} label={humanize(row.label)} attention={0} work={row.count} max={stageMax} />
            )) : <Box className="kpi-empty">No opportunity stage data available.</Box>}
          </Box>
        </Box>
      </Box>

      <Box className="kpi-panel">
        <Box className="kpi-panel-head">
          <Box>
            <Typography className="kpi-panel-title">SLA Compliance</Typography>
            <Typography className="kpi-panel-subtitle">Within TAT compared with breached items</Typography>
          </Box>
          <Box className="kpi-legend"><span><i className="kpi-dot kpi-dot--work" />Within TAT</span><span><i className="kpi-dot kpi-dot--attention" />Breached</span></Box>
        </Box>
        <Box className="kpi-comparison-grid performance-sla-grid">
          {slaTiles.map((item) => (
            <Box key={item.key} className="kpi-domain-card performance-tile performance-tile--sla">
              <span className="kpi-domain-head">
                <span className="kpi-domain-icon"><SpeedRoundedIcon fontSize="inherit" /></span>
                <span className="kpi-domain-name">{item.label}</span>
              </span>
              <span className="kpi-domain-values">
                <span><small>Within TAT</small><strong>{num(item.within)}</strong></span>
                <span><small>Breached</small><strong>{num(item.breached)}</strong></span>
              </span>
            </Box>
          ))}
        </Box>
      </Box>

      <Box className="kpi-panel">
        <Box className="kpi-panel-head">
          <Box>
            <Typography className="kpi-panel-title">Performance By {dimension.label}</Typography>
            <Typography className="kpi-panel-subtitle">Total opportunities and breached count</Typography>
          </Box>
          <Box className="kpi-segment">
            {DIMENSIONS.map((item) => (
              <Button
                key={item.code}
                className={dimensionCode === item.code ? 'active' : ''}
                onClick={() => { setDimensionCode(item.code); setSearch(''); setPage(1); }}
              >
                {item.label}
              </Button>
            ))}
          </Box>
        </Box>
        <Box className="kpi-bar-chart">
          {dimensionRows.length ? dimensionRows.slice(0, 8).map((row) => (
            <BarRow key={row.label} label={row.label} attention={row.breached} work={row.total} max={dimensionMax} />
          )) : <Box className="kpi-empty">No dimension summary available.</Box>}
        </Box>
      </Box>

      <Box className="kpi-panel" ref={detailSectionRef} tabIndex={-1}>
        <Box className="kpi-detail-toolbar">
          <Box>
            <Typography className="kpi-panel-title">Performance Data</Typography>
            <Typography className="kpi-panel-subtitle">{num(filteredRows.length)} {dimension.label} records</Typography>
          </Box>
          <TextField className="kpi-search" size="small" placeholder={`Search ${dimension.label}`} value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} />
          <FormControl className="kpi-page-size" size="small">
            <Select value={pageSize} onChange={(event) => { setPageSize(Number(event.target.value)); setPage(1); }}>{[10, 25, 50].map((value) => <MenuItem key={value} value={value}>{value}</MenuItem>)}</Select>
          </FormControl>
        </Box>
        <TableContainer className="kpi-detail-table-wrap">
          <Table className="kpi-table">
            <TableHead>
              <TableRow>
                <TableCell>{dimension.label}</TableCell>
                <TableCell align="right">Total Opportunity Status Count</TableCell>
                <TableCell align="right">Breached Count</TableCell>
                <TableCell align="right">Net Premium Amount</TableCell>
                <TableCell align="right">Brokerage Amount</TableCell>
                <TableCell>Status Split</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pageRows.length ? pageRows.map((row) => (
                <TableRow key={row.label}>
                  <TableCell><span className="kpi-primary">{row.label}</span></TableCell>
                  <TableCell align="right">{num(row.total)}</TableCell>
                  <TableCell align="right">{num(row.breached)}</TableCell>
                  <TableCell align="right"><CurrencyRupeeRoundedIcon className="performance-money-icon" fontSize="inherit" /> {money(row.netPremium)}</TableCell>
                  <TableCell align="right"><CurrencyRupeeRoundedIcon className="performance-money-icon" fontSize="inherit" /> {money(row.brokerage)}</TableCell>
                  <TableCell>{[...row.statuses.entries()].map(([key, value]) => `${humanize(key)}: ${num(value)}`).join(' | ') || '--'}</TableCell>
                </TableRow>
              )) : <TableRow><TableCell colSpan={6} className="kpi-empty">No performance data available.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </TableContainer>
        <Box className="kpi-footer">
          <Typography className="kpi-footer-text">{filteredRows.length ? `Showing ${num((boundedPage - 1) * pageSize + 1)} to ${num(Math.min(boundedPage * pageSize, filteredRows.length))} of ${num(filteredRows.length)} records` : 'Showing 0 records'}</Typography>
          <Box className="kpi-pagination">
            <Button className="kpi-page-btn" disabled={boundedPage <= 1} onClick={() => setPage((value) => Math.max(1, value - 1))} aria-label="Previous page"><ChevronLeftIcon fontSize="small" /></Button>
            <Typography className="kpi-footer-text">Page {boundedPage} of {totalPages}</Typography>
            <Button className="kpi-page-btn" disabled={boundedPage >= totalPages} onClick={() => setPage((value) => value + 1)} aria-label="Next page"><ChevronRightIcon fontSize="small" /></Button>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default PerformanceDashboard;
