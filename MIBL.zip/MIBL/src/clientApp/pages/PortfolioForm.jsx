import { useEffect, useState } from 'react';
import { Box, Button, Paper, TextField, Typography } from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { useQueryClient } from '@tanstack/react-query';
import { useLocation, useNavigate } from 'react-router-dom';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import PortfolioFormFields from '../components/client/PortfolioFormFields.jsx';
import { PORTFOLIO_MESSAGES as MSG } from '../config/messages.js';
import { encodedRoutePath, ROUTES } from '../config/routes.js';
import { getCurrentUserId } from '../config/clientApiConfig.js';
import { createClientPortfolio, getClientByUuid, searchClientsByName } from '../services/api.jsx';
import { queryKeys } from '../lib/queryKeys.js';
import {
  invalidateClientQueries,
  invalidateOpportunityQueries,
  invalidatePortfolioQueries,
  STALE_TIME_MS,
} from '../lib/queryClient.js';
import { mapClientRecordToFormDraft } from '../utils/clientFormState.js';
import {
  buildInitialPortfolioFromClient,
  buildPortfolioData,
  isNewBusinessType,
  mergePortfolioWithClientDraft,
} from '../utils/portfolioFormState.js';
import { validatePortfolioForm } from '../utils/portfolioFormValidation.js';
import './ClientsForm.css';

const normalizeOwners = (owners = []) =>
  (Array.isArray(owners) ? owners : [])
    .map((owner) => ({
      owner_id: owner?.owner_id ?? owner?.ownerId ?? owner?.id,
      owner_type_code: owner?.owner_type_code ?? owner?.ownerTypeCode ?? owner?.type,
    }))
    .filter((owner) => owner.owner_id && owner.owner_type_code);

const getClientOwners = (client = {}) => {
  const payload = client?.payload ?? client;
  return normalizeOwners(
    payload?.owners ??
      payload?.client?.owners ??
      client?.owners ??
      client?.accountOwner?.owners ??
      [],
  );
};

const getPortfolioUuid = (portfolio = {}) =>
  portfolio?.portfolio_uuid ??
  portfolio?.portfolio_UUID ??
  portfolio?.portfolioUUID ??
  portfolio?.uuid ??
  '';

const CONTACT_ONLY_LOCKED_FIELDS = [
  'product',
  'sub_product',
  'business_type',
  'policy_start_date',
  'policy_expiry_date',
  'previous_insurer',
  'previous_policy_number',
  'sum_insured',
  'expected_premium',
  'brokerage_consultancy',
  'renewal_date',
];

const normalizePortfolioForForm = (portfolio = {}) => {
  const data = portfolio?.portfolio_data ?? portfolio?.opportunity_data ?? {};
  return {
    ...data,
    ...portfolio,
    product:
      portfolio?.product ??
      portfolio?.portfolio_product_code ??
      data?.product ??
      data?.product_code ??
      '',
    sub_product:
      portfolio?.sub_product ??
      portfolio?.portfolio_sub_product_code ??
      data?.sub_product ??
      '',
    business_type:
      portfolio?.business_type ??
      portfolio?.portfolio_type_code ??
      data?.business_type ??
      data?.biz_type ??
      '',
    brokerage_consultancy:
      portfolio?.brokerage_consultancy ??
      data?.brokerage_percentage ??
      data?.brokerage_consultancy ??
      data?.brokerage ??
      '',
    contact: portfolio?.contacts ?? data?.contact ?? portfolio?.contact ?? [],
    previous_insurer: data?.previous_insurer ?? data?.previous_insuere ?? portfolio?.previous_insurer ?? '',
    previous_policy_number: data?.previous_policy_number ?? portfolio?.previous_policy_number ?? '',
    policy_start_date: data?.policy_start_date ?? portfolio?.policy_start_date ?? '',
    policy_expiry_date: data?.policy_expiry_date ?? portfolio?.policy_expiry_date ?? '',
    sum_insured: data?.sum_insured ?? portfolio?.sum_insured ?? '',
    expected_premium: portfolio?.expected_premium ?? data?.expected_premium ?? '',
    renewal_date: portfolio?.renewal_date ?? data?.renewal_date ?? '',
  };
};

const PortfolioForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();
  const routeClientDraft = location.state?.clientDraft;
  const fromClientList = Boolean(location.state?.fromClientList);
  const contactOnlyFromOpportunity = Boolean(location.state?.contactOnlyFromOpportunity);
  const portfolioIndex = location.state?.portfolioIndex;
  const routeSelectedPortfolio = location.state?.selectedPortfolio;
  const activeMenu = location.state?.activeMenu;
  const returnPath =
    location.state?.returnPath ??
    encodedRoutePath(fromClientList ? ROUTES.clients : ROUTES.clientsCreate);
  const [selectedClientDraft, setSelectedClientDraft] = useState(null);
  const [clientSearchText, setClientSearchText] = useState('');
  const [clientSearchResults, setClientSearchResults] = useState([]);
  const [clientSearching, setClientSearching] = useState(false);
  const [clientSuggestionsOpen, setClientSuggestionsOpen] = useState(false);
  const clientDraft = selectedClientDraft ?? routeClientDraft;
  const existingPortfolios = clientDraft?.portfolios ?? location.state?.portfolios ?? [];
  const selectedPortfolioForForm = contactOnlyFromOpportunity
    ? normalizePortfolioForForm(routeSelectedPortfolio ?? existingPortfolios[portfolioIndex ?? 0])
    : portfolioIndex != null
      ? existingPortfolios[portfolioIndex]
      : null;
  const sourcePortfolio = routeSelectedPortfolio ?? existingPortfolios[portfolioIndex ?? 0] ?? {};

  const [portfolio, setPortfolio] = useState(() =>
    buildInitialPortfolioFromClient(clientDraft, selectedPortfolioForForm),
  );
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);
  const [clientOwners, setClientOwners] = useState(() =>
    contactOnlyFromOpportunity
      ? normalizeOwners(routeSelectedPortfolio?.owners)
      : getClientOwners(routeClientDraft),
  );

  useEffect(() => {
    if (clientDraft || clientSearchText.trim().length < 2) {
      setClientSearchResults([]);
      setClientSearching(false);
      return undefined;
    }

    let cancelled = false;
    setClientSearching(true);
    const timer = window.setTimeout(async () => {
      const results = await searchClientsByName(clientSearchText, { source: 'client' });
      if (cancelled) return;
      setClientSearchResults(results);
      setClientSearching(false);
      setClientSuggestionsOpen(true);
    }, 300);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [clientDraft, clientSearchText]);

  useEffect(() => {
    if (!fromClientList || !clientDraft?.clientUUID) return;

    let cancelled = false;

    const loadClientContact = async () => {
      const client = await queryClient.fetchQuery({
        queryKey: queryKeys.client(clientDraft.clientUUID),
        queryFn: () => getClientByUuid(clientDraft.clientUUID),
        staleTime: STALE_TIME_MS,
      });
      if (cancelled || !client) return;

      const record = mapClientRecordToFormDraft(client);
      if (!record) return;

      if (!contactOnlyFromOpportunity) {
        setClientOwners(getClientOwners(client));
      }

      setPortfolio((prev) =>
        mergePortfolioWithClientDraft(prev, {
          ...clientDraft,
          ...record,
          communication: {
            ...clientDraft.communication,
            ...record.communication,
          },
          accountOwner: client.accountOwner ?? record.accountOwner ?? clientDraft.accountOwner,
        }),
      );
    };

    loadClientContact();
    return () => {
      cancelled = true;
    };
  }, [contactOnlyFromOpportunity, fromClientList, clientDraft?.clientUUID]);

  const handleBack = () => {
    navigate(returnPath, activeMenu ? { state: { activeMenu } } : undefined);
  };

  const handleGoToClientForm = () => {
    navigate(returnPath, activeMenu ? { state: { activeMenu } } : undefined);
  };

  const handleStandaloneClientSelect = async (option) => {
    setClientSearchText(option.clientName);
    setClientSuggestionsOpen(false);
    setClientSearchResults([]);
    setClientSearching(true);
    setSaveError('');

    try {
      const client = await queryClient.fetchQuery({
        queryKey: queryKeys.client(option.clientUUID),
        queryFn: () => getClientByUuid(option.clientUUID),
        staleTime: STALE_TIME_MS,
      });
      const record = mapClientRecordToFormDraft(client);
      const draft = record ?? {
        clientUUID: option.clientUUID,
        basicDetails: { client_name: option.clientName },
        communication: {},
        accountOwner: {},
        portfolios: [],
      };

      setSelectedClientDraft(draft);
      setClientOwners(getClientOwners(client));
      setPortfolio((prev) => mergePortfolioWithClientDraft(prev, draft));
    } catch (error) {
      setSelectedClientDraft({
        clientUUID: option.clientUUID,
        basicDetails: { client_name: option.clientName },
        communication: {},
        accountOwner: {},
        portfolios: [],
      });
      setClientOwners([]);
    } finally {
      setClientSearching(false);
    }
  };

  if (!clientDraft) {
    return (
      <Box className="client-form-page">
        <Paper className="client-form-paper table-auto-width">
          <Box className="client-form-body">
            <Box className="client-form-header">
              <Typography className="georama-SemiBold fs-24 client-form-title">
                {MSG.addTitle}
              </Typography>
              <Button
                className="text-capitalize georama-medium-selected custom-starticon client-form-back-btn"
                startIcon={<ChevronLeftIcon />}
                onClick={handleGoToClientForm}
              >
                {MSG.back}
              </Button>
            </Box>
            <Box className="client-form-header-divider" />

            <Box className="client-form-wizard portfolio-client-selection-wizard">
              <Box className="client-form-step-panel">
                <Box className="client-form-step-panel-head">
                  <Typography className="client-form-step-indicator georama-Regular">
                    {MSG.clientSelection.stepLabel}
                  </Typography>
                  <Typography className="client-form-step-title georama-SemiBold">
                    {MSG.clientSelection.title}
                  </Typography>
                </Box>

                <Box className="client-form-section-body client-form-section-body--panel">
                  <Box className="portfolio-client-select-card">
                    <Box className="portfolio-client-select-head">
                      <Typography className="client-form-portfolio-subsection-title georama-SemiBold">
                        {MSG.clientSelection.sectionTitle}
                      </Typography>
                      <Typography className="portfolio-client-select-hint georama-Regular">
                        {MSG.clientSelection.hint}
                      </Typography>
                    </Box>
                    <Box className="portfolio-client-search-wrap">
                      <Typography className="text-labels georama-Regular">
                        {MSG.clientSelection.clientNameLabel} <span>*</span>
                      </Typography>
                      <TextField
                        className="form-control-input portfolio-client-search-input"
                        fullWidth
                        size="small"
                        placeholder={MSG.clientSelection.placeholder}
                        value={clientSearchText}
                        onChange={(event) => {
                          setClientSearchText(event.target.value);
                          setClientSuggestionsOpen(true);
                        }}
                        onFocus={() => setClientSuggestionsOpen(true)}
                      />
                      {clientSuggestionsOpen && clientSearchText.trim().length >= 2 && (
                        <Box className="portfolio-client-search-results" role="listbox">
                          <Box className="portfolio-client-search-results-head">
                            <Typography className="portfolio-client-search-results-title georama-Medium">
                              {MSG.clientSelection.resultsTitle}
                            </Typography>
                            <Typography className="portfolio-client-search-results-subtitle georama-Regular">
                              {MSG.clientSelection.resultsSubtitle}
                            </Typography>
                          </Box>
                          {clientSearching ? (
                            <Typography className="portfolio-client-search-note georama-Regular">
                              {MSG.clientSelection.searching}
                            </Typography>
                          ) : null}
                          {!clientSearching && clientSearchResults.map((option) => (
                            <Button
                              key={option.clientUUID}
                              className="portfolio-client-search-result"
                              role="option"
                              onClick={() => handleStandaloneClientSelect(option)}
                            >
                              <Box className="portfolio-client-search-result-content">
                                <Typography className="portfolio-client-search-name georama-Medium">
                                  {option.clientName}
                                </Typography>
                                {option.owner ? (
                                  <Typography className="portfolio-client-search-owner georama-Regular">
                                    {MSG.clientSelection.ownerPrefix}: {option.owner}
                                  </Typography>
                                ) : null}
                                {option.city ? (
                                  <Typography className="portfolio-client-search-city georama-Regular">
                                    {option.city}
                                  </Typography>
                                ) : null}
                              </Box>
                              <ChevronRightIcon className="portfolio-client-search-arrow" fontSize="small" />
                            </Button>
                          ))}
                          {!clientSearching && clientSearchResults.length === 0 ? (
                            <Typography className="portfolio-client-search-note georama-Regular">
                              {MSG.clientSelection.noResults}
                            </Typography>
                          ) : null}
                        </Box>
                      )}
                    </Box>
                  </Box>
                </Box>
              </Box>
            </Box>
          </Box>
        </Paper>
      </Box>
    );
  }

  const clientName =
    clientDraft.basicDetails?.client_name?.trim() ||
    clientDraft.client?.client_name?.trim() ||
    MSG.unnamedClient;

  const handlePortfolioChange = (field, value) => {
    setPortfolio((prev) => {
      const next = { ...prev, [field]: value };
      if (field === 'business_type' && isNewBusinessType(value)) {
        next.policy_start_date = '';
        next.policy_expiry_date = '';
        next.previous_insurer = '';
        next.previous_policy_number = '';
      }
      return next;
    });
    setErrors((prev) => {
      const next = { ...prev };
      if (next[field]) delete next[field];
      if (field === 'business_type' && isNewBusinessType(value)) {
        ['policy_start_date', 'policy_expiry_date', 'previous_insurer', 'previous_policy_number'].forEach(
          (policyField) => {
            if (next[policyField]) delete next[policyField];
          },
        );
      }
      if (field === 'other_contacts') {
        Object.keys(next).forEach((key) => {
          if (key.startsWith('other_contact_')) delete next[key];
        });
      }
      return next;
    });
    setSaveError('');
  };

  const handleSaveAndBack = () => {
    const nextErrors = validatePortfolioForm(portfolio);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const updatedPortfolios = [...existingPortfolios];
    const portfolioData = buildPortfolioData(portfolio);
    if (portfolioIndex != null) {
      updatedPortfolios[portfolioIndex] = portfolioData;
    } else {
      updatedPortfolios.push(portfolioData);
    }

    navigate(returnPath, {
      state: {
        clientDraft: {
          ...clientDraft,
          portfolios: updatedPortfolios,
        },
        focusPortfolio: true,
        returnPath,
        activeMenu,
      },
    });
  };

  const validatePortfolioForSubmit = () => {
    if (!contactOnlyFromOpportunity) return validatePortfolioForm(portfolio);

    const fullErrors = validatePortfolioForm(portfolio);
    return Object.fromEntries(
      Object.entries(fullErrors).filter(([key]) =>
        [
          'primary_contact_person',
          'primary_contact_mobile',
          'primary_contact_email',
        ].includes(key) || key.startsWith('other_contact_'),
      ),
    );
  };

  const handleSubmitFromList = async () => {
    const nextErrors = validatePortfolioForSubmit();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const clientUUID = clientDraft.clientUUID;
    const portfolioData = buildPortfolioData(portfolio);
    const userId = getCurrentUserId();
    const expectedPremium = Number(portfolioData.expected_premium) || 0;
    const brokeragePercentage = Number(portfolioData.brokerage_consultancy) || 0;
    const brokerageFee = Number(((expectedPremium * brokeragePercentage) / 100).toFixed(2));
    const contacts = [
      {
        name: portfolioData.primary_contact_person,
        email: portfolioData.primary_contact_email,
        mobile: portfolioData.primary_contact_mobile,
      },
      ...(portfolioData.other_contacts ?? []),
    ].filter((contact) => contact.name || contact.email || contact.mobile);

    const owners = contactOnlyFromOpportunity
      ? normalizeOwners(sourcePortfolio?.owners)
      : clientOwners;

    const body = {
      userid: userId,
      message: 'Creating a new corporate portfolio',
      payload: {
        portfolio: {
          ...(contactOnlyFromOpportunity
            ? { portfolio_uuid: getPortfolioUuid(sourcePortfolio) }
            : {}),
          client_uuid: clientUUID,
          portfolio_type_code: portfolioData.business_type,
          portfolio_product_code: portfolioData.product,
          portfolio_sub_product_code: portfolioData.sub_product,
          expected_premium: expectedPremium,
          brokerage_fee: brokerageFee,
          reward_fee: 0,
          renewal_date: portfolioData.renewal_date,
        },
        portfolio_data: {
          risk_profile: '',
          previous_insuere: portfolioData.previous_insurer,
          previous_insurer: portfolioData.previous_insurer,
          brokerage_percentage: String(portfolioData.brokerage_consultancy ?? ''),
          reward_percentage: '',
          corporate_tier: '',
          exclusions_applied: [],
          sum_insured: portfolioData.sum_insured,
          previous_policy_number: portfolioData.previous_policy_number,
          policy_start_date: portfolioData.policy_start_date,
          policy_expiry_date: portfolioData.policy_expiry_date,
        },
        contacts,
        owners,
      },
    };

    setSubmitting(true);
    setSaveError('');
    try {
      await createClientPortfolio(body);
      await Promise.all([
        invalidateClientQueries(queryClient),
        invalidatePortfolioQueries(queryClient),
        invalidateOpportunityQueries(queryClient),
      ]);
      if (contactOnlyFromOpportunity) {
        setSuccessDialogOpen(true);
      } else {
        navigate(returnPath, activeMenu ? { state: { activeMenu } } : undefined);
      }
    } catch (error) {
      setSaveError(error?.message ?? 'Portfolio save failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSuccessReturn = () => {
    setSuccessDialogOpen(false);
    navigate(returnPath, activeMenu ? { state: { activeMenu } } : undefined);
  };

  return (
    <Box className="client-form-page">
      <BackdropLoader loading={submitting} />
      <ClientSaveSuccessDialog
        open={successDialogOpen}
        title="Contacts Updated Successfully!"
        message="The portfolio contact details have been updated."
        primaryLabel="Back to Opportunity"
        showSecondary={false}
        onViewProfile={handleSuccessReturn}
        onReturnToList={handleSuccessReturn}
      />
      <Paper className="client-form-paper table-auto-width">
        <Box className="client-form-body">
          <Box className="client-form-header">
            <Typography className="georama-SemiBold fs-24 client-form-title">
              {portfolioIndex != null ? MSG.editTitle : MSG.addTitle}
            </Typography>
            <Button
              className="text-capitalize georama-medium-selected custom-starticon client-form-back-btn"
              startIcon={<ChevronLeftIcon />}
              onClick={handleBack}
            >
              {MSG.back}
            </Button>
          </Box>
          <Box className="client-form-header-divider" />

          <Box className="client-form-wizard">
            <Box className="client-form-step-panel">
              <Box className="client-form-step-panel-head">
                <Typography className="client-form-step-indicator georama-Regular">
                  {MSG.portfolioForClientPrefix} <strong>{clientName}</strong>
                </Typography>
                <Typography className="client-form-step-title georama-SemiBold">
                  {MSG.sections.portfolio}
                </Typography>
              </Box>

              <Box className="client-form-section-body client-form-section-body--panel">
                <PortfolioFormFields
                  portfolio={portfolio}
                  errors={errors}
                  onChange={handlePortfolioChange}
                  clientDraft={clientDraft}
                  lockedFields={contactOnlyFromOpportunity ? CONTACT_ONLY_LOCKED_FIELDS : []}
                />
              </Box>

              {saveError ? (
                <Box className="client-form-save-error" role="alert">
                  <Typography className="client-form-save-error-title georama-SemiBold">
                    {saveError}
                  </Typography>
                </Box>
              ) : null}

              <Box className="client-form-step-footer">
                <Box />
                <Box className="client-form-step-footer-right">
                  {fromClientList ? (
                    <Button
                      className="btn-common-red border-radius-32 client-form-submit-btn"
                      onClick={handleSubmitFromList}
                      disabled={submitting}
                    >
                      {submitting ? MSG.submitting : MSG.submit}
                    </Button>
                  ) : (
                    <Button
                      className="btn-common-red border-radius-32 client-form-submit-btn"
                      onClick={handleSaveAndBack}
                    >
                      {MSG.saveAndBack}
                    </Button>
                  )}
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default PortfolioForm;
