import { useEffect, useMemo, useState } from 'react';
import {
  Box,
  Button,
  Chip,
  IconButton,
  InputAdornment,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import TrendingUpOutlinedIcon from '@mui/icons-material/TrendingUpOutlined';
import ManageAccountsOutlinedIcon from '@mui/icons-material/ManageAccountsOutlined';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import DateRangeFilter from '../components/common/DateRangeFilter.jsx';
import SortOrderButton from '../components/common/SortOrderButton.jsx';
import PortfolioListFilters from '../components/portfolio/PortfolioListFilters.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import ReassignOwnerDialog from '../components/client/ReassignOwnerDialog.jsx';
import { useClientByUuid, usePortfolioList } from '../hooks/useFetchQueries.js';
import { invalidateBusinessDataQueries } from '../lib/queryClient.js';
import { reassignPortfolioOwner } from '../services/api.jsx';
import { mapClientDetailFromApi } from '../utils/clientDetailMock.js';
import { sortRowsByDate } from '../utils/dateRangeFilters.js';
import { formatColumnLabel } from '../utils/labelFormat.js';
import { sanitizeByField } from '../utils/fieldUtils.js';
import { getListIsReassignFlag, isListActionAllowed } from '../utils/listPermissions.js';
import {
  getActivePortfolioFilterChips,
  hasActivePortfolioFilters,
  INITIAL_PORTFOLIO_FILTERS,
} from '../utils/portfolioListFilters.js';
import {
  PORTFOLIO_LIST_COLUMN_KEYS,
  PORTFOLIO_LIST_COLUMN_LABELS,
} from '../config/portfolioListColumns.js';
import { PORTFOLIO_LIST_MESSAGES as MSG } from '../config/messages/portfolioList.js';
import { REASSIGN_OWNER_MESSAGES } from '../config/messages/reassignOwner.js';
import { clientsDetailPath, encodedRoutePath, ROUTES } from '../config/routes.js';
import './Clients.css';
import './Opportunities.css';

const PORTFOLIO_PAGE_SIZE = 10;

const getPortfolioTotalPages = (totalCount) =>
  Math.max(Math.ceil(Number(totalCount || 0) / PORTFOLIO_PAGE_SIZE), 1);

const getPortfolioRouteLabel = (row) => {
  const readableParts = [
    row?.portfolio,
    [row?.product, row?.subProduct].filter(Boolean).join(' - '),
    [row?.raw?.portfolio_product, row?.raw?.portfolio_sub_product].filter(Boolean).join(' - '),
    [row?.raw?.product, row?.raw?.sub_product].filter(Boolean).join(' - '),
  ];

  return readableParts.map((value) => String(value ?? '').trim()).find(Boolean) ?? 'Selected portfolio';
};

const getPrimaryPortfolioOwner = (row) => {
  const owners = Array.isArray(row?.owners) ? row.owners : [];
  const primaryOwner =
    owners.find((owner) => {
      const flag = String(owner?.is_primary ?? owner?.isPrimary ?? owner?.primary ?? '').trim().toLowerCase();
      return flag === '1' || flag === 'true';
    }) ?? owners[0];

  if (primaryOwner) return primaryOwner;
  return row?.owner ? { value: row.owner, owner_name: row.owner } : '';
};

const Portfolios = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState(INITIAL_PORTFOLIO_FILTERS);
  const [appliedFilters, setAppliedFilters] = useState(INITIAL_PORTFOLIO_FILTERS);
  const [searchInput, setSearchInput] = useState('');
  const [actionMenu, setActionMenu] = useState({ anchorEl: null, row: null });
  const [reassignPortfolioRow, setReassignPortfolioRow] = useState(null);
  const [reassignSuccessOpen, setReassignSuccessOpen] = useState(false);
  const { data: portfolioListResponse, isLoading, isFetching } = usePortfolioList(page, appliedFilters);
  const reassignClientUUID = reassignPortfolioRow?.clientUUID ?? '';
  const {
    data: reassignClientResponse,
    isLoading: isReassignClientLoading,
    isFetching: isReassignClientFetching,
  } = useClientByUuid(reassignClientUUID);

  const portfolioData = portfolioListResponse?.list ?? [];
  const canShowAddPortfolio = isListActionAllowed(portfolioListResponse?.isAdd);
  const canShowReassignPortfolio = isListActionAllowed(getListIsReassignFlag(portfolioListResponse));
  const reassignClientProfile = useMemo(
    () => mapClientDetailFromApi(reassignClientResponse, reassignClientUUID, reassignPortfolioRow),
    [reassignClientResponse, reassignClientUUID, reassignPortfolioRow],
  );
  const portfolioOwnerOptions = useMemo(
    () => {
      if (!reassignClientResponse?.payload) return [];
      return [
        reassignClientProfile.primaryOwnerRecord ??
          (reassignClientProfile.primaryOwner
            ? { code: reassignPortfolioRow?.ownerId, value: reassignClientProfile.primaryOwner }
            : null),
        ...reassignClientProfile.coOwners,
      ].filter((owner) => owner?.value);
    },
    [
      reassignClientProfile.coOwners,
      reassignClientProfile.primaryOwner,
      reassignClientProfile.primaryOwnerRecord,
      reassignClientResponse?.payload,
      reassignPortfolioRow?.ownerId,
    ],
  );
  const sortedPortfolioData = useMemo(
    () => sortRowsByDate(portfolioData, (row) => row.raw?.created_on ?? row.raw?.created_at, appliedFilters.sortOrder),
    [appliedFilters.sortOrder, portfolioData],
  );
  const totalCount = portfolioListResponse?.totalCount ?? 0;
  const totalPages = useMemo(() => getPortfolioTotalPages(totalCount), [totalCount]);
  const tableHeaders = PORTFOLIO_LIST_COLUMN_KEYS;

  const paginationItems = useMemo(() => {
    if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);

    const pages = new Set([1, totalPages, page - 1, page, page + 1]);
    const visiblePages = [...pages]
      .filter((pageNumber) => pageNumber >= 1 && pageNumber <= totalPages)
      .sort((first, second) => first - second);

    return visiblePages.reduce((items, pageNumber, index) => {
      const previousPage = visiblePages[index - 1];
      if (index > 0 && pageNumber - previousPage > 1) items.push(`ellipsis-${previousPage}-${pageNumber}`);
      items.push(pageNumber);
      return items;
    }, []);
  }, [page, totalPages]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const nextSearch = searchInput.trim();
      setAppliedFilters((prev) => (prev.search === nextSearch ? prev : { ...prev, search: nextSearch }));
    }, 300);

    return () => window.clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    setPage(1);
  }, [appliedFilters]);

  const handleFilterChange = (field, value) => {
    setFilters((prev) => ({ ...prev, [field]: value }));
  };

  const handleApplyFilters = () => {
    setAppliedFilters({ ...filters, search: searchInput.trim() });
    setPage(1);
  };

  const handleToggleSortOrder = () => {
    const nextSortOrder = String(appliedFilters.sortOrder).toUpperCase() === 'ASC' ? 'DESC' : 'ASC';
    setFilters((prev) => ({ ...prev, sortOrder: nextSortOrder }));
    setAppliedFilters((prev) => ({ ...prev, sortOrder: nextSortOrder }));
    setPage(1);
  };

  const handleClearFilters = () => {
    setFilters(INITIAL_PORTFOLIO_FILTERS);
    setAppliedFilters(INITIAL_PORTFOLIO_FILTERS);
    setSearchInput('');
    setPage(1);
  };

  const handleRemoveFilterChip = (field) => {
    const nextFilters = {
      ...appliedFilters,
      [field]: '',
      ...(field === 'clientName' ? { clientUUID: '' } : {}),
      ...(field === 'owner' ? { ownerId: '' } : {}),
      ...(field === 'clientType' ? { clientTypeLabel: '' } : {}),
      ...(field === 'clientVertical' ? { clientVerticalLabel: '' } : {}),
      ...(field === 'portfolioType' ? { portfolioTypeLabel: '' } : {}),
      ...(field === 'product' ? { productLabel: '', subProduct: '', subProductLabel: '' } : {}),
      ...(field === 'subProduct' ? { subProductLabel: '' } : {}),
      ...(field === 'isActive' ? { isActiveLabel: '' } : {}),
      ...(field === 'dateRangePreset' ? { fromDate: '', toDate: '' } : {}),
    };
    setFilters(nextFilters);
    setAppliedFilters(nextFilters);
    if (field === 'search') setSearchInput('');
    setPage(1);
  };

  const handlePageChange = (nextPage) => {
    if (nextPage === page || nextPage < 1 || nextPage > totalPages) return;
    setPage(nextPage);
  };

  const handleActionMenuOpen = (row) => (event) => {
    setActionMenu({ anchorEl: event.currentTarget, row });
  };

  const handleActionMenuClose = () => {
    setActionMenu({ anchorEl: null, row: null });
  };

  const handleAddOpportunityFromList = () => {
    const row = actionMenu.row;
    handleActionMenuClose();
    if (!row) return;

    navigate(encodedRoutePath(ROUTES.opportunitiesCreate), {
      state: {
        source: 'portfolioList',
        activeMenu: 'Portfolios',
        selectedClient: {
          clientUUID: row.clientUUID ?? '',
          clientName: row.clientName ?? '',
          primaryOwner: row.owner ?? '',
        },
        selectedPortfolio: {
          portfolio_uuid: row.uuid ?? row.id ?? '',
          portfolio_product: row.product ?? '',
          portfolio_product_code: row.productCode ?? '',
          portfolio_sub_product: row.subProduct ?? '',
          portfolio_sub_product_code: row.subProductCode ?? '',
          renewal_date: row.renewalDate ?? '',
          total_opportunities: row.totalOpps ?? 0,
          owners: row.owners ?? [],
          ...(row.raw ?? {}),
        },
        returnPath: encodedRoutePath(ROUTES.portfolios),
      },
    });
  };

  const handleAddPortfolio = () => {
    navigate(encodedRoutePath(ROUTES.clientsCreatePortfolio), {
      state: {
        fromClientList: true,
        returnPath: encodedRoutePath(ROUTES.portfolios),
        activeMenu: 'Portfolios',
      },
    });
  };

  const handleReassignPortfolioFromList = () => {
    const row = actionMenu.row;
    handleActionMenuClose();
    if (!row) return;
    setReassignPortfolioRow(row);
  };

  const handleCloseReassignPortfolio = () => {
    setReassignPortfolioRow(null);
  };

  const handleCommitPortfolioReassign = async ({ owner, remarks }) => {
    await reassignPortfolioOwner({
      clientUUID: reassignPortfolioRow?.clientUUID,
      portfolioUUID: reassignPortfolioRow?.uuid ?? reassignPortfolioRow?.id,
      owner,
      remarks,
    });
    await invalidateBusinessDataQueries(queryClient);
    handleCloseReassignPortfolio();
    setReassignSuccessOpen(true);
  };

  const handlePortfolioClick = (row) => {
    const portfolioUUID = row?.uuid ?? row?.id ?? '';
    if (!portfolioUUID) return;

    navigate(encodedRoutePath(ROUTES.opportunities), {
      state: {
        filters: {
          portfolioUUID,
          portfolioLabel: getPortfolioRouteLabel(row),
        },
      },
    });
  };

  const filtersActive = hasActivePortfolioFilters(filters) || hasActivePortfolioFilters(appliedFilters);
  const activeFilterChips = useMemo(
    () => getActivePortfolioFilterChips(appliedFilters, MSG.filters),
    [appliedFilters],
  );

  const renderCellValue = (header, row) => {
    const value = String(row?.[header] ?? '');
    if (!value) return '';

    if (header === 'clientName') {
      return (
        <Tooltip title={value}>
          <Button
            className="client-mgmt-name-link"
            onClick={() =>
              row.clientUUID &&
              navigate(clientsDetailPath(row.clientUUID), {
                state: { activeMenu: 'Portfolios' },
              })
            }
          >
            <span className="client-mgmt-name-link-text">{value}</span>
          </Button>
        </Tooltip>
      );
    }

    if (header === 'portfolio') {
      return (
        <Tooltip title={value}>
          <Button className="client-mgmt-name-link" onClick={() => handlePortfolioClick(row)}>
            <span className="client-mgmt-name-link-text">{value}</span>
          </Button>
        </Tooltip>
      );
    }

    if (header === 'status') {
      const isActive = value.toLowerCase() === 'active';
      return (
        <span
          className={`client-mgmt-active-state-badge${
            isActive ? ' client-mgmt-active-state-badge--active' : ' client-mgmt-active-state-badge--inactive'
          }`}
          role="status"
          aria-label={value}
        >
          {value}
        </span>
      );
    }

    return value;
  };

  return (
    <Box className="client-mgmt-page opportunity-mgmt-page portfolio-mgmt-page">
      <BackdropLoader loading={isLoading || isFetching} />
      <Paper className="client-mgmt-paper table-auto-width">
        <Box className="client-mgmt-head-block table-body-bg border-radius-top-8">
          <Box className="client-mgmt-toolbar client-mgmt-toolbar-head">
            <Box className="client-mgmt-toolbar-left">
              <Box className="client-mgmt-page-title-wrap">
                <Typography className="georama-SemiBold fs-24 client-mgmt-title">{MSG.title}</Typography>
              </Box>
            </Box>
            <Box className="client-mgmt-toolbar-right">
              <TextField
                className="client-mgmt-search form-control-input"
                size="small"
                placeholder={MSG.search}
                value={searchInput}
                onChange={(event) => setSearchInput(sanitizeByField('search', event.target.value))}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon fontSize="small" className="client-mgmt-search-icon" />
                    </InputAdornment>
                  ),
                }}
              />
              <PortfolioListFilters
                filters={filters}
                appliedFilters={appliedFilters}
                onChange={handleFilterChange}
                onApply={handleApplyFilters}
                onClear={handleClearFilters}
                hasActiveFilters={filtersActive}
              />
              <DateRangeFilter
                filters={filters}
                appliedFilters={appliedFilters}
                dateFromField="fromDate"
                dateToField="toDate"
                onChange={handleFilterChange}
                onApply={handleApplyFilters}
                labels={MSG.filters}
                showDateFilterType={false}
              />
              <SortOrderButton value={appliedFilters.sortOrder} onToggle={handleToggleSortOrder} />
              {canShowAddPortfolio && (
                <Button className="btn-common-red border-radius-32 opportunity-mgmt-add-btn" onClick={handleAddPortfolio}>
                  {MSG.addNewPortfolio}
                </Button>
              )}
            </Box>
          </Box>

          {activeFilterChips.length > 0 && (
            <Box className="client-mgmt-active-filters">
              {activeFilterChips.map((chip) => (
                <Chip
                  key={chip.key}
                  label={chip.label}
                  size="small"
                  onDelete={() => handleRemoveFilterChip(chip.key)}
                  className="client-mgmt-filter-chip"
                />
              ))}
              <Button className="client-mgmt-filter-clear-all text-sky" onClick={handleClearFilters}>
                {MSG.filters.clearAll}
              </Button>
            </Box>
          )}
        </Box>

        <TableContainer component={Box} className="client-mgmt-table-wrap opportunity-mgmt-table-wrap">
          <Table>
            <TableHead>
              <TableRow>
                {tableHeaders.map((header) => (
                  <TableCell key={header} className={`client-mgmt-head-cell opportunity-mgmt-col-${header} georama-Medium fw-none`}>
                    {formatColumnLabel(header, PORTFOLIO_LIST_COLUMN_LABELS)}
                  </TableCell>
                ))}
                <TableCell className="client-mgmt-head-cell georama-Medium fw-none client-mgmt-actions-col">
                  {MSG.actions}
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody className="table-body-bg">
              {sortedPortfolioData.length > 0 ? (
                sortedPortfolioData.map((row, idx) => (
                  <TableRow key={row.uuid || idx}>
                    {tableHeaders.map((header) => (
                      <TableCell key={`${idx}-${header}`} className={`p-4 georama-Regular fs-14 opportunity-mgmt-col-${header}`}>
                        {renderCellValue(header, row)}
                      </TableCell>
                    ))}
                    <TableCell className="p-4 georama-Regular fs-14 client-mgmt-actions-col">
                      <Box className="client-mgmt-actions-wrap">
                        <Tooltip title={MSG.moreActions}>
                          <IconButton size="small" className="client-mgmt-more-btn" onClick={handleActionMenuOpen(row)} aria-label={MSG.moreActions}>
                            <MoreHorizIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={Math.max(tableHeaders.length + 1, 1)} className="client-mgmt-no-data">
                    {MSG.noDataFound}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Menu
          anchorEl={actionMenu.anchorEl}
          open={Boolean(actionMenu.anchorEl)}
          onClose={handleActionMenuClose}
          className="client-mgmt-action-menu"
          slotProps={{ paper: { className: 'client-mgmt-action-menu-paper', elevation: 8 } }}
        >
          <Box className="client-mgmt-action-menu-header">
            <Typography className="client-mgmt-action-menu-title georama-SemiBold">{MSG.quickActions}</Typography>
          </Box>
          <MenuItem className="client-mgmt-action-menu-item" onClick={handleAddOpportunityFromList}>
            <ListItemIcon className="client-mgmt-action-menu-icon client-mgmt-action-menu-icon--opportunity">
              <TrendingUpOutlinedIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText
              primary={MSG.addOpportunity}
              primaryTypographyProps={{ className: 'client-mgmt-action-menu-label georama-Medium' }}
            />
          </MenuItem>
          {canShowReassignPortfolio && (
            <MenuItem className="client-mgmt-action-menu-item" onClick={handleReassignPortfolioFromList}>
              <ListItemIcon className="client-mgmt-action-menu-icon client-mgmt-action-menu-icon--owner">
                <ManageAccountsOutlinedIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText
                primary={MSG.reassignOwner}
                primaryTypographyProps={{ className: 'client-mgmt-action-menu-label georama-Medium' }}
              />
            </MenuItem>
          )}
        </Menu>
        <ReassignOwnerDialog
          open={Boolean(reassignPortfolioRow)}
          onClose={handleCloseReassignPortfolio}
          onCommit={handleCommitPortfolioReassign}
          primaryOwner={getPrimaryPortfolioOwner(reassignPortfolioRow)}
          coOwners={[]}
          showCoOwners={false}
          infoContent={REASSIGN_OWNER_MESSAGES.portfolioInfo}
          ownerOptionsOverride={portfolioOwnerOptions}
          ownerOptionsLoading={isReassignClientLoading || isReassignClientFetching}
        />
        <ClientSaveSuccessDialog
          open={reassignSuccessOpen}
          title="Portfolio Reassigned Successfully!"
          message="The portfolio owner assignment has been updated successfully."
          primaryLabel="Done"
          showSecondary={false}
          onViewProfile={() => setReassignSuccessOpen(false)}
        />
        {totalPages > 1 && (
          <Box className="client-mgmt-pagination-wrap table-body-bg border-radius-bottom-8">
            <Typography className="client-mgmt-total-count georama-Medium">
              {MSG.totalPortfolios(totalCount)}
            </Typography>
            <Box className="client-mgmt-pagination">
              <Button className="client-mgmt-pagination-nav" disabled={page <= 1} onClick={() => handlePageChange(page - 1)} aria-label={MSG.previousPage}>
                <ChevronLeftIcon fontSize="small" />
              </Button>
              <Box className="client-mgmt-pagination-pages">
                {paginationItems.map((item) =>
                  typeof item === 'number' ? (
                    <Button
                      key={item}
                      className={`client-mgmt-pagination-page ${item === page ? 'client-mgmt-pagination-page-active' : ''}`}
                      onClick={() => handlePageChange(item)}
                      aria-current={item === page ? 'page' : undefined}
                    >
                      {item}
                    </Button>
                  ) : (
                    <Typography key={item} className="client-mgmt-pagination-ellipsis">...</Typography>
                  ),
                )}
              </Box>
              <Typography className="client-mgmt-pagination-label">{MSG.pageOf(totalPages)}</Typography>
              <Button className="client-mgmt-pagination-nav" disabled={page >= totalPages} onClick={() => handlePageChange(page + 1)} aria-label={MSG.nextPage}>
                <ChevronRightIcon fontSize="small" />
              </Button>
            </Box>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default Portfolios;
