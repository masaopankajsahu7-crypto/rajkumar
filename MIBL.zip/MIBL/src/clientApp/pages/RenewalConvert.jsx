import { useEffect, useMemo, useState } from 'react';
import { Box, Button, FormHelperText, Paper, TextField, Typography } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import ClientNameSearchField from '../components/client/ClientNameSearchField.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import KdsSelect from '../components/common/KdsSelect.jsx';
import { queryKeys } from '../lib/queryKeys.js';
import { encodedRoutePath, ROUTES } from '../config/routes.js';
import { CLIENT_KDS_FIELDS, OPPORTUNITY_KDS_FIELDS } from '../config/kdsFields.js';
import { convertRenewalLeadToOpportunity, getPincodeDetails, getRenewalLeadForConversion } from '../services/api.jsx';
import { isSmeVertical } from '../utils/clientFormValidation.js';
import { getFieldMaxLength, isValidByField, sanitizeByField } from '../utils/fieldUtils.js';
import { getEncryptedRouteParam } from '../utils/encryptedRouteParams.js';
import './ClientsForm.css';
import './RenewalConvert.css';

const formatDateInput = (value) => String(value ?? '').slice(0, 10);

const addOneDay = (value) => {
  const rawValue = formatDateInput(value);
  if (!rawValue) return '';
  const date = new Date(`${rawValue}T00:00:00`);
  if (Number.isNaN(date.getTime())) return '';
  date.setDate(date.getDate() + 1);
  return date.toISOString().slice(0, 10);
};

const formatMoney = (value) => {
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return '';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(numberValue);
};

const emptyForm = {
  clientUUID: '',
  clientName: '',
  vertical: '',
  clientType: '',
  pincode: '',
  contactName: '',
  contactEmail: '',
  contactMobile: '',
  ownerId: '',
  ownerName: '',
  ownerCode: '',
  ownerEmail: '',
  ownerMobile: '',
  ownerBranch: '',
  product: '',
  subproduct: '',
  businessType: 'Renewal',
  previousPolicy: '',
  previousInsurer: '',
  policyStart: '',
  policyEnd: '',
  renewalDate: '',
  renewalDays: '',
  sumInsured: '',
  netPremium: '',
  brokerage: '',
  reward: '',
  totalIncome: '',
};

const mapLeadToForm = (lead = {}) => ({
  clientUUID: lead.converted_client_uuid || '',
  clientName: lead.converted_client_name || lead.cust_name || lead.insured_name || '',
  vertical: lead.rm_vertical || '',
  clientType: lead.client_type || '',
  pincode: lead.pincode || '',
  contactName: lead.cust_contact_name || '',
  contactEmail: lead.cust_contact_email || '',
  contactMobile: lead.cust_contact_phone || '',
  ownerId: lead.assigned_owner_id || lead.converted_by_id || '',
  ownerName: lead.assigned_owner_name || lead.rm_name || '',
  ownerCode: lead.rm_empid || '',
  ownerEmail: lead.assigned_owner_email || lead.rm_domain_name || '',
  ownerMobile: lead.assigned_owner_mobile || lead.rm_mobile || lead.owner_mobile || '',
  ownerBranch: lead.rm_location || '',
  product: lead.product_name || lead.department || '',
  subproduct: lead.subproduct || '',
  businessType: 'Renewal',
  previousPolicy: lead.policy_no || '',
  previousInsurer: lead.insurer || '',
  policyStart: formatDateInput(lead.start_date),
  policyEnd: formatDateInput(lead.expiry_date),
  renewalDate: formatDateInput(lead.renewal_date) || addOneDay(lead.expiry_date),
  renewalDays: lead.renewal_days == null ? '' : `${lead.renewal_days} days`,
  sumInsured: formatMoney(lead.sum_insured),
  netPremium: formatMoney(lead.net_premium),
  brokerage: formatMoney(lead.total_brokerage_amount),
  reward: formatMoney(lead.total_reward_amount),
  totalIncome: formatMoney(lead.total_income),
});

const RenewalConvert = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { renewalLeadUUID, encrypted } = useParams();
  const routeRenewalLeadUUID =
    renewalLeadUUID || getEncryptedRouteParam(encrypted, /^\/renewals\/convert\/([^/]+)$/);
  const [form, setForm] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});
  const [pincodeInfo, setPincodeInfo] = useState({ city: '', state: '' });
  const [successOpen, setSuccessOpen] = useState(false);
  const isSmeSelected = isSmeVertical(form.vertical);

  const { data: lead, isLoading, isFetching } = useQuery({
    queryKey: queryKeys.renewalLeadConversion(routeRenewalLeadUUID),
    queryFn: () => getRenewalLeadForConversion(routeRenewalLeadUUID),
    enabled: Boolean(routeRenewalLeadUUID),
  });

  useEffect(() => {
    if (lead) setForm(mapLeadToForm(lead));
  }, [lead]);

  useEffect(() => {
    if (form.vertical && !isSmeSelected && form.clientType) {
      setForm((prev) => ({ ...prev, clientType: '' }));
    }
  }, [form.clientType, form.vertical, isSmeSelected]);

  useEffect(() => {
    if (!form.product && form.subproduct) {
      setForm((prev) => ({ ...prev, subproduct: '' }));
    }
  }, [form.product, form.subproduct]);

  useEffect(() => {
    const pincode = String(form.pincode ?? '').trim();
    if (pincode.length !== 6) {
      setPincodeInfo({ city: '', state: '' });
      return undefined;
    }

    let cancelled = false;
    const loadPincodeDetails = async () => {
      const details = await getPincodeDetails(pincode);
      if (cancelled) return;
      setPincodeInfo({
        city: details?.city_name ?? '',
        state: details?.state_name ?? '',
      });
    };

    loadPincodeDetails();
    return () => {
      cancelled = true;
    };
  }, [form.pincode]);

  const summary = useMemo(() => ({
    code: lead?.renewal_lead_code || 'Renewal Lead',
    client: lead?.cust_name || lead?.insured_name || '---',
    policy: lead?.policy_no || '---',
    renewal: form.renewalDate || '---',
    stage: String(lead?.renewal_stage || '---').replace(/_/g, ' '),
  }), [form.renewalDate, lead]);

  const handleChange = (field) => (event) => {
    const rawValue = event.target.value;
    const value = field === 'contactMobile'
      ? sanitizeByField('mobile', rawValue)
      : field === 'contactEmail'
        ? sanitizeByField('email', rawValue)
        : rawValue;

    setForm((prev) => ({
      ...prev,
      [field]: value,
      ...(field === 'clientName' ? { clientUUID: '' } : {}),
    }));
    setFormErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const handleClientNameChange = (value) => {
    setForm((prev) => ({ ...prev, clientName: value, clientUUID: '' }));
    setFormErrors((prev) => ({ ...prev, clientName: '', clientUUID: '' }));
  };

  const handleClientSelect = (client) => {
    setForm((prev) => ({
      ...prev,
      clientName: client.clientName || prev.clientName,
      clientUUID: client.clientUUID || '',
    }));
    setFormErrors((prev) => ({ ...prev, clientName: '', clientUUID: '' }));
  };

  const handleSelectChange = (field) => (value) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
      ...(field === 'vertical' ? { clientType: isSmeVertical(value) ? prev.clientType : '' } : {}),
      ...(field === 'product' ? { subproduct: '' } : {}),
    }));
    setFormErrors((prev) => ({
      ...prev,
      [field]: '',
      ...(field === 'vertical' ? { clientType: '' } : {}),
      ...(field === 'product' ? { subproduct: '' } : {}),
    }));
  };

  const validateForm = () => {
    const nextErrors = {};
    const requiredFields = [
      ['clientName', 'Client Name is required'],
      ['vertical', 'Vertical is required'],
      ['pincode', 'Pincode is required'],
      ['contactName', 'Contact Person Name is required'],
      ['contactMobile', 'Mobile is required'],
      ['contactEmail', 'Email is required'],
      ['product', 'Product is required'],
      ['subproduct', 'Sub-product is required'],
      ['businessType', 'Business Type is required'],
    ];
    if (isSmeSelected) requiredFields.push(['clientType', 'Client Type is required']);

    requiredFields.forEach(([field, message]) => {
      if (!String(form[field] ?? '').trim()) nextErrors[field] = message;
    });

    if (!String(form.ownerId ?? '').trim()) nextErrors.ownerName = 'Owner details are incomplete';
    if (String(form.contactMobile ?? '').trim() && !isValidByField('mobile', form.contactMobile)) {
      nextErrors.contactMobile = 'Mobile must be 10 digits';
    }
    if (String(form.contactEmail ?? '').trim() && !isValidByField('email', form.contactEmail)) {
      nextErrors.contactEmail = 'Enter a valid email address';
    }
    return nextErrors;
  };

  const convertMutation = useMutation({
    mutationFn: () =>
      convertRenewalLeadToOpportunity({
        renewalLeadUUID: routeRenewalLeadUUID,
        clientUUID: form.clientUUID,
        clientName: form.clientName,
        clientVerticalCode: form.vertical,
        clientTypeCode: isSmeSelected ? form.clientType : '',
        pincode: form.pincode,
        contactName: form.contactName,
        contactMobile: form.contactMobile,
        contactEmail: form.contactEmail,
        productCode: form.product,
        subProductCode: form.subproduct,
        ownerId: form.ownerId,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.renewalLeadsRoot?.() ?? ['renewalLeads'] });
      queryClient.invalidateQueries({ queryKey: queryKeys.opportunitiesRoot?.() ?? ['opportunities'] });
      setSuccessOpen(true);
    },
    onError: (error) => {
      const message = error?.message ?? 'Renewal conversion failed';
      setFormErrors((prev) => ({ ...prev, submit: message }));
      toast.error(message);
    },
  });

  const handleConvert = () => {
    const nextErrors = validateForm();
    setFormErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    convertMutation.mutate();
  };

  const renderField = (field, label, { type = 'text', required = false, readOnly = false, className = '' } = {}) => (
    <Box className={`renewal-convert-field${className ? ` ${className}` : ''}`}>
      <Typography className="renewal-convert-label">
        {label} {required && <span>*</span>}
      </Typography>
      <TextField
        className={`form-control-input border-radius-8 renewal-convert-input${readOnly ? ' renewal-convert-input-readonly disabled-input' : ''}`}
        size="small"
        fullWidth
        type={type}
        value={form[field] ?? ''}
        onChange={handleChange(field)}
        error={!!formErrors[field]}
        InputProps={{ readOnly }}
        InputLabelProps={type === 'date' ? { shrink: true } : undefined}
        inputProps={{
          ...(field === 'contactMobile' ? { maxLength: getFieldMaxLength('mobile'), inputMode: 'numeric' } : {}),
          ...(field === 'contactEmail' ? { maxLength: getFieldMaxLength('email') } : {}),
        }}
      />
      {formErrors[field] && <FormHelperText className="important-fields">{formErrors[field]}</FormHelperText>}
    </Box>
  );

  const renderPincodeField = () => (
    <Box
      className={`renewal-convert-pincode-row renewal-convert-field-full${
        pincodeInfo.city || pincodeInfo.state ? ' renewal-convert-pincode-row--with-meta' : ''
      }`}
    >
      {renderField('pincode', 'Pincode', { required: true })}
      {pincodeInfo.city || pincodeInfo.state ? (
        <>
          <Box className="renewal-convert-pincode-meta">
            <Typography className="renewal-convert-pincode-meta-label">City</Typography>
            <Typography className="renewal-convert-pincode-meta-value">{pincodeInfo.city}</Typography>
          </Box>
          <Box className="renewal-convert-pincode-meta">
            <Typography className="renewal-convert-pincode-meta-label">State</Typography>
            <Typography className="renewal-convert-pincode-meta-value">{pincodeInfo.state}</Typography>
          </Box>
        </>
      ) : null}
    </Box>
  );

  const renderKdsField = (
    field,
    label,
    config,
    {
      required = false,
      className = '',
      parentCode = '',
      cascade = false,
      disabled = false,
      placeholder,
      onResolvedOption,
    } = {},
  ) => (
    <Box className={`renewal-convert-field${className ? ` ${className}` : ''}`}>
      <KdsSelect
        {...config}
        label={label}
        value={form[field] ?? ''}
        onChange={handleSelectChange(field)}
        required={required}
        parentCode={parentCode}
        cascade={cascade}
        disabled={disabled}
        placeholder={placeholder}
        error={formErrors[field]}
        onResolvedOption={onResolvedOption}
      />
    </Box>
  );

  return (
    <Box className="client-form-page renewal-convert-page">
      <BackdropLoader loading={isLoading || isFetching || convertMutation.isPending} />
      <ClientSaveSuccessDialog
        open={successOpen}
        title="Renewal Converted Successfully"
        message="Renewal lead has been converted to opportunity successfully."
        primaryLabel="Back to Renewals"
        showSecondary={false}
        onViewProfile={() => navigate(encodedRoutePath(ROUTES.renewals))}
      />
      <Paper className="client-form-paper table-auto-width renewal-convert-paper">
        <Box className="client-form-body">
          <Box className="client-form-header renewal-convert-head">
            <Box>
              <Typography className="georama-SemiBold fs-24 client-form-title renewal-convert-title">
                Convert to Opportunity
              </Typography>
              <Typography className="renewal-convert-subtitle">
                Review renewal information and complete the opportunity details.
              </Typography>
            </Box>
            <Box className="renewal-convert-head-actions">
              <Box className="renewal-convert-lead-chip">{summary.code}</Box>
              <Button
                className="text-capitalize georama-medium-selected custom-starticon client-form-back-btn"
                startIcon={<ArrowBackIcon />}
                onClick={() => navigate(encodedRoutePath(ROUTES.renewals))}
              >
                Back
              </Button>
            </Box>
          </Box>
          <Box className="client-form-header-divider" />

          {!isLoading && !lead ? (
            <Paper className="renewal-convert-empty">
              <Typography className="renewal-convert-title">No renewal lead selected</Typography>
              <Button className="btn-common-red border-radius-32" onClick={() => navigate(encodedRoutePath(ROUTES.renewals))}>
                Back to Renewal Leads
              </Button>
            </Paper>
          ) : (
            <>
              <Box className="renewal-convert-source-strip">
                <Box><span>Renewal Client</span><strong>{summary.client}</strong></Box>
                <Box><span>Previous Policy</span><strong>{summary.policy}</strong></Box>
                <Box><span>Renewal Date</span><strong>{summary.renewal}</strong></Box>
                <Box><span>Renewal Stage</span><strong>{summary.stage}</strong></Box>
              </Box>

              <Box className="renewal-convert-grid">
                <Box className="renewal-convert-card-row">
                  <Paper className="renewal-convert-card">
                    <Typography className="renewal-convert-card-title">Client Details</Typography>
                    <Box className="renewal-convert-form-grid renewal-convert-client-grid">
                      <Box className="renewal-convert-field renewal-convert-field-full">
                        <ClientNameSearchField
                          label="Client Name"
                          value={form.clientName}
                          onChange={handleClientNameChange}
                          onSelectExistingClient={handleClientSelect}
                          placeholder="Type client name"
                          required
                          error={!!formErrors.clientName}
                          errorMessage={formErrors.clientName}
                          searchEnabled
                          showAvailabilityStatus={false}
                        />
                      </Box>
                      {renderKdsField('vertical', 'Vertical', CLIENT_KDS_FIELDS.vertical, { required: true })}
                      {renderKdsField('clientType', 'Client Type', CLIENT_KDS_FIELDS.clientType, {
                        required: isSmeSelected,
                        disabled: !isSmeSelected,
                        placeholder: isSmeSelected ? 'Select Client Type' : 'Select SME vertical first',
                      })}
                      {renderPincodeField()}
                      {renderField('contactName', 'Contact Person Name', { required: true, className: 'renewal-convert-field-full' })}
                      {renderField('contactMobile', 'Mobile', { required: true })}
                      {renderField('contactEmail', 'Email', { required: true })}
                    </Box>
                  </Paper>

                  <Paper className="renewal-convert-card">
                    <Typography className="renewal-convert-card-title">Owner Details</Typography>
                    <Box className="renewal-convert-form-grid">
                      {renderField('ownerName', 'Owner Name', {
                        required: true,
                        readOnly: true,
                        className: 'renewal-convert-field-full',
                      })}
                      {renderField('ownerCode', 'Employee Code', { readOnly: true })}
                      {renderField('ownerBranch', 'Branch', { readOnly: true })}
                      {renderField('ownerEmail', 'Email', { readOnly: true })}
                      {renderField('ownerMobile', 'Mobile', { readOnly: true })}
                    </Box>
                  </Paper>
                </Box>

                <Box className="renewal-convert-card-row">
                  <Paper className="renewal-convert-card">
                    <Typography className="renewal-convert-card-title">Opportunity Details</Typography>
                    <Box className="renewal-convert-form-grid">
                      {renderKdsField('product', 'Product', OPPORTUNITY_KDS_FIELDS.product, {
                        required: true,
                        onResolvedOption: (option) => {
                          if (option?.code && form.product !== option.code) {
                            setForm((prev) => ({ ...prev, product: option.code }));
                          }
                        },
                      })}
                      {renderKdsField('subproduct', 'Sub-product', OPPORTUNITY_KDS_FIELDS.subProduct, {
                        required: true,
                        parentCode: form.product,
                        cascade: true,
                        disabled: !form.product,
                        onResolvedOption: (option) => {
                          if (option?.code && form.subproduct !== option.code) {
                            setForm((prev) => ({ ...prev, subproduct: option.code }));
                          }
                        },
                      })}
                      {renderField('businessType', 'Business Type', { required: true, readOnly: true })}
                    </Box>
                  </Paper>

                  <Paper className="renewal-convert-card">
                    <Typography className="renewal-convert-card-title">Previous Policy Details</Typography>
                    <Box className="renewal-convert-form-grid">
                      {renderField('previousPolicy', 'Previous Policy No.', { readOnly: true })}
                      {renderField('previousInsurer', 'Previous Insurer', { readOnly: true })}
                      {renderField('policyStart', 'Policy Start Date', { type: 'date', readOnly: true })}
                      {renderField('policyEnd', 'Policy End Date', { type: 'date', readOnly: true })}
                      {renderField('renewalDate', 'Renewal Date', { type: 'date', readOnly: true })}
                      {renderField('renewalDays', 'Renewal Days', { readOnly: true })}
                    </Box>
                  </Paper>
                </Box>

                <Paper className="renewal-convert-card renewal-convert-card-full">
                  <Typography className="renewal-convert-card-title">Previous Policy Financials</Typography>
                  <Box className="renewal-convert-form-grid renewal-convert-form-grid-five">
                    {renderField('sumInsured', 'Sum Insured', { readOnly: true })}
                    {renderField('netPremium', 'Net Premium', { readOnly: true })}
                    {renderField('brokerage', 'Brokerage Amount', { readOnly: true })}
                    {renderField('reward', 'Reward Amount', { readOnly: true })}
                    {renderField('totalIncome', 'Total Income', { readOnly: true })}
                  </Box>
                </Paper>
              </Box>

              <Box className="renewal-convert-actions">
                <Typography className={`renewal-convert-action-note${formErrors.submit ? ' important-fields' : ''}`}>
                  {formErrors.submit || 'Fields marked with * are required before conversion.'}
                </Typography>
                <Box className="renewal-convert-action-buttons">
                  <Button className="renewal-convert-cancel" onClick={() => navigate(encodedRoutePath(ROUTES.renewals))}>Cancel</Button>
                  <Button
                    className="btn-common-red border-radius-32 renewal-convert-submit"
                    onClick={handleConvert}
                    disabled={convertMutation.isPending}
                  >
                    <SwapHorizIcon fontSize="small" />
                    Convert to Opportunity
                  </Button>
                </Box>
              </Box>
            </>
          )}
        </Box>
      </Paper>
    </Box>
  );
};

export default RenewalConvert;
