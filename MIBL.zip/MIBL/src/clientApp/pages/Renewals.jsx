import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Autocomplete,
  Box,
  Badge,
  Button,
  Checkbox,
  Chip,
  Dialog,
  DialogContent,
  FormControl,
  IconButton,
  MenuItem,
  InputAdornment,
  Popover,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined';
import SyncAltOutlinedIcon from '@mui/icons-material/SyncAltOutlined';
import HighlightOffOutlinedIcon from '@mui/icons-material/HighlightOffOutlined';
import PersonAddAltOutlinedIcon from '@mui/icons-material/PersonAddAltOutlined';
import SearchIcon from '@mui/icons-material/Search';
import CloseIcon from '@mui/icons-material/Close';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import ClientSaveSuccessDialog from '../components/client/ClientSaveSuccessDialog.jsx';
import DateRangeFilter from '../components/common/DateRangeFilter.jsx';
import KdsSelect from '../components/common/KdsSelect.jsx';
import SortOrderButton from '../components/common/SortOrderButton.jsx';
import { useKdsOptions, useRenewalLeadList } from '../hooks/useFetchQueries.js';
import {
  countActiveRenewalFilters,
  getActiveRenewalFilterChips,
  getRenewalLeadTotalPages,
  hasActiveRenewalFilters,
  INITIAL_RENEWAL_LEAD_FILTERS,
  RENEWAL_LEAD_PAGE_SIZE_OPTIONS,
  RENEWAL_LEAD_LIST_PAGE_SIZE,
  RENEWAL_SORT_OPTIONS,
} from '../utils/renewalLeadList.js';
import { sanitizeByField } from '../utils/fieldUtils.js';
import { renewalConvertPath } from '../config/routes.js';
import { RENEWAL_KDS_FIELDS } from '../config/kdsFields.js';
import { markRenewalLeadNotRenewable, reassignRenewalLeadOwner, searchAssignableOwners } from '../services/api.jsx';
import { queryKeys } from '../lib/queryKeys.js';
import './Clients.css';
import './Renewals.css';

const RENEWAL_COLUMNS = [
  { key: 'select', label: '' },
  { key: 'customer', label: 'Client' },
  { key: 'policy', label: 'Policy' },
  { key: 'insurer', label: 'Insurer' },
  { key: 'expiry', label: 'Expiry' },
  { key: 'owner', label: 'Owner' },
  { key: 'status', label: 'Status' },
  { key: 'actions', label: '' },
];

const DISPLAY_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];

const RENEWAL_FILTER_LABELS = {
  title: 'Filters',
  clear: 'Clear',
  apply: 'Apply',
  clearAll: 'Clear All',
  dateRangePreset: 'Date Range',
  sortAndRange: 'Sort & Range',
  sortBy: 'Sort By',
};

const BASIC_RENEWAL_FILTER_GROUPS = [
  {
    title: 'Client',
    fields: [
      ['clientName', 'Client Name'],
      ['clientMobile', 'Client Mobile'],
      ['clientEmail', 'Client Email'],
    ],
  },
  {
    title: 'Policy',
    fields: [
      ['product', 'Product'],
      ['policyNo', 'Policy No'],
    ],
  },
  {
    title: 'Renewal',
    fields: [
      ['renewalStatus', 'Renewal Status'],
    ],
  },
];

const ADVANCED_RENEWAL_FILTER_GROUPS = [
  {
    title: 'Policy Details',
    fields: [
      ['insurer', 'Insurer'],
      ['renewalDays', 'Renewal Days'],
    ],
  },
  {
    title: 'Ownership',
    fields: [
      ['owner', 'Owner'],
      ['department', 'Department'],
    ],
  },
];

const DEFAULT_RENEWAL_LEAD_FILTERS = {
  ...INITIAL_RENEWAL_LEAD_FILTERS,
  renewalStatus: 'RLS_PENDING',
};

const formatDate = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '---';
  const isoDateMatch = rawValue.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (isoDateMatch) {
    const [, year, month, day] = isoDateMatch;
    return `${Number(day)} ${DISPLAY_MONTHS[Number(month) - 1] ?? month} ${year}`;
  }
  const parsedDate = new Date(rawValue);
  if (Number.isNaN(parsedDate.getTime())) return rawValue;
  return `${parsedDate.getDate()} ${DISPLAY_MONTHS[parsedDate.getMonth()]} ${parsedDate.getFullYear()}`;
};

const formatDisplayName = (name) =>
  String(name ?? '')
    .trim()
    .split(/\s+/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');

const getRenewalDaysText = (row) => {
  const days = Number(row.renewalDays);
  if (!Number.isFinite(days)) return '---';
  if (days < 0) return `${Math.abs(days)} days overdue`;
  if (days === 0) return 'Due today';
  return `${days} days left`;
};

const getStatusClass = (status) => {
  const normalized = String(status ?? '').toLowerCase();
  if (normalized.includes('non renewable') || normalized.includes('not') || normalized.includes('reject')) {
    return 'renewals-status-badge--not-renewable';
  }
  if (normalized.includes('converted') || normalized.includes('opportunity')) return 'renewals-status-badge--converted';
  if (normalized.includes('pending')) return 'renewals-status-badge--pending';
  return '';
};

const canActOnRenewalLead = (row) =>
  String(row?.statusCode ?? row?.raw?.renewal_status_code ?? '').trim().toUpperCase() === 'RLS_PENDING';

const EllipsizedTooltipText = ({ value, className = '' }) => {
  const textRef = useRef(null);
  const [isEllipsized, setIsEllipsized] = useState(false);

  const handleMouseEnter = () => {
    const element = textRef.current;
    setIsEllipsized(Boolean(element && element.scrollWidth > element.clientWidth));
  };

  return (
    <Tooltip title={isEllipsized ? value : ''} placement="top" arrow disableInteractive>
      <span ref={textRef} className={className} onMouseEnter={handleMouseEnter}>
        {value}
      </span>
    </Tooltip>
  );
};

const DataLine = ({ primary, secondary }) => (
  <Box>
    <EllipsizedTooltipText value={primary || '---'} className="renewals-primary-text" />
    {Array.isArray(secondary)
      ? secondary.map((item) => (
          <EllipsizedTooltipText key={item} value={item} className="renewals-secondary-text" />
        ))
      : secondary ? <EllipsizedTooltipText value={secondary} className="renewals-secondary-text" /> : null}
  </Box>
);

const RenewalsListFilters = ({ filters, appliedFilters, onChange, onApply, onClear, hasActiveFilters }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [activeTab, setActiveTab] = useState('basic');
  const open = Boolean(anchorEl);
  const activeCount = countActiveRenewalFilters(appliedFilters);
  const visibleGroups = activeTab === 'basic' ? BASIC_RENEWAL_FILTER_GROUPS : ADVANCED_RENEWAL_FILTER_GROUPS;

  const renderFilterField = (field, label) => {
    if (field === 'renewalStatus') {
      return (
        <Box key={field} className="renewals-filter-kds-field">
          <KdsSelect
            {...RENEWAL_KDS_FIELDS.leadStatus}
            label=""
            value={filters[field] ?? ''}
            onChange={(value) => onChange(field, value)}
            placeholder={label}
            menuPaperClassName="renewals-filter-kds-menu-paper"
            menuListClassName="renewals-filter-kds-menu-list"
            menuItemClassName="renewals-filter-kds-menu-item"
          />
        </Box>
      );
    }

    return (
      <TextField
        key={field}
        className="client-mgmt-filter-input"
        size="small"
        placeholder={label}
        value={filters[field] ?? ''}
        onChange={(event) => onChange(field, sanitizeByField('search', event.target.value))}
      />
    );
  };

  const handleApply = () => {
    onApply();
    setAnchorEl(null);
  };

  return (
    <>
      <Badge
        badgeContent={activeCount}
        color="error"
        invisible={activeCount === 0}
        className="client-mgmt-filter-badge"
      >
        <Button
          className="client-mgmt-filter-toggle-btn client-mgmt-icon-btn"
          onClick={(event) => setAnchorEl(event.currentTarget)}
          aria-label="Filters"
        >
          <Box className="client-mgmt-filter-lines-icon" aria-hidden="true">
            <span />
            <span />
            <span />
          </Box>
        </Button>
      </Badge>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        className="client-mgmt-filter-popover opportunity-mgmt-filter-popover"
        slotProps={{ paper: { className: 'client-mgmt-filter-popover-paper opportunity-mgmt-filter-popover-paper' } }}
      >
        <Box className="client-mgmt-filter-popover-head">
          <Typography className="georama-SemiBold client-mgmt-filter-popover-title">Filters</Typography>
          <Button className="client-mgmt-filter-popover-close" onClick={() => setAnchorEl(null)} aria-label="Close filters">
            <CloseIcon fontSize="small" />
          </Button>
        </Box>
        <Box className="client-mgmt-filter-tabs">
          {['basic', 'advanced'].map((tabKey) => (
            <Button
              key={tabKey}
              className={`client-mgmt-filter-tab ${activeTab === tabKey ? 'client-mgmt-filter-tab-active' : ''}`}
              onClick={() => setActiveTab(tabKey)}
            >
              {tabKey === 'basic' ? 'Basic' : 'Advanced'}
            </Button>
          ))}
        </Box>
        <Box className="client-mgmt-filter-popover-body">
          {visibleGroups.map((group) => (
            <Box className="client-mgmt-filter-section" key={group.title}>
              <Typography className="client-mgmt-filter-section-title">{group.title}</Typography>
              <Box className="client-mgmt-filter-popover-row">
                {group.fields.map(([field, label]) => renderFilterField(field, label))}
              </Box>
            </Box>
          ))}
        </Box>
        <Box className="client-mgmt-filter-popover-actions">
          <Button className="client-mgmt-filter-clear-btn text-sky" onClick={onClear} disabled={!hasActiveFilters}>
            Clear
          </Button>
          <Button className="btn-common-red client-mgmt-filter-apply-btn" onClick={handleApply}>
            Apply
          </Button>
        </Box>
      </Popover>
    </>
  );
};

const Renewals = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState(DEFAULT_RENEWAL_LEAD_FILTERS);
  const [appliedFilters, setAppliedFilters] = useState(DEFAULT_RENEWAL_LEAD_FILTERS);
  const [searchInput, setSearchInput] = useState('');
  const [pageSize, setPageSize] = useState(RENEWAL_LEAD_LIST_PAGE_SIZE);
  const [selectedRows, setSelectedRows] = useState([]);
  const [actionAnchorEl, setActionAnchorEl] = useState(null);
  const [actionRow, setActionRow] = useState(null);
  const [notRenewableOpen, setNotRenewableOpen] = useState(false);
  const [notRenewableRow, setNotRenewableRow] = useState(null);
  const [notRenewableForm, setNotRenewableForm] = useState({ reason: '', remarks: '' });
  const [notRenewableErrors, setNotRenewableErrors] = useState({});
  const [notRenewableSuccessOpen, setNotRenewableSuccessOpen] = useState(false);
  const [reassignOpen, setReassignOpen] = useState(false);
  const [reassignRow, setReassignRow] = useState(null);
  const [reassignMode, setReassignMode] = useState('single');
  const [reassignForm, setReassignForm] = useState({ user: null, comment: '' });
  const [reassignErrors, setReassignErrors] = useState({});
  const [reassignUserSearch, setReassignUserSearch] = useState('');
  const [reassignUserOptions, setReassignUserOptions] = useState([]);
  const [reassignUsersLoading, setReassignUsersLoading] = useState(false);
  const [reassignSuccessOpen, setReassignSuccessOpen] = useState(false);
  const { data: renewalLeadResponse, isLoading, isFetching } = useRenewalLeadList(page, appliedFilters, pageSize);
  const { data: renewalStatusOptions = [] } = useKdsOptions(RENEWAL_KDS_FIELDS.leadStatus);

  const rows = useMemo(() => renewalLeadResponse?.list ?? [], [renewalLeadResponse]);
  const totalCount = renewalLeadResponse?.totalCount ?? 0;
  const totalPages = useMemo(() => getRenewalLeadTotalPages(totalCount, pageSize), [pageSize, totalCount]);
  const selectableRowIds = useMemo(
    () => rows
      .map((row, index) => ({ rowId: String(row.uuid || row.id || index), row }))
      .filter(({ row }) => canActOnRenewalLead(row))
      .map(({ rowId }) => rowId),
    [rows],
  );
  const allVisibleSelected = selectableRowIds.length > 0 && selectableRowIds.every((rowId) => selectedRows.includes(rowId));
  const someVisibleSelected = selectableRowIds.some((rowId) => selectedRows.includes(rowId));
  const selectedRenewalRows = useMemo(
    () => rows.filter((row, index) => selectedRows.includes(String(row.uuid || row.id || index))),
    [rows, selectedRows],
  );
  const selectedRenewalLeadUUIDs = useMemo(
    () => selectedRenewalRows
      .map((row) => row.uuid || row.raw?.renewal_lead_uuid)
      .filter(Boolean),
    [selectedRenewalRows],
  );

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setFilters((prev) => ({ ...prev, search: searchInput.trim() }));
      setAppliedFilters((prev) => ({ ...prev, search: searchInput.trim() }));
      setPage(1);
    }, 300);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    setSelectedRows((prev) => prev.filter((rowId) => selectableRowIds.includes(rowId)));
  }, [selectableRowIds]);

  useEffect(() => {
    if (!reassignOpen) return undefined;
    const normalizedSearch = String(reassignUserSearch ?? '').trim();
    if (normalizedSearch.length < 2) {
      setReassignUserOptions([]);
      setReassignUsersLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    setReassignUsersLoading(true);
    const timer = window.setTimeout(() => {
      searchAssignableOwners(normalizedSearch)
        .then((options) => {
          if (!ignoreResult) setReassignUserOptions(options);
        })
        .catch((error) => {
          if (!ignoreResult) toast.error(error?.message ?? 'Unable to load user list');
        })
        .finally(() => {
          if (!ignoreResult) setReassignUsersLoading(false);
        });
    }, 350);

    return () => {
      ignoreResult = true;
      window.clearTimeout(timer);
    };
  }, [reassignOpen, reassignUserSearch]);

  const renewalStatusDisplayMap = useMemo(() => (
    renewalStatusOptions.reduce((lookup, option) => {
      const code = String(option.code ?? '').trim();
      const value = String(option.value ?? '').trim();
      if (code && value) lookup[code] = value;
      return lookup;
    }, {})
  ), [renewalStatusOptions]);
  const activeFilterChips = useMemo(
    () => getActiveRenewalFilterChips(appliedFilters, { renewalStatus: renewalStatusDisplayMap }),
    [appliedFilters, renewalStatusDisplayMap],
  );
  const filtersActive = hasActiveRenewalFilters(filters) || hasActiveRenewalFilters(appliedFilters);

  const handleFilterChange = (field, value) => {
    setFilters((prev) => ({ ...prev, [field]: value }));
  };

  const handleApplyFilters = () => {
    setAppliedFilters({ ...filters, search: searchInput.trim() });
    setPage(1);
  };

  const handleClearFilters = () => {
    setFilters(INITIAL_RENEWAL_LEAD_FILTERS);
    setAppliedFilters(INITIAL_RENEWAL_LEAD_FILTERS);
    setSearchInput('');
    setPage(1);
  };

  const handleRemoveFilterChip = (key) => {
    const nextFilters = { ...filters, [key]: INITIAL_RENEWAL_LEAD_FILTERS[key] ?? '' };
    setFilters(nextFilters);
    setAppliedFilters((prev) => ({ ...prev, [key]: INITIAL_RENEWAL_LEAD_FILTERS[key] ?? '' }));
    if (key === 'search') setSearchInput('');
    setPage(1);
  };

  const handleToggleSortOrder = () => {
    const nextOrder = appliedFilters.sortOrder === 'ASC' ? 'DESC' : 'ASC';
    setFilters((prev) => ({ ...prev, sortOrder: nextOrder }));
    setAppliedFilters((prev) => ({ ...prev, sortOrder: nextOrder }));
    setPage(1);
  };

  const paginationItems = useMemo(() => {
    if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);

    const pages = new Set([1, totalPages, page - 1, page, page + 1]);
    const visiblePages = [...pages]
      .filter((pageNumber) => pageNumber >= 1 && pageNumber <= totalPages)
      .sort((first, second) => first - second);

    return visiblePages.reduce((items, pageNumber, index) => {
      const previousPage = visiblePages[index - 1];
      if (index > 0 && pageNumber - previousPage > 1) items.push(`ellipsis-${previousPage}-${pageNumber}`);
      items.push(pageNumber);
      return items;
    }, []);
  }, [page, totalPages]);

  const handlePageChange = (nextPage) => {
    if (nextPage === page || nextPage < 1 || nextPage > totalPages) return;
    setPage(nextPage);
  };

  const handlePageSizeChange = (event) => {
    setPageSize(Number(event.target.value));
    setPage(1);
  };

  const handleSelectAllRows = (event) => {
    setSelectedRows(event.target.checked ? selectableRowIds : []);
  };

  const handleSelectRow = (rowId) => (event) => {
    setSelectedRows((prev) => {
      if (event.target.checked) return prev.includes(rowId) ? prev : [...prev, rowId];
      return prev.filter((selectedId) => selectedId !== rowId);
    });
  };

  const handleOpenActions = (row) => (event) => {
    setActionAnchorEl(event.currentTarget);
    setActionRow(row);
  };

  const handleCloseActions = () => {
    setActionAnchorEl(null);
    setActionRow(null);
  };

  const handleOpenNotRenewableDialog = () => {
    setNotRenewableRow(actionRow);
    setNotRenewableForm({ reason: '', remarks: '' });
    setNotRenewableErrors({});
    handleCloseActions();
    setNotRenewableOpen(true);
  };

  const handleCloseNotRenewableDialog = () => {
    setNotRenewableOpen(false);
    setNotRenewableRow(null);
    setNotRenewableForm({ reason: '', remarks: '' });
    setNotRenewableErrors({});
  };

  const handleOpenReassignDialog = () => {
    setReassignRow(actionRow);
    setReassignMode('single');
    setReassignForm({ user: null, comment: '' });
    setReassignErrors({});
    setReassignUserSearch('');
    setReassignUserOptions([]);
    handleCloseActions();
    setReassignOpen(true);
  };

  const handleOpenBulkReassignDialog = () => {
    if (selectedRenewalLeadUUIDs.length === 0) return;
    setReassignRow(null);
    setReassignMode('bulk');
    setReassignForm({ user: null, comment: '' });
    setReassignErrors({});
    setReassignUserSearch('');
    setReassignUserOptions([]);
    setReassignOpen(true);
  };

  const handleCloseReassignDialog = () => {
    setReassignOpen(false);
    setReassignRow(null);
    setReassignMode('single');
    setReassignForm({ user: null, comment: '' });
    setReassignErrors({});
    setReassignUserSearch('');
    setReassignUserOptions([]);
  };

  const handleReassignChange = (field) => (event) => {
    setReassignForm((prev) => ({ ...prev, [field]: event.target.value }));
    setReassignErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const reassignMutation = useMutation({
    mutationFn: () =>
      reassignRenewalLeadOwner({
        owner: reassignForm.user,
        renewalLeadUUIDs: reassignMode === 'bulk'
          ? selectedRenewalLeadUUIDs
          : [reassignRow?.uuid || reassignRow?.raw?.renewal_lead_uuid],
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.renewalLeadsRoot() });
      handleCloseReassignDialog();
      setSelectedRows([]);
      setReassignSuccessOpen(true);
    },
    onError: (error) => {
      toast.error(error?.message ?? 'Renewal lead reassignment failed');
    },
  });

  const handleUpdateReassign = () => {
    const nextErrors = {};
    if (!reassignForm.user?.code) nextErrors.user = 'Select a valid user';
    if (!String(reassignForm.comment ?? '').trim()) nextErrors.comment = 'Comment is required';
    setReassignErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    reassignMutation.mutate();
  };

  const notRenewableMutation = useMutation({
    mutationFn: () =>
      markRenewalLeadNotRenewable({
        renewalLeadUUID: notRenewableRow?.uuid || notRenewableRow?.raw?.renewal_lead_uuid,
        rejectionReasonCode: notRenewableForm.reason,
        rejectionComment: notRenewableForm.remarks,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.renewalLeadsRoot() });
      handleCloseNotRenewableDialog();
      setNotRenewableSuccessOpen(true);
    },
    onError: (error) => {
      toast.error(error?.message ?? 'Unable to mark renewal lead as not renewable.');
    },
  });

  const handleNotRenewableChange = (field) => (valueOrEvent) => {
    const value = valueOrEvent?.target ? valueOrEvent.target.value : valueOrEvent;
    setNotRenewableForm((prev) => ({ ...prev, [field]: value }));
    setNotRenewableErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const handleMarkNotRenewable = () => {
    const nextErrors = {};
    if (!String(notRenewableForm.reason ?? '').trim()) nextErrors.reason = 'Select not renewable reason';
    if (!String(notRenewableForm.remarks ?? '').trim()) nextErrors.remarks = 'Remarks are required';
    setNotRenewableErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    notRenewableMutation.mutate();
  };

  const handleConvertToOpportunity = () => {
    const renewalLeadUUID = actionRow?.uuid || actionRow?.raw?.renewal_lead_uuid;
    handleCloseActions();
    if (!renewalLeadUUID) return;
    navigate(renewalConvertPath(renewalLeadUUID));
  };

  const isActionRowOpportunity = String(actionRow?.stage ?? actionRow?.raw?.renewal_stage ?? '')
    .trim()
    .toLowerCase() === 'opportunity';

  const renderCell = (column, row, index) => {
    const rowId = String(row.uuid || row.id || index);
    if (column === 'select') {
      if (!canActOnRenewalLead(row)) return null;
      return (
        <Checkbox
          size="small"
          checked={selectedRows.includes(rowId)}
          onChange={handleSelectRow(rowId)}
          className="renewals-row-checkbox"
        />
      );
    }
    if (column === 'customer') {
      const secondary = [row.contactPhone, row.contactEmail].filter(Boolean);
      const clientName = formatDisplayName(row.customerName);
      return <DataLine primary={clientName} secondary={secondary} title={clientName} />;
    }
    if (column === 'policy') {
      const secondary = [row.productName, row.subproduct].filter(Boolean).join(' | ');
      return <DataLine primary={row.policyNo} secondary={secondary} title={row.policyNo} />;
    }
    if (column === 'insurer') {
      const insurerName = formatDisplayName(row.insurer);
      return <DataLine primary={insurerName} title={insurerName} />;
    }
    if (column === 'expiry') {
      return (
        <Box>
          <span className="renewals-primary-text">{formatDate(row.expiryDate)}</span>
          <span className={`renewals-days-pill ${Number(row.renewalDays) < 0 ? 'renewals-days-pill--overdue' : ''}`}>
            {getRenewalDaysText(row)}
          </span>
        </Box>
      );
    }
    if (column === 'owner') {
      const ownerName = formatDisplayName(row.rmName);
      return <DataLine primary={ownerName} secondary={row.rmLocation} title={ownerName} />;
    }
    if (column === 'status') {
      return (
        <span className={`renewals-status-badge ${getStatusClass(row.status)}`} role="status">
          {row.status || '---'}
        </span>
      );
    }
    if (column === 'actions') {
      if (!canActOnRenewalLead(row)) return null;
      return (
        <Button className="renewals-action-btn" aria-label="Renewal lead actions" onClick={handleOpenActions(row)}>
          <MoreVertIcon fontSize="small" />
        </Button>
      );
    }
    return '---';
  };

  return (
    <Box className="client-mgmt-page renewals-page">
      <BackdropLoader loading={isLoading || isFetching || notRenewableMutation.isPending || reassignMutation.isPending} />
      <Paper className="client-mgmt-paper table-auto-width">
        <Box className="client-mgmt-head-block table-body-bg border-radius-top-8">
          <Box className="client-mgmt-toolbar client-mgmt-toolbar-head">
            <Box className="client-mgmt-toolbar-left">
              <Box className="client-mgmt-page-title-wrap">
                <Typography className="georama-SemiBold fs-24 client-mgmt-title">Renewal Leads</Typography>
              </Box>
            </Box>
            <Box className="client-mgmt-toolbar-right">
              <TextField
                className="client-mgmt-search form-control-input"
                size="small"
                placeholder="Search renewal leads..."
                value={searchInput}
                onChange={(event) => setSearchInput(sanitizeByField('search', event.target.value))}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon fontSize="small" className="client-mgmt-search-icon" />
                    </InputAdornment>
                  ),
                }}
              />
              <Button
                className="renewals-reassign-btn"
                onClick={handleOpenBulkReassignDialog}
                disabled={selectedRenewalLeadUUIDs.length === 0}
              >
                <GroupOutlinedIcon fontSize="small" />
                Re-Assign
                {selectedRenewalLeadUUIDs.length > 0 && (
                  <span className="renewals-reassign-count">{selectedRenewalLeadUUIDs.length}</span>
                )}
              </Button>
              <RenewalsListFilters
                filters={filters}
                appliedFilters={appliedFilters}
                onChange={handleFilterChange}
                onApply={handleApplyFilters}
                onClear={handleClearFilters}
                hasActiveFilters={filtersActive}
              />
              <DateRangeFilter
                filters={filters}
                appliedFilters={appliedFilters}
                dateFromField="fromDate"
                dateToField="toDate"
                onChange={handleFilterChange}
                onApply={handleApplyFilters}
                labels={RENEWAL_FILTER_LABELS}
                showDateFilterType={false}
                sortOptions={RENEWAL_SORT_OPTIONS}
              />
              <SortOrderButton value={appliedFilters.sortOrder} onToggle={handleToggleSortOrder} />
            </Box>
          </Box>
          {activeFilterChips.length > 0 && (
            <Box className="client-mgmt-active-filters">
              {activeFilterChips.map((chip) => (
                <Chip
                  key={chip.key}
                  label={chip.label}
                  size="small"
                  onDelete={() => handleRemoveFilterChip(chip.key)}
                  className="client-mgmt-filter-chip"
                />
              ))}
              <Button className="client-mgmt-filter-clear-all text-sky" onClick={handleClearFilters}>
                Clear All
              </Button>
            </Box>
          )}
        </Box>

        <Popover
          open={Boolean(actionAnchorEl)}
          anchorEl={actionAnchorEl}
          onClose={handleCloseActions}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          className="renewals-actions-popover"
          slotProps={{ paper: { className: 'renewals-actions-paper' } }}
        >
          <Box className="renewals-actions-title">Renewal Actions</Box>
          <Button
            className="renewals-actions-item"
            onClick={handleConvertToOpportunity}
            disabled={isActionRowOpportunity}
          >
            <SyncAltOutlinedIcon fontSize="small" />
            Convert to Opportunity
          </Button>
          <Button className="renewals-actions-item renewals-actions-item--danger" onClick={handleOpenNotRenewableDialog}>
            <HighlightOffOutlinedIcon fontSize="small" />
            Mark as Not Renewable
          </Button>
          <Button className="renewals-actions-item" onClick={handleOpenReassignDialog}>
            <PersonAddAltOutlinedIcon fontSize="small" />
            Re-Assign Renewal Data
          </Button>
        </Popover>

        <Dialog
          open={notRenewableOpen}
          onClose={handleCloseNotRenewableDialog}
          fullWidth
          maxWidth="sm"
          className="renewals-not-renewable-dialog"
        >
          <Box className="renewals-not-renewable-head">
            <Box>
              <Typography className="renewals-not-renewable-title georama-SemiBold">Mark as Not Renewable</Typography>
              <Typography className="renewals-not-renewable-subtitle georama-Regular">
                Record why this renewal will not be pursued.
              </Typography>
            </Box>
            <IconButton className="renewals-not-renewable-close" onClick={handleCloseNotRenewableDialog}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
          <DialogContent className="renewals-not-renewable-content">
            <Box className="renewals-not-renewable-summary">
              <Box>
                <span>Renewal Lead</span>
                <strong>{notRenewableRow?.code || notRenewableRow?.raw?.renewal_lead_code || '---'}</strong>
              </Box>
              <Box>
                <span>Client</span>
                <strong>{formatDisplayName(notRenewableRow?.customerName) || '---'}</strong>
              </Box>
              <Box>
                <span>Policy Number</span>
                <strong>{notRenewableRow?.policyNo || '---'}</strong>
              </Box>
              <Box>
                <span>Renewal Date</span>
                <strong>{formatDate(notRenewableRow?.renewalDate)}</strong>
              </Box>
            </Box>
            <Box className="renewals-not-renewable-alert">
              This lead will be marked as Not Renewable and removed from the pending-action queue.
            </Box>
            <Box className="renewals-not-renewable-field">
              <KdsSelect
                {...RENEWAL_KDS_FIELDS.notRenewableReason}
                label="Not renewable reason"
                value={notRenewableForm.reason}
                onChange={handleNotRenewableChange('reason')}
                required
                placeholder="Select reason"
                error={notRenewableErrors.reason}
                onClearError={() => setNotRenewableErrors((prev) => ({ ...prev, reason: '' }))}
              />
            </Box>
            <Box className="renewals-not-renewable-field">
              <Typography className="text-labels client-form-label georama-Medium">
                Remarks <span className="important-fields">*</span>
              </Typography>
              <TextField
                className="form-control-input border-radius-8 renewals-not-renewable-remarks"
                value={notRenewableForm.remarks}
                onChange={handleNotRenewableChange('remarks')}
                placeholder="Add a clear explanation..."
                multiline
                minRows={4}
                error={!!notRenewableErrors.remarks}
                helperText={notRenewableErrors.remarks}
                fullWidth
              />
            </Box>
          </DialogContent>
          <Box className="renewals-not-renewable-actions">
            <Button className="client-mgmt-filter-clear-btn" onClick={handleCloseNotRenewableDialog}>
              Cancel
            </Button>
            <Button className="btn-common-red border-radius-32" onClick={handleMarkNotRenewable}>
              Mark as Not Renewable
            </Button>
          </Box>
        </Dialog>

        <ClientSaveSuccessDialog
          open={notRenewableSuccessOpen}
          title="Renewal Marked as Not Renewable"
          message="The renewal lead has been updated successfully."
          primaryLabel="View Renewal Leads"
          showSecondary={false}
          onViewProfile={() => setNotRenewableSuccessOpen(false)}
        />

        <Dialog
          open={reassignOpen}
          onClose={handleCloseReassignDialog}
          fullWidth
          maxWidth="sm"
          className="renewals-modal-dialog"
        >
          <Box className="renewals-modal-head">
            <Box>
              <Typography className="renewals-modal-title georama-SemiBold">
                {reassignMode === 'bulk' ? 'Bulk Re-Assign Renewal Owner' : 'Re-Assign Renewal Data'}
              </Typography>
              <Typography className="renewals-modal-subtitle georama-Regular">
                {reassignMode === 'bulk'
                  ? 'Update the Renewal RM for all selected renewal leads.'
                  : 'Select a user and add a handover comment.'}
              </Typography>
            </Box>
            <IconButton className="renewals-modal-close" onClick={handleCloseReassignDialog}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
          <DialogContent className="renewals-modal-content">
            {reassignMode === 'bulk' ? (
              <Box className="renewals-modal-selection-banner">
                <span className="renewals-modal-selection-check" aria-hidden="true">✓</span>
                <Box>
                  <Typography className="renewals-modal-selection-title">
                    {selectedRenewalLeadUUIDs.length} renewal {selectedRenewalLeadUUIDs.length === 1 ? 'lead' : 'leads'} selected
                  </Typography>
                  <Typography className="renewals-modal-selection-text">
                    The same Renewal Owner will be applied to every selected row.
                  </Typography>
                </Box>
              </Box>
            ) : (
              <Box className="renewals-modal-summary">
                <Box>
                  <span>Renewal Lead</span>
                  <strong>{reassignRow?.code || reassignRow?.raw?.renewal_lead_code || '---'}</strong>
                </Box>
                <Box>
                  <span>Client</span>
                  <strong>{formatDisplayName(reassignRow?.customerName) || '---'}</strong>
                </Box>
                <Box>
                  <span>Policy Number</span>
                  <strong>{reassignRow?.policyNo || '---'}</strong>
                </Box>
                <Box>
                  <span>Renewal Date</span>
                  <strong>{formatDate(reassignRow?.renewalDate)}</strong>
                </Box>
              </Box>
            )}
            <Box className="renewals-modal-field">
              <Typography className="text-labels client-form-label georama-Medium">
                {reassignMode === 'bulk' ? 'Renewal Owner Name' : 'Assign to user'} <span className="important-fields">*</span>
              </Typography>
              <Autocomplete
                className="form-control-input border-radius-8 renewals-modal-user-select"
                options={reassignUserOptions}
                value={reassignForm.user}
                loading={reassignUsersLoading}
                getOptionLabel={(option) => String(option?.value ?? '')}
                isOptionEqualToValue={(option, value) => String(option?.code) === String(value?.code)}
                onChange={(_, option) => {
                  setReassignForm((prev) => ({ ...prev, user: option }));
                  setReassignErrors((prev) => ({ ...prev, user: '' }));
                }}
                onInputChange={(_, value, reason) => {
                  if (reason === 'input') setReassignUserSearch(value);
                }}
                noOptionsText={reassignUsersLoading ? 'Loading users...' : 'No matching user found'}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder="Start typing to search available users"
                    error={!!reassignErrors.user}
                    helperText={reassignErrors.user}
                    size="small"
                  />
                )}
                fullWidth
              />
              <Typography className="renewals-modal-help georama-Regular">
                Start typing to search available users.
              </Typography>
            </Box>
            <Box className="renewals-modal-field">
              <Typography className="text-labels client-form-label georama-Medium">
                Comment <span className="important-fields">*</span>
              </Typography>
              <TextField
                className="form-control-input border-radius-8 renewals-modal-remarks"
                value={reassignForm.comment}
                onChange={handleReassignChange('comment')}
                placeholder="Add reassignment or handover details..."
                multiline
                minRows={4}
                error={!!reassignErrors.comment}
                helperText={reassignErrors.comment}
                fullWidth
              />
            </Box>
          </DialogContent>
          <Box className="renewals-modal-actions">
            <Button className="client-mgmt-filter-clear-btn" onClick={handleCloseReassignDialog}>
              Cancel
            </Button>
            <Button
              className="btn-common-red border-radius-32"
              onClick={handleUpdateReassign}
              disabled={reassignMutation.isPending}
            >
              {reassignMode === 'bulk' ? 'Continue' : 'Update Assignment'}
            </Button>
          </Box>
        </Dialog>

        <ClientSaveSuccessDialog
          open={reassignSuccessOpen}
          title="Renewal Reassigned Successfully"
          message="The renewal lead owner has been updated successfully."
          primaryLabel="View Renewal Leads"
          showSecondary={false}
          onViewProfile={() => setReassignSuccessOpen(false)}
        />

        <TableContainer component={Box} className="renewals-table-wrap">
          <Table>
            <TableHead>
              <TableRow>
                {RENEWAL_COLUMNS.map((column) => (
                  <TableCell
                    key={column.key}
                    className={`renewals-head-cell renewals-col-${column.key}`}
                  >
                    {column.key === 'select' ? (
                      <Checkbox
                        size="small"
                        checked={allVisibleSelected}
                        indeterminate={!allVisibleSelected && someVisibleSelected}
                        onChange={handleSelectAllRows}
                        disabled={selectableRowIds.length === 0}
                        className="renewals-row-checkbox"
                      />
                    ) : column.label}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody className="table-body-bg">
              {rows.length > 0 ? (
                rows.map((row, index) => (
                  <TableRow key={row.uuid || row.id || index}>
                    {RENEWAL_COLUMNS.map((column) => (
                      <TableCell key={`${row.id || index}-${column.key}`} className={`renewals-col-${column.key}`}>
                        {renderCell(column.key, row, index)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={RENEWAL_COLUMNS.length} className="client-mgmt-no-data">
                    No renewal leads found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {totalCount > 0 && (
          <Box className="client-mgmt-pagination-wrap table-body-bg border-radius-bottom-8">
            <Typography className="client-mgmt-total-count georama-Medium">
              Total Renewal Leads: {totalCount}
            </Typography>
            <Box className="renewals-pagination-right">
              <FormControl size="small" className="renewals-page-size-control">
                <TextField
                  select
                  size="small"
                  value={pageSize}
                  onChange={handlePageSizeChange}
                >
                  {RENEWAL_LEAD_PAGE_SIZE_OPTIONS.map((option) => (
                    <MenuItem key={option} value={option}>{option} / page</MenuItem>
                  ))}
                </TextField>
              </FormControl>
              <Box className="client-mgmt-pagination">
                <Button
                  className="client-mgmt-pagination-nav"
                  onClick={() => handlePageChange(page - 1)}
                  disabled={page <= 1}
                  aria-label="Previous page"
                >
                  <ChevronLeftIcon fontSize="small" />
                </Button>
                <Box className="client-mgmt-pagination-pages">
                  {paginationItems.map((item) =>
                    typeof item === 'number' ? (
                      <Button
                        key={item}
                        className={`client-mgmt-pagination-page ${item === page ? 'client-mgmt-pagination-page-active' : ''}`}
                        onClick={() => handlePageChange(item)}
                        aria-current={item === page ? 'page' : undefined}
                      >
                        {item}
                      </Button>
                    ) : (
                      <Typography key={item} className="client-mgmt-pagination-ellipsis">
                        ...
                      </Typography>
                    ),
                  )}
                </Box>
                <Typography className="client-mgmt-pagination-label">of {totalPages}</Typography>
                <Button
                  className="client-mgmt-pagination-nav"
                  onClick={() => handlePageChange(page + 1)}
                  disabled={page >= totalPages}
                  aria-label="Next page"
                >
                  <ChevronRightIcon fontSize="small" />
                </Button>
              </Box>
            </Box>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default Renewals;
