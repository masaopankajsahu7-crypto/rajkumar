import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  Collapse,
  FormControl,
  IconButton,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import CloseIcon from '@mui/icons-material/Close';
import DownloadOutlinedIcon from '@mui/icons-material/DownloadOutlined';
import RefreshIcon from '@mui/icons-material/Refresh';
import CheckIcon from '@mui/icons-material/Check';
import ScheduleIcon from '@mui/icons-material/Schedule';
import SettingsIcon from '@mui/icons-material/Settings';
import DescriptionIcon from '@mui/icons-material/Description';
import { useQueryClient } from '@tanstack/react-query';
import { useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import { CLIENT_KDS_FIELDS, OPPORTUNITY_KDS_FIELDS, REPORT_KDS_FIELDS } from '../config/kdsFields.js';
import { queryKeys } from '../lib/queryKeys.js';
import { useKdsOptions, useReportList } from '../hooks/useFetchQueries.js';
import { generateReport, getKdsOptions, getReports, searchClientsByName } from '../services/api.jsx';
import { encodedRoutePath, ROUTES } from '../config/routes.js';
import {
  formatReportDate,
  formatReportLabel,
  REPORT_LIST_PAGE_SIZE,
} from '../utils/reportList.js';
import './Clients.css';
import './Reports.css';

const toInputDate = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getCurrentMonthRange = () => {
  const today = new Date();
  return {
    fromDate: toInputDate(new Date(today.getFullYear(), today.getMonth(), 1)),
    toDate: toInputDate(new Date(today.getFullYear(), today.getMonth() + 1, 0)),
  };
};

const getPaginationItems = (page, totalPages) => {
  if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);

  const visiblePages = [...new Set([1, totalPages, page - 1, page, page + 1])]
    .filter((pageNumber) => pageNumber >= 1 && pageNumber <= totalPages)
    .sort((first, second) => first - second);

  return visiblePages.reduce((items, pageNumber, index) => {
    const previousPage = visiblePages[index - 1];
    if (index > 0 && pageNumber - previousPage > 1) {
      items.push(`ellipsis-${previousPage}-${pageNumber}`);
    }
    items.push(pageNumber);
    return items;
  }, []);
};

const getStatusClass = (status) => {
  const normalized = String(status ?? '').trim().toUpperCase();
  if (normalized === 'READY') {
    return 'report-status--completed';
  }
  if (normalized.includes('FAIL') || normalized.includes('REJECT') || normalized.includes('ERROR')) {
    return 'report-status--failed';
  }
  return 'report-status--processing';
};

const getStatusLabel = (status) => {
  const normalized = String(status ?? '').trim().toUpperCase();
  if (normalized === 'READY') return 'Ready';
  if (normalized.includes('FAIL') || normalized.includes('REJECT') || normalized.includes('ERROR')) {
    return formatReportLabel(normalized);
  }
  return 'Processing';
};

const getReportTypeLabel = (reportTypeCode, labels = {}, reportTypeValue = '') => {
  const code = String(reportTypeCode ?? '').trim();
  const value = String(reportTypeValue ?? '').trim();
  if (value && value !== code) return value;
  return labels[code] ?? labels[value] ?? formatReportLabel(code);
};

const getReportFileHref = (fileUrl) => {
  const value = String(fileUrl ?? '').trim();
  if (!value) return '';
  if (/^(https?:|blob:|data:)/i.test(value)) return value;
  if (value.startsWith('/')) return `${window.location.origin}${value}`;
  return `${window.location.origin}/${value.replace(/^\/+/, '')}`;
};

const getGeneratedRequestId = (response) => {
  const payload = response?.payload ?? response?.data?.payload ?? response?.data ?? response;
  const report = payload?.report ?? payload?.reports?.[0] ?? payload;
  return String(
    report?.report_uuid ??
    report?.report_request_code ??
      report?.request_id ??
      report?.request_code ??
      report?.report_request_uuid ??
      '',
  ).trim();
};

const waitForReportsRefresh = () => new Promise((resolve) => setTimeout(resolve, 5));
const REPORT_BANNER_TIMEOUT_SECONDS = 10;
const DOWNLOAD_FEEDBACK_MS = 1800;
const REPORTS_ALL_ACCESS_DESIGNATIONS = new Set(['UDDVH', 'UDDBH', 'MIS']);
const PLACEMENT_TRACKER_REPORT_CODE = 'TAT_REPORT';

const Reports = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const designationCode = useSelector((state) => state?.user?.loggedData?.designation_code);
  const queryClient = useQueryClient();
  const downloadFeedbackTimerRef = useRef(null);
  const monthRange = useMemo(getCurrentMonthRange, []);
  const [reportRequestUUID, setReportRequestUUID] = useState(() =>
    String(location.state?.reportUUID ?? '').trim(),
  );
  const listFilters = useMemo(() => ({
    reportTypeCode: '',
    reportStatusCode: '',
    reportRequestUUID,
    ...(reportRequestUUID ? { fromDate: '', toDate: '' } : monthRange),
  }), [monthRange, reportRequestUUID]);
  const [page, setPage] = useState(1);
  const [generateOpen, setGenerateOpen] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [refreshingReports, setRefreshingReports] = useState(false);
  const [formError, setFormError] = useState('');
  const [generatedRequestId, setGeneratedRequestId] = useState('');
  const [downloadingReportId, setDownloadingReportId] = useState('');
  const [bannerCountdown, setBannerCountdown] = useState(REPORT_BANNER_TIMEOUT_SECONDS);
  const [formValues, setFormValues] = useState({
    reportTypeCode: '',
    clients: [],
    products: [],
    subProducts: [],
    clientVerticalCode: '',
    fromDate: monthRange.fromDate,
    toDate: monthRange.toDate,
  });
  const [clientSearch, setClientSearch] = useState('');
  const [clientOptions, setClientOptions] = useState([]);
  const [clientLoading, setClientLoading] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [productOptions, setProductOptions] = useState([]);
  const [productLoading, setProductLoading] = useState(false);
  const [subProductSearch, setSubProductSearch] = useState('');
  const [subProductOptions, setSubProductOptions] = useState([]);
  const [subProductLoading, setSubProductLoading] = useState(false);

  useEffect(() => {
    const routedUUID = String(location.state?.reportUUID ?? '').trim();
    if (!routedUUID) return;
    setReportRequestUUID(routedUUID);
    navigate(encodedRoutePath(ROUTES.reports), { replace: true, state: null });
  }, [location.state, navigate]);

  const { data: reportTypeOptions = [], isLoading: reportTypesLoading } = useKdsOptions(REPORT_KDS_FIELDS.reportType);
  const { data: verticalOptions = [], isLoading: verticalsLoading } = useKdsOptions(CLIENT_KDS_FIELDS.vertical);
  const canViewAllReportTypes = REPORTS_ALL_ACCESS_DESIGNATIONS.has(
    String(designationCode ?? '').trim().toUpperCase(),
  );
  const visibleReportTypeOptions = useMemo(
    () => canViewAllReportTypes
      ? reportTypeOptions
      : reportTypeOptions.filter(
        (option) => String(option.code ?? '').trim().toUpperCase() === PLACEMENT_TRACKER_REPORT_CODE,
      ),
    [canViewAllReportTypes, reportTypeOptions],
  );

  useEffect(() => {
    const search = clientSearch.trim();
    if (search.length < 2) {
      setClientOptions([]);
      setClientLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    const timer = window.setTimeout(async () => {
      setClientLoading(true);
      const results = await searchClientsByName(search, { source: 'client' });
      if (!ignoreResult) {
        setClientOptions(results);
        setClientLoading(false);
      }
    }, 350);

    return () => {
      ignoreResult = true;
      window.clearTimeout(timer);
    };
  }, [clientSearch]);

  useEffect(() => {
    const search = productSearch.trim();
    if (search.length < 2) {
      setProductOptions([]);
      setProductLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    const timer = window.setTimeout(async () => {
      setProductLoading(true);
      const results = await getKdsOptions({
        ...OPPORTUNITY_KDS_FIELDS.product,
        search,
        limit: 100,
      });
      if (!ignoreResult) {
        setProductOptions(results);
        setProductLoading(false);
      }
    }, 300);

    return () => {
      ignoreResult = true;
      window.clearTimeout(timer);
    };
  }, [productSearch]);

  useEffect(() => {
    const search = subProductSearch.trim();
    const selectedProducts = formValues.products;
    if (search.length < 2 || !selectedProducts.length) {
      setSubProductOptions([]);
      setSubProductLoading(false);
      return undefined;
    }

    let ignoreResult = false;
    setSubProductLoading(true);
    Promise.all(selectedProducts.map(async (product) => {
      const options = await getKdsOptions({
        ...OPPORTUNITY_KDS_FIELDS.subProduct,
        parentCode: product.code,
        search,
        limit: 100,
      });
      return options.map((option) => ({
        ...option,
        parentCode: option.parentCode || product.code,
      }));
    })).then((groups) => {
      if (ignoreResult) return;
      const uniqueOptions = new Map();
      groups.flat().forEach((option) => {
        const key = `${option.parentCode}:${option.code}`;
        if (!uniqueOptions.has(key)) uniqueOptions.set(key, option);
      });
      setSubProductOptions([...uniqueOptions.values()]);
    }).finally(() => {
      if (!ignoreResult) setSubProductLoading(false);
    });

    return () => {
      ignoreResult = true;
    };
  }, [formValues.products, subProductSearch]);

  const reportQuery = useReportList(page, '', listFilters);
  const reports = reportQuery.data?.list ?? [];
  const totalCount = reportQuery.data?.totalCount ?? 0;
  const totalPages = Math.max(Math.ceil(totalCount / REPORT_LIST_PAGE_SIZE), 1);
  const paginationItems = useMemo(
    () => getPaginationItems(page, totalPages),
    [page, totalPages],
  );
  const reportTypeLabels = useMemo(
    () => reportTypeOptions.reduce((labels, option) => ({
      ...labels,
      [option.code]: option.value,
    }), {}),
    [reportTypeOptions],
  );
  const selectedReportType = useMemo(
    () => visibleReportTypeOptions.find((option) => String(option.code) === String(formValues.reportTypeCode)) ?? null,
    [formValues.reportTypeCode, visibleReportTypeOptions],
  );
  const clientSearchOptions = useMemo(() => {
    const options = new Map();
    [...formValues.clients, ...clientOptions].forEach((client) => {
      if (client.clientUUID) options.set(String(client.clientUUID), client);
    });
    return [...options.values()];
  }, [clientOptions, formValues.clients]);
  const productSearchOptions = useMemo(() => {
    const options = new Map();
    [...formValues.products, ...productOptions].forEach((product) => {
      if (product.code) options.set(String(product.code), product);
    });
    return [...options.values()];
  }, [formValues.products, productOptions]);
  const subProductSearchOptions = useMemo(() => {
    const options = new Map();
    [...formValues.subProducts, ...subProductOptions].forEach((subProduct) => {
      const key = `${subProduct.parentCode}:${subProduct.code}`;
      if (subProduct.code) options.set(key, subProduct);
    });
    return [...options.values()];
  }, [formValues.subProducts, subProductOptions]);

  useEffect(() => {
    if (!visibleReportTypeOptions.length) {
      if (!reportTypesLoading && formValues.reportTypeCode) {
        setFormValues((current) => ({ ...current, reportTypeCode: '' }));
      }
      return;
    }

    const selectedIsAvailable = visibleReportTypeOptions.some(
      (option) => String(option.code) === String(formValues.reportTypeCode),
    );
    if (selectedIsAvailable) return;

    const preferredOption = visibleReportTypeOptions.find(
      (option) => String(option.code ?? '').trim().toUpperCase() === PLACEMENT_TRACKER_REPORT_CODE,
    ) ?? visibleReportTypeOptions[0];
    setFormValues((current) => ({ ...current, reportTypeCode: preferredOption.code }));
  }, [formValues.reportTypeCode, reportTypesLoading, visibleReportTypeOptions]);

  const handleFormChange = (field) => (event) => {
    setFormError('');
    setFormValues((current) => ({ ...current, [field]: event.target.value }));
  };

  const handleReportTypeChange = (_, selected) => {
    setFormError('');
    setFormValues((current) => ({ ...current, reportTypeCode: selected?.code ?? '' }));
  };

  const handleClientsChange = (_, clients) => {
    setFormValues((current) => ({ ...current, clients }));
  };

  const handleProductsChange = (_, products) => {
    const selectedCodes = new Set(products.map((product) => String(product.code)));
    setFormValues((current) => ({
      ...current,
      products,
      subProducts: current.subProducts.filter((subProduct) => selectedCodes.has(String(subProduct.parentCode))),
    }));
    setSubProductSearch('');
    setSubProductOptions([]);
  };

  const handleSubProductsChange = (_, subProducts) => {
    setFormValues((current) => ({ ...current, subProducts }));
  };

  const handleClientVerticalChange = (event) => {
    setFormValues((current) => ({ ...current, clientVerticalCode: event.target.value }));
  };

  useEffect(() => {
    if (!generatedRequestId) return undefined;

    setBannerCountdown(REPORT_BANNER_TIMEOUT_SECONDS);
    const timer = window.setInterval(() => {
      setBannerCountdown((current) => {
        if (current <= 1) {
          window.clearInterval(timer);
          setGeneratedRequestId('');
          return 0;
        }
        return current - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [generatedRequestId]);

  useEffect(() => () => {
    if (downloadFeedbackTimerRef.current) {
      window.clearTimeout(downloadFeedbackTimerRef.current);
    }
  }, []);

  const refreshFirstPage = async () => {
    setRefreshingReports(true);
    try {
      queryClient.removeQueries({ queryKey: queryKeys.reportsRoot(), type: 'inactive' });
      queryClient.setQueryData(queryKeys.reports(1, { ...listFilters, search: '' }), undefined);
      await waitForReportsRefresh();
      const refreshed = await getReports({ page: 1, search: '', filters: listFilters });
      queryClient.setQueryData(queryKeys.reports(1, { ...listFilters, search: '' }), refreshed);
      setPage(1);
    } finally {
      setRefreshingReports(false);
    }
  };

  const handleGenerateReport = async () => {
    if (!formValues.reportTypeCode || !formValues.fromDate || !formValues.toDate) {
      setFormError('Report Type, From Date and To Date are required.');
      return;
    }
    if (formValues.fromDate > formValues.toDate) {
      setFormError('From Date cannot be later than To Date.');
      return;
    }

    setGenerating(true);
    setFormError('');
    try {
      const response = await generateReport({
        reportTypeCode: formValues.reportTypeCode,
        fromDate: formValues.fromDate,
        toDate: formValues.toDate,
        clientUUIDs: formValues.clients.map((client) => client.clientUUID),
        opportunityProductCodes: formValues.products.map((product) => product.code),
        opportunitySubProductCodes: formValues.subProducts.map((subProduct) => subProduct.code),
        clientVerticalCode: formValues.clientVerticalCode,
      });
      setGeneratedRequestId(getGeneratedRequestId(response));
      setGenerateOpen(false);
      toast.success(response?.message ?? 'Report generation request submitted successfully.');
      refreshFirstPage().catch((refreshError) => {
        toast.error(refreshError?.message ?? 'Unable to refresh report status.');
      });
    } catch (error) {
      setFormError(error?.message ?? 'Unable to generate report.');
    } finally {
      setGenerating(false);
    }
  };

  const handleRefresh = async () => {
    setGeneratedRequestId('');
    try {
      await refreshFirstPage();
      toast.success('Report status refreshed.');
    } catch (error) {
      toast.error(error?.message ?? 'Unable to refresh report status.');
    }
  };

  const handleReportDownload = (reportKey) => (event) => {
    if (downloadingReportId === reportKey) {
      event.preventDefault();
      return;
    }

    setDownloadingReportId(reportKey);
    if (downloadFeedbackTimerRef.current) {
      window.clearTimeout(downloadFeedbackTimerRef.current);
    }
    downloadFeedbackTimerRef.current = window.setTimeout(() => {
      setDownloadingReportId('');
      downloadFeedbackTimerRef.current = null;
    }, DOWNLOAD_FEEDBACK_MS);
  };

  return (
    <Box className="client-mgmt-page report-mgmt-page">
      <BackdropLoader loading={reportQuery.isLoading || reportQuery.isFetching || generating || refreshingReports} />
      {generatedRequestId && (
        <Box className="report-generation-banner">
          <Box className="report-generation-banner-icon">
            <SettingsIcon fontSize="small" />
          </Box>
          <Box className="report-generation-banner-copy">
            <Typography className="report-generation-banner-title">
              Your report is being prepared
            </Typography>
            <Typography className="report-generation-banner-text">
              You can wait here or continue working. Once ready, your report will be available under Reports below. Thank you.
            </Typography>
          </Box>
          <Box className="report-generation-banner-side">
            <Typography className="report-generation-banner-id">
              Request ID: {generatedRequestId}
            </Typography>
            <Button
              className="report-generation-banner-close"
              onClick={() => setGeneratedRequestId('')}
            >
              Close in {bannerCountdown}s
            </Button>
          </Box>
        </Box>
      )}
      <Box className="client-mgmt-paper report-mgmt-paper">
        <Box className="client-mgmt-head-block table-body-bg border-radius-top-8">
          <Box className="client-mgmt-toolbar client-mgmt-toolbar-head">
            <Box className="client-mgmt-toolbar-left">
              <Box className="client-mgmt-page-title-wrap">
                <Typography className="client-mgmt-title">Reports</Typography>
              </Box>
            </Box>
            <Box className="client-mgmt-toolbar-right report-mgmt-toolbar-actions">
              <Button
                className="btn-common-red client-mgmt-btn-add report-mgmt-new-btn"
                startIcon={<DescriptionIcon fontSize="small" />}
                onClick={() => {
                  setFormError('');
                  setGenerateOpen((open) => !open);
                }}
              >
                New Report
              </Button>
              <Button
                className="report-mgmt-secondary-btn"
                startIcon={<RefreshIcon fontSize="small" />}
                onClick={handleRefresh}
                disabled={reportQuery.isFetching || refreshingReports}
              >
                Refresh Status
              </Button>
            </Box>
          </Box>
        </Box>

        <Collapse in={generateOpen} unmountOnExit>
          <Box className="report-generate-section">
            <Box className="report-generate-heading">
              <Box>
                <Typography className="report-generate-title">Generate Report</Typography>
                <Typography className="report-generate-subtitle">
                  Choose the report type and period.
                </Typography>
              </Box>
              <Tooltip title="Close">
                <IconButton size="small" onClick={() => setGenerateOpen(false)}>
                  <CloseIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>

            <Box className="report-generate-row">
              <Box className="report-generate-grid">
                <Box className="report-form-field report-form-field--type">
                  <Typography className="report-form-label">Report Type *</Typography>
                  <FormControl size="small" fullWidth>
                    <Autocomplete
                      className="client-kds-autocomplete form-control-input border-radius-8"
                      options={visibleReportTypeOptions}
                      value={selectedReportType}
                      loading={reportTypesLoading}
                      autoHighlight
                      getOptionLabel={(option) => option?.value ?? ''}
                      isOptionEqualToValue={(option, selected) => option.code === selected.code}
                      noOptionsText={reportTypesLoading ? 'Loading report types...' : 'No report types found'}
                      onChange={handleReportTypeChange}
                      slotProps={{
                        paper: { className: 'client-kds-menu-paper' },
                        listbox: { className: 'client-kds-menu-list' },
                      }}
                      renderInput={(params) => (
                        <TextField {...params} size="small" placeholder="Select report type" />
                      )}
                      renderOption={(props, option) => {
                        const { key, className, ...optionProps } = props;
                        return (
                          <li key={key} {...optionProps} className={`${className ?? ''} client-kds-menu-item client-kds-menu-item--simple`}>
                            {option.value}
                          </li>
                        );
                      }}
                    />
                  </FormControl>
                </Box>
                <Box className="report-form-field report-form-field--date">
                  <Typography className="report-form-label">From Date *</Typography>
                  <TextField
                    type="date"
                    size="small"
                    value={formValues.fromDate}
                    onChange={handleFormChange('fromDate')}
                    inputProps={{ max: formValues.toDate || undefined }}
                  />
                </Box>
                <Box className="report-form-field report-form-field--date">
                  <Typography className="report-form-label">To Date *</Typography>
                  <TextField
                    type="date"
                    size="small"
                    value={formValues.toDate}
                    onChange={handleFormChange('toDate')}
                    inputProps={{ min: formValues.fromDate || undefined }}
                  />
                </Box>
              </Box>

              <Box className="report-generate-actions">
                <Button className="report-mgmt-cancel-btn" onClick={() => setGenerateOpen(false)}>
                  Cancel
                </Button>
                <Button
                  className="btn-common-red border-radius-32 report-generate-btn"
                  onClick={handleGenerateReport}
                  disabled={generating}
                >
                  Generate Excel
                </Button>
              </Box>
            </Box>
            {formError && <Typography className="report-form-error">{formError}</Typography>}
          </Box>
        </Collapse>

        <TableContainer component={Box} className="client-mgmt-table-wrap report-mgmt-table-wrap">
          <Table>
            <TableHead>
              <TableRow>
                <TableCell className="report-col-request-id">Request ID</TableCell>
                <TableCell className="report-col-type">Report Type</TableCell>
                <TableCell className="report-col-date-range">Date Range</TableCell>
                <TableCell className="report-col-requested-on">Requested On</TableCell>
                <TableCell className="report-col-status">Status</TableCell>
                <TableCell className="report-col-action">File / Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody className="table-body-bg">
              {reports.length > 0 ? reports.map((report, index) => {
                const fileHref = getReportFileHref(report.fileUrl);
                const reportKey = String(report.requestId || report.fileName || `${page}-${index}`);
                const isDownloading = downloadingReportId === reportKey;
                const reportStatus = report.statusCode || report.status;
                const isReady = String(reportStatus ?? '').trim().toUpperCase() === 'READY';
                const statusText = getStatusLabel(reportStatus);
                return (
                  <TableRow key={report.requestId || `${page}-${index}`}>
                    <TableCell className="report-col-request-id">
                      <Tooltip title={report.requestId || '---'}>
                        <span className="report-request-id">{report.requestId || '---'}</span>
                      </Tooltip>
                    </TableCell>
                    <TableCell className="report-col-type">
                      {getReportTypeLabel(report.reportTypeCode, reportTypeLabels, report.reportType)}
                    </TableCell>
                    <TableCell className="report-col-date-range">
                      {formatReportDate(report.fromDate)} - {formatReportDate(report.toDate)}
                    </TableCell>
                    <TableCell className="report-col-requested-on">
                      <span className="report-requested-at">
                        {formatReportDate(report.requestedOn, { includeTime: true })}
                      </span>
                      {report.requestedBy && (
                        <span className="report-requested-by">{report.requestedBy}</span>
                      )}
                    </TableCell>
                    <TableCell className="report-col-status">
                      <span className={`report-status ${getStatusClass(reportStatus)}`}>
                        {isReady ? (
                          <CheckIcon className="report-status-icon" />
                        ) : (
                          <SettingsIcon className="report-status-icon report-status-icon--spin" />
                        )}
                        {statusText}
                      </span>
                    </TableCell>
                    <TableCell className="report-col-action">
                      {isReady && fileHref ? (
                        <Button
                          component="a"
                          href={fileHref}
                          target="_blank"
                          rel="noreferrer"
                          download={report.fileName || undefined}
                          className="report-download-btn"
                          startIcon={
                            isDownloading ? (
                              <CircularProgress className="report-download-spinner" size={14} thickness={5} />
                            ) : (
                              <DownloadOutlinedIcon fontSize="small" />
                            )
                          }
                          onClick={handleReportDownload(reportKey)}
                          aria-busy={isDownloading}
                        >
                          {isDownloading ? 'Preparing...' : 'Download'}
                        </Button>
                      ) : (
                        <Typography component="span" className="report-processing-action">
                          <ScheduleIcon className="report-processing-action-icon" />
                          Processing...
                        </Typography>
                      )}
                    </TableCell>
                  </TableRow>
                );
              }) : (
                <TableRow>
                  <TableCell colSpan={6} className="client-mgmt-no-data">
                    {reportQuery.isError ? reportQuery.error?.message : 'No report requests found.'}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {totalCount > 0 && (
          <Box className="client-mgmt-pagination-wrap table-body-bg border-radius-bottom-8">
            <Typography className="client-mgmt-total-count">
              Total Reports: {totalCount}
            </Typography>
            <Box className="client-mgmt-pagination">
              <Button
                className="client-mgmt-pagination-nav"
                disabled={page <= 1}
                onClick={() => setPage((current) => current - 1)}
                aria-label="Previous page"
              >
                <ChevronLeftIcon fontSize="small" />
              </Button>
              <Box className="client-mgmt-pagination-pages">
                {paginationItems.map((item) => typeof item === 'number' ? (
                  <Button
                    key={item}
                    className={`client-mgmt-pagination-page ${item === page ? 'client-mgmt-pagination-page-active' : ''}`}
                    onClick={() => setPage(item)}
                  >
                    {item}
                  </Button>
                ) : (
                  <Typography key={item} className="client-mgmt-pagination-ellipsis">...</Typography>
                ))}
              </Box>
              <Typography className="client-mgmt-pagination-label">Page {page} of {totalPages}</Typography>
              <Button
                className="client-mgmt-pagination-nav"
                disabled={page >= totalPages}
                onClick={() => setPage((current) => current + 1)}
                aria-label="Next page"
              >
                <ChevronRightIcon fontSize="small" />
              </Button>
            </Box>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default Reports;
