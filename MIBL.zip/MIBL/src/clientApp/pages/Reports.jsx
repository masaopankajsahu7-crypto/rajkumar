import { useEffect, useMemo, useState } from 'react';
import {
  Box,
  Button,
  Collapse,
  FormControl,
  IconButton,
  MenuItem,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import CloseIcon from '@mui/icons-material/Close';
import DownloadOutlinedIcon from '@mui/icons-material/DownloadOutlined';
import RefreshIcon from '@mui/icons-material/Refresh';
import CheckIcon from '@mui/icons-material/Check';
import ScheduleIcon from '@mui/icons-material/Schedule';
import SettingsIcon from '@mui/icons-material/Settings';
import DescriptionIcon from '@mui/icons-material/Description';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-toastify';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import { queryKeys } from '../lib/queryKeys.js';
import { useReportList } from '../hooks/useFetchQueries.js';
import { generateReport, getReports } from '../services/api.jsx';
import {
  formatReportDate,
  formatReportLabel,
  REPORT_LIST_PAGE_SIZE,
} from '../utils/reportList.js';
import './Clients.css';
import './Reports.css';

const REPORT_TYPE_OPTIONS = [{ code: 'TAT_REPORT', value: 'Performance Tracker' }];

const REPORT_TYPE_LABELS = REPORT_TYPE_OPTIONS.reduce((labels, option) => ({
  ...labels,
  [option.code]: option.value,
}), {});

const toInputDate = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getCurrentMonthRange = () => {
  const today = new Date();
  return {
    fromDate: toInputDate(new Date(today.getFullYear(), today.getMonth(), 1)),
    toDate: toInputDate(new Date(today.getFullYear(), today.getMonth() + 1, 0)),
  };
};

const getPaginationItems = (page, totalPages) => {
  if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);

  const visiblePages = [...new Set([1, totalPages, page - 1, page, page + 1])]
    .filter((pageNumber) => pageNumber >= 1 && pageNumber <= totalPages)
    .sort((first, second) => first - second);

  return visiblePages.reduce((items, pageNumber, index) => {
    const previousPage = visiblePages[index - 1];
    if (index > 0 && pageNumber - previousPage > 1) {
      items.push(`ellipsis-${previousPage}-${pageNumber}`);
    }
    items.push(pageNumber);
    return items;
  }, []);
};

const getStatusClass = (status) => {
  const normalized = String(status ?? '').trim().toUpperCase();
  if (normalized === 'READY') {
    return 'report-status--completed';
  }
  if (normalized.includes('FAIL') || normalized.includes('REJECT') || normalized.includes('ERROR')) {
    return 'report-status--failed';
  }
  return 'report-status--processing';
};

const getStatusLabel = (status) => {
  const normalized = String(status ?? '').trim().toUpperCase();
  if (normalized === 'READY') return 'Ready';
  if (normalized.includes('FAIL') || normalized.includes('REJECT') || normalized.includes('ERROR')) {
    return formatReportLabel(normalized);
  }
  return 'Processing';
};

const getReportTypeLabel = (reportType) => {
  const value = String(reportType ?? '').trim();
  return REPORT_TYPE_LABELS[value] ?? formatReportLabel(value);
};

const getReportFileHref = (fileUrl) => {
  const value = String(fileUrl ?? '').trim();
  if (!value) return '';
  if (/^(https?:|blob:|data:)/i.test(value)) return value;
  if (value.startsWith('/')) return `${window.location.origin}${value}`;
  return `${window.location.origin}/${value.replace(/^\/+/, '')}`;
};

const getGeneratedRequestId = (response) => {
  const payload = response?.payload ?? response?.data?.payload ?? response?.data ?? response;
  const report = payload?.report ?? payload?.reports?.[0] ?? payload;
  return String(
    report?.report_request_code ??
      report?.request_id ??
      report?.request_code ??
      report?.report_request_uuid ??
      '',
  ).trim();
};

const waitForReportsRefresh = () => new Promise((resolve) => setTimeout(resolve, 5));
const REPORT_BANNER_TIMEOUT_SECONDS = 10;

const Reports = () => {
  const queryClient = useQueryClient();
  const monthRange = useMemo(getCurrentMonthRange, []);
  const listFilters = useMemo(() => ({
    reportTypeCode: '',
    reportStatusCode: '',
    ...monthRange,
  }), [monthRange]);
  const [page, setPage] = useState(1);
  const [generateOpen, setGenerateOpen] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [refreshingReports, setRefreshingReports] = useState(false);
  const [formError, setFormError] = useState('');
  const [generatedRequestId, setGeneratedRequestId] = useState('');
  const [bannerCountdown, setBannerCountdown] = useState(REPORT_BANNER_TIMEOUT_SECONDS);
  const [formValues, setFormValues] = useState({
    reportTypeCode: 'TAT_REPORT',
    fromDate: monthRange.fromDate,
    toDate: monthRange.toDate,
  });

  const reportQuery = useReportList(page, '', listFilters);
  const reports = reportQuery.data?.list ?? [];
  const totalCount = reportQuery.data?.totalCount ?? 0;
  const totalPages = Math.max(Math.ceil(totalCount / REPORT_LIST_PAGE_SIZE), 1);
  const paginationItems = useMemo(
    () => getPaginationItems(page, totalPages),
    [page, totalPages],
  );

  const handleFormChange = (field) => (event) => {
    setFormError('');
    setFormValues((current) => ({ ...current, [field]: event.target.value }));
  };

  useEffect(() => {
    if (!generatedRequestId) return undefined;

    setBannerCountdown(REPORT_BANNER_TIMEOUT_SECONDS);
    const timer = window.setInterval(() => {
      setBannerCountdown((current) => {
        if (current <= 1) {
          window.clearInterval(timer);
          setGeneratedRequestId('');
          return 0;
        }
        return current - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [generatedRequestId]);

  const refreshFirstPage = async () => {
    setRefreshingReports(true);
    try {
      queryClient.removeQueries({ queryKey: queryKeys.reportsRoot(), type: 'inactive' });
      queryClient.setQueryData(queryKeys.reports(1, { ...listFilters, search: '' }), undefined);
      await waitForReportsRefresh();
      const refreshed = await getReports({ page: 1, search: '', filters: listFilters });
      queryClient.setQueryData(queryKeys.reports(1, { ...listFilters, search: '' }), refreshed);
      setPage(1);
    } finally {
      setRefreshingReports(false);
    }
  };

  const handleGenerateReport = async () => {
    if (!formValues.reportTypeCode || !formValues.fromDate || !formValues.toDate) {
      setFormError('Report Type, From Date and To Date are required.');
      return;
    }
    if (formValues.fromDate > formValues.toDate) {
      setFormError('From Date cannot be later than To Date.');
      return;
    }

    setGenerating(true);
    setFormError('');
    try {
      const response = await generateReport({
        reportTypeCode: formValues.reportTypeCode,
        fromDate: formValues.fromDate,
        toDate: formValues.toDate,
      });
      setGeneratedRequestId(getGeneratedRequestId(response));
      await refreshFirstPage();
      setGenerateOpen(false);
      toast.success(response?.message ?? 'Report generation request submitted successfully.');
    } catch (error) {
      setFormError(error?.message ?? 'Unable to generate report.');
    } finally {
      setGenerating(false);
    }
  };

  const handleRefresh = async () => {
    setGeneratedRequestId('');
    try {
      await refreshFirstPage();
      toast.success('Report status refreshed.');
    } catch (error) {
      toast.error(error?.message ?? 'Unable to refresh report status.');
    }
  };

  return (
    <Box className="client-mgmt-page report-mgmt-page">
      <BackdropLoader loading={reportQuery.isLoading || reportQuery.isFetching || generating || refreshingReports} />
      {generatedRequestId && (
        <Box className="report-generation-banner">
          <Box className="report-generation-banner-icon">
            <SettingsIcon fontSize="small" />
          </Box>
          <Box className="report-generation-banner-copy">
            <Typography className="report-generation-banner-title">
              Your report is being prepared
            </Typography>
            <Typography className="report-generation-banner-text">
              You can wait here or continue working. Once ready, your report will be available under Reports below. Thank you.
            </Typography>
          </Box>
          <Box className="report-generation-banner-side">
            <Typography className="report-generation-banner-id">
              Request ID: {generatedRequestId}
            </Typography>
            <Button
              className="report-generation-banner-close"
              onClick={() => setGeneratedRequestId('')}
            >
              Close in {bannerCountdown}s
            </Button>
          </Box>
        </Box>
      )}
      <Box className="client-mgmt-paper report-mgmt-paper">
        <Box className="client-mgmt-head-block table-body-bg border-radius-top-8">
          <Box className="client-mgmt-toolbar client-mgmt-toolbar-head">
            <Box className="client-mgmt-toolbar-left">
              <Box className="client-mgmt-page-title-wrap">
                <Typography className="client-mgmt-title">Reports</Typography>
              </Box>
            </Box>
            <Box className="client-mgmt-toolbar-right report-mgmt-toolbar-actions">
              <Button
                className="btn-common-red client-mgmt-btn-add report-mgmt-new-btn"
                startIcon={<DescriptionIcon fontSize="small" />}
                onClick={() => {
                  setFormError('');
                  setGenerateOpen((open) => !open);
                }}
              >
                New Report
              </Button>
              <Button
                className="report-mgmt-secondary-btn"
                startIcon={<RefreshIcon fontSize="small" />}
                onClick={handleRefresh}
                disabled={reportQuery.isFetching || refreshingReports}
              >
                Refresh Status
              </Button>
            </Box>
          </Box>
        </Box>

        <Collapse in={generateOpen} unmountOnExit>
          <Box className="report-generate-section">
            <Box className="report-generate-heading">
              <Box>
                <Typography className="report-generate-title">Generate Report</Typography>
                <Typography className="report-generate-subtitle">
                  Choose the report type and period.
                </Typography>
              </Box>
              <Tooltip title="Close">
                <IconButton size="small" onClick={() => setGenerateOpen(false)}>
                  <CloseIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>

            <Box className="report-generate-row">
              <Box className="report-generate-grid">
                <Box className="report-form-field report-form-field--type">
                  <Typography className="report-form-label">Report Type *</Typography>
                  <FormControl size="small" fullWidth>
                    <Select
                      value={formValues.reportTypeCode}
                      onChange={handleFormChange('reportTypeCode')}
                      displayEmpty
                    >
                      {REPORT_TYPE_OPTIONS.map((option) => (
                        <MenuItem key={option.code} value={option.code}>{option.value}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Box>
                <Box className="report-form-field report-form-field--date">
                  <Typography className="report-form-label">From Date *</Typography>
                  <TextField
                    type="date"
                    size="small"
                    value={formValues.fromDate}
                    onChange={handleFormChange('fromDate')}
                    inputProps={{ max: formValues.toDate || undefined }}
                  />
                </Box>
                <Box className="report-form-field report-form-field--date">
                  <Typography className="report-form-label">To Date *</Typography>
                  <TextField
                    type="date"
                    size="small"
                    value={formValues.toDate}
                    onChange={handleFormChange('toDate')}
                    inputProps={{ min: formValues.fromDate || undefined }}
                  />
                </Box>
              </Box>

              <Box className="report-generate-actions">
                <Button className="report-mgmt-cancel-btn" onClick={() => setGenerateOpen(false)}>
                  Cancel
                </Button>
                <Button
                  className="btn-common-red border-radius-32 report-generate-btn"
                  onClick={handleGenerateReport}
                  disabled={generating}
                >
                  Generate Excel
                </Button>
              </Box>
            </Box>
            {formError && <Typography className="report-form-error">{formError}</Typography>}
          </Box>
        </Collapse>

        <TableContainer component={Box} className="client-mgmt-table-wrap report-mgmt-table-wrap">
          <Table>
            <TableHead>
              <TableRow>
                <TableCell className="report-col-request-id">Request ID</TableCell>
                <TableCell className="report-col-type">Report Type</TableCell>
                <TableCell className="report-col-date-range">Date Range</TableCell>
                <TableCell className="report-col-requested-on">Requested On</TableCell>
                <TableCell className="report-col-status">Status</TableCell>
                <TableCell className="report-col-action">File / Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody className="table-body-bg">
              {reports.length > 0 ? reports.map((report, index) => {
                const fileHref = getReportFileHref(report.fileUrl);
                const reportStatus = report.statusCode || report.status;
                const isReady = String(reportStatus ?? '').trim().toUpperCase() === 'READY';
                const statusText = getStatusLabel(reportStatus);
                return (
                  <TableRow key={report.requestId || `${page}-${index}`}>
                    <TableCell className="report-col-request-id">
                      <Tooltip title={report.requestId || '---'}>
                        <span className="report-request-id">{report.requestId || '---'}</span>
                      </Tooltip>
                    </TableCell>
                    <TableCell className="report-col-type">
                      {getReportTypeLabel(report.reportTypeCode || report.reportType)}
                    </TableCell>
                    <TableCell className="report-col-date-range">
                      {formatReportDate(report.fromDate)} - {formatReportDate(report.toDate)}
                    </TableCell>
                    <TableCell className="report-col-requested-on">
                      <span className="report-requested-at">
                        {formatReportDate(report.requestedOn, { includeTime: true })}
                      </span>
                      {report.requestedBy && (
                        <span className="report-requested-by">{report.requestedBy}</span>
                      )}
                    </TableCell>
                    <TableCell className="report-col-status">
                      <span className={`report-status ${getStatusClass(reportStatus)}`}>
                        {isReady ? (
                          <CheckIcon className="report-status-icon" />
                        ) : (
                          <SettingsIcon className="report-status-icon report-status-icon--spin" />
                        )}
                        {statusText}
                      </span>
                    </TableCell>
                    <TableCell className="report-col-action">
                      {isReady && fileHref ? (
                        <Button
                          component="a"
                          href={fileHref}
                          target="_blank"
                          rel="noreferrer"
                          download={report.fileName || undefined}
                          className="report-download-btn"
                          startIcon={<DownloadOutlinedIcon fontSize="small" />}
                        >
                          Download
                        </Button>
                      ) : (
                        <Typography component="span" className="report-processing-action">
                          <ScheduleIcon className="report-processing-action-icon" />
                          Processing...
                        </Typography>
                      )}
                    </TableCell>
                  </TableRow>
                );
              }) : (
                <TableRow>
                  <TableCell colSpan={6} className="client-mgmt-no-data">
                    {reportQuery.isError ? reportQuery.error?.message : 'No report requests found.'}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {totalCount > 0 && (
          <Box className="client-mgmt-pagination-wrap table-body-bg border-radius-bottom-8">
            <Typography className="client-mgmt-total-count">
              Total Reports: {totalCount}
            </Typography>
            <Box className="client-mgmt-pagination">
              <Button
                className="client-mgmt-pagination-nav"
                disabled={page <= 1}
                onClick={() => setPage((current) => current - 1)}
                aria-label="Previous page"
              >
                <ChevronLeftIcon fontSize="small" />
              </Button>
              <Box className="client-mgmt-pagination-pages">
                {paginationItems.map((item) => typeof item === 'number' ? (
                  <Button
                    key={item}
                    className={`client-mgmt-pagination-page ${item === page ? 'client-mgmt-pagination-page-active' : ''}`}
                    onClick={() => setPage(item)}
                  >
                    {item}
                  </Button>
                ) : (
                  <Typography key={item} className="client-mgmt-pagination-ellipsis">...</Typography>
                ))}
              </Box>
              <Typography className="client-mgmt-pagination-label">Page {page} of {totalPages}</Typography>
              <Button
                className="client-mgmt-pagination-nav"
                disabled={page >= totalPages}
                onClick={() => setPage((current) => current + 1)}
                aria-label="Next page"
              >
                <ChevronRightIcon fontSize="small" />
              </Button>
            </Box>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default Reports;
