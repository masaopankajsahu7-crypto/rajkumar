import { useMemo, useState } from 'react';
import { Box, Button, FormControl, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import BackdropLoader from '../components/Loader/BackdropLoader.jsx';
import { useNavigate } from 'react-router-dom';
import { useUserList } from '../hooks/useFetchQueries.js';
import { getTotalPages, parseUserListResponse } from '../utils/userList.js';
import { USER_MESSAGES as MSG } from '../config/messages/user.js';
import { ROUTES } from '../config/routes.js';
import { sanitizeByField } from '../utils/fieldUtils.js';
import './UserManagement.css';

const UserManagement = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const { data: response, isLoading, isFetching } = useUserList(page);

  const { list: userData, totalCount } = useMemo(() => parseUserListResponse(response, page), [response, page]);
  const totalPages = useMemo(() => getTotalPages(totalCount), [totalCount]);
  const pageOptions = useMemo(
    () => Array.from({ length: totalPages }, (_, index) => index + 1),
    [totalPages],
  );

  const filteredData = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return userData;
    return userData.filter((row) =>
      Object.values(row).some((value) => String(value ?? '').toLowerCase().includes(query)),
    );
  }, [search, userData]);

  const tableHeaders = useMemo(() => {
    const keys = new Set();
    filteredData.forEach((item) => {
      Object.keys(item || {}).forEach((key) => keys.add(key));
    });
    return [...keys];
  }, [filteredData]);

  const handlePageChange = (nextPage) => {
    if (nextPage === page || nextPage < 1 || nextPage > totalPages) return;
    setPage(nextPage);
  };

  const handleAddUser = () => {
    navigate(ROUTES.userManagementCreate);
  };

  const handlePrevPage = () => {
    handlePageChange(page - 1);
  };

  const handleNextPage = () => {
    handlePageChange(page + 1);
  };

  return (
    <Box className="user-mgmt-page">
      <BackdropLoader loading={isLoading || isFetching} />
      <Paper className="user-mgmt-paper table-auto-width">
        <Box className="table-body-bg border-radius-top-8 user-mgmt-toolbar user-mgmt-toolbar-head">
          <Typography className="georama-SemiBold fs-24">{MSG.title}</Typography>
          <Box className="user-mgmt-toolbar-right">
            <Button className="btn-common-red user-mgmt-btn-add" onClick={handleAddUser}>
              {MSG.addNewUser}
            </Button>
            <TextField
              className="user-mgmt-search"
              size="small"
              placeholder={MSG.search}
              value={search}
              onChange={(e) => setSearch(sanitizeByField('search', e.target.value))}
            />
          </Box>
        </Box>

        <TableContainer component={Box} className="user-mgmt-table-wrap">
          <Table>
            <TableHead>
              <TableRow>
                {tableHeaders.map((header) => (
                  <TableCell key={header} className="p-3 georama-Medium body-formbg fw-none">
                    {header}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody className="table-body-bg">
              {filteredData.length > 0 ? (
                filteredData.map((row, idx) => (
                  <TableRow key={idx}>
                    {tableHeaders.map((header) => (
                      <TableCell key={`${idx}-${header}`} className="p-4 georama-Regular fs-14">
                        {String(row?.[header] ?? '')}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={Math.max(tableHeaders.length, 1)} className="user-mgmt-no-data">
                    {MSG.noDataFound}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {totalPages > 1 && (
          <Box className="user-mgmt-pagination-wrap table-body-bg border-radius-bottom-8">
            <Box className="user-mgmt-pagination">
              <Button
                className="user-mgmt-pagination-nav"
                disabled={page <= 1}
                onClick={handlePrevPage}
                aria-label={MSG.previousPage}
              >
                <ChevronLeftIcon fontSize="small" />
              </Button>

              <Typography className="user-mgmt-pagination-label">{MSG.page}</Typography>

              <FormControl size="small" className="user-mgmt-page-select form-control-input border-radius-8">
                <Select
                  value={page}
                  onChange={(e) => handlePageChange(Number(e.target.value))}
                  MenuProps={{ PaperProps: { className: 'user-mgmt-page-select-menu' } }}
                >
                  {pageOptions.map((pageNumber) => (
                    <MenuItem key={pageNumber} value={pageNumber}>
                      {pageNumber}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <Typography className="user-mgmt-pagination-label">{MSG.pageOf(totalPages)}</Typography>

              <Button
                className="user-mgmt-pagination-nav"
                disabled={page >= totalPages}
                onClick={handleNextPage}
                aria-label={MSG.nextPage}
              >
                <ChevronRightIcon fontSize="small" />
              </Button>
            </Box>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default UserManagement;
