// LOCKED — Approved Add User form layout. Do not modify without explicit user approval.
import { Box, Button, FormControl, FormHelperText, MenuItem, Paper, Select, TextField, Typography } from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { useEffect, useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { addNewUser } from '../services/api.jsx';
import { APP_CONFIG } from '../config/appConfig.js';
import { USER_MESSAGES as MSG } from '../config/messages/user.js';
import { USER_FORM_VALIDATION as USER_CFG } from '../config/validation/userForm.js';
import { ROUTES } from '../config/routes.js';
import { sanitizeByField } from '../utils/fieldUtils.js';
import { validateUserAltMobile, validateUserForm } from '../utils/userFormValidation.js';
import { useRolesByDepartment, useUserBySap } from '../hooks/useFetchQueries.js';
import './UserManagementForm.css';

const UserManagementForm = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [sapCode, setSapCode] = useState('');
  const [debouncedSap, setDebouncedSap] = useState('');
  const [department, setDepartment] = useState('');
  const [role, setRole] = useState('');
  const [autoData, setAutoData] = useState({
    name: '',
    mobile: '',
    email: '',
    reportingManager: '',
    altMobile: '',
  });
  const [errors, setErrors] = useState({});

  const { data: sapUser, isFetching: fetchingSap } = useUserBySap(debouncedSap);
  const { data: roles = [], isFetching: fetchingRoles } = useRolesByDepartment(department);

  const addUserMutation = useMutation({
    mutationFn: addNewUser,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
  });

  const validateForm = () =>
    validateUserForm({
      sapCode,
      autoData,
      department,
      role,
    });

  const handleAltMobileBlur = () => {
    if (!autoData.altMobile) {
      setErrors((prev) => ({ ...prev, altMobile: '' }));
      return;
    }
    setErrors((prev) => ({
      ...prev,
      altMobile: validateUserAltMobile(autoData.altMobile),
    }));
  };

  const handleSubmit = async () => {
    const nextErrors = validateForm();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const payload = {
      sap: sapCode,
      name: autoData.name,
      mobile: autoData.mobile,
      email: autoData.email,
      reportingManager: autoData.reportingManager,
      alternateMobile: autoData.altMobile,
      department,
      role,
    };
    await addUserMutation.mutateAsync(payload);
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSap(sapCode.replace(/\D/g, ''));
    }, APP_CONFIG.SAP_DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [sapCode]);

  useEffect(() => {
    if (debouncedSap.length !== 8) {
      setAutoData((prev) => ({ ...prev, name: '', mobile: '', email: '', reportingManager: '' }));
      return;
    }

    if (!sapUser) return;

    setAutoData((prev) => ({
      ...prev,
      name: sapUser?.name ?? '',
      mobile: sapUser?.mobile ?? '',
      email: sapUser?.email ?? '',
      reportingManager: sapUser?.reportingManager ?? sapUser?.rm ?? '',
    }));
  }, [debouncedSap, sapUser]);

  useEffect(() => {
    setRole('');
  }, [department]);

  const getRoleOption = (item) => {
    if (typeof item === 'string') {
      return { value: item, label: item };
    }
    const value = item?.roleId ?? item?.id ?? item?.roleName ?? item?.name ?? '';
    const label = item?.roleName ?? item?.name ?? value;
    return { value: String(value), label };
  };

  const handleBack = () => {
    navigate(-1);
  };

  const handleSapChange = (value) => {
    setSapCode(sanitizeByField('sap', value));
    if (errors.sap) setErrors((prev) => ({ ...prev, sap: '' }));
  };

  const handleAltMobileChange = (value) => {
    setAutoData((prev) => ({ ...prev, altMobile: sanitizeByField('mobile', value) }));
    if (errors.altMobile) setErrors((prev) => ({ ...prev, altMobile: '' }));
  };

  return (
    <Box className="user-form-page">
      <Paper className="user-form-paper table-auto-width">
        <Box className="user-form-body">
          <Box className="user-form-header">
            <Typography className="georama-SemiBold fs-24 user-form-title">{MSG.addTitle}</Typography>
            <Button
              className="text-capitalize georama-medium-selected custom-starticon user-form-back-btn"
              startIcon={<ChevronLeftIcon />}
              onClick={handleBack}
            >
              {MSG.back}
            </Button>
          </Box>
          <Box className="user-form-header-divider" />

          <Box className="user-form-content">
          <Box className="user-form-row user-form-row--sap">
            <Box className="user-form-field user-form-field--sap">
              <Typography className="text-labels user-form-label">
                {MSG.labels.sap} <span className="important-fields">*</span>
              </Typography>
              <TextField
                className="form-control-input border-radius-8 user-form-sap-input"
                size="small"
                fullWidth
                placeholder={MSG.placeholders.sap}
                value={sapCode}
                error={!!errors.sap}
                onChange={(e) => handleSapChange(e.target.value)}
              />
              {errors.sap && <FormHelperText className="important-fields">{errors.sap}</FormHelperText>}
              {fetchingSap && <Typography className="user-form-fetching">{MSG.fetchingUser}</Typography>}
            </Box>
          </Box>

          <Box className="user-form-divider" />

          <Box className="user-form-grid">
            <Box className="user-form-field">
              <Typography className="text-labels user-form-label">{MSG.labels.name}</Typography>
              <TextField
                className="disabled-input border-radius-8"
                size="small"
                fullWidth
                disabled
                value={autoData.name}
                placeholder={MSG.placeholders.name}
                error={!!errors.name}
              />
              {errors.name && <FormHelperText className="important-fields">{errors.name}</FormHelperText>}
            </Box>

            <Box className="user-form-field">
              <Typography className="text-labels user-form-label">{MSG.labels.email}</Typography>
              <TextField
                className="disabled-input border-radius-8"
                size="small"
                fullWidth
                disabled
                value={autoData.email}
                placeholder={MSG.placeholders.email}
                error={!!errors.email}
              />
              {errors.email && <FormHelperText className="important-fields">{errors.email}</FormHelperText>}
            </Box>
          </Box>

          <Box className="user-form-grid">
            <Box className="user-form-field">
              <Typography className="text-labels user-form-label">{MSG.labels.mobile}</Typography>
              <TextField
                className="disabled-input border-radius-8"
                size="small"
                fullWidth
                disabled
                value={autoData.mobile}
                placeholder={MSG.placeholders.mobile}
                error={!!errors.mobile}
              />
              {errors.mobile && <FormHelperText className="important-fields">{errors.mobile}</FormHelperText>}
            </Box>

            <Box className="user-form-field">
              <Typography className="text-labels user-form-label">
                {MSG.labels.reportingManager} <span className="important-fields">*</span>
              </Typography>
              <TextField
                className="form-control-input border-radius-8"
                size="small"
                fullWidth
                placeholder={MSG.placeholders.reportingManager}
                value={autoData.reportingManager}
                error={!!errors.reportingManager}
                onChange={(e) => {
                  setAutoData((prev) => ({ ...prev, reportingManager: e.target.value }));
                  if (errors.reportingManager) setErrors((prev) => ({ ...prev, reportingManager: '' }));
                }}
              />
              {errors.reportingManager && (
                <FormHelperText className="important-fields">{errors.reportingManager}</FormHelperText>
              )}
            </Box>
          </Box>

          <Box className="user-form-row user-form-row--single">
            <Box className="user-form-field user-form-field--sap">
              <Typography className="text-labels user-form-label">{MSG.labels.alternateMobile}</Typography>
              <TextField
                className="form-control-input border-radius-8"
                size="small"
                fullWidth
                placeholder={MSG.placeholders.alternateMobile}
                value={autoData.altMobile}
                error={!!errors.altMobile}
                onBlur={handleAltMobileBlur}
                onChange={(e) => handleAltMobileChange(e.target.value)}
              />
              {errors.altMobile && <FormHelperText className="important-fields">{errors.altMobile}</FormHelperText>}
            </Box>
          </Box>

          <Box className="user-form-divider" />

          <Box className="user-form-grid user-form-grid--bottom">
            <Box className="user-form-col">
              <Box className="user-form-field">
                <Typography className="text-labels user-form-label">
                  {MSG.labels.department} <span className="important-fields">*</span>
                </Typography>
                <FormControl className="form-control-input border-radius-8" size="small" fullWidth error={!!errors.department}>
                  <Select
                    displayEmpty
                    value={department}
                    onChange={(e) => {
                      setDepartment(e.target.value);
                      if (errors.department) setErrors((prev) => ({ ...prev, department: '' }));
                    }}
                  >
                    <MenuItem value="" disabled>{MSG.placeholders.selectDepartment}</MenuItem>
                    {USER_CFG.departments.map((item) => (
                      <MenuItem key={item.value} value={item.value}>
                        {MSG.departments[item.labelKey]}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                {errors.department && <FormHelperText className="important-fields">{errors.department}</FormHelperText>}
              </Box>
            </Box>

            <Box className="user-form-col user-form-col--right">
              <Box className="user-form-field">
                <Typography className="text-labels user-form-label">
                  {MSG.labels.role} <span className="important-fields">*</span>
                </Typography>
                <FormControl className="form-control-input border-radius-8" size="small" fullWidth error={!!errors.role}>
                  <Select
                    displayEmpty
                    value={role}
                    disabled={!department || fetchingRoles}
                    onChange={(e) => {
                      setRole(e.target.value);
                      if (errors.role) setErrors((prev) => ({ ...prev, role: '' }));
                    }}
                  >
                    <MenuItem value="" disabled>
                      {fetchingRoles ? MSG.loadingRoles : MSG.placeholders.selectRole}
                    </MenuItem>
                    {roles.map((item) => {
                      const { value, label } = getRoleOption(item);
                      return (
                        <MenuItem key={value} value={value}>
                          {label}
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
                {errors.role && <FormHelperText className="important-fields">{errors.role}</FormHelperText>}
                {fetchingRoles && <Typography className="user-form-fetching">{MSG.fetchingRoles}</Typography>}
              </Box>
            </Box>
          </Box>

          <Box className="user-form-actions">
            <Button className="btn-common-red border-radius-32 user-form-submit-btn" onClick={handleSubmit}>
              {MSG.submit}
            </Button>
          </Box>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default UserManagementForm;
