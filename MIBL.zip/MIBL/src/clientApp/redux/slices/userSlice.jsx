import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  loggedData: null,
  loggedIn: false,
  token: '',
  featureAccess: [],
  isCaller: 'caller',
  fetchUserByManager: [],
  credFlag: false,
  inputUser: '',
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setInputUser(state, action) {
      state.inputUser = action.payload;
    },
    setLogin(state, action) {
      state.loggedData = action.payload.user;
      state.loggedIn = action.payload.loggedIn;
      state.token = action.payload.token;
      state.featureAccess = action.payload.featureAccess;
    },
    setLogout(state) {
      state.loggedData = null;
      state.loggedIn = false;
      state.token = '';
    },
    setIsCaller(state, action) {
      state.isCaller = action.payload;
    },
    setFetchUserByManager(state, action) {
      state.fetchUserByManager = action.payload;
    },
    setCredFlag(state, action) {
      state.credFlag = action.payload ?? true;
    },
  },
});

export const {
  setInputUser,
  setLogin,
  setLogout,
  setIsCaller,
  setFetchUserByManager,
  setCredFlag,
} = userSlice.actions;

export default userSlice.reducer;
