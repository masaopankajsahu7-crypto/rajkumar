import axios from 'axios';
import {
  appServiceBaseUrl,
  baseUrl,
  clientServiceBaseUrl,
  encryptedAppServiceBaseUrl,
  encryptedClientServiceBaseUrl,
  encryptedMasterServiceBaseUrl,
  masterServiceBaseUrl,
} from '../env/env';
import { APP_CONFIG } from '../config/appConfig.js';
import {
  APP_SERVICE_ENDPOINTS as APP_SERVICE_API,
  API_ENDPOINTS as API,
  CLIENT_SERVICE_ENDPOINTS as CLIENT_API,
  MASTER_SERVICE_ENDPOINTS as MASTER_API,
} from '../config/apiEndpoints.js';
import { getCurrentLastLoginDate, getCurrentLoggedInState, getCurrentUserId } from '../config/clientApiConfig.js';
import { OPPORTUNITY_KDS_FIELDS } from '../config/kdsFields.js';
import { buildKdsRequest, normalizeKdsOptions } from '../utils/kdsOptions.js';
import { normalizeClientSearchResults } from '../utils/clientNameSearch.js';
import { handleSessionExpired } from '../../utils/sessionManager.js';
import {
  INITIAL_CLIENT_FILTERS,
  normalizeClientListFilters,
} from '../utils/clientListFilters.js';
import {
  INITIAL_OPPORTUNITY_FILTERS,
  normalizeOpportunityListFilters,
} from '../utils/opportunityListFilters.js';
import {
  INITIAL_PORTFOLIO_FILTERS,
  normalizePortfolioListFilters,
} from '../utils/portfolioListFilters.js';
import {
  buildCheckRequest,
  buildGetRequest,
  buildListRequest,
  buildSavePayload,
} from '../utils/clientApiMapper.js';
import {
  mapClientToListRow,
  parseClientListApiResponse,
} from '../utils/clientList.js';
import {
  OPPORTUNITY_LIST_PAGE_SIZE,
  parseOpportunityListApiResponse,
} from '../utils/opportunityList.js';
import { normalizeClientPortfolios, parsePortfolioListApiResponse } from '../utils/clientPortfolios.js';
import { normalizeClientOpportunities } from '../utils/clientOpportunities.js';
import { parseReportListApiResponse, REPORT_LIST_PAGE_SIZE } from '../utils/reportList.js';
import {
  CRM_MIGRATION_LIST_PAGE_SIZE,
  parseCrmMigrationListResponse,
} from '../utils/crmMigration.js';
import {
  INITIAL_RENEWAL_LEAD_FILTERS,
  normalizeRenewalLeadFilters,
  parseRenewalLeadListApiResponse,
  RENEWAL_LEAD_LIST_PAGE_SIZE,
} from '../utils/renewalLeadList.js';
import { parseClientActivitiesResponse } from '../utils/clientActivities.js';
import { assertNoBlockedSpecialCharacters } from '../utils/securityValidation.js';
import { decryptPayload, ENCRYPTION_SECRET_TYPES, encryptPayload } from './encryptRequest.jsx';

const jsonHeaders = { 'Content-Type': 'application/json' };

const shouldUsePayloadEncryption = (config = {}) =>
  APP_CONFIG.ENABLE_API_PAYLOAD_ENCRYPTION && config.encryptPayload !== false;

const getServiceBaseUrl = (plainBaseUrl, encryptedBaseUrl, config = {}) =>
  shouldUsePayloadEncryption(config) ? encryptedBaseUrl : plainBaseUrl;

const formatAuthTimestamp = (date = new Date()) => {
  const pad = (value) => String(value).padStart(2, '0');

  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
  ].join('-') + ` ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
};

const buildEncryptedAuthorizationHeader = async (config = {}) => {
  if (!shouldUsePayloadEncryption(config)) return {};

  const encryptedToken = await encryptPayload({
    logged_in: getCurrentLoggedInState(),
    userid: getCurrentUserId(),
    last_login_date: getCurrentLastLoginDate(),
    timestamp: formatAuthTimestamp(),
  }, {
    secretType: ENCRYPTION_SECRET_TYPES.dynamic,
  });

  return encryptedToken?.d ? { Authorization: `Bearer ${encryptedToken.d}` } : {};
};

const prepareRequestData = async (data, config = {}) => {
  if (data === undefined) return data;
  if (typeof FormData !== 'undefined' && data instanceof FormData) return data;
  if (config.validateSpecialCharacters !== false) assertNoBlockedSpecialCharacters(data);
  if (!shouldUsePayloadEncryption(config)) return data;
  return encryptPayload(data);
};

const decryptResponseData = async (data, config = {}) => {
  if (!shouldUsePayloadEncryption(config)) return data;
  const encryptedPayload =
    typeof data === 'string'
      ? data
      : typeof data?.payload === 'string'
        ? data.payload
        : typeof data?.data?.payload === 'string'
          ? data.data.payload
          : typeof data?.d === 'string'
            ? data.d
            : typeof data?.data?.d === 'string'
              ? data.data.d
              : '';

  if (!encryptedPayload) return data;
  return decryptPayload(encryptedPayload);
};

const sanitizeRequestConfig = (config = {}) => {
  const {
    encryptPayload: _encryptPayload,
    validateSpecialCharacters: _validateSpecialCharacters,
    ...rest
  } = config;
  return rest;
};

const requestJson = async (method, path, data, config = {}) => {
  const requestConfig = sanitizeRequestConfig(config);
  const requestData = await prepareRequestData(data, config);
  const result = await axios({
    ...requestConfig,
    method,
    url: `${baseUrl}${path}`,
    headers: { ...jsonHeaders, ...requestConfig.headers },
    ...(requestData !== undefined ? { data: requestData } : {}),
  }).catch(async (error) => {
    if (error?.response?.status === 401) await handleSessionExpired();
    throw error;
  });

  result.data = await decryptResponseData(result.data, config);
  return result;
};

const postJson = async (path, data, config = {}) => requestJson('post', path, data, config);

/** POST helper targeting the Client Service microservice (separate base URL). */
const postClientService = async (path, data, config = {}) => {
  const requestConfig = sanitizeRequestConfig(config);
  const requestData = await prepareRequestData(data, config);
  const authorizationHeader = await buildEncryptedAuthorizationHeader(config);
  const result = await axios({
    ...requestConfig,
    method: 'post',
    url: `${getServiceBaseUrl(clientServiceBaseUrl, encryptedClientServiceBaseUrl, config)}${path}`,
    headers: { ...jsonHeaders, ...authorizationHeader, ...requestConfig.headers },
    data: requestData,
  }).catch(async (error) => {
    if (error?.response?.status === 401) await handleSessionExpired();
    throw error;
  });
  result.data = await decryptResponseData(result.data, config);
  return result;
};

/** POST helper targeting the Master Service microservice (dropdown / kds data). */
const postMasterService = async (path, data, config = {}) => {
  const requestConfig = sanitizeRequestConfig(config);
  const requestData = await prepareRequestData(data, config);
  const authorizationHeader = await buildEncryptedAuthorizationHeader(config);
  const result = await axios({
    ...requestConfig,
    method: 'post',
    url: `${getServiceBaseUrl(masterServiceBaseUrl, encryptedMasterServiceBaseUrl, config)}${path}`,
    headers: { ...jsonHeaders, ...authorizationHeader, ...requestConfig.headers },
    data: requestData,
  }).catch(async (error) => {
    if (error?.response?.status === 401) await handleSessionExpired();
    throw error;
  });
  result.data = await decryptResponseData(result.data, config);
  return result;
};

/** POST helper targeting the App Service microservice (opportunity workflow APIs). */
const postAppService = async (path, data, config = {}) => {
  const userId = getCurrentUserId();
  const requestConfig = sanitizeRequestConfig(config);
  const requestData = await prepareRequestData(data, config);
  const authorizationHeader = await buildEncryptedAuthorizationHeader(config);
  const result = await axios({
    ...requestConfig,
    method: 'post',
    url: `${getServiceBaseUrl(appServiceBaseUrl, encryptedAppServiceBaseUrl, config)}${path}`,
    headers: { ...jsonHeaders, ...authorizationHeader, 'X-User-Id': userId, ...requestConfig.headers },
    data: requestData,
  }).catch(async (error) => {
    if (error?.response?.status === 401) await handleSessionExpired();
    throw error;
  });
  result.data = await decryptResponseData(result.data, config);
  return result;
};

const buildOpportunityListRequest = ({ page = 1, filters = INITIAL_OPPORTUNITY_FILTERS } = {}) => {
  const normalized = normalizeOpportunityListFilters(filters);
  const offset = Math.max(Number(page) - 1, 0) * OPPORTUNITY_LIST_PAGE_SIZE;
  const toBackendCode = (value) =>
    String(value ?? '')
      .trim()
      .toUpperCase()
      .replace(/\s+/g, '_');
  const breachedFilter = normalized.breached === '1' ? { breached: 1 } : {};
  const dateFilters = normalized.renewalFrom || normalized.renewalTo
    ? {
        from_date: normalized.renewalFrom,
        to_date: normalized.renewalTo,
      }
    : {};

  return {
    userid: getCurrentUserId(),
    offset,
    limit: OPPORTUNITY_LIST_PAGE_SIZE,
    search: normalized.search,
    filters: {
      client_uuid: normalized.clientUUID,
      portfolio_UUID: normalized.portfolioUUID,
      opportunity_uuid: '',
      owner_id: normalized.ownerId,
      placement_rm_id: normalized.placementRmId,
      client_name: normalized.clientName,
      is_active: '',
      client_type_code: '',
      client_vertical_code: normalized.clientVertical,
      opportunity_type_code: normalized.businessType,
      opportunity_status_code: toBackendCode(normalized.opportunityStatus),
      opportunity_stage_code: toBackendCode(normalized.opportunityStage),
      opportunity_lob_code: '',
      opportunity_product_code: normalized.product,
      opportunity_sub_product_code: normalized.subProduct,
      ...breachedFilter,
      ...dateFilters,
      sort_column: normalized.sortColumn || 'created_on',
      sort_order: normalized.sortOrder,
    },
  };
};

const PORTFOLIO_LIST_PAGE_SIZE = 10;

const buildPortfolioListRequest = ({ page = 1, filters = INITIAL_PORTFOLIO_FILTERS } = {}) => {
  const normalized = normalizePortfolioListFilters(filters);
  const offset = Math.max(Number(page) - 1, 0) * PORTFOLIO_LIST_PAGE_SIZE;
  const dateFilters = normalized.fromDate || normalized.toDate
    ? {
        from_date: normalized.fromDate,
        to_date: normalized.toDate,
      }
    : {};

  return {
    userid: getCurrentUserId(),
    offset,
    limit: PORTFOLIO_LIST_PAGE_SIZE,
    search: normalized.search,
    filters: {
      client_uuid: normalized.clientUUID,
      owner_id: normalized.ownerId,
      client_name: normalized.clientName,
      is_active: normalized.isActive,
      client_type_code: normalized.clientType,
      client_vertical_code: normalized.clientVertical,
      portfolio_type_code: normalized.portfolioType,
      portfolio_product_code: normalized.product,
      portfolio_sub_product_code: normalized.subProduct,
      ...dateFilters,
      sort_column: normalized.dateFilterType,
      sort_order: normalized.sortOrder,
    },
  };
};

const buildOpportunityWorkflowRequest = (opportunityUUID) => ({
  userid: getCurrentUserId(),
  payload: {
    opportunity_uuid: String(opportunityUUID ?? '').trim(),
  },
});

const buildOpportunityViewRequest = (opportunityUUID) => ({
  userid: getCurrentUserId(),
  payload: {
    client_uuid: '',
    portfolio_uuid: '',
    opportunity_uuid: String(opportunityUUID ?? '').trim(),
  },
});

const buildOpportunityActivityLogsRequest = (opportunityUUID) => ({
  userid: getCurrentUserId(),
  payload: {
    opportunity_uuid: String(opportunityUUID ?? '').trim(),
    offset: 0,
    limit: 100,
  },
});

/**
 * Fetch a single dropdown's options from the master-service `kds` endpoint.
 * Returns normalized [{ code, value, parentCode }] (empty array on failure — the caller
 * shows an empty dropdown rather than crashing the form).
 */
export const getKdsOptions = async ({
  module = 'client',
  source,
  name,
  search = '',
  offset = 0,
  limit = 100,
  parentCode = '',
}) => {
  try {
    const body = buildKdsRequest({
      userid: getCurrentUserId(),
      module,
      source,
      name,
      search,
      offset,
      limit,
      parentCode,
    });
    const result = await postMasterService(MASTER_API.kds, body);
    return normalizeKdsOptions(result.data);
  } catch (error) {
    console.error('getKdsOptions failed', { module, source, name }, error);
    return [];
  }
};

export const getOpportunityKdsOptions = async ({
  module = 'opportunity',
  source,
  name,
  search = '',
  offset = 0,
  limit = 100,
  parentCode = '',
}) => {
  try {
    const result = await postAppService(APP_SERVICE_API.kds, {
      userid: getCurrentUserId(),
      offset,
      limit,
      search,
      payload: {
        key_module: module,
        key_source: source,
        key_name: name,
        ...(parentCode ? { parent_code: parentCode } : {}),
      },
    });
    return normalizeKdsOptions(result.data);
  } catch (error) {
    console.error('getOpportunityKdsOptions failed:', { module, source, name }, error);
    return [];
  }
};

export const getOpportunityWorkflowStageOptions = async () =>
  getOpportunityKdsOptions(OPPORTUNITY_KDS_FIELDS.workflowStage);

/**
 * Resolve a pincode to its city/state via the master-service. Returns the first match
 * ({ pincode, city_code, city_name, state_code, state_name }) or null when not found / on error.
 */
export const getPincodeDetails = async (pincode) => {
  try {
    const result = await postMasterService(MASTER_API.pincode, {
      userid: getCurrentUserId(),
      search: '',
      payload: { pincode: String(pincode ?? '').trim() },
    });
    const list = result?.data?.payload?.pincode ?? [];
    return list[0] ?? null;
  } catch (error) {
    console.error('getPincodeDetails failed', error);
    return null;
  }
};

export const login = async ({ checkLoginType, email, password, forceLogin = false }) => {
  try {
    const result = await postJson(API.authCheck, { checkLoginType, email, password },
      { headers: { forceLogout: forceLogin } },
    );
    return result.data;
  } catch (error) {
    console.error(error);
    return error.response?.data ?? error;
  }
};

export const otpVerification = async (data) => {
  try {
    const result = await postJson(API.otpVerification, data, {
      headers: {
        userName: data?.email,
        Authorization: `Bearer ${data?.token}`,
      },
    });
    return result.data;
  } catch (error) {
    console.error(error);
    return error.response?.data ?? error;
  }
};

export const sendOTP = async (email, token = '') => {
  try {
    return await postJson(API.sendOTP, { email },
      {
        headers: {
          userName: email,
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      },
    );
  } catch (error) {
    console.error(error);
    return error.response ?? error;
  }
};

export const verifyOTP = async (data) => {
  try {
    const result = await postJson(API.verifyOTP, data);
    return result.data;
  } catch (error) {
    console.error(error);
    return error.response?.data ?? error;
  }
};

export const resetPasswordUser = async (data) => {
  try {
    const result = await postJson(API.resetPassword, data);
    return result.data;
  } catch (error) {
    console.error(error);
    return error.response?.data ?? error;
  }
};

export const changePasswordUser = async (data) => {
  try {
    const result = await postJson(API.changePassword, data);
    return result.data;
  } catch (error) {
    console.error(error);
    return error.response?.data ?? error;
  }
};

export const getUserDetails = async (data) => {
  try {
    const result = await postJson(API.getUserList, data);
    return result.data;
  } catch (error) {
    console.error(error);
    return error.response?.data ?? error;
  }
};

/** POST /clients/list — paginated + filtered client list */
export const getClients = async ({ page = 1, filters = INITIAL_CLIENT_FILTERS } = {}) => {
  const normalizedFilters = normalizeClientListFilters(filters);
  const body = buildListRequest(page, normalizedFilters);

  try {
    const result = await postClientService(CLIENT_API.list, body);
    return parseClientListApiResponse(result.data, page);
  } catch (error) {
    console.error('getClients failed:', error);
    return { list: [], totalCount: 0, page };
  }
};

/** POST /Opportunities/list - paginated opportunity list. */
export const getOpportunities = async ({ page = 1, filters = INITIAL_OPPORTUNITY_FILTERS } = {}) => {
  const normalizedFilters = normalizeOpportunityListFilters(filters);

  try {
    const result = await postAppService(
      APP_SERVICE_API.opportunityList,
      buildOpportunityListRequest({ page, filters: normalizedFilters }),
    );
    const parsed = parseOpportunityListApiResponse(result.data, page);
    return parsed;
  } catch (error) {
    console.error('getOpportunities failed:', error);
    return { list: [], totalCount: 0, page };
  }
};

export const searchClientsForOpportunity = async (clientName) => {
  const trimmed = String(clientName ?? '').trim();
  if (!trimmed) return [];

  try {
    const result = await postClientService(
      CLIENT_API.list,
      buildListRequest(1, { ...INITIAL_CLIENT_FILTERS, clientName: trimmed }, 5),
    );
    return parseClientListApiResponse(result.data, 1).list.map(mapClientToListRow);
  } catch (error) {
    console.error('searchClientsForOpportunity failed:', error);
    return [];
  }
};

export const getOpportunityPortfoliosByClient = async (clientUUID) => {
  const trimmedClientUUID = String(clientUUID ?? '').trim();
  if (!trimmedClientUUID) return [];

  try {
    const result = await postAppService(APP_SERVICE_API.opportunityPortfolioList, {
      userid: getCurrentUserId(),
      offset: 0,
      limit: 10,
      search: '',
      filters: {
        client_uuid: trimmedClientUUID,
        owner_id: '',
        client_name: '',
        is_active: '',
        client_type_code: '',
        client_vertical_code: '',
        portfolio_type_code: '',
        portfolio_product_code: '',
        portfolio_sub_product_code: '',
        sort_column: '',
        sort_order: '',
      },
    });
    return normalizeClientPortfolios(result.data);
  } catch (error) {
    console.error('getOpportunityPortfoliosByClient failed:', error);
    return [];
  }
};

export const getPortfolios = async ({ page = 1, filters = INITIAL_PORTFOLIO_FILTERS } = {}) => {
  const normalizedFilters = normalizePortfolioListFilters(filters);

  try {
    const result = await postAppService(
      APP_SERVICE_API.opportunityPortfolioList,
      buildPortfolioListRequest({ page, filters: normalizedFilters }),
    );
    return parsePortfolioListApiResponse(result.data, page);
  } catch (error) {
    console.error('getPortfolios failed:', error);
    return { list: [], totalCount: 0, page };
  }
};

export const getReports = async ({
  page = 1,
  search = '',
  filters = {},
} = {}) => {
  const normalizedPage = Math.max(Number(page) || 1, 1);

  try {
    const result = await postAppService(APP_SERVICE_API.getReport, {
      userid: getCurrentUserId(),
      offset: (normalizedPage - 1) * REPORT_LIST_PAGE_SIZE,
      limit: REPORT_LIST_PAGE_SIZE,
      search: String(search ?? '').trim(),
      filters: {
        report_type_code: String(filters.reportTypeCode ?? '').trim(),
        report_status_code: String(filters.reportStatusCode ?? '').trim(),
        from_date: String(filters.fromDate ?? '').trim(),
        to_date: String(filters.toDate ?? '').trim(),
      },
    });
    return parseReportListApiResponse(result.data, normalizedPage);
  } catch (error) {
    console.error('getReports failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Unable to load reports',
    );
  }
};

export const getCrmMigrationList = async ({ page = 1, search = '' } = {}) => {
  const normalizedPage = Math.max(Number(page) || 1, 1);

  try {
    const result = await postAppService(APP_SERVICE_API.opportunityMigrationList, {
      userid: getCurrentUserId(),
      offset: (normalizedPage - 1) * CRM_MIGRATION_LIST_PAGE_SIZE,
      limit: CRM_MIGRATION_LIST_PAGE_SIZE,
      search: String(search ?? '').trim(),
      filters: {
        migration_row_id: null,
        is_migrated: 0,
        fromdate: null,
        todate: null,
        client: null,
        name: null,
        serial_no: null,
      },
    }, { encryptPayload: false });
    return parseCrmMigrationListResponse(result.data, normalizedPage);
  } catch (error) {
    console.error('getCrmMigrationList failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Unable to load CRM records',
    );
  }
};

export const getCrmMigrationRecord = async (migrationRowId) => {
  const normalizedMigrationRowId = Number(migrationRowId);
  if (!Number.isInteger(normalizedMigrationRowId) || normalizedMigrationRowId <= 0) {
    throw new Error('Migration record details are incomplete');
  }

  try {
    const result = await postAppService(APP_SERVICE_API.opportunityMigrationList, {
      userid: getCurrentUserId(),
      offset: 0,
      limit: CRM_MIGRATION_LIST_PAGE_SIZE,
      search: '',
      filters: {
        migration_row_id: normalizedMigrationRowId,
        is_migrated: 0,
        fromdate: null,
        todate: null,
        client: null,
        name: null,
        serial_no: null,
      },
    }, { encryptPayload: false });
    return parseCrmMigrationListResponse(result.data, 1).list?.[0] ?? null;
  } catch (error) {
    console.error('getCrmMigrationRecord failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Unable to load CRM record',
    );
  }
};

export const convertCrmMigrationOpportunity = async ({
  migrationRowId,
  ownerId,
  convertRemarks,
  client,
  portfolio,
  opportunity,
  opportunityRemarks,
}) => {
  const normalizedMigrationRowId = Number(migrationRowId);
  const normalizedOwnerId = Number(ownerId);

  if (!Number.isInteger(normalizedMigrationRowId) || normalizedMigrationRowId <= 0) {
    throw new Error('Migration record details are incomplete');
  }
  if (!Number.isInteger(normalizedOwnerId) || normalizedOwnerId <= 0) {
    throw new Error('Owner ID is required');
  }

  try {
    const result = await postAppService(APP_SERVICE_API.opportunityMigrationConvert, {
      userid: getCurrentUserId(),
      message: 'Convert migration opportunity',
      payload: {
        action_code: 'CONVERT',
        migration_row_id: normalizedMigrationRowId,
        owner_id: normalizedOwnerId,
        convert_remarks: String(convertRemarks ?? '').trim(),
        client: {
          client_uuid: String(client?.clientUUID ?? '').trim() || null,
          client_name: String(client?.clientName ?? '').trim(),
          client_type_code: String(client?.clientTypeCode ?? '').trim(),
          client_vertical_code: String(client?.clientVerticalCode ?? '').trim(),
          pincode: String(client?.pincode ?? '').trim(),
          branch_name: String(client?.branchName ?? '').trim(),
          contact: {
            name: String(client?.contactName ?? '').trim(),
            mobile: String(client?.contactMobile ?? '').trim(),
            email: String(client?.contactEmail ?? '').trim(),
          },
        },
        portfolio: {
          portfolio_type_code: String(portfolio?.portfolioTypeCode ?? '').trim(),
          portfolio_lob_code: String(portfolio?.portfolioLobCode ?? '').trim(),
          portfolio_product_code: String(portfolio?.portfolioProductCode ?? '').trim(),
          portfolio_sub_product_code: String(portfolio?.portfolioSubProductCode ?? '').trim(),
          expected_premium: Number(portfolio?.expectedPremium) || 0,
          brokerage_fee: Number(portfolio?.brokerageFee) || 0,
          reward_fee: Number(portfolio?.rewardFee) || 0,
          renewal_date: String(portfolio?.renewalDate ?? '').trim(),
        },
        opportunity: {
          opportunity_type_code: String(opportunity?.opportunityTypeCode ?? '').trim(),
          opportunity_status_code: String(opportunity?.opportunityStatusCode ?? '').trim(),
          opportunity_stage_code: String(opportunity?.opportunityStageCode ?? '').trim(),
          allowed_sla_days: Number(opportunity?.allowedSlaDays) || 0,
        },
        client_payload: {},
        portfolio_payload: {},
        opportunity_payload: {
          remarks: String(opportunityRemarks ?? '').trim(),
        },
      },
    }, { encryptPayload: false });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('convertCrmMigrationOpportunity failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'CRM migration conversion failed',
    );
  }
};

export const rejectCrmMigrationOpportunity = async ({
  migrationRowId,
  ownerId = getCurrentUserId(),
  convertRemarks = 'Rejected by business user',
} = {}) => {
  const normalizedMigrationRowId = Number(migrationRowId);
  const normalizedOwnerId = Number(ownerId);

  if (!Number.isInteger(normalizedMigrationRowId) || normalizedMigrationRowId <= 0) {
    throw new Error('Migration record details are incomplete');
  }
  if (!Number.isInteger(normalizedOwnerId) || normalizedOwnerId <= 0) {
    throw new Error('Owner ID is required');
  }

  try {
    const result = await postAppService(APP_SERVICE_API.opportunityMigrationConvert, {
      userid: getCurrentUserId(),
      message: 'Marking opportunity as lost',
      payload: {
        action_code: 'REJECT',
        migration_row_id: normalizedMigrationRowId,
        owner_id: normalizedOwnerId,
        convert_remarks: String(convertRemarks ?? '').trim(),
      },
    }, { encryptPayload: false });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('rejectCrmMigrationOpportunity failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'CRM migration rejection failed',
    );
  }
};

export const getRenewalLeads = async ({ page = 1, filters = INITIAL_RENEWAL_LEAD_FILTERS, pageSize = RENEWAL_LEAD_LIST_PAGE_SIZE } = {}) => {
  const normalizedPage = Math.max(Number(page) || 1, 1);
  const normalizedPageSize = Math.max(Number(pageSize) || RENEWAL_LEAD_LIST_PAGE_SIZE, 1);
  const normalizedFilters = normalizeRenewalLeadFilters(filters);
  const dateFilters = normalizedFilters.fromDate || normalizedFilters.toDate
    ? {
        from_date: normalizedFilters.fromDate,
        to_date: normalizedFilters.toDate,
      }
    : {};

  try {
    const result = await postAppService(APP_SERVICE_API.renewalLeadList, {
      userid: getCurrentUserId(),
      offset: (normalizedPage - 1) * normalizedPageSize,
      limit: normalizedPageSize,
      search: normalizedFilters.search,
      filters: {
        client_name: normalizedFilters.clientName,
        client_mobile: normalizedFilters.clientMobile,
        client_email: normalizedFilters.clientEmail,
        product: normalizedFilters.product,
        policy_no: normalizedFilters.policyNo,
        insurer: normalizedFilters.insurer,
        department: normalizedFilters.department,
        renewal_status: normalizedFilters.renewalStatus,
        renewal_stage: '',
        renewal_days: normalizedFilters.renewalDays,
        owner: normalizedFilters.owner,
        renewal_lead_uuid: normalizedFilters.renewalLeadUUID,
        ...dateFilters,
        sort_column: normalizedFilters.sortColumn,
        sort_order: normalizedFilters.sortOrder,
      },
    });
    return parseRenewalLeadListApiResponse(result.data);
  } catch (error) {
    console.error('getRenewalLeads failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Unable to load renewal leads',
    );
  }
};

export const getClientActivities = async ({ page = 1, filters = {} } = {}) => {
  const normalizedPage = Math.max(Number(page) || 1, 1);
  const limit = Math.max(Number(filters.limit) || 20, 1);

  try {
    const result = await postAppService(APP_SERVICE_API.clientActivitiesList, {
      userid: getCurrentUserId(),
      offset: (normalizedPage - 1) * limit,
      limit,
      search: String(filters.search ?? '').trim(),
      filters: {
        activity_uuid: String(filters.activityUUID ?? filters.activity_uuid ?? '').trim(),
        client_uuid: String(filters.clientUUID ?? '').trim(),
        activity_type_code: String(filters.activityType ?? '').trim(),
        meeting_mode_code: String(filters.meetingMode ?? '').trim(),
        current_status_code: String(filters.currentStatus ?? '').trim(),
        from_date: String(filters.fromDate ?? '').trim(),
        to_date: String(filters.toDate ?? '').trim(),
      },
    });
    return parseClientActivitiesResponse(result.data);
  } catch (error) {
    console.error('getClientActivities failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Unable to load client activities',
    );
  }
};

export const createClientActivity = async (body) => {
  try {
    const result = await postAppService(APP_SERVICE_API.clientActivitiesSave, body);
    return result.data;
  } catch (error) {
    console.error('createClientActivity failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Activity save failed',
    );
  }
};

export const getRenewalLeadForConversion = async (renewalLeadUUID) => {
  const normalizedUUID = String(renewalLeadUUID ?? '').trim();
  if (!normalizedUUID) throw new Error('Renewal lead details are incomplete');

  const response = await getRenewalLeads({
    page: 1,
    pageSize: 10,
    filters: {
      ...INITIAL_RENEWAL_LEAD_FILTERS,
      search: '',
      fromDate: '',
      toDate: '',
      sortColumn: '',
      sortOrder: '',
      renewalLeadUUID: normalizedUUID,
    },
  });

  return response.list?.[0]?.raw ?? null;
};

export const convertRenewalLeadToOpportunity = async ({
  renewalLeadUUID,
  clientUUID,
  pincode,
  contactName,
  contactMobile,
  contactEmail,
  clientName,
  clientVerticalCode,
  clientTypeCode,
  productCode,
  subProductCode,
  ownerId,
}) => {
  const normalizedRenewalLeadUUID = String(renewalLeadUUID ?? '').trim();
  const normalizedClientUUID = String(clientUUID ?? '').trim();
  const normalizedProductCode = String(productCode ?? '').trim();
  const normalizedSubProductCode = String(subProductCode ?? '').trim();
  const normalizedOwnerId = Number(ownerId);

  if (!normalizedRenewalLeadUUID) throw new Error('Renewal lead details are incomplete');
  if (!normalizedProductCode) throw new Error('Product is required');
  if (!normalizedSubProductCode) throw new Error('Sub-product is required');
  if (!Number.isInteger(normalizedOwnerId) || normalizedOwnerId <= 0) throw new Error('Owner details are incomplete');

  try {
    const result = await postAppService(APP_SERVICE_API.renewalLeadOpportunity, {
      userid: getCurrentUserId(),
      message: 'Convert renewal lead to opportunity',
      payload: {
        action_code: 'CONVERT',
        renewal_lead_uuid: normalizedRenewalLeadUUID,
        client: {
          pincode: String(pincode ?? '').trim(),
          client_uuid: normalizedClientUUID,
          client_name: String(clientName ?? '').trim(),
          client_vertical_code: String(clientVerticalCode ?? '').trim(),
          client_type_code: String(clientTypeCode ?? '').trim(),
          contact: {
            name: String(contactName ?? '').trim(),
            mobile: String(contactMobile ?? '').trim(),
            email: String(contactEmail ?? '').trim(),
          },
        },
        product_code: normalizedProductCode,
        sub_product_code: normalizedSubProductCode,
        owner_id: normalizedOwnerId,
      },
    });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('convertRenewalLeadToOpportunity failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Renewal conversion failed',
    );
  }
};

export const generateReport = async ({
  reportTypeCode,
  fromDate,
  toDate,
  clientVerticalCode = '',
  opportunityProductCode = '',
  placementRmId = '',
}) => {
  try {
    const result = await postAppService(APP_SERVICE_API.saveReport, {
      userid: getCurrentUserId(),
      message: 'Generate TAT report',
      payload: {
        report_type_code: String(reportTypeCode ?? '').trim(),
        from_date: String(fromDate ?? '').trim(),
        to_date: String(toDate ?? '').trim(),
        filters: {
          client_vertical_code: String(clientVerticalCode ?? '').trim(),
          opportunity_product_code: String(opportunityProductCode ?? '').trim(),
          placement_rm_id: String(placementRmId ?? '').trim(),
        },
      },
    });
    const data = result.data;
    const status = String(data?.status ?? data?.status_code ?? '');
    if (!status.startsWith('2')) {
      throw new Error(data?.message ?? data?.status_message ?? 'Report generation request failed');
    }
    return data;
  } catch (error) {
    console.error('generateReport failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Report generation request failed',
    );
  }
};

const assertOpportunitySaved = (data) => {
  const status = String(data?.status ?? data?.status_code ?? '');
  if (!status.startsWith('2')) {
    throw new Error(data?.message ?? data?.status_message ?? 'Opportunity save failed');
  }
  return data;
};

export const createOpportunity = async (body) => {
  try {
    const result = await postAppService(APP_SERVICE_API.opportunitySave, body);
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('createOpportunity failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Opportunity save failed',
    );
  }
};

export const assignOpportunityPlacementRm = async ({ opportunityUUID, placementRmId }) => {
  const normalizedOpportunityUUID = String(opportunityUUID ?? '').trim();
  const normalizedPlacementRmId = Number(placementRmId);

  if (!normalizedOpportunityUUID || !Number.isInteger(normalizedPlacementRmId) || normalizedPlacementRmId <= 0) {
    throw new Error('Select a valid Placement RM');
  }

  try {
    const result = await postAppService(APP_SERVICE_API.opportunityAssign, {
      userid: getCurrentUserId(),
      message: 'Assign Placement RM to opportunity',
      request_id: `placement-assignment-${crypto.randomUUID()}`,
      payload: {
        opportunity_uuid: normalizedOpportunityUUID,
        placement_rm_id: normalizedPlacementRmId,
      },
    });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('assignOpportunityPlacementRm failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Placement RM assignment failed',
    );
  }
};

export const markRenewalLeadNotRenewable = async ({
  renewalLeadUUID,
  rejectionReasonCode,
  rejectionComment,
}) => {
  const normalizedRenewalLeadUUID = String(renewalLeadUUID ?? '').trim();
  const normalizedReasonCode = String(rejectionReasonCode ?? '').trim();
  const normalizedComment = String(rejectionComment ?? '').trim();
  const currentUserId = getCurrentUserId();

  if (!normalizedRenewalLeadUUID) throw new Error('Renewal lead details are incomplete');
  if (!normalizedReasonCode) throw new Error('Not renewable reason is required');
  if (!normalizedComment) throw new Error('Remarks are required');

  try {
    const result = await postAppService(APP_SERVICE_API.renewalLeadOpportunity, {
      userid: currentUserId,
      message: 'Convert renewal lead to opportunity',
      payload: {
        action_code: 'REJECT',
        renewal_lead_uuid: normalizedRenewalLeadUUID,
        rejection_reason_code: normalizedReasonCode,
        rejection_comment: normalizedComment,
        owner_id: currentUserId,
      },
    });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('markRenewalLeadNotRenewable failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Unable to mark renewal lead as not renewable',
    );
  }
};

const normalizeAssignableUsers = (data) => {
  const payload = data?.payload ?? data;
  const rawUsers =
    payload?.users ??
    payload?.user ??
    payload?.records ??
    payload?.list ??
    payload?.data ??
    payload;
  const users = Array.isArray(rawUsers) ? rawUsers : [];

  return users
    .map((user) => {
      const code =
        user?.userid ??
        user?.key_code ??
        user?.user_id ??
        user?.id ??
        user?.employee_id ??
        user?.code ??
        '';
      const value =
        user?.key_value ??
        user?.full_name ??
        user?.user_name ??
        user?.username ??
        user?.name ??
        user?.employee_name ??
        user?.value ??
        '';
      return {
        ...user,
        code: String(code ?? '').trim(),
        value: String(value ?? '').trim(),
      };
    })
    .filter((user) => user.code && user.value);
};

export const searchAssignableOwners = async (
  search = '',
  { userType = 'SALES_RM', isHierarchy = 0 } = {},
) => {
  const normalizedSearch = String(search ?? '').trim();

  try {
    const result = await postAppService(APP_SERVICE_API.masterUser, {
      userid: getCurrentUserId(),
      offset: 0,
      limit: 20,
      search: normalizedSearch,
      filters: {
        user_type: userType,
        is_hierarchy: isHierarchy,
      },
    });
    return normalizeAssignableUsers(result.data);
  } catch (error) {
    console.error('searchAssignableOwners failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Unable to load owner list',
    );
  }
};

export const searchCommonUsers = (search = '') =>
  searchAssignableOwners(search, { userType: 'common', isHierarchy: 0 });

export const reassignRenewalLeadOwner = async ({ owner, renewalLeadUUIDs = [] }) => {
  const ownerId = Number(owner?.code ?? owner?.userid ?? owner?.user_id ?? owner?.owner_id);
  const normalizedLeadUUIDs = renewalLeadUUIDs
    .map((uuid) => String(uuid ?? '').trim())
    .filter(Boolean);

  if (!Number.isInteger(ownerId) || ownerId <= 0) throw new Error('Select a valid user');
  if (normalizedLeadUUIDs.length === 0) throw new Error('Select at least one renewal lead');

  try {
    const result = await postAppService(APP_SERVICE_API.renewalLeadOwnerReassign, {
      userid: getCurrentUserId(),
      message: 'renewal lead owner reassignment',
      payload: {
        owner_id: ownerId,
        renewal_lead_uuids: normalizedLeadUUIDs,
      },
    });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('reassignRenewalLeadOwner failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Renewal lead reassignment failed',
    );
  }
};

export const reassignClientOwners = async ({
  clientUUID,
  remarks,
  owner,
  coOwners = [],
}) => {
  const normalizedClientUUID = String(clientUUID ?? '').trim();
  let primaryOwnerId = Number(owner?.code ?? owner?.userid ?? owner?.user_id ?? owner?.owner_id);
  const normalizedRemarks = String(remarks ?? '').trim();
  const normalizedCoOwners = (Array.isArray(coOwners) ? coOwners : [])
    .map((item) => Number(item?.code ?? item?.userid ?? item?.user_id ?? item?.owner_id))
    .filter((userid) => Number.isInteger(userid) && userid > 0)
    .map((userid) => ({ userid }));

  if (!normalizedClientUUID) {
    throw new Error('Client details are incomplete');
  }
  if (!normalizedRemarks) {
    throw new Error('Reason for Ownership Shift is required');
  }

  try {
    if (!Number.isInteger(primaryOwnerId) || primaryOwnerId <= 0) {
      const ownerName = String(owner?.value ?? owner?.owner_name ?? owner?.name ?? '').trim();
      if (ownerName) {
        const ownerMatches = await searchAssignableOwners(ownerName);
        const matchedOwner =
          ownerMatches.find((item) => String(item?.value ?? '').trim().toLowerCase() === ownerName.toLowerCase()) ??
          ownerMatches[0];
        primaryOwnerId = Number(matchedOwner?.code ?? matchedOwner?.userid ?? matchedOwner?.user_id ?? matchedOwner?.owner_id);
      }
    }

    if (!Number.isInteger(primaryOwnerId) || primaryOwnerId <= 0) {
      throw new Error('Select a valid Primary Account Owner');
    }

    const result = await postAppService(APP_SERVICE_API.clientsReassign, {
      userid: getCurrentUserId(),
      message: 'Reassigning client owner and co-owners',
      payload: {
        client_uuid: normalizedClientUUID,
        remarks: normalizedRemarks,
        owner: {
          userid: primaryOwnerId,
        },
        co_owners: normalizedCoOwners,
      },
    });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('reassignClientOwners failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Client ownership reassignment failed',
    );
  }
};

export const reassignPortfolioOwner = async ({
  clientUUID,
  portfolioUUID,
  remarks,
  owner,
}) => {
  const normalizedClientUUID = String(clientUUID ?? '').trim();
  const normalizedPortfolioUUID = String(portfolioUUID ?? '').trim();
  const normalizedRemarks = String(remarks ?? '').trim();
  let primaryOwnerId = Number(owner?.code ?? owner?.userid ?? owner?.user_id ?? owner?.owner_id);

  if (!normalizedClientUUID) {
    throw new Error('Client details are incomplete');
  }
  if (!normalizedPortfolioUUID) {
    throw new Error('Portfolio details are incomplete');
  }
  if (!normalizedRemarks) {
    throw new Error('Reason for Ownership Shift is required');
  }

  try {
    if (!Number.isInteger(primaryOwnerId) || primaryOwnerId <= 0) {
      const ownerName = String(
        owner?.value ?? owner?.owner_name ?? owner?.username ?? owner?.name ?? '',
      ).trim();
      if (ownerName) {
        const ownerMatches = await searchAssignableOwners(ownerName);
        const matchedOwner =
          ownerMatches.find((item) => String(item?.value ?? '').trim().toLowerCase() === ownerName.toLowerCase()) ??
          ownerMatches[0];
        primaryOwnerId = Number(matchedOwner?.code ?? matchedOwner?.userid ?? matchedOwner?.user_id ?? matchedOwner?.owner_id);
      }
    }

    if (!Number.isInteger(primaryOwnerId) || primaryOwnerId <= 0) {
      throw new Error('Select a valid Primary Account Owner');
    }

    const result = await postAppService(APP_SERVICE_API.opportunityPortfolioReassign, {
      userid: getCurrentUserId(),
      message: 'Reassigning portfolio owner and co-owners',
      payload: {
        client_uuid: normalizedClientUUID,
        portfolio_uuid: normalizedPortfolioUUID,
        remarks: normalizedRemarks,
        owner: {
          userid: primaryOwnerId,
        },
      },
    });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('reassignPortfolioOwner failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Portfolio ownership reassignment failed',
    );
  }
};

export const saveOpportunityWorkflow = async ({
  opportunityUUID,
  opportunityStatusCode,
  actionCode,
  stageCode,
  delayReason,
  workflowData,
}) => {
  const normalizedOpportunityUUID = String(opportunityUUID ?? '').trim();
  const normalizedStatusCode = String(opportunityStatusCode ?? '').trim();

  if (!normalizedOpportunityUUID || !normalizedStatusCode) {
    throw new Error('Opportunity workflow details are incomplete');
  }

  try {
    const result = await postAppService(APP_SERVICE_API.opportunityWorkflowSave, {
      userid: getCurrentUserId(),
      message: 'Creating a new corporate opportunity workflow',
      payload: {
        opportunity: {
          opportunity_uuid: normalizedOpportunityUUID,
          opportunity_status_code: normalizedStatusCode,
        },
        workflow: {
          action_code: actionCode,
          stage_code: stageCode,
          direction_moved: 'FORWARD',
          delay_reason: String(delayReason ?? '').trim(),
          reversion_reason: null,
        },
        workflow_data: workflowData,
      },
    });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('saveOpportunityWorkflow failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Opportunity workflow save failed',
    );
  }
};

export const markOpportunityAsLost = async ({ opportunityUUID, lostReason, comments }) => {
  const normalizedOpportunityUUID = String(opportunityUUID ?? '').trim();
  const normalizedLostReason = String(lostReason ?? '').trim();
  const normalizedComments = String(comments ?? '').trim();

  if (!normalizedOpportunityUUID) {
    throw new Error('Opportunity details are incomplete');
  }
  if (!normalizedLostReason) {
    throw new Error('Loss Reason is required');
  }
  if (!normalizedComments) {
    throw new Error('Comments is required');
  }

  try {
    const result = await postAppService(APP_SERVICE_API.opportunityLost, {
      userid: getCurrentUserId(),
      message: 'Marking opportunity as lost',
      payload: {
        opportunity: {
          opportunity_uuid: normalizedOpportunityUUID,
        },
        workflow: {
          lost_reason: normalizedLostReason,
          comments: normalizedComments,
        },
      },
    });
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('markOpportunityAsLost failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Mark as Lost failed',
    );
  }
};

export const getOpportunityWorkflowHierarchy = async (opportunityUUID) => {
  try {
    const result = await postAppService(
      APP_SERVICE_API.opportunityView,
      buildOpportunityViewRequest(opportunityUUID),
    );
    return result?.data?.payload ? result.data : { status: 200, message: '', payload: {} };
  } catch (error) {
    console.error('getOpportunityWorkflowHierarchy failed:', error);
    return { status: 500, message: error?.message ?? 'Opportunity hierarchy failed', payload: {} };
  }
};

export const getOpportunityWorkflowRecords = async (opportunityUUID) => {
  try {
    const result = await postAppService(
      APP_SERVICE_API.opportunityWorkflowView,
      buildOpportunityWorkflowRequest(opportunityUUID),
    );
    return result?.data?.payload
      ? result.data
      : { status: 200, message: '', payload: { workflow_stages: [], total_workflow_stages: 0 } };
  } catch (error) {
    console.error('getOpportunityWorkflowRecords failed:', error);
    return { status: 500, message: error?.message ?? 'Opportunity workflow failed', payload: { workflow_stages: [], total_workflow_stages: 0 } };
  }
};

export const getOpportunityActivityLogs = async (opportunityUUID) => {
  try {
    const result = await postAppService(
      APP_SERVICE_API.opportunityActivityLogs,
      buildOpportunityActivityLogsRequest(opportunityUUID),
    );
    return result?.data?.payload ? result.data : { status: 200, message: '', payload: { activities: [] } };
  } catch (error) {
    console.error('getOpportunityActivityLogs failed:', error);
    return { status: 500, message: error?.message ?? 'Opportunity activity logs failed', payload: { activities: [] } };
  }
};

/** POST /clients/get — single client by client_ID */
export const getOpportunityDashboardSection = async ({
  dashboardName,
  fromDate = '',
  toDate = '',
} = {}) => {
  try {
    const result = await postAppService(APP_SERVICE_API.opportunityDashboardView, {
      userid: getCurrentUserId(),
      filters: {
        from_date: fromDate,
        to_date: toDate,
        dashboard_name: dashboardName,
      },
    });
    return result?.data?.payload ?? result?.data ?? {};
  } catch (error) {
    console.error('getOpportunityDashboardSection failed:', { dashboardName }, error);
    return {};
  }
};

export const getClientByUuid = async (clientUUID) => {
  try {
    const result = await postClientService(CLIENT_API.get, buildGetRequest(clientUUID));
    if (result?.data) return result.data;
    return { status: 404, message: 'Client record not found', payload: null };
  } catch (error) {
    console.error('getClientByUuid failed:', error);
    return { status: 500, message: error?.message ?? 'Client get failed', payload: null };
  }
};

/** POST /clients/portfolios — active portfolios for a client (endpoint TBD -> dummy fallback). */
export const getClientPortfolios = async (clientUUID) => {
  try {
    const result = await getPortfolios({
      page: 1,
      filters: {
        ...INITIAL_PORTFOLIO_FILTERS,
        clientUUID,
      },
    });
    return Object.assign(result.list ?? [], { isAdd: result.isAdd });
  } catch (error) {
    console.error('getClientPortfolios failed:', error);
    return [];
  }
};

/** POST /clients/opportunities — pipeline for a client (endpoint TBD -> dummy fallback). */
export const getClientOpportunities = async (clientUUID) => {
  try {
    const result = await getOpportunities({
      page: 1,
      filters: {
        ...INITIAL_OPPORTUNITY_FILTERS,
        clientUUID,
      },
    });
    return Object.assign(normalizeClientOpportunities(result), { isAdd: result.isAdd });
  } catch (error) {
    console.error('getClientOpportunities failed:', error);
    return [];
  }
};

/** POST /clients/save — create a new client */
/**
 * The save endpoint can fail two ways: an HTTP error (axios throws) or an HTTP 200 whose BODY
 * carries a failure status (e.g. { status: 500, message: 'Database Transaction Failed...' }).
 * Treat both as failures so the caller's onError fires — never report a bad save as success.
 */
const assertClientSaved = (data) => {
  const status = String(data?.status ?? data?.status_code ?? '');
  if (!status.startsWith('2')) {
    throw new Error(data?.message ?? data?.status_message ?? 'Client save failed');
  }
  return data;
};

const extractSaveError = (error) =>
  error?.response?.data?.message ??
  error?.response?.data?.status_message ??
  error?.message ??
  'Client save failed';

export const createClient = async (payload) => {
  const body = buildSavePayload(payload);
  try {
    const result = await postClientService(CLIENT_API.save, body);
    return assertClientSaved(result.data);
  } catch (error) {
    console.error('createClient failed:', error);
    throw new Error(extractSaveError(error));
  }
};

/** POST /clients/save — update an existing client (same endpoint, client_ID included) */
export const updateClient = async (clientUUID, payload) => {
  const body = buildSavePayload({ ...payload, clientUUID });
  try {
    const result = await postClientService(CLIENT_API.save, body);
    return assertClientSaved(result.data);
  } catch (error) {
    console.error('updateClient failed:', error);
    throw new Error(extractSaveError(error));
  }
};

/** POST /clients/{clientUUID}/portfolios — add portfolio to existing client */
/** POST /clients/approve - approve or reject a pending client. */
export const approveClient = async ({
  clientUUID,
  statusCode,
  reasonCode = '',
  remarks = '',
}) => {
  const body = {
    userid: getCurrentUserId(),
    payload: {
      client_uuid: String(clientUUID ?? '').trim(),
      client_status_code: statusCode,
      client_reason_code: reasonCode,
      client_remarks: remarks,
    },
  };

  try {
    const result = await postClientService(CLIENT_API.approve, body);
    return assertClientSaved(result.data);
  } catch (error) {
    console.error('approveClient failed:', error);
    throw new Error(extractSaveError(error));
  }
};

export const createClientPortfolio = async (body) => {
  try {
    const result = await postAppService(APP_SERVICE_API.opportunityPortfolioSave, body);
    return assertOpportunitySaved(result.data);
  } catch (error) {
    console.error('createClientPortfolio failed:', error);
    throw new Error(
      error?.response?.data?.message ??
        error?.response?.data?.status_message ??
        error?.message ??
        'Portfolio save failed',
    );
  }
};

/** @deprecated use getClients */
export const getClientDetails = async () => getClients();

/** @deprecated use createClient */
export const addNewClient = createClient;

/** POST /clients/check — smart search: matching clients for a name */
export const searchClientsByName = async (query, { source = '', clientUUID = '' } = {}) => {
  const trimmed = String(query ?? '').trim();
  if (!trimmed) return [];

  try {
    const result = await postClientService(CLIENT_API.check, buildCheckRequest({
      clientName: trimmed,
      clientUUID,
      source,
    }));
    // 200 = name is unique (no matches) -> empty list -> green tick.
    return normalizeClientSearchResults(result.data);
  } catch (error) {
    // The check API returns HTTP 409 when similar clients exist; the matches are in the body.
    // Use the actual response — no mock fallback.
    const body = error?.response?.data;
    if (body) return normalizeClientSearchResults(body);
    console.error('searchClientsByName failed:', error);
    return [];
  }
};

/** POST /clients/check — duplicate check: whether a client with this name exists */
export const checkClientByName = async (clientName, { source = 'add', clientUUID = '' } = {}) => {
  const evaluate = (data) => {
    const matches = normalizeClientSearchResults(data);
    const exists = data?.exists ?? data?.payload?.exists ?? matches.length > 0;
    return { exists: Boolean(exists) };
  };
  try {
    const result = await postClientService(CLIENT_API.check, buildCheckRequest({
      clientName,
      clientUUID,
      source,
    }));
    return evaluate(result?.data ?? {});
  } catch (error) {
    // 409 = a similar/duplicate client exists; the matches come back in the response body.
    const body = error?.response?.data;
    if (body) return evaluate(body);
    console.error('checkClientByName failed:', error);
    return { exists: false };
  }
};

// Temporary dummy service for SAP-based autofill.
// Replace with real API integration later.
export const fetchUserBySap = async (sapCode) => {
  const mockBySap = {
    '27011932': {
      name: 'Amit Kumar',
      mobile: '9876543210',
      email: 'amit.kumar@hm.com',
      reportingManager: 'Rajesh Sharma',
    },
    '12345678': {
      name: 'Neha Singh',
      mobile: '9123456780',
      email: 'neha.singh@hm.com',
      reportingManager: 'Vikram Mehta',
    },
  };

  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(
        mockBySap[sapCode] ?? {
          name: 'Auto User',
          mobile: '9000000000',
          email: `sap${sapCode}@hm.com`,
          reportingManager: 'Default Manager',
        },
      );
    }, 500);
  });
};

// Temporary stub for create-user submission.
// Replace this with actual API integration later.
export const addNewUser = async (payload) => {
  console.log('addNewUser payload:', payload);
  return Promise.resolve({
    status_code: '200',
    status_message: 'Mock submit success',
  });
};

const mockRolesByDepartment = {
  sales: ['Sales Manager', 'Sales Executive', 'Sales Lead'],
  placement: ['Placement Manager', 'Placement Executive', 'Placement Coordinator'],
};

export const fetchRole = async (department) => {
  try {
    const result = await postJson(API.fetchRole, { department });
    return result.data;
  } catch (error) {
    console.error(error);
    return {
      status_code: '200',
      roles: mockRolesByDepartment[department] ?? [],
    };
  }
};
