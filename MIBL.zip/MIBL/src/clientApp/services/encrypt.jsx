import CryptoJS from 'crypto-js';

const SECRET_KEY = 'Secret_KEY_123';

function base64ToBase64Url(str) {
  return str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlToBase64(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) {
    str += '=';
  }
  return str;
}

export function encryptRoute(path) {
  const encrypted = CryptoJS.AES.encrypt(path, SECRET_KEY).toString();
  return base64ToBase64Url(encrypted);
}

export function decryptRoute(cipherText) {
  const base64 = base64UrlToBase64(cipherText);
  const bytes = CryptoJS.AES.decrypt(base64, SECRET_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
}
