const ITERATIONS = 250000;
const SALT_LEN = 16;
const IV_LEN = 12;
const KEY_TIME_ZONE = 'Asia/Kolkata';
const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
const WEEKDAYS = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];

const getCrypto = () => globalThis.crypto?.subtle;

const getKolkataDateParts = () => {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: KEY_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  const parts = formatter.formatToParts(new Date());
  const year = parts.find((part) => part.type === 'year')?.value ?? '';
  const month = parts.find((part) => part.type === 'month')?.value ?? '';
  const day = parts.find((part) => part.type === 'day')?.value ?? '';

  return {
    year: Number(year),
    month: Number(month),
    day: Number(day),
  };
};

const getDynamicSecret = () => {
  const { year, month, day } = getKolkataDateParts();
  const utcDate = new Date(Date.UTC(year, month - 1, day));
  const weekday = WEEKDAYS[utcDate.getUTCDay()];
  const monthName = MONTHS[month - 1];
  const ymd = `${year}${String(month).padStart(2, '0')}${String(day).padStart(2, '0')}`;

  return btoa(`${weekday}${monthName}${ymd}`);
};

const bytesToBase64 = (bytes) => {
  let binary = '';
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
};

const base64ToBytes = (value) => {
  const binary = atob(String(value ?? ''));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
};

export const ENCRYPTION_SECRET_TYPES = {
  payload: 'dynamic',
  dynamic: 'dynamic',
};

const getSecret = () => getDynamicSecret();

const deriveAesKey = async (salt, usage, secretType = ENCRYPTION_SECRET_TYPES.payload) => {
  const subtle = getCrypto();
  if (!subtle) throw new Error('Web Crypto API is not available');

  const encoder = new TextEncoder();
  const passwordKey = await subtle.importKey(
    'raw',
    encoder.encode(getSecret(secretType)),
    'PBKDF2',
    false,
    ['deriveKey'],
  );

  return subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: ITERATIONS,
      hash: 'SHA-256',
    },
    passwordKey,
    {
      name: 'AES-GCM',
      length: 256,
    },
    false,
    [usage],
  );
};

export async function encryptPayload(payload, options = {}) {
  const subtle = getCrypto();
  if (!subtle) throw new Error('Web Crypto API is not available');

  const encoder = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(SALT_LEN));
  const iv = crypto.getRandomValues(new Uint8Array(IV_LEN));
  const aesKey = await deriveAesKey(salt, 'encrypt', options.secretType);
  const plaintext = JSON.stringify(payload);
  const ciphertext = await subtle.encrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    aesKey,
    encoder.encode(plaintext),
  );

  const encrypted = new Uint8Array(salt.length + iv.length + ciphertext.byteLength);
  encrypted.set(salt, 0);
  encrypted.set(iv, salt.length);
  encrypted.set(new Uint8Array(ciphertext), salt.length + iv.length);

  return {
    d: bytesToBase64(encrypted),
  };
}

export async function decryptPayload(encryptedBase64, options = {}) {
  const subtle = getCrypto();
  if (!subtle) throw new Error('Web Crypto API is not available');

  const encrypted = base64ToBytes(encryptedBase64);
  if (encrypted.length <= SALT_LEN + IV_LEN) {
    throw new Error('Encrypted response is invalid');
  }

  const salt = encrypted.slice(0, SALT_LEN);
  const iv = encrypted.slice(SALT_LEN, SALT_LEN + IV_LEN);
  const ciphertext = encrypted.slice(SALT_LEN + IV_LEN);
  const aesKey = await deriveAesKey(salt, 'decrypt', options.secretType);
  const decrypted = await subtle.decrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    aesKey,
    ciphertext,
  );

  const text = new TextDecoder().decode(decrypted);
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}
