import { FIELD_RULES } from '../config/fieldRules.js';
import { AUTH_MESSAGES as MSG } from '../config/messages/auth.js';
import { isValidByField } from './fieldUtils.js';

const hasPasswordComplexity = (value, requireUpperCase = false) => {
  const hasAlphabet = /[a-zA-Z]/.test(value);
  const hasUpperCase = /[A-Z]/.test(value);
  const hasNumber = /\d/.test(value);
  const hasSpecialChar = /[^A-Za-z0-9]/.test(value);

  if (requireUpperCase) {
    return hasUpperCase && hasNumber && hasSpecialChar;
  }

  return hasAlphabet && hasNumber && hasSpecialChar;
};

export const validateLoginEmail = (value) => {
  if (!value) return MSG.errors.emailRequired;
  return '';
};

export const validateLoginEmailOrMobile = (value) => {
  if (!value) return MSG.errors.emailRequired;
  if (isValidByField('email', value)) return '';
  if (isValidByField('indianMobile', value)) return '';
  return MSG.errors.emailInvalid;
};

export const validateLoginSap = (value = '') => {
  if (!value.trim()) return MSG.errors.sapRequired;
  return '';
};

export const validateLoginPassword = (value, fieldKey = 'password') => {
  const rule = FIELD_RULES[fieldKey];
  if (!value) return MSG.errors.passwordRequired;
  if (value.length < rule.minLength) return MSG.errors.passwordLength;
  if (!hasPasswordComplexity(value, fieldKey === 'passwordForgot')) {
    return MSG.errors.passwordRules;
  }
  return '';
};

export const validatePasswordMatch = (password, confirmPassword) =>
  password !== confirmPassword ? MSG.errors.passwordMismatch : '';

export const validateOtp = (value) => {
  if (value.length !== FIELD_RULES.otp.exactLength) return MSG.errors.otpLength;
  return '';
};

export const truncateAuthField = (fieldKey, value) => {
  const rule = FIELD_RULES[fieldKey];
  if (!rule?.maxLength) return value;
  return String(value).slice(0, rule.maxLength);
};
