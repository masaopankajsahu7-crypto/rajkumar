export const CLIENT_ACTIVITIES_FALLBACK_RESPONSE = {
  status: 200,
  message: 'Client activities fallback data.',
  payload: {
    limit: 20,
    offset: 0,
    total_records: 7,
    activity_count: 6,
    total_activities: 6,
    activities: [
      {
        active: 1,
        is_edit: 1,
        schedule: '4 days overdue',
        client_name: 'HANSA RESEARCH GROUP PRIVATE LIMITED',
        client_uuid: '9153585dc67b9cQa761Q11f1Q8299Q6045bda5cbc6',
        meeting_mode: 'Online',
        participants: [
          { name: 'Anand Mng', user_id: 88, participant_role_code: 'JOINT_USER' },
          { name: 'Pradeep RM', user_id: 91, participant_role_code: 'ORGANIZER' },
          { name: 'Zeenet PRM', user_id: 93, participant_role_code: 'JOINT_USER' },
        ],
        scheduled_at: '2026-09-01 15:30:00',
        activity_code: 'ACT-6',
        activity_name: 'Quarterly policy discussion',
        activity_type: 'Policy Review',
        activity_uuid: '68870045bd73ffQa911Q11f1Q8950Q42d564741922',
        current_status: 'Breached',
        current_status_code: 'BREACHED',
        meeting_status: 'Scheduled',
        client_interest: 'Not Recorded',
        created_by_name: 'Pradeep RM',
        reschedule_count: 0,
        is_current_activity: 1,
      },
      {
        active: 1,
        is_edit: 0,
        client_name: 'HANSA RESEARCH GROUP PRIVATE LIMITED',
        client_uuid: '9153585dc67b9cQa761Q11f1Q8299Q6045bda5cbc6',
        meeting_mode: 'Online',
        participants: [
          { name: 'Anand Mng', user_id: 88, participant_role_code: 'JOINT_USER' },
          { name: 'Pradeep RM', user_id: 91, participant_role_code: 'ORGANIZER' },
        ],
        scheduled_at: '2026-09-02 15:30:00',
        activity_code: 'ACT-7',
        activity_name: 'Quarterly policy discussion',
        activity_type: 'Policy Review',
        activity_uuid: '4700474c6a80f8Qa911Q11f1Q8950Q42d564741922',
        current_status: 'Closed',
        current_status_code: 'CLOSED',
        meeting_status: 'Closed',
        client_interest: 'Not Recorded',
        created_by_name: 'Pradeep RM',
        modified_by_name: 'Pradeep RM',
        reschedule_count: 1,
        is_current_activity: 0,
      },
      {
        active: 1,
        is_edit: 1,
        schedule: '11:30 AM',
        client_name: 'HANSA RESEARCH GROUP PRIVATE LIMITED',
        client_uuid: '9153585dc67b9cQa761Q11f1Q8299Q6045bda5cbc6',
        meeting_mode: 'Online',
        participants: [{ name: 'Pradeep RM', user_id: 91, participant_role_code: 'ORGANIZER' }],
        scheduled_at: '2026-09-19 11:30:00',
        activity_code: 'ACT-28',
        activity_name: 'Quarterly policy discussion',
        activity_type: 'Policy Review',
        activity_uuid: '1841365d5774e2Qa914Q11f1Q8950Q42d564741922',
        current_status: 'Today',
        current_status_code: 'TODAY',
        meeting_status: 'Scheduled',
        client_interest: 'Not Recorded',
        created_by_name: 'Pradeep RM',
        reschedule_count: 0,
        is_current_activity: 1,
      },
      {
        active: 1,
        is_edit: 1,
        schedule: '1 day',
        client_name: 'HANSA RESEARCH GROUP PRIVATE LIMITED',
        client_uuid: '9153585dc67b9cQa761Q11f1Q8299Q6045bda5cbc6',
        meeting_mode: 'Online',
        participants: [{ name: 'Pradeep RM', user_id: 91, participant_role_code: 'ORGANIZER' }],
        scheduled_at: '2026-09-20 11:30:00',
        activity_code: 'ACT-29',
        activity_name: 'Quarterly policy discussion',
        activity_type: 'Policy Review',
        activity_uuid: '310541705146abQa914Q11f1Q8950Q42d564741922',
        current_status: 'Tomorrow',
        current_status_code: 'TOMORROW',
        meeting_status: 'Scheduled',
        client_interest: 'Not Recorded',
        created_by_name: 'Pradeep RM',
        reschedule_count: 0,
        is_current_activity: 1,
      },
      {
        active: 1,
        is_edit: 1,
        schedule: '5 days',
        client_name: 'HANSA RESEARCH GROUP PRIVATE LIMITED',
        client_uuid: '9153585dc67b9cQa761Q11f1Q8299Q6045bda5cbc6',
        meeting_mode: 'Online',
        participants: [
          { name: 'Anand Mng', user_id: 88, participant_role_code: 'JOINT_USER' },
          { name: 'Pradeep RM', user_id: 91, participant_role_code: 'ORGANIZER' },
        ],
        scheduled_at: '2026-09-24 11:00:00',
        activity_code: 'ACT-7',
        activity_name: 'Quarterly policy discussion',
        activity_type: 'Policy Review',
        activity_uuid: '1324362392aacbQa916Q11f1Q8950Q42d564741922',
        current_status: 'Upcoming',
        current_status_code: 'UPCOMING',
        meeting_status: 'Scheduled',
        client_interest: 'Maybe / Follow Up Required',
        remarks_by_client: 'Client requested the revised schedule.',
        created_by_name: 'Pradeep RM',
        reschedule_count: 1,
        is_current_activity: 1,
      },
      {
        active: 1,
        is_edit: 0,
        client_name: 'HANSA RESEARCH GROUP PRIVATE LIMITED',
        client_uuid: '9153585dc67b9cQa761Q11f1Q8299Q6045bda5cbc6',
        meeting_mode: 'Online',
        participants: [{ name: 'Pradeep RM', user_id: 91, participant_role_code: 'ORGANIZER' }],
        scheduled_at: '2026-09-12 11:00:00',
        activity_code: 'ACT-3',
        activity_name: 'Quarterly policy discussion',
        activity_type: 'Policy Review',
        activity_uuid: '957817c4f2272dQa90eQ11f1Q8950Q42d564741922',
        current_status: 'Completed',
        current_status_code: 'COMPLETED',
        meeting_status: 'Completed',
        client_interest: 'Yes, Interested',
        remarks_by_client: 'Meeting completed successfully.',
        created_by_name: 'Pradeep RM',
        modified_by_name: 'Pradeep RM',
        reschedule_count: 0,
        is_current_activity: 1,
      },
    ],
  },
};

const asText = (value) => String(value ?? '').trim();

export const parseActivityDate = (value) => {
  const raw = asText(value);
  if (!raw) return null;
  const date = new Date(raw.replace(' ', 'T'));
  return Number.isNaN(date.getTime()) ? null : date;
};

export const getActivityBucket = (activity = {}) => {
  const status = asText(activity.current_status_code || activity.currentStatusCode || activity.current_status).toUpperCase();
  const meetingStatus = asText(activity.meeting_status_code || activity.meetingStatusCode || activity.meeting_status).toUpperCase();
  if (['COMPLETED', 'CLOSED'].some((key) => status.includes(key) || meetingStatus.includes(key))) return 'done';
  if (Number(activity.active ?? 1) === 0) return 'inactive';
  if (status.includes('BREACHED')) return 'breached';
  if (status.includes('TODAY')) return 'today';
  return 'upcoming';
};

export const mapClientActivity = (activity = {}) => {
  const scheduledAt = parseActivityDate(activity.scheduled_at || activity.scheduledAt);
  const participants = Array.isArray(activity.participants) ? activity.participants : [];
  const activityUUID = asText(activity.activity_uuid || activity.activityUUID || activity.activity_id || activity.id);
  return {
    id: activityUUID,
    activityUUID,
    activity_uuid: activityUUID,
    activityCode: asText(activity.activity_code || activity.code),
    clientName: asText(activity.client_name || activity.clientName),
    clientUUID: asText(activity.client_uuid || activity.clientUUID),
    portfolioName: asText(activity.portfolio_name || activity.portfolioName || 'No portfolio linked'),
    title: asText(activity.activity_name || activity.activityName || activity.title),
    type: asText(activity.activity_type || activity.activityType),
    mode: asText(activity.meeting_mode || activity.meetingMode),
    meetingStatus: asText(activity.meeting_status || activity.meetingStatus),
    currentStatus: asText(activity.current_status || activity.currentStatus),
    currentStatusCode: asText(activity.current_status_code || activity.currentStatusCode),
    clientInterest: asText(activity.client_interest || activity.clientInterest),
    remarks: asText(activity.remarks_by_client || activity.remarks),
    createdByName: asText(activity.created_by_name || activity.createdByName),
    modifiedByName: asText(activity.modified_by_name || activity.modifiedByName),
    schedule: asText(activity.schedule),
    rescheduleCount: Number(activity.reschedule_count ?? activity.rescheduleCount ?? 0) || 0,
    isCurrent: Number(activity.is_current_activity ?? activity.isCurrent ?? 1) === 1,
    isEdit: Number(activity.is_edit ?? activity.isEdit ?? 0) === 1,
    active: Number(activity.active ?? 1) === 1,
    scheduledAt,
    participants,
    jointUsers: participants.filter((item) => asText(item.participant_role_code) === 'JOINT_USER'),
    organizer: participants.find((item) => asText(item.participant_role_code) === 'ORGANIZER'),
    raw: activity,
  };
};

export const parseClientActivitiesResponse = (response = {}, { fallback = false } = {}) => {
  const payload = response?.payload && typeof response.payload === 'object'
    ? response.payload
    : response?.activities || response?.activity_count || response?.total_records
      ? response
      : {};
  const list = Array.isArray(payload.activities) ? payload.activities.map(mapClientActivity) : [];
  return {
    list,
    totalCount: Number(payload.total_records ?? list.length) || 0,
    activityCount: Number(payload.activity_count ?? list.length) || 0,
    totalActivities: Number(payload.total_activities ?? list.length) || 0,
    isFallback: fallback,
    raw: response,
  };
};
