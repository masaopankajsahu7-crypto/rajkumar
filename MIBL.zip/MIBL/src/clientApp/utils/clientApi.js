import { normalizeClientList } from './clientList.js';

export const getClientNameFromRecord = (client) => {
  const basic = client?.basicDetails ?? client;
  return (basic?.client_name ?? client?.client_name ?? client?.clientName ?? '').trim();
};

export const clientExistsByName = (clients, clientName) => {
  const target = String(clientName ?? '').trim().toLowerCase();
  if (!target) return false;

  return normalizeClientList(clients).some(
    (client) => getClientNameFromRecord(client).toLowerCase() === target,
  );
};
