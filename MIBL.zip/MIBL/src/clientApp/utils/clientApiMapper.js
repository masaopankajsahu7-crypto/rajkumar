import { APP_CONFIG } from '../config/appConfig.js';
import {
  getCurrentUserId,
  toClientActiveState,
  toClientStatusCode,
  toClientTypeCode,
  toVerticalCode,
} from '../config/clientApiConfig.js';

const trim = (value) => String(value ?? '').trim();

/**
 * POST /clients/list — paginated + filtered list.
 * UI is 1-based (page); API is 0-based (offset).
 */
export const buildListRequest = (page = 1, filters = {}, pageSize = APP_CONFIG.LIST_PAGE_SIZE) => {
  const limit = pageSize;
  const offset = Math.max(0, (Number(page) - 1) * limit);
  const dateFilters = trim(filters.fromDate) || trim(filters.toDate)
    ? {
        from_date: trim(filters.fromDate),
        to_date: trim(filters.toDate),
      }
    : {};

  return {
    userid: getCurrentUserId(),
    offset,
    limit,
    // Free-text search box is its own top-level param. Client Name is a separate filter field,
    // so both can be sent together when the user has a search term AND applied filters.
    search: trim(filters.search),
    filters: {
      client_name: trim(filters.clientName),
      client_uuid: trim(filters.clientUUID),
      client_type_code: filters.clientType ? toClientTypeCode(filters.clientType) : '',
      client_vertical_code: filters.vertical ? toVerticalCode(filters.vertical) : '',
      primary_owner: trim(filters.primaryOwner),
      owner_id: trim(filters.ownerId),
      pincode: trim(filters.pincode),
      city_name: trim(filters.cityName),
      client_status_code: filters.clientStatus ? toClientStatusCode(filters.clientStatus) : '',
      is_active: filters.activeState ? toClientActiveState(filters.activeState) : '',
      ...dateFilters,
      sort_column: trim(filters.dateFilterType) || 'created_on',
      sort_order: trim(filters.sortOrder),
    },
  };
};

/** POST /clients/check — smart search / duplicate name check. */
export const buildCheckRequest = ({ clientName = '', clientUUID = '', source = '' } = {}) => ({
  userid: getCurrentUserId(),
  payload: {
    client: {
      client_name: trim(clientName),
      client_uuid: trim(clientUUID),
      source: trim(source),
    },
  },
});

/** POST /clients/view — single client by its UUID. */
export const buildGetRequest = (clientUUID) => ({
  userid: getCurrentUserId(),
  payload: {
    client_UUID: trim(clientUUID),
  },
});

const buildContacts = (communication = {}) => {
  const primary = {
    name: trim(communication.primary_contact_name),
    email: trim(communication.primary_email),
    mobile: trim(communication.primary_mobile),
  };
  const secondaries = (communication.secondaries ?? []).map((item) => ({
    name: trim(item.name),
    email: trim(item.email),
    mobile: trim(item.mobile),
  }));

  return [primary, ...secondaries].filter((c) => c.name || c.email || c.mobile);
};

/**
 * Portfolio's own contact block, stored under client_data.portfolio.contact.
 * Array: primary first, then each other contact, using the same name/email/mobile shape as
 * normal client contacts. Round-trips back into the form on edit.
 */
const buildPortfolioContact = (portfolio = {}) => {
  const primary = {
    name: trim(portfolio.primary_contact_person),
    email: trim(portfolio.primary_contact_email),
    mobile: trim(portfolio.primary_contact_mobile),
  };
  const others = (portfolio.other_contacts ?? [])
    .map((c) => ({ name: trim(c.name), email: trim(c.email), mobile: trim(c.mobile) }))
    .filter((c) => c.name || c.mobile || c.email);
  return [primary, ...others].filter((c) => c.name || c.mobile || c.email);
};

/**
 * POST /clients/save — create + update.
 * Maps the form payload (basicDetails / address / communication / portfolios) into the
 * client-service envelope. When clientUUID is present the same endpoint performs an update.
 *
 * Address sends city_name / state_name (resolved from the pincode) — not city/state IDs. The
 * backend stores/echoes these so they populate straight back on edit.
 */
export const buildSavePayload = (formPayload = {}) => {
  const basic = formPayload.basicDetails ?? {};
  const address = formPayload.address ?? {};
  const portfolio = formPayload.portfolios?.[0] ?? {};
  const isUpdate = Boolean(formPayload.clientUUID);
  const shouldSendPortfolio = Object.prototype.hasOwnProperty.call(formPayload, 'portfolios');

  const clientData = {
    client: {
      gstin: trim(basic.gstin),
      pancard: trim(basic.pan),
      cin_number: trim(basic.cin),
      tin_number: '',
    },
    address: {
      pincode: trim(address.pincode),
      city_name: trim(address.city),
      state_name: trim(address.state),
      address_line1: trim(address.address_line1),
      address_line2: trim(address.address_line2),
    },
  };

  if (shouldSendPortfolio) {
    clientData.portfolio = {
      product: trim(portfolio.product),
      biz_type: trim(portfolio.business_type),
      brokerage: portfolio.brokerage_consultancy ?? null,
      sub_product: trim(portfolio.sub_product),
      sum_insured: portfolio.sum_insured ?? null,
      renewal_date: portfolio.renewal_date || null,
      policy_start_date: portfolio.policy_start_date || null,
      policy_expiry_date: portfolio.policy_expiry_date || null,
      previous_insurer: trim(portfolio.previous_insurer),
      previous_policy_number: trim(portfolio.previous_policy_number),
      expected_premium: portfolio.expected_premium ?? null,
      contact: buildPortfolioContact(portfolio),
    };
  }

  return {
    userid: getCurrentUserId(),
    message: isUpdate
      ? 'Updating an existing corporate client profile'
      : 'Creating a brand new corporate client profile',
    payload: {
      client: {
        // On edit, send the selected client's UUID so the backend updates the right record.
        ...(isUpdate ? { client_UUID: formPayload.clientUUID } : {}),
        ...(formPayload.active !== undefined && formPayload.active !== null
          ? { active: formPayload.active ? 1 : 0 }
          : {}),
        client_name: trim(basic.client_name),
        client_type_code: toClientTypeCode(basic.client_type),
        client_vertical_code: toVerticalCode(basic.vertical),
      },
      contacts: buildContacts(formPayload.communication),
      client_data: clientData,
    },
  };
};
