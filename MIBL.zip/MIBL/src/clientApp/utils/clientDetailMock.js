import { normalizeClientPortfolios } from './clientPortfolios.js';

const DEFAULT_PROFILE = {
  clientUUID: 'fallback-1',
  clientName: 'Mahindra Insurance Brokers',
  clientCode: 'AMC123',
  codeDate: '21st April, 2026',
  clientType: 'Insurance Broking',
  vertical: 'Financial Services',
  status: 'Approved',
  primaryOwner: 'Pankaj Sahu',
  coOwners: ['Krishna', 'Raj'],
  approvedBy: 'Sandeep Sharma',
  approvedDate: '23rd April, 2026',
  address: {
    line: 'Mumbai, Maharashtra',
    pincode: '400001',
    city: 'Mumbai',
    state: 'Maharashtra',
  },
  statutory: {
    gstin: '27AABCM1234A1Z5',
    cin: 'U65990MH2000PLC123456',
    pan: 'AABCM1234A',
  },
  contacts: [
    {
      name: 'Amit Yadav',
      mobile: '9857465412',
      email: 'amit.y@mahindra.com',
    },
    {
      name: 'Priya Nair',
      mobile: '9876543210',
      email: 'priya.n@mahindra.com',
    },
  ],
  portfolios: [
    {
      id: 'PF-2401',
      lob: 'Motor',
      product: 'Commercial Vehicle',
      subProduct: 'Fleet',
      owner: 'Pankaj Sahu',
      activeOpps: 8,
      totalOpps: 12,
    },
    {
      id: 'PF-2402',
      lob: 'Health',
      product: 'Group Mediclaim',
      subProduct: 'Corporate',
      owner: 'Krishna',
      activeOpps: 3,
      totalOpps: 5,
    },
    {
      id: 'PF-2403',
      lob: 'Property',
      product: 'Fire & Burglary',
      subProduct: 'Industrial',
      owner: 'Raj',
      activeOpps: 2,
      totalOpps: 4,
    },
    {
      id: 'PF-2404',
      lob: 'Marine',
      product: 'Cargo',
      subProduct: 'Import',
      owner: 'Pankaj Sahu',
      activeOpps: 1,
      totalOpps: 2,
    },
  ],
  opportunities: [
    {
      id: 'OPP-8801',
      lob: 'Motor',
      product: 'Commercial Vehicle',
      subProduct: 'Fleet',
      owner: 'Pankaj Sahu',
      rfqStatus: 'Submitted',
      qcrStatus: 'Approved',
      dealStatus: 'Policy Issued',
    },
    {
      id: 'OPP-8802',
      lob: 'Health',
      product: 'Group Mediclaim',
      subProduct: 'Corporate',
      owner: 'Krishna',
      rfqStatus: 'Pending',
      qcrStatus: 'In Review',
      dealStatus: 'RFQ',
    },
    {
      id: 'OPP-8803',
      lob: 'Property',
      product: 'Fire & Burglary',
      subProduct: 'Industrial',
      owner: 'Raj',
      rfqStatus: 'Closed',
      qcrStatus: 'Approved',
      dealStatus: 'Won',
    },
    {
      id: 'OPP-8804',
      lob: 'Marine',
      product: 'Cargo',
      subProduct: 'Import',
      owner: 'Pankaj Sahu',
      rfqStatus: 'Submitted',
      qcrStatus: 'Rejected',
      dealStatus: 'Lost',
    },
    {
      id: 'OPP-8805',
      lob: 'Liability',
      product: 'D&O',
      subProduct: 'Corporate',
      owner: 'Krishna',
      rfqStatus: 'Draft',
      qcrStatus: 'Pending',
      dealStatus: 'RFQ',
    },
  ],
};

const formatCreatedDate = (value) => {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
};

/** Backend client_type_code -> display label. */
const CLIENT_TYPE_LABELS = { cttd: 'Dealer', cttc: 'Corporate' };

const normalizeOwnerName = (owner) =>
  String(
    owner?.owner_name ??
      owner?.key_value ??
      owner?.full_name ??
      owner?.name ??
      owner?.value ??
      owner?.user_name ??
      owner?.username ??
      '',
  ).trim();

const normalizeOwnerCode = (owner) =>
  String(
    owner?.owner_id ??
      owner?.userid ??
      owner?.key_code ??
      owner?.user_id ??
      owner?.id ??
      owner?.code ??
      '',
  ).trim();

const normalizeOwnerRecord = (owner, fallbackName = '') => ({
  ...owner,
  code: normalizeOwnerCode(owner),
  value: normalizeOwnerName(owner) || String(fallbackName ?? '').trim(),
});

/**
 * Build the detail profile from the REAL /clients/get response.
 * The get API returns: payload.client (id/name/type), payload.contacts[],
 * payload.client_data.{client (statutory), address}. Fields it does NOT return
 * (owner, co-owner, approved, vertical) fall back to the list row where available.
 *
 * Portfolios & Opportunities stay DUMMY here — they'll come from their own APIs later.
 */
export const mapClientDetailFromApi = (apiResponse, clientUUID, listRow) => {
  const payload = apiResponse?.payload ?? {};
  const client = payload.client ?? {};
  const clientData = payload.client_data ?? {};
  const cdClient = clientData.client ?? {};
  const cdAddress = clientData.address ?? {};
  const apiContacts = Array.isArray(payload.contacts) ? payload.contacts : [];
  const primaryOwnerRecords = Array.isArray(payload.owner)
    ? payload.owner
    : Array.isArray(payload.owners)
      ? payload.owners.filter((owner) => String(owner?.owner_type_code ?? '').toUpperCase() === 'PRIMARY')
      : Array.isArray(client.owners)
        ? client.owners.filter((owner) => String(owner?.owner_type_code ?? '').toUpperCase() === 'PRIMARY')
        : [];
  const coOwnerRecords = Array.isArray(payload.coowner)
    ? payload.coowner
    : Array.isArray(payload.owners)
      ? payload.owners.filter((owner) => String(owner?.owner_type_code ?? '').toUpperCase() === 'CO_OWNER')
      : Array.isArray(client.owners)
        ? client.owners.filter((owner) => String(owner?.owner_type_code ?? '').toUpperCase() === 'CO_OWNER')
        : [];
  const primaryOwnerRecord = primaryOwnerRecords[0];

  const addressLine =
    [cdAddress.address_line1, cdAddress.address_line2].filter(Boolean).join(', ') ||
    listRow?.client_city ||
    '';

  const primaryOwner = normalizeOwnerName(primaryOwnerRecord) || client.client_owner || listRow?.client_owner || '';
  const portfolios = normalizeClientPortfolios(clientData.portfolio).map((portfolio) => ({
    ...portfolio,
    owner: portfolio.owner || primaryOwner,
  }));

  return {
    clientUUID: clientUUID || DEFAULT_PROFILE.clientUUID,
    clientName: client.client_name || listRow?.client_name || '',
    // The get API now returns client_code + created_on / approval_on + owner / status / vertical
    // directly; the list row is only a fallback when a field is absent.
    clientCode: client.client_code || (client.client_id != null ? String(client.client_id) : (listRow?.client_id || '')),
    codeDate: formatCreatedDate(client.created_on || listRow?.createdDate) || '',
    clientType:
      client.client_type || CLIENT_TYPE_LABELS[client.client_type_code] || client.client_type_code || listRow?.client_type || '',
    vertical: client.client_vertical || listRow?.client_vertical || '',
    status: client.client_status || listRow?.client_status || '',
    primaryOwner,
    primaryOwnerRecord: primaryOwnerRecord ? normalizeOwnerRecord(primaryOwnerRecord, primaryOwner) : null,
    coOwners: coOwnerRecords.map(normalizeOwnerRecord).filter((owner) => owner.value),
    approvedBy:
      client.approve_by && String(client.approve_by).trim() !== '0' ? client.approve_by : '---',
    approvedDate: client.approval_on ? formatCreatedDate(client.approval_on) : '',
    address: {
      line: addressLine,
      pincode: client.pincode || cdAddress.pincode || '',
      city: cdAddress.city_name || cdAddress.city || client.city_name || listRow?.client_city || listRow?.city_name || '',
      state: cdAddress.state_name || cdAddress.state || client.state_name || listRow?.state_name || '',
    },
    statutory: {
      gstin: cdClient.gstin || '',
      cin: cdClient.cin_number || '',
      pan: cdClient.pancard || '',
    },
    isActive: client.active ?? cdClient.is_active,
    portfolios,
    contacts: apiContacts.map((c) => ({
      name: c?.name ?? '',
      mobile: c?.mobile ?? '',
      email: c?.email ?? '',
    })),
    // Access-control flags from rfq_sp_get_client (strings "1"/"0"). canApprove drives whether
    // the approval action is shown at all — only the entitled reviewer sees it.
    canApprove: String(payload.is_approve ?? '') === '1',
    canEdit: String(payload.is_edit ?? '') === '1',
    canEditOwner: String(payload.is_owner ?? '') === '1',
    canView: String(payload.is_view ?? '1') === '1',
    canToggleActive: String(payload.is_active ?? '') === '1',
    // Portfolios & Opportunities are now owned by their own components
    // (ClientPortfolios / ClientOpportunities), each with its own dummy data + future API.
  };
};

export const getClientDetailProfile = (clientUUID, listRow) => {
  const base = {
    ...DEFAULT_PROFILE,
    clientUUID: clientUUID || DEFAULT_PROFILE.clientUUID,
    clientName: listRow?.clientName || DEFAULT_PROFILE.clientName,
    clientType: listRow?.clientType || DEFAULT_PROFILE.clientType,
    vertical: listRow?.vertical || DEFAULT_PROFILE.vertical,
    status: listRow?.status || DEFAULT_PROFILE.status,
    primaryOwner: listRow?.primaryOwner || DEFAULT_PROFILE.primaryOwner,
    codeDate: formatCreatedDate(listRow?.createdDate) || DEFAULT_PROFILE.codeDate,
    contacts: [
      {
        name: listRow?.primaryContactName || DEFAULT_PROFILE.contacts[0].name,
        mobile: listRow?.mobile || DEFAULT_PROFILE.contacts[0].mobile,
        email: listRow?.email || DEFAULT_PROFILE.contacts[0].email,
      },
      DEFAULT_PROFILE.contacts[1],
    ],
    address: {
      ...DEFAULT_PROFILE.address,
      city: listRow?.city || DEFAULT_PROFILE.address.city,
      state: listRow?.state || DEFAULT_PROFILE.address.state,
      line: [listRow?.city, listRow?.state].filter(Boolean).join(', ') || DEFAULT_PROFILE.address.line,
    },
  };

  if (listRow?.clientName?.toLowerCase().includes('sandeep')) {
    return {
      ...base,
      clientName: listRow.clientName,
      clientCode: 'SDS-001',
      primaryOwner: listRow.primaryOwner || 'Rajesh Sharma',
    };
  }

  if (listRow?.clientName?.toLowerCase().includes('acme')) {
    return {
      ...base,
      clientName: listRow.clientName,
      clientCode: 'ACM-442',
      clientType: listRow.clientType || 'Corporate',
      vertical: listRow.vertical || 'Commercial Vehicles',
    };
  }

  return {
    ...base,
    clientCode: `CL-${String(clientUUID || '001').slice(-4).toUpperCase()}`,
  };
};
