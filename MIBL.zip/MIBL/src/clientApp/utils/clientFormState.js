export const mapSecondariesFromRecord = (items = []) =>
  items
    .map((item) => ({
      name: item?.name ?? '',
      mobile: item?.mobile ?? '',
      email: item?.email ?? '',
    }))
    .filter((item) => item.name.trim() || item.mobile.trim() || item.email.trim());

const resolveClientStatus = (client, responseClient, listRow) =>
  responseClient?.client_status ??
  client?.client_status ??
  listRow?.client_status ??
  client?.status_text ??
  '';

const resolveIsActive = (...sources) => {
  const rawValue = sources.find((value) => value !== undefined && value !== null);
  if (rawValue === undefined) return undefined;
  return String(rawValue) === '1' ? 1 : 0;
};

export const mapClientRecordToFormDraft = (client, listRow) => {
  if (!client) return null;

  if (client.basicDetails) {
    return {
      clientUUID: client.clientUUID ?? client.uuid ?? client.id ?? '',
      is_active: resolveIsActive(client.active, client.client_data?.client?.is_active),
      status: resolveClientStatus(client, null, listRow) || client.status || '',
      basicDetails: client.basicDetails,
      address: client.address ?? {},
      communication: {
        primary_contact_name: client.communication?.primary_contact_name ?? '',
        primary_mobile: client.communication?.primary_mobile ?? '',
        primary_email: client.communication?.primary_email ?? '',
        secondaries: mapSecondariesFromRecord(client.communication?.secondaries),
      },
      accountOwner: client.accountOwner ?? {},
      portfolios: client.portfolios ?? [],
    };
  }

  // The real /clients/get response wraps everything in `payload`; older/fallback shapes don't.
  const root = client.payload ?? client;
  const responseClient = root.client ?? {};
  const responseClientData = root.client_data?.client ?? {};
  const legacyAddress = root.client_data?.address ?? {};
  const legacyPortfolio = root.client_data?.portfolio;
  const primaryContact = root.contacts?.[0] ?? {};

  return {
    clientUUID:
      client.clientUUID ??
      client.uuid ??
      client.id ??
      responseClient.client_UUID ??
      responseClient.client_id ??
      '',
    is_active: resolveIsActive(responseClient.active, responseClientData.is_active),
    status: resolveClientStatus(client, responseClient, listRow),
    basicDetails: {
      client_name: responseClient.client_name ?? client.clientName ?? '',
      // client_type / vertical are backend CODES (kds key_code). KdsSelect stores the code and
      // resolves the label from the master, so we set the raw code straight through here.
      client_type:
        responseClient.client_type_code ??
        listRow?.client_type_code ??
        client.clientType ??
        '',
      vertical: responseClient.client_vertical_code ?? '',
      pan: responseClientData.pancard ?? '',
      cin: responseClientData.cin_number ?? '',
      gstin: responseClientData.gstin ?? '',
    },
    address: {
      address_line1: legacyAddress.address_line1 ?? '',
      address_line2: legacyAddress.address_line2 ?? '',
      // We save city/state as names (city_name/state_name); they echo back here on edit.
      city: legacyAddress.city_name ?? legacyAddress.city ?? client.city_name ?? client.city ?? '',
      state: legacyAddress.state_name ?? legacyAddress.state ?? client.state_name ?? '',
      pincode: legacyAddress.pincode ?? '',
    },
    communication: {
      primary_contact_name:
        client.communication?.primary_contact_name ?? primaryContact.name ?? '',
      primary_mobile: client.communication?.primary_mobile ?? primaryContact.mobile ?? client.mobile ?? '',
      primary_email: client.communication?.primary_email ?? primaryContact.email ?? client.email ?? '',
      secondaries: mapSecondariesFromRecord(
        client.communication?.secondaries ?? (root.contacts ?? []).slice(1),
      ),
    },
    // The get API returns a single client_data.portfolio (legacy keys lob/biz_type/brokerage);
    // wrap it so applyClientRecord pre-fills the Portfolio section. mapPortfolioToForm handles
    // the legacy -> form key conversion.
    portfolios: legacyPortfolio
      ? [legacyPortfolio]
      : client.portfolios ?? [],
  };
};

