import { CLIENT_CREATE_MESSAGES as MSG } from '../config/messages/client.js';
import { PATTERNS } from '../config/patterns.js';
import { SECTION_KEYS, OPTIONAL_CLIENT_SECTIONS } from '../config/clientFormSteps.js';
import { isValidByField, sanitizeFieldValue } from './fieldUtils.js';
import { validatePortfolioForm } from './portfolioFormValidation.js';
import { VERTICAL_CODE_MAP } from '../config/clientApiConfig.js';

export { SECTION_KEYS };

const isValidName = (value) => PATTERNS.NAME.test(value.trim());

const setIf = (errors, key, condition, message) => {
  if (condition) errors[key] = message;
};

export const isSmeVertical = (value) => {
  const normalizedValue = String(value ?? '').trim().toLowerCase();
  return normalizedValue === 'sme' || normalizedValue === String(VERTICAL_CODE_MAP.SME ?? '').toLowerCase();
};

export const validateBasicSection = (basicDetails) => {
  const errors = {};
  setIf(errors, 'client_name', !basicDetails.client_name?.trim(), MSG.errors.clientNameRequired);
  setIf(errors, 'vertical', !basicDetails.vertical, MSG.errors.verticalRequired);
  setIf(
    errors,
    'client_type',
    isSmeVertical(basicDetails.vertical) && !basicDetails.client_type,
    MSG.errors.clientTypeRequired,
  );

  const pan = basicDetails.pan?.trim() ?? '';
  if (pan && !isValidByField('pan', pan)) errors.pan = MSG.errors.invalidPan;

  const gstin = basicDetails.gstin?.trim() ?? '';
  if (gstin && !isValidByField('gstin', gstin)) errors.gstin = MSG.errors.invalidGstin;

  const cin = basicDetails.cin?.trim() ?? '';
  if (cin && !isValidByField('cin', cin)) errors.cin = MSG.errors.invalidCin;

  return errors;
};

export const validateAddressSection = (address) => {
  const errors = {};
  const pincode = address.pincode?.trim() ?? '';
  setIf(errors, 'pincode', !pincode, MSG.errors.pincodeRequired);
  if (pincode && !isValidByField('pincode', pincode)) errors.pincode = MSG.errors.invalidPincode;

  const city = address.city?.trim() ?? '';
  setIf(errors, 'city', !city, MSG.errors.cityRequired);
  if (city && !isValidName(city)) errors.city = MSG.errors.invalidCityState;

  const state = address.state?.trim() ?? '';
  setIf(errors, 'state', !state, MSG.errors.stateRequired);
  if (state && !isValidName(state)) errors.state = MSG.errors.invalidCityState;

  return errors;
};

export const validateCommunicationPrimary = (communication) => {
  const errors = {};
  setIf(
    errors,
    'primary_contact_name',
    !communication.primary_contact_name?.trim(),
    MSG.errors.primaryContactNameRequired,
  );
  setIf(
    errors,
    'comm_primary_mobile',
    !communication.primary_mobile?.trim(),
    MSG.errors.primaryContactMobileRequired,
  );
  setIf(
    errors,
    'comm_primary_email',
    !communication.primary_email?.trim(),
    MSG.errors.primaryContactEmailRequired,
  );

  const primaryName = communication.primary_contact_name?.trim() ?? '';
  if (primaryName && !isValidName(primaryName)) errors.primary_contact_name = MSG.errors.invalidName;

  if (communication.primary_mobile?.trim() && !isValidByField('mobile', communication.primary_mobile.trim())) {
    errors.comm_primary_mobile = MSG.errors.invalidMobile;
  }
  if (communication.primary_email?.trim() && !isValidByField('email', communication.primary_email.trim())) {
    errors.comm_primary_email = MSG.errors.invalidEmail;
  }

  return errors;
};

export const validateCommunicationSecondaries = (communication) => {
  const errors = {};

  communication.secondaries?.forEach((item, index) => {
    const name = item.name?.trim() ?? '';
    const mobile = item.mobile?.trim() ?? '';
    const email = item.email?.trim() ?? '';

    if (name && !isValidName(name)) errors[`secondary_name_${index}`] = MSG.errors.invalidName;
    if (mobile && !isValidByField('mobile', mobile)) errors[`secondary_mobile_${index}`] = MSG.errors.invalidMobile;
    if (email && !isValidByField('email', email)) errors[`secondary_email_${index}`] = MSG.errors.invalidEmail;
  });

  return errors;
};

export const validateContactSection = (address, communication) => ({
  ...validateAddressSection(address),
  ...validateCommunicationPrimary(communication),
  ...validateCommunicationSecondaries(communication),
});

export const validatePortfolioSection = (portfolioDraft) => validatePortfolioForm(portfolioDraft ?? {});

const sectionValidators = {
  [SECTION_KEYS.basic]: (formData) => validateBasicSection(formData.basicDetails),
  [SECTION_KEYS.contact]: (formData) => validateContactSection(formData.address, formData.communication),
  [SECTION_KEYS.portfolio]: (_data, portfolioDraft) => validatePortfolioSection(portfolioDraft),
};

export const validateSection = (sectionKey, formData, portfolioDraft = null) => {
  const validator = sectionValidators[sectionKey];
  if (!validator) return {};

  if (sectionKey === SECTION_KEYS.portfolio) {
    return validator(formData, portfolioDraft);
  }

  return validator(formData);
};

export const validateAllSections = (formData, portfolioDraft = null) =>
  Object.keys(sectionValidators).reduce((allErrors, sectionKey) => {
    const sectionErrors = validateSection(sectionKey, formData, portfolioDraft);
    return { ...allErrors, ...sectionErrors };
  }, {});

export const isSectionComplete = (sectionKey, formData, portfolioDraft = null, visitedSections = new Set()) => {
  const errors = validateSection(sectionKey, formData, portfolioDraft);
  if (Object.keys(errors).length > 0) return false;

  if (OPTIONAL_CLIENT_SECTIONS.has(sectionKey) && !visitedSections.has(sectionKey)) {
    return false;
  }

  return true;
};

export const getCompletedSections = (formData, portfolioDraft = null, visitedSections = new Set()) =>
  Object.keys(sectionValidators).filter((key) =>
    isSectionComplete(key, formData, portfolioDraft, visitedSections),
  );

export { sanitizeFieldValue };
