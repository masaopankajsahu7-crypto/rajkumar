import { APP_CONFIG } from '../config/appConfig.js';
import { CLIENT_TYPE_LABEL_MAP, VERTICAL_LABEL_MAP } from '../config/clientApiConfig.js';
import { getListIsAddFlag, getListIsReassignFlag } from './listPermissions.js';

export const CLIENT_LIST_PAGE_SIZE = APP_CONFIG.LIST_PAGE_SIZE;

export const MOCK_EXISTING_CLIENT_NAMES = ['sandeep d sharma', 'client 1', 'acme corp'];

const getClientName = (client) => {
  const basic = client?.basicDetails ?? client;
  return (
    basic?.client_name ??
    client?.client_name ??
    client?.clientName ??
    ''
  );
};

const firstNonBlank = (...values) =>
  values.find((value) => String(value ?? '').trim() !== '') ?? '';

export const mapClientToListRow = (client) => {
  const basic = client?.basicDetails ?? {};
  const address = client?.address ?? client?.client_data?.address ?? {};
  const communication = client?.communication ?? {};
  const accountOwner = client?.accountOwner ?? {};

  return {
    clientUUID: client?.clientUUID ?? client?.client_UUID ?? client?.client_ID ?? client?.uuid ?? client?.id ?? '',
    clientName: getClientName(client),
    clientType:
      basic.client_type ??
      client?.client_type ??
      CLIENT_TYPE_LABEL_MAP[client?.client_type_code] ??
      client?.client_type_code ??
      '',
    vertical:
      basic.vertical ??
      client?.vertical ??
      VERTICAL_LABEL_MAP[client?.v_client_vertical_code] ??
      client?.v_client_vertical_code ??
      '',
    city: firstNonBlank(address.city, address.city_name, client?.city, client?.city_name),
    city_name: firstNonBlank(client?.city_name, address.city_name, address.city),
    pincode: firstNonBlank(address.pincode, client?.pincode),
    state: firstNonBlank(address.state, address.state_name, client?.state_name),
    state_name: firstNonBlank(client?.state_name, address.state_name, address.state),
    email: communication.primary_email ?? accountOwner.primary_email ?? client?.email ?? '',
    mobile: communication.primary_mobile ?? accountOwner.primary_mobile ?? client?.contact ?? '',
    primaryContactName:
      communication.primary_contact_name ??
      communication.primary_contact_person ??
      client?.primaryContactName ??
      '',
    primaryOwner:
      accountOwner.primary_owner ??
      accountOwner.name ??
      client?.primaryOwner ??
      client?.client_owner ??
      client?.primary_owner ??
      '',
    ownerId: accountOwner.owner_id ?? client?.ownerId ?? client?.owner_id ?? '',
    createdDate:
      client?.createdDate ??
      client?.created_on ??
      client?.created_at ??
      client?.onboardedDate ??
      client?.onboarded_date ??
      '',
    status: client?.status ?? client?.client_status ?? '',
    activeState:
      client?.active ??
      client?.activeState ??
      client?.client_state ??
      '',
  };
};

/** Normalizes GET /clients response into an array of client objects */
export const normalizeClientList = (response) => {
  if (!response) return [];

  if (Array.isArray(response)) return response;

  const candidates = [
    response.data,
    response.content,
    response.items,
    response.clients,
    response.result,
    response.result0,
    response.list,
    response.rows,
    response.records,
    response.payload?.clients,
    response.payload?.list,
    response.payload?.data,
    response.data?.clients,
    response.data?.list,
  ];

  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return candidate;
  }

  return [];
};

const enrichClientListRow = (client) => {
  const address = client?.client_data?.address ?? client?.address ?? {};

  return {
    ...client,
    city_name: firstNonBlank(client?.city_name, address.city_name, address.city),
    state_name: firstNonBlank(client?.state_name, address.state_name, address.state),
    pincode: firstNonBlank(client?.pincode, address.pincode),
  };
};

export const getAllClientRows = (response) => {
  return normalizeClientList(response).map(mapClientToListRow);
};

export function getPaginatedClientRows(rows, page = 1) {
  const start = (page - 1) * CLIENT_LIST_PAGE_SIZE;
  return {
    list: rows.slice(start, start + CLIENT_LIST_PAGE_SIZE),
    totalCount: rows.length,
  };
}

export function parseClientListApiResponse(response, page = 1) {
  // Rows are returned as-is from the API so the list columns stay dynamic
  // (whatever keys the response contains are what gets shown).
  const list = normalizeClientList(response).map(enrichClientListRow);

  const totalCount = response?.payload?.total_records ?? list.length;

  return {
    list,
    totalCount: Number(totalCount) || 0,
    page: response?.page ?? response?.currentPage ?? page,
    isAdd: getListIsAddFlag(response),
    isReassign: getListIsReassignFlag(response),
  };
}

export function getClientTotalPages(totalCount, pageSize = CLIENT_LIST_PAGE_SIZE) {
  if (!totalCount) return 0;
  return Math.ceil(totalCount / pageSize);
}
