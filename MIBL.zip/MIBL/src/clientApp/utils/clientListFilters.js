import { APP_CONFIG } from '../config/appConfig.js';
import {
  DEFAULT_DATE_RANGE_PRESET,
  DEFAULT_SORT_ORDER,
  getDateFilterTypeLabel,
  getDateRangeLabel,
} from './dateRangeFilters.js';

export const INITIAL_CLIENT_FILTERS = {
  search: '',
  clientName: '',
  clientUUID: '',
  clientType: '',
  clientTypeLabel: '',
  primaryOwner: '',
  ownerId: '',
  vertical: '',
  verticalLabel: '',
  pincode: '',
  cityName: '',
  clientStatus: '',
  clientStatusLabel: '',
  activeState: '',
  fromDate: '',
  toDate: '',
  dateRangePreset: DEFAULT_DATE_RANGE_PRESET,
  dateFilterType: 'created_on',
  sortOrder: DEFAULT_SORT_ORDER,
};

export const normalizeClientListFilters = (filters = INITIAL_CLIENT_FILTERS) => ({
  search: String(filters.search ?? '').trim(),
  clientName: String(filters.clientName ?? '').trim(),
  clientUUID: String(filters.clientUUID ?? '').trim(),
  clientType: String(filters.clientType ?? '').trim(),
  clientTypeLabel: String(filters.clientTypeLabel ?? '').trim(),
  primaryOwner: String(filters.primaryOwner ?? '').trim(),
  ownerId: String(filters.ownerId ?? '').trim(),
  vertical: String(filters.vertical ?? '').trim(),
  verticalLabel: String(filters.verticalLabel ?? '').trim(),
  pincode: String(filters.pincode ?? '').trim(),
  cityName: String(filters.cityName ?? '').trim(),
  clientStatus: String(filters.clientStatus ?? '').trim(),
  clientStatusLabel: String(filters.clientStatusLabel ?? '').trim(),
  activeState: String(filters.activeState ?? '').trim(),
  fromDate: String(filters.fromDate ?? '').trim(),
  toDate: String(filters.toDate ?? '').trim(),
  dateRangePreset: String(filters.dateRangePreset ?? '').trim(),
  dateFilterType: String(filters.dateFilterType ?? '').trim(),
  sortOrder: String(filters.sortOrder ?? '').trim(),
});

export const buildClientListQueryParams = (page = 1, filters = INITIAL_CLIENT_FILTERS, pageSize) => {
  const normalized = normalizeClientListFilters(filters);
  const params = new URLSearchParams();

  params.set('page', String(page));
  params.set('pageSize', String(pageSize ?? APP_CONFIG.LIST_PAGE_SIZE));

  if (normalized.search) params.set('search', normalized.search);
  if (normalized.clientName) params.set('clientName', normalized.clientName);
  if (normalized.clientUUID) params.set('clientUUID', normalized.clientUUID);
  if (normalized.clientType) params.set('clientType', normalized.clientType);
  if (normalized.primaryOwner) params.set('primaryOwner', normalized.primaryOwner);
  if (normalized.ownerId) params.set('ownerId', normalized.ownerId);
  if (normalized.vertical) params.set('vertical', normalized.vertical);
  if (normalized.pincode) params.set('pincode', normalized.pincode);
  if (normalized.cityName) params.set('cityName', normalized.cityName);
  if (normalized.clientStatus) params.set('clientStatus', normalized.clientStatus);
  if (normalized.activeState) params.set('activeState', normalized.activeState);
  if (normalized.fromDate) params.set('fromDate', normalized.fromDate);
  if (normalized.toDate) params.set('toDate', normalized.toDate);
  if (normalized.dateRangePreset) params.set('dateRangePreset', normalized.dateRangePreset);
  if (normalized.dateFilterType) params.set('dateFilterType', normalized.dateFilterType);
  if (normalized.sortOrder) params.set('sortOrder', normalized.sortOrder);

  return params;
};

const toComparableDate = (value) => {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const matchesDateRange = (rowDateValue, fromDate, toDate) => {
  const rowDate = toComparableDate(rowDateValue);
  if (!rowDate) return false;

  const from = toComparableDate(fromDate);
  const to = toComparableDate(toDate);

  if (from && rowDate < from) return false;
  if (to) {
    const endOfDay = new Date(to);
    endOfDay.setHours(23, 59, 59, 999);
    if (rowDate > endOfDay) return false;
  }

  return true;
};

const GENERIC_SEARCH_FIELDS = [
  'clientName',
  'clientType',
  'vertical',
  'city',
  'state',
  'email',
  'mobile',
  'primaryOwner',
  'primaryContactName',
  'status',
];

export const matchesGenericSearch = (row, search) => {
  const query = String(search ?? '').trim().toLowerCase();
  if (!query) return true;

  return GENERIC_SEARCH_FIELDS.some((field) =>
    String(row?.[field] ?? '')
      .toLowerCase()
      .includes(query),
  );
};

export const filterClientRows = (rows, filters = INITIAL_CLIENT_FILTERS) => {
  const search = String(filters.search ?? '').trim();
  const clientName = String(filters.clientName ?? '').trim().toLowerCase();
  const clientUUID = String(filters.clientUUID ?? '').trim().toLowerCase();
  const clientType = String(filters.clientType ?? '').trim();
  const primaryOwner = String(filters.primaryOwner ?? '').trim().toLowerCase();
  const ownerId = String(filters.ownerId ?? '').trim().toLowerCase();
  const vertical = String(filters.vertical ?? '').trim();
  const pincode = String(filters.pincode ?? '').trim();
  const cityName = String(filters.cityName ?? '').trim().toLowerCase();
  const clientStatus = String(filters.clientStatus ?? '').trim();
  const activeState = String(filters.activeState ?? '').trim();
  const fromDate = filters.fromDate ?? '';
  const toDate = filters.toDate ?? '';
  const hasDateFilter = Boolean(fromDate || toDate);

  return (rows ?? []).filter((row) => {
    if (!matchesGenericSearch(row, search)) {
      return false;
    }

    if (clientName && !String(row.clientName ?? '').toLowerCase().includes(clientName)) {
      return false;
    }

    if (clientUUID && !String(row.clientUUID ?? row.client_uuid ?? '').toLowerCase().includes(clientUUID)) {
      return false;
    }

    if (clientType && String(row.clientType ?? '') !== clientType) {
      return false;
    }

    if (primaryOwner && !String(row.primaryOwner ?? '').toLowerCase().includes(primaryOwner)) {
      return false;
    }

    if (ownerId && !String(row.ownerId ?? row.owner_id ?? '').toLowerCase().includes(ownerId)) {
      return false;
    }

    if (vertical && String(row.vertical ?? '') !== vertical) {
      return false;
    }

    if (pincode && String(row.pincode ?? '') !== pincode) {
      return false;
    }

    if (cityName && !String(row.city ?? row.city_name ?? '').toLowerCase().includes(cityName)) {
      return false;
    }

    if (clientStatus && String(row.status ?? row.client_status ?? '') !== clientStatus) {
      return false;
    }

    if (activeState && String(row.activeState ?? row.active_state ?? '') !== activeState) {
      return false;
    }

    if (hasDateFilter && !matchesDateRange(row.createdDate, fromDate, toDate)) {
      return false;
    }

    return true;
  });
};

export const hasActiveClientFilters = (filters = INITIAL_CLIENT_FILTERS) =>
  Object.entries(filters).some(([key, value]) => {
    if (key === 'ownerId' || key === 'clientUUID') return false;
    if ((key === 'fromDate' || key === 'toDate') && filters.dateRangePreset !== 'CUSTOM') return false;
    if (key === 'dateRangePreset' && value === DEFAULT_DATE_RANGE_PRESET) return false;
    if (key === 'dateFilterType' && value === 'created_on') return false;
    if (key === 'sortOrder' && value === DEFAULT_SORT_ORDER) return false;
    return String(value ?? '').trim() !== '';
  });

export const countActiveClientFilters = (filters = INITIAL_CLIENT_FILTERS) =>
  Object.entries(filters).filter(([key, value]) => {
    if (key === 'ownerId' || key === 'clientUUID' || key.endsWith('Label')) return false;
    if (['fromDate', 'toDate', 'dateRangePreset', 'dateFilterType', 'sortOrder'].includes(key)) return false;
    return String(value ?? '').trim() !== '';
  }).length;

const formatChipDate = (value) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

export const getActiveClientFilterChips = (filters = INITIAL_CLIENT_FILTERS, labels = {}) => {
  const chips = [];

  if (String(filters.search ?? '').trim()) {
    chips.push({ key: 'search', label: `${labels.search ?? 'Search'}: ${filters.search.trim()}` });
  }
  if (String(filters.clientName ?? '').trim()) {
    chips.push({ key: 'clientName', label: `${labels.clientName ?? 'Client'}: ${filters.clientName.trim()}` });
  }
  if (String(filters.clientType ?? '').trim()) {
    chips.push({
      key: 'clientType',
      label: `${labels.clientType ?? 'Type'}: ${filters.clientTypeLabel || filters.clientType}`,
    });
  }
  if (String(filters.primaryOwner ?? '').trim()) {
    chips.push({
      key: 'primaryOwner',
      label: `${labels.primaryOwner ?? 'Owner'}: ${filters.primaryOwner.trim()}`,
    });
  }
  if (String(filters.vertical ?? '').trim()) {
    chips.push({
      key: 'vertical',
      label: `${labels.vertical ?? 'Vertical'}: ${filters.verticalLabel || filters.vertical}`,
    });
  }
  if (String(filters.pincode ?? '').trim()) {
    chips.push({ key: 'pincode', label: `${labels.pincode ?? 'Pincode'}: ${filters.pincode.trim()}` });
  }
  if (String(filters.cityName ?? '').trim()) {
    chips.push({ key: 'cityName', label: `${labels.cityName ?? 'City'}: ${filters.cityName.trim()}` });
  }
  if (String(filters.clientStatus ?? '').trim()) {
    chips.push({
      key: 'clientStatus',
      label: `${labels.clientStatus ?? 'Status'}: ${filters.clientStatusLabel || filters.clientStatus}`,
    });
  }
  if (String(filters.activeState ?? '').trim()) {
    chips.push({ key: 'activeState', label: `${labels.activeState ?? 'Client Status'}: ${filters.activeState}` });
  }
  const shouldShowCustomDates = filters.dateRangePreset === 'CUSTOM';

  if (shouldShowCustomDates && String(filters.fromDate ?? '').trim()) {
    chips.push({
      key: 'fromDate',
      label: `${labels.fromDate ?? 'From'}: ${formatChipDate(filters.fromDate)}`,
    });
  }
  if (shouldShowCustomDates && String(filters.toDate ?? '').trim()) {
    chips.push({
      key: 'toDate',
      label: `${labels.toDate ?? 'To'}: ${formatChipDate(filters.toDate)}`,
    });
  }
  if (
    String(filters.dateRangePreset ?? '').trim() &&
    filters.dateRangePreset !== DEFAULT_DATE_RANGE_PRESET
  ) {
    chips.push({
      key: 'dateRangePreset',
      label: `${labels.dateRangePreset ?? 'Date Range'}: ${getDateRangeLabel(filters.dateRangePreset)}`,
    });
  }
  if (String(filters.dateFilterType ?? '').trim() && filters.dateFilterType !== 'created_on') {
    chips.push({
      key: 'dateFilterType',
      label: `${labels.dateFilterType ?? 'Date Type'}: ${getDateFilterTypeLabel(filters.dateFilterType)}`,
    });
  }
  return chips;
};
