export const mapClientSearchHit = (item) => {
  const ownerName =
    item?.owner_name ??
    item?.owner ??
    item?.client_owner ??
    item?.primary_owner ??
    item?.accountOwner?.primary_owner ??
    item?.accountOwner?.name ??
    '';

  return {
    clientUUID:
      item?.client_UUID ??
      item?.clientUUID ??
      item?.uuid ??
      item?.id ??
      '',
    clientName:
      item?.client_name ??
      item?.clientName ??
      item?.basicDetails?.client_name ??
      '',
    city: item?.city ?? item?.address?.city ?? '',
    owner: ownerName,
    primaryOwner: ownerName,
    coOwner: item?.co_owner_name ?? item?.coOwner ?? '',
  };
};

export const normalizeClientSearchResults = (response) => {
  if (!response) return [];

  if (Array.isArray(response)) {
    return response.map(mapClientSearchHit).filter((item) => item.clientName);
  }

  const candidates = [
    response.payload,   // client-service /clients/check shape: { status, message, payload: [...] }
    response.data,
    response.results,
    response.items,
    response.clients,
    response.content,
  ];

  for (const candidate of candidates) {
    if (Array.isArray(candidate)) {
      return candidate.map(mapClientSearchHit).filter((item) => item.clientName);
    }
  }

  return [];
};
