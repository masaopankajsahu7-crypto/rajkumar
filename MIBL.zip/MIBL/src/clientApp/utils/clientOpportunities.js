const getOpportunityList = (response) => {
  if (Array.isArray(response)) return response;
  if (Array.isArray(response?.list)) return response.list;
  if (Array.isArray(response?.payload?.opportunities)) return response.payload.opportunities;
  if (Array.isArray(response?.payload?.opportunity_list)) return response.payload.opportunity_list;
  if (Array.isArray(response?.payload?.list)) return response.payload.list;
  if (Array.isArray(response?.payload?.data)) return response.payload.data;
  if (Array.isArray(response?.opportunities)) return response.opportunities;
  if (Array.isArray(response?.data)) return response.data;
  return [];
};

/** Best-effort parse of an opportunities API response into the client detail table row shape. */
export const normalizeClientOpportunities = (response) => {
  const list = getOpportunityList(response);
  return list.map((o, i) => ({
    id: o?.opportunity_code ?? o?.opp_code ?? o?.opportunity_id ?? o?.id ?? '',
    businessType: o?.opportunity_type ?? o?.biz_type ?? o?.businessType ?? o?.business_type ?? '',
    product: o?.opportunity_product ?? o?.product ?? '',
    subProduct: o?.opportunity_sub_product ?? o?.sub_product ?? o?.subProduct ?? '',
    owner: o?.portfolio_owner ?? o?.owner ?? o?.opportunity_owner ?? o?.primary_owner ?? '',
    placementRm: o?.placement_rm ?? o?.placement_head ?? o?.placementRm ?? '',
    renewalDate: o?.renewal_date ?? o?.renewalDate ?? '',
    status: o?.opportunity_status ?? o?.status ?? o?.deal_status ?? o?.dealStatus ?? '',
    stage: o?.opportunity_stage ?? o?.stage ?? '',
  }));
};
