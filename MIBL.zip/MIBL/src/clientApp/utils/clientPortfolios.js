import { getListIsAddFlag, getListIsReassignFlag } from './listPermissions.js';

const toPortfolioList = (value) => {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
};

const joinPortfolioName = (product, subProduct) =>
  [product, subProduct].map((value) => String(value ?? '').trim()).filter(Boolean).join(' - ');

const isActiveValue = (value) => {
  const normalized = String(value ?? '').trim().toLowerCase();
  return normalized === '1' || normalized === 'true' || normalized === 'active';
};

/** Best-effort parse of a (future) portfolios API response into the table row shape. */
export const normalizeClientPortfolios = (response) => {
  const list =
    response?.payload?.portfolios ??
    response?.payload?.client_data?.portfolio ??
    response?.payload ??
    response?.client_data?.portfolio ??
    response?.portfolio ??
    response?.portfolios ??
    response?.data ??
    response;
  return toPortfolioList(list).map((p, i) => {
    const product = p?.portfolio_product ?? p?.product ?? '';
    const subProduct = p?.portfolio_sub_product ?? p?.sub_product ?? p?.subProduct ?? '';

    return {
      raw: p,
      id: p?.portfolio_code ?? p?.portfolio_uuid ?? p?.portfolio_UUID ?? p?.portfolio_id ?? p?.id ?? '',
      uuid: p?.portfolio_uuid ?? p?.portfolio_UUID ?? '',
      portfolioCode: p?.portfolio_code ?? '',
      clientUUID: p?.client_uuid ?? p?.client_UUID ?? p?.clientUUID ?? '',
      clientName: p?.client_name ?? p?.clientName ?? p?.client ?? '',
      clientVertical: p?.client_vertical ?? p?.clientVertical ?? p?.client?.client_vertical ?? '',
      portfolio: joinPortfolioName(product, subProduct),
      lob: p?.portfolio_lob ?? p?.lob ?? '',
      product,
      productCode: p?.portfolio_product_code ?? p?.product_code ?? p?.portfolio_product ?? p?.product ?? '',
      subProduct,
      subProductCode:
        p?.portfolio_sub_product_code ??
        p?.sub_product_code ??
        p?.portfolio_sub_product ??
        p?.sub_product ??
        p?.subProduct ??
        '',
      businessType: p?.portfolio_type ?? p?.business_type ?? p?.biz_type ?? '',
      businessTypeCode: p?.portfolio_type_code ?? p?.business_type_code ?? p?.biz_type ?? '',
      renewalDate: p?.renewal_date ?? '',
      owner: p?.portfolio_owner ?? p?.owner ?? p?.primary_owner ?? '',
      owners: Array.isArray(p?.owners) ? p.owners : [],
      activeOpps: p?.active_opps ?? p?.activeOpps ?? p?.active_opportunities ?? 0,
      totalOpps: p?.total_opps ?? p?.totalOpps ?? p?.total_opportunities ?? 0,
      active: p?.active,
      status: isActiveValue(p?.active) ? 'Active' : 'Inactive',
    };
  });
};

export const parsePortfolioListApiResponse = (response, page = 1) => {
  const list = normalizeClientPortfolios(response);
  const payload = response?.payload ?? {};
  const totalCount =
    Number(payload.total_records ?? payload.total_portfolios ?? response?.total_records ?? list.length) || 0;

  return {
    list,
    totalCount,
    page,
    isAdd: getListIsAddFlag(response),
    isReassign: getListIsReassignFlag(response),
  };
};
