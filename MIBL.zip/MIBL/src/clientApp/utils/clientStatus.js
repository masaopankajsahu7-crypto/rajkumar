export const normalizeClientStatus = (status) => String(status ?? '').trim().toLowerCase();

export const isClientApproved = (status) => normalizeClientStatus(status) === 'approved';

export const getClientStatusClass = (status) => {
  const normalized = normalizeClientStatus(status);
  if (normalized === 'approved') return 'client-mgmt-status--approved';
  if (normalized === 'rejected') return 'client-mgmt-status--rejected';
  if (normalized === 'pending') return 'client-mgmt-status--pending';
  return 'client-mgmt-status--default';
};
