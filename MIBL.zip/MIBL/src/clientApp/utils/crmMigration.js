export const CRM_MIGRATION_LIST_PAGE_SIZE = 10;

export const CRM_MIGRATION_COLUMN_KEYS = [
  'client',
  'product',
  'sub_product',
  'corporate_vertical',
  'created_by',
  'renewal_date',
  'opportunity_status',
];

export const CRM_MIGRATION_COLUMN_LABELS = {
  client: 'Client',
  product: 'Product',
  sub_product: 'Sub Product',
  corporate_vertical: 'Vertical',
  created_by: 'Created By',
  renewal_date: 'Renewal Date',
  opportunity_status: 'Status',
};

export const parseCrmMigrationListResponse = (response = {}, page = 1) => {
  const payload = response?.payload ?? response?.data?.payload ?? response?.data ?? response;
  const records = Array.isArray(payload?.records)
    ? payload.records
    : Array.isArray(payload)
      ? payload
      : [];

  return {
    list: records,
    totalCount: Number(payload?.total_records ?? payload?.totalRecords ?? records.length) || 0,
    page,
  };
};

export const getCrmMigrationTotalPages = (totalCount) =>
  Math.max(Math.ceil((Number(totalCount) || 0) / CRM_MIGRATION_LIST_PAGE_SIZE), 1);
