const DATE_RANGE_PRESETS = {
  TODAY_30: 'TODAY_30',
  CURRENT_MONTH: 'CURRENT_MONTH',
  PREVIOUS_MONTH: 'PREVIOUS_MONTH',
  LAST_3_MONTHS: 'LAST_3_MONTHS',
  NEXT_MONTH: 'NEXT_MONTH',
  NEXT_3_MONTHS: 'NEXT_3_MONTHS',
  CUSTOM: 'CUSTOM',
};

export const DATE_FILTER_TYPES = [
  { code: 'renewal_date', value: 'Renewal Date' },
  { code: 'created_on', value: 'Created Date' },
];

export const SORT_ORDER_OPTIONS = [
  { code: 'ASC', value: 'Ascending' },
  { code: 'DESC', value: 'Descending' },
];

export const DATE_RANGE_OPTIONS = [
  { code: DATE_RANGE_PRESETS.TODAY_30, value: 'Today +/- 30' },
  { code: DATE_RANGE_PRESETS.CURRENT_MONTH, value: 'Current Month' },
  { code: DATE_RANGE_PRESETS.PREVIOUS_MONTH, value: 'Previous Month' },
  { code: DATE_RANGE_PRESETS.LAST_3_MONTHS, value: 'Last 3 Months' },
  { code: DATE_RANGE_PRESETS.NEXT_MONTH, value: 'Next Month' },
  { code: DATE_RANGE_PRESETS.NEXT_3_MONTHS, value: 'Next 3 Months' },
  { code: DATE_RANGE_PRESETS.CUSTOM, value: 'Custom' },
];

export const DEFAULT_DATE_RANGE_PRESET = DATE_RANGE_PRESETS.TODAY_30;
export const DEFAULT_SORT_ORDER = 'DESC';

export const countActiveDateFilters = (filters = {}, { includeDateType = true } = {}) => {
  let count = 0;
  const preset = String(filters.dateRangePreset ?? '').trim();
  const dateType = String(filters.dateFilterType ?? '').trim();

  if (preset && preset !== DEFAULT_DATE_RANGE_PRESET) count += 1;
  if (includeDateType && dateType && dateType !== 'created_on') count += 1;

  return count;
};

export const sortRowsByDate = (rows = [], getDateValue, sortOrder = DEFAULT_SORT_ORDER) => {
  const direction = String(sortOrder).toUpperCase() === 'ASC' ? 1 : -1;
  const toTime = (value) => {
    const rawValue = String(value ?? '').trim();
    if (!rawValue) return Number.NaN;

    const normalizedValue = rawValue.replace(',', '').replace(/\s+/g, ' ');
    const isoCandidate = normalizedValue.replace(' ', 'T');
    const isoTime = Date.parse(isoCandidate);
    if (!Number.isNaN(isoTime)) return isoTime;

    const numericMatch = normalizedValue.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/);
    if (numericMatch) {
      const [, day, month, year] = numericMatch;
      return new Date(Number(year), Number(month) - 1, Number(day)).getTime();
    }

    const namedMonthMatch = normalizedValue.match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/);
    if (namedMonthMatch) {
      const [, day, monthName, year] = namedMonthMatch;
      const monthIndex = [
        'jan',
        'feb',
        'mar',
        'apr',
        'may',
        'jun',
        'jul',
        'aug',
        'sep',
        'sept',
        'oct',
        'nov',
        'dec',
      ].indexOf(monthName.toLowerCase());
      const normalizedMonthIndex = monthIndex === 9 ? 8 : monthIndex;
      if (normalizedMonthIndex >= 0) {
        return new Date(Number(year), normalizedMonthIndex, Number(day)).getTime();
      }
    }

    return Number.NaN;
  };

  return rows
    .map((row, index) => ({ row, index }))
    .sort((first, second) => {
      const firstTime = toTime(getDateValue(first.row));
      const secondTime = toTime(getDateValue(second.row));

      if (Number.isNaN(firstTime) && Number.isNaN(secondTime)) return first.index - second.index;
      if (Number.isNaN(firstTime)) return 1;
      if (Number.isNaN(secondTime)) return -1;
      if (firstTime === secondTime) return first.index - second.index;
      return (firstTime - secondTime) * direction;
    })
    .map(({ row }) => row);
};

const toDateInputValue = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const addDays = (date, days) => {
  const nextDate = new Date(date);
  nextDate.setDate(nextDate.getDate() + days);
  return nextDate;
};

const addMonths = (date, months) => {
  const nextDate = new Date(date);
  nextDate.setMonth(nextDate.getMonth() + months);
  return nextDate;
};

const startOfMonth = (date) => new Date(date.getFullYear(), date.getMonth(), 1);
const endOfMonth = (date) => new Date(date.getFullYear(), date.getMonth() + 1, 0);
const calendarMonth = (date, monthOffset) =>
  new Date(date.getFullYear(), date.getMonth() + monthOffset, 1);

export const getDateRangeForPreset = (preset) => {
  const today = new Date();

  switch (preset) {
    case DATE_RANGE_PRESETS.CURRENT_MONTH:
      return {
        fromDate: toDateInputValue(startOfMonth(today)),
        toDate: toDateInputValue(endOfMonth(today)),
      };
    case DATE_RANGE_PRESETS.PREVIOUS_MONTH: {
      const previousMonth = calendarMonth(today, -1);
      return {
        fromDate: toDateInputValue(startOfMonth(previousMonth)),
        toDate: toDateInputValue(endOfMonth(previousMonth)),
      };
    }
    case DATE_RANGE_PRESETS.LAST_3_MONTHS:
      return {
        fromDate: toDateInputValue(calendarMonth(today, -3)),
        toDate: toDateInputValue(endOfMonth(calendarMonth(today, -1))),
      };
    case DATE_RANGE_PRESETS.NEXT_MONTH: {
      const nextMonth = calendarMonth(today, 1);
      return {
        fromDate: toDateInputValue(startOfMonth(nextMonth)),
        toDate: toDateInputValue(endOfMonth(nextMonth)),
      };
    }
    case DATE_RANGE_PRESETS.NEXT_3_MONTHS:
      return {
        fromDate: toDateInputValue(calendarMonth(today, 1)),
        toDate: toDateInputValue(endOfMonth(calendarMonth(today, 3))),
      };
    case DATE_RANGE_PRESETS.CUSTOM:
      return null;
    case DATE_RANGE_PRESETS.TODAY_30:
    default:
      return {
        fromDate: toDateInputValue(addDays(today, -30)),
        toDate: toDateInputValue(addDays(today, 30)),
      };
  }
};

export const getDateRangeLabel = (preset) =>
  DATE_RANGE_OPTIONS.find((option) => option.code === preset)?.value ?? '';

export const getDateFilterTypeLabel = (type) =>
  DATE_FILTER_TYPES.find((option) => option.code === type)?.value ?? '';

export const getSortOrderLabel = (sortOrder) =>
  SORT_ORDER_OPTIONS.find((option) => option.code === sortOrder)?.value ?? '';
