/**
 * Format an epoch-millisecond timestamp as a localized clock time (HH:MM:SS).
 * Returns an empty string for falsy/invalid input so callers can guard rendering.
 */
export const formatClockTime = (timestamp) => {
  if (!timestamp) return '';

  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return '';

  return date.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
};
