import { decryptRoute } from '../../services/encrypt';

export const getDecryptedPathFromParam = (encrypted) => {
  if (!encrypted) return '';
  try {
    return decryptRoute(decodeURIComponent(encrypted));
  } catch {
    return '';
  }
};

export const getEncryptedRouteParam = (encrypted, pattern) => {
  const decryptedPath = getDecryptedPathFromParam(encrypted);
  const match = decryptedPath.match(pattern);
  return match?.[1] ? decodeURIComponent(match[1]) : '';
};
