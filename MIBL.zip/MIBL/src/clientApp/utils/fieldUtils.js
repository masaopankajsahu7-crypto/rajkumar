import { PATTERNS, PATTERN_STRIP } from '../config/patterns.js';
import { FIELD_RULES } from '../config/fieldRules.js';
import { stripBlockedSpecialCharacters } from './securityValidation.js';

const applyMaxLength = (value, maxLength) =>
  maxLength != null ? String(value).slice(0, maxLength) : value;

const sanitizeDecimal = (value, precision = 2) => {
  const cleaned = String(value).replace(PATTERN_STRIP.DECIMAL_CHARS, '');
  const [whole = '', ...decimalParts] = cleaned.split('.');
  const hasDecimal = cleaned.includes('.');
  const decimal = decimalParts.join('').slice(0, precision);

  if (!hasDecimal) return whole;
  return `${whole || '0'}.${decimal}`;
};

const applyNumericCeiling = (value, maxExclusive, precision = 2) => {
  if (maxExclusive == null || value === '' || value === '.') return value;

  const numericValue = Number(value);
  if (!Number.isFinite(numericValue) || numericValue < maxExclusive) return value;

  return (maxExclusive - 1 / 10 ** precision).toFixed(precision);
};

export const sanitizeByField = (fieldKey, value) => {
  const rule = FIELD_RULES[fieldKey];
  if (!rule || value == null) return value;

  let next = String(value);
  next = stripBlockedSpecialCharacters(next);

  switch (rule.sanitize) {
    case 'mobile':
    case 'pincode':
    case 'digits':
      next = next.replace(PATTERN_STRIP.NON_DIGIT, '');
      break;
    case 'pan':
    case 'gstin':
    case 'cin':
      next = next.replace(PATTERN_STRIP.NON_ALPHANUMERIC, '').toUpperCase();
      break;
    case 'name':
      next = next
        .replace(PATTERN_STRIP.NAME_CHARS, '')
        .replace(PATTERN_STRIP.MULTIPLE_SPACES, ' ')
        .trimStart();
      break;
    case 'email':
      next = next.replace(PATTERN_STRIP.EMAIL_SPACES, '').toLowerCase();
      break;
    case 'address':
      next = next.replace(PATTERN_STRIP.ADDRESS_CHARS, '');
      break;
    case 'cityState':
      next = next.replace(PATTERN_STRIP.CITY_STATE_CHARS, '');
      break;
    case 'brokerage':
    case 'decimal2':
      next = sanitizeDecimal(next, 2);
      if (rule.sanitize === 'brokerage') {
        next = applyNumericCeiling(next, rule.maxExclusive, 2);
      }
      break;
    case 'policyNumber':
      next = next.replace(PATTERN_STRIP.POLICY_NUMBER_CHARS, '').toUpperCase();
      break;
    case 'search':
      next = next
        .trimStart()
        .replace(PATTERNS.SEARCH, '')
        .replace(PATTERN_STRIP.MULTIPLE_SPACES, ' ');
      break;
    default:
      break;
  }

  return applyMaxLength(next, rule.maxLength);
};

export const isValidByField = (fieldKey, value) => {
  const rule = FIELD_RULES[fieldKey];
  const trimmed = typeof value === 'string' ? value.trim() : value;
  if (!trimmed) return true;
  if (rule?.pattern && !rule.pattern.test(trimmed)) return false;

  const numericValue = Number(trimmed);
  if (Number.isFinite(numericValue)) {
    if (rule?.minExclusive != null && numericValue <= rule.minExclusive) return false;
    if (rule?.maxExclusive != null && numericValue >= rule.maxExclusive) return false;
  }

  return true;
};

export const getFieldMaxLength = (fieldKey) => FIELD_RULES[fieldKey]?.maxLength;

export const getFieldMinLength = (fieldKey) => FIELD_RULES[fieldKey]?.minLength;

/** Legacy inputType map used by client form renderers */
export const sanitizeFieldValue = (inputType, value) => {
  const typeMap = {
    mobile: 'mobile',
    pincode: 'pincode',
    pan: 'pan',
    gstin: 'gstin',
    cin: 'cin',
    name: 'name',
    email: 'email',
    address: 'address',
    cityState: 'cityState',
    brokerage: 'brokerage',
    digits: 'digits',
    policyNumber: 'policyNumber',
    search: 'search',
  };

  const fieldKey = typeMap[inputType];
  return fieldKey ? sanitizeByField(fieldKey, value) : value;
};
