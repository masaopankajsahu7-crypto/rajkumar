/**
 * Normalizers for the master-service `kds` dropdown endpoint.
 *
 * API response shape:
 *   { status, message, payload: { master: [{ code, value, parent_code, parent_value }], key_name, total_records } }
 *
 * The UI contract is uniform for every dropdown:
 *   - `code`  (key_code)  -> the value we STORE / SUBMIT to the backend
 *   - `value` (key_value) -> the label we SHOW in the dropdown
 *   - `parentCode`        -> only relevant for dependent (hierarchical) dropdowns
 *   - `parentValue`       -> fallback link when a master row carries parent label instead of code
 */

/** Build the request body for a single dropdown fetch. */
export const buildKdsRequest = ({
  userid,
  module,
  source,
  name,
  search = '',
  offset = 0,
  limit = 100,
  parentCode = '',
}) => ({
  userid,
  offset,
  limit,
  search,
  payload: {
    key_module: module,
    key_source: source,
    key_name: name,
    ...(parentCode ? { parent_code: parentCode } : {}),
  },
});

/** Map the API response into [{ code, value, parentCode }], dropping any row without a code. */
export const normalizeKdsOptions = (response) => {
  const master = response?.payload?.master ?? [];
  return master
    .map((item) => ({
      code: item?.code ?? item?.key_code ?? item?.keyCode ?? '',
      value: item?.value ?? item?.key_value ?? item?.keyValue ?? '',
      parentCode: item?.parent_code ?? '',
      parentValue: item?.parent_value ?? '',
      sortOrder: item?.sort_order ?? item?.sortOrder ?? item?.display_order ?? item?.displayOrder ?? '',
    }))
    .filter((option) => option.code !== '');
};
