/** Words that should render fully uppercased rather than title-cased. */
const ACRONYMS = new Set(['id', 'uuid', 'pan', 'cin', 'gstin', 'gst', 'tin', 'lob', 'sap']);

/**
 * Convert a raw object key into a human-readable label.
 * Handles snake_case, kebab-case and camelCase.
 *   client_name       -> "Client Name"
 *   client_type_code  -> "Client Type Code"
 *   clientId          -> "Client ID"
 */
export const humanizeKey = (key) =>
  String(key ?? '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .split(/[_\-\s]+/)
    .filter(Boolean)
    .map((word) =>
      ACRONYMS.has(word.toLowerCase())
        ? word.toUpperCase()
        : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase(),
    )
    .join(' ');

/**
 * Resolve a column header label for a raw key. Allows per-key overrides for the
 * cases where the auto-generated label isn't ideal; falls back to humanizeKey.
 */
export const formatColumnLabel = (key, overrides = {}) => overrides[key] ?? humanizeKey(key);
