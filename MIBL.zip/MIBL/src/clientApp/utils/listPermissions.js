export const isListActionAllowed = (value) => {
  const normalized = String(value ?? '').trim().toLowerCase();
  return normalized === '1' || normalized === 'true';
};

const LIST_REPORT_DESIGNATIONS = new Set(['uddbh', 'uddvh', 'mis', 'admin']);

export const isListReportActionAllowed = (userDetails) =>
  LIST_REPORT_DESIGNATIONS.has(String(userDetails?.designation_code ?? '').trim().toLowerCase());

export const getListIsAddFlag = (response) =>
  response?.payload?.is_add ??
  response?.payload?.isAdd ??
  response?.is_add ??
  response?.isAdd ??
  '0';

export const getListIsReassignFlag = (response) =>
  response?.payload?.is_reassign ??
  response?.payload?.isReassign ??
  response?.is_reassign ??
  response?.isReassign ??
  '1';
