import { APP_CONFIG } from '../config/appConfig.js';

import { getListIsAddFlag } from './listPermissions.js';

export const OPPORTUNITY_LIST_PAGE_SIZE = APP_CONFIG.LIST_PAGE_SIZE;

export const normalizeOpportunityStatus = (value) => {
  const rawValue = String(value ?? '').trim();
  const normalizedValue = rawValue.toLowerCase();

  if (normalizedValue === 'quoted') return 'In Progress';
  if (normalizedValue === 'won') return 'Completed';

  return rawValue;
};

const OPPORTUNITY_STAGE_LABELS = {
  OPPORTUNITY: 'Opportunity',
  RFQ_STAGE: 'RFQ Stage',
  QCR_STAGE: 'QCR Stage',
  CLIENT_REVIEW: 'Client Review',
  POLICY_INSURANCE: 'Policy Insurance',
  POLICY_WON: 'Policy Won',
  COMPLETED: 'Completed',
};

export const formatOpportunityStage = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '';

  const normalizedCode = rawValue.toUpperCase().replace(/[\s-]+/g, '_');
  if (OPPORTUNITY_STAGE_LABELS[normalizedCode]) return OPPORTUNITY_STAGE_LABELS[normalizedCode];

  return rawValue
    .replace(/_/g, ' ')
    .toLowerCase()
    .replace(/\b\w/g, (character) => character.toUpperCase());
};


const getPrimaryOwnerName = (owners = []) => {
  if (!Array.isArray(owners)) return '';
  const primaryOwner = owners.find((owner) => owner?.owner_type_code === 'PRIMARY') ?? owners[0];
  return primaryOwner?.owner_name ?? primaryOwner?.name ?? '';
};

const getPlacementRmName = (placementRm) => {
  if (!placementRm) return '';
  if (typeof placementRm === 'string') return placementRm;
  return placementRm.owner_name ?? placementRm.name ?? placementRm.user_name ?? '';
};

const firstValue = (...values) => values.find((value) => String(value ?? '').trim()) ?? '';

export const mapOpportunityToListRow = (opportunity = {}) => ({
  opportunity_uuid:
    opportunity.opportunity_uuid ??
    opportunity.opportunity_UUID ??
    opportunity.opportunityId ??
    opportunity.id ??
    '',
  opportunity_code: firstValue(opportunity.opportunity_code, opportunity.opp_code),
  product: firstValue(
    opportunity.opportunity_product,
    opportunity.product_value,
    opportunity.product,
    opportunity.product_name,
    opportunity.opportunity_product_code,
  ),
  sub_product: firstValue(
    opportunity.opportunity_sub_product,
    opportunity.sub_product_value,
    opportunity.sub_product,
    opportunity.subProduct,
    opportunity.sub_product_name,
    opportunity.opportunity_sub_product_code,
  ),
  brokerage: opportunity.brokerage_percent ?? opportunity.brokerage ?? '',
  brokerage_fee: opportunity.brokerage_fee ?? opportunity.brokerageFee ?? opportunity.brokerage_amount ?? '',
  premium: opportunity.expected_premium ?? opportunity.expectedPremium ?? '',
  renewal_date: opportunity.renewal_date ?? opportunity.renewalDate ?? '',
  created_on: opportunity.created_on ?? opportunity.createdDate ?? opportunity.created_at ?? '',
  biz_type: firstValue(
    opportunity.opportunity_type,
    opportunity.biz_type_value,
    opportunity.biz_type,
    opportunity.business_type,
    opportunity.opportunity_type_code,
  ),
  owner: firstValue(
    getPlacementRmName(opportunity.portfolio_owner),
    opportunity.owner,
    opportunity.opportunity_owner,
    opportunity.primary_owner,
    getPrimaryOwnerName(opportunity.owners),
    opportunity.portfolio_owner,
  ),
  placement_head: firstValue(
    getPlacementRmName(opportunity.placement_rm),
    opportunity.placement_head,
    opportunity.placementHead,
    opportunity.placement_rm_name,
  ),
  opportunity_status: normalizeOpportunityStatus(
    firstValue(opportunity.opportunity_status, opportunity.status, opportunity.opportunity_status_code),
  ),
  opportunity_stage: firstValue(
    opportunity.opportunity_stage,
    opportunity.stage,
    opportunity.opportunity_sub_status,
    opportunity.opportunity_stage_code,
  ),
  client_name: firstValue(opportunity.client_name, opportunity.clientName, opportunity.client?.client_name),
  client_vertical: firstValue(
    opportunity.client_vertical,
    opportunity.clientVertical,
    opportunity.client?.client_vertical,
    opportunity.client_vertical_code,
  ),
});

export const normalizeOpportunityList = (response) => {
  if (!response) return [];
  if (Array.isArray(response)) return response;

  const candidates = [
    response.payload?.opportunities,
    response.payload?.opportunity_list,
    response.payload?.opportunityList,
    response.payload?.opportunity,
    response.payload?.list,
    response.payload?.data,
    response.data?.opportunities,
    response.data?.list,
    response.opportunities,
    response.list,
    response.rows,
    response.records,
  ];

  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return candidate;
  }

  return [];
};

export const getPaginatedOpportunityRows = (rows, page = 1) => {
  const start = (page - 1) * OPPORTUNITY_LIST_PAGE_SIZE;
  return {
    list: rows.slice(start, start + OPPORTUNITY_LIST_PAGE_SIZE),
    totalCount: rows.length,
  };
};

export const parseOpportunityListApiResponse = (response, page = 1) => {
  const list = normalizeOpportunityList(response).map(mapOpportunityToListRow);
  const totalCount =
    response?.payload?.total_records ??
    response?.payload?.totalRecords ??
    response?.payload?.total_opportunities ??
    response?.total_records ??
    list.length;

  return {
    list,
    totalCount: Number(totalCount) || 0,
    page: response?.page ?? response?.currentPage ?? page,
    isAdd: getListIsAddFlag(response),
  };
};

export const getOpportunityTotalPages = (totalCount, pageSize = OPPORTUNITY_LIST_PAGE_SIZE) => {
  if (!totalCount) return 0;
  return Math.ceil(totalCount / pageSize);
};

export const getOpportunityFilterOptions = (rows = []) => {
  const unique = (field) =>
    [...new Set(rows.map((row) => String(row?.[field] ?? '').trim()).filter(Boolean))].sort();

  return {
    product: unique('product'),
    subProduct: unique('sub_product'),
    businessType: unique('biz_type'),
    owner: unique('owner'),
    placementRm: unique('placement_head'),
    opportunityStatus: unique('opportunity_status'),
    opportunityStage: unique('opportunity_stage'),
    clientVertical: unique('client_vertical'),
  };
};
