import {
  DEFAULT_DATE_RANGE_PRESET,
  DEFAULT_SORT_ORDER,
  getDateRangeLabel,
} from './dateRangeFilters.js';

export const INITIAL_OPPORTUNITY_FILTERS = {
  search: '',
  product: '',
  productLabel: '',
  subProduct: '',
  subProductLabel: '',
  renewalFrom: '',
  renewalTo: '',
  dateRangePreset: DEFAULT_DATE_RANGE_PRESET,
  dateFilterType: 'created_on',
  sortColumn: 'created_on',
  sortOrder: DEFAULT_SORT_ORDER,
  businessType: '',
  businessTypeLabel: '',
  owner: '',
  ownerId: '',
  placementRm: '',
  placementRmId: '',
  opportunityStatus: '',
  opportunityStatusLabel: '',
  opportunityStage: '',
  opportunityStageLabel: '',
  clientName: '',
  clientUUID: '',
  portfolioUUID: '',
  portfolioLabel: '',
  clientVertical: '',
  clientVerticalLabel: '',
  breached: '',
};

export const normalizeOpportunityListFilters = (filters = INITIAL_OPPORTUNITY_FILTERS) => ({
  search: String(filters.search ?? '').trim(),
  product: String(filters.product ?? '').trim(),
  productLabel: String(filters.productLabel ?? '').trim(),
  subProduct: String(filters.subProduct ?? '').trim(),
  subProductLabel: String(filters.subProductLabel ?? '').trim(),
  renewalFrom: String(filters.renewalFrom ?? '').trim(),
  renewalTo: String(filters.renewalTo ?? '').trim(),
  dateRangePreset: String(filters.dateRangePreset ?? '').trim(),
  dateFilterType: String(filters.dateFilterType ?? '').trim(),
  sortColumn: String(filters.sortColumn ?? 'created_on').trim(),
  sortOrder: String(filters.sortOrder ?? '').trim(),
  businessType: String(filters.businessType ?? '').trim(),
  businessTypeLabel: String(filters.businessTypeLabel ?? '').trim(),
  owner: String(filters.owner ?? '').trim(),
  ownerId: String(filters.ownerId ?? '').trim(),
  placementRm: String(filters.placementRm ?? '').trim(),
  placementRmId: String(filters.placementRmId ?? '').trim(),
  opportunityStatus: String(filters.opportunityStatus ?? '').trim(),
  opportunityStatusLabel: String(filters.opportunityStatusLabel ?? '').trim(),
  opportunityStage: String(filters.opportunityStage ?? '').trim(),
  opportunityStageLabel: String(filters.opportunityStageLabel ?? '').trim(),
  clientName: String(filters.clientName ?? '').trim(),
  clientUUID: String(filters.clientUUID ?? '').trim(),
  portfolioUUID: String(filters.portfolioUUID ?? '').trim(),
  portfolioLabel: String(filters.portfolioLabel ?? '').trim(),
  clientVertical: String(filters.clientVertical ?? '').trim(),
  clientVerticalLabel: String(filters.clientVerticalLabel ?? '').trim(),
  breached: String(filters.breached ?? '').trim() === '1' ? '1' : '',
});

const GENERIC_SEARCH_FIELDS = [
  'product',
  'sub_product',
  'biz_type',
  'owner',
  'placement_head',
  'opportunity_status',
  'opportunity_stage',
  'client_name',
  'client_vertical',
];

const toComparableDate = (value) => {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const matchesDateRange = (rowDateValue, fromDate, toDate) => {
  const rowDate = toComparableDate(rowDateValue);
  if (!rowDate) return false;

  const from = toComparableDate(fromDate);
  const to = toComparableDate(toDate);

  if (from && rowDate < from) return false;
  if (to) {
    const endOfDay = new Date(to);
    endOfDay.setHours(23, 59, 59, 999);
    if (rowDate > endOfDay) return false;
  }

  return true;
};

const matchesText = (rowValue, filterValue) => {
  const query = String(filterValue ?? '').trim().toLowerCase();
  if (!query) return true;
  return String(rowValue ?? '').toLowerCase().includes(query);
};

const matchesExact = (rowValue, filterValue) => {
  const query = String(filterValue ?? '').trim();
  if (!query) return true;
  return String(rowValue ?? '') === query;
};

export const matchesOpportunitySearch = (row, search) => {
  const query = String(search ?? '').trim().toLowerCase();
  if (!query) return true;

  return GENERIC_SEARCH_FIELDS.some((field) =>
    String(row?.[field] ?? '').toLowerCase().includes(query),
  );
};

export const filterOpportunityRows = (rows, filters = INITIAL_OPPORTUNITY_FILTERS) => {
  const normalized = normalizeOpportunityListFilters(filters);
  const hasRenewalDateFilter = Boolean(normalized.renewalFrom || normalized.renewalTo);
  const productFilter = normalized.productLabel || normalized.product;
  const subProductFilter = normalized.subProductLabel || normalized.subProduct;
  const businessTypeFilter = normalized.businessTypeLabel || normalized.businessType;
  const clientVerticalFilter = normalized.clientVerticalLabel || normalized.clientVertical;

  return (rows ?? []).filter((row) => {
    if (!matchesOpportunitySearch(row, normalized.search)) return false;
    if (!matchesExact(row.product, productFilter)) return false;
    if (!matchesExact(row.sub_product, subProductFilter)) return false;
    if (!matchesExact(row.biz_type, businessTypeFilter)) return false;
    if (!matchesText(row.owner, normalized.owner)) return false;
    if (!matchesText(row.placement_head, normalized.placementRm)) return false;
    if (!matchesExact(row.opportunity_status, normalized.opportunityStatus)) return false;
    if (!matchesExact(row.opportunity_stage, normalized.opportunityStage)) return false;
    if (!matchesText(row.client_name, normalized.clientName)) return false;
    if (!matchesExact(row.client_vertical, clientVerticalFilter)) return false;

    if (
      hasRenewalDateFilter &&
      !matchesDateRange(row.renewal_date, normalized.renewalFrom, normalized.renewalTo)
    ) {
      return false;
    }

    return true;
  });
};

export const hasActiveOpportunityFilters = (filters = INITIAL_OPPORTUNITY_FILTERS) =>
  Object.entries(filters).some(([key, value]) => {
    if (key === 'ownerId' || key === 'placementRmId' || key === 'clientUUID' || key === 'portfolioUUID' || key.endsWith('Label')) return false;
    if ((key === 'renewalFrom' || key === 'renewalTo') && filters.dateRangePreset !== 'CUSTOM') return false;
    if (key === 'dateRangePreset' && value === DEFAULT_DATE_RANGE_PRESET) return false;
    if (key === 'dateFilterType' && value === 'created_on') return false;
    if (key === 'sortColumn' && value === 'created_on') return false;
    if (key === 'sortOrder' && value === DEFAULT_SORT_ORDER) return false;
    if (key === 'breached' && value !== '1') return false;
    return String(value ?? '').trim() !== '';
  });

export const countActiveOpportunityFilters = (filters = INITIAL_OPPORTUNITY_FILTERS) =>
  Object.entries(filters).filter(([key, value]) => {
    if (key === 'search' || key === 'ownerId' || key === 'placementRmId' || key === 'clientUUID' || key === 'portfolioUUID' || key.endsWith('Label')) return false;
    if (['renewalFrom', 'renewalTo', 'dateRangePreset', 'dateFilterType', 'sortColumn', 'sortOrder'].includes(key)) return false;
    if (key === 'breached' && value !== '1') return false;
    return String(value ?? '').trim() !== '';
  }).length;

const formatChipDate = (value) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

export const getActiveOpportunityFilterChips = (filters = INITIAL_OPPORTUNITY_FILTERS, labels = {}) => {
  const chips = [];

  const chipConfig = [
    ['search', labels.search ?? 'Search'],
    ['product', labels.product ?? 'Product', filters.productLabel],
    ['subProduct', labels.subProduct ?? 'Sub- Product', filters.subProductLabel],
    ['businessType', labels.businessType ?? 'Business Type', filters.businessTypeLabel],
    ['owner', labels.owner ?? 'Owner'],
    ['placementRm', labels.placementRm ?? 'Placement RM'],
    ['opportunityStatus', labels.opportunityStatus ?? 'Opportunity Status', filters.opportunityStatusLabel],
    ['opportunityStage', labels.opportunityStage ?? 'Opportunity Stage', filters.opportunityStageLabel],
    ['clientName', labels.clientName ?? 'Client Name'],
    ['portfolioUUID', labels.portfolio ?? 'Portfolio', filters.portfolioLabel],
    ['clientVertical', labels.clientVertical ?? 'Client Vertical', filters.clientVerticalLabel],
  ];

  chipConfig.forEach(([key, label, displayValue]) => {
    if (String(filters[key] ?? '').trim()) {
      const chipValue = key === 'portfolioUUID'
        ? String(displayValue || labels.selectedPortfolio || 'Selected portfolio').trim()
        : String(displayValue || filters[key]).trim();
      chips.push({ key, label: `${label}: ${chipValue}` });
    }
  });

  const shouldShowCustomDates = filters.dateRangePreset === 'CUSTOM';

  if (shouldShowCustomDates && String(filters.renewalFrom ?? '').trim()) {
    chips.push({ key: 'renewalFrom', label: `${labels.renewalFrom ?? 'Renewal From'}: ${formatChipDate(filters.renewalFrom)}` });
  }

  if (shouldShowCustomDates && String(filters.renewalTo ?? '').trim()) {
    chips.push({ key: 'renewalTo', label: `${labels.renewalTo ?? 'Renewal To'}: ${formatChipDate(filters.renewalTo)}` });
  }
  if (
    String(filters.dateRangePreset ?? '').trim() &&
    filters.dateRangePreset !== DEFAULT_DATE_RANGE_PRESET
  ) {
    chips.push({
      key: 'dateRangePreset',
      label: `${labels.dateRangePreset ?? 'Date Range'}: ${getDateRangeLabel(filters.dateRangePreset)}`,
    });
  }
  if (String(filters.breached ?? '') === '1') {
    chips.push({ key: 'breached', label: 'Breached' });
  }
  return chips;
};
