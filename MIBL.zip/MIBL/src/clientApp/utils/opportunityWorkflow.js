import {
  OPPORTUNITY_STAGE_ALIASES,
  OPPORTUNITY_WORKFLOW_STAGES,
} from '../config/opportunityWorkflowStages.js';

export const FALLBACK_OPPORTUNITY_HIERARCHY_RESPONSE = {
  status: 200,
  message: 'Opportunity hierarchy found.',
  payload: {
    client: {
      active: 1,
      client_name: 'Geet Technology',
      client_type: 'Dealer',
      client_uuid: '374501073c0364Q88e7Q11f1Qa87aQb2f5b6ad4241',
      client_vertical: 'Strategic Alliance',
      client_type_code: 'cttd',
      client_vertical_code: 'cvva',
    },
    is_edit: '1',
    is_view: '1',
    is_delay: '1',
    portfolios: [
      {
        active: 1,
        owners: [{ owner_id: 72, owner_name: 'Pan RM', owner_type_code: 'PRIMARY' }],
        contacts: [],
        renewal_date: '2027-01-12',
        brokerage_fee: 7608.09,
        reward_fee: 0,
        portfolio_type: 'New',
        portfolio_uuid: '579003548393f1Q88e7Q11f1Qa87aQb2f5b6ad4241',
        expected_premium: 89824,
        portfolio_product: 'Liability',
        portfolio_sub_product: 'Bankers Indemnity',
        portfolio_data: {
          contact: [
            { name: 'Amit Yadav', mobile: '9857465412', email: 'amit.y@mahindra.com' },
            { name: 'Priya Nair', mobile: '9876543210', email: 'priya.n@mahindra.com' },
          ],
        },
        opportunities: [
          {
            active: 1,
            owners: [{ owner_id: 72, owner_name: 'Pan RM', owner_type_code: 'PRIMARY' }],
            breached: 0,
            created_on: '2026-07-26 17:14:16',
            reward_fee: 0,
            modified_on: '2026-07-26 17:34:23',
            placement_rm: null,
            renewal_date: '2027-01-12',
            brokerage_fee: 7608.09,
            expected_premium: 89824,
            opportunity_data: {
              biz_type: 'NEW',
              brokerage: 8.47,
              sub_product: 'CORP000036',
              sum_insured: 43886420,
              product_code: 'CORP000031',
              renewal_date: '2027-01-12',
              expected_premium: 89824,
            },
            opportunity_type: 'New',
            opp_code: 'OPP-99812',
            opportunity_uuid: '771517548485cbQ88e7Q11f1Qa87aQb2f5b6ad4241',
            opportunity_stage: 'Completed',
            opportunity_status: 'Completed',
            opportunity_product: 'Liability',
            opportunity_type_code: 'NEW',
            opportunity_stage_code: 'COMPLETED',
            opportunity_status_code: 'COMPLETED',
            opportunity_sub_product: 'Bankers Indemnity',
            opportunity_product_code: 'CORP000031',
            opportunity_sub_product_code: 'CORP000036',
          },
        ],
      },
    ],
    is_workflow: '1',
    reference_type: 'OPPORTUNITY',
    is_activity_log: '1',
    is_workflow_log: '1',
    total_portfolios: 1,
    total_opportunities: 1,
  },
};

export const FALLBACK_OPPORTUNITY_WORKFLOW_RESPONSE = {
  status: 200,
  message: 'Opportunity workflow records found.',
  payload: {
    opportunity: {
      active: 1,
      created_on: '2026-07-26 17:14:16',
      reward_fee: 0,
      renewal_date: '2027-01-12',
      brokerage_fee: 7608.09,
      opportunity_id: 2624,
      expected_premium: 89824,
      opportunity_uuid: '771517548485cbQ88e7Q11f1Qa87aQb2f5b6ad4241',
      opportunity_status: 'Completed',
      opportunity_stage_code: 'COMPLETED',
      opportunity_status_code: 'COMPLETED',
      opportunity_product_code: 'CORP000031',
      opportunity_sub_product_code: 'CORP000036',
    },
    placement_rm: null,
    workflow_state: {
      workflow_code: 'MIBL',
      allowed_actions: [],
      current_stage_code: 'COMPLETED',
      is_workflow_locked: 1,
      previous_stage_code: 'POLICY_WON',
      current_stage_sequence: 6,
    },
    workflow_stages: [
      {
        stage_code: 'OPPORTUNITY',
        processed_by: 72,
        stage_sequence: 1,
        stage_start_at: '2026-07-26 17:14:16',
        stage_end_at: '2026-07-26 17:14:58',
        sla_compliance: 'WITHIN_TAT',
        stage_display_name: 'Opportunity Assignment Pending',
        latest_workflow_stage_data: {
          updated_on: '2026-07-26 17:14:58',
          stage_payload: {
            comment: 'Placement RM informed and assignment accepted',
            informed_by: 'Pankaj Manager',
          },
        },
      },
      {
        stage_code: 'RFQ_STAGE',
        processed_by: 72,
        stage_sequence: 2,
        stage_start_at: '2026-07-26 17:14:58',
        stage_end_at: '2026-07-26 17:17:27',
        sla_compliance: 'WITHIN_TAT',
        stage_display_name: 'RFQ in Progress',
        latest_workflow_stage_data: {
          updated_on: '2026-07-26 17:17:27',
          stage_payload: {
            comment: 'RFQ floated to the selected insurers',
            rfq_status: 'FLOATED',
          },
        },
      },
      {
        stage_code: 'QCR_STAGE',
        processed_by: 72,
        stage_sequence: 3,
        stage_start_at: '2026-07-26 17:17:27',
        stage_end_at: '2026-07-26 17:18:51',
        sla_compliance: 'WITHIN_TAT',
        delay_reason: 'Insurer quotation received late',
        stage_display_name: 'QCR in Progress',
        latest_workflow_stage_data: {
          updated_on: '2026-07-26 17:18:51',
          stage_payload: {
            comment: 'QCR prepared and shared for client review',
            qcr_status: 'FLOATED',
          },
        },
      },
      {
        stage_code: 'CLIENT_REVIEW',
        processed_by: 72,
        stage_sequence: 4,
        stage_start_at: '2026-07-26 17:18:51',
        stage_end_at: '2026-07-26 17:34:12',
        sla_compliance: 'WITHIN_TAT',
        stage_display_name: 'Client Review',
        latest_workflow_stage_data: {
          updated_on: '2026-07-26 17:34:12',
          stage_payload: {
            comment: 'Approval received from the client',
            review_reason: 'Client accepted the recommended quotation',
            review_status: 'WON',
          },
        },
      },
      {
        stage_code: 'POLICY_WON',
        processed_by: 72,
        stage_sequence: 5,
        stage_start_at: '2026-07-26 17:34:12',
        stage_end_at: '2026-07-26 17:34:23',
        sla_compliance: 'WITHIN_TAT',
        stage_display_name: 'Opportunity Won',
        latest_workflow_stage_data: {
          updated_on: '2026-07-26 17:34:23',
          stage_payload: {
            comment: 'Policy issued and booking details completed',
            policy_status: 'ISSUED',
            policy_number: 'POL-2026-000123',
            policy_sum_insured: 50000000,
            policy_insurer: 'Reliance General Insurance',
            policy_start_date: '2026-08-01',
            policy_end_date: '2027-07-31',
            policy_premium: 850000,
            brokerage_percentage: 10,
            brokerage_amount: 85000,
            reward_percentage: 1,
            reward_amount: 8500,
          },
        },
      },
      {
        stage_code: 'COMPLETED',
        processed_by: 72,
        stage_sequence: 6,
        stage_start_at: '2026-07-26 17:34:23',
        stage_end_at: '2026-07-26 17:34:23',
        sla_compliance: 'WITHIN_TAT',
        stage_display_name: 'Opportunity Process Completed',
        latest_workflow_stage_data: {
          updated_on: '2026-07-26 17:34:23',
          stage_payload: {},
        },
      },
    ],
    total_workflow_stages: 6,
  },
};

export const FALLBACK_OPPORTUNITY_ACTIVITY_LOGS_RESPONSE = {
  status: 200,
  message: 'Opportunity activity logs found.',
  payload: {
    activities: [
      {
        user_name: 'Sandeep',
        stage_code: 'OPPORTUNITY',
        activity_description: 'User created the opportunity.',
        created_on: '2026-07-01 11:11:00',
      },
      {
        user_name: 'Pankaj',
        stage_code: 'OPPORTUNITY',
        activity_description: 'Viewed the opportunity.',
        created_on: '2026-07-02 11:11:00',
      },
      {
        user_name: 'Pankaj',
        stage_code: 'OPPORTUNITY',
        activity_description: 'Assigned Placement RM Mr. Sham to the opportunity.',
        created_on: '2026-07-03 11:11:00',
      },
      {
        user_name: 'Sham',
        stage_code: 'RFQ_STAGE',
        activity_description: 'Submitted the RFQ details.',
        created_on: '2026-07-05 11:11:00',
      },
      {
        user_name: 'System',
        stage_code: 'BREACHED',
        activity_description: 'System updated the breached status to True because the stage exceeded the TAT by 3 days.',
        created_on: '2026-07-10 11:11:00',
      },
      {
        user_name: 'System',
        stage_code: 'NOTIFICATION',
        activity_description: 'System created a notification for the users.',
        created_on: '2026-07-11 11:11:00',
      },
      {
        user_name: 'Sham',
        stage_code: 'CLIENT_REVIEW',
        activity_description: 'Submitted the QCR details.',
        created_on: '2026-07-12 11:11:00',
      },
    ],
    total_records: 7,
  },
};

const DISPLAY_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];

export const formatWorkflowDate = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '---';

  const datePart = rawValue.split(' ')[0];
  const isoDateMatch = datePart.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (isoDateMatch) {
    const [, year, month, day] = isoDateMatch;
    return `${Number(day)} ${DISPLAY_MONTHS[Number(month) - 1] ?? month} ${year}`;
  }

  const parsedDate = new Date(rawValue);
  if (Number.isNaN(parsedDate.getTime())) return rawValue;

  return `${parsedDate.getDate()} ${DISPLAY_MONTHS[parsedDate.getMonth()]} ${parsedDate.getFullYear()}`;
};

export const formatWorkflowDateTime = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '---';

  const [datePart, timePart = ''] = rawValue.split(' ');
  const displayDate = formatWorkflowDate(datePart);
  if (!timePart) return displayDate;

  return `${displayDate}, ${timePart.slice(0, 5)}`;
};

export const formatWorkflowActivityDateTime = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return '---';

  const [datePart, timePart = ''] = rawValue.split(' ');
  const displayDate = formatWorkflowDate(datePart);
  if (!timePart) return displayDate;

  return `${displayDate}, ${timePart.slice(0, 5)}`;
};

export const formatWorkflowCurrency = (value) => {
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return '---';

  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(numberValue);
};

export const formatWorkflowValue = (value) => {
  if (value === null || value === undefined || value === '') return '---';
  if (typeof value === 'number') return new Intl.NumberFormat('en-IN').format(value);
  return String(value);
};

export const formatWorkflowLabel = (value) =>
  String(value ?? '')
    .replace(/_/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());

export const normalizeOpportunityContacts = (contacts = []) => {
  if (!Array.isArray(contacts)) return [];

  return contacts
    .map((contact) => ({
      name: contact?.name ?? contact?.primary_contact_person ?? '',
      mobile: contact?.mobile ?? contact?.primary_contact_mobile ?? '',
      email: contact?.email ?? contact?.primary_contact_email ?? '',
    }))
    .filter((contact) => contact.name || contact.mobile || contact.email);
};

export const getOpportunityFromHierarchy = (hierarchyPayload = {}, opportunityUUID = '') => {
  const portfolios = Array.isArray(hierarchyPayload.portfolios) ? hierarchyPayload.portfolios : [];
  const requestedUUID = String(opportunityUUID ?? '').trim();

  for (const portfolio of portfolios) {
    const opportunities = Array.isArray(portfolio.opportunities) ? portfolio.opportunities : [];
    const matched = opportunities.find(
      (opportunity) => String(opportunity?.opportunity_uuid ?? '').trim() === requestedUUID,
    );
    if (matched) return { portfolio, opportunity: matched };
  }

  const firstPortfolio = portfolios[0] ?? {};
  return {
    portfolio: firstPortfolio,
    opportunity: Array.isArray(firstPortfolio.opportunities) ? firstPortfolio.opportunities[0] ?? {} : {},
  };
};

export const normalizeStageCode = (value) => {
  const rawValue = String(value ?? '').trim();
  return OPPORTUNITY_STAGE_ALIASES[rawValue] ?? rawValue.toUpperCase().replace(/\s+/g, '_');
};

export const normalizeWorkflowStageDefinitions = (stageOptions = [], { useFallback = true } = {}) => {
  if (!Array.isArray(stageOptions) || stageOptions.length === 0) {
    return useFallback ? OPPORTUNITY_WORKFLOW_STAGES : [];
  }

  const normalized = stageOptions
    .map((stage, index) => ({
      code: normalizeStageCode(stage.code),
      label: stage.value || stage.code,
      sortOrder: Number.isFinite(Number(stage.sortOrder)) ? Number(stage.sortOrder) : index + 1,
    }))
    .filter((stage) => stage.code && stage.label)
    .sort((first, second) => first.sortOrder - second.sortOrder);

  return normalized.length ? normalized : useFallback ? OPPORTUNITY_WORKFLOW_STAGES : [];
};

const getSlaComplianceLabel = (slaCompliance, hasApiStage) => {
  const tat = String(slaCompliance ?? '').trim().toUpperCase();
  if (!hasApiStage || !tat) return 'Pending';
  if (tat.includes('BREACH')) return 'Breached';
  if (tat === 'WITHIN_TAT') return 'Within TAT';
  if (tat === 'PENDING') return 'Pending';
  return formatWorkflowLabel(tat);
};

export const buildWorkflowStages = (workflowPayload = {}, stageOptions = [], options = {}) => {
  const stageDefinitions = normalizeWorkflowStageDefinitions(stageOptions, options);
  const returnedStages = Array.isArray(workflowPayload.workflow_stages) ? workflowPayload.workflow_stages : [];
  const stagesByCode = new Map(returnedStages.map((stage) => [normalizeStageCode(stage.stage_code), stage]));
  const currentCode = normalizeStageCode(
    workflowPayload.workflow_state?.current_stage_code ?? workflowPayload.opportunity?.opportunity_stage_code,
  );
  const currentIndex = stageDefinitions.findIndex((stage) => stage.code === currentCode);

  return stageDefinitions.map((stage, index) => {
    const apiStage = stagesByCode.get(stage.code);
    const isCompleted = currentIndex >= 0 && index < currentIndex;
    const isCurrent = currentIndex >= 0 && index === currentIndex;
    const tat = String(apiStage?.sla_compliance ?? '').toUpperCase();
    const isBreached = tat.includes('BREACH');

    return {
      ...stage,
      apiStage,
      status: isBreached ? 'breached' : isCurrent ? 'current' : isCompleted ? 'completed' : 'pending',
      tatLabel: getSlaComplianceLabel(apiStage?.sla_compliance, Boolean(apiStage)),
    };
  });
};

export const normalizeOpportunityActivityLogs = (response) => {
  const payload = response?.payload ?? response ?? {};
  const candidates = [
    payload.activities,
    payload.activity_logs,
    payload.activityLogs,
    payload.logs,
    payload.list,
    payload.records,
    payload.data,
    response?.activities,
    response?.logs,
  ];
  const list = candidates.find((candidate) => Array.isArray(candidate)) ?? [];

  return list.map((item, index) => ({
    id:
      item?.activity_id ??
      item?.activity_log_id ??
      item?.id ??
      `${item?.process_code ?? item?.stage_code ?? item?.activity_type ?? 'activity'}-${index}`,
    userName: formatWorkflowValue(
      item?.user_name ??
        item?.user ??
        item?.created_by_name ??
        item?.updated_by_name ??
        item?.actor_name ??
        item?.created_by,
    ),
    stageCode: formatWorkflowValue(
      item?.process_code ??
        item?.stage_code ??
        item?.activity_type ??
        item?.reference_type ??
        item?.module ??
        item?.tag,
    ),
    message: formatWorkflowValue(
      item?.activity_description ??
        item?.description ??
        item?.message ??
        item?.remarks ??
        item?.comment ??
        item?.comments ??
        item?.action,
    ),
    createdOn:
      item?.created_on ??
      item?.activity_on ??
      item?.updated_on ??
      item?.modified_on ??
      item?.date ??
      '',
  }));
};
