import { APP_CONFIG } from '../config/appConfig.js';

export const MAX_PORTFOLIO_OTHER_CONTACTS = APP_CONFIG.PORTFOLIO_MAX_OTHER_CONTACTS ?? 10;

export const isNewBusinessType = (businessType) =>
  String(businessType ?? '').trim().toLowerCase() === 'new';

export const showExpiringPolicyDetails = (businessType) => {
  const trimmed = String(businessType ?? '').trim();
  return trimmed !== '' && !isNewBusinessType(businessType);
};

const trim = (value) => (typeof value === 'string' ? value.trim() : value ?? '');

const fillIfEmpty = (current, fallback) => {
  const existing = trim(current);
  if (existing) return existing;
  return trim(fallback);
};

const LEGACY_FIELD_MAP = {
  lob: 'mibl_practice_lob',
  biz_type: 'business_type',
  brokerage: 'brokerage_consultancy',
};

const mapLegacyFields = (item) => {
  if (!item) return {};
  const mapped = { ...item };
  Object.entries(LEGACY_FIELD_MAP).forEach(([legacy, current]) => {
    if (mapped[current] == null && mapped[legacy] != null) {
      mapped[current] = mapped[legacy];
    }
  });
  return mapped;
};

export const emptyOtherContact = () => ({
  name: '',
  mobile: '',
  email: '',
});

const mapOtherContactsToForm = (source) => {
  if (Array.isArray(source?.other_contacts) && source.other_contacts.length) {
    return source.other_contacts.map((contact) => ({
      name: contact?.name ?? contact?.other_contact ?? '',
      mobile: contact?.mobile ?? contact?.other_contact_mobile ?? '',
      email: contact?.email ?? contact?.other_contact_email ?? '',
    }));
  }

  const legacyName = source?.other_contact ?? '';
  const legacyMobile = source?.other_contact_mobile ?? '';
  const legacyEmail = source?.other_contact_email ?? '';

  if (trim(legacyName) || trim(legacyMobile) || trim(legacyEmail)) {
    return [{ name: legacyName, mobile: legacyMobile, email: legacyEmail }];
  }

  return [];
};

/**
 * Read the portfolio contact back into form fields. New shape is client_data.portfolio.contact:
 * an array with the primary first (primary_contact_* keys) then other contacts (name/mobile/email).
 * Falls back to the old flat shape (primary_contact_* + other_contacts on the portfolio itself).
 */
const extractPortfolioContact = (source) => {
  if (Array.isArray(source?.contact) && source.contact.length) {
    const [primary = {}, ...others] = source.contact;
    return {
      primary_contact_person: primary.primary_contact_person ?? primary.name ?? '',
      primary_contact_mobile: primary.primary_contact_mobile ?? primary.mobile ?? '',
      primary_contact_email: primary.primary_contact_email ?? primary.email ?? '',
      other_contacts: others.map((c) => ({
        name: c?.name ?? '',
        mobile: c?.mobile ?? '',
        email: c?.email ?? '',
      })),
    };
  }
  return {
    primary_contact_person: source?.primary_contact_person ?? '',
    primary_contact_mobile: source?.primary_contact_mobile ?? '',
    primary_contact_email: source?.primary_contact_email ?? '',
    other_contacts: mapOtherContactsToForm(source),
  };
};

const mapSecondariesToOtherContacts = (secondaries = []) =>
  secondaries
    .map((item) => ({
      name: trim(item?.name),
      mobile: trim(item?.mobile),
      email: trim(item?.email),
    }))
    .filter((item) => item.name || item.mobile || item.email);

export const initialPortfolio = () => ({
  product: '',
  sub_product: '',
  primary_contact_person: '',
  primary_contact_mobile: '',
  primary_contact_email: '',
  other_contacts: [],
  sum_insured: '',
  expected_premium: '',
  brokerage_consultancy: '',
  renewal_date: '',
  business_type: '',
  policy_start_date: '',
  policy_expiry_date: '',
  previous_insurer: '',
  previous_policy_number: '',
  primary_owner: '',
  primary_owner_mobile: '',
  primary_owner_email: '',
  co_owner: '',
  co_owner_mobile: '',
  co_owner_email: '',
});

const toFormString = (value) => (value == null ? '' : String(value));

export const mapPortfolioToForm = (item) => {
  const source = mapLegacyFields(item);
  const contact = extractPortfolioContact(source);
  return {
    product: source.product ?? '',
    sub_product: source.sub_product ?? '',
    primary_contact_person: contact.primary_contact_person,
    primary_contact_mobile: contact.primary_contact_mobile,
    primary_contact_email: contact.primary_contact_email,
    other_contacts: contact.other_contacts,
    sum_insured: source.sum_insured != null ? toFormString(source.sum_insured) : '',
    expected_premium: source.expected_premium != null ? toFormString(source.expected_premium) : '',
    brokerage_consultancy:
      source.brokerage_consultancy != null ? toFormString(source.brokerage_consultancy) : '',
    renewal_date: source.renewal_date ?? '',
    business_type: source.business_type ?? '',
    policy_start_date: source.policy_start_date ?? '',
    policy_expiry_date: source.policy_expiry_date ?? '',
    previous_insurer: source.previous_insurer ?? '',
    previous_policy_number: source.previous_policy_number ?? '',
    primary_owner: source.primary_owner ?? '',
    primary_owner_mobile: source.primary_owner_mobile ?? '',
    primary_owner_email: source.primary_owner_email ?? '',
    co_owner: source.co_owner ?? '',
    co_owner_mobile: source.co_owner_mobile ?? '',
    co_owner_email: source.co_owner_email ?? '',
  };
};

const resolveContactName = (clientDraft) => {
  const comm = clientDraft?.communication ?? {};
  return trim(
    comm.primary_contact_name ??
      comm.primary_contact_person ??
      clientDraft?.primaryContactName ??
      '',
  );
};

const resolveOtherContacts = (portfolio, clientDraft) => {
  const existing = portfolio.other_contacts ?? [];
  const hasExisting = existing.some((item) => trim(item.name) || trim(item.mobile) || trim(item.email));
  if (hasExisting) return existing;

  const fromClient = mapSecondariesToOtherContacts(clientDraft?.communication?.secondaries);
  return fromClient;
};

export const mergePortfolioWithClientDraft = (portfolio, clientDraft) => {
  const comm = clientDraft?.communication ?? {};
  const contactName = resolveContactName(clientDraft);

  return {
    ...portfolio,
    primary_contact_person: fillIfEmpty(portfolio.primary_contact_person, contactName),
    primary_contact_mobile: fillIfEmpty(portfolio.primary_contact_mobile, comm.primary_mobile),
    primary_contact_email: fillIfEmpty(portfolio.primary_contact_email, comm.primary_email),
    other_contacts: resolveOtherContacts(portfolio, clientDraft),
  };
};

export const buildInitialPortfolioFromClient = (clientDraft, existingPortfolio) => {
  const base = existingPortfolio ? mapPortfolioToForm(existingPortfolio) : initialPortfolio();
  if (!clientDraft) return base;
  return mergePortfolioWithClientDraft(base, clientDraft);
};

export const getAutoPopulatedPortfolioFields = (clientDraft) => {
  const fields = new Set();
  if (!clientDraft) return fields;

  const comm = clientDraft.communication ?? {};

  if (resolveContactName(clientDraft)) fields.add('primary_contact_person');
  if (trim(comm.primary_mobile)) fields.add('primary_contact_mobile');
  if (trim(comm.primary_email)) fields.add('primary_contact_email');

  comm.secondaries?.forEach((secondary, index) => {
    if (trim(secondary?.name)) fields.add(`other_contact_${index}_name`);
    if (trim(secondary?.mobile)) fields.add(`other_contact_${index}_mobile`);
    if (trim(secondary?.email)) fields.add(`other_contact_${index}_email`);
  });

  return fields;
};

const toNumberOrNull = (value) => {
  const trimmed = trim(value);
  if (!trimmed) return null;
  const num = Number(trimmed);
  return Number.isNaN(num) ? null : num;
};

export const buildPortfolioData = (portfolio) => {
  const otherContacts = (portfolio.other_contacts ?? [])
    .map((contact) => ({
      name: trim(contact.name),
      mobile: trim(contact.mobile),
      email: trim(contact.email),
    }))
    .filter((contact) => contact.name || contact.mobile || contact.email);

  const firstOther = otherContacts[0] ?? { name: '', mobile: '', email: '' };

  return {
    product: trim(portfolio.product),
    sub_product: trim(portfolio.sub_product),
    primary_contact_person: trim(portfolio.primary_contact_person),
    primary_contact_mobile: trim(portfolio.primary_contact_mobile),
    primary_contact_email: trim(portfolio.primary_contact_email),
    other_contact: firstOther.name,
    other_contact_mobile: firstOther.mobile,
    other_contact_email: firstOther.email,
    other_contacts: otherContacts,
    sum_insured: toNumberOrNull(portfolio.sum_insured),
    expected_premium: Number(portfolio.expected_premium),
    brokerage_consultancy: Number(portfolio.brokerage_consultancy),
    renewal_date: portfolio.renewal_date,
    business_type: trim(portfolio.business_type),
    policy_start_date: portfolio.policy_start_date || null,
    policy_expiry_date: portfolio.policy_expiry_date || null,
    previous_insurer: trim(portfolio.previous_insurer),
    previous_policy_number: trim(portfolio.previous_policy_number),
    primary_owner: trim(portfolio.primary_owner),
    primary_owner_mobile: trim(portfolio.primary_owner_mobile),
    primary_owner_email: trim(portfolio.primary_owner_email),
    co_owner: trim(portfolio.co_owner),
    co_owner_mobile: trim(portfolio.co_owner_mobile),
    co_owner_email: trim(portfolio.co_owner_email),
  };
};
