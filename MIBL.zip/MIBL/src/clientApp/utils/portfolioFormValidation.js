import { PORTFOLIO_MESSAGES as MSG } from '../config/messages/portfolio.js';
import { PORTFOLIO_FORM_VALIDATION as CFG } from '../config/validation/portfolioForm.js';
import { isValidByField } from './fieldUtils.js';
import { showExpiringPolicyDetails } from './portfolioFormState.js';

const EXPIRING_POLICY_REQUIRED_FIELDS = [
  'policy_start_date',
  'policy_expiry_date',
  'previous_insurer',
  'previous_policy_number',
];

const isWithinRenewalDateRange = (value) => {
  const selected = new Date(`${value}T00:00:00`);
  if (Number.isNaN(selected.getTime())) return false;

  const min = new Date();
  const max = new Date();
  min.setHours(0, 0, 0, 0);
  max.setHours(0, 0, 0, 0);
  min.setFullYear(min.getFullYear() - 5);
  max.setFullYear(max.getFullYear() + 5);

  return selected >= min && selected <= max;
};

const parseDateOnly = (value) => {
  const rawValue = String(value ?? '').trim();
  if (!rawValue) return null;
  const parsedDate = new Date(`${rawValue}T00:00:00`);
  return Number.isNaN(parsedDate.getTime()) ? null : parsedDate;
};

const isAfterDate = (value, compareValue) => {
  const selectedDate = parseDateOnly(value);
  const compareDate = parseDateOnly(compareValue);
  if (!selectedDate || !compareDate) return true;
  return selectedDate > compareDate;
};

export const validatePortfolioForm = (portfolio) => {
  const errors = {};

  const requiredFields = showExpiringPolicyDetails(portfolio.business_type)
    ? [...CFG.required, ...EXPIRING_POLICY_REQUIRED_FIELDS]
    : CFG.required;

  requiredFields.forEach((field) => {
    const value = portfolio[field];
    const isEmpty = value == null || String(value).trim() === '';
    if (isEmpty) {
      const errorKey = CFG.errorKeys[field];
      errors[field] = MSG.errors[errorKey];
    }
  });

  Object.entries(CFG.fieldTypes).forEach(([field, fieldType]) => {
    if (errors[field]) return;
    const value = portfolio[field];
    if (!value || !String(value).trim()) return;
    if (!isValidByField(fieldType, value)) {
      errors[field] = MSG.errors[CFG.formatErrorKeys[fieldType]] ?? MSG.errors.invalidMobile;
    }
  });

  if (!errors.renewal_date && portfolio.renewal_date && !isWithinRenewalDateRange(portfolio.renewal_date)) {
    errors.renewal_date = MSG.errors.renewalDateRange;
  }

  if (
    !errors.policy_expiry_date &&
    portfolio.policy_start_date &&
    portfolio.policy_expiry_date &&
    !isAfterDate(portfolio.policy_expiry_date, portfolio.policy_start_date)
  ) {
    errors.policy_expiry_date = 'Policy Expiry Date should be after Policy Start Date';
  }

  if (
    !errors.renewal_date &&
    portfolio.policy_start_date &&
    portfolio.renewal_date &&
    !isAfterDate(portfolio.renewal_date, portfolio.policy_start_date)
  ) {
    errors.renewal_date = 'Renewal Date should be after Policy Start Date';
  }

  (portfolio.other_contacts ?? []).forEach((contact, index) => {
    const name = String(contact?.name ?? '').trim();
    const mobile = String(contact?.mobile ?? '').trim();
    const email = String(contact?.email ?? '').trim();
    const hasContactData = Boolean(name || mobile || email);

    if (!hasContactData) {
      errors[`other_contact_name_${index}`] = MSG.errors.otherContactRequired;
      errors[`other_contact_mobile_${index}`] = MSG.errors.otherContactMobileRequired;
      errors[`other_contact_email_${index}`] = MSG.errors.otherContactEmailRequired;
      return;
    }

    if (!name) {
      errors[`other_contact_name_${index}`] = MSG.errors.otherContactRequired;
    } else if (!isValidByField('name', name)) {
      errors[`other_contact_name_${index}`] = MSG.errors.invalidName;
    }

    if (!mobile) {
      errors[`other_contact_mobile_${index}`] = MSG.errors.otherContactMobileRequired;
    } else if (!isValidByField('mobile', mobile)) {
      errors[`other_contact_mobile_${index}`] = MSG.errors.invalidMobile;
    }

    if (!email) {
      errors[`other_contact_email_${index}`] = MSG.errors.otherContactEmailRequired;
    } else if (!isValidByField('email', email)) {
      errors[`other_contact_email_${index}`] = MSG.errors.invalidEmail;
    }
  });

  return errors;
};
