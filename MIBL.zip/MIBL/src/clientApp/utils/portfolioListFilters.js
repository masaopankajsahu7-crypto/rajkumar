import {
  DEFAULT_DATE_RANGE_PRESET,
  DEFAULT_SORT_ORDER,
  getDateRangeLabel,
} from './dateRangeFilters.js';

export const INITIAL_PORTFOLIO_FILTERS = {
  search: '',
  clientName: '',
  clientUUID: '',
  clientType: '',
  clientTypeLabel: '',
  clientVertical: '',
  clientVerticalLabel: '',
  owner: '',
  ownerId: '',
  portfolioType: '',
  portfolioTypeLabel: '',
  product: '',
  productLabel: '',
  subProduct: '',
  subProductLabel: '',
  isActive: '',
  isActiveLabel: '',
  fromDate: '',
  toDate: '',
  dateRangePreset: DEFAULT_DATE_RANGE_PRESET,
  dateFilterType: 'created_on',
  sortOrder: DEFAULT_SORT_ORDER,
};

export const normalizePortfolioListFilters = (filters = INITIAL_PORTFOLIO_FILTERS) => ({
  search: String(filters.search ?? '').trim(),
  clientName: String(filters.clientName ?? '').trim(),
  clientUUID: String(filters.clientUUID ?? '').trim(),
  clientType: String(filters.clientType ?? '').trim(),
  clientTypeLabel: String(filters.clientTypeLabel ?? '').trim(),
  clientVertical: String(filters.clientVertical ?? '').trim(),
  clientVerticalLabel: String(filters.clientVerticalLabel ?? '').trim(),
  owner: String(filters.owner ?? '').trim(),
  ownerId: String(filters.ownerId ?? '').trim(),
  portfolioType: String(filters.portfolioType ?? '').trim(),
  portfolioTypeLabel: String(filters.portfolioTypeLabel ?? '').trim(),
  product: String(filters.product ?? '').trim(),
  productLabel: String(filters.productLabel ?? '').trim(),
  subProduct: String(filters.subProduct ?? '').trim(),
  subProductLabel: String(filters.subProductLabel ?? '').trim(),
  isActive: String(filters.isActive ?? '').trim(),
  isActiveLabel: String(filters.isActiveLabel ?? '').trim(),
  fromDate: String(filters.fromDate ?? '').trim(),
  toDate: String(filters.toDate ?? '').trim(),
  dateRangePreset: String(filters.dateRangePreset ?? '').trim(),
  dateFilterType: String(filters.dateFilterType ?? 'created_on').trim(),
  sortOrder: String(filters.sortOrder ?? '').trim(),
});

export const hasActivePortfolioFilters = (filters = INITIAL_PORTFOLIO_FILTERS) =>
  Object.entries(filters).some(([key, value]) => {
    if (key === 'clientUUID' || key === 'ownerId' || key.endsWith('Label')) return false;
    if ((key === 'fromDate' || key === 'toDate') && filters.dateRangePreset !== 'CUSTOM') return false;
    if (key === 'dateRangePreset' && value === DEFAULT_DATE_RANGE_PRESET) return false;
    if (key === 'dateFilterType' && value === 'created_on') return false;
    if (key === 'sortOrder' && value === DEFAULT_SORT_ORDER) return false;
    return String(value ?? '').trim() !== '';
  });

export const countActivePortfolioFilters = (filters = INITIAL_PORTFOLIO_FILTERS) =>
  Object.entries(filters).filter(([key, value]) => {
    if (key === 'search' || key === 'clientUUID' || key === 'ownerId' || key.endsWith('Label')) return false;
    if (['fromDate', 'toDate', 'dateRangePreset', 'dateFilterType', 'sortOrder'].includes(key)) return false;
    return String(value ?? '').trim() !== '';
  }).length;

const formatChipDate = (value) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

export const getActivePortfolioFilterChips = (filters = INITIAL_PORTFOLIO_FILTERS, labels = {}) => {
  const chips = [];
  const chipConfig = [
    ['search', labels.search ?? 'Search'],
    ['clientName', labels.clientName ?? 'Client Name'],
    ['clientType', labels.clientType ?? 'Client Type', filters.clientTypeLabel],
    ['clientVertical', labels.vertical ?? 'Vertical', filters.clientVerticalLabel],
    ['owner', labels.owner ?? 'Owner'],
    ['portfolioType', labels.portfolioType ?? 'Business Type', filters.portfolioTypeLabel],
    ['product', labels.product ?? 'Product', filters.productLabel],
    ['subProduct', labels.subProduct ?? 'Sub Product', filters.subProductLabel],
    ['isActive', labels.portfolioStatus ?? 'Portfolio Status', filters.isActiveLabel],
  ];

  chipConfig.forEach(([key, label, displayValue]) => {
    if (String(filters[key] ?? '').trim()) {
      chips.push({ key, label: `${label}: ${String(displayValue || filters[key]).trim()}` });
    }
  });

  if (filters.dateRangePreset === 'CUSTOM' && String(filters.fromDate ?? '').trim()) {
    chips.push({ key: 'fromDate', label: `${labels.fromDate ?? 'Created From'}: ${formatChipDate(filters.fromDate)}` });
  }

  if (filters.dateRangePreset === 'CUSTOM' && String(filters.toDate ?? '').trim()) {
    chips.push({ key: 'toDate', label: `${labels.toDate ?? 'Created To'}: ${formatChipDate(filters.toDate)}` });
  }

  if (filters.dateRangePreset && filters.dateRangePreset !== DEFAULT_DATE_RANGE_PRESET) {
    chips.push({
      key: 'dateRangePreset',
      label: `${labels.dateRangePreset ?? 'Date Range'}: ${getDateRangeLabel(filters.dateRangePreset)}`,
    });
  }

  return chips;
};
