import {
  DEFAULT_DATE_RANGE_PRESET,
  DEFAULT_SORT_ORDER,
} from './dateRangeFilters.js';

export const RENEWAL_LEAD_LIST_PAGE_SIZE = 10;
export const RENEWAL_LEAD_PAGE_SIZE_OPTIONS = [10, 20, 30, 40, 50];

export const INITIAL_RENEWAL_LEAD_FILTERS = {
  search: '',
  fromDate: '',
  toDate: '',
  dateRangePreset: DEFAULT_DATE_RANGE_PRESET,
  sortColumn: '',
  sortOrder: DEFAULT_SORT_ORDER,
  clientName: '',
  clientMobile: '',
  clientEmail: '',
  product: '',
  policyNo: '',
  insurer: '',
  department: '',
  renewalStatus: '',
  renewalDays: '',
  owner: '',
  renewalLeadUUID: '',
};

const firstValue = (...values) =>
  values.find((value) => value !== undefined && value !== null && String(value).trim() !== '');

export const normalizeRenewalLeadFilters = (filters = {}) => ({
  search: String(filters.search ?? '').trim(),
  fromDate: String(filters.fromDate ?? '').trim(),
  toDate: String(filters.toDate ?? '').trim(),
  dateRangePreset: String(filters.dateRangePreset ?? INITIAL_RENEWAL_LEAD_FILTERS.dateRangePreset).trim(),
  sortColumn: String(filters.sortColumn ?? INITIAL_RENEWAL_LEAD_FILTERS.sortColumn).trim(),
  sortOrder: String(filters.sortOrder ?? INITIAL_RENEWAL_LEAD_FILTERS.sortOrder).toUpperCase() === 'DESC'
    ? 'DESC'
    : 'ASC',
  clientName: String(filters.clientName ?? '').trim(),
  clientMobile: String(filters.clientMobile ?? '').trim(),
  clientEmail: String(filters.clientEmail ?? '').trim(),
  product: String(filters.product ?? '').trim(),
  policyNo: String(filters.policyNo ?? '').trim(),
  insurer: String(filters.insurer ?? '').trim(),
  department: String(filters.department ?? '').trim(),
  renewalStatus: String(filters.renewalStatus ?? '').trim(),
  renewalDays: String(filters.renewalDays ?? '').trim(),
  owner: String(filters.owner ?? '').trim(),
  renewalLeadUUID: String(filters.renewalLeadUUID ?? '').trim(),
});

export const RENEWAL_SORT_OPTIONS = [
  { code: 'client_name', value: 'Client Name' },
  { code: 'policy_end_date', value: 'Policy End Date' },
  { code: 'renewal_create_date', value: 'Renewal Create Date' },
];

const FILTER_FIELD_LABELS = {
  clientName: 'Client Name',
  clientMobile: 'Client Mobile',
  clientEmail: 'Client Email',
  product: 'Product',
  policyNo: 'Policy No',
  insurer: 'Insurer',
  department: 'Department',
  renewalStatus: 'Renewal Status',
  renewalDays: 'Renewal Days',
  owner: 'Owner',
};

export const countActiveRenewalFilters = (filters = INITIAL_RENEWAL_LEAD_FILTERS) =>
  Object.entries(FILTER_FIELD_LABELS).filter(([key]) => String(filters[key] ?? '').trim() !== '').length;

export const hasActiveRenewalFilters = (filters = INITIAL_RENEWAL_LEAD_FILTERS) =>
  countActiveRenewalFilters(filters) > 0 ||
  String(filters.search ?? '').trim() !== '' ||
  String(filters.sortColumn ?? '').trim() !== '' ||
  String(filters.sortOrder ?? INITIAL_RENEWAL_LEAD_FILTERS.sortOrder).trim() !== INITIAL_RENEWAL_LEAD_FILTERS.sortOrder ||
  String(filters.dateRangePreset ?? '').trim() !== INITIAL_RENEWAL_LEAD_FILTERS.dateRangePreset ||
  String(filters.fromDate ?? '').trim() !== INITIAL_RENEWAL_LEAD_FILTERS.fromDate ||
  String(filters.toDate ?? '').trim() !== INITIAL_RENEWAL_LEAD_FILTERS.toDate;

export const getActiveRenewalFilterChips = (filters = INITIAL_RENEWAL_LEAD_FILTERS, displayValues = {}) => {
  const chips = [];
  Object.entries(FILTER_FIELD_LABELS).forEach(([key, label]) => {
    const value = String(filters[key] ?? '').trim();
    if (value) chips.push({ key, label: `${label}: ${displayValues[key]?.[value] ?? value}` });
  });
  return chips;
};

export const mapRenewalLeadRow = (lead = {}) => ({
  id: firstValue(lead.renewal_lead_id, lead.id),
  uuid: firstValue(lead.renewal_lead_uuid, lead.uuid),
  code: firstValue(lead.renewal_lead_code, lead.code),
  customerName: firstValue(lead.cust_name, lead.insured_name, lead.converted_client_name),
  contactPhone: firstValue(lead.cust_contact_phone, lead.mobile, lead.phone),
  contactEmail: firstValue(lead.cust_contact_email, lead.email),
  policyNo: firstValue(lead.policy_no, lead.policy_number),
  productName: firstValue(lead.product_name, lead.department),
  subproduct: firstValue(lead.subproduct, lead.sub_product),
  insurer: firstValue(lead.insurer, lead.insurer_name),
  department: firstValue(lead.department),
  policyCategory: firstValue(lead.policy_category),
  expiryDate: firstValue(lead.expiry_date, lead.policy_expiry_date),
  renewalDate: firstValue(lead.renewal_date),
  renewalDays: lead.renewal_days,
  graceDaysRemaining: lead.grace_days_remaining,
  rmName: firstValue(lead.assigned_owner_name, lead.rm_name),
  rmLocation: firstValue(lead.rm_location),
  status: firstValue(lead.renewal_status),
  statusCode: firstValue(lead.renewal_status_code),
  stage: firstValue(lead.renewal_stage),
  stageCode: firstValue(lead.converted_opportunity_stage_code),
  netPremium: lead.net_premium,
  sumInsured: lead.sum_insured,
  totalIncome: lead.total_income,
  brokerageAmount: lead.total_brokerage_amount,
  rewardAmount: lead.total_reward_amount,
  raw: lead,
});

export const parseRenewalLeadListApiResponse = (response) => {
  const payload = response?.payload ?? {};
  const list = Array.isArray(payload.renewal_leads) ? payload.renewal_leads.map(mapRenewalLeadRow) : [];

  return {
    list,
    totalCount: Number(payload.total_records ?? list.length) || 0,
    offset: Number(payload.offset ?? 0) || 0,
    limit: Number(payload.limit ?? RENEWAL_LEAD_LIST_PAGE_SIZE) || RENEWAL_LEAD_LIST_PAGE_SIZE,
    raw: response,
  };
};

export const getRenewalLeadTotalPages = (totalCount, pageSize = RENEWAL_LEAD_LIST_PAGE_SIZE) =>
  Math.max(Math.ceil((Number(totalCount) || 0) / pageSize), 1);
