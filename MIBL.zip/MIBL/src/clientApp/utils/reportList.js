export const REPORT_LIST_PAGE_SIZE = 10;

const firstValue = (...values) =>
  values.find((value) => value !== undefined && value !== null && String(value).trim() !== '') ?? '';

const getReportRecords = (response) => {
  const payload = response?.payload ?? response?.data?.payload ?? response?.data ?? response;
  const records = firstValue(
    payload?.reports,
    payload?.report_list,
    payload?.reportList,
    payload?.records,
    payload?.list,
    payload?.data,
    payload,
  );
  return Array.isArray(records) ? records : [];
};

export const normalizeReportRow = (report = {}) => ({
  requestId: String(firstValue(
    report.report_request_code,
    report.request_id,
    report.report_request_id,
    report.report_request_uuid,
    report.request_uuid,
    report.report_uuid,
    report.id,
  )),
  reportType: String(firstValue(
    report.report_type,
    report.report_type_name,
    report.report_name,
    report.report_type_code,
  )),
  reportTypeCode: String(firstValue(report.report_type_code, report.report_type)),
  fromDate: String(firstValue(report.from_date, report.start_date, report.date_from)),
  toDate: String(firstValue(report.to_date, report.end_date, report.date_to)),
  requestedOn: String(firstValue(
    report.requested_at,
    report.requested_on,
    report.request_on,
    report.created_on,
    report.created_at,
  )),
  requestedBy: String(firstValue(report.requested_by_name, report.requested_by, report.created_by_name)),
  status: String(firstValue(
    report.report_status_code,
    report.report_status,
    report.report_status_name,
    report.status_name,
    report.status,
  )),
  statusCode: String(firstValue(report.report_status_code, report.status_code, report.status)),
  fileUrl: String(firstValue(
    report.file_download_path,
    report.file_url,
    report.download_url,
    report.report_url,
    report.file_path,
    report.file,
  )),
  fileName: String(firstValue(report.file_name, report.filename, report.report_file_name)),
  raw: report,
});

export const parseReportListApiResponse = (response, page = 1) => {
  const payload = response?.payload ?? response?.data?.payload ?? response?.data ?? response;
  const list = getReportRecords(response).map(normalizeReportRow);
  const totalValue = firstValue(
    payload?.total_records,
    payload?.totalRecords,
    payload?.total_count,
    payload?.totalCount,
    payload?.pagination?.total_records,
    payload?.pagination?.total,
    list.length,
  );

  return {
    list,
    totalCount: Number(totalValue) || 0,
    page,
  };
};

export const formatReportLabel = (value) => {
  const text = String(value ?? '').trim();
  if (!text) return '---';
  return text
    .toLowerCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
};

export const formatReportDate = (value, { includeTime = false } = {}) => {
  const text = String(value ?? '').trim();
  if (!text) return '---';

  const parsed = new Date(text);
  const normalizedParsed = Number.isNaN(parsed.getTime())
    ? new Date(text.replace(' ', 'T'))
    : parsed;
  if (Number.isNaN(normalizedParsed.getTime())) return text;

  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    ...(includeTime ? { hour: '2-digit', minute: '2-digit', hour12: true } : {}),
  }).format(normalizedParsed);
};
