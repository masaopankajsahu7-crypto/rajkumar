export const BLOCKED_SPECIAL_CHARACTERS = ['>', '<', '#', '~'];
export const SPECIAL_CHARACTER_ERROR_MESSAGE = 'Special character not allowed';

const BLOCKED_SPECIAL_CHARACTER_PATTERN = /[><#~]/;

export const containsBlockedSpecialCharacter = (value) =>
  typeof value === 'string' && BLOCKED_SPECIAL_CHARACTER_PATTERN.test(value);

export const stripBlockedSpecialCharacters = (value) =>
  typeof value === 'string' ? value.replace(/[><#~]/g, '') : value;

const shouldSkipValue = (value) => {
  if (value == null) return true;
  if (value instanceof Date) return true;
  if (typeof File !== 'undefined' && value instanceof File) return true;
  if (typeof Blob !== 'undefined' && value instanceof Blob) return true;
  if (typeof FormData !== 'undefined' && value instanceof FormData) return true;
  return false;
};

export const findBlockedSpecialCharacterPath = (value, path = '') => {
  if (shouldSkipValue(value)) return '';

  if (containsBlockedSpecialCharacter(value)) return path || 'payload';

  if (Array.isArray(value)) {
    for (let index = 0; index < value.length; index += 1) {
      const match = findBlockedSpecialCharacterPath(value[index], `${path}[${index}]`);
      if (match) return match;
    }
    return '';
  }

  if (typeof value === 'object') {
    for (const [key, childValue] of Object.entries(value)) {
      const match = findBlockedSpecialCharacterPath(childValue, path ? `${path}.${key}` : key);
      if (match) return match;
    }
  }

  return '';
};

export const assertNoBlockedSpecialCharacters = (value) => {
  const blockedPath = findBlockedSpecialCharacterPath(value);
  if (blockedPath) {
    throw new Error(SPECIAL_CHARACTER_ERROR_MESSAGE);
  }
};

