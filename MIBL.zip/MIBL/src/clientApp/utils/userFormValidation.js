import { USER_MESSAGES as MSG } from '../config/messages/user.js';
import { USER_FORM_VALIDATION as CFG } from '../config/validation/userForm.js';
import { isValidByField } from './fieldUtils.js';

export const validateUserForm = (formData) => {
  const errors = {};
  const {
    sapCode,
    autoData,
    department,
    role,
  } = formData;

  if (!sapCode?.trim()) {
    errors.sap = MSG.errors.sapRequired;
  } else if (sapCode.replace(/\D/g, '').length !== 8) {
    errors.sap = MSG.errors.sapInvalid;
  }

  if (!autoData.name?.trim()) errors.name = MSG.errors.nameRequired;
  if (!autoData.mobile?.trim()) errors.mobile = MSG.errors.mobileRequired;
  if (!autoData.email?.trim()) errors.email = MSG.errors.emailRequired;
  if (!autoData.reportingManager?.trim()) errors.reportingManager = MSG.errors.reportingManagerRequired;
  if (!department) errors.department = MSG.errors.departmentRequired;
  if (!role) errors.role = MSG.errors.roleRequired;

  if (autoData.altMobile && !isValidByField('mobile', autoData.altMobile)) {
    errors.altMobile = MSG.errors.invalidMobile;
  }

  return errors;
};

export const validateUserAltMobile = (value) => {
  if (!value) return '';
  return isValidByField('mobile', value) ? '' : MSG.errors.invalidMobile;
};
