export const USER_LIST_PAGE_SIZE = 10;

export const FALLBACK_TOTAL_COUNT = 57;

const ALL_FALLBACK_USERS = Array.from({ length: FALLBACK_TOTAL_COUNT }, (_, index) => ({
  name: `User ${index + 1}`,
  phone: `98765${String(index + 1).padStart(5, '0')}`.slice(0, 10),
  email: `user${index + 1}@hm.com`,
  status: index % 2 === 0 ? 'Active' : 'Inactive',
}));

export function getFallbackUserList(page = 1) {
  const start = (page - 1) * USER_LIST_PAGE_SIZE;
  return {
    list: ALL_FALLBACK_USERS.slice(start, start + USER_LIST_PAGE_SIZE),
    totalCount: FALLBACK_TOTAL_COUNT,
  };
}

export function parseUserListResponse(response, page = 1) {
  if (!response) {
    return { list: [], totalCount: 0 };
  }

  if (response?.status_code === '200') {
    const rawList = response?.result0 ?? response?.result1 ?? response?.data ?? [];
    const list = Array.isArray(rawList)
      ? rawList.filter((row) => row && row.paginationCount == null && row.total_count == null)
      : [];

    const totalCount =
      response?.result1?.[0]?.paginationCount ??
      response?.result2?.[0]?.paginationCount ??
      response?.totalCount?.[0]?.total_count ??
      response?.totalCount ??
      response?.paginationCount ??
      list.length;

    if (list.length) {
      return { list, totalCount: Number(totalCount) || list.length };
    }

    return getFallbackUserList(page);
  }

  return getFallbackUserList(page);
}

export function getTotalPages(totalCount, pageSize = USER_LIST_PAGE_SIZE) {
  if (!totalCount) return 0;
  return Math.ceil(totalCount / pageSize);
}

export function buildPaginationItems(totalPages, currentPage = 1) {
  if (totalPages <= 0) return [];

  if (totalPages <= 3) {
    return Array.from({ length: totalPages }, (_, index) => ({
      type: 'page',
      page: index + 1,
      key: `page-${index + 1}`,
    }));
  }

  const pages = new Set([1, totalPages]);

  if (currentPage <= 3) {
    for (let page = 1; page <= Math.min(currentPage + 2, totalPages); page += 1) {
      pages.add(page);
    }
  } else if (currentPage >= totalPages - 2) {
    for (let page = Math.max(1, totalPages - 4); page <= totalPages; page += 1) {
      pages.add(page);
    }
  } else {
    pages.add(currentPage - 1);
    pages.add(currentPage);
    pages.add(currentPage + 1);
  }

  const sortedPages = [...pages].sort((a, b) => a - b);
  const items = [];

  sortedPages.forEach((page, index) => {
    const previousPage = sortedPages[index - 1];
    if (index > 0 && page - previousPage > 1) {
      items.push({ type: 'ellipsis', key: `ellipsis-${previousPage}-${page}` });
    }
    items.push({ type: 'page', page, key: `page-${page}` });
  });

  return items;
}
