import { Dialog, DialogTitle, DialogContent, IconButton, DialogActions, TextField, Button, Box, Typography, } from "@mui/material";
import { useEffect, useState } from "react";
import CloseIcon from '@mui/icons-material/Close';

const AddItemModal = ({ open, onClose, onSubmit, title, fields }) => {
    const [formData, setFormData] = useState({});

    useEffect(() => {
        setFormData({})
    }, [open])

    const handleChange = (field, value) => {
        setFormData((prev) => ({
            ...prev,
            [field]: value,
        }));
    };

    const handleSubmit = () => {
        onSubmit({ title, formData });
        setFormData({});
        onClose();
    };

    return (
        <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs"
            PaperProps={{
                sx: { borderRadius: "20px" },
            }}>
            <Box display={"flex"} justifyContent={"space-between"}>
                <DialogTitle className="fs-20 georama-Medium">Add New {title}</DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{ position: 'absolute', right: 8, top: 8, }}
                >
                    <CloseIcon />
                </IconButton>
            </Box>

            <DialogContent>
                <Box my={3} display="flex" flexDirection="column" gap={1}>  
                    <Typography className='text-labels' >
                        New {title} <span className="important-fields">*</span>
                    </Typography>
                    {fields.map((field) => (
                        <TextField
                            className='form-control-input border-radius-8'
                            key={field.name}
                            size="small"
                            fullWidth
                            required
                            placeholder={`Enter ${field.label}`}
                            value={formData[field.name] || ""}
                            // onInput={(e) => {
                            //     e.target.value = e.target.value.replace(/[^a-zA-Z]/g, '').slice(0, 50);
                            // }}
                            onChange={(e) => handleChange(field.name, e.target.value)}
                        />
                    ))}
                </Box>
            </DialogContent>

            <DialogActions>
                <Box display={"flex"} justifyContent={"space-between"} width={"100%"} gap={1} m={1}>
                    <Button className="btn-assign assign-txt" fullWidth onClick={onClose}>Close</Button>

                    <Button className="btn-common-red"
                        disabled={Object.values(formData).every((val) => val.trim() === "")}
                        fullWidth onClick={handleSubmit}>
                        Submit
                    </Button>
                </Box>
            </DialogActions>
        </Dialog>

    );
};

export default AddItemModal;