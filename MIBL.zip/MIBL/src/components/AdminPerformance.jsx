// import { useState } from 'react';
// import { Bar } from 'react-chartjs-2';

// const AdminPerformance = ({ adminPerformance = [] }) => {

//     const [selectedMetric, setSelectedMetric] = useState("weekly");

//     // Sort months to maintain correct order
//     const monthOrder = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

//     const sortedData = [...adminPerformance].sort(
//         (a, b) => monthOrder.indexOf(a.month) - monthOrder.indexOf(b.month)
//     );

//     const chartData = {
//         labels: sortedData.map(item => item.month),
//         datasets: [
//             {
//                 label: '% Conversion week-over-week',
//                 type: 'line',
//                 data: sortedData.map(item => item.weekly_avg_conversion_percent),
//                 borderColor: '#FF8A00',
//                 backgroundColor: '#FF8A00',
//                 yAxisID: 'y',
//                 tension: 0.6,
//                 pointRadius: 0,
//                 pointHoverRadius: 0,
//                 fill: false,
//                 order: 1,
//             },
//             {
//                 label: 'Month-over-month',
//                 type: 'line',
//                 data: sortedData.map(item => item.monthly_conversion_percent),
//                 borderColor: '#309CFF',
//                 backgroundColor: '#309CFF',
//                 yAxisID: 'y',
//                 tension: 0.4,
//                 pointRadius: 0,
//                 pointHoverRadius: 0,
//                 fill: false,
//                 order: 2,
//             },
//         ],
//     };

//     const options = {
//         responsive: true,
//         plugins: {
//             legend: {
//                 position: 'bottom',
//                 labels: {
//                     usePointStyle: true,
//                     pointStyle: 'circle',
//                     font: {
//                         size: 12,
//                         weight: 'bold',
//                     },
//                     boxWidth: 6,
//                     boxHeight: 6,
//                 },
//             },
//             tooltip: {
//                 enabled: true,
//                 callbacks: {
//                     label: function (context) {
//                         return `${context.dataset.label}: ${context.parsed.y}%`;
//                     },
//                 },
//             },
//         },
//         scales: {
//             y: {
//                 beginAtZero: true,
//                 position: 'left',
//                 min: 0,
//                 max: 100,
//                 title: { display: false },
//                 grid: { display: true },
//                 ticks: { color: '#333' },
//             },
//         },
//     };

//     return <Bar data={chartData} options={options} />;
// };

// export default AdminPerformance;







import React, { useState, useMemo } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
} from "chart.js";
import { Box, Stack, Typography } from "@mui/material";
import useMediaQuery from '@mui/material/useMediaQuery';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip);

const AdminPerformance = ({ adminPerformance = [] }) => {
  const [selectedMetric, setSelectedMetric] = useState("weekly");
  const isDesktop = useMediaQuery('(min-width:992px)');
  const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

  // Separate monthly and weekly data
  const monthlyData = useMemo(
    () =>
      adminPerformance
        .filter((d) =>
          [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
          ].includes(d.report_label)
        )
        .sort((a, b) => a.sort_key - b.sort_key),
    [adminPerformance]
  );

  const weeklyData = useMemo(
    () =>
      adminPerformance
        .filter((d) => d.report_label?.includes("Week"))
        .sort((a, b) => a.sort_key - b.sort_key),
    [adminPerformance]
  );

  // Choose data dynamically
  const activeData = selectedMetric === "weekly" ? weeklyData : monthlyData;
  const labels = activeData.map((d) => d.report_label);
  const conversionValues =
    selectedMetric === "weekly"
      ? activeData.map((d) => d.weekly_conversion_percent || 0)
      : activeData.map((d) => d.monthly_conversion_percent || 0);

  // Get overall average
  const overall = adminPerformance.find((d) => d.report_label === "Overall Average");
  const averageValue =
    selectedMetric === "weekly"
      ? overall?.weekly_conversion_percent || 0
      : overall?.monthly_conversion_percent || 0;

  const averageLine = new Array(labels.length).fill(averageValue);

  const chartData = {
    labels,
    datasets: [
      {
        label:
          selectedMetric === "weekly"
            ? "% Conversion week-over-week"
            : "Month-over-month",
        data: conversionValues,
        borderColor: selectedMetric === "weekly" ? "#FF8A00" : "#309CFF",
        backgroundColor: selectedMetric === "weekly" ? "#FF8A00" : "#309CFF",
        borderWidth: 2,
        pointRadius: 3,
        pointHoverRadius: 6,
        fill: false,
        tension: 0.4,
      },
      {
        label: "Average",
        data: averageLine,
        borderColor: "#1EB564",
        backgroundColor: "#1EB564",
        borderWidth: 2,
        borderDash: [4, 4],
        pointRadius: 2,
        pointHoverRadius: 5,
        tension: 0,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { display: false },
      tooltip: {
        mode: "nearest",
        intersect: false,
        callbacks: {
          title: (context) => {
            const index = context[0].dataIndex;
            const data = activeData[index];

            // ✅ Show week_start and week_end only for weekly data
            if (selectedMetric === "weekly" && data.week_start && data.week_end) {
              const start = new Date(data.week_start).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
              });
              const end = new Date(data.week_end).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
              });
              return `${data.report_label} (${start} - ${end})`;
            }

            // For monthly data
            return data.report_label;
          },
          label: (context) => {
            const datasetLabel = context.dataset.label;
            const value = context.parsed.y;
            if (datasetLabel === "Average") {
              return `Average: ${value.toFixed(2)}%`;
            }
            return `${datasetLabel}: ${value.toFixed(2)}%`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        ticks: { color: "#333", callback: (val) => `${val}%` },
        title: {
          display: true,
          text:
            selectedMetric === "weekly"
              ? "Weekly Conversion %"
              : "Monthly Conversion %",
          color: "#333",
          font: { size: 12, weight: "bold" },
        },
      },
      x: {
        ticks: { color: "#333" },
        title: {
          display: true,
          text: selectedMetric === "weekly" ? "Weeks" : "Months",
          color: "#333",
          font: { size: 12, weight: "bold" },
        },
        grid: { display: false },
      },
    },
  };

  const legendItems = [
    { key: "weekly", color: "#FF8A00", label: "% Conversion week-over-week" },
    { key: "monthly", color: "#309CFF", label: "Month-over-month" },
  ];

  return (
    <Box className="w-full bg-white p-4 rounded-lg shadow-md" sx={{ height: 300 }} mb={7} >
      <Line data={chartData} options={{
        ...options,
        maintainAspectRatio: false,
      }} />

      {/* Custom Legend */}
      <Stack
        direction="row"
        justifyContent="center"
        alignItems="center"
        spacing={2}
        sx={{ my: 2 }}
      >
        {legendItems.map((item) => (
          <Stack
            key={item.key}
            direction="row"
            alignItems="center"
            spacing={0.5}
            onClick={() => setSelectedMetric(item.key)}
            sx={{
              cursor: "pointer",
              transition: "all 0.2s ease",
              opacity: selectedMetric === item.key ? 1 : 0.6,
              transform:
                selectedMetric === item.key ? "scale(1.05)" : "scale(1)",
              "&:hover": { opacity: 0.8 },
            }}
          >
            <Box
              sx={{
                width: isMobile ? 14 : 8,
                height: isMobile ? 8 : 8,
                borderRadius: "50%",
                backgroundColor: item.color,
              }}
            />
            <Typography
              variant="body2"
              sx={{
                fontSize: isMobile ? 10 : 12,
                fontWeight: 500,
                color:
                  selectedMetric === item.key
                    ? item.color
                    : "text.secondary",
              }}
            >
              {item.label}
            </Typography>
          </Stack>
        ))}

        {/* Always show Average */}
        <Stack direction="row" alignItems="center" spacing={0.5}>
          <Box
            sx={{
              width: 10,
              height: 10,
              borderRadius: "50%",
              backgroundColor: "#1EB564",
            }}
          />
          <Typography
            variant="body2"
            sx={{ fontSize: 12, fontWeight: 500, color: "#1EB564" }}
          >
            Average
          </Typography>
        </Stack>
      </Stack>
    </Box>
  );
};

export default AdminPerformance;
