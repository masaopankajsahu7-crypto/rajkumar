import { useMemo, useState } from 'react';
import { Box, Button, Checkbox, FormControlLabel, Divider, List, ListItemButton, TextField, Stack, useMediaQuery } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { setSelectedFilters } from '../redux/slices/callQueueSlice';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import "./DateRange/DateRangeStyles.css";
import { startOfMonth, subMonths } from 'date-fns';
import { DateRangePicker } from 'react-date-range';
import dayjs from 'dayjs';

export default function AdvancedFilter({ saveFilter, applyFilter, resetFilter }) {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const dispatch = useDispatch();
    const [activeFilter, setActiveFilter] = useState('Renewal Category');
    const minAllowedDate = useMemo(() => startOfMonth(subMonths(new Date(), 1)), []);
    const selectedFilters = useSelector((state) => state.callQueue.selectedFilters);
    const filterValues = useSelector((state) => state.callQueue.filterValues);
    const { fromDate, toDate } = useSelector(state => state.callQueue);
    const createDefaultRange = () => ({
        startDate: selectedFilters?.['Expiry Date From'],
        endDate: selectedFilters?.['Expiry Date To'],
        key: 'selection'
    });

    const [range, setRange] = useState([
        createDefaultRange()
    ]);
    const handleSelect = (ranges) => {
        setRange([ranges.selection]);
        if (ranges.selection?.startDate && ranges.selection?.endDate) {
            let startDate = dayjs(ranges.selection?.startDate).format('YYYY-MM-DD');
            let endDate = dayjs(ranges.selection?.endDate).format('YYYY-MM-DD');
            dispatch(setSelectedFilters({ ...selectedFilters, 
                ["Expiry Date From"]: startDate, ["Expiry Date To"]: endDate}));
        }
        console.log(selectedFilters);
    };
    

    const handleCheckboxChange = (filterKey, value) => {
        const current = selectedFilters?.[filterKey] ?? [];
        const updated = current.includes(value)
            ? current.filter((v) => v !== value)
            : [...current, value];

        dispatch(setSelectedFilters({ ...selectedFilters, [filterKey]: updated }));
    };

    return (
        <Box>
            <Box display='flex' sx={{ justifyContent: "space-between", px: 2, alignItems: 'center' }}>
                <Box><b>Filters</b></Box>
                <Button color='error' onClick={() => saveFilter()}>Save Filter</Button>
            </Box>
            <Divider />
            {/* Body */}
            <Box display="flex" height={300} overflow="auto">
                {/* Left list of filter types */}
                <List sx={{ py: 0, width: '30%', borderRight: '1px solid #ddd' }}>
                    {Object.keys(filterValues).map((key) => (
                        <ListItemButton
                            sx={{
                                backgroundColor: activeFilter === key ? '#FFE8EC !important' : 'transparent',
                            }}
                            key={key}
                            selected={activeFilter === key}
                            onClick={() => setActiveFilter(key)}
                        >
                            {key}
                        </ListItemButton>
                    ))}
                </List>

                {/* Right checkboxes */}
                <Stack sx={{ width: '70%', overflowY: 'auto', overflowX: 'hidden', maxHeight: 300 }}>
                    {activeFilter !== 'Expiry Days' ? filterValues[activeFilter]?.map((option) => (
                        <FormControlLabel sx={{ px: 1 }}
                            key={option}
                            control={
                                <Checkbox size='small' sx={{ color: '#e53935', '&.Mui-checked': { color: '#e53935' }, }}
                                    checked={(selectedFilters?.[activeFilter] ?? [])?.includes(option) || false}
                                    onChange={() => handleCheckboxChange(activeFilter, option)}
                                />
                            }
                            label={option}
                        />
                    )) :
                        // <TextField size='small' sx={{ py: 1, mx: 1 }}
                        //     onChange={(e) => {
                        //         const cleaned = e.target.value.replace(/[^0-9-]/g, '').replace(/(?!^)-/g, '');
                        //         let value = Number(cleaned);
                        //         if (value > 60) {
                        //             value = 60;
                        //         }
                        //         dispatch(setSelectedFilters({ ...selectedFilters, ['Expiry Days']: value }));
                        //     }} placeholder='Enter Expiry Days' value={selectedFilters?.['Expiry Days'] || ''}
                        //     inputProps={{ max: 60 }} />
                        <DateRangePicker minDate={minAllowedDate}
                            ranges={range}
                            onChange={handleSelect}
                            showSelectionPreview
                            moveRangeOnFirstSelection={false}
                            months={1}
                            direction="horizontal"
                            editableDateInputs
                        />
                    }
                </Stack>
            </Box>
            <Divider />
            <Box display='flex' sx={{ justifyContent: "end", p: 1, alignItems: 'center' }}>
                <Button sx={{ color: 'black' }} onClick={() => resetFilter()}>Reset All</Button>
                <Button onClick={applyFilter} className="btn-common-red">Apply</Button>
            </Box>
        </Box>
    );
}
