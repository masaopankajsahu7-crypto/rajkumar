import { Box } from '@mui/material';
import { useState } from 'react';
import { useSelector } from 'react-redux';
import { Outlet, useLocation, useParams } from 'react-router-dom';
import { bgGray100 } from '../utils/Colors';
import Header, { DrawerHeader } from './Header';
import SideNav from './SideNav';
import './AppLayout.css';
import { decryptRoute } from '../services/encrypt';

const AppLayout = ({ children },) => {
  const [open, setOpen] = useState(true);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const userdata = useSelector((state) => state.user.loggedData);
  const location = useLocation();
  const { encrypted } = useParams();
  const currentPath = (() => {
    try {
      return encrypted ? decryptRoute(decodeURIComponent(encrypted)) : location.pathname;
    } catch {
      return location.pathname;
    }
  })();
  const isClientWorkAreaRoute =
    currentPath.startsWith('/dashboard') ||
    currentPath.startsWith('/clients') ||
    currentPath.startsWith('/opportunities') ||
    currentPath.startsWith('/portfolios') ||
    currentPath.startsWith('/renewals') ||
    currentPath.startsWith('/activities') ||
    currentPath.startsWith('/crm') ||
    currentPath.startsWith('/kpi-dashboard') ||
    currentPath.startsWith('/performance-dashboard') ||
    currentPath.startsWith('/aes-json-cipher') ||
    currentPath.startsWith('/reports');

  const handleDrawer = () => {
    setOpen(!open);
  };

  return (
    <>
      <Box sx={{ display: 'flex', ...bgGray100 }}>
        <Header open={open} handleDrawer={handleDrawer} />
        {userdata?.roleType === "MIBL" ? (
          <>
            {!isClientWorkAreaRoute && (
              <SideNav open={open} selectedIndex={selectedIndex} setSelectedIndex={setSelectedIndex} />
            )}
            <Box width={isClientWorkAreaRoute ? '100%' : 'calc(100% - 57px)'} display="flex" flexDirection='column'>
              <Box width="100%" display="flex"><DrawerHeader /></Box>
              <Box
                width="100%"
                display="flex"
                className={isClientWorkAreaRoute ? 'app-layout-client-surface' : 'body-formbg'}
              >
                <Outlet />
                {children}
              </Box>
            </Box>
          </>
        )
          : (
            <>
              <Box width="100%" display="flex" flexDirection='column'>
                <Box width="100%" display="flex"><DrawerHeader /></Box>
                <Box width="100%" display="flex" className='body-formbg'>
                  <Outlet />
                  {/* {userdata?.marque && <MarqueeInfo/>} */}
                  {children}
                </Box>
              </Box>
            </>
          )}
      </Box>
    </>
  );
};

export default AppLayout;
