import { Box, Grid, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, ToggleButton, ToggleButtonGroup, Tooltip } from '@mui/material';
import { useEffect, useState } from 'react';
import { customerDetail } from "../services/api";
import { InfoCard } from './DealerOverview';
// import { InfoCard } from '../components/DealerOverview';
import { ChevronRight, InfoOutline } from '@mui/icons-material';
import { format, parseISO } from 'date-fns';
import { useSelector } from 'react-redux';
import addonpremium from '../assets/images/customer/addonpremium.svg';
import chassisno from '../assets/images/customer/chassisno.svg';
import dateInvoice from '../assets/images/customer/dateInvoice.svg';
import dateregistration from '../assets/images/customer/dateregistration.svg';
import engineno from '../assets/images/customer/engine-no.svg';
import fueltype from '../assets/images/customer/fueltype.svg';
import make from '../assets/images/customer/make.svg';
import model from '../assets/images/customer/model.svg';
import ncbpercentage from '../assets/images/customer/ncbpercentage.svg';
import oddates from '../assets/images/customer/oddates.svg';
import oddiscount from '../assets/images/customer/oddiscount.svg';
import plantype from '../assets/images/customer/plantype.svg';
import premium from '../assets/images/customer/premium.svg';
import registrationno from '../assets/images/customer/registrationno.svg';
import renewallink from '../assets/images/customer/renewallink.svg';
import totalod from '../assets/images/customer/totalod.svg';
import totaltp from '../assets/images/customer/totaltp.svg';
import variant from '../assets/images/customer/variant.svg';
import vehicleclass from '../assets/images/customer/vehicle-class.svg';
import viewaddon from '../assets/images/customer/viewaddon.svg';
import group from '../assets/images/group.svg';
import AddOnDrawer from '../components/Drawers/AddOnDrawer';
import { borderLight, cursorpointer, tabselectedColor } from '../utils/Colors';
import BackdropLoader from './Loader/BackdropLoader';

const CustomerSearchDetail = ({ customerInfo }) => {
    const [type, setType] = useState('policy');
    const [loading, setLoading] = useState(false);


    const handleTypeChange = async (e, v) => {
        if (!v) return;

        setLoading(true);

        try {
            setType(v);
            // if (!rows[v]) {
            let typeRows = await fetchData(v);
            if (typeRows) {
                setRows((prev) => ({
                    ...prev,
                    [v]: typeRows?.policyDetails,
                }));
            }
            // }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const initFetch = async () => {
            try {
                setLoading(true);
                let typeRows = await fetchData("policy");
                if (typeRows) {
                    setRows((prev) => ({
                        ...prev,
                        policy: typeRows?.policyDetails,
                    }));
                }
            } catch (error) {
                console.error(error);
            } finally {
                setLoading(false);
            }
        };

        initFetch();
    }, []);

    // const handleTypeChange = async (e, v) => {
    //     setType(v);
    //     if (!rows[v]) {
    //         let typeRows = await fetchData(v);
    //         setRows(prev => ({
    //             ...prev,
    //             [v]: typeRows[v],
    //         }));
    //     }
    // };

    const { user_id } = useSelector((state) => state.user.loggedData);
    const [rows, setRows] = useState({});
    const [response, setResponse] = useState({});
    const [openDrawer, setOpenDrawer] = useState(false);
    const [addonData, setAddonData] = useState(null);

    const handleOpenDrawer = () => {
        fetchData("addon");
        setOpenDrawer(true);
    };

    const handleCloseDrawer = () => {
        setOpenDrawer(false);
    };

    useEffect(() => {
        fetchPage();
        fetchData("addon");
        // fetchData(type);
    }, []);

    const fields = [
        { label: "Policy Details", type: 'policy', icon: '' },
        { label: "Service History", type: 'service', icon: '' },
        { label: "Claim History", type: 'claim', icon: '' },
        { label: "Sales History", type: 'sales', icon: '' },
        { label: "Reminder Renewal", type: 'reminder', icon: '' }
    ];

    const columns = {
        "policy": {
            "Insurance Company": "insurance_company",
            "Policy No": "policy_no",
            "Tenure": "policy_tenure",
            "Type": "policy_type",
            "Effective Date": "policy_effective_date",
            "Expiry Date": "policy_expiry_date",
            "Plan Type": "plan_type",
            "YOM": "yom"
        },
        "service": {
            "Service Type": "service_type",
            "Repair Order No": "repair_order_no",
            "Service Category": "service_category",
            "RO Date": "ro_date",
            "Customer Mobile No.": "customer_mobile_no",
            "Service Advisor": "service_advisor"
        },
        "claim": {
            "Policy No": "policy_no",
            "Claim No": "claim_no",
            "Claim Intimation Date and Time": "claim_intimation_date_time",
            "Nature of Loss": "nature_of_loss",
            "Insurance Claim No": "insurance_claim_no",
            "Accident City": "accident_city",
            "Claim Status": "claim_status"
        },
        "sales": {
            "Invoice Number": "invoice_number",
            "Invoice Date and Time": "invoice_date_time",
            "Dealer Parent Code": "dealer_parent_code",
            "Dealer Parent Name": "dealer_parent_name",
            "Dealer Location Code": "dealer_location_code",
        },
        "reminder": {
            "Policy ID": "policy_id",
            "Mode": "mode",
            "Reminder Frequency": "reminder_frequency",
            "Sent Date": "sent_date",
            "Renewal Link": "renewal_link",
        }
    };

    const [customerDetails, setCustomerDetails] = useState({});

    const fetchPage = async () => {
        try {
            setLoading(true);
            let result = await customerDetail({ ...customerInfo, type: 'overview', userId: user_id })
            // setResponse(result);
            setCustomerDetails(result.policyDetails[0]);
            // setRows({ policy: result.policyHistory });
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    const fetchData = async (type) => {
        try {
            setLoading(true);
            let result = await customerDetail({ ...customerInfo, type, userId: user_id })
            if (type === "addon") {
                setAddonData(result?.policyDetails || []);
            }
            return result;
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    const Dealer_Overview_Data = [
        [
            { icon: <img src={make} alt="Make" />, label: 'Make', value: customerDetails?.make },
            { icon: <img src={model} alt="Model" />, label: 'Model', value: customerDetails?.model },
            { icon: <img src={variant} alt="Variant" />, label: 'Variant', value: customerDetails?.variant },
            { icon: <img src={fueltype} alt="Fuel Type" />, label: 'Fuel Type', value: customerDetails?.fuel_type },
            { icon: <img src={vehicleclass} alt="Vehicle Class" />, label: 'Vehicle Class', value: customerDetails?.vehicle_class },
        ],
        [
            { icon: <img src={registrationno} alt="Registration No" />, label: 'Registration no', value: customerDetails?.vehicle_reg_no },
            { icon: <img src={engineno} alt="Engine No" />, label: 'Engine No', value: customerDetails?.engine_no },
            { icon: <img src={chassisno} alt="Chassis No" />, label: 'Chassis No', value: customerDetails?.chassis_no },
            {
                icon: <img src={dateregistration} alt="Date of Registration" />, label: 'Date of Registration',
                value: `${customerDetails && customerDetails?.registration_date ? customerDetails?.registration_date : ''}`
                // value: `${customerDetails && customerDetails?.registration_date ? format(parseISO(customerDetails?.registration_date), 'dd-MM-yyyy') : ''}`
            },
            {
                icon: <img src={dateInvoice} alt="Date of Invoice" />, label: 'Date of Invoice',
                value: `${customerDetails && customerDetails?.invoice_date ? customerDetails?.invoice_date : ''}`
            },
            // { icon: <img src={claimhistory} alt="Claim History" />, label: 'Claim History', value: `${customerDetails?.claim_history}` },
        ],
        [
            { icon: <img src={plantype} alt="Plan Type" />, label: 'Plan Type', value: customerDetails?.plan_type },
            {
                icon: <img src={oddates} alt="OD Dates" />, label: 'OD Dates', value: customerDetails?.odDates
                // customerDetails?.odDates?.split(' | ')?.map(d => format(parseISO(d), 'dd-MMM-yyyy')).join(' | ')}`
            },
            {
                icon: <img src={oddates} alt="TP Date" />, label: 'TP Date', value: customerDetails?.tpDates
                // customerDetails?.tpDates?.split(' | ')?.map(d => format(parseISO(d), 'dd-MMM-yyyy')).join(' | ')}`
            },
            {
                icon: <img src={renewallink} alt="Renewal Link" />, label: 'Renewal Link',
                value: <Box component="a" href={customerDetails?.renewal_Link} target='_blank' display={"flex"} alignItems={"center"}
                    sx={customerDetails?.renewal_Link ? { ...tabselectedColor, ...cursorpointer } : { ...cursorpointer }}>Renewal<ChevronRight /></Box>
            },
            {
                icon: <img src={viewaddon} alt="View Addon" />, label: 'View Addon',
                value: <Box display={"flex"} alignItems={"center"}
                    onClick={addonData?.length > 0 ? handleOpenDrawer : null}
                    sx={addonData?.length > 0 ? { ...tabselectedColor, ...cursorpointer } : { ...cursorpointer }}
                // sx={{ ...tabselectedColor, ...cursorpointer }}
                // onClick={handleOpenDrawer}
                >View<ChevronRight /></Box>
            },
            {
                icon: <img src={viewaddon} alt="Combi Products" />, label: 'Combi Products',
                value: customerDetails?.group_product
                // value: <Box display={"flex"} justifyItems={"center"} sx={{ ...tabselectedColor, ...cursorpointer }}>View<ChevronRight /></Box>
            },
        ],
        [
            { icon: <img src={ncbpercentage} alt="NCB Percentage" />, label: 'NCB Percentage', value: `${customerDetails?.ncb_percentage || 0}%` },
            { icon: <img src={oddiscount} alt="OD Discount %" />, label: 'OD Discount %', value: `${customerDetails?.od_discount || 0}%` },
            {
                icon: <img src={totalod} alt="Total OD" />, label: 'Total OD', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.totalod ?? 0)}`
            },
            {
                icon: <img src={totaltp} alt="Total TP" />, label: 'Total TP', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.totaltp ?? 0)}`
            },
            {
                icon: <img src={addonpremium} alt="Addon Premium" />, label: 'Addon Premium', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.addon_premium_amount ?? 0)}`
            },
            {
                icon: <img src={premium} alt="Premium" />, label: 'Premium', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.net_premium ?? 0)}`
            },
        ]
    ];

    return (
        <>
            <BackdropLoader loading={loading} />
            <Box sx={{ py: 2 }} >
                <Box sx={{ backgroundColor: "white", borderRadius: 2, }}>
                    {/* <Typography variant="h6">Overview</Typography> */}
                    <Box>
                        <Grid container spacing={2}>
                            {
                                // customerDetails &&
                                Dealer_Overview_Data?.map((card, index) => (
                                    <Grid className="" sx={{ borderRadius: 2 }} size={3} item key={index} xs={12} sm={6} md={6} lg={4}>
                                        <InfoCard items={card} />
                                    </Grid>
                                ))}
                        </Grid>
                    </Box>
                </Box>

                <Box sx={{ my: 1, ...borderLight, boxShadow: "none", backgroundColor: "white", py: 0.5, borderRadius: 2, }}>
                    <Box display="flex" gap={1}
                    // sx={{ borderBottom: "1px solid #e1e0e0ff" }}
                    >
                        <ToggleButtonGroup
                            value={type}
                            exclusive
                            onChange={(e, v) => { if (v) handleTypeChange(e, v) }}
                            sx={{
                                display: 'flex',
                                gap: 1,
                                p: 1,
                                // border: 'none',

                            }}
                        >
                            {fields.map((fieldData) => (
                                <ToggleButton className="toggle-button"
                                    key={fieldData.type}
                                    value={fieldData.type}
                                >
                                    {fieldData.label}{fieldData.type === 'claim' && customerDetails?.claim_history === 'Yes' &&
                                        <img style={{ marginLeft: 5 }} src={group} />}
                                </ToggleButton>
                            ))}
                        </ToggleButtonGroup>
                    </Box>

                    {/* Table Section */}
                    <TableContainer sx={{ boxShadow: "none" }}>
                        <Table sx={{ boxShadow: "none" }} className='customer-details-table-td'>
                            <TableHead className='customer-details-table'>
                                <TableRow>
                                    {Object.keys(columns[type]).map((col, i) => <TableCell sx={{ fontWeight: "normal" }} className='georama-Medium fs-12' key={i}>{col}{type === 'reminder' &&
                                        col === 'Reminder Frequency' && <Tooltip title="T-Policy Expiry Date" sx={{ ml: 1 }} placement="top" arrow>
                                            <InfoOutline fontSize='1em' />
                                        </Tooltip>}</TableCell>)}
                                    {type === 'policy' && <TableCell>Add on</TableCell>}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rows && rows[type] && rows[type]?.map((row, index) => (
                                    <TableRow key={index}>
                                        {
                                            Object.values(columns[type])?.map((f) => (
                                                f.slice(-4) === 'time' ?
                                                    <TableCell key={f} sx={{ borderBottom: "none" }}>
                                                        {/* {format(parseISO(row[f]), 'dd-MM-yyyy HH:mm')} */}
                                                        {row[f]}
                                                    </TableCell>
                                                    : f.slice(-4) === 'date' ? <TableCell sx={{ borderBottom: "none" }} key={f}>{format(parseISO(row[f]), `${type === 'policy' ? 'dd-MMM-yy' : type === 'reminder' ? 'dd-MM-yyyy' : 'dd-MM-yyyy HH:mm'
                                                        }`)}</TableCell>
                                                        : f === 'renewal_link' ? <TableCell sx={{ borderBottom: "none" }}>
                                                            <b><Box display={"flex"} alignItems={"center"} component="a" href={row[f]} target='_blank' sx={row[f] ? { ...tabselectedColor, ...cursorpointer } : { ...cursorpointer }}>Renewal<ChevronRight /></Box></b>
                                                        </TableCell> : <TableCell sx={{ borderBottom: "none" }} key={f}>{row[f]}</TableCell>
                                            ))}
                                        {type === 'policy' && <TableCell sx={{ borderBottom: "none" }}>
                                            <b><Box display={"flex"} alignItems={"center"}
                                                sx={addonData?.length > 0 ? { ...tabselectedColor, ...cursorpointer } : { ...cursorpointer }}
                                                onClick={addonData?.length > 0 ? handleOpenDrawer : null}
                                            // onClick={handleOpenDrawer} sx={{ ...tabselectedColor, ...cursorpointer }}
                                            >View<ChevronRight /></Box></b>
                                        </TableCell>}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>
            </Box >
            <AddOnDrawer open={openDrawer} onClose={handleCloseDrawer} addonData={addonData} />
        </>
    )
}

export default CustomerSearchDetail;