import { Box, Grid, Paper, Typography, useMediaQuery } from '@mui/material';
import { useSelector } from 'react-redux';
import recentlysvg from "../assets/images/managerdashboard/recently.svg";

const DashboardLayout = () => {
  const convertedLeads = useSelector(state => state.dashboard.recentlyConverted);
  const isDesktop = useMediaQuery('(min-width:992px)');
  const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

  return (
    <Grid
      p={isMobile ? 0.5 : 2}
      borderRadius={2}
      sx={{ backgroundColor: "#ffffff" }}
      item
      xs={12}
      md={4}
    >
      <Box
        display={"flex"}
        alignItems="center"
        justifyContent={"left"}
        gap={1}
        p={isMobile ? 1 : 0}
      >
        <img loading="lazy" width={16} height={16} src={recentlysvg} alt="" />
        <Typography className="georama-SemiBold fs-14">
          Recently Converted / Closed Leads
        </Typography>
      </Box>

      <Paper
        elevation={0}
        sx={{ height: "95vh", gap: 2, overflowY: "auto" }}
      // sx={{ gap: 2, overflowY: "auto" }}
      >

        <Grid
          spacing={3}
          container
          sx={{
            padding: 0.5,
            mt: isMobile ? 0 : 1,
            display: "flex",
            flexDirection: "column",
            gap: 1.2,
          }}
        >
          {convertedLeads &&
            convertedLeads
              .filter(
                (lead) =>
                  lead.leadId !== 0 &&
                  lead.status !== "0" &&
                  lead.customerName !== "0" &&
                  lead.policyNo !== "0" &&
                  lead.vehicleDetail !== "0"
              )
              .map((lead, index) => (
                <Grid
                  key={index}
                  p={1}
                  sx={{
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    display: "flex",
                    flexDirection: "column",
                    gap: 0,
                  }}
                >
                  <Box
                    display={"flex"}
                    gap={2}
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <Typography
                      className="georama-SemiBold fs-14"
                      fontWeight={600}
                    >
                      {lead?.customerName}
                    </Typography>

                    <Typography
                      size="small"
                      variant="contained"
                      sx={{
                        alignSelf: "flex-start",
                        fontSize: 12,
                        color: "white",
                        borderRadius: 2,
                        padding: "3px 3px 5px 6px",
                        backgroundColor: (() => {
                          switch (lead.dispositionColor?.toLowerCase()) {
                            case "red":
                              return "#e53935";
                            case "orange":
                              return "#f07d2d";
                            case "purple":
                              return "#8e24aa";
                            case "blue":
                              return "#1e88e5";
                            case "green":
                              return "#43a047";
                            case "grey":
                              return "#9e9e9e";
                            default:
                            // fallback for existing logic
                            // return lead.status?.startsWith("Callback Scheduled")
                            //   ? "#43a047" // green
                            //   : lead.status?.startsWith("Interested")
                            //     ? "#f06292" // pink
                            //     : lead.status?.startsWith("Follow-Up")
                            //       ? "#f07d2d" // orange
                            //       : !!lead.status && lead.status !== "(0)"
                            //         ? "#1e88e5" // blue
                            //         : "transparent";
                          }
                        })(),
                        // "&:hover": {
                        //   backgroundColor: (() => {
                        //     switch (lead.statusColor?.toLowerCase()) {
                        //       case "red":
                        //         return "#e53935";
                        //       case "orange":
                        //         return "#f07d2d";
                        //       case "purple":
                        //         return "#8e24aa";
                        //       case "blue":
                        //         return "#1e88e5";
                        //       case "green":
                        //         return "#43a047";
                        //       case "grey":
                        //         return "#9e9e9e";
                        //       default:
                        //         return "transparent";
                        //     }
                        //   })(),
                        // },
                      }}
                    >
                      {lead?.status}
                    </Typography>


                    {/* <Typography
                      size="small"
                      variant="contained"
                      sx={{
                        alignSelf: "flex-start",
                        fontSize: 12,
                        color: "white",
                        borderRadius: 2,
                        padding: "2px 8px",
                        backgroundColor:
                          lead.status?.startsWith("Callback Scheduled")
                            ? greenbg
                            : lead.status?.startsWith("Interested")
                              ? pinkbg
                              : lead.status?.startsWith("Follow-Up")
                                ? orangebg
                                : !!lead.status && lead.status !== "(0)"
                                  ? bluebg
                                  : "transparent",
                        "&:hover": {
                          backgroundColor:
                            lead.status?.startsWith("Callback Scheduled")
                              ? greenbg
                              : lead.status?.startsWith("Interested")
                                ? pinkbg
                                : lead.status?.startsWith("Follow-Up")
                                  ? orangebg
                                  : !!lead.status && lead.status !== "(0)"
                                    ? bluebg
                                    : "transparent",
                        },
                      }}
                    >
                      {lead?.status}
                    </Typography> */}
                    {/* <Typography
                      size="small"
                      variant="contained"
                      sx={{
                        alignSelf: "flex-start",
                        fontSize: 12,
                        color: "white",
                        borderRadius: 2,
                        padding: "2px 8px",
                        backgroundColor: lead.status?.includes("Contacted")
                          ? "#f65d5d"
                          : "#FFA500",
                        "&:hover": {
                          backgroundColor: lead.status?.includes("Contacted")
                            ? "#f65d5d"
                            : "#e09100",
                        },
                      }}
                    >
                      {lead?.status}
                    </Typography> */}
                  </Box>
                  <Typography className="gray-color-500 georama-Regular fs-12">
                    Lead Id {lead?.leadId}
                  </Typography>
                  <Box
                    display={"flex"}
                    justifyContent={"space-between"}
                    gap={0.5}
                  >
                    <Typography className="gray-color-500 georama-Regular fs-12">
                      Policy No:
                      <br />
                      <span className="georama-Medium fs-12">
                        {lead?.policyNo}
                      </span>
                    </Typography>
                    <Typography
                      display={"flex"}
                      flexDirection={"column"}
                      alignItems={"end"}
                      className="gray-color-500 georama-Regular fs-12"
                    >
                      Vehicle details
                      <br />
                      <span className="georama-Medium fs-12">
                        {lead?.vehicleDetail}
                      </span>
                    </Typography>
                  </Box>
                </Grid>
              ))}
        </Grid>
      </Paper>
    </Grid>
  );
};

export default DashboardLayout;