import { useState } from 'react';
import { Box, Button, Popper, Typography } from '@mui/material';
import { DateRangePicker } from 'react-date-range';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import dayjs from 'dayjs';
import startOfWeek from 'date-fns/startOfWeek';
import endOfWeek from 'date-fns/endOfWeek';
import startOfMonth from 'date-fns/startOfMonth';
import endOfMonth from 'date-fns/endOfMonth';
import "./DateRangeStyles.css"
import ClickAwayListener from '@mui/material/ClickAwayListener';

const CustomDateRange = ({ open, anchorRef, setOpen, label, onChange, setDate, clearDate, minDate = null }) => {
    const createDefaultRange = () => ({
        startDate: new Date(),
        endDate: new Date(),
        key: 'selection'
    });

    const [range, setRange] = useState([
        createDefaultRange()
    ]);

    // Store the last selected range in local state
    const handleSelect = (ranges) => {
        setRange([ranges.selection]);
    };

    const handleApply = () => {
        const selectedRange = range[0];
        const formattedStart = dayjs(selectedRange.startDate).format('YYYY-MM-DD');
        const formattedEnd = dayjs(selectedRange.endDate).format('YYYY-MM-DD');
        setDate({ startDate: formattedStart, endDate: formattedEnd });
        setOpen(false); // Optionally close the popper
    };


    const handleQuickSelect = (type) => {
        const today = new Date();
        let start, end;
        let newLabel;

        switch (type) {
            case 'Today':
                start = end = today;
                break;
            case 'This Week':
                start = startOfWeek(today, { weekStartsOn: 1 });
                end = endOfWeek(today, { weekStartsOn: 1 });
                break;
            case 'This Month':
                start = startOfMonth(today);
                end = endOfMonth(today);
                break;
            case 'Reset':
                setRange([createDefaultRange()]);
                if (onChange) onChange({ startDate: "", endDate: "" }, label || 'Date Range');
                clearDate();
                setOpen(false);
                break;
            default:
                return;
        }
        setRange([{ startDate: start, endDate: end, key: 'selection' }]);
        newLabel = `${dayjs(start).format('MMM D')} - ${dayjs(end).format('MMM D')}`;
        if (onChange) onChange({ startDate: dayjs(start).format('YYYY-MM-DD'), endDate: dayjs(end).format('YYYY-MM-DD') }, newLabel);
        // handleApply();
    };

    return (
        <>
            <Popper open={open} anchorEl={anchorRef.current} placement="bottom-start" style={{ zIndex: 1300 }}>
                <ClickAwayListener onClickAway={() => setOpen(false)}>
                    <Box
                        sx={{
                            // width: 350,
                            // p: 1,
                            bgcolor: 'background.paper',
                            boxShadow: 3,
                            borderRadius: 2,
                            display: 'flex'
                        }}
                    >
                        <Box
                            sx={{
                                // minWidth: 120,
                                // gap: 1,
                                display: 'flex',
                                flexDirection: 'column',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                            }}
                        >
                            <Box sx={{
                                display: 'flex', flexDirection: 'column', my: 1, ml: 0.5
                            }}>
                                {['Today', 'This Week', 'This Month', 'Custom'].map((option) => (
                                    <Typography
                                        key={option}
                                        sx={{
                                            py: 1,
                                            px: 1,
                                            fontSize: '13px',
                                            cursor: 'pointer',
                                            color: 'text.primary',
                                            fontWeight: 500,
                                            '&:hover': { bgcolor: '#f5f5f5' }
                                        }}
                                        onClick={() => handleQuickSelect(option)}
                                    >
                                        {option}
                                    </Typography>
                                ))}
                            </Box>

                            <Typography
                                key="Reset"
                                sx={{
                                    my: 0.5,
                                    px: 1,
                                    py: 1,
                                    cursor: 'pointer',
                                    color: 'error.main',
                                    fontWeight: 500,
                                    '&:hover': { bgcolor: '#f5f5f5' }
                                }}
                                onClick={() => handleQuickSelect('Reset')}
                            >
                                Reset
                            </Typography>

                        </Box>

                        <Box display={"flex"} flexDirection="column" justifyContent="end" alignItems="end" sx={{}}>
                            <DateRangePicker minDate={minDate}
                                ranges={range}
                                onChange={handleSelect}
                                showSelectionPreview
                                moveRangeOnFirstSelection={false}
                                months={1}
                                direction="horizontal"
                                editableDateInputs
                            />
                            <Button
                                className='btn-common-red'
                                onClick={handleApply}
                                variant="contained"
                                sx={{ my: 0.5, mr: 4 }}
                            >
                                Apply
                            </Button>
                        </Box>

                    </Box>
                </ClickAwayListener>
            </Popper >
        </>
    );
};

export default CustomDateRange;
