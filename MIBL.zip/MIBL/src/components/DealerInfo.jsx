import { Box, Typography } from '@mui/material';
import React from 'react';
import { bluebg, greenbg, orangebg, pinkbg } from '../utils/Colors';

export const KeyValueItem = ({ label, value }) => (
    <Box sx={{ flex: 1 }}>
        <Typography variant="caption" color="text.secondary" display={'flex'}>
            {label}
        </Typography>
        {label !== "Status" ? <Typography variant="caption" fontWeight={500} noWrap>
            <b>{value}</b>
        </Typography> :
            <Typography variant='subtitle2'
                sx={{
                    width: 'fit-content',
                    padding: '4px 12px',
                    borderRadius: '12px',
                    fontSize: '12px',
                    fontWeight: 500,
                    color: 'white',
                    backgroundColor:
                        value?.toLowerCase() === 'customer visit planned'
                            ? greenbg
                            : value?.slice(0, 9).toLowerCase() === 'try again' && value?.length > 15
                                ? pinkbg
                                : value?.slice(0, 9).toLowerCase() === 'try again'
                                    ? orangebg : (!!value && value !== '(0)') ? bluebg : 'transparent',
                }}
            >
                {value}
            </Typography>}
    </Box>
);

export const InfoDisplay = ({ data }) => {

    const highlightStatuses = [
        "Quote Shared",
        "Insurer Selected",
        "Declaration Acknowledged",
        "CKYC Completed",
        "Proposal Confirmed",
        "Payment Completed",
        "Policy Issued",
        "Policy Booked"
    ];

    const getBgColor = (recentUpdate) => {
        if (recentUpdate?.startsWith("Callback Scheduled")) return greenbg;
        if (recentUpdate?.startsWith("Interested")) return pinkbg;
        if (recentUpdate?.startsWith("Follow-Up")) return orangebg;
        return bluebg;
    };

    // const getBgColor = (recentUpdate, status) => {
    //     if (recentUpdate?.startsWith("Callback Scheduled")) return greenbg;
    //     if (recentUpdate?.startsWith("Interested")) return pinkbg;
    //     if (recentUpdate?.startsWith("Follow-Up")) return orangebg;
    //     if (!!status && status !== "(0)") return bluebg;
    //     return "transparent";
    // };

    return (
        <Box
            sx={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: 4,
                p: 2,
                backgroundColor: 'white',
                borderRadius: 2,
            }}
        >
            <KeyValueItem label="Policy No" value={data.policyNo} />
            <KeyValueItem
                label="Insurance Company"
                value={
                    <span className="text-wrap" style={{ whiteSpace: "normal", wordBreak: "break-word" }}>
                        {data.insuranceCompany}
                    </span>
                }
            />
            <KeyValueItem label="Expiry Date" value={data.expiryDate} />
            <KeyValueItem label="Customer Type" value={data.customerType} />

            <KeyValueItem label="Recent Updates" value={data.recentUpdate.split('\n').map((line, index) => (
                <React.Fragment key={index}>
                    {line.trim()}
                    <br />
                </React.Fragment>
            ))} />
            {/* <KeyValueItem
                label="Recent Updates"
                value={data.recentUpdate
                    ?.split("\n")
                    .map((line, index) => (
                        <div key={index} className="text-wrap">
                            {line.trim()}
                        </div>
                    ))
                }
            /> */}
            {/* <KeyValueItem
                label="Recent Updates"
                value={data.recentUpdate
                    ?.split("\n")
                    .map((line, index) => {
                        const [text, date] = line.split("|");

                        return (
                            <React.Fragment key={index}>
                                <span className="text-wrap">
                                    {text?.trim()} {data.recentUpdate ? "|" : ""}
                                    {date?.trim() && (
                                        <>
                                            <br />
                                            {date.trim()}
                                        </>
                                    )}
                                </span>
                                <br />
                            </React.Fragment>
                        );
                    })}
            /> */}
            <KeyValueItems
                label="Status"
                value={data.status}
                sx={{
                    backgroundColor:
                        data.recentUpdate?.startsWith('Callback Scheduled')
                            ? greenbg
                            : data.recentUpdate?.startsWith('Interested')
                                ? pinkbg
                                : data.recentUpdate?.startsWith('Follow-Up')
                                    ? orangebg : (!!data.status && data.status !== '(0)') ? bluebg : 'transparent',
                }}
            // sx={{ backgroundColor: getBgColor(data.recentUpdate) }}
            />
            <KeyValueItems label="EBM Status" value={data.ebmStatus === "" ? "N/A" : data.ebmStatus}
                sx={{
                    padding: '4px 12px',
                    borderRadius: '12px',
                    fontWeight: 600,
                    backgroundColor: 'white',
                    color: highlightStatuses.includes(data.ebmStatus)
                        ? data.ebmStatusColor
                        : "#333",
                    // color: data.ebmStatusColor,
                    border: highlightStatuses.includes(data.ebmStatus)
                        ? `2px solid ${data.ebmStatusColor}`
                        : "1.5px solid #333",
                    // `2px solid ${data.ebmStatusColor}`,
                }} />
        </Box>
    );
};


export const KeyValueItems = ({ label, value, sx }) => (
    <Box sx={{ flex: 1 }}>
        <Typography variant="caption" color="text.secondary" display={"flex"}>
            {label}
        </Typography>

        {label !== "Status" && label !== "EBM Status" ? (
            <Typography variant="caption" fontWeight={500} noWrap>
                <b>{value}</b>
            </Typography>
        ) : (label !== "EBM Status" ?
            <Typography
                variant="subtitle2"
                sx={{
                    width: "fit-content",
                    padding: "4px 12px",
                    borderRadius: "12px",
                    fontSize: "12px",
                    fontWeight: 500,
                    color: "white",
                    ...(sx || {}), // <-- merge custom sx
                }}
            >
                {value}
            </Typography>
            : <Box component="span" className="georama-Regular fs-12 pl-2" sx={sx}>{value}</Box>
        )}
    </Box>
);
