import { Box, Typography, Paper } from '@mui/material';

export const InfoCard = ({ items }) => (
    <Paper
        elevation={0}
        sx={{
            borderRadius: 2,
            flex: 1,
            border: '1px solid #eee',
            minWidth: 300,
            boxShadow: '1px 3px 5px -3px rgba(0, 0, 0, 0.1)'
        }}
    >
        {items?.map((item, idx) => (
            <Box
                key={idx}
                display="flex"
                flexWrap={"wrap"}
                alignItems="center"
                justifyContent="space-between"
                py={1.2}
                px={1}
                borderBottom={idx !== items.length - 1 ? '1px solid #eee' : 'none'}
            >
                {/* Icon + Label grouped */}
                <Box display="flex" alignItems="center" flex={1}>
                    <Box mr={0.9} display="flex" alignItems="center">
                        {item.icon}
                    </Box>
                    <Typography
                        className='fs-11'
                        variant="caption"
                        color="text.secondary"
                        sx={{ lineHeight: 1 }}
                    >
                        {item.label}
                    </Typography>
                </Box>

                {/* Value */}
                <Typography className="fs-12 px-1" sx={{ textAlign: "right", width: item.value === "Base" ? 200 : "auto" }} pl={2} fontWeight={600}>
                    {item.value}
                    {/* {item.value === "Base" ? "hasbahsba hsbashbashabsh abshabshab shasjabsajhsa" : ""} */}
                </Typography>
            </Box>
        ))}
    </Paper >
);