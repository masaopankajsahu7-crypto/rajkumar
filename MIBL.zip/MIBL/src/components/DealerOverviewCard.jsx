import DriveEtaIcon from '@mui/icons-material/DriveEta'; // Make
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar'; // Variant
import LocalGasStationIcon from '@mui/icons-material/LocalGasStation'; // Fuel Type
import DirectionsCarFilledIcon from '@mui/icons-material/DirectionsCarFilled'; // Vehicle Class
import DirectionsCarOutlinedIcon from '@mui/icons-material/DirectionsCarOutlined'; // Model

import CreditCardIcon from '@mui/icons-material/CreditCard'; // Registration No
import BuildIcon from '@mui/icons-material/Build'; // Engine No
import Grid3x3Icon from '@mui/icons-material/Grid3x3'; // Chassis No
import EventIcon from '@mui/icons-material/Event'; // Date of Registration
import ReceiptIcon from '@mui/icons-material/Receipt'; // Date of Invoice

import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone'; // Plan Type
import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee'; // Premium
import ExtensionIcon from '@mui/icons-material/Extension'; // Addon Premium
import AutorenewIcon from '@mui/icons-material/Autorenew'; // Renewal Link (static icon)
import VisibilityIcon from '@mui/icons-material/Visibility'; // View Add on (static icon)
import SyncIcon from '@mui/icons-material/Sync'; // Value replacement icon (optional)

export const Dealer_Overview_Data = [
    [
        { icon: <DriveEtaIcon sx={{ color: 'red' }} />, label: 'Make', value: 'Mahindra' },
        { icon: <DirectionsCarIcon sx={{ color: 'red' }} />, label: 'Variant', value: 'AX5 PM AT BS6.2' },
        { icon: <LocalGasStationIcon sx={{ color: 'red' }} />, label: 'Fuel Type', value: 'PETROL' },
        { icon: <DirectionsCarFilledIcon sx={{ color: 'red' }} />, label: 'Vehicle Class', value: 'PCP' },
        { icon: <DirectionsCarOutlinedIcon sx={{ color: 'red' }} />, label: 'Model', value: 'XUV3XO' },
    ],
    [
        { icon: <CreditCardIcon sx={{ color: 'red' }} />, label: 'Registration no', value: 'HR-26-EG-1549' },
        { icon: <BuildIcon sx={{ color: 'red' }} />, label: 'Engine No', value: 'NWSZA90440' },
        { icon: <Grid3x3Icon sx={{ color: 'red' }} />, label: 'Chassis No', value: 'MA1NS2NWPS2B80180' },
        { icon: <EventIcon sx={{ color: 'red' }} />, label: 'Date of Registration', value: '24-05-219' },
        { icon: <ReceiptIcon sx={{ color: 'red' }} />, label: 'Date of Invoice', value: '24-05-219' },
    ],
    [
        { icon: <PhoneIphoneIcon sx={{ color: 'red' }} />, label: 'Plan Type', value: '1-3' },
        { icon: <CurrencyRupeeIcon sx={{ color: 'red' }} />, label: 'Premium', value: '2090' },
        { icon: <ExtensionIcon sx={{ color: 'red' }} />, label: 'Addon Premium', value: '8887' },
        { icon: <AutorenewIcon sx={{ color: 'blue' }} />, label: 'Renewal Link', value: <SyncIcon sx={{ color: 'blue' }} /> },
        { icon: <VisibilityIcon sx={{ color: 'blue' }} />, label: 'View Add on', value: <VisibilityIcon sx={{ color: 'blue' }} /> },
    ]
];
