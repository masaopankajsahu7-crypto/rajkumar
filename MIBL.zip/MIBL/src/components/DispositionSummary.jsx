import React, { useEffect, useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip as ChartTooltip, LineController, BarController, PieController, ScatterController, DoughnutController } from 'chart.js';
import { Grid, Typography, Box, Tooltip } from '@mui/material';
import infoIcon from "../assets/images/dashboard/infoIcon.svg";
import useMediaQuery from '@mui/material/useMediaQuery';

ChartJS.register(ArcElement, ChartTooltip, LineController, BarController, PieController, ScatterController, DoughnutController);

const chartOptions = {
    cutout: '50%',
    plugins: {
        tooltip: { enabled: false },
        legend: { display: false }
    },
    responsive: true,
    maintainAspectRatio: false
};

const DispositionSummary = ({ dispositiondata, subDispositiondata, conversionType }) => {
    const isDesktop = useMediaQuery('(min-width:1024px)');
    const isTab = useMediaQuery('(min-width:600px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    // const total = 1000;
    const [Converted, setConverted] = useState('Converted');
    const [filteredDispositionData, setFilteredDisposition] = useState([]);
    const [hoveredDisposition, setHoveredDisposition] = useState(null);

    useEffect(() => {
        const dispositionNames = dispositiondata?.map(item => item.disposition);
        const filtered = subDispositiondata.filter(item =>
            dispositionNames?.includes(item.disposition)
        );
        setFilteredDisposition(filtered);
    }, [dispositiondata, subDispositiondata]);


    const getSubDispositions = (disposition) => {
        return filteredDispositionData.filter(
            (item) => item.disposition === disposition
        );
    };

    const handleConversion = (val) => {
        setConverted(val)
        if (val === 'Converted') {
            conversionType("Converted");
        } else if (val === 'NonConverted') {
            conversionType("NonConverted");
        }
    }

    // Map color names to hex codes
    const colorMap = {
        "Converted/ Won": '#A56EFF',
        "Interested": '#28B463',
        "Follow-Up": '#F39C12',
        "Callback Scheduled": '#3498DB',
        "Not Eligible": '#884A39',
        "Not Interested": '#E74C3C',
        "Not Reachable": '#566573'
    };

    const ShowDisposition = () => {

    }


    const staticDispositions = [
        "Converted/ Won",
        "Follow-Up",
        "Interested",
        "Not Reachable",
        "Callback Scheduled",
        "Not Eligible",
        "Not Interested",
    ];

    const mergedData = staticDispositions.map((disp) => {
        const apiItem = dispositiondata.find((d) => d.disposition === disp);
        return {
            disposition: disp,
            count: apiItem ? apiItem.count : 0,
            percentage: apiItem ? apiItem.percentage : 0,
        };
    });

    
  

    return (
        <>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={1.3}>
                <Box display="flex" justifyContent="flex-end" alignItems="center">
                    {/* <ToggleButtonGroup exclusive size="small" value={Converted} onChange={(e, v) => handleConversion(v)}
                        className="bg-white"
                        sx={{ backgroundColor: '#f0f0f5 !important', border: '2px solid #cccccc', borderRadius: '33px !important' }}>
                        <ToggleButton className={`text-capitalize  ${isTab ? 'fs-12' : 'fs-10'}`} value="Converted" sx={{
                            px: 1.5,
                            py: 0.2,
                            mr: 0.5,
                            borderRadius: '33px !important',
                            border: '0px !important',
                            color: 'black',
                            '&.Mui-selected': {
                                backgroundColor: '#E31837 !important',
                                color: 'white',
                            }
                        }}>
                            Converted
                        </ToggleButton>

                        <ToggleButton className={`text-capitalize  ${isTab ? 'fs-12' : 'fs-10'}`} value="NonConverted" sx={{
                            px: 1.5,
                            py: 0.2,
                            borderRadius: '33px !important',
                            border: '0px !important',
                            color: 'black',
                            backgroundColor: '#f0f0f5 !important',
                            '&.Mui-selected': {
                                backgroundColor: '#E31837 !important',
                                color: 'white',
                            }
                        }}>
                            Non-Converted
                        </ToggleButton>
                    </ToggleButtonGroup> */}
                </Box>
            </Box>

            <Grid container spacing={isMobile ? 1.5 : 1.5}>
                {mergedData.map((item, index) => {
                    let colorHex = item.disposition;
                    if (colorMap[item.disposition]) {
                        colorHex = colorMap[item.disposition];
                    }

                    const data = {
                        labels: [item.disposition],
                        datasets: [
                            {
                                data: [item.percentage, 100 - Number(item.percentage)],
                                backgroundColor: [colorHex, "#E6E6E6"],
                                borderWidth: 0,
                            },
                        ],
                    };

                    const subDispositions = getSubDispositions(item.disposition);

                    return (
                        <Grid
                            key={index}
                            size={{ xs: 12, sm: 6, md: 4, lg: 3 }}
                            sx={{
                                border: "1px solid #e0e0e0",
                                borderRadius: "8px",
                                padding: isDesktop ? 1 : 0.5,
                            }}
                        >
                            <Box display="flex" alignItems={"center"}>
                                <Box sx={{ width: 48, height: 40, pl: isMobile ? 0.5 : 0 }}>
                                    <Doughnut data={data} options={chartOptions} />
                                </Box>

                                <Box sx={{ pl: isMobile ? 1 : 1 }}>
                                    <Box>
                                        <Typography
                                            variant="h6"
                                            sx={{ color: item.color, fontWeight: 600 }}
                                        >
                                            {item.count}
                                        </Typography>
                                    </Box>

                                    <Box gap={0.5} display={"flex"}>
                                        <Typography className="dark-black georama-Regular fs-12">
                                            {item.disposition}
                                        </Typography>

                                        <Tooltip
                                            arrow
                                            // placement="center"
                                            enterTouchDelay={0}
                                            leaveTouchDelay={3000}
                                            title={
                                                subDispositions?.length > 0 ? (
                                                    <Box>
                                                        {subDispositions?.map((sub, i) => (
                                                            <Box
                                                                key={i}
                                                                display="flex"
                                                                justifyContent="space-between"
                                                            >
                                                                <Typography className="fs-12 text-white">
                                                                    {sub?.sub_disposition}
                                                                </Typography>
                                                                <Typography className="fs-12 text-white" pl={2}>
                                                                    {sub?.total_count}
                                                                </Typography>
                                                            </Box>
                                                        ))}
                                                    </Box>
                                                ) : (
                                                    <Typography variant="body2">
                                                        No sub-dispositions
                                                    </Typography>
                                                )
                                            }
                                        >
                                            <img className="cursor-pointer" src={infoIcon} alt="" />
                                        </Tooltip>
                                    </Box>
                                </Box>
                            </Box>
                        </Grid>
                    );
                })}
            </Grid>
        </>
    );
};

export default DispositionSummary;