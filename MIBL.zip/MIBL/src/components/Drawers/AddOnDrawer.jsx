import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import Divider from '@mui/material/Divider';
import { Typography, IconButton, Paper } from '@mui/material';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';

const AddOnDrawer = ({ open, onClose, addonData }) => {

    return (
        <Drawer
            anchor="right"
            open={open}
            onClose={onClose}
            sx={{
                display: 'flex',
                flexDirection: 'column',
                position: "absolute",
                top: 0,
                right: 0,
                zIndex: 1300,
                borderTopLeftRadius: 16,
                borderBottomLeftRadius: 16,
                overflow: 'hidden',
            }}
        >
            {/* Header */}
            <Box className="bg-white"
                display="flex"
                alignItems="center"
                justifyContent="space-between"
                sx={{
                    position: 'sticky',
                    top: 0,
                    zIndex: 1201,
                    py: 2, px: 2,
                }}
            >
                <Box display="flex" alignItems="center">
                    {/* <img src={addonImg} alt="Add-on Icon" width={18} height={18} /> */}
                    <Typography className='georama-Medium' variant="subtitle1" sx={{ ml: 1 }}>
                        View Add On
                    </Typography>
                </Box>
                <IconButton onClick={onClose}>
                    <CloseOutlinedIcon />
                </IconButton>
            </Box>

            <Divider />

            {/* Add-on Items */}
            <Box sx={{ p: 2, overflowY: "scroll" }}>
                {addonData && addonData?.length > 0 ? (
                    addonData.map((item, idx) => (
                        <Paper
                            key={idx}
                            variant="outlined"
                            sx={{
                                width: "350px",
                                borderColor: idx === 0 ? '#ddd' : '#ddd',
                                borderWidth: idx === 0 ? 2 : 1,
                                borderStyle: 'solid',
                                borderRadius: 2,
                                p: 2,
                                mb: 2,
                            }}
                        >
                            <Box display="flex" flexWrap={"wrap"} justifyContent="space-between" alignItems="flex-start">
                                <Box>
                                    <Typography fontWeight={600}>{item?.add_on_name}</Typography>
                                    <Typography width={"260px"} variant="body2" color="textSecondary">
                                        {item?.bundle_name}
                                    </Typography>
                                </Box>
                                <Typography fontWeight={600} color="error" whiteSpace="nowrap">
                                    ₹ {item?.premium}
                                </Typography>
                            </Box>
                        </Paper>
                    ))
                ) : (
                    <Paper
                        sx={{
                            width: "350px",
                            backgroundColor: "none",
                            boxShadow: "none"
                        }}
                    >
                        <Typography className='georama-Medium'>No add-ons available.</Typography>
                    </Paper>
                )}
            </Box>
        </Drawer>
    );
}

export default AddOnDrawer