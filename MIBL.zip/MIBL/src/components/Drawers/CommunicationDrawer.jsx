import { Box, Typography, IconButton, Drawer, Paper, Divider, Stepper, Step, StepLabel, StepContent, useMediaQuery } from "@mui/material";
import CloseOutlinedIcon from "@mui/icons-material/CloseOutlined";
import { orangebg, greenbg, bluebg, pinkbg } from '../../utils/Colors';
import CustomStepIcon from "./CustomStepIcon";


const CommunicationHistoryDrawer = ({ open, onClose, communication }) => {
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    return (
        <>
            <Drawer
                anchor="right"
                open={open}
                onClose={onClose}
                PaperProps={{
                    sx: {
                        width: isMobile ? 380 : 450,
                        borderTopLeftRadius: 16,
                        borderBottomLeftRadius: 16,
                    }
                }}
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    position: "absolute",
                    top: 0,
                    right: 0,
                    zIndex: 1300,
                    borderTopLeftRadius: 16,
                    borderBottomLeftRadius: 16,
                    overflow: 'hidden',
                }}
            >
                {/* Header */}
                <Box display="flex" className="bg-white"
                    alignItems="center"
                    justifyContent="space-between"
                    sx={{
                        position: 'sticky',
                        top: 0,
                        zIndex: 1201,
                        py: 2, px: 2,
                    }}>
                    <Box display="flex" alignItems="center">
                        <Typography className='georama-Medium'>Communication History</Typography>
                    </Box>
                    <IconButton onClick={onClose}>
                        <CloseOutlinedIcon />
                    </IconButton>
                </Box>

                <Divider />

                <Box className="comm-body">
                    <Stepper className="custom-stepper" orientation="vertical" nonLinear activeStep={-1} sx={{ paddingTop: 2 }}>
                        {communication && communication.length > 0 ? (
                            communication.map((item, idx) => (
                                <Step
                                    key={idx}
                                    expanded
                                    sx={{ mx: 3 }}
                                >
                                    <StepLabel sx={{ padding: 0 }} StepIconComponent={CustomStepIcon}>
                                        <Typography fontWeight={600}>
                                            {item["call_status"]}
                                        </Typography>
                                        <Typography variant="body2">{item.first_name}</Typography>
                                    </StepLabel>
                                    <StepContent sx={{ paddingY: 1 }}>
                                        <Paper elevation={0} className="comm-card">
                                            <Typography className="comm-next-call">
                                                {item["NextCallDateTime"]}
                                            </Typography>
                                            <Typography className="comm-description">
                                                {item.remarks}
                                            </Typography>
                                            <Box component="span"
                                                sx={{
                                                    padding: '4px 12px',
                                                    borderRadius: '12px',
                                                    fontSize: '12px',
                                                    fontWeight: 500,
                                                    color: 'white',

                                                    backgroundColor:
                                                        item?.call_status?.startsWith('Callback Scheduled')
                                                            ? greenbg
                                                            : item?.call_status?.startsWith('Interested')
                                                                ? pinkbg
                                                                : item?.call_status?.startsWith('Follow-Up')
                                                                    ? orangebg : (!!item?.call_status && item?.call_status !== '(0)') ? bluebg : 'transparent',

                                                    // backgroundColor: item?.sub_disposition?.toLowerCase() === 'customer visit planned'
                                                    //     ? greenbg
                                                    //     : item?.sub_disposition?.slice(0, 9).toLowerCase() === 'try again' && item?.sub_disposition?.length > 15
                                                    //         ? pinkbg : item?.sub_disposition?.slice(0, 9).toLowerCase() === 'try again'
                                                    //             ? orangebg : !item?.sub_disposition || item?.sub_disposition === '(0)' ? 'transparent' : bluebg,
                                                }}
                                            >
                                                {item?.sub_disposition}
                                            </Box>
                                        </Paper>
                                    </StepContent>
                                </Step>
                            ))
                        ) : (
                            <Paper
                                sx={{
                                    width: "350px",
                                    backgroundColor: "none",
                                    boxShadow: "none",
                                    px: 3
                                }}
                            >
                                <Typography className='georama-Medium'>No communication history available.</Typography>
                            </Paper>
                        )}
                    </Stepper>
                </Box>
            </Drawer>
        </>
    );
};

export default CommunicationHistoryDrawer;
