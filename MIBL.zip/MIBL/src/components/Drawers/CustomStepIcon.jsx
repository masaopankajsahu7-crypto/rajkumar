// CustomStepIcon.js
import React from 'react';
import { Box } from '@mui/material';
import stepperImg from "../../assets/images/StepperImg.svg";


const CustomStepIcon = () => {
    return (
        <Box>
            <img
                src={stepperImg}
                alt="step icon"
                style={{ width: 24, height: 24 }}
            />
        </Box>
    );
};

export default CustomStepIcon;
