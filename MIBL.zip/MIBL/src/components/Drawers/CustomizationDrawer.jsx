import { Box, Typography, IconButton, Drawer, Paper, Divider, Stepper, Step, StepLabel, StepContent, useMediaQuery, Button } from "@mui/material";
import CloseOutlinedIcon from "@mui/icons-material/CloseOutlined";
import { useEffect, useState } from 'react';
import CustomizationStep from "./CustomizationStep";
import { getEBMPolicyAuthectication, getModifyQuote, getQuotationData } from "../../services/api";
import { useDispatch, useSelector } from "react-redux";
import { cursorpointer, tabselectedColor } from "../../utils/Colors";
import SendQuoteDrawer from "./SendQuoteDrawer";
import BackdropLoader from "../Loader/BackdropLoader";
import { setEbmAuthenToken } from "../../redux/slices/userSlice";

const CustomizationDrawer = ({ open, onClose, quotationData, MobileNumber, showError }) => {
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [quoteList, setQuoteList] = useState([]);
    const ebmColorList = useSelector(state => state.callQueue).ebmColorList;
    const [quoteModes, setQuoteModes] = useState([]);
    const [openSendQuoteDrawer, setOpenSendQuoteDrawer] = useState(false);
    const [loading, setLoading] = useState(false);
    const [ebmAuthToken, setEbmAuthToken] = useState("");
    const dispatch = useDispatch();
    const userData = useSelector((state) => state.user.loggedData);

    useEffect(() => {
        if (quotationData?.policyNo) fetchData();
    }, [open]);

    const fetchData = async () => {
        setLoading(true);
        try {
            const response = await getQuotationData(quotationData);
            setQuoteList(response?.result0);
        } catch (error) {
            console.error(error);
            return [];
        } finally {
            setLoading(false);
        }
    }

    const handleOpenSendQuoteDrawer = () => {
        setOpenSendQuoteDrawer(true);
    };

    const handleCloseCustDrawer = () => {
        setOpenSendQuoteDrawer(false);
    };

    const fetchModifyQuote = async () => {
        try {
            const payload = {
                "ebmUserId": "EBMtoCRM",
                "ebmPassword": "EBMtoCRMpwd2026"
            }
            const response = await getModifyQuote(payload);
            if (response) {
                const token = response.ebmAuthTokenNo;
                setEbmAuthToken(token);
                dispatch(setEbmAuthenToken(token));
                // getEBMPolicyAuth(token);
            }
        } catch (error) {
            console.error(error);
        }
    }

    const getEBMPolicyAuth = async () => {
        try {
            setLoading(true);
            const payload = {
                "auth": {
                    "ebmUserId": "EBMtoCRM",
                    "ebmPassword": "EBMtoCRMpwd2026"
                },
                // "policyAuth": {
                //     // "policyNo": quotationData?.policyNo,
                //     // "mobileNo": quotationData?.phone,
                //     // "dealerCode": userData?.dealerCode,
                //     // "proposalNo": null,
                //     "policyNo": "MIB/1275840",
                //     "mobileNo": "8087133223",
                //     "dealerCode": "string",
                //     "proposalNo": "string",
                //     "crmTransactionTokenNo": "CRM_TRN_30012026121300168",
                //     "ebmUserId": "8",
                //     "crmLeadNo": "string",
                //     "additionalParameter1": "string",
                //     "additionalParameter2": "string"
                // }
                // "policyAuth": {
                //     "policyNo": "MIB/1275840",
                //     "mobileNo": "8299407549",
                //     "dealerCode": "string",
                //     "proposalNo": "string",
                //     "crmTransactionTokenNo": "CRM_TRN_30012026121300168",
                //     "ebmUserId": "K010801KBS112",
                //     "crmLeadNo": "0176002236",
                //     "additionalParameter1": "string",
                //     "additionalParameter2": "string"
                // }
                "policyAuth": {
                    "policyNo": quotationData?.policyNo,
                    "mobileNo": quotationData?.phone,
                    "dealerCode": userData?.dealerCode,
                    "ebmUserId": quotationData?.assigned_agent_ebm_user_id ? quotationData?.assigned_agent_ebm_user_id : "",
                    "proposalNo": quotationData?.proposal_no,
                    // "crmTransactionTokenNo": "CRM_TRN_30012026121300168",
                    "crmLeadNo": "",
                    "additionalParameter1": "",
                    "additionalParameter2": ""
                }
            }

            const response = await getEBMPolicyAuthectication(payload);
            if (response?.errorMessage) {
                showError(response?.errorMessage);
            }
            if (response?.redirectionUrl) {
                window.open(response.redirectionUrl, '_blank');
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }


    return (
        <>
            <BackdropLoader loading={loading} />

            <Drawer
                anchor="right"
                open={open}
                onClose={onClose}
                PaperProps={{
                    sx: {
                        width: isMobile ? 380 : 480,
                        borderTopLeftRadius: 16,
                        borderBottomLeftRadius: 16,
                    }
                }}
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    position: "absolute",
                    top: 0,
                    right: 0,
                    zIndex: 1300,
                    borderTopLeftRadius: 16,
                    borderBottomLeftRadius: 16,
                    overflow: 'hidden',
                }}
            >
                {/* Header */}
                <Box display="flex" className="bg-white"
                    alignItems="center"
                    justifyContent="space-between"
                    sx={{
                        position: 'sticky',
                        top: 0,
                        zIndex: 1201,
                        py: 2, px: 2,
                    }}>
                    <Box display="flex" alignItems="center">
                        <Typography className='georama-Medium'>Manage Quote</Typography>
                    </Box>
                    <Box display="flex" gap={1} alignItems="center">
                        <Button
                            // disabled={quoteList?.length === 0}
                            // component="a"
                            // href={quoteList?.length > 0 ? quoteList[0]?.renewal_link_modify : ''} target='_blank'
                            variant="contained"
                            onClick={getEBMPolicyAuth}
                            sx={{
                                textTransform: 'capitalize',
                                backgroundColor: '#e53935',
                                color: '#fff',
                                borderRadius: '20px',
                                px: 2,
                                textOrientation: 'mixed',
                                fontSize: '13px',
                                fontWeight: 'bold',
                            }}
                        >
                            Modify Qoute
                        </Button>
                        <Button
                            disabled={quoteList[0]?.renewal_link_modify === null || quoteList[0]?.renewal_link_modify === undefined || quoteList[0]?.renewal_link_modify === ''}
                            onClick={handleOpenSendQuoteDrawer}
                            variant="contained"
                            sx={{
                                textTransform: 'capitalize',
                                backgroundColor: '#424242',
                                color: '#fff',
                                borderRadius: '20px',
                                px: 2,
                                textOrientation: 'mixed',
                                fontSize: '13px',
                                fontWeight: 'bold',
                            }}
                        >
                            Send Quote
                        </Button>
                        <IconButton onClick={onClose}>
                            <CloseOutlinedIcon />
                        </IconButton>
                    </Box>
                </Box>

                <Divider />

                <Box>
                    {!quoteList?.length && !loading && <Typography textAlign={"center"} ml={2} mt={5}>No Data Available</Typography>}
                </Box>

                <Box className="comm-body">
                    {quoteList?.length > 0 && !loading && <Box mx={3} my={2} display={"flex"} justifyContent="start" gap={1.5} alignItems="center" >
                        <Typography className="text-gray">
                            Renewal Link :
                        </Typography>
                        <Typography className="fs-14" fontWeight={600}>
                            <Box component="a"
                                href={quotationData?.renewal_Link}
                                target='_blank' display={"flex"} alignItems={"center"}
                                sx={quotationData?.renewal_Link ? { ...tabselectedColor, ...cursorpointer, textDecoration: 'none' } : { ...cursorpointer, textDecoration: 'none' }}>Renewal {">"}</Box>
                        </Typography>
                    </Box>}
                    <Stepper orientation="vertical" nonLinear activeStep={-1} sx={{ mt: 1 }}>
                        {quoteList?.length > 0 && quoteList.map((quote, i) =>
                            <Step
                                expanded
                                sx={{ ml: 3.7 }}
                            >
                                <StepLabel sx={{ padding: 0 }}
                                    StepIconComponent={CustomizationStep}
                                >
                                    <Typography fontWeight={600} sx={{ px: 0.5 }} className="dark-black georama-Medium fs-14 fw-500">
                                        {quote.formatted_timestamp}
                                    </Typography>
                                </StepLabel>
                                <StepContent sx={i < quoteList?.length - 1 ? { borderLeft: '1px dashed #bdbdbd', ml: 1 } : { ml: 1 }} >
                                    <Paper elevation={0} sx={{ mr: 1 }}>
                                        <Box ml={0.5} display={"flex"} justifyContent="space-between" alignItems="center" mb={2}>
                                            <Typography className="text-gray georama-Regular fs-14">
                                                Proposal Status
                                            </Typography>
                                            <Box
                                                component="span"
                                                className="georama-Regular fs-12 pl-2"
                                                sx={{
                                                    padding: '4px 12px',
                                                    borderRadius: '12px',
                                                    fontWeight: 600,
                                                    backgroundColor: 'white',
                                                    color: ebmColorList[quote.proposal_status],
                                                    border: `2px solid ${ebmColorList[quote.proposal_status]}`,
                                                }}
                                            >
                                                {quote.proposal_status}
                                            </Box>
                                        </Box>
                                        {/* <Box ml={1.5} mb={1} display={"flex"} justifyContent="space-between" alignItems="center" >
                                            <Typography className="text-gray">
                                                Renewal Link
                                            </Typography>
                                            <Typography className="fs-12" fontWeight={600}>
                                                <Box component="a" href={quote?.renewal_link_read_only} target='_blank' display={"flex"} alignItems={"center"}
                                                    sx={quote?.renewal_link_read_only ? { ...tabselectedColor, ...cursorpointer, textDecoration: 'none' } : { ...cursorpointer, textDecoration: 'none' }}>Renewal<ChevronRight /></Box>
                                            </Typography>
                                        </Box> */}
                                    </Paper>
                                </StepContent>
                            </Step>
                        )}
                    </Stepper>
                </Box>
            </Drawer>

            <SendQuoteDrawer open={openSendQuoteDrawer} onClose={handleCloseCustDrawer} quotationData={quotationData} MobileNumber={MobileNumber} />

        </>
    );
};

export default CustomizationDrawer;