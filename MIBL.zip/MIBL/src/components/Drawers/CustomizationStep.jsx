// CustomStepIcon.js
import React from 'react';
import { Box } from '@mui/material';
import stepperImg from "../../assets/images/CustomStepImg.svg";


const CustomizationStep = () => {
    return (
        <Box sx={{ borderRadius: '50%', overflow: 'hidden', width: 32, 
        height: 32, bgcolor: '#FEEFEF', display: 'flex',
         alignItems: 'center', justifyContent: 'center', ml: -1 }}>
            <img
                src={stepperImg}
                alt="step icon"
                style={{ width: 18, height: 18 }}
            />
        </Box>
    );
};

export default CustomizationStep;
