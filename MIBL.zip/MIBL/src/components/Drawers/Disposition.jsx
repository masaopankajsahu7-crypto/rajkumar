import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import { Button, Checkbox, FormControl, FormControlLabel, IconButton, MenuItem, Select, Stack, TextField, Typography } from '@mui/material';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { addMonths, format } from 'date-fns';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { getDispositionByFlag, getDispositionByInputs, saveDispostionDetails } from '../../services/api';
import BackdropLoader from '../Loader/BackdropLoader';

const Disposition = ({ open, onClose, dispositionData, MobileNumber, showMessage }) => {
    const [talked, setTalked] = useState('');
    const [dispositionFields, setDispositionFields] = useState([]);
    const [statusOptions, setStatusOptions] = useState([]);
    const [status, setStatus] = useState('');
    const [nestedStatus, setNestedStatus] = useState('');
    const [dynamicFields, setDynamicFields] = useState([]);
    const [formValues, setFormValues] = useState({});
    const [loading, setLoading] = useState(false);


    useEffect(() => {
        if (open) {
            // setTalked('');
            setStatus('');
            setNestedStatus('');
            setDynamicFields([]);
            setFormValues({});
            setDispositionFields([]);
            setStatusOptions([]);
            setNotification({
                Whatsapp: false,
                SMS: false,
                Email: false,
            });
            getDispositionDetails();
        }
    }, [open]);

    const [notification, setNotification] = useState({});
    const [notificationText, setNotificationText] = useState({ WhatsApp: '', SMS: '' });
    const userData = useSelector((state) => state.user.loggedData);

    const handleCheckboxChange = (e) => {
        setNotification((prev) => ({
            ...prev,
            [e.target.name]: e.target.checked,
        }));
    };

    useEffect(() => {
        getNotificationText();
    }, [notification, nestedStatus]);

    const getNotificationText = async () => {
        let communications = Object.entries(notification)
            .filter(([key, value]) => value === true)
            .map(([key, value]) => key);
        if (!status || !nestedStatus || communications.length === 0) {
            setNotificationText({ WhatsApp: '', SMS: '' });
            return;
        }
        let res = await getDispositionByFlag({
            customer_id: dispositionData.clusterId,
            type: 'notification', disposition: status, subdisposition: nestedStatus, communicationtype: communications.join(',')
        });
        if (res.status_code === "200") {
            let notifications = {};
            res.result0.filter(t => t.communication_type !== 'Email').forEach((t) => {
                notifications[t.communication_type] = t.template_body;
            });
            setNotificationText(notifications);
        }
    }

    useEffect(() => {
        if (formValues["Sub Disposition"]) {
            fetchNotificationData();
        }
    }, [formValues["Sub Disposition"]]);

    const fetchNotificationData = async () => {
        try {
            const response = await getDispositionByFlag(
                {
                    type: 'notification',
                    disposition: status,
                    subdisposition: nestedStatus,
                    fetchcommunicationtype: "Yes",
                    customer_id: dispositionData.clusterId,
                    dealerCode: userData.dealerCode,
                    parentCode: userData.parentCode,
                });
            if (response?.status_code === "200" || response?.status_message === "Fetched successfully") {
                let communicationList = response?.result0;

                let communications = {};
                if (Array.isArray(communicationList) && communicationList.length > 0) {
                    communicationList
                        .filter(c => c?.communication)
                        .forEach(c => {
                            communications[c.communication] = false;
                        });
                }

                setNotification(communications);
            }
        } catch (error) {
            console.error('Error posting data:', error);
        }
    };

    const handleNestedChange = async (event) => {
        const selected = event.target.value;
        setFormValues((prev) => ({
            ...prev,
            ['Sub Disposition']: selected,
        }));
        setNestedStatus(selected);
    }

    const handleStatusChange = async (event) => {
        const selected = event.target.value;
        setStatus(selected);

        try {
            const response = await getDispositionByInputs({ options_input: selected });
            if (response.status_code === "200" || response.status_message === "Fetched successfully") {
                setDynamicFields(response.result0);
                setFormValues({});
            }
        } catch (err) {
            console.error("Error hitting status change API", err);
        }
    };

    const getDispositionDetails = async () => {
        try {
            const response = await getDispositionByFlag({ type: 'init', dealerCode: userData.dealerCode, parentCode: userData.parentCode });
            if (response.status_code === "200" || response.status_message === "Fetched successfully") {
                const dropdownField = response.result0;
                if (dropdownField) {
                    const optionsArray = dropdownField.map(opt => ({
                        value: opt.disposition.trim(),
                        label: opt.disposition.trim(),
                        dispositionStatus: opt.dispositionStatus.trim()
                    }));
                    setStatusOptions(optionsArray);
                    setDispositionFields(response.result0);
                }
                let communicationList = response?.result1[0]?.communication.split(',');
                let communications = {};
                if (communicationList?.length > 0) communicationList.filter(c => !!c).forEach(c => communications[c] = false);
                setNotification(communications);
            }
        } catch (error) {
            console.error('Error posting data:', error);
        }
    };
    // useEffect(() => {
    //     if (talked) {
    //         getDispositionDetails();
    //     }
    // }, [talked]);

    const saveDispostion = async () => {
        if (!status) {
            showMessage(`Please Select Status`, "error");
            return;
        }
        let errorFields = dynamicFields.filter(field => !formValues[field.field_label]);
        if (errorFields.length > 0) {
            showMessage(`Please fill ${errorFields.map(f => f.field_label).join(', ')}`, "error");
            return;
        }
        if (!(formValues["Remarks"]?.length > 1)) {
            showMessage(`Remarks must be at least 2 characters long`, "error");
            return;
        }

        const fieldDetails = dynamicFields
            .filter(field => formValues[field.field_label]?.trim() !== "") // only include if value exists
            .map(field => ({
                configId: field.mast_config_id,
                fieldLabel: field.field_label,
                fieldType: field.field_type,
                fieldValue: formValues[field.field_label]
            }));

        const nextCall = fieldDetails.find(field => field.fieldType === 'datetime')?.fieldValue;

        if (nextCall) {
            const selectedTime = new Date(nextCall);
            const currentTime = new Date();

            const diffInMs = selectedTime - currentTime;
            const diffInMinutes = diffInMs / (1000 * 60);

            if (diffInMinutes < 2) {
                showMessage("Next call time must be at least 2 minutes in the future", "error");
                return;
            }
        }

        let communications = Object.entries(notification)
            .filter(([key, value]) => value === true)
            .map(([key, value]) => key);

        const disposition = {
            // "communicationtype":"Whatsapp",
            "communicationtype": communications.join(","),
            "email": dispositionData?.email,
            "type": "sendnotification",
            "MobileNumber": MobileNumber,
            "customer_id": dispositionData.clusterId,
            "lead_id": Number(dispositionData.leadId),
            "user_id": userData.user_id,
            "dealer_code": userData.dealerCode,
            "call_status": status,
            "next_call_datetime": fieldDetails.find(field => field.fieldType === 'datetime')?.fieldValue,
            "remarks": formValues["Remarks"],
            "fieldDetails": fieldDetails,
            "dispositionStatus": statusOptions.find(d => d.label.trim() === status).dispositionStatus
            // "": nestedStatus,
        }
        let response;
        try {
            setLoading(true);
            response = await saveDispostionDetails(disposition);
            if (response.status_code === "200" || response.status_message === "Disposition Saved") {
                showMessage(response.status_message, "success");
                onClose();
            }
            else if (response.status_code === "300" || response.status_message === "Something Went Wrong") {
                showMessage(response.status_message, "error");
                onClose();
            }
            else {
                showMessage(response.status_message, "error");
                onClose();
            }
        } catch (error) {
            showMessage(response.status_message, "error");
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <BackdropLoader loading={loading} />
            <Drawer
                className='disposition-inputs'
                anchor="right"
                open={open}
                onClose={onClose}
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    position: "absolute",
                    top: 0,
                    right: 0,
                    zIndex: 1300,
                    borderTopLeftRadius: 16,
                    borderBottomLeftRadius: 16,
                    overflow: 'hidden',
                }}
            >
                <Box className="drawer-body">
                    <Box className="bg-white"
                        display="flex"
                        alignItems="center"
                        justifyContent="space-between"
                        sx={{
                            width: "350px",
                            position: 'sticky',
                            top: 0,
                            zIndex: 1201,
                            py: 0.7, px: 2,
                        }}
                    >
                        <Box display="flex" alignItems="center">
                            <Typography className='georama-Medium' sx={{ pl: 1 }}>
                                Disposition
                            </Typography>
                        </Box>

                        <IconButton onClick={onClose}>
                            <CloseOutlinedIcon />
                        </IconButton>
                    </Box>
                    <Divider />
                    <Box className="form-container" >
                        {/* <FormControl component="fieldset" className="form-group">
                            <Typography component="legend">Did you talk to Customer</Typography>
                            <RadioGroup
                                row
                                value={talked}
                                onChange={(e) => setTalked(e.target.value)}
                            >
                                <FormControlLabel value="yes" control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />} label="Yes" />
                                <FormControlLabel value="no" control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />} label="No" />
                            </RadioGroup>
                        </FormControl> */}



                        {dispositionFields &&
                            <FormControl fullWidth sx={{ mb: 2 }}>
                                <Typography className='text-labels' component="legend">What did Customer say?</Typography>

                                <Select
                                    fullWidth
                                    className='form-control-input'
                                    value={status}
                                    onChange={handleStatusChange}
                                    displayEmpty
                                >
                                    <MenuItem value="" disabled>Select Status</MenuItem>

                                    {statusOptions.map((option) => (
                                        <MenuItem key={option.value} value={option.value}>
                                            {option.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        }

                        {dynamicFields && dynamicFields.map((field, index) => {
                            let minDate = new Date();
                            let maxDate = addMonths(new Date(), 3);

                            if (field.field_type === "datetime") {
                                return (
                                    <Box key={index} my={2}>
                                        <Typography className='text-labels' fontWeight={500}>
                                            {field.field_label}
                                        </Typography>

                                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                                            {/* <DateTimePicker
                                                ampm={false}
                                                value={formValues[field.field_label] ? new Date(formValues[field.field_label]) : null}
                                                onChange={(newValue) => {
                                                    if (!newValue) return;
                                                    let validDate = newValue < minDate ? minDate : newValue > maxDate ? maxDate : newValue;
                                                    setFormValues((prev) => ({
                                                        ...prev,
                                                        [field.field_label]: format(validDate, "yyyy-MM-dd HH:mm:ss"),
                                                    }));
                                                }}
                                                minDateTime={minDate}
                                                maxDateTime={maxDate}
                                                format="dd/MM/yyyy HH:mm"
                                                slotProps={{
                                                    textField: {
                                                        fullWidth: true,
                                                        className: 'form-control-input',
                                                        size: 'small'
                                                    }
                                                }}
                                            /> */}
                                            <DateTimePicker
                                                ampm={false}
                                                value={
                                                    formValues[field.field_label]
                                                        ? new Date(formValues[field.field_label])
                                                        : null
                                                }
                                                onChange={(newValue) => {
                                                    if (!newValue) return;

                                                    // ✅ Convert to JS Date safely
                                                    const dateObj =
                                                        newValue instanceof Date
                                                            ? newValue
                                                            : new Date(newValue?.$d || newValue);

                                                    if (isNaN(dateObj)) {
                                                        console.warn("Invalid date received:", newValue);
                                                        return;
                                                    }

                                                    const validDate =
                                                        dateObj < minDate
                                                            ? minDate
                                                            : dateObj > maxDate
                                                                ? maxDate
                                                                : dateObj;

                                                    setFormValues((prev) => ({
                                                        ...prev,
                                                        [field.field_label]: format(validDate, "yyyy-MM-dd HH:mm:ss"),
                                                    }));
                                                }}
                                                minDateTime={minDate}
                                                maxDateTime={maxDate}
                                                format="dd/MM/yyyy HH:mm"
                                                slotProps={{
                                                    textField: {
                                                        fullWidth: true,
                                                        className: "form-control-input",
                                                        size: "small",
                                                    },
                                                }}
                                            />

                                        </LocalizationProvider>
                                    </Box>
                                );
                            }

                            if (field.field_type === "dropdown") {
                                const dropdownOptions = field.options
                                    ? field.options.split(',').map(opt => opt.trim())
                                    : [];

                                return (
                                    <>
                                        <Typography className='text-labels'> {field.field_label}</Typography>

                                        <FormControl fullWidth key={index} sx={{ mb: 2 }}>
                                            <Select className='form-control-input'
                                                value={nestedStatus}
                                                onChange={handleNestedChange}
                                                displayEmpty
                                            >
                                                <MenuItem value="" disabled>Select </MenuItem>

                                                {dropdownOptions.map((option, i) => (
                                                    <MenuItem key={i} value={option}>
                                                        {option}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    </>
                                );
                            }

                            // Amount
                            if (field.field_type === "number") {
                                return (
                                    <Box key={index} my={2}>
                                        <Typography className='text-labels' fontWeight={500}>{field.field_label}</Typography>

                                        <TextField className='form-control-input'
                                            fullWidth
                                            type="number"
                                            placeholder='Rs.'
                                            value={formValues[field.field_label] || ""}
                                            onChange={(e) => {
                                                setFormValues((prev) => ({
                                                    ...prev,
                                                    [field.field_label]: e.target.value,
                                                }));
                                            }}
                                            inputProps={{
                                                inputMode: 'numeric',
                                                pattern: '[0-9]*',
                                                min: 0
                                            }}
                                        />
                                    </Box>
                                );
                            }

                            // collected By 
                            if (field.field_type === "text") {
                                return (
                                    <Box key={index} my={2}>
                                        <Typography className='text-labels' fontWeight={500}>{field.field_label}</Typography>

                                        <TextField className='form-control-input'
                                            fullWidth
                                            value={formValues[field.field_label] || ""}
                                            onChange={(e) => {
                                                setFormValues((prev) => ({
                                                    ...prev,
                                                    [field.field_label]: e.target.value,
                                                }));
                                            }}
                                        />
                                    </Box>
                                );
                            }

                            // Remark
                            if (field.field_type === "textarea") {
                                return (
                                    <Box fullWidth key={index} my={2}>
                                        <Typography className='text-labels' fontWeight={500}>{field.field_label}</Typography>

                                        <TextField className='form-control-input'
                                            fullWidth multiline minRows={2} maxRows={3}
                                            value={formValues[field.field_label] || ""}
                                            onChange={(e) => {
                                                setFormValues((prev) => ({
                                                    ...prev,
                                                    [field.field_label]: e.target.value.trimStart().replace(/[^a-zA-Z0-9,.\s]/g, '').replace(/\s+/g, ' ').slice(0, 200),
                                                }));
                                            }}
                                        />
                                    </Box>
                                );
                            }
                            return null;
                        })}


                        {formValues["Sub Disposition"] && dynamicFields.length > 0 && Object.keys(notification)?.length > 0 && <>
                            <Typography className="form-label">Send Notification</Typography>

                            <Stack display={"flex"} direction={"row"} gap={2} flexWrap={"wrap"} >
                                {Object.keys(notification)?.length > 0 && Object.keys(notification).map((label) => (
                                    <Box display={"flex"} key={label} className="communication-box" px={0}>
                                        <FormControlLabel
                                            label={label}
                                            className="communication-label fs-10"
                                            control={
                                                <Checkbox
                                                    name={label}
                                                    className="communication-checkbox"
                                                    value={label}
                                                    checked={notification[label]}
                                                    onChange={handleCheckboxChange}
                                                />
                                            }
                                        />
                                    </Box>
                                ))}
                            </Stack>

                            {/* <Box className="notification-checkboxes">
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            checked={notification.WhatsApp}
                                            onChange={handleCheckboxChange}
                                            name="whatsapp"
                                            sx={{ "&.Mui-checked": { color: "#e53935" } }}
                                        />
                                    }
                                    label="WhatsApp"
                                />
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            checked={notification.SMS}
                                            onChange={handleCheckboxChange}
                                            name="sms"
                                            sx={{ "&.Mui-checked": { color: "#e53935" } }}
                                        />
                                    }
                                    label="SMS"
                                />
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            checked={notification.Email}
                                            onChange={handleCheckboxChange}
                                            name="email"
                                            sx={{ "&.Mui-checked": { color: "#e53935" } }}
                                        />
                                    }
                                    label="Email"
                                />
                            </Box> */}
                        </>
                        }

                        {
                            Object.values(notificationText).join('') &&
                            Object.keys(notificationText).map((nt) => (
                                notificationText[nt] &&
                                <Box key={nt} my={2}>
                                    <Typography className='text-labels' fontWeight={500}>{nt}</Typography>

                                    <TextField className='disabled-input cursor-nodrop' disabled
                                        fullWidth multiline minRows={2} maxRows={3}
                                        value={notificationText[nt]}
                                    />
                                </Box>
                            ))
                        }

                        {/* Show date & time field for callLater and converted */}

                        {/* {(status === 'callLater' || status === 'converted') && (
                        <Box my={2}>
                            <Typography fontWeight={500} >
                                Next Call Date & Time
                            </Typography>
                            <TextField
                                fullWidth
                                type="datetime-local"
                                InputLabelProps={{ shrink: true }}
                            />
                        </Box>
                    )}
                    <Box my={2}>
                        <Typography fontWeight={500}>
                            Remarks
                        </Typography>
                        <TextField
                            fullWidth
                            multiline
                            minRows={2}
                        />
                    </Box> */}


                    </Box>
                </Box>
                <Box className="drawer-footer">
                    <Button sx={{ px: '45px !important' }} disabled={loading} onClick={saveDispostion} type="submit" className="btn-common-red">
                        Submit
                    </Button>
                    <Button sx={{ px: '45px !important' }} onClick={onClose} type="button" className="btn-assign assign-txt">
                        Close
                    </Button>
                </Box>
            </Drawer >
        </>

    );
}

export default Disposition