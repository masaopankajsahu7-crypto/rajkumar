import React, { useEffect, useState } from 'react'
import { Box, Typography, IconButton, Drawer, Paper, Divider, Stepper, Step, StepLabel, StepContent, useMediaQuery, Button } from "@mui/material";
import BackdropLoader from '../Loader/BackdropLoader';
import { useSelector } from 'react-redux';
import { getSendQuote, sendQuotePreview, submitSendQuote } from '../../services/api';
import { FormControl, FormControlLabel, Select, MenuItem, TextField, Checkbox, Stack } from '@mui/material';
import CloseOutlinedIcon from "@mui/icons-material/CloseOutlined";
import { ToastContainer, toast } from 'react-toastify';

const SendQuoteDrawer = ({ open, onClose, quotationData, MobileNumber }) => {
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [loading, setLoading] = useState(false);
    const [formValues, setFormValues] = useState({});
    const userData = useSelector((state) => state.user.loggedData);
    const [notification, setNotification] = useState([]);
    const [templatesPreview, setTemplatesPreview] = useState([]);
    const [selectedNotifications, setSelectedNotifications] = useState([]);
    const [notificationText, setNotificationText] = useState({});

    const fetchQuotationData = async () => {
        try {
            const response = await getSendQuote({
                "cluster_id": quotationData?.clusterId,
                "lead_id": quotationData?.leadId,
                "dealer_id": userData?.dealerCode,
                "ebm_status": quotationData?.ebmStatus
            });
            if (response.status_code === "200" || response.status_message === "Fetched user communication modes successfully") {
                setNotification(response.result0);
            }
        } catch (error) {
            console.error("Error fetching quotation data:", error);
        }
    }

    useEffect(() => {
    }, [open]);

    useEffect(() => {
        if (open) {
            setNotification([]);
            setTemplatesPreview([]);
            setSelectedNotifications([]);
            fetchQuotationData();
        }
    }, [open]);


    const fetchTemplatePreview = async (communicationModes) => {
        try {
            const payload = {
                customer_id: quotationData?.clusterId,
                communicationtype: communicationModes.join(","),
            };

            const response = await sendQuotePreview(payload);

            if (response?.status_code === "200") {
                const templates = response?.result0 || [];

                const formatted = templates.reduce((acc, item) => {
                    acc[item.communication_type] = item.template_body;
                    return acc;
                }, {});

                setNotificationText(formatted);
            }
        } catch (error) {
            console.error(error);
        }
    };

    useEffect(() => {
        if (selectedNotifications.length > 0) {
            fetchTemplatePreview(selectedNotifications);
        } else {
            setNotificationText({});
        }
    }, [selectedNotifications]);



    const handleCheckboxChange = (event) => {
        const { value, checked } = event.target;

        setSelectedNotifications((prev) =>
            checked
                ? [...prev, value]
                : prev.filter((item) => item !== value)
        );
    };


    const handleSubmit = async () => {
        if (selectedNotifications.length > 0) {
            try {
                setLoading(true);
                const response = await submitSendQuote(
                    // {
                    //     "customer_id": quotationData?.clusterId,
                    //     "ebm_status": quotationData?.ebmStatus,
                    //     "communicationtype": selectedNotifications.join(","),
                    //     "MobileNumber": quotationData?.phone,
                    //     "email": quotationData?.email
                    // }
                    {
                        "customer_id": quotationData?.clusterId,
                        "ebm_status": quotationData?.ebmStatus,
                        "communicationtype": selectedNotifications.join(","),
                        "MobileNumber": MobileNumber,
                        "email": quotationData?.email
                    }
                );
                if (response?.status_message === "Communication sent successfully" || response?.status_code === "200") {
                    toast.success("Quote sent successfully!");
                    onClose();
                }
            } catch (error) {
                console.error("Error submitting send quote:", error);
            } finally {
                setLoading(false);
            }
        }
    }

    return (
        <>
            <BackdropLoader loading={loading} />
            <Drawer
                anchor="right"
                open={open}
                onClose={onClose}
                PaperProps={{
                    sx: {
                        width: isMobile ? 380 : 480,
                        borderTopLeftRadius: 16,
                        borderBottomLeftRadius: 16,
                    }
                }}
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    position: "absolute",
                    top: 0,
                    right: 0,
                    zIndex: 1300,
                    borderTopLeftRadius: 16,
                    borderBottomLeftRadius: 16,
                    overflow: 'hidden',
                }}
            >
                <Box>
                    <Box className="drawer-body">
                        {/* Header */}
                        <Box px={2} display="flex" className="bg-white"
                            alignItems="center"
                            justifyContent="space-between"
                            sx={{
                                position: 'sticky',
                                top: 0,
                                zIndex: 1201,
                                py: 1, px: 2,
                            }}>
                            <Box display="flex" alignItems="center">
                                <Typography className='georama-Medium'>Send Quote</Typography>
                            </Box>
                            <IconButton onClick={onClose}>
                                <CloseOutlinedIcon />
                            </IconButton>
                        </Box>

                        <Divider />

                        {Object.keys(notification)?.length > 0 ? <>
                            <Stack direction="row" gap={2} py={2} px={2}>
                                {notification
                                    ?.filter(item => item.communication_mode) // remove nulls
                                    ?.map((item) => (
                                        <Box
                                            key={item.communication_mode}
                                            className="communication-box"
                                            px={0}
                                        >
                                            <FormControlLabel
                                                label={item.communication_mode}
                                                className="communication-label fs-10"
                                                control={
                                                    <Checkbox
                                                        value={item.communication_mode}
                                                        checked={selectedNotifications.includes(item.communication_mode)}
                                                        onChange={handleCheckboxChange}
                                                        className="communication-checkbox"
                                                    />
                                                }
                                            />
                                        </Box>
                                    ))}
                            </Stack>
                        </> : (!loading && Object.keys(notification)?.length < 0 &&
                            <Typography textAlign={"center"} m={2}>
                                No Data Found
                            </Typography>)
                        }

                        {
                            Object.values(notificationText).join('') &&
                            Object.keys(notificationText).map((nt) => (
                                notificationText[nt] &&
                                <Box key={nt} my={2} px={2} className>
                                    <Typography className='text-labels' fontWeight={500}>{nt}</Typography>

                                    <TextField
                                        className='disabled-input cursor-nodrop'
                                        disabled
                                        fullWidth
                                        multiline
                                        minRows={2}
                                        maxRows={3}
                                        value={notificationText[nt]}
                                    />
                                </Box>
                            ))
                        }
                    </Box>
                </Box>
                <Box sx={{ width: '100%', position: 'absolute', bottom: 10 }}>
                    <Box className="drawer-footer">
                        <Button sx={{ mx: 1, width: '100% !important' }} onClick={onClose} type="button" className="btn-assign assign-txt">
                            Close
                        </Button>
                        <Button sx={{ mx: 1, width: '100% !important' }} onClick={handleSubmit} disabled={!selectedNotifications.length} type="submit" className="btn-common-red">
                            Submit
                        </Button>
                    </Box>
                </Box>
            </Drawer >

            <ToastContainer autoClose={1000} />
        </>
    )
}

export default SendQuoteDrawer