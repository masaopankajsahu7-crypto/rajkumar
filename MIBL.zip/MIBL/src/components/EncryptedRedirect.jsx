// src/components/EncryptedRedirect.jsx
import { lazy } from 'react';
import { Navigate, useParams } from 'react-router-dom';
import { decryptRoute } from '../services/encrypt';
import AppLayout from './AppLayout';
import ProtectedRoute from './ProtectedRoute';
import { useAuth } from '../services/useAuth';

const MISPsetup = lazy(() => import('../pages/Setup'));
const MISPOutlet = lazy(() => import('../pages/MISPOutlet'));
const CallQueue = lazy(() => import('../pages/CallQueue'));
const CustomerDetailsPage = lazy(() => import('../pages/DealerDetail360'));
const UserProfile = lazy(() => import('../pages/UserProfile'));
const ManagerDashboard = lazy(() => import('../pages/ManagerDashboard'));
const EditMISPOutlet = lazy(() => import('../pages/EditMISPOutlet'));
const LeadPoolList = lazy(() => import('../pages/LeadpoolList'));
const LeadPoolForm = lazy(() => import('../pages/NewLeadpool'));
const UserTable = lazy(() => import('../pages/UserManagement'));
const CreateUser = lazy(() => import('../pages/CreateUser'));
const RoleList = lazy(() => import('../pages/RoleList'));
const CreateRole = lazy(() => import('../pages/CreateRole'));
const AssignReassignLeads = lazy(() => import('../pages/AssignReassignLeads'));
const CustomerSearch = lazy(() => import('../pages/CustomerSearch'));
const DataUpload = lazy(() => import('../pages/DataUpload'));
const Forgot = lazy(() => import('../pages/ForgotPassword'));
const AdminDashboard = lazy(() => import('../pages/AdminDashboard'));
const SystemConfiguration = lazy(() => import('../pages/SystemConfiguration'));
const RenewalDashboard = lazy(() => import('../pages/RenewalDashboard'));
const FAQ = lazy(() => import('../pages/Faq'));
const CreateDealer = lazy(() => import('../pages/CreateDealer'));
const TATMonitoring = lazy(() => import('../pages/TATMonitoring'));
const AgentTATPerformance = lazy(() => import('../pages/AgentTATPerformance'));
const TeamLeadsTATPerformance = lazy(() => import('../pages/TeamLeadsTATPerformance'));
const LeaderBoard = lazy(() => import('../pages/LeaderBoard'));
const PerformanceDashboard = lazy(() => import('../pages/PerformanceDashboard'));
const LeadMovementReport = lazy(() => import('../pages/AdminDashboard/LeadMovementReport'));
const Target = lazy(() => import('../pages/Target'));
const ViewCharts = lazy(() => import('../pages/ViewCharts'));
const ClientApp = lazy(() => import('../clientApp/ClientApp.jsx'));
const RfqDashboard = lazy(() => import('../clientApp/pages/Dashboard.jsx'));
const Clients = lazy(() => import('../clientApp/pages/Clients.jsx'));
const ClientsCreate = lazy(() => import('../clientApp/pages/ClientsCreate.jsx'));
const PortfolioForm = lazy(() => import('../clientApp/pages/PortfolioForm.jsx'));
const ClientDetail = lazy(() => import('../clientApp/pages/ClientDetail.jsx'));
const Opportunities = lazy(() => import('../clientApp/pages/Opportunities.jsx'));
const Portfolios = lazy(() => import('../clientApp/pages/Portfolios.jsx'));
const Renewals = lazy(() => import('../clientApp/pages/Renewals.jsx'));
const Activities = lazy(() => import('../clientApp/pages/Activities.jsx'));
const CRM = lazy(() => import('../clientApp/pages/CRM.jsx'));
const CRMConvert = lazy(() => import('../clientApp/pages/CRMConvert.jsx'));
const ActivityForm = lazy(() => import('../clientApp/pages/ActivityForm.jsx'));
const RenewalConvert = lazy(() => import('../clientApp/pages/RenewalConvert.jsx'));
const OpportunityCreate = lazy(() => import('../clientApp/pages/OpportunityCreate.jsx'));
const OpportunityWorkflow = lazy(() => import('../clientApp/pages/OpportunityWorkflow.jsx'));
const KpiDashboard = lazy(() => import('../clientApp/pages/KpiDashboard.jsx'));
const ClientPerformanceDashboard = lazy(() => import('../clientApp/pages/PerformanceDashboard.jsx'));
const CorporateReports = lazy(() => import('../clientApp/pages/Reports.jsx'));
const AesJsonCipher = lazy(() => import('../clientApp/pages/AesJsonCipher.jsx'));

const getClientAppElement = (path) => {
    if (path === '/dashboard') return <RfqDashboard />;
    if (path === '/clients') return <Clients />;
    if (path === '/clients/create') return <ClientsCreate />;
    if (path === '/clients/create/portfolio') return <PortfolioForm />;
    if (/^\/clients\/edit\/[^/]+$/.test(path)) return <ClientsCreate />;
    if (/^\/clients\/[^/]+$/.test(path)) return <ClientDetail />;
    if (path === '/opportunities') return <Opportunities />;
    if (path === '/opportunities/create') return <OpportunityCreate />;
    if (/^\/opportunities\/[^/]+\/portfolio\/contacts$/.test(path)) return <PortfolioForm />;
    if (/^\/opportunities\/[^/]+$/.test(path)) return <OpportunityWorkflow />;
    if (path === '/portfolios') return <Portfolios />;
    if (path === '/renewals') return <Renewals />;
    if (path === '/activities') return <Activities />;
    if (path === '/crm') return <CRM />;
    if (/^\/crm\/convert\/[^/]+$/.test(path)) return <CRMConvert />;
    if (path === '/activities/create') return <ActivityForm mode="create" />;
    const activityEditMatch = path.match(/^\/activities\/edit\/([^/]+)$/);
    if (activityEditMatch) {
        return <ActivityForm mode="update" activity_uuid={decodeURIComponent(activityEditMatch[1])} />;
    }
    if (/^\/renewals\/convert\/[^/]+$/.test(path)) return <RenewalConvert />;
    if (path === '/kpi-dashboard') return <KpiDashboard />;
    if (path === '/performance-dashboard') return <ClientPerformanceDashboard />;
    if (path === '/aes-json-cipher') return <AesJsonCipher />;
    if (path === '/reports') return <CorporateReports />;
    return null;
};

const EncryptedRedirect = () => {
    const { encrypted } = useParams();
    const isAuthenticated = useAuth().isLoggedIn;

    let decryptedPath = '';
    try {
        decryptedPath = decryptRoute(decodeURIComponent(encrypted));
    } catch (err) {
        console.error('Failed to decrypt route:', err);
        return <div>Invalid encrypted route</div>;
    }

    const clientAppElement = getClientAppElement(decryptedPath);

    const routeMap = {
        '/faq': <FAQ />,
        '/forgot': <Forgot />,
        '/profile': <UserProfile />,
        '/managerdashboard': <ManagerDashboard />,
        '/admindashboard': <AdminDashboard />,
        '/admindashboard/viewAll': <LeadMovementReport />,
        '/renewalDashboard': <RenewalDashboard />,

        // Setup
        '/mispoutlet': <MISPOutlet />,
        '/editmispoutlet': <EditMISPOutlet />,
        '/mispoutlet/create': <MISPsetup />,
        '/editmispoutlet/edit': <MISPsetup />,
        '/editmispoutlet/create': <CreateDealer />,

        // Lead Pool
        '/leadpool': <LeadPoolList />,
        '/leadpool/create': <LeadPoolForm />,
        '/leadpool/edit': <LeadPoolForm />,
        '/leadpool/view': <LeadPoolForm />,

        // Users
        '/userManagement': <UserTable />,
        '/userManagement/create': <CreateUser />,
        '/userManagement/edit': <CreateUser />,

        // Roles
        '/role': <RoleList />,
        '/role/create': <CreateRole />,
        '/role/edit': <CreateRole />,

        // Other Pages
        '/callqueue': <CallQueue />,
        '/callqueue/customerdetails': <CustomerDetailsPage />,
        '/assignLeads': <AssignReassignLeads />,
        '/customerSearch': <CustomerSearch />,
        '/dataupload': <DataUpload />,
        '/systemconfiguration': <SystemConfiguration />,
        '/tatMonitoring': <TATMonitoring />,
        '/tatMonitoring/tatviewAll': <AgentTATPerformance />,
        '/tatMonitoring/teamleadviewAll': <TeamLeadsTATPerformance />,
        '/leaderBoard': <LeaderBoard />,
        '/performanceDashboard': <PerformanceDashboard />,
        '/target': <Target />,
        '/viewCharts': <ViewCharts />
    };

    const ComponentToRender = routeMap[decryptedPath];

    if (!ComponentToRender && !clientAppElement) {
        return <div>404 - Page not found</div>;
    }

    if (decryptedPath === '/forgot' || encrypted === '/forgot') {
        return <Forgot />;
    }

    return (
        <ProtectedRoute isAuthenticated={isAuthenticated}>
            <AppLayout>
                {clientAppElement ? <ClientApp>{clientAppElement}</ClientApp> : ComponentToRender}
            </AppLayout>
        </ProtectedRoute>
    );
};

export default EncryptedRedirect;
