// FunnelChartComponent.jsx
import { useMediaQuery } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import funnel from 'highcharts/modules/funnel';

// Initialize funnel module
if (typeof funnel === 'function') {
    funnel(Highcharts);
}

export default function FunnelChartComponent({ leadConversion }) {
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    const colorMap = {
        'Total Leads': '#FF3D3D',
        'Contacted': '#FF9F40',
        'Quote Shared': '#18B86A',
        'Converted': '#2196F3',
    };

    const order = ['Total Leads', 'Contacted', 'Quote Shared', 'Converted'];

    const funnelData = order
        .map(status => leadConversion && leadConversion.find(item => item.leadStatus === status))
        .filter(Boolean)
        .map(item => ({
            name: item.leadStatus,
            y: 1,
            count: Number(item.count),
            color: colorMap[item.leadStatus] || '#2196F3',
            customPercentage: Number(item.percentage).toFixed(2)
        }));

    const chartOptions = {
        chart: {
            type: 'funnel',
            height: 320,
            inverted: false,
            spacingTop: 38,
            spacingBottom: 0
        },
        title: { text: null },
        credits: { enabled: false },
        legend: {
            enabled: true,
            align: 'center',
            verticalAlign: 'bottom',
            layout: 'horizontal',
            itemStyle: {
                fontWeight: '500',
                fontSize: isMobile ? '10px' : '12px'
            },
            symbolRadius: 6,
            symbolHeight: 9,
            symbolWidth: 6,
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    useHTML: true,
                    align: 'center',
                    verticalAlign: 'middle',
                    allowOverlap: true,
                    y: 1,
                    formatter: function () {
                        return `
                        <div style="text-align:center;">
                            <div style="font-size:13px;font-weight:700;color:#fff;">${this.point.count}</div>
                            <div style="font-size:12px;color:#fff;">(${this.point.customPercentage}%)</div>
                        </div>`;
                    },
                    color: 'white',
                    inside: true,
                },
                colors: ['#FF3D3D', '#FF9F40', '#18B86A', '#2196F3'],
                center: ['50%', '45%'],
                neckWidth: isMobile ? '28%' : '25%',
                neckHeight: isMobile ? '25%' : '25%',
                width: isMobile ? '80%' : '65%',
                borderRadius: 12,
                borderWidth: 0
            }
        },
        tooltip: {
            useHTML: true,
            formatter: function () {
                return `
                    <b>${this.point.name}</b><br/>
                    Count: ${this.point.count}<br/>
                    Percentage: ${this.point.customPercentage}%
                `;
            }
        },
        series: [
            {
                name: 'Leads',
                showInLegend: true,
                data: funnelData,
            }
        ]
    };

    return <HighchartsReact highcharts={Highcharts} options={chartOptions} />;
}