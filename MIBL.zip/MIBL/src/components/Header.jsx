import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import MenuIcon from '@mui/icons-material/Menu';
import { Avatar, Box, Button, Drawer, List, ListItem, ListItemButton, ListItemText, Menu, MenuItem, Paper, Popover, Popper, ToggleButton, ToggleButtonGroup, Tooltip } from '@mui/material';
import MuiAppBar from '@mui/material/AppBar';
import Grid from '@mui/material/Grid';
import IconButton from '@mui/material/IconButton';
import { styled } from '@mui/material/styles';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import useMediaQuery from '@mui/material/useMediaQuery';
import React, { useEffect, useRef, useState } from 'react';
import { toast } from 'react-toastify';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import "../App.css";
import logo from '../assets/images/logo.svg';
import leadpool from '../assets/images/sidenavbar/leadpool.svg';
import reportsSvg from "../assets/images/sidenavbar/reports.svg";
import rolespermissions from '../assets/images/sidenavbar/rolespermissions.svg';
import settingsSvg from "../assets/images/sidenavbar/settings.svg";
import setup from '../assets/images/sidenavbar/setup.svg';
import uploaddata from '../assets/images/sidenavbar/uploaddata.svg';
import usermanagement from '../assets/images/sidenavbar/usermanagement.svg';
import { setPage } from '../redux/slices/callQueueSlice';
import { setIsCaller } from '../redux/slices/userSlice';
import { logout } from '../services/api';
import { decryptRoute, encryptRoute } from '../services/encrypt';
import { clearSessionState } from '../utils/sessionManager';
import { tabselectedColor } from '../utils/Colors';

export const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
}));

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  backgroundColor: 'white',
  transition: theme.transitions.create(['width', 'margin'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100%)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

export default function Header({ open }) {
  const { encrypted } = useParams();
  const location = useLocation();
  const isDesktop = useMediaQuery('(min-width:1250px)');
  const isMobile = useMediaQuery('(min-width:520px)');
  const [mobileOpen, setMobileOpen] = useState(false);

  const [anchorEl, setAnchorEl] = useState(null);
  const settings = ['Logout'];
  const navigate = useNavigate();
  const [value, setValue] = useState();
  const [anchor, setAnchor] = React.useState(null);
  const isOpen = Boolean(anchor);

  const handleClick = (event) => {
    setAnchor(event.currentTarget);
  };

  const showDrawer = () => {
    setMobileOpen(!mobileOpen);
  }

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const userdata = useSelector((state) => state?.user?.loggedData);
  const user_Name = useSelector((state) => state.user.userName);
  const fetchUserByManager = useSelector((state) => state.user.fetchUserByManager);
  const page = useSelector(state => state.callQueue.page);
  const allowedUrls = useSelector((state) => state?.user?.featureAccess.map(fa => fa.Url));
  const dashboard = '/dashboard';
  const displayName = user_Name || userdata?.UserName;

  const pathToTab = {
    '/dashboard': 'Dashboard',
    '/managerdashboard': 'Dashboard',
    '/callqueue': 'Call Queue',
    '/callqueue/customerdetails': 'Call Queue',
    '/assignLeads': 'Assign / Reassign',
    '/customerSearch': 'Customer Search',
    '/admindashboard': 'Dashboard',
  };

  const dashboardSubMenu = [
    { text: 'Follow Up Efficiency Dashboard', route: '/tatMonitoring' },
    { text: 'Leader Board', route: '/leaderBoard' },
    { text: 'Performance Dashboard', route: '/performanceDashboard' },
    { text: 'Renewal Dashboard', route: '/renewalDashboard' }
  ];

  const menuItems = [
    { text: 'Target', icon: setup, route: '/target' },
    { text: 'Dealer Setup', icon: setup, route: '/mispoutlet' },
    { text: 'Dealer List', icon: setup, route: '/editmispoutlet' },
    { text: 'Lead Pool', icon: leadpool, route: '/leadpool' },
    { text: 'User Management', icon: usermanagement, route: '/userManagement' },
    { text: 'Role & Permissions', icon: rolespermissions, route: '/role' },
    { text: 'Reports', icon: reportsSvg, route: '/reports' },
    { text: 'System Configuration', icon: settingsSvg, route: '/systemconfiguration' },
    { text: 'Data Upload', icon: uploaddata, route: '/dataupload' },
    { text: 'Clients', icon: usermanagement, route: '/clients' },
    { text: 'Portfolios', icon: usermanagement, route: '/portfolios' },
    { text: 'Opportunities', icon: usermanagement, route: '/opportunities' },
    { text: 'Renewals', icon: usermanagement, route: '/renewals' }
  ];

  const [dashboardSubOpen, setDashboardSubOpen] = useState(false);
  const dashboardCloseTimerRef = useRef(null);
  const dashboardItemRef = useRef(null);
  const OTHERS_MENU_WIDTH = 220;

  const showDashboardSection = dashboardSubMenu.some(m =>
    allowedUrls.some(au => !!au && au.startsWith(m.route))
  );

  const allowedMenuItems = menuItems.filter(m =>
    allowedUrls.some(au => !!au && au.startsWith(m.route)) || m.route === '/opportunities' || m.route === '/portfolios' || m.route === '/renewals'
  );

  // Encrypted MIBL routes carry the path in :encrypted; plain routes (the embedded /clients
  // flow) carry it directly in the URL pathname.
  const currentPath = (() => {
    try {
      return encrypted ? decryptRoute(decodeURIComponent(encrypted)) : location.pathname;
    } catch {
      return location.pathname;
    }
  })();
  const isClientRoute = currentPath.startsWith('/clients');
  const isOpportunityRoute = currentPath.startsWith('/opportunities');
  const isPortfolioRoute = currentPath.startsWith('/portfolios');
  const isRenewalRoute = currentPath.startsWith('/renewals');
  const isActivitiesRoute = currentPath.startsWith('/activities');
  const isCrmRoute = currentPath.startsWith('/crm');
  const isKpiDashboardRoute = currentPath.startsWith('/kpi-dashboard');
  const isPerformanceDashboardRoute = currentPath.startsWith('/performance-dashboard');
  const isAesJsonCipherRoute = currentPath.startsWith('/aes-json-cipher');
  const isReportRoute = currentPath.startsWith('/reports');
  const isRfqDashboardRoute = currentPath.startsWith('/dashboard');
  const activeMenuOverride = location.state?.activeMenu;
  const isClientContextOpportunityCreate =
    currentPath === '/opportunities/create' &&
    ['clientDashboard', 'clientList'].includes(location.state?.source);
  const isClientWorkAreaRoute = isRfqDashboardRoute || isClientRoute || isOpportunityRoute || isPortfolioRoute || isRenewalRoute || isActivitiesRoute || isCrmRoute || isKpiDashboardRoute || isPerformanceDashboardRoute || isAesJsonCipherRoute || isReportRoute;
  const isPlacementRole = String(userdata?.role ?? '').toLowerCase().includes('placement');
  const clientHeaderMenuItems = [
    { text: 'Dashboard', route: '/dashboard' },
    { text: 'Clients', route: '/clients' },
    { text: 'Portfolios', route: '/portfolios' },
    { text: 'Opportunities', route: '/opportunities' },
    { text: 'Renewals', route: '/renewals' },
    { text: 'Activities', route: '/activities' },
    { text: 'CRM', route: '/crm' },
    { text: 'Reports', route: '/reports' },
  ].filter((item) =>
    !isPlacementRole || !['/clients', '/portfolios', '/renewals', '/crm'].includes(item.route)
  );

  const isDashboardActive = dashboardSubMenu.some(item =>
    currentPath.startsWith(item.route)
  );

  const openDashboardSub = () => {
    clearTimeout(dashboardCloseTimerRef.current);
    setDashboardSubOpen(true);
  };

  const scheduleCloseDashboardSub = () => {
    dashboardCloseTimerRef.current = setTimeout(() => {
      setDashboardSubOpen(false);
    }, 120);
  };

  const handleCloseAll = () => {
    clearTimeout(dashboardCloseTimerRef.current);
    setAnchor(null);
    setDashboardSubOpen(false);
    selectTab();
  };

  const othersMenuItemSx = (active) => ({
    borderRadius: 1,
    mx: 0.5,
    py: 0.75,
    fontFamily: '"Georama Medium", Arial, Helvetica, sans-serif',
    fontSize: 14,
    color: active ? '#E31837' : 'var(--dark-black)',
    bgcolor: active ? 'rgba(227, 24, 55, 0.08)' : 'transparent',
    '&:hover': {
      bgcolor: 'rgba(227, 24, 55, 0.08)',
    },
  });

  useEffect(() => {
    selectTab();
  }, [location.pathname]);

  const selectTab = () => {
    setValue(pathToTab[currentPath] || 'others');
  }

  const dispatch = useDispatch();
  const isCaller = useSelector((state) => state.user.isCaller);
  const showToggle = currentPath === '/callqueue';
  const caller = userdata?.callingFlag === 'Y';
  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = async (setting) => {
    if (setting === 'Profile') {
      navigate(`/${encodeURIComponent(encryptRoute('/profile'))}`);
    }
    if (setting === 'Logout') {
      try {
        toast.dismiss();
        toast.clearWaitingQueue?.();
        navigate('/');
        await logout(userdata?.email);
      } catch (error) {
        console.error(error);
      }
      await clearSessionState({ broadcast: true });
    }
    setAnchorEl(null);
  };


  const handleCaller = (val) => {
    dispatch(setIsCaller(val));
    dispatch(setPage(1));
  }

  const handleMenuClick = (route) => {
    navigate(`/${encodeURIComponent(encryptRoute(route))}`);
    setMobileOpen(false);
  };

  const handleRoute = (route) => {
    switch (route) {
      case '/dashboard':
      case '/tatMonitoring':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/leaderBoard':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/performanceDashboard':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/target':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/mispoutlet':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/renewalDashboard':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/editmispoutlet':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/leadpool':
        // if (allowedUrls.includes(route)) {
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        // } else {
        //   navigate(`/${encodeURIComponent(encryptRoute(`${route}/create`))}`);
        // }
        break;
      case '/userManagement':
        // if (allowedUrls.includes(route)) {
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        // } else {
        //   navigate(`/${encodeURIComponent(encryptRoute(`${route}/create`))}`);
        // }
        break;
      case '/role':
        // if (allowedUrls.includes(route)) {
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        // } else {
        //   navigate(`/${encodeURIComponent(encryptRoute(`${route}/create`))}`);
        // }
        break;
      case '/systemconfiguration':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/dataupload':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      case '/clients':
      case '/opportunities':
      case '/portfolios':
      case '/renewals':
      case '/activities':
      case '/crm':
      case '/kpi-dashboard':
      case '/reports':
        navigate(`/${encodeURIComponent(encryptRoute(route))}`);
        break;
      default:
        selectTab();
        break;
    }
    setAnchor(null);
  }

  const handleClientHeaderRoute = (route) => {
    handleRoute(route);
  };

  const getInitials = (name) => {
    if (!name) return "";
    const parts = name.trim().split(" ");
    return parts
      .filter(Boolean) // avoid extra spaces
      .map((word) => word[0].toUpperCase())
      .slice(0, 2) // limit to 2 letters
      .join("");
  };


  return (
    <AppBar className='header-p' sx={{ minHeight: "40px" }} position="fixed" open={open} >
      <Toolbar>
        <Grid
          container
          alignItems="center"
          justifyContent="space-between"
          sx={{ width: '100%' }}
        >
          {/* Left Section */}

          <Box display="flex" alignItems="center">
            {!isDesktop && userdata?.roleType === "DEALER" &&
              <IconButton size="medium" edge="start" onClick={() => showDrawer()}
                // onClick={handleDrawer}
                aria-label="menu"
              //  sx={{ display: { xs: 'block', sm: 'block', md: 'block', lg: 'none' } }}
              >
                <MenuIcon />
              </IconButton>}

            <Typography>
              <img loading="lazy" src={logo} height={isDesktop ? "32px" : "24px"} alt="logo" style={{ cursor: 'pointer' }}
                onClick={() => navigate(`/${encodeURIComponent(encryptRoute(dashboard))}`)} />
            </Typography>
          </Box>

          {/* Center Tabs Section */}
          {userdata?.roleType === "DEALER" &&
            <>
              {isDesktop ? (
                <Tabs
                  className='nav-text custom-tabs'
                  value={value}
                  onChange={handleChange}
                  centered
                  sx={{
                    '& .MuiTabs-indicator': {
                      display: 'none',
                    },
                  }}
                >
                  {<Tab
                    className='nav-text'
                    label="Dashboard"
                    value="Dashboard"
                    component="a"
                    onClick={() => navigate(`/${encodeURIComponent(encryptRoute(dashboard))}`)}
                    sx={{
                      textTransform: 'capitalize',
                      '&.Mui-selected': {
                        ...tabselectedColor
                      },
                    }}
                  />}

                  <Tab
                    className='nav-text'
                    label="Call Queue"
                    value="Call Queue"
                    component="a"
                    onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/callqueue'))}`)}
                    sx={{
                      textTransform: 'capitalize',
                      '&.Mui-selected': {
                        ...tabselectedColor
                      },
                    }}
                  />

                  {!!fetchUserByManager?.length &&
                    <Tab
                      className='nav-text'
                      label="Assign / Reassign"
                      value="Assign / Reassign"
                      component="a"
                      onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/assignLeads'))}`)}
                      sx={{
                        textTransform: 'capitalize',
                        '&.Mui-selected': {
                          ...tabselectedColor
                        },
                      }}
                    />}

                  <Tab
                    className='nav-text'
                    label="Customer Search"
                    value="Customer Search"
                    component="a"
                    onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/customerSearch'))}`)}
                    sx={{
                      textTransform: 'capitalize',
                      '&.Mui-selected': {
                        ...tabselectedColor
                      },
                    }}
                  />

                  {(allowedMenuItems.length > 0 ||
                    dashboardSubMenu.some(m => allowedUrls.some(au => !!au && au.startsWith(m.route)))) && (
                      <Tab
                        className="nav-text"
                        id="basic-button"
                        label="Others"
                        value="others"
                        component="a"
                        aria-controls={isOpen ? 'basic-menu' : undefined}
                        aria-haspopup="true"
                        aria-expanded={isOpen ? 'true' : undefined}
                        onClick={handleClick}
                        sx={{
                          textTransform: 'capitalize',
                          '&.Mui-selected': {
                            ...tabselectedColor
                          },
                        }}
                      />
                    )}
                </Tabs>
              ) : null}

              <Popover
                id="basic-menu"
                anchorEl={anchor}
                open={isOpen}
                onClose={handleCloseAll}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                transformOrigin={{ vertical: 'top', horizontal: 'center' }}
                disableScrollLock
                slotProps={{
                  paper: {
                    'aria-labelledby': 'basic-button',
                    sx: {
                      mt: 0.75,
                      width: OTHERS_MENU_WIDTH,
                      minWidth: OTHERS_MENU_WIDTH,
                      maxWidth: OTHERS_MENU_WIDTH,
                      borderRadius: 2,
                      boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
                      overflow: 'hidden',
                    },
                  },
                }}
              >
                <List dense disablePadding sx={{ py: 0.5 }}>
                  {showDashboardSection && (
                    <ListItemButton
                      ref={dashboardItemRef}
                      selected={isDashboardActive || dashboardSubOpen}
                      onMouseEnter={openDashboardSub}
                      onMouseLeave={scheduleCloseDashboardSub}
                      onClick={openDashboardSub}
                      sx={{
                        ...othersMenuItemSx(isDashboardActive || dashboardSubOpen),
                        justifyContent: 'space-between',
                      }}
                    >
                      <ListItemText primary="Dashboard" primaryTypographyProps={{ fontSize: 14 }} />
                      <ChevronRightIcon sx={{ fontSize: 18, color: 'inherit', opacity: 0.7 }} />
                    </ListItemButton>
                  )}
                  {allowedMenuItems.map((m) => (
                    <ListItemButton
                      key={m.route}
                      selected={currentPath.startsWith(m.route)}
                      onMouseEnter={() => setDashboardSubOpen(false)}
                      onClick={() => {
                        handleRoute(m.route);
                        handleCloseAll();
                      }}
                      sx={othersMenuItemSx(currentPath.startsWith(m.route))}
                    >
                      <ListItemText primary={m.text} primaryTypographyProps={{ fontSize: 14 }} />
                    </ListItemButton>
                  ))}
                </List>
              </Popover>

              <Popper
                open={isOpen && dashboardSubOpen && showDashboardSection}
                anchorEl={dashboardItemRef.current}
                placement="right-start"
                disablePortal={false}
                modifiers={[
                  { name: 'offset', options: { offset: [6, 0] } },
                  { name: 'preventOverflow', options: { padding: 8 } },
                ]}
                sx={{ zIndex: (theme) => theme.zIndex.modal + 2 }}
              >
                <Paper
                  elevation={8}
                  onMouseEnter={openDashboardSub}
                  onMouseLeave={scheduleCloseDashboardSub}
                  sx={{
                    borderRadius: 2,
                    minWidth: 248,
                    boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
                  }}
                >
                  <List dense disablePadding sx={{ py: 0.5 }}>
                    {dashboardSubMenu
                      .filter(m => allowedUrls.some(au => !!au && au.startsWith(m.route)))
                      .map((m) => (
                        <ListItemButton
                          key={m.route}
                          selected={currentPath.startsWith(m.route)}
                          onClick={() => {
                            handleRoute(m.route);
                            handleCloseAll();
                          }}
                          sx={othersMenuItemSx(currentPath.startsWith(m.route))}
                        >
                          <ListItemText primary={m.text} primaryTypographyProps={{ fontSize: 14 }} />
                        </ListItemButton>
                      ))}
                  </List>
                </Paper>
              </Popper>
            </>
          }

          {isClientWorkAreaRoute && userdata?.roleType === "MIBL" && (
            <Box
              display="flex"
              alignItems="center"
              justifyContent="center"
              gap={1}
              flex={1}
              px={2}
              sx={{
                overflowX: 'auto',
                '&::-webkit-scrollbar': { display: 'none' },
              }}
            >
              {clientHeaderMenuItems.map((item) => {
                const active =
                  activeMenuOverride
                    ? item.text === activeMenuOverride
                    : item.route === '/clients'
                    ? isClientRoute || isClientContextOpportunityCreate
                    : item.route === '/dashboard'
                      ? isRfqDashboardRoute
                    : item.route === '/opportunities'
                      ? isOpportunityRoute && !isClientContextOpportunityCreate
                    : item.route === '/portfolios'
                        ? isPortfolioRoute
                    : item.route === '/renewals'
                        ? isRenewalRoute
                      : item.route === '/activities'
                        ? isActivitiesRoute
                      : item.route === '/crm'
                        ? isCrmRoute
                      : item.route === '/reports'
                        ? isReportRoute
                        : currentPath.startsWith(item.route);
                return (
                  <Button
                    key={item.route}
                    className="nav-text"
                    onClick={() => handleClientHeaderRoute(item.route)}
                    sx={{
                      minWidth: 'auto',
                      px: 1.25,
                      py: 0.5,
                      whiteSpace: 'nowrap',
                      textTransform: 'none',
                      color: active ? '#E31837 !important' : 'var(--dark-black) !important',
                      borderBottom: active ? '2px solid #E31837' : '2px solid transparent',
                      borderRadius: 0,
                      fontSize: '14px !important',
                      lineHeight: '20px !important',
                    }}
                  >
                    {item.text}
                  </Button>
                );
              })}
            </Box>
          )}

          {/* Drawer for mobile/tablet */}
          <Drawer
            anchor="left"
            open={mobileOpen}
            onClose={() => setMobileOpen(false)}
            ModalProps={{
              keepMounted: true,
            }}
          >
            <Box sx={{ width: 240, mt: 6 }}>
              <List sx={{
                "& .MuiListItem-root": {
                  py: 0.5,
                },
              }}>
                {/* Dashboard */}
                <ListItem button onClick={() => {
                  setAnchorEl(null); setMobileOpen(false);
                  navigate(`/${encodeURIComponent(encryptRoute(dashboard))}`);
                }}>
                  <ListItemText primary="Dashboard" />
                </ListItem>

                {/* Call Queue */}
                <ListItem button onClick={() => {
                  setAnchorEl(null); setMobileOpen(false);
                  navigate(`/${encodeURIComponent(encryptRoute('/callqueue'))}`);
                }}>
                  <ListItemText primary="Call Queue" />
                </ListItem>

                {/* Assign / Reassign (only if manager data exists) */}
                {!!fetchUserByManager?.length && (
                  <ListItem button onClick={() => {
                    setAnchorEl(null); setMobileOpen(false);
                    navigate(`/${encodeURIComponent(encryptRoute('/assignLeads'))}`);
                  }}>
                    <ListItemText primary="Assign / Reassign" />
                  </ListItem>
                )}

                {/* Customer Search */}
                <ListItem button onClick={() => {
                  setAnchorEl(null); setMobileOpen(false);
                  navigate(`/${encodeURIComponent(encryptRoute('/customerSearch'))}`);
                }}>
                  <ListItemText primary="Customer Search" />
                </ListItem>

                {/* Others menu (same as your Tab "Others") */}
                {allowedMenuItems.length > 0 && (
                  <>
                    {/* <ListItem>
                      <ListItemText primary="Others" />
                    </ListItem> */}
                    {allowedMenuItems
                      .map(m => (
                        <ListItem key={m.text} button onClick={() => { setAnchorEl(null); setMobileOpen(false); handleRoute(m.route); }}>
                          <ListItemText primary={m.text} />
                        </ListItem>
                      ))}
                  </>
                )}
                {dashboardSubMenu?.filter(m => allowedUrls.some(au => !!au && au.startsWith(m.route))).length > 0 && (
                  <>
                    {/* <ListItem>
                      <ListItemText primary="Others" />
                    </ListItem> */}
                    {dashboardSubMenu?.filter(m => allowedUrls.some(au => !!au && au.startsWith(m.route))).map(m => (
                      <ListItem key={m.text} button onClick={() => { setAnchorEl(null); setMobileOpen(false); handleRoute(m.route); }}>
                        <ListItemText primary={m.text} />
                      </ListItem>
                    ))}
                  </>
                )}
              </List>
            </Box>
          </Drawer>

          {!isMobile &&
            <>
              <Box display="flex" justifyContent="flex-end" alignItems="center">
                <Tooltip title="Open settings">
                  <IconButton onClick={handleMenu} sx={{ p: 0 }}>
                    <Avatar className='secondary-light' sx={{ width: 32, height: 32 }}>
                      <Typography className='text-gray georama-SemiBold fs-12'>
                        {getInitials(userdata?.UserName)}
                      </Typography>
                    </Avatar>
                  </IconButton>
                </Tooltip>
              </Box>
            </>}

          {/* Right Section */}
          {fetchUserByManager?.length > 0 && caller && showToggle &&
            <Box display="flex" justifyContent="flex-end" alignItems="center" pb={0.5}>
              <ToggleButtonGroup exclusive size="small" value={isCaller} onChange={(e, v) => { if (v) handleCaller(v); }}
                sx={{ mr: 2, border: '1px solid #cccccc', borderRadius: '33px !important' }}>
                <ToggleButton className='text-capitalize fs-12' value="caller" sx={{
                  px: 1.2,
                  py: 0.5,
                  borderRadius: '33px !important',
                  border: '0px !important',
                  color: 'black',
                  '&.Mui-selected': {
                    backgroundColor: '#e53935 !important',
                    color: 'white',
                  }
                }}>
                  Caller
                </ToggleButton>

                <ToggleButton className='text-capitalize fs-12' value="noncaller" sx={{
                  px: 1.2,
                  py: 0.5,
                  borderRadius: '33px !important',
                  border: '0px !important',
                  color: 'black',
                  '&.Mui-selected': {
                    backgroundColor: '#e53935 !important',
                    color: 'white',
                  }
                }}>
                  Non Caller
                </ToggleButton>
              </ToggleButtonGroup>
            </Box>
          }

          {/* <IconButton size="large" aria-label="notifications" sx={{ color: 'black' }}>
                <Badge color="error" variant="dot">
                  <NotificationsNoneRoundedIcon />
                </Badge>
              </IconButton> */}

          {isMobile &&
            <>
              <Box display="flex" justifyContent="flex-end" alignItems="center">
                <Tooltip title="Open settings">
                  <IconButton onClick={handleMenu} sx={{ p: 0 }}>
                    <Avatar className='secondary-light' sx={{ width: 32, height: 32 }}>
                      <Typography className='text-gray georama-SemiBold fs-12'>
                        {getInitials(userdata?.UserName)}
                      </Typography>
                    </Avatar>
                  </IconButton>
                </Tooltip>

                {isMobile &&
                  <Box ml={1} color="black">
                    <Typography className='georama-Regular fs-16' sx={{
                      width: 105,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }} width={105}>
                      {displayName}
                    </Typography>
                    <Typography className='georama-Regular fs-10'>{userdata?.role}</Typography>
                  </Box>
                }
              </Box>
            </>
          }

          <Menu
            sx={{ mt: '45px' }}
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
            anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          >
            {settings.map((setting) => (
              <MenuItem key={setting} onClick={() => handleClose(setting)}>
                <Typography textAlign="center">{setting}</Typography>
              </MenuItem>
            ))}
          </Menu>
        </Grid>
      </Toolbar>
    </AppBar >
  );
}
