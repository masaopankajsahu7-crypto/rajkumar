import React from "react";
import { Box } from "@mui/material";
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    LineElement,
    PointElement,
    Tooltip,
    Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    LineElement,
    PointElement,
    Tooltip,
    Legend
);

const LeadsAssignedBar = ({ leadsAssigned }) => {
    // const leadsAssigneds = [
    //     { month: "Jan", leadCount: 0, renewalConversionPercentage: 0 },
    //     { month: "Feb", leadCount: 0, renewalConversionPercentage: 0 },
    //     { month: "Mar", leadCount: 0, renewalConversionPercentage: 0 },
    //     { month: "Apr", leadCount: 0, renewalConversionPercentage: 0 },
    //     { month: "May", leadCount: 0, renewalConversionPercentage: 0 },
    //     { month: "Jun", leadCount: 0, renewalConversionPercentage: 0 },
    //     { month: "Jul", leadCount: 208, renewalConversionPercentage: 50 },
    //     { month: "Aug", leadCount: 12, renewalConversionPercentage: 10 },
    //     { month: "Sep", leadCount: 8, renewalConversionPercentage: 150 },
    //     { month: "Oct", leadCount: 0, renewalConversionPercentage: 0 },
    //     { month: "Nov", leadCount: 0, renewalConversionPercentage: 0 },
    //     { month: "Dec", leadCount: 0, renewalConversionPercentage: 0 },
    // ];

    const labels = leadsAssigned.map((item) => item.month);
    const leadCounts = leadsAssigned.map((item) => item.leadCount);
    const renewalPercentages = leadsAssigned.map(
        (item) => item.renewalConversionPercentage
    );

    // ✅ Convert percentage to position relative to lead count
    const relativeConversion = leadsAssigned.map((item) => {
        if (item.leadCount === 0) return 0;
        const relativeValue = (item.leadCount * item.renewalConversionPercentage) / 100;
        return item.renewalConversionPercentage > 100
            ? item.leadCount * 1.1
            : relativeValue;
    });

    const data = {
        labels,
        datasets: [
            {
                type: "bar",
                label: "Total Leads Assigned",
                data: leadCounts,
                backgroundColor: "#FF3D3D",
                borderRadius: 4,
                barThickness: 20,
                order: 2,
                yAxisID: "y",
            },
            {
                type: "line",
                label: "Conversion Rate %",
                data: renewalPercentages,
                borderColor: "#00C853",
                backgroundColor: "#00C853",
                tension: 0.3,
                pointRadius: 2,
                pointHoverRadius: 6,
                borderWidth: 2,
                order: 1,
                yAxisID: "y1",
            },
        ],
    };

    const options = {
        responsive: true,
        interaction: {
            mode: "index",
            intersect: false,
        },
        plugins: {
            legend: {
                position: "bottom",
                labels: {
                    usePointStyle: true,
                    pointStyle: "circle",
                    font: { size: 12, weight: "bold" },
                    boxWidth: 6,
                    boxHeight: 6,
                },
            },
            tooltip: {
                callbacks: {
                    label: function (context) {
                        if (context.dataset.label === "Conversion Rate %") {
                            return `Conversion Rate: ${renewalPercentages[context.dataIndex]}%`;
                        }
                        return `Total Leads Assigned: ${leadCounts[context.dataIndex]}`;
                    },
                },
            },
        },
        scales: {
            y: {
                type: "linear",
                display: true,
                position: "left",
                beginAtZero: true,
                ticks: { color: "#333" },
                grid: { drawBorder: false },
                title: {
                    display: true,
                    text: "Total Leads",
                    color: "#FF3D3D",
                    font: { size: 12, weight: "bold" },
                },
            },
            y1: {
                type: "linear",
                display: true,
                position: "right",
                beginAtZero: true,
                ticks: {
                    color: "#00C853",
                    callback: (value) => `${value}%`,
                },
                grid: { drawOnChartArea: false },
                title: {
                    display: true,
                    text: "Conversion Rate %",
                    color: "#00C853",
                    font: { size: 12, weight: "bold" },
                },
            },
            x: {
                grid: { display: false },
            },
        },
    };

    return (
        <Box
            sx={{
                backgroundColor: "#fff",
                // p: 2,
                py:2,
                height: 300,
                borderRadius: 3,
            }}
        >
            <Bar data={data}
                options={{
                    ...options,
                    maintainAspectRatio: false,
                }}
                // options={options}
            />
        </Box>
    );
};

export default LeadsAssignedBar;
