import { CircularProgress, Backdrop, Box, Typography } from "@mui/material";

const BackdropLoader = ({ loading }) => {
    return (
            <Backdrop
                sx={{ color: "#e31837", backgroundColor: "rgb(255 255 255 / 50%)", zIndex: (theme) => theme.zIndex.drawer + 50000 }}
                open={loading}
            >
                <Box
                    display="flex"
                    flexDirection="column"
                    alignItems="center"
                >
                    <CircularProgress color="inherit" />
                    <Typography variant="h6" mt={2}>
                        Loading...
                    </Typography>
                </Box>
            </Backdrop>
    )
}

export default BackdropLoader
