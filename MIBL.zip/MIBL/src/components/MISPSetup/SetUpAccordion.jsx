import CloseIcon from '@mui/icons-material/Close';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { Accordion, AccordionDetails, AccordionSummary, Autocomplete, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormControlLabel, Grid, IconButton, LinearProgress, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from '@mui/material';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as XLSX from 'xlsx';
import excelIcon from '../../assets/images/excel.svg';
import excelSheetimg from '../../assets/images/excelSheetimg.svg';
import uploadIcon from '../../assets/images/upload.svg';
import { downloadTemplateExcel, saveColumnMapping } from '../../services/api';
import { borderRed, btnRed, checkBoxRed } from '../../utils/Colors';
import BackdropLoader from '../Loader/BackdropLoader';

const customTheme = createTheme({
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    variants: [
                        {
                            props: { variant: 'dashed', color: 'primary' },
                            style: ({ theme }) => ({
                                textTransform: 'none',
                                border: `2px dashed gray`,
                                color: 'gray',
                            }),
                        },
                    ],
                },
            },
        },
    },
});

const SetUpAccordion = ({ dealerInfo, dealerDetails, label, data, accordion, setAccordion, mappingSaved, setMappingSaved, formValues, handleInputChange, setColumnMapping, customTemplates, columnMapping, selectedTemplates, isEdit }) => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const fileInputRef = useRef(null);
    const [dragOver, setDragOver] = useState(false);
    const [uploadedFile, setUploadedFile] = useState(null);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [fileSize, setFileSize] = useState(0);
    const [loc, setLoc] = useState('');
    const [excelHeaders, setExcelHeaders] = useState([]);
    const [fieldMapping, setFieldMapping] = useState({});
    const { parentId, dealerId, dealerLocCode } = dealerInfo;
    const userdetails = useSelector((state) => state.user.loggedData);
    const [resetOpen, setResetOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    const isValidFile = (file) => {
        const validTypes = [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-excel',
            'text/csv',
        ];
        return validTypes.includes(file.type);
    };

    const handleFile = (file) => {
        if (file && isValidFile(file)) {
            const sizeMB = file.size / (1024 * 1024); // convert to MB
            setUploadedFile(file);
            setFileSize(sizeMB.toFixed(1));
            setUploadProgress(0);
            simulateUploadProgress(sizeMB);
        }
    };

    const saveCustomTemplate = async () => {
        try {
            setLoading(true);
            let reponse = await saveColumnMapping(userdetails.user_id, dealerId, parentId, formValues[`${data}Flag`], dealerLocCode, loc, null, null);
            if (reponse.statusCode === '200') {
                setMappingSaved(prev => ({
                    ...prev,
                    [`${data}Flag`]: 1
                }));
                toast.success(`Template Mapped Successfully!`)
            } else toast.error(`Something went Wrong!`)
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    const handleExcelUpload = (e, type) => {
        e.preventDefault();
        if (uploadedFile) {// if file is already uploaded and user Uploads file again.
            toast.warning('Please remove Uploaded File before Uploading.');
            return;
        }
        let file;
        if (type === 'drop') {
            file = e.dataTransfer.files[0];
        } else {
            const filedata = e.target.files[0];
            handleFile(filedata);
            file = e.target.files[0];
        }
        if (!isValidFile(file)) {
            toast.error('Please upload a valid Excel or CSV file.');
            return;
        }
        setUploadedFile(file);
        const sizeMB = file.size / (1024 * 1024);
        setFileSize(sizeMB.toFixed(1));
        setUploadProgress(0);
        simulateUploadProgress(sizeMB);
        e.target.value = '';
    };

    const base64ToFile = (base64, fileName, mimeType) => {
        const byteString = atob(base64);
        const byteArray = new Uint8Array(
            [...byteString].map(char => char.charCodeAt(0))
        );
        const blob = new Blob([byteArray], { type: mimeType });
        return new File([blob], fileName, { type: mimeType });
    };

    useEffect(() => {
        if (Object.keys(fieldMapping).length === 0 && isEdit && columnMapping && columnMapping.length > 0) {
            const mappedFields = {};
            let headers = [];
            let excelColumns;
            columnMapping.filter(item => item?.dbTableName?.includes(data.toLowerCase())).forEach((item, index) => {
                if (index === 0) {
                    let blobFile = base64ToFile(item.column_mapping_excel, item.column_mapping_file_name,
                        getContentTypeFromExtension(item.column_mapping_file_name.split('.').at(-1))
                    );
                    setUploadedFile(blobFile);
                    // setFileSize(getFileSizeFromBase64(item.column_mapping_excel));
                    let blobSize = (blobFile.size / (1024 * 1024)).toFixed(1);
                    setFileSize(blobSize);
                    setUploadProgress(100);
                    excelColumns = item.column_mapping_excel;
                }
                const key = item?.dbTableName?.includes(data.toLowerCase()) ? data : '';
                if (key) {
                    mappedFields[item.dbColumnName] = item.excelColumnName;
                    headers.push(item.excelColumnName);
                    setMappingSaved(prev => ({
                        ...prev,
                        [`${data}Flag`]: 2
                    }));
                }
            });
            setFieldMapping(mappedFields);
            if (excelColumns) {
                const binaryStr = atob(excelColumns);
                const len = binaryStr.length;
                const bytes = new Uint8Array(len);
                for (let i = 0; i < len; i++) {
                    bytes[i] = binaryStr.charCodeAt(i);
                }

                const workbook = XLSX.read(bytes, { type: 'array' });

                // Read the first sheet
                const firstSheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[firstSheetName];

                // Convert sheet to JSON and get the first row
                const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 }); // header:1 returns rows as arrays
                if (data.length > 0) {
                    headers = data[0];
                }
            }
            setExcelHeaders(headers);
        }
    }, [columnMapping]);

    useEffect(() => {
        if (isEdit && selectedTemplates && selectedTemplates.length > 0) {
            setLoc(selectedTemplates.find(st => st.customtype === data)?.dealerId || '');
        }
    }, [selectedTemplates]);

    const getExtensionFromContentType = (contentType) => {
        switch (contentType) {
            case 'text/csv':
                return 'csv';
            case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
                return 'xlsx';
            case 'application/vms-excel':
                return 'xls';
        }
    };

    const getContentTypeFromExtension = (ext) => {
        switch (ext) {
            case 'csv':
                return 'text/csv';
            case 'xlsx':
                return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            case 'xls':
                return 'application/vms-excel';
        }
    };

    const downloadExcel = async () => {
        try {
            setLoading(true);
            const response = await downloadTemplateExcel({
                customtype: data,
                parentId,
                dealerId: dealerInfo.dealerId,
                mapping_dealer_code: loc
            });

            if (response && response.data) {
                const contentType = response.headers['content-type'];
                const extension = getExtensionFromContentType(contentType);
                const filename = `${data}_Template.${extension}`;

                const blob = new Blob([response.data], { type: contentType });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', filename);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error('Download failed:', error);
        } finally {
            setLoading(false);
        }
    };

    const downloadCustomExcel = async () => {
        try {
            setLoading(true);
            const response = await downloadTemplateExcel({
                customtype: data,
                parentId,
                dealerId: dealerInfo.dealerId,
                mapping_dealer_code: dealerInfo.dealerId
            });

            if (response && response.data) {
                const contentType = response.headers['content-type'];
                const extension = getExtensionFromContentType(contentType);
                const filename = `${data}_Template.${extension}`;

                const blob = new Blob([response.data], { type: contentType });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', filename);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error('Download failed:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleContinue = () => {
        const reader = new FileReader();

        reader.onload = (evt) => {
            const bstr = evt.target.result;
            const workbook = XLSX.read(bstr, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
            const headers = jsonData[0];
            setExcelHeaders(headers);
        };

        reader.readAsBinaryString(uploadedFile);
    }

    const handleDrop = (e) => {
        e.preventDefault();
        if (uploadedFile) {// if file is already uploaded and user Uploads file again.
            toast.warning('Please remove Uploaded File before Uploading.');
            setDragOver(false);
            return;
        }
        handleExcelUpload(e, 'drop');
        setDragOver(false);
        const file = e.dataTransfer.files[0];
        handleFile(file);
    };

    const handleSelectChange = (mispField, selectedValue) => {
        setFieldMapping((prev) => ({
            ...prev,
            [mispField]: selectedValue
        }));
    };

    const simulateUploadProgress = (sizeMB) => {
        let uploaded = 0;
        const total = sizeMB;
        const interval = setInterval(() => {
            uploaded += 0.3;
            const progress = Math.min(uploaded / total, 1) * 100;
            setUploadProgress(progress);
            if (uploaded >= total) clearInterval(interval);
        }, 100);
    };

    const handleFileClick = () => {
        fileInputRef.current.click();
    };

    const handleCancelUpload = () => {
        setUploadedFile(null);
        setUploadProgress(0);
        setExcelHeaders([]);
        setMappingSaved(prev => ({
            ...prev,
            [`${data}Flag`]: 0
        }));
        setFieldMapping({});
    };

    const handleCancel = () => {
        setResetOpen(false);
    }

    const handleOk = () => {
        handleCancelUpload();
        setResetOpen(false);
    }

    const handleColumnMapping = async (saveForField) => {
        const requiredFields = dealerDetails
            .filter(item => item.required === '1')
            .map(item => item.columnName);

        const missingRequiredFields = requiredFields.filter(
            column => !fieldMapping[column]
        );

        if (missingRequiredFields.length > 0) {
            toast.error(`Please map all required fields: ${missingRequiredFields.join(', ')}`);
            return;
        }

        let mappedColumns = [];
        Object.keys(fieldMapping).filter((field) => fieldMapping[field] !== null).map((field) =>
            mappedColumns.push({
                "excelColumnName": fieldMapping[field],
                "dbColumnName": field,
                "dbTableName": saveForField === 'addOn' ? 'mmi_poladdon_data' : `mmi_ebm_${saveForField}_data`
                // "dealerId": dealerId,
                // "parentId": parentId
            })
        )
        setColumnMapping(prev => [...prev, { saveForField: mappedColumns }]);
        try {
            setLoading(true);
            let reponse = await saveColumnMapping(userdetails.user_id, dealerId, parentId, formValues[`${data}Flag`], dealerLocCode, dealerId, mappedColumns, uploadedFile);
            if (reponse.statusCode === '200') {
                setMappingSaved(prev => ({
                    ...prev,
                    [`${data}Flag`]: 1
                }));
                toast.success(`Fields Mapped Successfully!`);
            } else toast.error(`Something went Wrong!`);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (formValues[`${data}Flag`] === `${data.toLowerCase()}_created_custom`) {
            handleCancelUpload();
        }
        if (formValues[`${data}Flag`] === `${data.toLowerCase()}_custom`) {
            setLoc('');
        }
        if (formValues[`${data}Flag`] === `${data.toLowerCase()}_system`) {
            handleCancelUpload();
            setLoc('');
        }
    }, [formValues[`${data}Flag`]])

    const isSaveDisabled = useMemo(() => {
        return dealerDetails && dealerDetails
            .filter(item => item.required === "1")
            .some(item => !fieldMapping[item.columnName]);
    }, [dealerDetails, fieldMapping]);

    return (
        <>
            <BackdropLoader loading={loading} />
            <Accordion className='custom-accordion bg-white' expanded={accordion === label} onChange={() => setAccordion(accordion === label ? null : label)}
                sx={{ boxShadow: 'none' }} >
                <AccordionSummary className='bg-white' expandIcon={<ExpandMoreIcon />}>
                    <Typography>{label}</Typography>
                </AccordionSummary>
                <AccordionDetails className='bg-white'>
                    <RadioGroup
                        className="radio-button-box"
                        value={formValues[`${data}Flag`]}
                        onChange={(e) => handleInputChange(`${data}Flag`, e.target.value)}
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            flexDirection: 'row',
                            gap: 2,
                        }}
                        name="radio-buttons-group"
                    >
                        <FormControlLabel
                            className="radio-button-label"
                            value={`${data.toLowerCase()}_system`}
                            control={
                                <Radio
                                    sx={{
                                        color: 'gray',
                                        '&.Mui-checked': {
                                            color: checkBoxRed,
                                        },
                                    }}
                                />
                            }
                            label="Use System Template"
                        />
                        <FormControlLabel
                            className="radio-button-label"
                            value={`${data.toLowerCase()}_custom`}
                            control={
                                <Radio
                                    sx={{
                                        color: 'gray',
                                        '&.Mui-checked': {
                                            color: checkBoxRed,
                                        },
                                    }}
                                />
                            }
                            label="Create Custom Template"
                        />
                        {customTemplates && customTemplates.filter(ct => ct.customtype === data.toLowerCase() && ct.dealerId !== dealerId).length > 0 &&
                            <FormControlLabel
                                className="radio-button-label"
                                value={`${data.toLowerCase()}_created_custom`}
                                control={
                                    <Radio
                                        sx={{
                                            color: 'gray',
                                            '&.Mui-checked': {
                                                color: checkBoxRed,
                                            },
                                        }}
                                    />
                                }
                                label="Use Created Template"
                            />
                        }
                    </RadioGroup>

                    {formValues[`${data}Flag`] === `${data.toLowerCase()}_system` || formValues[`${data}Flag`] === `${data.toLowerCase()}_created_custom` ? (
                        <Box my={2}>
                            {formValues[`${data}Flag`] === `${data.toLowerCase()}_created_custom` && customTemplates && customTemplates.filter(ct => ct.customtype === data.toLowerCase() && ct.dealerId !== dealerId).length > 0 && <>
                                <FormControl size="small">
                                    <Select onChange={(e) => setLoc(e.target.value)}
                                        defaultValue=""
                                        displayEmpty
                                        sx={{
                                            p: 0,
                                            m: 0,
                                            fontSize: '14px',
                                            borderRadius: 2,
                                            backgroundColor: '#fff',
                                        }}
                                        value={loc}
                                    >
                                        <MenuItem disabled value="">Select Custom Template</MenuItem>
                                        {customTemplates.filter(ct => ct.customtype === data.toLowerCase() && ct.dealerId !== dealerId)
                                            .map(ct => <MenuItem value={ct.dealerId}>{ct.dealerLocName}</MenuItem>)}
                                    </Select>
                                </FormControl>
                                <Button variant="outlined" onClick={() => downloadExcel()}
                                    sx={{ ml: 1, borderColor: borderRed, textTransform: 'capitalize' }}>
                                    <img src={excelIcon} alt="upload" />
                                    Sample Data
                                </Button>
                                <Button variant="contained" onClick={() => saveCustomTemplate()}
                                    sx={{ ...btnRed, float: 'right', my: 2 }}
                                    disabled={!loc || mappingSaved[`${data}Flag`] === 1}
                                >
                                    Save
                                </Button>
                            </>}
                            {formValues[`${data}Flag`] === `${data.toLowerCase()}_system` &&
                                <Button variant="outlined" component='a' download href={`../../public/${data}.xlsx`}
                                    sx={{ borderColor: borderRed, textTransform: 'capitalize' }}>
                                    <img src={excelIcon} alt="upload" />
                                    Sample Data
                                </Button>}
                        </Box>
                    ) : (
                        <>
                            <input type="file" accept=".csv,.xls,.xlsx" ref={fileInputRef} onChange={handleExcelUpload} style={{ display: 'none' }} />

                            <ThemeProvider theme={customTheme}>
                                <Grid container spacing={isMobile ? 1 : 4} columns={12} alignItems={'center'}>
                                    <Grid size={{ xs: 12, sm: 12, md: 5, lg: 5 }} sx={{ mt: 1.5 }}>
                                        <Typography >Upload Data</Typography>
                                        <Box sx={{ display: 'flex', flexWrap: "wrap", alignItems: 'center', gap: 1, mt: 1 }}>
                                            <Button
                                                className={`${isMobile ? 'fs-10' : 'fs-14'}`}
                                                sx={{
                                                    border: '2px dashed #ccc',
                                                    borderColor: dragOver ? 'primary.main' : '#ccc',
                                                    borderRadius: 2,
                                                    px: 'auto', py: 2,
                                                    cursor: 'pointer',
                                                    width: '100%',
                                                    textAlign: 'center',
                                                    transition: '0.2s ease',
                                                }}
                                                component="span"
                                                variant="dashed"
                                                color="primary"
                                                accept=".csv,.xlsx,.xls"
                                                onClick={handleFileClick}
                                                onDrop={handleDrop}
                                                onDragOver={(e) => {
                                                    e.preventDefault();
                                                    setDragOver(true);
                                                }}
                                                onDragLeave={() => setDragOver(false)}
                                            >
                                                <img src={uploadIcon} alt="upload" style={{ marginRight: 8 }} />
                                                Drag and Drop or
                                                <span
                                                    className={`${isMobile ? 'fs-10' : 'fs-14'} pr-2 dark-black text-underline`}
                                                >
                                                    Click to Upload
                                                </span>
                                            </Button>
                                            <Typography variant="caption" className='fs-10' display="block" sx={{ float: 'right', mt: 0.2, ml: 'auto' }}>
                                                CSV/Excel accepted
                                            </Typography>
                                        </Box>
                                    </Grid>
                                    {uploadedFile && (
                                        <Grid size={{ xs: 12, sm: 12, md: 8, lg: 7 }} sx={{ mt: 1.5 }}>
                                            <Grid container spacing={isMobile ? 1 : 4} columns={12} alignItems={'center'}>
                                                <Grid size={{ xs: 12, sm: 12, md: 8, lg: 8 }}>
                                                    <Typography variant="subtitle1">
                                                        Uploaded file
                                                    </Typography>
                                                    <Box
                                                        sx={{
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            justifyItems: 'center',
                                                            border: '1px solid #ccc',
                                                            borderRadius: 2,
                                                            // width: '100%',
                                                            pl: 1, pr: 2, py: 0.7,
                                                            mb: 1,
                                                            position: 'relative',
                                                        }}
                                                    >
                                                        <img
                                                            src={excelSheetimg}
                                                            alt="excel"
                                                            style={{ width: 32, marginRight: 12 }}
                                                        />
                                                        <Box sx={{ flexGrow: 1 }}>
                                                            <Typography variant="body2">{uploadedFile.name}</Typography>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={uploadProgress}
                                                                sx={{ height: 3, borderRadius: 1, mt: 0.5, color: 'gray', bgcolor: 'gray' }}
                                                            />
                                                            <Typography variant="caption" sx={{ mt: 0.5, display: 'block' }}>
                                                                {(fileSize * (uploadProgress / 100)).toFixed(1)} MB of {fileSize} MB
                                                            </Typography>
                                                        </Box>
                                                        <IconButton
                                                            onClick={() => setResetOpen(true)}
                                                            sx={{ position: 'absolute', top: 4, right: 4 }}
                                                        >
                                                            <CloseIcon fontSize="small" />
                                                        </IconButton>
                                                    </Box>
                                                    {isEdit && mappingSaved?.[`${data}Flag`] === 2 && <Button component="a" sx={{ py: 0 }} className='text-capitalize text-sky georama-Regular fs-12' onClick={() => downloadCustomExcel()} >Download CSV/Excel</Button>}
                                                </Grid>
                                                <Grid size={3} item xs={2} sx={{ mt: isMobile ? 0 : 3, mx: 2 }} alignItems={'center'}>
                                                    <Button onClick={handleContinue} className='btn-common-red' disabled={excelHeaders.length > 0 && uploadedFile}>
                                                        Continue
                                                    </Button>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    )}
                                </Grid>
                            </ThemeProvider>

                            {(isEdit || uploadedFile) && excelHeaders && excelHeaders.length > 0 &&
                                <Paper sx={{ p: 1, boxShadow: 'none' }}>
                                    <Typography variant="h6" gutterBottom>Fields Mapping</Typography>
                                    <TableContainer sx={{
                                        mt: 1, border: '1px solid rgb(224, 215, 215)', borderRadius: 3,
                                        maxHeight: 300,
                                    }}>
                                        <Table stickyHeader className='border-stroke'>
                                            <TableHead className='border-stroke' >
                                                <TableRow >
                                                    <TableCell className='body-formbg border-stroke nav-text'>MISP Fields</TableCell>
                                                    <TableCell className='body-formbg border-stroke nav-text'></TableCell>
                                                    <TableCell className='body-formbg border-stroke nav-text'>Mapping Fields</TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody className='border-stroke'>
                                                {dealerDetails?.filter(f => f.required === '1').map((item, index) => {
                                                    return (<TableRow key={index} >
                                                        <TableCell sx={{ borderBottom: 'none', width: '45%', px: 2, py: 1 }} className='georama-Medium border-none text-truncate' data-required={item.required} >{item.columnName}</TableCell>
                                                        <TableCell sx={{ borderBottom: 'none', width: '2%', px: 2, py: 1 }}>→</TableCell>
                                                        <TableCell sx={{ borderBottom: 'none', width: '45%', px: 2, py: 1 }}>
                                                            <Autocomplete
                                                                // className='georama-Medium border-none'
                                                                fullWidth
                                                                size="small"
                                                                options={excelHeaders}
                                                                value={fieldMapping[item.columnName] || null}
                                                                onChange={(event, newValue) => handleSelectChange(item.columnName, newValue)}
                                                                getOptionDisabled={(option) =>
                                                                    Object.values(fieldMapping).includes(option) && fieldMapping[item.columnName] !== option
                                                                }
                                                                renderInput={(params) => <TextField {...params} placeholder='Select' />}
                                                            />
                                                        </TableCell>
                                                    </TableRow>)
                                                })}
                                                {dealerDetails.filter(f => f.required !== '1').map((item, index) => {
                                                    return (<TableRow key={index} >
                                                        <TableCell sx={{ borderBottom: 'none', width: '45%', px: 2, py: 1 }} className='georama-Medium border-none' data-required={item.required} >{item.columnName}</TableCell>
                                                        <TableCell sx={{ borderBottom: 'none', width: '10%', px: 2, py: 1 }}>→</TableCell>
                                                        <TableCell sx={{ borderBottom: 'none', width: '45%', px: 2, py: 1 }}>
                                                            <Autocomplete
                                                                size="small"
                                                                options={excelHeaders}
                                                                value={fieldMapping[item.columnName] || null}
                                                                onChange={(event, newValue) => handleSelectChange(item.columnName, newValue)}
                                                                getOptionDisabled={(option) =>
                                                                    Object.values(fieldMapping).includes(option) && fieldMapping[item.columnName] !== option
                                                                }
                                                                renderInput={(params) => <TextField {...params} placeholder='Select' />}
                                                                fullWidth
                                                            />
                                                        </TableCell>
                                                    </TableRow>)
                                                })}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>

                                    <Button variant="contained" onClick={() => handleColumnMapping(data)}
                                        sx={{ ...btnRed, float: 'right', my: 2 }}
                                        disabled={isSaveDisabled || mappingSaved[`${data}Flag`] === 1}>
                                        Save
                                    </Button>
                                </Paper>}
                        </>
                    )}
                    <Dialog open={resetOpen} handleCancel={handleCancel} handleOk={handleOk}>
                        <DialogTitle>Are You Sure?</DialogTitle>
                        <DialogContent>
                            <Typography variant='h6'>All Mapped Fields for {label} will be removed!</Typography>
                        </DialogContent>
                        <DialogActions>
                            <Button autoFocus onClick={handleCancel}>
                                Cancel
                            </Button>
                            <Button onClick={handleOk}>Ok</Button>
                        </DialogActions>
                    </Dialog>
                </AccordionDetails>
                <ToastContainer autoClose={1000} />
            </Accordion>
        </>
    );
};

export default SetUpAccordion;