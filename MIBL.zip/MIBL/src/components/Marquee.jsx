import Marquee from "react-fast-marquee";
import StarIcon from '@mui/icons-material/Star';
import IconButton from '@mui/material/IconButton'
import { Box, Typography } from "@mui/material";
import { useSelector } from "react-redux";

const MarqueeInfo = () => {
    const userData = useSelector((state) => state.user.loggedData);
    
    return (
        <>
            <Box className="pink-light">
                <Marquee
                    gradient={false}
                    speed={50}
                    pauseOnHover
                // play={false}
                >
                    <Box display="flex" alignItems="center" >
                        {[1, 2, 3].map((_, index) => (
                            <Box display="flex" alignItems="center" key={index}>
                                <Box display="flex" alignItems="center" px={10}>
                                    <IconButton >
                                        <StarIcon color="white" className="marquee-star star-icon" />
                                    </IconButton>
                                    <Typography className="marquee-text georama-medium" whiteSpace="nowrap">
                                        {userData?.marque}
                                        {/* Mahindra offers various insurance policies for new vehicles with potential discounts and offers. */}
                                    </Typography>
                                </Box>
                            </Box>
                        ))}
                    </Box>
                </Marquee >
            </Box >
        </>
    )
}

export default MarqueeInfo