import { Bar } from 'react-chartjs-2';
import { ZAxis } from 'recharts';

const data = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
        {
            label: 'Converted Leads',
            backgroundColor: '#FF9F40',
            data: [200, 180, 156, 170, 190, 210],
            // barThickness: 20,
            categoryPercentage: 0.5, // reduces bar width, increases gap
            barPercentage: 0.9,
            order: 10, // Bar order
        },
        {
            label: 'Total leads with conversion %',
            backgroundColor: '#FF3D3D',
            data: [220, 200, 180, 160, 200, 195],
            // barThickness: 20,
            categoryPercentage: 0.5, // reduces bar width, increases gap
            barPercentage: 0.9,
            order: 10, // Bar order
        },
        {
            label: '% Conversion',
            type: 'line',
            data: [20, 30, 18, 45, 25, 35],
            borderColor: '#00B86B',
            backgroundColor: '#00B86B',
            yAxisID: 'y1',
            tension: 0.4,
            pointBackgroundColor: '#00B86B',
            pointBorderColor: '#fff',
            pointRadius: 5,
            fill: false,
            order: 1,
        },
    ],
};

// const options = {
//     responsive: true,
//     plugins: {
//         legend: { position: 'bottom' },
//     },
// };

const options = {
    responsive: true,
    plugins: {
        legend: {
            position: 'bottom',
            labels: {
                usePointStyle: true,
                pointStyle: 'circle',
                font: {
                    size: 12, // Label text font size
                    weight: 'bold'
                },
                // padding: 20, // Optional: adds space between legend items
                boxWidth: 6, // Circle diameter (smaller than font size)
                boxHeight: 6, // Circle height (smaller than font size)
            },
        },
        // tooltip: {
        //     enabled: true,
        //     callbacks: {
        //         label: function (context) {
        //             return `${context.dataset.label}: ${context.parsed.y}`;
        //         }
        //     }
        // }
        tooltip: {
            enabled: true,
            callbacks: {
                label: function (context) {
                    if (context.dataset.label === '% Conversion') {
                        return `${context.dataset.label}: ${context.parsed.y}%`;
                    }
                    return `${context.dataset.label}: ${context.parsed.y}`;
                }
            }
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            position: 'left',
            title: { display: false },
            grid: { display: true },
            ticks: { color: '#333' }
        },
        y1: {
            beginAtZero: true,
            position: 'right',
            min: 0,
            max: 80,
            grid: { drawOnChartArea: false },
            ticks: {
                callback: (value) => `${value}%`,
                // color: '#00B86B',
            },
            title: { display: false }
        },
        x: {
            grid: { display: false }
        }
        // y: {
        //     display: true, // Hide y-axis numbers and grid
        //     grid: { display: false },
        //     ticks: { display: false }
        // },
        // x: {
        //     grid: { display: false }
        // }
    }
};

const PerformanceBarChart = () => <Bar data={data} options={options} />;

export default PerformanceBarChart;
