import { useSelector } from 'react-redux';
import { Navigate, useParams } from 'react-router-dom';
import { decryptRoute } from '../services/encrypt';

const ProtectedRoute = ({ isAuthenticated, children }) => {
  const { encrypted } = useParams();
  const userData = useSelector((state) => state?.user?.loggedData);
  const fetchUserByManager = useSelector((state) => state?.user?.fetchUserByManager);

  const defaultUrls = !(userData?.callingFlag === 'Y' || fetchUserByManager?.length) ? '/profile' :
    `/editmispoutlet/create,/admindashboard,/managerdashboard,/callqueue,/callqueue/customerdetails,/customerSearch,${fetchUserByManager?.length > 0 ? '/assignLeads' : ''},/profile,/forgot`;
  const allowedUrls = useSelector((state) => state?.user?.featureAccess.map(fa => fa.Url)).concat([defaultUrls.split(',')]);

  if (!isAuthenticated && !allowedUrls.includes(decryptRoute(decodeURIComponent(encrypted)))) {
    return <Navigate to="/" replace />;
  }
  return children;
};

export default ProtectedRoute;