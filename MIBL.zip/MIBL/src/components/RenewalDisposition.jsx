import { useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip as ChartTooltip, LineController, BarController, PieController, ScatterController, DoughnutController } from 'chart.js';
import { Grid, Typography, Box, FormControl, InputLabel, Select, MenuItem, Button, Tooltip } from '@mui/material';
import dispositionsvg from "../assets/images/managerdashboard/disposition.svg";
import { reportDownload } from '../services/api';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { useSelector } from 'react-redux';
import BackdropLoader from './Loader/BackdropLoader';
import useMediaQuery from '@mui/material/useMediaQuery';
import dateFilter from "../assets/images/dashboard/dateFilter.svg";
import FilterDialog from '../modals/FilterDialog';
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";

ChartJS.register(ArcElement, ChartTooltip, LineController, BarController, PieController, ScatterController, DoughnutController);

const chartOptions = {
    cutout: '56%',
    plugins: {
        tooltip: { enabled: false },
        legend: { display: false }
    },
    responsive: true,
    maintainAspectRatio: false
};

const RenewalDisposition = ({ dispositiondata, onApplyFilters }) => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const userDetails = useSelector((state) => state.user.loggedData);
    const [report, setReports] = useState('');
    const [loading, setLoading] = useState(false);
    const [filterModalOpen, setFilterModalOpen] = useState(false);
    const reportList = []

    const [appliedFilters, setAppliedFilters] = useState({});

    const handleApplyFilters = (filters) => {
        setAppliedFilters(filters);
    };

    const handleChangeReports = (event) => {
        setReports(event.target.value);
    };

    const downloadExcelData = async () => {
        try {
            setLoading(true);
            const fieldValue = report === "Promise to pay Tracker" ? "Ready to Pay" : ""
            const type = report === "Promise to pay Tracker" ? "promiseToPayTracker" : report === "Not Contactable Summary" ? "NotContactable" : report === "Renewal Pipe Line" ? "renewalPipeLine" : report === "Daily Agent-wise Call & Renewal Report" ? "dailyAgentWiseCallRenewal" : report === "Dealer-wise Revenue & Retention Report" ? "dealerWiseRevenueAndRetention" : "";
            const payload = {
                "fileName": report,
                "fieldValue": fieldValue,
                "type": type,
                "roleId": userDetails.roleId,
                "userId": userDetails.user_id,
                roleType: userDetails.roleType,
                "dealerId": userDetails.dealerCode
            }
            const result = await reportDownload(payload);

            if (result && result.data) {
                // Create a download link
                const blob = new Blob([result.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', report + '.xlsx');
                document.body.appendChild(link);
                link.click();
                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error('Error downloading Excel file:', error);
        } finally {
            setLoading(false);
        }
    };

    const colorMap = {
        // "Converted/ Won": '#A56EFF',
        "Leads Contacted": '#28B463',
        "Policy Renewed": '#F39C12',
        "Renewal Retention": '#3498DB',
        "Revenue Generated": '#884A39',
        "Conversion Rate": '#E74C3C',
        "TAT Compliance": '#566573'
    };

    return (
        <>
            <BackdropLoader loading={loading} />
            <Box display="flex" flexWrap={"wrap"} justifyContent="space-between" alignItems="center" mb={1.3}>
                <Box display={'flex'} alignItems="center" justifyContent={"center"} gap={1} mb={1}>
                    <img src={dispositionsvg} alt="" />
                    <Typography className="georama-SemiBold fs-14" >Renewal Summary</Typography>
                </Box>
                {/* <Box display={'flex'} flexWrap={"wrap"} alignItems="center" justifyContent={"center"} gap={1}>
                    <Button className='bg-white text-gray text-capitalize border-light-gray border-radius-8' onClick={() => setFilterModalOpen(true)}>
                        <img className='px-1' src={dateFilter} alt="" />
                        <Typography className="dropdown-label" mt={0.5} px={1}>All Filter</Typography>
                    </Button>
                </Box> */}
                {/* <Box display={'flex'} flexWrap={"wrap"} alignItems="center" justifyContent={"center"} gap={1}>
                    <FormControl className='bg-white' size="small" sx={{ minWidth: isMobile ? 100 : 110, maxWidth: isMobile ? 100 : 110, borderRadius: 2 }}>
                        <InputLabel id="menu-select-label" className="dropdown-label fs-10" >Reports</InputLabel>
                        <Select
                            className='fs-12'
                            labelId="menu-select-label"
                            id="menu-select"
                            value={report}
                            label="Select Menu"
                            onChange={handleChangeReports}
                        >
                            <MenuItem className='fs-12' value="Renewal Pipe Line">Renewal Pipeline (Hot/Warm)</MenuItem>
                            <MenuItem className='fs-12' value="Promise to pay Tracker">Promise to Pay Tracker</MenuItem>
                            <MenuItem className='fs-12' value="Not Contactable Summary">Not Contactable Summary</MenuItem>

                            <MenuItem className='fs-12' value="Daily Agent-wise Call & Renewal Report">Daily Agent-wise Call & Renewal Report</MenuItem>
                            <MenuItem className='fs-12' value="Dealer-wise Revenue & Retention Report">Dealer-wise Revenue & Retention Report</MenuItem>
                        </Select>
                    </FormControl>
                    <Button
                        disabled={!report}
                        onClick={downloadExcelData}
                        endIcon={<FileDownloadIcon />}
                        className={`btn-common-red ${isMobile ? 'fs-10' : 'fs-14'}`}
                    >
                        Download
                    </Button>
                    <FormControl className='' size="small" sx={{ maxWidth: 150, minWidth: 150, backgroundColor: '#ffffff', borderRadius: 2 }}>
                        <InputLabel id="menu-select-label">Download</InputLabel>
                        <Select
                            labelId="menu-select-label"
                            id="menu-select"
                            value={downloadoption}
                            label="Select Menu"
                            onChange={handleChangeDownload}
                        >
                            <MenuItem value="Excel">Excel</MenuItem>
                        </Select>
                    </FormControl>
                </Box> */}
            </Box>

            <Grid container spacing={2}>
                {dispositiondata && dispositiondata.map((item, index) => {
                    let colorHex = item.Name;
                    // If item.color is a color name, map it to hex
                    if (colorMap[item.Name]) {
                        colorHex = colorMap[item.Name];
                    }
                    const data = {
                        // labels: [item.Name, 'Remaining'],
                        labels: [item.Name],
                        datasets: [
                            {
                                data: [item.percentage, 100 - Number(item.percentage)],
                                // data: [25, 100 - Number(25)],
                                // backgroundColor: [item.color, '#E6E6E6'],
                                backgroundColor: [colorHex, '#E6E6E6'],
                                borderWidth: 0
                            }
                        ]
                    };

                    // Tooltip text for specific metrics
                    let tooltipText = "";
                    if (item.Name === "Renewal Retention") {
                        tooltipText = "(Policies Secured / Eligible Leads) × 100";
                    } else if (item.Name === "Conversion Rate") {
                        tooltipText = "(Policy Secured Against Leads Contacted / Leads Contacted) × 100";
                    }

                    return (
                        <Grid
                            key={index}
                            size={{ xs: 12, sm: 6, md: 4, lg: 3 }}
                            sx={{
                                border: '1px solid #e0e0e0',
                                borderRadius: '8px',
                                px: 0, py: 1,
                            }}
                        >
                            <Box display={'flex'} justifyContent={"start"} alignItems="center" gap={isMobile ? 1 : 0} >
                                <Box sx={{ width: isMobile ? 45 : 60, height: isMobile ? 45 : 40, ml: 1 }}>
                                    <Doughnut data={data} options={chartOptions} />
                                </Box>

                                <Box>
                                    <Typography className='georama-semiBold fs-20' sx={{ color: colorHex, fontWeight: 600 }}>
                                        {item.Name === "Renewal Retention" ? item.count !== null ? item.count + " %" : 0 + "%" : item.Name === "Conversion Rate" ? item.count + " %" : item.count}
                                    </Typography>

                                    <Box display="flex" alignItems="center" gap={1}>
                                        <Typography className='georama-Regular fs-14'>
                                            {item.Name === "Renewal Retention" ? "Renewal Retention %" : item.Name === "Conversion Rate" ? "Conversion Rate %" : item.Name}
                                        </Typography>
                                        {/* Tooltip only for specific items */}
                                        {(item.Name === "Renewal Retention" ||
                                            item.Name === "Conversion Rate") && (
                                                <Tooltip title={tooltipText} arrow>
                                                    <InfoOutlinedIcon
                                                        fontSize="small"
                                                        sx={{ color: "#555", fontSize: 13, cursor: "pointer" }}
                                                    />
                                                </Tooltip>
                                            )}
                                    </Box>
                                </Box>
                            </Box>
                        </Grid>
                    );
                })}
            </Grid>

            {/* <FilterDialog
                open={filterModalOpen}
                onClose={() => setFilterModalOpen(false)}
                onApplyFilters={onApplyFilters}
            /> */}

        </>

    );
};

export default RenewalDisposition;

