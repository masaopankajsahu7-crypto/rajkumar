import HistoryIcon from '@mui/icons-material/History';
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer';
import { Box, Button, Tooltip, useMediaQuery } from '@mui/material';
import { useState } from 'react';
import { useSelector } from 'react-redux';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CustomizationIcon from '../assets/icons/CustomizationIcon';
import { getHistory } from '../services/api';
import CommunicationHistoryDrawer from './Drawers/CommunicationDrawer';
import CustomizationDrawer from './Drawers/CustomizationDrawer';
import Disposition from './Drawers/Disposition';

export default function SideFloatingButtons({ communicationData, dispositionData, MobileNumber, refresh, quotationData }) {
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [openCommDrawer, setopenCommDrawer] = useState(false);
    const [openDispDrawer, setopenDispDrawer] = useState(false);
    const [openCustDrawer, setopenCustDrawer] = useState(false);
    const [communication, setCommunication] = useState([]);
    const isCaller = useSelector((state) => state.user.isCaller);
    const userDetails = useSelector((state) => state?.user?.loggedData);

    const fetchCommunication = async (row) => {
        let response = await getHistory({ leadId: row.leadId, clusterId: row.clusterId, vehicleName: row.vehicleName, type: 'communication' });
        setCommunication(response.communication);
    }

    const handleCloseCommDrawer = () => {
        setopenCommDrawer(false);
    };
    const handleOpenCommDrawer = () => {
        setopenCommDrawer(true);
        fetchCommunication(communicationData);
    };

    const handleCloseDispDrawer = () => {
        setopenDispDrawer(false);
    };
    const handleOpenDispDrawer = () => {
        setopenDispDrawer(true);
    };

    const handleCloseCustDrawer = () => {
        setopenCustDrawer(false);
    };
    const handleOpenCustDrawer = () => {
        setopenCustDrawer(true);
    };

    const showMessage = (msg, type = 'success') => {
        if (type === 'success') {
            toast.success(msg, {
                autoClose: 1000,
                onClose: () => refresh()
            });
        } else {
            toast.error(msg, {
                autoClose: 1500,
                // onClose: () => refresh()
            });
        }
    };

    const showError = (msg) => {
        setopenCustDrawer(false);
        setTimeout(() => {
            toast.error(msg, { autoClose: 6000 });
        }, 1000);
    };

    return (
        <>
            <Box sx={{
                position: 'fixed',
                right: 0,
                top: isMobile ? 90 : 170,
                display: 'flex',
                flexDirection: 'column',
                alignItems: "center",
                alignSelf: 'anchor-center',
                gap: 2,
                zIndex: 999,
            }}
            >
                {/* Manage Qoute Button */}
                {isCaller === 'caller' &&
                    // userDetails?.modifyQuoteFlag === "Yes" &&
                    <>
                        <Tooltip title="Manage Qoute" placement="left">
                            <Button
                                onClick={handleOpenCustDrawer}
                                variant="contained"
                                sx={{
                                    textTransform: 'capitalize',
                                    backgroundColor: '#424242',
                                    color: '#fff',
                                    borderTopLeftRadius: '20px',
                                    borderBottomLeftRadius: '20px',
                                    borderTopRightRadius: 0,
                                    borderBottomRightRadius: 0,
                                    px: 0,
                                    py: 1.8,
                                    minWidth: '40px',
                                    writingMode: 'sideways-lr',
                                    textOrientation: 'mixed',
                                    fontSize: '13px',
                                    fontWeight: 'bold',
                                }}
                            >
                                <CustomizationIcon sx={{ py: 0.7, width: 15, height: 15 }} />
                                Manage Qoute
                            </Button>
                        </Tooltip>
                    </>}

                {/* Disposition Button */}
                {isCaller === 'caller' &&
                    <Tooltip title="Disposition" placement="right">
                        <Button
                            onClick={handleOpenDispDrawer}
                            variant="contained"
                            sx={{
                                textTransform: 'capitalize',
                                backgroundColor: '#e53935',
                                color: '#fff',
                                borderTopLeftRadius: '20px',
                                borderBottomLeftRadius: '20px',
                                borderTopRightRadius: 0,
                                borderBottomRightRadius: 0,
                                px: 0,
                                py: 2,
                                minWidth: '40px',
                                writingMode: 'sideways-lr',
                                textOrientation: 'mixed',
                                fontSize: '13px',
                                fontWeight: 'bold',
                            }}
                        >
                            <HistoryIcon sx={{ width: '18px' }} />
                            Disposition
                        </Button>
                    </Tooltip>
                }

                {/* Communication Button */}
                <Tooltip title="Communication" placement="left">
                    <Button
                        onClick={handleOpenCommDrawer}
                        variant="contained"
                        sx={{
                            textTransform: 'capitalize',
                            backgroundColor: '#424242',
                            color: '#fff',
                            borderTopLeftRadius: '20px',
                            borderBottomLeftRadius: '20px',
                            borderTopRightRadius: 0,
                            borderBottomRightRadius: 0,
                            px: 0,
                            py: 1.8,
                            minWidth: '40px',
                            writingMode: 'sideways-lr',
                            textOrientation: 'mixed',
                            fontSize: '13px',
                            fontWeight: 'bold',
                        }}
                    >
                        <QuestionAnswerIcon sx={{ width: '15px' }} />
                        Communication
                    </Button>
                </Tooltip>
            </Box >

            <CommunicationHistoryDrawer open={openCommDrawer} onClose={handleCloseCommDrawer} communication={communication} />
            <CustomizationDrawer open={openCustDrawer} onClose={handleCloseCustDrawer} quotationData={quotationData} MobileNumber={MobileNumber} showError={showError} />
            <Disposition MobileNumber={MobileNumber} open={openDispDrawer} onClose={handleCloseDispDrawer} dispositionData={dispositionData} showMessage={showMessage} />
            <ToastContainer autoClose={1000} />
        </>
    );
}