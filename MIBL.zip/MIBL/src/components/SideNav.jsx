import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import MuiDrawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import { styled } from '@mui/material/styles';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import dashboardSvg from "../assets/images/sidenavbar/dashboard.svg";
import dealerList from '../assets/images/sidenavbar/dealerList.svg';
import leadpool from '../assets/images/sidenavbar/leadpool.svg';
import renewalSvg from "../assets/images/sidenavbar/renewal.svg";
import reportsSvg from "../assets/images/sidenavbar/reports.svg";
import rolespermissions from '../assets/images/sidenavbar/rolespermissions.svg';
import settingsSvg from "../assets/images/sidenavbar/settings.svg";
import setup from '../assets/images/sidenavbar/setup.svg';
import uploaddata from '../assets/images/sidenavbar/uploaddata.svg';
import usermanagement from '../assets/images/sidenavbar/usermanagement.svg';
import { decryptRoute, encryptRoute } from '../services/encrypt';
import { sideNavWidth } from '../utils/Constants';
import { DrawerHeader } from './Header';

import leaderboardSvg from "../assets/images/sidenavbar/Leader-Board.svg";
import performanceSvg from "../assets/images/sidenavbar/Performance.svg";
import tatSvg from "../assets/images/sidenavbar/tat-monitoring.svg";

import { useMediaQuery } from '@mui/material';
import Tooltip from '@mui/material/Tooltip';
import { useState } from 'react';
import { useSelector } from 'react-redux';

const openedMixin = (theme) => ({
  width: sideNavWidth,
  [theme.breakpoints.down('sm')]: {
    width: `calc(${theme.spacing(7)} + 1px)`,
  },
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(6)} + 1px)`
});

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    width: sideNavWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
    ...(open && {
      ...openedMixin(theme),
      '& .MuiDrawer-paper': openedMixin(theme),
    }),
    ...(!open && {
      ...closedMixin(theme),
      '& .MuiDrawer-paper': closedMixin(theme),
    }),
  }),
);

export default function SideNav({ open }) {
  const isMobile = useMediaQuery('(min-width:320px) and (max-width:600px)');
  const [tooltipOpen, setTooltipOpen] = useState(null);

  const { encrypted } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  // Resolve the active path. Encrypted MIBL routes carry the path in the :encrypted param;
  // plain routes (e.g. the embedded /clients flow) carry it directly in the URL pathname.
  let activePath = '';
  try {
    activePath = encrypted ? decryptRoute(decodeURIComponent(encrypted)) : location.pathname;
  } catch {
    activePath = location.pathname;
  }
  const allowedUrls = useSelector((state) => state?.user?.featureAccess.map(fa => fa.Url));
  const userdata = useSelector((state) => state.user.loggedData);
  const dashboard = userdata?.roleType === "MIBL" ? '/admindashboard' : '/managerdashboard';

  const menuItems = [
    { text: 'Dashboard', icon: dashboardSvg, route: dashboard },
    { text: 'Renewal Dashboard', icon: renewalSvg, route: '/renewalDashboard' },
    { text: 'Dealer Setup', icon: setup, route: '/mispoutlet' },
    { text: 'Dealer List', icon: dealerList, route: '/editmispoutlet' },
    { text: 'Lead Pool', icon: leadpool, route: '/leadpool' },
    { text: 'User Management', icon: usermanagement, route: '/userManagement' },
    { text: 'Role & Permissions', icon: rolespermissions, route: '/role' },
    { text: 'Reports', icon: reportsSvg, route: '/reports' },
    { text: 'System Configuration', icon: settingsSvg, route: '/systemconfiguration' },
    { text: 'Data Upload', icon: uploaddata, route: '/dataupload' },
    { text: 'Follow Up Efficiency Dashboard', icon: tatSvg, route: '/tatMonitoring' },
    { text: 'Leader Board', icon: leaderboardSvg, route: '/leaderBoard' },
    { text: 'Performance Dashboard', icon: performanceSvg, route: '/performanceDashboard' },
    { text: 'Clients', icon: usermanagement, route: '/clients' },
    { text: 'Portfolios', icon: usermanagement, route: '/portfolios' },
    { text: 'Opportunities', icon: usermanagement, route: '/opportunities' },
  ];

  // The embedded Client/Opportunity flow lives on its own plain (non-encrypted) paths.
  const isPlainRoute = (route) =>
    route.startsWith('/clients') || route.startsWith('/opportunities') || route.startsWith('/portfolios');

  // const getSelectedIndex = () => {
  //   const response = menuItems.findIndex(item => location.pathname.startsWith(item.route));
  //   return response;
  // };

  const handleNavClick = (index, route) => {
    if (isPlainRoute(route)) {
      navigate(route);
      return;
    }
    const encryptedPath = encryptRoute(route);
    navigate(`/${encodeURIComponent(encryptedPath)}`);
    // navigate(route)
  };

  return (
    <Drawer variant="permanent" open={open}>
      <DrawerHeader />
      <Divider />
      <List className='sidenav-list'>
        {menuItems
          // .filter(m => allowedUrls.some(au => !!au && au.startsWith(m.route)) || m.route === dashboard || m.route === '/tatMonitoring' || m.route === '/leaderBoard' || m.route === '/performanceDashboard')
          .filter(m =>
            allowedUrls.some(au => !!au && au.startsWith(m.route)) ||
            m.route === dashboard ||
            m.route === '/opportunities' ||
            m.route === '/portfolios'
          )
          .map((item, index) => {
            const isActive = activePath.startsWith(item.route);
            return (
              <Box
                py={1}
                key={index}
                onClick={() => handleNavClick(index, item.route)}
                className={isActive ? 'sidenav-list-selected' : 'cursor-pointer tab-text'}
              >
                <ListItem button disablePadding sx={{ ml: 1.3, my: 0.2 }}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Tooltip
                      sx={{ py: 1 }}
                      title={item.text}
                      placement="right"
                      open={tooltipOpen === index}
                      onClose={() => setTooltipOpen(null)}
                      disableHoverListener
                      disableTouchListener
                    >
                      <img
                        src={item.icon}
                        alt={item.text}
                        style={{
                          paddingTop: isMobile ? 3 : 0,
                          paddingBottom: isMobile ? 3 : 0,
                          width: 26,
                          height: 24,
                          filter: isActive ? 'brightness(0) invert(1)' : 'none',
                          transition: 'filter 0.2s ease',
                        }}
                        onClick={(e) => {
                          if (isMobile) {
                            // e.stopPropagation();        // ⛔ prevent navigation
                            setTooltipOpen(index);      // ✅ show tooltip
                            setTimeout(() => {
                              setTooltipOpen(null);
                            }, 1000);                   // auto hide
                          }
                        }}
                        onMouseEnter={() => !isMobile && setTooltipOpen(index)}
                        onMouseLeave={() => !isMobile && setTooltipOpen(null)}
                      />
                    </Tooltip>
                  </Box>

                  {!isMobile && <ListItemText
                    primary={item.text}
                    primaryTypographyProps={{
                      sx: {
                        whiteSpace: "normal",      // allow wrapping
                        wordBreak: "break-word",   // break long words
                        overflowWrap: "break-word",
                      },
                    }}
                  />}
                </ListItem>
              </Box>
            )
          })}
      </List >
    </Drawer >
  );
}
