import { Box, Card, CardContent, Typography } from "@mui/material";
import trendSvg from "../../assets/images/target/trend.svg";

const ChartCard = ({ title, children }) => {
  return (
    <Card sx={{ borderRadius: 3, boxShadow: "none" }}>
      <CardContent>
        <Box display={"flex"} alignItems={"center"}>
          <img src={trendSvg} alt="" />
          <Typography variant="subtitle1" fontWeight={600} ml={1}>
            {title}
          </Typography>
        </Box>
        <Box height={300}>
          {children}
        </Box>
      </CardContent>
    </Card>
  );
};

export default ChartCard;