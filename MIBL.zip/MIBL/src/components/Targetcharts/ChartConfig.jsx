import { BarElement, CategoryScale, Chart as ChartJS, Legend, LinearScale, LineElement, PointElement, Tooltip } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, Tooltip, Legend);

const formatLakhs = (value) => {
    if (!value) return "0";
    return `${(value / 100000).toFixed(1)} lakhs`;
};

export const commonOptions = {
    responsive: true,
    maintainAspectRatio: false,

    plugins: {
        legend: {
            display: true,
            position: "top",
            align: "end",
            labels: {
                usePointStyle: true,
                pointStyle: "circle",
                boxWidth: 2,
                boxHeight: 6,
                pointStyleWidth: 8,
                padding: 20,
            },
        },
        tooltip: {
            backgroundColor: "#111",
            titleColor: "#fff",
            bodyColor: "#fff",
            callbacks: {
                label: function (context) {
                    const val = context.raw || 0;
                    return `${context.dataset.label}: ${formatLakhs(val)}`;
                },
            },
        },
    },

    scales: {
        x: {
            grid: { display: false },
            barPercentage: 0.5,
            categoryPercentage: 0.5,
        },
        y: {
            grid: { color: "#f2f1f1" },
            ticks: {
                callback: function (value) {
                    return formatLakhs(value);
                },
            },
        },
    },
};

const computeAxisBounds = (values = []) => {
    const cleaned = values
        .map((v) => Number(v) || 0)
        .filter((v) => Number.isFinite(v) && v >= 0);

    const maxValue = cleaned.length ? Math.max(...cleaned) : 0;
    const minValue = 0;

    if (maxValue === 0) {
        return { min: 0, max: 100000, stepSize: 20000 };
    }

    const roughStep = (maxValue - minValue) / 5 || maxValue / 5;
    const magnitude = 10 ** Math.floor(Math.log10(roughStep));
    const normalized = roughStep / magnitude;

    let niceNormalized = 1;
    if (normalized > 5) niceNormalized = 10;
    else if (normalized > 2) niceNormalized = 5;
    else if (normalized > 1) niceNormalized = 2;

    const stepSize = niceNormalized * magnitude;
    const max = Math.ceil(maxValue / stepSize) * stepSize;

    return { min: minValue, max, stepSize };
};

export const getPremiumChartOptions = (values = []) => {
    const bounds = computeAxisBounds(values);

    return {
        ...commonOptions,
        scales: {
            ...commonOptions.scales,
            y: {
                ...commonOptions.scales.y,
                min: bounds.min,
                max: bounds.max,
                ticks: {
                    ...commonOptions.scales.y.ticks,
                    stepSize: bounds.stepSize,
                },
            },
        },
    };
};