import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import { Box, Tooltip as MuiTooltip, Typography } from "@mui/material";
import {
    ArcElement,
    Chart as ChartJS,
    Legend,
    Tooltip
} from "chart.js";
import { useState } from "react";
import { Doughnut } from "react-chartjs-2";
import percentageSvg from "../../assets/images/target/percentage.svg";

// ✅ Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

const GaugeChart = ({ title, current = 0, target = 0, tooltip }) => {
    const clampPercent = (value) => Math.max(0, Math.min(100, Number(value) || 0));
    const currentValue = clampPercent(current);
    const targetValue = clampPercent(target);

    const getLowRangeColor = (index, maxIndex) => {
        if (maxIndex <= 0) return "#16A34A";
        const t = index / maxIndex;
        const r = Math.round(225 + (245 - 225) * t);
        const g = Math.round(29 + (158 - 29) * t);
        const b = Math.round(72 + (11 - 72) * t);
        return `rgb(${r}, ${g}, ${b})`;
    };

    // Dynamic color band:
    // 0 -> target  : red to orange gradient
    // target -> 100: green
    const data = {
        datasets: [
            {
                data: Array.from({ length: 100 }, () => 1),
                backgroundColor: Array.from({ length: 100 }, (_, i) => (
                    i < targetValue ? getLowRangeColor(i, Math.max(1, targetValue - 1)) : "#16A34A"
                )),
                borderWidth: 0,
                circumference: 180,
                rotation: 270,
                cutout: "73%",
            },
        ],
    };

    // ✅ Tooltip Config
    const options = {
        responsive: true,
        
        plugins: {
            legend: { display: false },
            tooltip: {
                enabled: false,
                callbacks: {
                    label: () => [
                        `Achievement: ${currentValue}%`,
                        `Target: ${targetValue}%`
                    ],

                    labelColor: (context) => {
                        const lineIndex = context.formattedValue.includes("Achievement")
                            ? 0
                            : 1;

                        return {
                            borderColor: lineIndex === 0 ? "#E11D48" : "#16A34A",
                            backgroundColor: lineIndex === 0 ? "#E11D48" : "#16A34A",
                        };
                    }
                }
            }
        }
    };

    // Achievement pointer
    const needlePlugin = (value) => ({
        id: "needle",
        afterDatasetDraw(chart) {
            const { ctx } = chart;
            const meta = chart.getDatasetMeta(0);

            const xCenter = meta.data[0].x;
            const yCenter = meta.data[0].y;

            const angle = Math.PI + (value / 100) * Math.PI;

            ctx.save();
            ctx.translate(xCenter, yCenter);
            ctx.rotate(angle);

            ctx.beginPath();
            ctx.moveTo(0, -4);
            ctx.lineTo(chart.width * 0.35, 0);
            ctx.lineTo(0, 4);
            ctx.fillStyle = "#111";
            ctx.fill();

            ctx.restore();

            // center dot
            ctx.beginPath();
            ctx.arc(xCenter, yCenter, 5, 0, Math.PI * 2);
            ctx.fillStyle = "#111";
            ctx.fill();
        },
    });

    // Target marker (black line on arc)
    const targetMarkerPlugin = (value) => ({
        id: "targetMarker",
        afterDatasetDraw(chart) {
            const { ctx } = chart;
            const meta = chart.getDatasetMeta(0);
            const arc = meta.data[0];
            if (!arc) return;

            const angle = Math.PI + (value / 100) * Math.PI;
            const { x, y, innerRadius, outerRadius } = arc;

            ctx.save();
            ctx.beginPath();
            ctx.moveTo(x + Math.cos(angle) * innerRadius, y + Math.sin(angle) * innerRadius);
            ctx.lineTo(x + Math.cos(angle) * outerRadius, y + Math.sin(angle) * outerRadius);
            ctx.strokeStyle = "#111";
            ctx.lineWidth = 2.5;
            ctx.lineCap = "round";
            ctx.stroke();
            ctx.restore();
        },
    });

    // ✅ Tick Labels Plugin (0–100 step 10)
    const tickPlugin = {
        id: "ticks",
        afterDraw(chart) {
            const { ctx } = chart;
            const meta = chart.getDatasetMeta(0);

            const xCenter = meta.data[0].x;
            const yCenter = meta.data[0].y;
            const radius = meta.data[0].outerRadius;

            ctx.save();
            ctx.font = "12px Arial";
            ctx.fillStyle = "#666";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            for (let i = 0; i <= 100; i += 10) {
                const angle = Math.PI + (i / 100) * Math.PI;

                // Reduce radius to place numbers inside the arc (e.g. radius - 20)
                const r = radius - 75;

                const x = xCenter + Math.cos(angle) * r;
                const y = yCenter + Math.sin(angle) * r;

                ctx.fillText(i, x, y);
            }

            ctx.restore();
        },
    };

    const [showTooltip, setShowTooltip] = useState(false);

    return (
        <>
            <Box display="flex" justifyContent="space-between" mb={0}>
                <Box display="flex" alignItems="center">
                    <img src={percentageSvg} alt="" />

                    <Typography mx={1} fontWeight="bold">
                        {title}
                    </Typography>

                    <MuiTooltip title={tooltip} arrow>
                        <InfoOutlinedIcon
                            sx={{
                                fontSize: 16,
                                cursor: "pointer",
                                color: "#666"
                            }}
                        />
                    </MuiTooltip>
                </Box>

                <Box display="flex" gap={2}>
                    <Typography fontSize={14}>
                        <span className="fs-20 highlight-red">●</span> Achievement
                    </Typography>

                    <Typography fontSize={14}>
                        <span className="fs-20 highlight-green">●</span> Target
                    </Typography>
                </Box>
            </Box>

            {/* Chart */}
            <Box
                position="relative"
                width={500}
                height={400}
                mx="auto"
                onMouseEnter={() => setShowTooltip(true)}
                onMouseLeave={() => setShowTooltip(false)}
            // position="relative" width={500} height={400} mx="auto"
            >
                <Doughnut
                    data={data}
                    options={options}
                    plugins={[targetMarkerPlugin(targetValue), needlePlugin(currentValue), tickPlugin]}
                />

                {/* Center Value */}
                <Typography
                    variant="h6"
                    fontWeight="bold"
                    position="absolute"
                    top="82%"
                    left="50%"
                    sx={{ transform: "translate(-50%, -50%)" }}
                >
                    {currentValue}%
                </Typography>

                {/* Static Right Info Box */}
                {showTooltip && (
                    <Box
                        sx={{
                            position: "absolute",
                            right: -50,
                            top: "48%",
                            transform: "translateY(-50%)",
                            bgcolor: "#4B4B4B",
                            color: "#fff",
                            px: 1,
                            py: 1.2,
                            borderRadius: "12px",
                            fontSize: 14,
                            boxShadow: "0 4px 12px rgba(0,0,0,0.25)",
                            minWidth: 150,
                            zIndex: 10,
                        }}
                    >
                        <Box display="flex" alignItems="center" gap={1} mb={0.8}>
                            <Box
                                sx={{
                                    width: 10,
                                    height: 10,
                                    borderRadius: "50%",
                                    bgcolor: "#E11D48",
                                }}
                            />
                            <span>Current : {currentValue}%</span>
                        </Box>

                        <Box display="flex" alignItems="center" gap={1}>
                            <Box
                                sx={{
                                    width: 10,
                                    height: 10,
                                    borderRadius: "50%",
                                    bgcolor: "#16A34A",
                                }}
                            />
                            <span>Target : {targetValue}%</span>
                        </Box>
                    </Box>
                )}
            </Box>

            {/* Right Tooltip Box */}
            {/* <Box
                sx={{
                    position: "absolute",
                    right: -20,
                    top: 120,
                    bgcolor: "#374151", // dark grey
                    color: "#fff",
                    px: 2,
                    py: 1.5,
                    borderRadius: "10px",
                    fontSize: 13,
                    boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
                    minWidth: "140px"
                }}
            >
                <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                    <Box
                        sx={{
                            width: 8,
                            height: 8,
                            borderRadius: "50%",
                            bgcolor: "#E11D48" // red
                        }}
                    />
                    <span>Current : {current}%</span>
                </Box>

                <Box display="flex" alignItems="center" gap={1}>
                    <Box
                        sx={{
                            width: 8,
                            height: 8,
                            borderRadius: "50%",
                            bgcolor: "#16A34A" // green
                        }}
                    />
                    <span>Target : {target}%</span>
                </Box>
            </Box> */}
        </>
    );
};

export default GaugeChart;