import { Bar } from "react-chartjs-2";
import ChartCard from "./ChartCard";
import { commonOptions } from "./ChartConfig";
import { Backdrop } from "@mui/material";

// labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]

export default function NetAddonPremium({ data }) {
    const chartData = {
        labels: data.labels,
        datasets: [
            {
                type: "bar",
                label: "Achievement",
                data: data.achievement,
                backgroundColor: "#ef4444",
                barThickness: 20,
            },
            {
                type: "line",
                label: "Target",
                data: data.target,
                borderColor: "#FF8A00",   // ✅ use borderColor for line
                backgroundColor: "#FDC0701A", // ✅ shaded area
                fill: true,               // ✅ IMPORTANT
                tension: 0,             // optional (smooth curve)
                pointBackgroundColor: "#FF8A00",
                // width of the line can be controlled by borderWidth
                borderWidth: 1,
                barThickness: 20,
                borderradius: 4

            }
        ],
    };

    return (
        <ChartCard title="Net Add-on Premium">
            <Bar data={chartData} options={commonOptions} />
        </ChartCard>
    );
}