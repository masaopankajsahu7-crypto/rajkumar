import { Bar } from "react-chartjs-2";
import ChartCard from "./ChartCard";
import { commonOptions } from "./ChartConfig";


// const data = {
// labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
//     datasets: [
//         {
//             label: "Target",
//             data: [31, 29, 30, 28, 32, 34],
//             backgroundColor: "#f97316",
//             borderRadius: 6,
//             categoryPercentage: 0.2,
//             barPercentage: 0.7 // 👈 creates gap
//         },
//         {
//             label: "Achievement",
//             data: [20, 19, 34, 30, 20, 22],
//             backgroundColor: "#ef4444",
//             borderRadius: 6,
//             categoryPercentage: 0.2,
//             barPercentage: 0.7
//         },
//     ],
// };

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default function NetODPremium({ data }) {

    // ✅ normalize to 12 months
    const monthMap = {};
    data.labels.forEach((m, i) => {
        monthMap[m] = {
            achievement: data.achievement[i],
            target: data.target[i],
        };
    });

    const labels = MONTHS;

    const achievement = labels.map((m) => monthMap[m]?.achievement || 0);
    const target = labels.map((m) => monthMap[m]?.target || 0);

    const chartData = {
        labels,
        datasets: [
            {
                label: "Achievement",
                data: achievement,
                backgroundColor: "#ef4444",
                borderRadius: 6,
                categoryPercentage: 0.5,
                barPercentage: 0.6,
            },
            {
                label: "Target",
                data: target,
                backgroundColor: "#f97316",
                borderRadius: 6,
                categoryPercentage: 0.5,
                barPercentage: 0.6,
            }
        ],
    };

    return (
        <ChartCard title="Net OD Premium">
            <Bar data={chartData} options={commonOptions} />
        </ChartCard>
    );
}