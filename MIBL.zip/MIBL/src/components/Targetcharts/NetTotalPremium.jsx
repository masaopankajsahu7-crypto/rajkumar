import { Bar } from "react-chartjs-2";
import ChartCard from "./ChartCard";
import { commonOptions } from "./ChartConfig";

// const labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];

export default function NetTotalPremium({ data }) {
    const chartData = {
        labels: data.labels,
        datasets: [
            {
                type: "bar",
                label: "Achievement",
                data: data.achievement,
                backgroundColor: "#F22222",
                barThickness: 20,
                borderRadius: 4,
                clip: false,
            },
            {
                type: "line",
                width: 2,
                label: "Target",
                data: data.target,
                backgroundColor: "#22c55e",
                barThickness: 20,
                borderRadius: 4,
                 clip: false,
            },
        ],
    };

    return (
        <ChartCard title="Net Total Premium">
            <Bar data={chartData} options={commonOptions} />
        </ChartCard>
    );
}