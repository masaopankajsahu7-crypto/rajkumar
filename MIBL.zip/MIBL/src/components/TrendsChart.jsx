import React, { useState, useMemo } from "react";
import {
    Chart as ChartJS,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement,
    Tooltip,
    Legend,
    Filler,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { Stack, Typography, Box, useMediaQuery } from "@mui/material";

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend, Filler);

const ChartComponent = ({ renewalDailyWeeklyTrends = [] }) => {
    // renewalDailyWeeklyTrends = [
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 1 (2025-11)",
    //         "week_start": "2025-11-01",
    //         "week_end": "2025-11-07",
    //         "leads_contacted": 0,
    //         "conversion_rate": 0,
    //         "total_net_premium": 0
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 2 (2025-11)",
    //         "week_start": "2025-11-08",
    //         "week_end": "2025-11-14",
    //         "leads_contacted": 0,
    //         "conversion_rate": 0,
    //         "total_net_premium": 0
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 3 (2025-11)",
    //         "week_start": "2025-11-15",
    //         "week_end": "2025-11-21",
    //         "leads_contacted": 0,
    //         "conversion_rate": 0,
    //         "total_net_premium": 0
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 4 (2025-11)",
    //         "week_start": "2025-11-22",
    //         "week_end": "2025-11-28",
    //         "leads_contacted": 0,
    //         "conversion_rate": 0,
    //         "total_net_premium": 0
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 5 (2025-11)",
    //         "week_start": "2025-11-29",
    //         "week_end": "2025-11-30",
    //         "leads_contacted": 0,
    //         "conversion_rate": 0,
    //         "total_net_premium": 0
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 1 (2025-12)",
    //         "week_start": "2025-12-01",
    //         "week_end": "2025-12-07",
    //         "leads_contacted": 138,
    //         "conversion_rate": 23.19,
    //         "total_net_premium": 662546
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 2 (2025-12)",
    //         "week_start": "2025-12-08",
    //         "week_end": "2025-12-14",
    //         "leads_contacted": 924,
    //         "conversion_rate": 24.68,
    //         "total_net_premium": 6615273
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 3 (2025-12)",
    //         "week_start": "2025-12-15",
    //         "week_end": "2025-12-21",
    //         "leads_contacted": 95,
    //         "conversion_rate": 6.32,
    //         "total_net_premium": 128176
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 4 (2025-12)",
    //         "week_start": "2025-12-22",
    //         "week_end": "2025-12-28",
    //         "leads_contacted": 0,
    //         "conversion_rate": 0,
    //         "total_net_premium": 0
    //     },
    //     {
    //         "metric_type": "Weekly",
    //         "period": "Week 5 (2025-12)",
    //         "week_start": "2025-12-29",
    //         "week_end": "2025-12-31",
    //         "leads_contacted": 0,
    //         "conversion_rate": 0,
    //         "total_net_premium": 0
    //     }
    // ]
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    const [metricType] = useState("Weekly");
    const [visibleMetric, setVisibleMetric] = useState("leads");

    const filteredData = useMemo(() => {
        return renewalDailyWeeklyTrends
            .filter((d) => d.metric_type === metricType)
            .sort((a, b) => new Date(a.week_start) - new Date(b.week_start));
    }, [renewalDailyWeeklyTrends, metricType]);

    // ✅ Labels (Week 1, Week 2, etc.)
    let currentMonth = "";
    let weekCounter = 1;
    const labels = filteredData.map((item) => {
        const month = new Date(item.week_start).toLocaleString("en-US", { month: "short" });
        if (month !== currentMonth) {
            currentMonth = month;
            weekCounter = 1;
        }
        const label = `Week ${weekCounter}`;
        weekCounter++;
        if (weekCounter > 5) weekCounter = 1;
        return label;
    });

    const chartData = {
        labels,
        datasets: [
            {
                label: "Conversion Rate (%)",
                data: filteredData.map((d) => d.conversion_rate),
                borderColor: "#f6a821",
                backgroundColor: "#f5d8a6ff",
                tension: 0.6,
                pointRadius: 3,
                // pointBackgroundColor: "#f6a821",
                borderWidth: 2,
                fill: true,
                yAxisID: "y1",
                order: 2,
            },
            {
                label: "Number of Contacted Leads",
                data: filteredData.map((d) => d.leads_contacted),
                borderColor: "#e74c3c",
                backgroundColor: "rgba(231,76,60,0.2)",
                tension: 0.6,
                pointRadius: 3,
                pointBackgroundColor: "#e74c3c",
                borderWidth: 2,
                fill: true,
                hidden: visibleMetric !== "leads",
                yAxisID: "y",
                order: 1,
            },
            {
                label: "Net Premium Amount",
                data: filteredData.map((d) => d.total_net_premium),
                borderColor: "#2ecc71",
                // backgroundColor: "rgba(246,168,33,0.2)",
                backgroundColor: "rgba(46,204,113,0.2)",
                tension: 0.4,
                pointRadius: 3,
                // pointBackgroundColor: "#2ecc71",
                borderWidth: 2,
                fill: true,
                hidden: visibleMetric !== "premium",
                yAxisID: "y",
                order: 1,
            },
        ],
    };

    const options = {
        responsive: true,
        interaction: { mode: "index", intersect: false },
        plugins: {
            legend: { display: false },
            tooltip: {
                callbacks: {
                    title: function (context) {
                        const dataPoint = filteredData[context[0].dataIndex];
                        const start = new Date(dataPoint.week_start).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                        });
                        const end = new Date(dataPoint.week_end).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                        });
                        return `${dataPoint.period} (${start} - ${end})`;
                    },
                    label: function (context) {
                        const label = context.dataset.label;
                        const value = context.formattedValue;
                        if (label.includes("Premium")) return `${label}: ₹${value}`;
                        if (label.includes("Conversion")) return `${label}: ${value}%`;
                        return `${label}: ${value}`;
                    },
                },
            },
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: { color: "#555" },
                grid: { color: "rgba(200,200,200,0.2)" },
                title: { display: true, text: "Leads / Amount", color: "#555" },
            },
            y1: {
                beginAtZero: true,
                position: "right",
                ticks: {
                    color: "#f6a821",
                    callback: (value) => `${value}%`,
                },
                grid: { drawOnChartArea: false },
                title: { display: true, text: "Conversion Rate (%)", color: "#f6a821" },
            },
            x: {
                ticks: { color: "#555", font: { size: 8, weight: 600 } },
                grid: { display: false },
            },
        },
    };

    // ✅ Legend
    const legendItems = [
        { key: "conversion", label: "Conversion Rate", color: "#f6a821", fixed: true },
        { key: "leads", label: "Number of Contacted Leads", color: "#e74c3c" },
        { key: "premium", label: "Net Premium Amount", color: "#2ecc71" },
    ];

    return (
        <Box sx={{ width: "100%", height: 300, mb: 8 }}>
            <Line data={chartData}
                options={{
                    ...options,
                    maintainAspectRatio: false,
                }}
            // options={options}
            />

            {/* ✅ Custom Legend */}
            <Stack
                direction="row"
                justifyContent="center"
                alignItems="center"
                spacing={isMobile ? 1.5 : 3}
                sx={{ mt: 2 }}
            >
                {legendItems?.map((item) => (
                    <Stack
                        key={item.key}
                        direction="row"
                        alignItems="center"
                        spacing={1}
                        onClick={() => {
                            if (item.fixed) return; // conversion always visible
                            setVisibleMetric(item.key);
                        }}
                        sx={{
                            cursor: item.fixed ? "default" : "pointer",
                            opacity:
                                item.fixed || visibleMetric === item.key ? 1 : 0.5,
                            transform:
                                visibleMetric === item.key || item.fixed
                                    ? "scale(1.05)"
                                    : "scale(1)",
                            transition: "all 0.25s ease",
                        }}
                    >
                        <Box
                            sx={{
                                width: isMobile ? 12 : 10,
                                height: isMobile ? 8 : 10,
                                borderRadius: "50%",
                                backgroundColor: item.color,
                            }}
                        />
                        <Typography
                            variant="body2"
                            sx={{
                                fontSize: isMobile ? 10 : 12,
                                fontWeight: 500,
                                color:
                                    visibleMetric === item.key || item.fixed
                                        ? item.color
                                        : "text.secondary",
                            }}
                        >
                            {item.label}
                        </Typography>
                    </Stack>
                ))}
            </Stack>
        </Box>
    );
};

export default ChartComponent;
