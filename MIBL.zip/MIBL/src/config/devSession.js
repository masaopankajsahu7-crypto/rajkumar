/**
 * DEV-ONLY login bypass.
 * When DEV_BYPASS_LOGIN is true, the app auto-seeds this mock session into Redux
 * so you land in the authenticated layout (and the dashboard) without going through login.
 *
 * roleType drives which navigation chrome renders (see AppLayout / Header / SideNav):
 *   - 'MIBL'   -> left SideNav is shown (Client tab appears there)
 *   - 'DEALER' -> top tabs with the "Others" dropdown are shown (Client appears in that menu)
 * Flip DEV_ROLE_TYPE below to preview the other navigation.
 *
 * Set DEV_BYPASS_LOGIN to false before any real build.
 */
export const DEV_BYPASS_LOGIN = false;

export const DEV_ROLE_TYPE = 'MIBL'; // 'MIBL' | 'DEALER'

export const DEV_MOCK_SESSION = {
  loggedIn: true,
  token: 'dev-bypass-token',
  user: {
    otp: 'No',
    role: 'MIBL Admin',
    email: 'dev.bypass@mibl.local',
    adFlag: 'N',
    marque: null,
    roleId: 1,
    is_lock: 'U',
    sapCode: null,
    user_id: 8,
    UserName: 'Dev User',
    roleType: DEV_ROLE_TYPE,
    lead_flag: '',
    dealerCode: null,
    parentCode: null,
    callingFlag: 'Y',
    lastLoginDate: '2026-06-30 10:00:00',
    team_email_flag: '',
  },
  featureAccess: [
    { Url: '/client', AccessName: 'View', FeatureName: 'Client' },
    { Url: '/mispoutlet', AccessName: 'View', FeatureName: 'Dealer Setup' },
    { Url: '/editmispoutlet', AccessName: 'View', FeatureName: 'Dealer List' },
    { Url: '/leadpool', AccessName: 'View', FeatureName: 'Lead Pool' },
    { Url: '/userManagement', AccessName: 'View', FeatureName: 'User Management' },
    { Url: '/role', AccessName: 'View', FeatureName: 'Role & Permissions' },
    { Url: '/reports', AccessName: 'View', FeatureName: 'Reports' },
    { Url: '/systemconfiguration', AccessName: 'View', FeatureName: 'System Configuration' },
    { Url: '/dataupload', AccessName: 'View', FeatureName: 'Data Upload' },
    { Url: '/tatMonitoring', AccessName: 'Yes', FeatureName: 'FollowUp Efficiency' },
    { Url: '/leaderBoard', AccessName: 'Yes', FeatureName: 'LeaderBoard' },
    { Url: '/performanceDashboard', AccessName: 'Yes', FeatureName: 'PerformanceDashboard' },
    { Url: '/renewalDashboard', AccessName: 'Yes', FeatureName: 'Renewal Dashboard' },
  ],
};
