// export const baseUrl = 'https://cb56b3922506.ngrok-free.app';
//export const baseUrl = 'http://10.54.224.168:8080/api/v1';
// export const baseUrl = "http://192.168.1.40:8080/api/v1";
// export const baseUrl = 'http://10.241.182.217:8080/api/v1';
// export const baseUrl = 'http://192.168.1.55:8081';
// export const baseUrl = 'http://localhost:2000';
// export const baseUrl = 'https://ppmcm.mahindrainsure.com/CRM/api/v1';
// export const baseUrl = "https://umspcm.mahindrainsure.com/CRM/api/v1";
// Same-origin CRM backend. Local dev proxies /CRM to UAT; deployed builds use current host.
export const baseUrl = "/CRM/api/v1";
// export const baseUrl = 'https://mysaathi.mahindrainsure.com/CRM/api/v1';
// export const baseUrl = "https://5a82-2409-40c0-6e-f46d-6d77-585c-47ba-d8f.ngrok-free.app/api/v1";
// export const baseUrl = 'http://192.168.1.88:8080/api/v1';  // Pankaj
// export const baseUrl = 'http://10.109.140.217:8080/api/v1';  // Pankaj
// export const baseUrl = 'http://192.168.1.39:8080/api/v1';  // Krishna
// export const baseUrl = 'http://192.168.1.8:8080/api/v1';   // Vaibhav
