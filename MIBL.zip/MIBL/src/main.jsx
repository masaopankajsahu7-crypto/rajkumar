import { ThemeProvider } from "@mui/material/styles"
import { createRoot } from 'react-dom/client'
import { Provider } from 'react-redux'
import theme from "../src/theme/theme.js"
import App from './App.jsx'
import './index.css'
import store from './redux/store.jsx'
import { encryptRoute } from './services/encrypt.jsx'

const KPI_DASHBOARD_PATH = '/kpi-dashboard';
const PERFORMANCE_DASHBOARD_PATH = '/performance-dashboard';
const AES_JSON_CIPHER_PATH = '/aes-json-cipher';
const KPI_DASHBOARD_SHORTCUTS = [
  { ctrlKey: true, altKey: true, code: 'KeyO' },
  { ctrlKey: true, altKey: true, code: 'KeyK' },
  { altKey: true, shiftKey: true, code: 'KeyO' },
];
const PERFORMANCE_DASHBOARD_SHORTCUTS = [
  { ctrlKey: true, altKey: true, code: 'KeyP' },
];
const AES_JSON_CIPHER_SHORTCUTS = [
  { ctrlKey: true, altKey: true, code: 'KeyE' },
];

const isShortcutMatch = (event, shortcut) =>
  (!shortcut.ctrlKey || event.ctrlKey || event.getModifierState?.('AltGraph')) &&
  (!shortcut.altKey || event.altKey || event.getModifierState?.('AltGraph')) &&
  (!shortcut.shiftKey || event.shiftKey) &&
  event.code === shortcut.code;

const isKpiDashboardShortcut = (event) =>
  KPI_DASHBOARD_SHORTCUTS.some((shortcut) => isShortcutMatch(event, shortcut)) ||
  (
    (event.ctrlKey || event.getModifierState?.('AltGraph')) &&
    (event.altKey || event.getModifierState?.('AltGraph')) &&
    (event.key?.toLowerCase() === 'o' || event.keyCode === 79)
  );

const isPerformanceDashboardShortcut = (event) =>
  PERFORMANCE_DASHBOARD_SHORTCUTS.some((shortcut) => isShortcutMatch(event, shortcut)) ||
  (
    (event.ctrlKey || event.getModifierState?.('AltGraph')) &&
    (event.altKey || event.getModifierState?.('AltGraph')) &&
    (event.key?.toLowerCase() === 'p' || event.keyCode === 80)
  );

const isAesJsonCipherShortcut = (event) =>
  AES_JSON_CIPHER_SHORTCUTS.some((shortcut) => isShortcutMatch(event, shortcut)) ||
  (
    (event.ctrlKey || event.getModifierState?.('AltGraph')) &&
    (event.altKey || event.getModifierState?.('AltGraph')) &&
    (event.key?.toLowerCase() === 'e' || event.keyCode === 69)
  );

const navigateToDashboardPath = (path) => {
  const targetPath = `/${encodeURIComponent(encryptRoute(path))}`;
  if (window.location.pathname !== targetPath) {
    window.history.pushState({}, '', targetPath);
    window.dispatchEvent(new PopStateEvent('popstate'));
  }
};

const navigateToKpiDashboard = () => navigateToDashboardPath(KPI_DASHBOARD_PATH);
const navigateToPerformanceDashboard = () => navigateToDashboardPath(PERFORMANCE_DASHBOARD_PATH);
const navigateToAesJsonCipher = () => navigateToDashboardPath(AES_JSON_CIPHER_PATH);

const openKpiDashboard = (event) => {
  if (!isKpiDashboardShortcut(event)) return;

  event.preventDefault();
  event.stopPropagation();
  sessionStorage.setItem('lastKpiDashboardShortcut', new Date().toISOString());
  navigateToKpiDashboard();
};

const openPerformanceDashboard = (event) => {
  if (!isPerformanceDashboardShortcut(event)) return;

  event.preventDefault();
  event.stopPropagation();
  sessionStorage.setItem('lastPerformanceDashboardShortcut', new Date().toISOString());
  navigateToPerformanceDashboard();
};

const openAesJsonCipher = (event) => {
  if (!isAesJsonCipherShortcut(event)) return;

  event.preventDefault();
  event.stopPropagation();
  sessionStorage.setItem('lastAesJsonCipherShortcut', new Date().toISOString());
  navigateToAesJsonCipher();
};

window.openKpiDashboard = navigateToKpiDashboard;
window.openPerformanceDashboard = navigateToPerformanceDashboard;
window.openAesJsonCipher = navigateToAesJsonCipher;

window.addEventListener('keydown', openKpiDashboard, true);
window.addEventListener('keyup', openKpiDashboard, true);
document.addEventListener('keydown', openKpiDashboard, true);
document.addEventListener('keyup', openKpiDashboard, true);
window.addEventListener('keydown', openPerformanceDashboard, true);
window.addEventListener('keyup', openPerformanceDashboard, true);
document.addEventListener('keydown', openPerformanceDashboard, true);
document.addEventListener('keyup', openPerformanceDashboard, true);
window.addEventListener('keydown', openAesJsonCipher, true);
window.addEventListener('keyup', openAesJsonCipher, true);
document.addEventListener('keydown', openAesJsonCipher, true);
document.addEventListener('keyup', openAesJsonCipher, true);

createRoot(document.getElementById('root')).render(
  <Provider store={store}>
    <ThemeProvider theme={theme}>
      <App />
    </ThemeProvider>
  </Provider>
)
