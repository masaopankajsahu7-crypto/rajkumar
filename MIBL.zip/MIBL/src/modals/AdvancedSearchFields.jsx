import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import KeyboardDoubleArrowDownIcon from '@mui/icons-material/KeyboardDoubleArrowDown';
import { Box, Button, Collapse, Grid, MenuItem, TextField, Tooltip } from "@mui/material";

const AdvancedSearchFields = ({ search, handleSearchInput, handleSearch, isMobile, setSearch, handleToggleAdvanced, showAdvanced, clearSearchFields }) => {

    return (
        <>
            <Box className="body-whitebg" py={1}>
                <Grid className="body-whitebg" container spacing={isMobile ? 0.5 : 0}>
                    <TextField sx={{ mr: isMobile ? 0 : 2, ml: isMobile ? 0 : 1, pl: 1.5 }} className="custom-textfield body-formbg" value={search.name} placeholder="Name" onChange={(e) => handleSearchInput('name', e.target.value)}
                    />
                    <TextField sx={{ mr: isMobile ? 0 : 2, pl: 1.5 }} value={search.phoneNumber} placeholder="Phone Number" onChange={(e) => handleSearchInput('phoneNumber', e.target.value)}
                        className="custom-textfield body-formbg"
                    />
                    <TextField sx={{ mr: isMobile ? 0 : 2, pl: 1.5 }} value={search.vinNumber} placeholder="Chassis/VIN Number" onChange={(e) => handleSearchInput('vinNumber', e.target.value)}
                        className="custom-textfield body-formbg"
                    />
                    <TextField sx={{ pl: 1.5 }} value={search.registrationNo} placeholder="Registration No." onChange={(e) => handleSearchInput('registrationNo', e.target.value)}
                        className="custom-textfield body-formbg"
                    />
                    {!isMobile &&
                        <>
                            <Tooltip title="Advanced Search">
                                <Button onClick={handleToggleAdvanced}
                                    sx={{
                                        backgroundColor: "rgb(235, 231, 231)",
                                        display: 'flex',
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        minWidth: 0,
                                        px: 1,
                                        pt: 0.8,
                                        borderRadius: 2,
                                        mx: 2
                                    }}
                                >
                                    {showAdvanced
                                        ? <KeyboardArrowUpIcon sx={{ color: 'black' }} />
                                        : <KeyboardDoubleArrowDownIcon sx={{ color: 'black' }} />}
                                </Button>
                            </Tooltip>
                            <Button
                                className="btn-common-red"
                                onClick={() => handleSearch(1)}
                                sx={{ width: "82px" }}
                            >
                                Search
                            </Button>
                            {Object.values(search).some(val => val != "") &&
                                <Button
                                    className="text-capitalize highlight-red"
                                    sx={{ width: "85px" }}
                                    onClick={() => {
                                        clearSearchFields();
                                        setSearch({
                                            name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: ''
                                        });
                                    }}
                                >
                                    Clear All
                                </Button>}
                            {/* </Box> */}
                        </>
                    }

                    {!isMobile &&
                        <Collapse
                            in={showAdvanced}
                            timeout="auto"
                            unmountOnExit
                            sx={{
                                position: 'absolute',
                                top: '100%',
                                bgcolor: 'white',
                                left: 0,
                                right: 0,
                                zIndex: 10,
                                boxShadow: 2,
                                borderRadius: 2,
                                pb: 2,
                                px: 1
                            }}
                        >
                            <Box mt={2}>
                                <Grid container columnSpacing={isMobile ? 0.2 : 2.8} rowSpacing={isMobile ? 0.2 : 1.5}>
                                    <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }}>
                                        <TextField
                                            sx={{ pl: 1.5 }}
                                            className="custom-textfield body-formbg"
                                            placeholder="Policy No"
                                            fullWidth
                                            value={search.policyNo}
                                            onChange={(e) => handleSearchInput("policyNo", e.target.value)}
                                        />
                                    </Grid>

                                    <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }}>
                                        <TextField
                                            sx={{ pl: 1.5 }}
                                            className="custom-textfield body-formbg"
                                            placeholder="Policy Tenure"
                                            fullWidth
                                            value={search.policyTenure}
                                            onChange={(e) => handleSearchInput("policyTenure", e.target.value)}
                                        />
                                    </Grid>

                                    <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }}>
                                        <TextField
                                            sx={{ pl: 1.5 }}
                                            className="custom-textfield body-formbg"
                                            select
                                            fullWidth
                                            value={search.policyType}
                                            onChange={(e) => handleSearchInput("policyType", e.target.value)}
                                            SelectProps={{ displayEmpty: true }}
                                        >
                                            <MenuItem value="" disabled>
                                                Policy Type
                                            </MenuItem>
                                            {["new", "renewal", "rollover"].map((option) => (
                                                <MenuItem key={option} value={option}>
                                                    {option.charAt(0).toUpperCase() + option.slice(1)}
                                                </MenuItem>
                                            ))}
                                        </TextField>
                                    </Grid>

                                    <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }} >
                                        <TextField
                                            sx={{ pl: 1.5 }}
                                            className="custom-textfield body-formbg"
                                            placeholder="Make"
                                            fullWidth
                                            value={search.make}
                                            onChange={(e) => handleSearchInput("make", e.target.value)}
                                        />
                                    </Grid>

                                    <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }} >
                                        <TextField
                                            sx={{ pl: 1.5 }}
                                            className="custom-textfield body-formbg"
                                            placeholder="Model"
                                            fullWidth
                                            value={search.model}
                                            onChange={(e) => handleSearchInput("model", e.target.value)}
                                        />
                                    </Grid>

                                    <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }} >
                                        <TextField
                                            sx={{ pl: 1.5 }}
                                            className="custom-textfield body-formbg"
                                            placeholder="Variant"
                                            fullWidth
                                            value={search.variant}
                                            onChange={(e) => handleSearchInput("variant", e.target.value)}
                                        />
                                    </Grid>

                                    <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }} >
                                        <TextField
                                            sx={{ pl: 1.5 }}
                                            className="custom-textfield body-formbg"
                                            select
                                            fullWidth
                                            value={search.vehicleClass}
                                            onChange={(e) => handleSearchInput("vehicleClass", e.target.value)}
                                            SelectProps={{ displayEmpty: true }}
                                        >
                                            <MenuItem value="" disabled>
                                                Vehicle Class
                                            </MenuItem>
                                            {["pcp", "pcv", "gcv", "misd", "tw"].map((option) => (
                                                <MenuItem key={option} value={option}>
                                                    {option.toUpperCase()}
                                                </MenuItem>
                                            ))}
                                        </TextField>
                                    </Grid>

                                    <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }}>
                                        <TextField
                                            sx={{ pl: 1.5 }}
                                            className="custom-textfield body-formbg"
                                            placeholder="Engine No"
                                            fullWidth
                                            value={search.engineNo}
                                            onChange={(e) => { handleSearchInput("engineNo", e.target.value) }}
                                        />
                                    </Grid>
                                </Grid>
                            </Box>
                        </Collapse>}

                    {isMobile &&
                        <>
                            <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }}>
                                <TextField
                                    sx={{ pl: 1.5 }}
                                    className="custom-textfield body-formbg"
                                    placeholder="Policy No"
                                    fullWidth
                                    value={search.policyNo}
                                    onChange={(e) => handleSearchInput("policyNo", e.target.value)}
                                />
                            </Grid>

                            <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }}>
                                <TextField
                                    sx={{ pl: 1.5 }}
                                    className="custom-textfield body-formbg"
                                    placeholder="Policy Tenure"
                                    fullWidth
                                    value={search.policyTenure}
                                    onChange={(e) => handleSearchInput("policyTenure", e.target.value)}
                                />
                            </Grid>

                            <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }}>
                                <TextField
                                    sx={{ pl: 1.5 }}
                                    className="custom-textfield body-formbg"
                                    select
                                    fullWidth
                                    value={search.policyType}
                                    onChange={(e) => handleSearchInput("policyType", e.target.value)}
                                    SelectProps={{ displayEmpty: true }}
                                >
                                    <MenuItem value="" disabled>
                                        Policy Type
                                    </MenuItem>
                                    {["new", "renewal", "rollover"].map((option) => (
                                        <MenuItem key={option} value={option}>
                                            {option.charAt(0).toUpperCase() + option.slice(1)}
                                        </MenuItem>
                                    ))}
                                </TextField>
                            </Grid>

                            <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }} >
                                <TextField
                                    sx={{ pl: 1.5 }}
                                    className="custom-textfield body-formbg"
                                    placeholder="Make"
                                    fullWidth
                                    value={search.make}
                                    onChange={(e) => handleSearchInput("make", e.target.value)}
                                />
                            </Grid>

                            <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }} >
                                <TextField
                                    sx={{ pl: 1.5 }}
                                    className="custom-textfield body-formbg"
                                    placeholder="Model"
                                    fullWidth
                                    value={search.model}
                                    onChange={(e) => handleSearchInput("model", e.target.value)}
                                />
                            </Grid>

                            <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }} >
                                <TextField
                                    sx={{ pl: 1.5 }}
                                    className="custom-textfield body-formbg"
                                    placeholder="Variant"
                                    fullWidth
                                    value={search.variant}
                                    onChange={(e) => handleSearchInput("variant", e.target.value)}
                                />
                            </Grid>

                            <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }} >
                                <TextField
                                    sx={{ pl: 1.5 }}
                                    className="custom-textfield body-formbg"
                                    select
                                    fullWidth
                                    value={search.vehicleClass}
                                    onChange={(e) => handleSearchInput("vehicleClass", e.target.value)}
                                    SelectProps={{ displayEmpty: true }}
                                >
                                    <MenuItem value="" disabled>
                                        Vehicle Class
                                    </MenuItem>
                                    {["pcp", "pcv", "gcv", "misd", "tw"].map((option) => (
                                        <MenuItem key={option} value={option}>
                                            {option.toUpperCase()}
                                        </MenuItem>
                                    ))}
                                </TextField>
                            </Grid>

                            <Grid size={{ xs: 12, sm: 2.5, md: 2.3 }}>
                                <TextField
                                    sx={{ pl: 1.5 }}
                                    className="custom-textfield body-formbg"
                                    placeholder="Engine No"
                                    fullWidth
                                    value={search.engineNo}
                                    onChange={(e) => { handleSearchInput("engineNo", e.target.value) }}
                                />
                            </Grid>
                        </>}
                </Grid>
            </Box>
        </>
    );
}

export default AdvancedSearchFields;