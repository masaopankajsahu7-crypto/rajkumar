import { Button, Dialog, DialogTitle, DialogContent, IconButton, TextField, Box, Typography, Divider } from '@mui/material';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import { toast } from 'react-toastify';
import { secondaryGray } from '../utils/Colors';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        paddingTop: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#e53935',
    color: '#fff',
    padding: theme.spacing(2),
    fontWeight: 600,
}));

export default function DataUploadModal({ open, onClose, validateData, downloadErrorFile }) {

    return (
        <>
            <BootstrapDialog open={open} lockonClose={onClose} fullWidth maxWidth="xs">
                <DialogTitleWrapper className='reset-modal-header'>
                    <Typography className='fs-18'>
                        Download Error Records
                    </Typography>

                    <IconButton
                        aria-label="close"
                        onClick={() => onClose()}
                        sx={{ position: 'absolute', right: 8, top: 8, }}
                    >
                        <CloseIcon />
                    </IconButton>
                </DialogTitleWrapper>

                <Divider />

                <DialogContent >
                    <Box fullWidth >
                        <Typography className='text-labels'>{validateData?.statusMessage}</Typography>
                    </Box>

                    <Box display={"flex"} mt={2} mb={1} gap={1} justifyContent={"space-between"}>

                        {validateData &&
                            // validateData?.invalidRows &&
                            <Button
                                size="small"
                                variant="outlined"
                                disabled={!validateData}
                                sx={{
                                    borderRadius: 2,
                                    py: 0.8,
                                    textTransform: 'none',
                                    borderColor: '#ccc',
                                    color: '#fff',
                                    ...secondaryGray,
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 1,
                                }}
                                onClick={downloadErrorFile}
                            >
                                <Typography className="bulk-assign-head">Download Error Record</Typography>
                            </Button>}
                    </Box>
                </DialogContent>
            </BootstrapDialog >
        </>
    );
}



