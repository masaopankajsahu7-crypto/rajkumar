import React, { useEffect, useState } from "react";
import { Dialog, DialogTitle, DialogContent, Popover, IconButton, Grid, Button, FormControl, InputLabel, Select, MenuItem, Checkbox, Box, TextField, Typography, } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import { DateRange } from "react-date-range";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import { fetchRenewalDashboard, fetchRenewalFilterData } from "../services/api";
import { useDispatch, useSelector } from "react-redux";
import { setAgentListData, setconversionStatusList, setcurrentDispositionList, setDealerListData, setLeadTypeListData, setSegmentDataList, setsourceDataList, setvehicleTypeData } from "../redux/slices/dashboardSlice";

const FilterDialog = ({ onApplyFilters }) => {
    const dispatch = useDispatch();
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const userData = useSelector((state) => state.user.loggedData);

    const [selectedDealers, setSelectedDealers] = useState([]);
    const dealerListData = useSelector((state) => state.dashboard.dealerListData);
    const [dealerSelectOpen, setDealerSelectOpen] = useState(false);

    const [selectedAgents, setSelectedAgents] = useState([]);
    const agentList = useSelector((state) => state.dashboard.agentList);
    const [agentSelectOpen, setAgentSelectOpen] = useState(false);

    const [selectedLeadType, setSelectedLeadType] = useState([]);
    const LeadTypeList = useSelector((state) => state.dashboard.LeadTypeList);
    const [LeadTypeSelectOpen, setLeadTypeSelectOpen] = useState(false);

    const [selectedVehicleType, setSelectedVehicleType] = useState([]);
    const vehicleType = useSelector((state) => state.dashboard.vehicleType);
    const [vehicleTypeSelectOpen, setvehicleTypeSelectOpen] = useState(false);

    const [selectedSegment, setSelectedSegment] = useState([]);
    const segment = useSelector((state) => state.dashboard.segment);
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);

    const [selectedSource, setSelectedSource] = useState([]);
    const sourceData = useSelector((state) => state.dashboard.sourceData);
    const [sourceSelectOpen, setSourceSelectOpen] = useState(false);

    const [selectedCurrentDispo, setSelectedCurrentDispo] = useState([]);
    const currentDisposition = useSelector((state) => state.dashboard.currentDisposition);
    const [currentDispoSelectOpen, setCurrentDispoSelectOpen] = useState(false);

    const [selectedConversionStatus, setSelectedConversionStatus] = useState([]);
    const conversionStatus = useSelector((state) => state.dashboard.conversionStatus);
    const [conversionStatusSelectOpen, setConversionStatusSelectOpen] = useState(false);


    useEffect(() => {
        if (selectedDealers.length > 0) {
            const payload = {
                type: "MIBL",
                parentCodes: selectedDealers
            };
            fetchDealerRelatedData(payload);
        }
    }, [selectedDealers]);

    const fetchDealerRelatedData = async (payload) => {
        try {
            const response = await fetchRenewalFilterData(payload);
            if (response.statusCode === "200" || response.statusMessage === "Data fetched successfully") {
                dispatch(setAgentListData(response.data.result1));
                dispatch(setLeadTypeListData(response.data.result2));
                dispatch(setvehicleTypeData(response.data.result3));
                dispatch(setSegmentDataList(response.data.result4));
                dispatch(setsourceDataList(response.data.result5));
                dispatch(setcurrentDispositionList(response.data.result6));
                dispatch(setconversionStatusList(response.data.result7));
            }
        } catch (error) {
            console.error("Error fetching filter data:", error);
        }
    };


    // for Dealer
    const handleDealerChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedDealers.length === dealerListData.length) {
                setSelectedDealers([]);
            } else {
                setSelectedDealers(dealerListData.map(zone => zone.Zone));
            }
        } else {
            setSelectedDealers(value);
        }
    };

    // const handleDealerToggle = (dealerCode) => {
    //     if (dealerCode === "all") {
    //         if (selectedDealers.length === dealerListData.length) {
    //             setSelectedDealers([]);
    //         } else {
    //             setSelectedDealers(dealerListData.map((d) => d.parent_code));
    //         }
    //     } else {
    //         const currentIndex = selectedDealers.indexOf(dealerCode);
    //         const newSelected = [...selectedDealers];
    //         if (currentIndex === -1) {
    //             newSelected.push(dealerCode);
    //         } else {
    //             newSelected.splice(currentIndex, 1);
    //         }
    //         setSelectedDealers(newSelected);
    //     }
    // };

    const handleDealerToggle = (code) => {
        if (code === "all") {
            if (selectedDealers.length === dealerListData.length) {
                setSelectedDealers([]);
            } else {
                setSelectedDealers(dealerListData.map(d => d.dealer_id));
            }
        } else {
            setSelectedDealers(prevSelected => {
                const newSelected = prevSelected.includes(code)
                    ? prevSelected.filter(item => item !== code)
                    : [...prevSelected, code];
                return newSelected;
            });
        }
    };


    // for Agent
    const handleAgentToggle = (id) => {
        if (id === "all") {
            if (selectedAgents.length === agentList.length) {
                setSelectedAgents([]);
            } else {
                setSelectedAgents(agentList.map((a) => a.id));
            }
        } else {
            setSelectedAgents((prev) => {
                const alreadySelected = prev.includes(id);
                return alreadySelected
                    ? prev.filter((item) => item !== id)
                    : [...prev, id];
            });
        }
    };


    // for Lead Type
    const handleLeadTypeChange = (event) => {
        const value = event.target.value;
        if (value.includes("all")) {
            if (selectedLeadType.length === LeadTypeList.length) {
                setSelectedLeadType([]);
            } else {
                setSelectedLeadType(LeadTypeList.map(item => item.leadType));
            }
        } else {
            setSelectedLeadType(value);
        }
    };

    // ✅ Handle Lead Type toggle (for checkboxes)
    const handleLeadTypeToggle = (type) => {
        if (type === "all") {
            if (selectedLeadType.length === LeadTypeList.length) {
                setSelectedLeadType([]);
            } else {
                setSelectedLeadType(LeadTypeList.map(item => item.leadType));
            }
        } else {
            const currentIndex = selectedLeadType.indexOf(type);
            const newSelected = [...selectedLeadType];

            if (currentIndex === -1) newSelected.push(type);
            else newSelected.splice(currentIndex, 1);

            setSelectedLeadType(newSelected);
        }
    };


    // for Vehicle Type
    const handleVehicleTypeChange = (event) => {
        const value = event.target.value;
        if (value.includes("all")) {
            if (selectedVehicleType.length === vehicleType.length) {
                setSelectedVehicleType([]);
            } else {
                setSelectedVehicleType(vehicleType.map(item => item.vehicle_class));
            }
        } else {
            setSelectedVehicleType(value);
        }
    };

    // Handle checkbox toggle
    const handleVehicleTypeToggle = (type) => {
        if (type === "all") {
            if (selectedVehicleType.length === vehicleType.length) {
                setSelectedVehicleType([]);
            } else {
                setSelectedVehicleType(vehicleType.map(item => item.vehicle_class));
            }
        } else {
            const currentIndex = selectedVehicleType.indexOf(type);
            const newSelected = [...selectedVehicleType];

            if (currentIndex === -1) newSelected.push(type);
            else newSelected.splice(currentIndex, 1);

            setSelectedVehicleType(newSelected);
        }
    };




    // for Segment Type
    const handleSegmentChange = (event) => {
        const value = event.target.value;
        // The Select component's onChange gives an array when multiple is true,
        // unless the 'all' MenuItem is clicked which would return a string 'all'
        if (value.includes('all')) {
            // Toggle 'All' selection
            if (selectedSegment.length === segment.length) {
                setSelectedSegment([]); // Deselect all
            } else {
                // Select all segments using the 'Segment' property from the data
                setSelectedSegment(segment.map(item => item.Segment));
            }
        } else {
            // For individual item selection from a regular Select change
            setSelectedSegment(value); // value is the new array of selected segments
        }
    };

    const handleSegmentToggle = (segmentName) => {
        if (segmentName === 'all') {
            // Toggle 'All' selection
            if (selectedSegment.length === segment.length) {
                setSelectedSegment([]); // Deselect all
            } else {
                // Select all segments using the 'Segment' property from the data
                setSelectedSegment(segment.map(item => item.Segment));
            }
        } else {
            // Toggle individual segment
            const currentIndex = selectedSegment.indexOf(segmentName);
            const newSelected = [...selectedSegment];

            if (currentIndex === -1) {
                newSelected.push(segmentName);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedSegment(newSelected);
        }
    };


    const handleSourceChange = (event) => {
        const value = event.target.value;

        if (value.includes('all')) {
            // Toggle 'All' selection
            if (selectedSource.length === sourceData.length) {
                setSelectedSource([]); // Deselect all
            } else {
                // Select all sources using the 'datapull_name' property
                setSelectedSource(sourceData.map(item => item.datapull_name));
            }
        } else {
            setSelectedSource(value);
        }
    };

    const handleSourceToggle = (name) => {
        if (name === 'all') {
            if (selectedSource.length === sourceData.length) {
                setSelectedSource([]);
            } else {
                setSelectedSource(sourceData.map(item => item.datapull_name));
            }
        } else {
            const currentIndex = selectedSource.indexOf(name);
            const newSelected = [...selectedSource];

            if (currentIndex === -1) {
                newSelected.push(name);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedSource(newSelected);
        }
    };


    // for Current Disposition
    const handleCurrentDispositionChange = (event) => {
        const value = event.target.value;

        if (value.includes('all')) {
            // Toggle 'All' selection
            if (selectedCurrentDispo.length === currentDisposition.length) {
                setSelectedCurrentDispo([]); // Deselect all
            } else {
                // Select all dispositions using the 'disposition' property
                setSelectedCurrentDispo(currentDisposition.map(item => item.disposition));
            }
        } else {
            // For individual item selection from a regular Select change, value is the new array
            setSelectedCurrentDispo(value);
        }
    };

    const handleCurrentDispositionToggle = (dispo) => {
        if (dispo === 'all') {
            // Toggle 'All' selection
            if (selectedCurrentDispo.length === currentDisposition.length) {
                setSelectedCurrentDispo([]); // Deselect all
            } else {
                // Select all dispositions using the 'disposition' property
                setSelectedCurrentDispo(currentDisposition.map(item => item.disposition));
            }
        } else {
            // Toggle individual disposition
            const currentIndex = selectedCurrentDispo.indexOf(dispo);
            const newSelected = [...selectedCurrentDispo];

            if (currentIndex === -1) {
                newSelected.push(dispo);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedCurrentDispo(newSelected);
        }
    };



    // for Current Disposition
    const handleConversionStatusChange = (event) => {
        const value = event.target.value;

        if (value.includes('all')) {
            if (selectedConversionStatus.length === conversionStatus.length) {
                setSelectedConversionStatus([]); // Deselect all
            } else {
                setSelectedConversionStatus(conversionStatus.map(item => item.conversionStatus));
            }
        } else {
            setSelectedConversionStatus(value);
        }
    };

    const handleConversionStatusToggle = (status) => {
        if (status === 'all') {
            // Toggle 'All' selection
            if (selectedConversionStatus.length === conversionStatus.length) {
                setSelectedConversionStatus([]); // Deselect all
            } else {
                // Select all statuses using the 'conversionStatus' property
                setSelectedConversionStatus(conversionStatus.map(item => item.conversionStatus));
            }
        } else {
            // Toggle individual status
            const currentIndex = selectedConversionStatus.indexOf(status);
            const newSelected = [...selectedConversionStatus];

            if (currentIndex === -1) {
                newSelected.push(status);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedConversionStatus(newSelected);
        }
    };

    const fetchData = async () => {
        let payload;

        if (userData?.roleType === "MIBL") {
            payload = {
                type: "MIBL"
            }
        }

        try {
            const response = await fetchRenewalFilterData(payload);
            if (response.statusCode === "200" || response.statusMessage === "Data fetched successfully") {
                dispatch(setDealerListData(response.data.result3));
                // dispatch(setLeadTypeListData(response.data.result2));
            }
        } catch (error) {
            console.error("Error fetching filter data:", error);

        }
    }

    useEffect(() => {
        fetchData();
    }, []);


    const handleReset = () => {
        setSelectedDealers([]);
        setSelectedAgents([]);
        setSelectedLeadType([]);
        setSelectedVehicleType([]);
        setSelectedSegment([]);
        setSelectedSource([]);
        setSelectedCurrentDispo([]);
        setSelectedConversionStatus([]);
        setFromDate(null);
        setToDate(null);
    };

    // policyExpiryDate

    const [range, setRange] = useState([
        {
            startDate: null,
            endDate: null,
            key: 'selection'
        }
    ]);
    const [anchorEl, setAnchorEl] = useState(null);

    const handleOpen = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const openAnch = Boolean(anchorEl);

    const getDisplayValue = () => {
        const selectedRange = range[0];
        if (selectedRange.startDate && selectedRange.endDate) {
            const start = selectedRange.startDate.toLocaleDateString('en-GB');
            const end = selectedRange.endDate.toLocaleDateString('en-GB');
            return `${start} - ${end}`;
        }
        return "";
    };

    const handleDateRangeChange = (item) => {
        const newRange = [item.selection];
        setRange(newRange);

        const { startDate, endDate } = item.selection;

        if (startDate && endDate) {
            const getUTCDateString = (date) => {
                if (!date) return null;

                const year = date.getFullYear();
                const month = date.getMonth();
                const day = date.getDate();

                const utcDate = new Date(Date.UTC(year, month, day));

                const isoString = utcDate.toISOString();

                return isoString.split('T')[0];
            };

            const fromDatePlain = getUTCDateString(startDate);
            const toDatePlain = getUTCDateString(endDate);
            setFromDate(fromDatePlain);
            setToDate(toDatePlain);
        }
    };


    const handleApply = async () => {
        const filters = {
            dealerName: selectedDealers,
            agentName: selectedAgents,
            leadType: selectedLeadType,
            vehicleType: selectedVehicleType,
            segment: selectedSegment,
            leadSource: selectedSource,
            currentDisposition: selectedCurrentDispo,
            conversionStatus: selectedConversionStatus,
            policyExpiryDateFrom: fromDate || "",
            policyExpiryDateTo: toDate || "",
        };
        if (onApplyFilters) {
            await onApplyFilters(filters);
        }
    };


    return (
        <>
            {/* Dealer Name */}
            {userData?.roleType === "MIBL" &&
                <Box>
                    <FormControl
                        size="small"
                        sx={{
                            minWidth: 100,
                            maxWidth: 100,
                            backgroundColor: "#ffffff",
                            borderRadius: 2,
                        }}
                    >
                        <InputLabel id="dealer-label" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                            Dealer Name
                        </InputLabel>
                        <Select
                            className="fs-14"
                            labelId="dealer-label"
                            multiple
                            open={dealerSelectOpen}
                            onClose={() => setDealerSelectOpen(false)}
                            onOpen={() => setDealerSelectOpen(true)}
                            value={selectedDealers}
                            renderValue={(selected) => {
                                if (selected.length === dealerListData?.length) return "All";
                                const selectedNames = dealerListData
                                    .filter((d) => selected.includes(d.dealer_id))
                                    .map((d) => d.dealer_name)
                                    .join(", ");
                                return selectedNames || "Select Dealer";
                            }}
                            MenuProps={{
                                disableScrollLock: true,
                                PaperProps: {
                                    style: {
                                        maxHeight: 300,
                                        position: "fixed",
                                        zIndex: 1500,
                                    },
                                    sx: {
                                        "&::-webkit-scrollbar": { width: "4px" },
                                        "&::-webkit-scrollbar-thumb": {
                                            backgroundColor: "#d0cac9ff",
                                            borderRadius: "4px",
                                        },
                                        "&::-webkit-scrollbar-thumb:hover": { backgroundColor: "#e53935" },
                                    },
                                },
                            }}
                        >
                            {/* ✅ All Option */}
                            <MenuItem className="fs-14" disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all" onClick={() => handleDealerToggle("all")}>
                                <Checkbox
                                    sx={{
                                        "&.Mui-checked": { color: "#e53935" },
                                        "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                    }}
                                    checked={selectedDealers.length === dealerListData?.length}
                                    indeterminate={
                                        selectedDealers.length > 0 &&
                                        selectedDealers.length < dealerListData.length
                                    }
                                />
                                All
                            </MenuItem>

                            {/* ✅ Dealer List */}
                            <Box sx={{ maxHeight: 250, overflowY: "auto", pr: 1 }}>
                                {dealerListData && dealerListData?.map((dealer, index) => (
                                    <MenuItem
                                        className="fs-14"
                                        key={index}
                                        value={dealer.dealer_id}
                                        disableGutters
                                        sx={{ py: 0, px: 1, m: 0 }}
                                        onClick={() => handleDealerToggle(dealer.dealer_id)}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                            }}
                                            checked={selectedDealers.includes(dealer.dealer_id)}
                                        />
                                        {dealer.dealer_name}
                                    </MenuItem>
                                ))}
                            </Box>
                        </Select>
                    </FormControl>
                </Box>
            }



            {/* Policy Expiry Date Range */}
            <Box>
                <FormControl
                    size="small"
                    sx={{
                        minWidth: 100,
                        maxWidth: 100,
                        backgroundColor: "#ffffff",
                        borderRadius: 2,
                    }}
                >
                    {/* Label */}
                    <InputLabel htmlFor="policy-expiry" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                        Policy Expiry
                    </InputLabel>

                    {/* TextField with fixed width */}
                    <TextField
                        id="policy-expiry"
                        size="small"
                        value={getDisplayValue()}
                        onClick={handleOpen}
                        // placeholder="Select Date Range"
                        InputProps={{
                            // startAdornment: <CalendarMonthIcon sx={{ color: "#666", mr: 1 }} />,
                            readOnly: true,
                        }}
                        sx={{ width: 100 }} // Fixed width
                    />
                </FormControl>

                {/* Date Range Popover */}
                <Popover
                    open={openAnch}
                    anchorEl={anchorEl}
                    onClose={handleClose}
                    anchorOrigin={{
                        vertical: "bottom",
                        horizontal: "left",
                    }}
                >
                    <DateRange
                        editableDateInputs={true}
                        onChange={handleDateRangeChange}
                        moveRangeOnFirstSelection={false}
                        ranges={range}
                    />
                </Popover>
            </Box>



            {/* Agent Name */}
            <Box>
                <FormControl
                    size="small"
                    sx={{
                        minWidth: 100,
                        maxWidth: 100,
                        backgroundColor: "#ffffff",
                        borderRadius: 2,
                    }}
                >
                    <InputLabel id="agent-label" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                        Agent Name
                    </InputLabel>
                    <Select
                        labelId="agent-label"
                        multiple
                        open={agentSelectOpen}
                        onClose={() => setAgentSelectOpen(false)}
                        onOpen={() => setAgentSelectOpen(true)}
                        value={selectedAgents}
                        renderValue={(selected) => {
                            if (selected.length === agentList?.length) return "All";
                            const selectedNames = agentList
                                ?.filter((a) => selected.includes(a.id))
                                ?.map((a) => a.agentName)
                                ?.join(", ");
                            return selectedNames || "Select Agent";
                        }}
                        MenuProps={{
                            disableScrollLock: true,
                            PaperProps: {
                                style: {
                                    maxHeight: 300,
                                    position: "fixed",
                                    zIndex: 1500,
                                },
                                sx: {
                                    "&::-webkit-scrollbar": { width: "4px" },
                                    "&::-webkit-scrollbar-thumb": {
                                        backgroundColor: "#d0cac9ff",
                                        borderRadius: "4px",
                                    },
                                    "&::-webkit-scrollbar-thumb:hover": {
                                        backgroundColor: "#e53935",
                                    },
                                },
                            },
                        }}
                    >
                        {/* ✅ All Option */}
                        <MenuItem
                            disableGutters
                            sx={{ py: 0, px: 1, m: 0 }}
                            value="all"
                            onClick={() => handleAgentToggle("all")}
                        >
                            <Checkbox
                                sx={{
                                    "&.Mui-checked": { color: "#e53935" },
                                    "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                }}
                                checked={selectedAgents.length === agentList?.length}
                                indeterminate={
                                    selectedAgents.length > 0 &&
                                    selectedAgents.length < agentList.length
                                }
                            />
                            All
                        </MenuItem>

                        {/* ✅ Agent List */}
                        <Box sx={{ maxHeight: 250, overflowY: "auto", pr: 1 }}>
                            {agentList &&
                                agentList.map((agent, index) => (
                                    <MenuItem
                                        key={index}
                                        value={agent.id}
                                        disableGutters
                                        sx={{ py: 0, px: 1, m: 0 }}
                                        onClick={() => handleAgentToggle(agent.id)}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                            }}
                                            checked={selectedAgents.includes(agent.id)}
                                        />
                                        {agent.agentName}
                                    </MenuItem>
                                ))}
                        </Box>
                    </Select>
                </FormControl>
            </Box>



            {/* Lead Type */}
            <Box>
                <FormControl size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#fff', borderRadius: 2 }}>
                    <InputLabel id="leadType-label" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                        Lead Type
                    </InputLabel>
                    <Select
                        multiple
                        labelId="leadType-label"
                        open={LeadTypeSelectOpen}
                        onClose={() => setLeadTypeSelectOpen(false)}
                        onOpen={() => setLeadTypeSelectOpen(true)}
                        value={selectedLeadType}
                        onChange={handleLeadTypeChange}
                        renderValue={(selected) => {
                            if (selected.length === LeadTypeList.length) return "All";
                            return selected.join(", ");
                        }}
                        MenuProps={{
                            disableScrollLock: true,
                            PaperProps: {
                                style: { position: "fixed", zIndex: 1500, maxHeight: 200 },
                                sx: {
                                    "&::-webkit-scrollbar": { width: "4px" },
                                    "&::-webkit-scrollbar-thumb": { backgroundColor: "#d0cac9ff", borderRadius: "4px" },
                                    "&::-webkit-scrollbar-thumb:hover": { backgroundColor: "#e53935" },
                                },
                            },
                        }}
                    >
                        {/* All Option */}
                        <MenuItem value="all" onClick={() => handleLeadTypeToggle("all")} sx={{ py: 0, px: 1 }}>
                            <Checkbox
                                sx={{
                                    "&.Mui-checked": { color: "#e53935" },
                                    "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                }}
                                checked={selectedLeadType.length === LeadTypeList.length}
                                indeterminate={
                                    selectedLeadType.length > 0 && selectedLeadType.length < LeadTypeList.length
                                }
                            />
                            All
                        </MenuItem>

                        {/* List */}
                        <Box sx={{ maxHeight: 150, overflowY: "auto", pr: 1 }}>
                            {LeadTypeList.map((item, index) => (
                                <MenuItem key={index} value={item.leadType} sx={{ py: 0, px: 1 }} onClick={() => handleLeadTypeToggle(item.leadType)}>
                                    <Checkbox
                                        sx={{ "&.Mui-checked": { color: "#e53935" } }}
                                        checked={selectedLeadType.includes(item.leadType)}
                                    />
                                    {item.leadType}
                                </MenuItem>
                            ))}
                        </Box>
                    </Select>
                </FormControl>
            </Box>

            {/* Vehicle Type */}
            <Box>
                <FormControl size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: "#fff", borderRadius: 2 }}>
                    <InputLabel id="vehicle-type-label" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                        Lead Type
                    </InputLabel>
                    <Select
                        multiple
                        labelId="vehicle-type-label"
                        open={vehicleTypeSelectOpen}
                        onClose={() => setvehicleTypeSelectOpen(false)}
                        onOpen={() => setvehicleTypeSelectOpen(true)}
                        value={selectedVehicleType}
                        onChange={handleVehicleTypeChange}
                        renderValue={(selected) => {
                            if (selected.length === vehicleType.length) return "All";
                            return selected.join(", ");
                        }}
                        MenuProps={{
                            disableScrollLock: true,
                            PaperProps: {
                                style: { maxHeight: 200, position: "fixed", zIndex: 1500 },
                                sx: {
                                    "&::-webkit-scrollbar": { width: "4px" },
                                    "&::-webkit-scrollbar-thumb": { backgroundColor: "#d0cac9ff", borderRadius: "4px" },
                                    "&::-webkit-scrollbar-thumb:hover": { backgroundColor: "#e53935" },
                                },
                            },
                        }}
                    >
                        {/* All Option */}
                        <MenuItem value="all" onClick={() => handleVehicleTypeToggle("all")} sx={{ py: 0, px: 1 }}>
                            <Checkbox
                                sx={{
                                    "&.Mui-checked": { color: "#e53935" },
                                    "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                }}
                                checked={selectedVehicleType.length === vehicleType.length}
                                indeterminate={
                                    selectedVehicleType.length > 0 && selectedVehicleType.length < vehicleType.length
                                }
                            />
                            All
                        </MenuItem>

                        {/* Vehicle List */}
                        <Box sx={{ maxHeight: 150, overflowY: "auto", pr: 1 }}>
                            {vehicleType.map((v, index) => (
                                <MenuItem
                                    key={index}
                                    value={v.vehicle_class}
                                    sx={{ py: 0, px: 1 }}
                                    onClick={() => handleVehicleTypeToggle(v.vehicle_class)}
                                >
                                    <Checkbox
                                        sx={{ "&.Mui-checked": { color: "#e53935" } }}
                                        checked={selectedVehicleType.includes(v.vehicle_class)}
                                    />
                                    {v.vehicle_class}
                                </MenuItem>
                            ))}
                        </Box>
                    </Select>
                </FormControl>
            </Box>


            {/* Segment */}
            <Box>
                <FormControl className='' size="small" sx={{ minWidth: 80, maxWidth: 80, backgroundColor: '#ffffff', borderRadius: 2 }}>
                    <InputLabel id="segment-label" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                        Segment
                    </InputLabel>
                    <Select
                        className='georama-Medium'
                        labelId="segment-label"
                        id="segment-select"
                        multiple
                        value={selectedSegment} // Binds to the array of selected segments (e.g., ['GCV', 'MIS'])
                        onChange={handleSegmentChange}
                        open={segmentSelectOpen}
                        onClose={() => setSegmentSelectOpen(false)}
                        onOpen={() => setSegmentSelectOpen(true)}
                        renderValue={(selected) => {
                            // Check if all segments are selected
                            if (selected.length === segment?.length) return "All";

                            // Render the comma-separated list of selected segment names
                            // Note: The 'selected' array already contains the segment names (e.g., ['GCV', 'MIS']),
                            // so we don't need to filter the `segment` data like in your original code.
                            // We can directly join the selected array.
                            return selected.join(', ');
                        }}
                        MenuProps={{
                            disableScrollLock: true,
                            PaperProps: {
                                style: {
                                    position: 'fixed',
                                    zIndex: 1500,
                                    scrollbarWidth: 'thin',
                                    scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                },
                                sx: {
                                    '&::-webkit-scrollbar': { width: '4px' },
                                    '&::-webkit-scrollbar-track': { backgroundColor: '#f1f1f1', borderRadius: '4px' },
                                    '&::-webkit-scrollbar-thumb': { backgroundColor: '#d0cac9ff', borderRadius: '4px' },
                                    '&::-webkit-scrollbar-thumb:hover': { backgroundColor: '#d32f2f' },
                                }
                            },
                            getContentAnchorEl: null,
                        }}
                    >
                        {/* 'Select All' option */}
                        <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                            onClick={() => handleSegmentToggle('all')} // Use handleSegmentToggle for checkbox click
                        >
                            <Checkbox
                                sx={{
                                    '&.Mui-checked': { color: '#e53935' },
                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                }}
                                checked={selectedSegment.length === segment?.length}
                                indeterminate={
                                    selectedSegment.length > 0 &&
                                    selectedSegment.length < segment.length
                                }
                            />
                            All
                        </MenuItem>

                        {/* Individual Segment options */}
                        <Box
                            sx={{
                                maxHeight: 150,
                                overflowY: 'auto',
                                pr: 1,
                            }}
                        >
                            {segment && segment.map((segmentItem, index) => (
                                <MenuItem
                                    className={selectedSegment.includes(segmentItem.Segment) ? 'georama- fs-14' : ''}
                                    disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                    key={index}
                                    // Value must be the segment name/key you want to store in selectedSegment array
                                    value={segmentItem.Segment}
                                    onClick={() => handleSegmentToggle(segmentItem.Segment)} // Use handleSegmentToggle for checkbox click
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedSegment.includes(segmentItem.Segment)}
                                    />

                                    {segmentItem.Segment}
                                </MenuItem>
                            ))}
                        </Box>
                    </Select>
                </FormControl>
            </Box>



            {/* Source */}
            <Box>
                <FormControl className='' size="small" sx={{ minWidth: 80, maxWidth: 80, backgroundColor: '#ffffff', borderRadius: 2 }}>
                    <InputLabel id="source-label" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                        Source
                    </InputLabel>
                    <Select
                        className='georama-Medium'
                        labelId="source-label"
                        id="source-select"
                        multiple
                        value={selectedSource}
                        onChange={handleSourceChange}
                        open={sourceSelectOpen}
                        onClose={() => setSourceSelectOpen(false)}
                        onOpen={() => setSourceSelectOpen(true)}
                        renderValue={(selected) => {
                            if (selected.length === sourceData?.length) return "All";

                            return selected.join(', ');
                        }}
                        MenuProps={{
                            disableScrollLock: true,
                            PaperProps: {
                                style: {
                                    position: 'fixed',
                                    zIndex: 1500,
                                    scrollbarWidth: 'thin',
                                    scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                },
                                sx: {
                                    '&::-webkit-scrollbar': { width: '4px' },
                                    '&::-webkit-scrollbar-track': { backgroundColor: '#f1f1f1', borderRadius: '4px' },
                                    '&::-webkit-scrollbar-thumb': { backgroundColor: '#d0cac9ff', borderRadius: '4px' },
                                    '&::-webkit-scrollbar-thumb:hover': { backgroundColor: '#d32f2f' },
                                }
                            },
                            getContentAnchorEl: null,
                        }}
                    >
                        <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                            onClick={() => handleSourceToggle('all')}
                        >
                            <Checkbox
                                sx={{
                                    '&.Mui-checked': { color: '#e53935' },
                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                }}
                                checked={selectedSource.length === sourceData?.length}
                                indeterminate={
                                    selectedSource.length > 0 &&
                                    selectedSource.length < sourceData.length
                                }
                            />
                            All
                        </MenuItem>

                        {/* Individual Source options */}
                        <Box
                            sx={{
                                maxHeight: 150,
                                overflowY: 'auto',
                                pr: 1,
                            }}
                        >
                            {sourceData && sourceData.map((sourceItem, index) => (
                                <MenuItem
                                    className={selectedSource.includes(sourceItem.datapull_name) ? 'georama- fs-14' : ''}
                                    disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                    key={index}
                                    // Value must be the 'datapull_name' string
                                    value={sourceItem.datapull_name}
                                    onClick={() => handleSourceToggle(sourceItem.datapull_name)}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedSource.includes(sourceItem.datapull_name)}
                                    />

                                    {sourceItem.datapull_name}
                                </MenuItem>
                            ))}
                        </Box>
                    </Select>
                </FormControl>
            </Box>



            {/* Current Disposition */}
            <Box>
                <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                    <InputLabel id="current-disposition-label" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                        Current Disposition
                    </InputLabel>
                    <Select
                        className='georama-Medium'
                        labelId="current-disposition-label"
                        id="current-disposition--select"
                        multiple
                        value={selectedCurrentDispo} // Binds to the array of selected dispositions
                        onChange={handleCurrentDispositionChange}
                        open={currentDispoSelectOpen}
                        onClose={() => setCurrentDispoSelectOpen(false)}
                        onOpen={() => setCurrentDispoSelectOpen(true)}
                        renderValue={(selected) => {
                            // Check if all are selected
                            if (selected.length === currentDisposition?.length) return "All";

                            // Return comma-separated list of selected disposition names (selected is already an array of strings)
                            return selected.join(', ');
                        }}
                        MenuProps={{
                            disableScrollLock: true,
                            PaperProps: {
                                style: {
                                    position: 'fixed',
                                    zIndex: 1500,
                                    scrollbarWidth: 'thin',
                                    scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                },
                                sx: {
                                    '&::-webkit-scrollbar': { width: '4px' },
                                    '&::-webkit-scrollbar-track': { backgroundColor: '#f1f1f1', borderRadius: '4px' },
                                    '&::-webkit-scrollbar-thumb': { backgroundColor: '#d0cac9ff', borderRadius: '4px' },
                                    '&::-webkit-scrollbar-thumb:hover': { backgroundColor: '#d32f2f' },
                                }
                            },
                            getContentAnchorEl: null,
                        }}
                    >
                        {/* 'Select All' option */}
                        <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                            onClick={() => handleCurrentDispositionToggle('all')} // Use the correct toggle function
                        >
                            <Checkbox
                                sx={{
                                    '&.Mui-checked': { color: '#e53935' },
                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                }}
                                checked={selectedCurrentDispo.length === currentDisposition?.length}
                                indeterminate={
                                    selectedCurrentDispo.length > 0 &&
                                    selectedCurrentDispo.length < currentDisposition.length
                                }
                            />
                            All
                        </MenuItem>

                        {/* Individual Disposition options */}
                        <Box
                            sx={{
                                maxHeight: 150,
                                overflowY: 'auto',
                                pr: 1,
                            }}
                        >
                            {currentDisposition && currentDisposition.map((dispoItem, index) => (
                                <MenuItem
                                    className={selectedCurrentDispo.includes(dispoItem.disposition) ? 'georama- fs-14' : ''}
                                    disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                    key={index}
                                    // Value must be the disposition string
                                    value={dispoItem.disposition}
                                    onClick={() => handleCurrentDispositionToggle(dispoItem.disposition)}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedCurrentDispo.includes(dispoItem.disposition)}
                                    />

                                    {dispoItem.disposition}
                                </MenuItem>
                            ))}
                        </Box>
                    </Select>
                </FormControl>
            </Box>



            {/* Conversion Status */}
            <Box>
                <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                    <InputLabel id="conversion-status-label" className="fs-10" sx={{ fontWeight: 500, fontSize: '0.875rem' }}>
                        Conversion Status
                    </InputLabel>
                    <Select
                        className='georama-Medium'
                        labelId="conversion-status-label"
                        id="conversion-status-select"
                        multiple
                        value={selectedConversionStatus}
                        onChange={handleConversionStatusChange}
                        open={conversionStatusSelectOpen}
                        onClose={() => setConversionStatusSelectOpen(false)}
                        onOpen={() => setConversionStatusSelectOpen(true)}
                        renderValue={(selected) => {
                            if (selected.length === conversionStatus?.length) return "All";
                            return selected.join(', ');
                        }}
                        MenuProps={{
                            disableScrollLock: true,
                            PaperProps: {
                                style: {
                                    position: 'fixed',
                                    zIndex: 1500,
                                    scrollbarWidth: 'thin',
                                    scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                },
                                sx: {
                                    '&::-webkit-scrollbar': { width: '4px' },
                                    '&::-webkit-scrollbar-track': { backgroundColor: '#f1f1f1', borderRadius: '4px' },
                                    '&::-webkit-scrollbar-thumb': { backgroundColor: '#d0cac9ff', borderRadius: '4px' },
                                    '&::-webkit-scrollbar-thumb:hover': { backgroundColor: '#d32f2f' },
                                }
                            },
                            getContentAnchorEl: null,
                        }}
                    >
                        {/* 'Select All' option */}
                        <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                            onClick={() => handleConversionStatusToggle('all')}
                        >
                            <Checkbox
                                sx={{
                                    '&.Mui-checked': { color: '#e53935' },
                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                }}
                                checked={selectedConversionStatus.length === conversionStatus?.length}
                                indeterminate={
                                    selectedConversionStatus.length > 0 &&
                                    selectedConversionStatus.length < conversionStatus.length
                                }
                            />
                            All
                        </MenuItem>

                        {/* Individual Status options */}
                        <Box
                            sx={{
                                maxHeight: 150,
                                overflowY: 'auto',
                                pr: 1,
                            }}
                        >
                            {conversionStatus && conversionStatus.map((statusItem, index) => (
                                <MenuItem
                                    className={selectedConversionStatus.includes(statusItem.conversionStatus) ? 'georama- fs-14' : ''}
                                    disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                    key={index}
                                    // Value must be the status string
                                    value={statusItem.conversionStatus}
                                    onClick={() => handleConversionStatusToggle(statusItem.conversionStatus)}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedConversionStatus.includes(statusItem.conversionStatus)}
                                    />

                                    {statusItem.conversionStatus}
                                </MenuItem>
                            ))}
                        </Box>
                    </Select>
                </FormControl>
            </Box>

            <Button
                className="btn-assign assign-txt fs-12"
                variant="outlined"
                // fullWidth
                onClick={handleReset}
                sx={{ borderRadius: 8, textTransform: "none", px: 4 }}
            >
                Reset
            </Button>

            <Button
                className='btn-common-red fs-12'
                // fullWidth
                size="small"
                onClick={handleApply}
            >
                Apply Filter
            </Button>
        </>
    );
};

export default FilterDialog;
