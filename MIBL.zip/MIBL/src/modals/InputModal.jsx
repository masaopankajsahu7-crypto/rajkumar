import { Button, Dialog, DialogTitle, DialogContent, DialogActions, IconButton, TextField, Box, FormControl, MenuItem, Select, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import { useEffect, useMemo, useState } from 'react';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        paddingTop: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#e53935',
    color: '#fff',
    padding: theme.spacing(2),
    fontWeight: 600,
}));

export default function Inputmodal({ open, onClose, onSubmit, field }) {
    const [newInput, setNewInput] = useState('');

    useEffect(() => {
        if (open) setNewInput('');
    }, [open])

    const handleDialogSubmit = () => {
        if (newInput.trim()) {
            onSubmit(newInput.trim(), field);
            setNewInput('');
            onClose(field);
        }
    };

    const validField = useMemo(() => {
        if (field === 'Mobile No.') {
            const phoneRegex = /^\d{10}$/;
            return phoneRegex.test(newInput.trim());
        } else if (field === 'Email Id') {
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            return emailRegex.test(newInput.trim());
        }
        return false;
    }, [field, newInput]);

    const handleInputChange = (value) => {
        if (field === 'Mobile No.') {
            setNewInput(value.replace(/\D/g, '').slice(0, 10))
        } else if (field === 'Email Id') {
            setNewInput(value.slice(0, 50))
        }
    }

    return (
        <>
            <BootstrapDialog open={open} onClose={onClose} maxWidth="md">
                <DialogTitleWrapper>
                    <Typography sx={{ fontSize: "18px" }}>
                        Add New {field}
                    </Typography>
                    <IconButton
                        aria-label="close"
                        onClick={() => onClose(field)}
                        sx={{ position: 'absolute', right: 8, top: 8, color: 'white' }}
                    >
                        <CloseIcon />
                    </IconButton>
                </DialogTitleWrapper>

                {/* <DialogContent sx={{ display: "flex", justifyContent: "center", my: 5 }}>
                    <Box sx={{ width: "100%", maxWidth: field === 'Mobile No.' ? "300px" : "500px" }}>
                        <Typography variant="subtitle1" mb={1}>
                            New {field}
                        </Typography>

                        <TextField
                            fullWidth
                            placeholder={`Enter ${field}`}
                            variant="outlined"
                            value={newInput}
                            onChange={(e) => handleInputChange(e.target.value.replace(/\D/g, ''))} // allow only digits
                            error={
                                field === "Mobile No." &&
                                newInput.length === 10 &&
                                !/^[6-9]\d{9}$/.test(newInput)
                            }
                            helperText={
                                field === "Mobile No." &&
                                    newInput.length === 10 &&
                                    !/^[6-9]\d{9}$/.test(newInput)
                                    ? "Enter a valid 10-digit mobile number"
                                    : ""
                            }
                            sx={{
                                '& input::placeholder': { color: '#999' },
                                width: field === 'Mobile No.' ? "300px" : "500px",
                                backgroundColor: '#fff',
                                borderRadius: 1,
                            }}
                            inputProps={{ maxLength: field === "Mobile No." ? 10 : undefined }}
                        />
                    </Box>
                </DialogContent> */}

                <DialogContent sx={{ display: "flex", justifyContent: "center", my: 5 }}>
                    <Box sx={{ width: "100%", maxWidth: field === 'Mobile No.' ? "300px" : "500px" }}>
                        <Typography variant="subtitle1" mb={1}>
                            New {field}
                        </Typography>

                        <TextField
                            fullWidth
                            placeholder={`Enter ${field}`}
                            variant="outlined"
                            value={newInput}
                            onChange={(e) => {
                                const value = e.target.value;
                                if (field === "Mobile No.") {
                                    // allow only digits
                                    handleInputChange(value.replace(/\D/g, ""));
                                } else {
                                    handleInputChange(value);
                                }
                            }}
                            error={
                                (field === "Mobile No." &&
                                    newInput.length === 10 &&
                                    !/^[6-9]\d{9}$/.test(newInput)) ||
                                (field === "Email Id" &&
                                    newInput.length > 0 &&
                                    !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(newInput))
                            }
                            helperText={
                                field === "Mobile No."
                                    ? newInput.length === 10 &&
                                        !/^[6-9]\d{9}$/.test(newInput)
                                        ? "Enter a valid 10-digit mobile number"
                                        : ""
                                    : field === "Email Id"
                                        ? newInput.length > 0 &&
                                            !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(newInput)
                                            ? "Enter a valid email address"
                                            : ""
                                        : ""
                            }
                            sx={{
                                "& input::placeholder": { color: "#999" },
                                width: field === "Mobile No." ? "300px" : "500px",
                                backgroundColor: "#fff",
                                borderRadius: 1,
                            }}
                            inputProps={{
                                maxLength: field === "Mobile No." ? 10 : undefined,
                            }}
                        />
                    </Box>
                </DialogContent>


                <DialogActions sx={{ borderTop: "1px solid rgb(185, 175, 175)" }}>
                    <Button
                        onClick={handleDialogSubmit}
                        variant="contained"
                        sx={{
                            backgroundColor: '#444',
                            px: 5,
                            py: 1,
                            borderRadius: '12px',
                            textTransform: 'none',
                            '&:hover': { backgroundColor: '#333' },
                        }}
                        disabled={
                            field === "Mobile No."
                                ? !/^[6-9]\d{9}$/.test(newInput) // disable until valid mobile entered
                                : newInput.trim() === ""
                        }
                    >
                        Submit
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </>
    );
}