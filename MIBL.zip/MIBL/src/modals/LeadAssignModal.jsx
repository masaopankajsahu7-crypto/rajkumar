import { Button, Dialog, DialogTitle, DialogContent, DialogActions, IconButton, TextField, Box, FormControl, MenuItem, Select, Typography, Autocomplete } from '@mui/material';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import { useEffect, useState } from 'react';
import assignImg from "../assets/images/assignRed.svg"
import { AssignLeads } from '../services/api';
import { useSelector } from 'react-redux';
import 'react-toastify/dist/ReactToastify.css';
import BackdropLoader from '../components/Loader/BackdropLoader';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        paddingTop: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#e53935',
    color: '#fff',
    padding: theme.spacing(2),
    fontWeight: 600,
}));

export default function LeadAssignModal({ open, onClose, leadIds, onInfo, assign = false, agentDataModal }) {
    const [selectedAgentId, setSelectedAgentId] = useState('');
    const data = useSelector((state) => state.user.loggedData);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setSelectedAgentId("");
    }, [open])

    const handleSubmit = async () => {
        if (!selectedAgentId) {
            onInfo("Please select an agent.", "error");
            return;
        }
        const formattedLeadIds = leadIds.map(item => item.leadId);

        let response;
        try {
            setLoading(true);
            response = await AssignLeads({ userId: data.user_id, agentId: selectedAgentId, leadIds: formattedLeadIds, dealerCode: data.dealerCode, type: "assignLeads" });
            if (response.statusCode === "200" || response.statusMessage === "Updated the leads to the respective assigned agent.") {
                onInfo(response.statusMessage, "success");
                onClose();
            }
            else {
                onInfo(response.statusMessage, "error");
                onClose();
            }
        } catch (err) {
            console.error("Assignment failed", err);
            onInfo(response.statusMessage, "error");
            onClose();
        } finally {
            setLoading(false);
        }
        setSelectedAgentId('');
    };

    return (
        <>
            <BackdropLoader loading={loading} />
            <BootstrapDialog open={open} onClose={onClose}>
                <DialogTitleWrapper>
                    <Typography sx={{ fontSize: "18px", display: "flex" }}>
                        {assign && <img src={assignImg} alt="" />}
                        <Typography variant="h6" component="div" sx={{ ml: 1 }}>
                            {assign ? 'Lead Assign' : 'Add New Mobile No'}
                        </Typography>
                    </Typography>
                    <IconButton
                        aria-label="close"
                        onClick={onClose}
                        sx={{ position: 'absolute', right: 8, top: 8, color: 'white' }}
                    >
                        <CloseIcon />
                    </IconButton>
                </DialogTitleWrapper>

                <DialogContent sx={{ mx: 2, my: 5 }}>
                    <Typography variant="subtitle1" mb={1}>
                        Lead Assign to
                    </Typography>
                    <Autocomplete
                        fullWidth
                        value={ agentDataModal?.find((agent) => agent.agentId === selectedAgentId) || null }
                        onChange={(e, newValue) => setSelectedAgentId(newValue ? newValue.agentId : "")}
                        options={
                            agentDataModal
                                ? agentDataModal.filter(
                                    (agent) =>
                                        !leadIds.some(
                                            (selected) =>
                                                selected.agentId === agent.agentId &&
                                                selected.agentName === agent.agentName
                                        )
                                )
                                : []
                        }
                        getOptionLabel={(option) => option.agentName || ""}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                placeholder="Select Agent"
                                sx={{
                                    width: "300px",
                                    backgroundColor: "#fff",
                                    borderRadius: 1,
                                }}
                                InputProps={{
                                    ...params.InputProps,
                                    sx: { borderRadius: 1 },
                                }}
                            />
                        )}
                        renderOption={(props, option) => (
                            <li {...props} key={option.agentId}>
                                {option.agentName}
                            </li>
                        )}
                    />
                </DialogContent>


                <DialogActions sx={{ borderTop: '1px solid rgb(185, 175, 175)' }}>
                    <Button
                        onClick={handleSubmit}
                        disabled={!selectedAgentId || loading}
                        variant="contained"
                        sx={{
                            backgroundColor: '#444',
                            px: 5,
                            py: 1,
                            borderRadius: '12px',
                            textTransform: 'none',
                            '&:hover': { backgroundColor: '#333' },
                        }}>
                        Submit
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </>
    );
}