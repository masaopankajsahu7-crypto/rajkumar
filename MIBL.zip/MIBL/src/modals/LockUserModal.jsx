import { Button, Dialog, DialogTitle, DialogContent, IconButton, TextField, Box, Typography, Divider } from '@mui/material';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import { useEffect, useState } from 'react';
import { updateUserStatus, userAccountLock } from '../services/api';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        paddingTop: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#e53935',
    color: '#fff',
    padding: theme.spacing(2),
    fontWeight: 600,
}));

export default function LockUserModal({ lockopen, lockonClose, email, status, editUser, userStatus, userId }) {
    const userDetails = useSelector((state) => state.user.loggedData);
    const [remarks, setRemarks] = useState("");
    const [loading, setLoading] = useState(false);


    useEffect(() => {
        setRemarks("")
    }, [lockopen]);

    const handleUserStatus = async () => {
        if (remarks.trim().length > 10) {
            const payload = {
                "email": email,
                "puserId": userId,
                "lockStatus": status === "Unlocked" ? "L" : "U",
                "userId": userDetails.user_id,
                "remark": remarks
            }
            try {
                const response = await userAccountLock(payload);
                if (response.status_code === "200" || response.status_message === "User account locked ") {
                    toast.success("User Activation Changed successfully");
                    lockonClose("success");
                } else if (response.status_code === "404") {
                    toast.error(response.status_message);
                }
            } catch (error) {
                console.error('Error posting data:', error);
            }
        }
        else toast.error('Please enter a valid remark (minimum 10 characters).');
    }

    const handleUserActivation = async () => {
        if (remarks.trim().length > 10) {
            const payload = {
                // "email": email,
                "puserId": userId,
                "userStatus": userStatus,
                "userId": userDetails.user_id,
                "remark": remarks
            }

            try {
                const response = await updateUserStatus(payload);
                if (response.status_code === "200" || response.status_message === "User account deactivated successfully") {
                    toast.success("User Activation Changed successfully");
                    lockonClose(userStatus);
                } else {
                    toast.error("Something went wrong");
                }
            } catch (error) {
                console.error('Error posting data:', error);
            }
        }
        else toast.error('Please enter a valid remark (minimum 10 characters).');
    }

    return (
        <>
            <BootstrapDialog open={lockopen} lockonClose={lockonClose} fullWidth maxWidth="xs">
                <DialogTitleWrapper className='reset-modal-header'>
                    <Typography className='fs-18'>
                        {editUser == true ? "Status" : status}
                    </Typography>

                    <IconButton
                        aria-label="close"
                        onClick={() => lockonClose(userStatus === "1" ? "0" : "1")}
                        sx={{ position: 'absolute', right: 8, top: 8, }}
                    >
                        <CloseIcon />
                    </IconButton>
                </DialogTitleWrapper>

                <Divider />

                <DialogContent >
                    <Box fullWidth >
                        <Typography className='text-labels' fontWeight={500}>Reason <span className="important-fields">*</span></Typography>

                        <TextField sx={{ borderRadius: '8px' }} className='form-control-input'
                            placeholder='Enter reason'
                            fullWidth multiline minRows={3} maxRows={5}
                            onInput={(e) => {
                                e.target.value = e.target.value.replace(/[^a-zA-Z0-9 ]/g, '').slice(0, 50);
                            }}
                            onChange={(e) => setRemarks(e.target.value)}
                        />
                    </Box>

                    <Box display={"flex"} mt={2} mb={1} gap={1} justifyContent={"space-between"}>
                        <Button
                            fullWidth
                            className='close-btn'
                            onClick={() => lockonClose(userStatus === "1" ? "0" : "1")}
                        >
                            Close
                        </Button>

                        <Button
                            disabled={remarks.trim().replace(/\s/g, '').length < 5 && loading}
                            fullWidth
                            className="btn-common-red"
                            onClick={editUser == true ? handleUserActivation : handleUserStatus}
                        >
                            Submit
                        </Button>
                    </Box>
                </DialogContent>
            </BootstrapDialog >
        </>
    );
}