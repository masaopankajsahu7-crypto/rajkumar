import { Button, Dialog, DialogTitle, DialogContent, Box, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import { useState } from 'react';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import { generateUserPassword } from '../services/api';
import { toast } from 'react-toastify';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        paddingTop: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#e53935',
    color: '#fff',
    padding: theme.spacing(2),
    fontWeight: 600,
}));

export default function LoginConfirmationModal({ open, onClose, email }) {
    const [showConfirmation, setShowConfirmation] = useState(false);

    const handleConfirmYes = async () => {
        try {
            const response = await generateUserPassword(email);
            if (response.p_status_code === "200" || response.p_status_message === "Password updated successfully"
                || response.status_code === "200" || response.status_message === "Password updated successfully") {
                onClose();
                toast.success(response.status_message);
            } else {
                toast.error("Something went wrong. Please try again");
            }
        } catch (err) {
            console.error("Password reset failed", err);
            toast.error("Password Reset Failed");
        } finally {
            setShowConfirmation(false);
        }
    };

    const handleConfirmNo = () => {
        setShowConfirmation(false);
        onClose();
    };

    return (
        <>
            <BootstrapDialog open={open} onClose={onClose}>
                <DialogContent sx={{ mx: 5, my: 6 }}>
                    {!showConfirmation && (
                        <>
                            <Typography mb={3}>
                                An account with this email is already logged in. Do you want to continue and log in anyway?
                            </Typography>
                            <Box display="flex" justifyContent="center" gap={4}>
                                <Button
                                    variant="contained"
                                    color="success"
                                    startIcon={<CheckCircleIcon />}
                                    onClick={handleConfirmYes}
                                >
                                    Yes
                                </Button>
                                <Button
                                    variant="outlined"
                                    color="error"
                                    startIcon={<CancelIcon />}
                                    onClick={handleConfirmNo}
                                >
                                    No
                                </Button>
                            </Box>
                        </>
                    )}
                </DialogContent>
            </BootstrapDialog>
        </>
    );
}