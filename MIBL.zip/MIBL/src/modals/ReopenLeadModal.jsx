import { Button, Dialog, DialogTitle, DialogContent, DialogActions, IconButton, Box, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import { reopenleads } from '../services/api';
import { useSelector } from 'react-redux';
import 'react-toastify/dist/ReactToastify.css';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        paddingTop: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#e53935',
    color: '#fff',
    padding: theme.spacing(2),
    fontWeight: 600,
}));

export default function ReopenLeadModal({ open, onClose, onInfo, selectedRows, selectedReopenData }) {
    const data = useSelector((state) => state.user.loggedData);

    const handleSubmit = async () => {
        let formattedLeadIds;
        let formattedCustomerIds;
        if (selectedRows.length > 0) {
            formattedLeadIds = selectedRows.map(item => item.leadId);
            formattedCustomerIds = selectedRows.map(item => item.customerId);
        } else if (selectedReopenData && !selectedRows.length) {
            formattedLeadIds = [selectedReopenData.leadId];
            formattedCustomerIds = [selectedReopenData.customerId];
        }

        const payload = {
            roleName: data.role,
            userId: data.user_id,
            dealerCode: data.dealerCode,
            lead_ids: formattedLeadIds,
            customer_ids: formattedCustomerIds
        }


        let response;
        try {
            response = await reopenleads(payload);
            if (response.status_code === "200" || response.status_message === "Lead(s) reopened successfully") {
                onInfo(response.status_message, "success");
                onClose();
            } else {
                onInfo(response.status_message, "error");
                onClose();
            }
        } catch (err) {
            onInfo(response.statusMessage, "error");
            onClose();
        }
    };

    return (
        <>
            <BootstrapDialog open={open} onClose={onClose}>
                <DialogTitleWrapper sx={{ bgcolor: "transparent", color: "black" }}>
                    <Typography className='georama-Medium fs-20'>
                        Reopen Lead
                    </Typography>
                    <IconButton
                        aria-label="close"
                        onClick={onClose}
                        sx={{ position: 'absolute', right: 8, top: 8, color: 'black' }}
                    >
                        <CloseIcon />
                    </IconButton>
                </DialogTitleWrapper>

                <DialogContent>
                    <Box mb={0} mt={5}>
                        <Typography className='center-text' mx={3}>
                            Are you sure want to reopen the lead?
                        </Typography>
                    </Box>
                </DialogContent>


                <DialogActions>
                    <Button
                        onClick={onClose}
                        fullWidth
                        sx={{
                            border: "1px solid gray",
                            borderRadius: 8,
                            color: "black",
                            backgroundColor: 'transparent',
                        }}
                    >
                        No
                    </Button>

                    <Button
                        onClick={() => handleSubmit()}
                        fullWidth
                        className='btn-common-red'
                        sx={{ my: 1 }}
                    >
                        Yes
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </>
    );
}