import { Button, Dialog, DialogTitle, DialogContent, IconButton, Box, Typography, Divider } from '@mui/material';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import { useState } from 'react';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import { generateUserPassword } from '../services/api';
import { toast } from 'react-toastify';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        paddingTop: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#e53935',
    color: '#fff',
    padding: theme.spacing(2),
    fontWeight: 600,
}));

export default function ResetModal({ open, onClose, email, userId, mobileNo }) {
    const [showConfirmation, setShowConfirmation] = useState(false);

    const handleGenerateClick = () => {
        setShowConfirmation(true);
    };

    const handleConfirmYes = async () => {
        try {
            const puserId = userId;
            const response = await generateUserPassword(puserId, email, mobileNo);
            // if (response.p_status_code === "200" || response.p_status_message === "Password updated successfully"
            //     || response.status_code === "200" || response.status_message === "Password updated successfully") {
            //     onClose();
            //     toast.success(response.status_message);
            // } else {
            //     toast.error("Something went wrong. Please try again");
            // }
            if (response?.result0?.[0].status_code === "200" || response.status_message === "Password updated successfully") {
                onClose();
                toast.success(response?.result0?.[0].status_message);
            } else {
                toast.success(response?.result0?.[0].status_message);
            }
        } catch (err) {
            console.error("Password reset failed", err);
            toast.error("Password Reset Failed");
        } finally {
            setShowConfirmation(false);
        }
    };

    const handleConfirmNo = () => {
        setShowConfirmation(false);
        onClose();
    };

    return (
        <>
            <BootstrapDialog open={open} onClose={onClose}>
                <DialogTitleWrapper className='reset-modal-header'>
                    <Typography className='fs-18'>
                        Reset Password
                    </Typography>
                    <IconButton
                        aria-label="close"
                        onClick={onClose}
                        sx={{ position: 'absolute', right: 8, top: 8, }}
                    >
                        <CloseIcon />
                    </IconButton>
                </DialogTitleWrapper>
                <Divider />

                <DialogContent sx={{ mx: 5, my: 6 }}>
                    {!showConfirmation ? (
                        <>
                            <Box display={"flex"} flexDirection={"column"} justifyContent={"center"} alignItems={"center"}>
                                <Typography>
                                    Your strong password has been sent to your email.
                                </Typography>
                                <Button
                                    className='btn-common-red'
                                    sx={{ px: 3, mx: "auto", my: 2 }}
                                    onClick={handleGenerateClick}
                                >
                                    Generate Password
                                </Button>
                            </Box>
                        </>
                    ) : (
                        <>
                            <Typography mb={3}>
                                Are you sure you want to proceed to generate password?
                            </Typography>

                            <Box display="flex" justifyContent="center" gap={4}>
                                <Button
                                    variant="contained"
                                    color="success"
                                    startIcon={<CheckCircleIcon />}
                                    onClick={handleConfirmYes}
                                >
                                    Yes
                                </Button>
                                <Button
                                    variant="outlined"
                                    color="error"
                                    startIcon={<CancelIcon />}
                                    onClick={handleConfirmNo}
                                >
                                    No
                                </Button>
                            </Box>
                        </>
                    )}
                </DialogContent>
            </BootstrapDialog>
        </>
    );
}