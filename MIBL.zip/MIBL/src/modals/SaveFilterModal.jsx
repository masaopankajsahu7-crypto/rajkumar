import { Button, Dialog, DialogTitle, DialogContent, DialogActions, IconButton, TextField, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        paddingTop: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#e53935',
    color: '#fff',
    padding: theme.spacing(2),
    fontWeight: 600,
}));

export default function FilterModal({ open, onClose, filterName, setFilterName, validateFilterName }) {

    return (
        <>
            <BootstrapDialog open={open} onClose={onClose}>
                <DialogTitleWrapper>
                    <Typography sx={{ fontSize: "18px" }}>
                        Save Filter
                    </Typography>
                    <IconButton
                        aria-label="close"
                        onClick={onClose}
                        sx={{ position: 'absolute', right: 8, top: 8, color: 'white' }}
                    >
                        <CloseIcon />
                    </IconButton>
                </DialogTitleWrapper>

                <DialogContent sx={{ mx: 2, my: 5 }}>
                    <Typography variant="subtitle1" mb={1}>
                        Filter Name
                    </Typography>
                    <TextField
                        fullWidth
                        placeholder="Filter Name"
                        variant="outlined"
                        value={filterName}
                        onChange={(e) => setFilterName(e.target.value.trimStart().replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, ' ').slice(0, 50))}
                        sx={{
                            '& input::placeholder': {
                                color: '#999',
                            },
                            width: "220px",
                            mx: 'auto',
                            backgroundColor: '#fff',
                            borderRadius: 1,
                        }}
                    />
                </DialogContent>

                <DialogActions sx={{ borderTop: "1px solid rgb(185, 175, 175)" }}>
                    <Button
                        onClick={validateFilterName}
                        variant="contained"
                        sx={{
                            backgroundColor: '#444',
                            px: 5,
                            py: 1,
                            borderRadius: '12px',
                            textTransform: 'none',
                            '&:hover': {
                                backgroundColor: '#333',
                            },
                        }}
                        disabled={!filterName?.trim()}
                    >
                        Submit
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </>
    );
}
