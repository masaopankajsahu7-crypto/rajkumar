import { Box, Button, Dialog, DialogActions, Grid, DialogContent, DialogTitle, IconButton, Typography } from '@mui/material';
import { LinearProgress } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { styled } from '@mui/material/styles';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import uploadIcon from '../assets/images/upload.svg';
// import excelIcon from '../assets/images/excel.svg';
import React, { useEffect, useRef, useState } from 'react';
import { btnRed, secondaryGray } from '../utils/Colors';
import excelSheetimg from '../assets/images/excelSheetimg.svg';
import bulkDownload from "../assets/images/bulkDowload.svg";
import { downloadErrorExcel, validateBulkExcel, saveValidatedExcel, uploadTargetPlanningDetails } from '../services/api';
import { toast, ToastContainer } from 'react-toastify';
import { useSelector } from 'react-redux';
import DownloadIcon from "@mui/icons-material/Download";

const customTheme = createTheme({
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    variants: [
                        {
                            props: { variant: 'dashed', color: 'primary' },
                            style: ({ theme }) => ({
                                textTransform: 'none',
                                border: `2px dashed gray`,
                                color: 'gray',
                            }),
                        },
                    ],
                },
            },
        },
    },
});

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiPaper-root': {
        borderRadius: 12,
        overflow: 'hidden',
        width: 400,
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(2),
        justifyContent: 'center',
    },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#fff',
    padding: theme.spacing(2),
    borderBottom: '1px solid #eee',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    fontWeight: 600,
}));

export default function BulkTargetModal({ clearBulkModalvalues, openbulkmodal, onInfo, handleClosebulkmodal }) {
    const fileInputRef = useRef(null);
    const [dragOver, setDragOver] = useState(false);
    const [uploadedFile, setUploadedFile] = useState(null);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [fileSize, setFileSize] = useState(0);
    const [excelHeaders, setExcelHeaders] = useState([]);
    const [fullWidth, setFullWidth] = useState(true);
    const [maxWidth, setMaxWidth] = useState('sm');
    const [validateData, setValidateData] = useState(null);
    const [uploadedSize, setUploadedSize] = useState('');
    const userdetails = useSelector((state) => state.user.loggedData);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (clearBulkModalvalues || openbulkmodal) {
            setUploadedFile(null);
            setUploadProgress(0);
            setValidateData(null);
        }
    }, [clearBulkModalvalues, openbulkmodal])

    const isValidFile = (file) => {
        const validTypes = [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-excel',
            'text/csv',
        ];
        return validTypes.includes(file.type);
    };

    const formatFileSize = (bytes) => {
        if (bytes < 1024) {
            return `${bytes} B`;
        } else if (bytes < 1024 * 1024) {
            return `${(bytes / 1024).toFixed(1)} KB`;
        } else {
            return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
        }
    };

    const handleFile = (file) => {
        if (!file) return;

        const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

        // ✅ Size validation
        if (file.size > MAX_FILE_SIZE) {
            toast.error("File size should not exceed 10 MB");
            return;
        }

        // ✅ Type validation
        if (!isValidFile(file)) {
            toast.error("Only Excel or CSV files are allowed.");
            return;
        }

        const sizeBytes = file.size;
        const formattedSize = formatFileSize(sizeBytes);

        setUploadedFile(file);
        setFileSize(formattedSize);
        setUploadProgress(0);
        simulateUploadProgress(sizeBytes);
    };

    const handleExcelUpload = (e, type) => {
        e.preventDefault();
        if (uploadedFile) {
            toast.warning('Please remove Uploaded File before Uploading.');
            return;
        }
        let file;
        if (type === 'drop') {
            file = e.dataTransfer.files[0];
        } else {
            const filedata = e.target.files[0];
            handleFile(filedata);
            file = e.target.files[0];
        }
        if (!isValidFile(file)) {
            toast.error('Please upload a valid Excel or CSV file.');
            return;
        }
        setUploadedFile(file);
        const sizeBytes = file.size;
        setFileSize(formatFileSize(sizeBytes));
        setUploadProgress(0);
        simulateUploadProgress(sizeBytes);
        e.target.value = '';
    };

    const saveExcel = async () => {
        if (!uploadedFile) {
            toast.error("Please upload a file first");
            return;
        }

        const formData = new FormData();
        formData.append("file", uploadedFile);

        // Optional: add more fields if API needs
        // formData.append("userId", userdetails?.id);

        let response;
        try {
            setLoading(true);

            response = await uploadTargetPlanningDetails(formData);

            if (response.p_status_code == "200" || response.p_status_message == "Bulk records inserted successfully") {
                onInfo(response.p_status_message, "success");

                // Reset state
                setUploadedFile(null);
                setUploadProgress(0);
                setValidateData(null);

                handleClosebulkmodal();
            }
            else if (
                response.p_status_code == 404 ||
                response.p_status_message == "No valid Records found."
            ) {
                onInfo(response.p_status_message, "warning");
            }
            else {
                onInfo(response.p_status_message, "error");
            }

        } catch (error) {
            console.error("Upload failed:", error);
            onInfo("Upload failed. Try again.", "error");
        } finally {
            setLoading(false);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        if (uploadedFile) {
            toast.warning('Please remove Uploaded File before Uploading.');
            setDragOver(false);
            return;
        }
        handleExcelUpload(e, 'drop');
        setDragOver(false);
        // const file = e.dataTransfer.files[0];
        // handleFile(file);
    };

    const simulateUploadProgress = (totalBytes) => {
        let uploaded = 0;
        const interval = setInterval(() => {
            uploaded += 3000000; // 30KB chunks
            const progress = Math.min(uploaded / totalBytes, 1) * 100;
            setUploadProgress(progress);
            const currentFormatted = formatFileSize(Math.min(uploaded, totalBytes));
            const totalFormatted = formatFileSize(totalBytes);
            setUploadedSize(`${currentFormatted} of ${totalFormatted}`);
            if (uploaded >= totalBytes) clearInterval(interval);
        }, 100);
    };

    const handleFileClick = () => {
        fileInputRef.current.click();
    };

    const handleCancelUpload = () => {
        setValidateData(null)
        setUploadedFile(null);
        setUploadProgress(0);
        setExcelHeaders([]);
    };

    return (
        <>
            <Dialog fullWidth={fullWidth}
                maxWidth={maxWidth}
                open={openbulkmodal}
                onClose={handleClosebulkmodal}>
                <DialogTitleWrapper>
                    <Typography variant="subtitle1" fontWeight={600}>Upload Excel</Typography>
                    <Box>
                        <Button
                            sx={{ mr: 1.5 }}
                            variant="outlined"
                            component="a"
                            href="/public/target.xlsx"
                            download
                            // disabled={!fileToDownload}
                            // onClick={downloadTargetExcel}
                            endIcon={<DownloadIcon />}
                            className="btn-common-red"
                        >
                            Sample Data
                        </Button>
                        <IconButton onClick={handleClosebulkmodal}>
                            <CloseIcon />
                        </IconButton>
                    </Box>
                </DialogTitleWrapper>

                <DialogContent>
                    <input type="file" accept=".csv,.xls,.xlsx" ref={fileInputRef} onChange={handleExcelUpload} style={{ display: 'none' }} />

                    <ThemeProvider theme={customTheme}>
                        <Grid container spacing={4} columns={12} alignItems={'center'}>
                            <Grid size={12} item sx={{ mt: 1.5 }}>
                                <Typography >Upload Data</Typography>
                                <Box>
                                    <Button
                                        sx={{
                                            border: '2px dashed #ccc',
                                            borderColor: dragOver ? 'primary.main' : '#ccc',
                                            borderRadius: 2,
                                            px: "auto", py: 2.5,
                                            cursor: 'pointer',
                                            width: '100%',
                                            textAlign: 'center',
                                            transition: '0.2s ease',
                                        }}
                                        component="span"
                                        variant="dashed"
                                        color="primary"
                                        accept=".xlsx,.xls"
                                        onClick={handleFileClick}
                                        onDrop={handleDrop}
                                        onDragOver={(e) => {
                                            e.preventDefault();
                                            setDragOver(true);
                                        }}
                                        onDragLeave={() => setDragOver(false)}
                                    >
                                        <img src={uploadIcon} alt="upload" style={{ marginRight: 8 }} />
                                        Drag and Drop or{' '}
                                        <span
                                            style={{
                                                textDecoration: 'underline',
                                                color: 'black',
                                                padding: '0 5px',
                                            }}
                                        >
                                            Click to Upload
                                        </span>
                                    </Button>
                                    <Typography variant="caption" display="block" className='fs-10' sx={{ float: 'left', mt: 0.2, mr: 'auto' }}>
                                        Supported formats: XLS, XLSX
                                    </Typography>
                                    <Typography variant="caption" display="block" className='fs-10' sx={{ float: 'right', mt: 0.2, ml: 'auto' }}>
                                        Maximum File Size : 10MB.
                                    </Typography>
                                </Box>
                            </Grid>
                        </Grid>
                        {uploadedFile && (
                            <Grid item xs={7}>
                                <Grid container spacing={2} columns={12} alignItems={'center'}>
                                    <Grid size={12} item xs={8}>
                                        <Typography variant="subtitle1" >
                                            Uploaded file
                                        </Typography>
                                        <Box
                                            sx={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                justifyItems: 'center',
                                                border: '1px solid #ccc',
                                                borderRadius: 2,
                                                py: 0.7,
                                                px: 1,
                                                mb: 1,
                                                position: 'relative',
                                            }}
                                        >
                                            <img
                                                src={excelSheetimg}
                                                alt="excel"
                                                style={{ width: 32, marginRight: 12 }}
                                            />
                                            <Box sx={{ flexGrow: 1 }}>
                                                <Typography variant="body2">{uploadedFile.name}</Typography>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={uploadProgress}
                                                    sx={{ height: 3, borderRadius: 1, mt: 0.5, color: 'gray', bgcolor: 'gray' }}
                                                />
                                                <Typography variant="caption" sx={{ mt: 0.5, display: 'block' }}>
                                                    {uploadedSize}
                                                    {/* {(fileSize * (uploadProgress / 100)).toFixed(1)} MB of {fileSize} MB */}
                                                </Typography>
                                            </Box>
                                            <IconButton
                                                onClick={handleCancelUpload}
                                                sx={{ position: 'absolute', top: 4, right: 4 }}
                                            >
                                                <CloseIcon fontSize="small" />
                                            </IconButton>
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                        )}
                    </ThemeProvider>
                </DialogContent>

                <DialogActions
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-evenly',
                        alignItems: 'center',
                        px: 3,
                        py: 2,
                        borderTop: "1px solid rgb(238, 224, 224)"
                    }}
                >
                    <Button
                        disabled={!uploadedFile || loading}
                        className='btn-common-red'
                        onClick={saveExcel}
                    >
                        {loading ? "Uploading..." : "Submit"}
                    </Button>
                </DialogActions>
            </Dialog>
            <ToastContainer autoClose={1000} />
        </>
    );
}