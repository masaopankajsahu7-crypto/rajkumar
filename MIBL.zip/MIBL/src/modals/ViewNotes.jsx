import CloseIcon from "@mui/icons-material/Close";
import {
    Dialog,
    DialogContent,
    DialogTitle,
    IconButton,
    Typography
} from "@mui/material";

const ViewNotes = ({ open, handleClose, notes }) => {
    return (
        <Dialog open={open} onClose={handleClose} fullWidth maxWidth="sm" PaperProps={{
            sx: { borderRadius: 5 }
        }}>
            <DialogTitle
                sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center"
                }}>
                <Typography className="georama-Medium fs-20">
                    {notes ? notes.name : ""}
                </Typography>
                <IconButton onClick={handleClose}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>

            <DialogContent>
                <Typography className="georama-regular fs-14" pb={2}>
                    {notes ? notes.notes : "No notes available"}
                </Typography>
            </DialogContent>
        </Dialog>
    );
};

export default ViewNotes;