import { Check } from '@mui/icons-material';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import { Box, Dialog, DialogContent, DialogTitle, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import { useEffect, useState } from 'react';
import BackdropLoader from '../components/Loader/BackdropLoader';
import { getRoleFeatureView } from '../services/api';

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
    backgroundColor: '#fff',
    padding: theme.spacing(2),
    borderBottom: '1px solid #eee',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    fontWeight: 600,
}));

const ViewRoles = ({ open, onClose, item }) => {
    const checkboxStyles = {
        "&.Mui-checked": { color: "#e53935" },
        "&.MuiCheckbox-indeterminate": { color: "#e53935" },
    };
    const [maxWidth, setMaxWidth] = useState('md');
    const [fullWidth, setFullWidth] = useState(true);

    const [viewRolePermissions, setViewRolePermissions] = useState([]);
    const [features, setFeatures] = useState([]);
    const [permissionColumns, setPermissionColumns] = useState([]);
    const [loading, setLoading] = useState(false);

    const getViewRoles = async () => {
        try {
            setLoading(true);
            const response = await getRoleFeatureView({ "roleName": item?.roleName, "parentCode": item?.parent_code });
            if (response?.result2 && response?.result0 && response?.result1) {
                const featureList = response.result0; // features like "Add & Setup Outlet"
                const accessList = response.result1;   // access like "Edit", "View", etc.
                const roleMappings = response.result2; // current role permissions

                const accessNames = accessList.map(a => a.access_name);
                setPermissionColumns(accessNames);
                setFeatures(featureList);

                // Prepare mapping: featureId => [accessNames]
                const permissionMap = {};

                roleMappings.forEach(item => {
                    const fid = item.parent_feature_id ?? item.feature_id;
                    const accessName = item.access_name;

                    if (!permissionMap[fid]) {
                        permissionMap[fid] = [];
                    }
                    permissionMap[fid].push(accessName);
                });

                setViewRolePermissions(permissionMap);
            }
        } catch (error) {
            console.error("Error fetching role features:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        getViewRoles();
    }, [item]);

    if (!item) return null;

    return (
        <>
            <BackdropLoader loading={loading} />
            <Dialog
                fullWidth={fullWidth}
                maxWidth={maxWidth}
                sx={{ mx: 0 }}
                open={open} onClose={onClose}>
                <DialogTitleWrapper>
                    <Box>
                        <Typography variant="h6" gutterBottom>
                            {item?.roleName}
                        </Typography>
                        {item?.dealerName && <Typography variant="subtitle2" gutterBottom>
                            {item?.dealerName}
                        </Typography>}
                    </Box>
                    <IconButton onClick={() => onClose()}>
                        <HighlightOffIcon />
                    </IconButton>
                </DialogTitleWrapper>

                <DialogContent>
                    <Box px={0}>
                        <TableContainer sx={{ mt: 1 }}>
                            <Table>
                                <TableHead sx={{ backgroundColor: "#f5f5f5" }}>
                                    <TableRow>
                                        <TableCell sx={{ border: "1px solid #ccc", fontWeight: "bold" }}>
                                            Features
                                        </TableCell>
                                        {permissionColumns.map((col) => (
                                            <TableCell key={col} sx={{ border: "1px solid #ccc", fontWeight: "bold" }}>
                                                {col}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                </TableHead>

                                <TableBody>
                                    {features.map((row) => (
                                        <TableRow key={row.id}>
                                            <TableCell sx={{ border: "1px solid #ccc" }}>
                                                {row.features}
                                            </TableCell>

                                            {permissionColumns.map((perm) => {
                                                const hasPermission = viewRolePermissions[row.id]?.includes(perm);
                                                return (
                                                    <TableCell key={perm} sx={{ border: "1px solid #ccc", textAlign: "center" }}>
                                                        {hasPermission && (
                                                            <IconButton size="small" disabled>
                                                                <Check htmlColor='#00b26e' />
                                                            </IconButton>
                                                        )}
                                                    </TableCell>
                                                );
                                            })}
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Box>
                </DialogContent>

            </Dialog>
        </>
    )
}

export default ViewRoles