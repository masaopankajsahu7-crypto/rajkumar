import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { Box, Button, Card, Checkbox, CircularProgress, FormControl, Grid, InputLabel, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import useMediaQuery from '@mui/material/useMediaQuery';
import { ArcElement, BarController, BarElement, CategoryScale, Chart as ChartJS, DoughnutController, Legend, LinearScale, LineController, LineElement, PieController, PointElement, ScatterController, Tooltip } from 'chart.js';
import { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import agentImg from '../assets/images/dashboard/agents.svg';
import branchImg from '../assets/images/dashboard/branch.svg';
import coldLeadImg from '../assets/images/dashboard/coldLeadImg.svg';
import dealerImg from '../assets/images/dashboard/dealer.svg';
import hotLeadImg from '../assets/images/dashboard/hotLeadImg.svg';
import totalLeadImg from '../assets/images/dashboard/totalLeadImg.svg';
import userImg from '../assets/images/dashboard/users.svg';
import warmLeadImg from '../assets/images/dashboard/warmLeadImg.svg';

import dateFilter from "../assets/images/dashboard/dateFilter.svg";
import InactiveLeadssvg from "../assets/images/dashboard/InactiveLeads.svg";
import performancesvg from "../assets/images/managerdashboard/leadconversion.svg";
import myleadssvg from "../assets/images/managerdashboard/myleads.svg";
import AdminPerformance from '../components/AdminPerformance';
import CustomDateRange from '../components/DateRange/CustomDateRange';
import FunnelChart from '../components/FunnelChartComponent';
import BackdropLoader from "../components/Loader/BackdropLoader";
import { setAdminLeadConversion, setAdminLeadStatus, setBranchList, setConversionTrends, setDealerList, setDispositionSummary, setInactiveLeadsList, setLeadSummary, setSegmentList, setStateList, setSubDispositionSummary, setZoneList } from '../redux/slices/dashboardSlice';
import { downloadLeadReport, fetchAdminDashboard, fetchLeadAgingData, filterAdminDashboard } from '../services/api';
import { encryptRoute } from '../services/encrypt';
import { btnRed } from '../utils/Colors';

// ChartJS Registration
ChartJS.register(
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    CategoryScale,
    LinearScale,
    BarElement, LineController, BarController, PieController, ScatterController, DoughnutController
);

const AdminDashboard = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const dispatch = useDispatch();
    const userDetails = useSelector((state) => state.user.loggedData);

    const navigate = useNavigate();

    const adminLeadStatusData = useSelector((state) => state.dashboard?.adminLeadStatus);
    const adminLeadConversion = useSelector((state) => state.dashboard.adminLeadConversion);
    // const segmentData = useSelector((state) => state.dashboard.segmentData);
    const zoneList = useSelector((state) => state.dashboard.zoneList);
    const stateList = useSelector((state) => state.dashboard.stateList);
    const dealerList = useSelector((state) => state.dashboard.dealerList);
    const branchList = useSelector((state) => state.dashboard.branchList);
    const segmentData = useSelector((state) => state.dashboard.segmentList);
    const InactiveLeads = useSelector((state) => state.dashboard.InactiveLeads);
    const conversionTrendsData = useSelector((state) => state.dashboard?.conversionTrendsData);
    const hasFetched = useSelector((state) => state.dashboard.hasFetched);

    const adminLeadStatus = adminLeadStatusData ? Object.entries(adminLeadStatusData).map(([key, value]) => ({
        leadType: value?.Name || key.replace(/_/g, ' '),
        count: value?.Count ?? 0
    })) : [];


    const [selectedSegments, setSelectedSegments] = useState([]);
    const [selectedZones, setselectedZones] = useState([]);
    const [selectedStates, setselectedStates] = useState([]);
    const [selectedDealers, setselectedDealers] = useState([]);
    const [selectedBranches, setselectedBranches] = useState([]);
    const [open, setOpen] = useState(false);
    const anchorRef = useRef(null);
    const [dateSelected, setDateSelected] = useState();
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);
    const [stateSelectionOpen, setStateSelectionOpen] = useState(false);
    const [zoneSelectOpen, setZoneSelectOpen] = useState(false);
    const [dealerSelectOpen, setDealerSelectOpen] = useState(false);
    const [branchSelectOpen, setBranchSelectOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [inactiveLoading, setInactiveLoading] = useState(false);

    const [dealerSearchText, setDealerSearchText] = useState("");

    // Filter dealer list by search
    const filteredDealers = dealerList?.filter((d) =>
        d?.dealer_name?.toLowerCase()?.includes(dealerSearchText?.toLowerCase())
    );

    // for zone 
    const handleZoneChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList.map(zone => zone.Zone));
            }
        } else {
            setselectedZones(value);
        }
    };
    const handleZoneToggle = (zone) => {
        if (zone === 'all') {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList.map(zone => zone.Zone));
            }
        } else {
            const currentIndex = selectedZones.indexOf(zone);
            const newSelected = [...selectedZones];

            if (currentIndex === -1) {
                newSelected.push(zone);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedZones(newSelected);
        }
    };

    // for state 
    const handleStateChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList.map(data => data.State));
            }
        } else {
            setselectedStates(value);
        }
    };
    const handleStateToggle = (state) => {
        if (state === 'all') {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList.map(data => data.State));
            }
        } else {
            const currentIndex = selectedStates.indexOf(state);
            const newSelected = [...selectedStates];

            if (currentIndex === -1) {
                newSelected.push(state);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedStates(newSelected);
        }
    };

    // for dealer 
    const handleDealerToggle = (dealerId) => {
        if (dealerId === 'all') {
            if (selectedDealers.length === dealerList.length) {
                setselectedDealers([]);
            } else {
                setselectedDealers(dealerList.map(data => data.dealer_id));
            }
        } else {
            const currentIndex = selectedDealers.indexOf(dealerId);
            const newSelected = [...selectedDealers];

            if (currentIndex === -1) {
                newSelected.push(dealerId);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedDealers(newSelected);
        }
    };

    // for branch 
    const handleBranchChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedBranches.length === branchList.length) {
                setselectedBranches([]);
            } else {
                setselectedBranches(branchList.map(data => data.loc_code));
            }
        } else {
            setselectedBranches(value);
        }
    };
    const handleBranchToggle = (loc_code) => {
        if (loc_code === 'all') {
            if (selectedBranches.length === branchList.length) {
                setselectedBranches([]);
            } else {
                setselectedBranches(branchList.map(data => data.loc_code));
            }
        } else {
            const currentIndex = selectedBranches.indexOf(loc_code);
            const newSelected = [...selectedBranches];

            if (currentIndex === -1) {
                newSelected.push(loc_code);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedBranches(newSelected);
        }
    };

    // for Segment 
    const handleSegmentChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData.map(seg => seg.Segment));
            }
        } else {
            setSelectedSegments(value);
        }
    };
    const handleSegmentToggle = (segment) => {
        if (segment === 'all') {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData.map(seg => seg.Segment));
            }
        } else {
            const currentIndex = selectedSegments.indexOf(segment);
            const newSelected = [...selectedSegments];

            if (currentIndex === -1) {
                newSelected.push(segment);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedSegments(newSelected);
        }
    };

    const fetchDashboardData = async () => {
        if (!userDetails?.user_id) return;

        try {
            const payload = {
                type: "adminDashboard",
                userId: userDetails.user_id,
                roleType: userDetails.roleType,
                roleId: userDetails.roleId
            };

            setLoading(true);
            const response = await fetchAdminDashboard(payload);

            if (response?.statusCode === "200" || response?.statusMessage === "Admin dashboard data fetched successfully.") {
                const { result0, result1, result2, result3, result4, result5, result6, result7, result8 } = response.data;
                dispatch(setAdminLeadStatus(result0));
                dispatch(setAdminLeadConversion(result1));
                dispatch(setConversionTrends(result2));
                // dispatch(setInactiveLeadsList(result3));
                // dispatch(setDashboardFetched());
                dispatch(setSegmentList(result3));
                dispatch(setZoneList(result4));
                dispatch(setStateList(result5));
                dispatch(setDealerList(result6));
                dispatch(setBranchList(result8));
                setLoading(false);

                // 2️⃣ Second API (after first success)
                await fetchLeadAgingDataApi(payload);
            } else {
                console.error("Failed to fetch dashboard:", response);
                setLoading(false);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
            setLoading(false);
        } finally {
            // setLoading(false);
        }
    };

    const fetchLeadAgingDataApi = async (data) => {
        try {
            setInactiveLoading(true);

            const response = await fetchLeadAgingData(data);

            if (
                response?.statusCode === "200" ||
                response?.statusMessage === "Fetched Dashboard Details."
            ) {
                dispatch(setInactiveLeadsList(response.data.result0));
                setInactiveLoading(false);
            } else {
                console.error("Failed to fetch lead aging:", response);
                setInactiveLoading(false);
            }
        } catch (err) {
            console.error("Error fetching lead aging:", err);
        } finally {
            setInactiveLoading(false);
        }
    };

    useEffect(() => {
        if (userDetails?.user_id) {
            fetchDashboardData();
        }
    }, [userDetails?.user_id]);

    const [clearType, setClearType] = useState(null);

    useEffect(() => {
        if (clearType) {
            filterDashboard();
            setClearType(null);
        }
    }, [selectedZones, selectedStates, selectedDealers, selectedBranches, selectedSegments, clearType]);

    const handleClearFilters = (type) => {
        const resetters = {
            zone: setselectedZones,
            state: setselectedStates,
            dealer: setselectedDealers,
            branch: setselectedBranches,
            segment: setSelectedSegments,
        };

        if (resetters[type]) {
            resetters[type]([]);
            setClearType(type);
        }
    };

    useEffect(() => {
        if (dateSelected && dateSelected !== "") {
            filterDashboard();
        }
    }, [dateSelected]);

    const filterDashboard = async (date = dateSelected) => {
        if (!userDetails?.user_id) return;

        try {
            const startDate = !date || date === "" || date?.startDate === "Invalid Date" ? "" : date.startDate;
            const endDate = !date || date === "" || date?.endDate === "Invalid Date" ? "" : date.endDate;

            const payload2 = {
                // roleId: "1",
                roleId: userDetails.roleId,
                userId: userDetails.user_id,
                dealerLocCode: selectedBranches.join(","),
                dealerId: selectedDealers.join(","),
                state: selectedStates.join(","),
                segment: selectedSegments.join(","),
                zone: selectedZones.join(","),
                startDate,
                endDate,
                type: "filterAdminDashboard",
                roleType: userDetails.roleType,
                // "dealerName": selectedDealers.join(","),
                // dealerCode: selectedDealers,
            }

            setLoading(true);
            const response = await filterAdminDashboard(payload2);

            if (response?.statusCode === "200" || response?.statusMessage === "Fetched Filter Dashboard Details.") {
                const { result0, result1, result2, result7, result8, result9, result10, result11 } = response.data;
                dispatch(setLeadSummary(result0));
                dispatch(setConversionTrends(result10));
                dispatch(setAdminLeadConversion(result8));
                dispatch(setDispositionSummary(result0));
                dispatch(setSubDispositionSummary(result1));
                dispatch(setAdminLeadStatus(result7));
                dispatch(setDispositionSummary(result1));
                dispatch(setSubDispositionSummary(result2));
                setLoading(false);
                fetchLeadAgingDataApi(payload2);
                // dispatch(setInactiveLeadsList(result10));
            } else {
                console.error("Failed to fetch dashboard:", response);
                setLoading(false);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
            setLoading(false);
        } finally {
            // setLoading(false);
        }
    }

    const downloadExcelData = async () => {
        try {
            setLoading(true);
            const result = await downloadLeadReport(
                {
                    userId: userDetails.user_id,
                    roleType: userDetails.roleType,
                    roleId: userDetails.roleId,
                    type: "downloadInactiveLeadExcel",
                    dealerLocCode: selectedBranches.join(","),
                    dealerId: selectedDealers.join(","),
                    state: selectedStates.join(","),
                    segment: selectedSegments.join(","),
                    zone: selectedZones.join(","),
                    // limit: 10,
                    // offset: page,
                });

            if (result && result.data) {
                const blob = new Blob([result.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', 'Lead_Movement_Report.xlsx');
                document.body.appendChild(link);
                link.click();
                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error('Error downloading Excel file:', error);
        } finally {
            setLoading(false);
        }
    };

    const leadConfig = {
        Dealers: {
            bgClass: "dashboard-yellow",
            icon: dealerImg,
        },
        Branch: {
            bgClass: "dashboard-cyan",
            icon: branchImg,
        },
        Users: {
            bgClass: "dashboard-pink",
            icon: userImg,
        },
        Agents: {
            bgClass: "dashboard-green",
            icon: agentImg,
        },
        "Total Leads": {
            bgClass: "dashboard-purple",
            icon: totalLeadImg,
        },
        "Hot Leads": {
            bgClass: "dashboard-red",
            icon: hotLeadImg,
        },
        "Warm Leads": {
            bgClass: "dashboard-orange",
            icon: warmLeadImg,
        },
        "Cold Leads": {
            bgClass: "dashboard-blue",
            icon: coldLeadImg,
        }
    };

    return (
        <Paper className="body-formbg table-auto-width" elevation={0} sx={{ boxShadow: 'none' }}>
            <BackdropLoader loading={loading} />
            <Box py={isMobile ? 1.3 : 0.5} px={isMobile ? 1.5 : 2}>
                <Box display={'flex'} flexWrap={"wrap"} justifyContent="space-between" alignItems="center" mb={1.2} mt={1}>
                    <Box display={'flex'} alignItems="center" justifyContent={"start"} mb={1}>
                        <img src={myleadssvg} alt="" />
                        <Typography px={1} className="georama-SemiBold fs-16">Pan-India Lead Status</Typography>
                    </Box>

                    <Box display="flex" gap={1} flexWrap={"wrap"}>
                        <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel id="zone-label" className="dropdown-label">Zone</InputLabel>

                            <Select
                                className='georama-Medium'
                                labelId="zone-label"
                                id="zone-select"
                                multiple
                                value={selectedZones}
                                label="Zone"
                                onChange={handleZoneChange}
                                open={zoneSelectOpen}
                                onClose={() => setZoneSelectOpen(false)}
                                onOpen={() => setZoneSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === zoneList?.length) return "All";
                                    return zoneList
                                        .filter(zone => selected.includes(zone.Zone))
                                        .map(zone => zone.Zone)
                                        .join(',');
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            // maxHeight: 300,
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                            >
                                <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                    onClick={() => handleZoneToggle('all')}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedZones.length === zoneList?.length}
                                        indeterminate={
                                            selectedZones.length > 0 &&
                                            selectedZones.length < zoneList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {zoneList && zoneList.map((zone, index) => (
                                        <MenuItem
                                            className={selectedZones.includes(zone.Zone) ? 'georama- fs-14' : ''}
                                            disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                            key={index}
                                            value={zone.Zone}
                                            onClick={() => handleZoneToggle(zone.Zone)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedZones.includes(zone.Zone)}
                                            />

                                            {zone.Zone}
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        // disabled={selectedZones.length === 0}
                                        fullWidth
                                        size="small"
                                        onClick={() => {
                                            if (selectedZones.length > 0) {
                                                handleClearFilters("zone");
                                                setZoneSelectOpen(false);
                                            }
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        // disabled={selectedZones.length === 0}
                                        variant="contained"
                                        fullWidth
                                        className='btn-common-red'
                                        size="small"
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedZones.length > 0) {
                                                filterDashboard("");
                                                setZoneSelectOpen(false);
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>

                        <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel id="state-label" className="dropdown-label">State</InputLabel>

                            <Select
                                className='georama-Medium'
                                labelId="state-label"
                                id="state-select"
                                multiple
                                value={selectedStates}
                                label="State"
                                onChange={handleStateChange}
                                open={stateSelectionOpen}
                                onClose={() => setStateSelectionOpen(false)}
                                onOpen={() => setStateSelectionOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === stateList?.length) return "All";
                                    return stateList
                                        .filter(data => selected.includes(data.State))
                                        .map(data => data.State)
                                        .join(',');
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            // maxHeight: 300,
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                            >
                                <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                    onClick={() => handleStateToggle('all')}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedStates.length === stateList?.length}
                                        indeterminate={
                                            selectedStates.length > 0 &&
                                            selectedStates.length < stateList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {stateList && stateList.map((data, index) => (
                                        <MenuItem
                                            className={selectedStates.includes(data.State) ? 'georama- fs-14' : ''}
                                            disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                            key={index}
                                            value={data.State}
                                            onClick={() => handleStateToggle(data.State)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedStates.includes(data.State)}
                                            />

                                            {data.State}
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        // disabled={selectedStates.length === 0}
                                        size="small"
                                        fullWidth
                                        onClick={() => {
                                            if (selectedStates.length > 0) {
                                                handleClearFilters("state");
                                                setStateSelectionOpen(false);
                                            }
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        className='btn-common-red'
                                        fullWidth
                                        // disabled={selectedStates.length === 0}
                                        size="small"
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedStates.length > 0) {
                                                filterDashboard("");
                                                setStateSelectionOpen(false);
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>

                        <FormControl
                            size="small"
                            sx={{
                                width: 300,
                                minWidth: 100,
                                maxWidth: 100,
                                backgroundColor: "#ffffff",
                                borderRadius: 2,
                            }}
                        >
                            <InputLabel id="dealer-label" className="dropdown-label">
                                Dealer
                            </InputLabel>

                            <Select
                                className="georama-Medium"
                                labelId="dealer-label"
                                id="dealer-select"
                                multiple
                                value={selectedDealers}
                                label="Dealer"
                                open={dealerSelectOpen}
                                onClose={() => setDealerSelectOpen(false)}
                                onOpen={() => setDealerSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === dealerList?.length) return "All";
                                    return dealerList
                                        .filter((data) => selected.includes(data.dealer_id))
                                        .map((data) => data.dealer_name)
                                        .join(", ");
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            position: "fixed",
                                            zIndex: 1500,
                                            // width: 300,
                                        },
                                    },
                                }}
                            >
                                {/* 🔍 Search input (Autocomplete-like) */}
                                <Box
                                    sx={{
                                        p: 1,
                                        position: "sticky",
                                        top: 0,
                                        background: "#fff",
                                        zIndex: 2,
                                    }}
                                >
                                    <input
                                        type="text"
                                        placeholder="Search dealer..."
                                        value={dealerSearchText}
                                        onChange={(e) => setDealerSearchText(e.target.value)}
                                        onKeyDown={(e) => e.stopPropagation()}
                                        style={{
                                            width: "90%",
                                            padding: "6px 8px",
                                            borderRadius: "6px",
                                            border: "1px solid #ccc",
                                            fontSize: "13px",
                                        }}
                                    />
                                </Box>

                                {/* “All” Option */}
                                <MenuItem
                                    disableGutters
                                    sx={{ py: 0, px: 1, m: 0 }}
                                    value="all"
                                    onClick={() => handleDealerToggle("all")}
                                >
                                    <Checkbox
                                        sx={{
                                            "&.Mui-checked": { color: "#e53935" },
                                            "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                        }}
                                        checked={selectedDealers.length === dealerList?.length}
                                        indeterminate={
                                            selectedDealers.length > 0 &&
                                            selectedDealers.length < dealerList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                {/* Filtered Dealers */}
                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: "auto",
                                        pr: 1,
                                    }}
                                >
                                    {filteredDealers && filteredDealers.length > 0 ? (
                                        filteredDealers.map((data, index) => (
                                            <MenuItem
                                                disableGutters
                                                sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={data.dealer_id}
                                                onClick={() => handleDealerToggle(data.dealer_id)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        "&.Mui-checked": { color: "#e53935" },
                                                        "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                    }}
                                                    checked={selectedDealers.includes(data.dealer_id)}
                                                />
                                                {data.dealer_name}
                                            </MenuItem>
                                        ))
                                    ) : (
                                        <MenuItem disabled>No results found</MenuItem>
                                    )}
                                </Box>

                                {/* Buttons */}
                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        fullWidth
                                        size="small"
                                        onClick={() => {
                                            if (selectedDealers.length > 0) {
                                                handleClearFilters("dealer");
                                                setDealerSelectOpen(false);
                                                setDealerSearchText("");
                                            }
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        className="btn-common-red"
                                        size="small"
                                        fullWidth
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedDealers.length > 0) {
                                                filterDashboard("");
                                                setDealerSelectOpen(false);
                                                setDealerSearchText("");
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>

                        {selectedDealers && selectedDealers?.length > 0 && branchList?.length > 0 && <FormControl className='' size="small" sx={{ minWidth: 110, maxWidth: 110, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel id="branch-label" className="dropdown-label">Branch</InputLabel>

                            <Select
                                className='georama-Medium'
                                labelId="branch-label"
                                id="branch-select"
                                multiple
                                value={selectedBranches}
                                label="Branch"
                                onChange={handleBranchChange}
                                open={branchSelectOpen}
                                onClose={() => setBranchSelectOpen(false)}
                                onOpen={() => setBranchSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === branchList?.length) return "All";
                                    return branchList
                                        .filter(data => selected.includes(data.loc_code))
                                        .map(data => data.loc_name)
                                        .join(',');
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            // maxHeight: 300,
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                            >
                                <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                    onClick={() => handleBranchToggle('all')}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedBranches.length === branchList?.length}
                                        indeterminate={
                                            selectedBranches.length > 0 &&
                                            selectedBranches.length < branchList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {branchList && branchList.map((data, index) => (
                                        <MenuItem
                                            className={selectedBranches.includes(data.loc_name) ? 'georama- fs-14' : ''}
                                            disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                            key={index}
                                            value={data.loc_code}
                                            onClick={() => handleBranchToggle(data.loc_code)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedBranches.includes(data.loc_code)}
                                            />

                                            {data.loc_name}
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        // disabled={selectedBranches.length === 0}
                                        fullWidth
                                        variant="contained"
                                        size="small"
                                        onClick={() => {
                                            if (selectedBranches.length > 0) {
                                                handleClearFilters("branch");
                                                setBranchSelectOpen(false);
                                            }
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        className='btn-common-red'
                                        fullWidth
                                        // disabled={selectedBranches.length === 0}
                                        size="small"
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedBranches.length > 0) {
                                                filterDashboard("");
                                                setBranchSelectOpen(false);
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>}

                        <FormControl className='' size="small" sx={{ minWidth: 110, maxWidth: 110, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel id="segment-label" className="dropdown-label">Segment</InputLabel>

                            <Select
                                className='georama-Medium'
                                labelId="segment-label"
                                id="segment-select"
                                multiple
                                value={selectedSegments}
                                label="Segment"
                                onChange={handleSegmentChange}
                                open={segmentSelectOpen}
                                onClose={() => setSegmentSelectOpen(false)}
                                onOpen={() => setSegmentSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === segmentData?.length) return "All";
                                    return segmentData
                                        .filter(seg => selected.includes(seg.Segment))
                                        .map(seg => seg.Segment)
                                        .join(',');
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            // maxHeight: 300,
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                            >
                                <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                    onClick={() => handleSegmentToggle('all')}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedSegments.length === segmentData?.length}
                                        indeterminate={
                                            selectedSegments.length > 0 &&
                                            selectedSegments.length < segmentData.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {segmentData && segmentData.map((seg, index) => (
                                        <MenuItem
                                            className={selectedSegments.includes(seg.Segment) ? 'georama- fs-14' : ''}
                                            disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                            key={index}
                                            value={seg.Segment}
                                            onClick={() => handleSegmentToggle(seg.Segment)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedSegments.includes(seg.Segment)}
                                            />

                                            {seg.Segment}
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        // disabled={selectedSegments.length === 0}
                                        fullWidth
                                        variant="contained"
                                        size="small"
                                        onClick={() => {
                                            if (selectedSegments.length > 0) {
                                                handleClearFilters("segment");
                                                setSegmentSelectOpen(false);
                                            }
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        // disabled={selectedSegments.length === 0}
                                        className='btn-common-red'
                                        fullWidth
                                        size="small"
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedSegments.length > 0) {
                                                filterDashboard("");
                                                setSegmentSelectOpen(false);
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>

                        <Box>
                            <Button className='bg-white text-gray text-capitalize border-light-gray border-radius-8' ref={anchorRef} onClick={() => setOpen(true)}>
                                <img className='px-1' src={dateFilter} alt="" />

                                <Typography className="dropdown-label" mt={0.5} px={1}>Date Range</Typography>
                            </Button>

                            <CustomDateRange
                                open={open}
                                anchorRef={anchorRef}
                                setOpen={setOpen}
                                setDate={setDateSelected}
                                onChange={() => setDateSelected("")}
                                clearDate={() => {
                                    setDateSelected("");
                                    setOpen(false);
                                    filterDashboard("");
                                }}
                            />
                        </Box>
                    </Box>
                </Box>

                <Grid container spacing={2.5}>
                    <Grid size={12} item xs={12} md={12}>
                        {/* Summary Cards */}
                        <Box sx={{ flexGrow: 1 }}>
                            <Grid container spacing={1.3}>
                                {adminLeadStatus?.map((lead, index) => {
                                    const config = leadConfig[lead.leadType] || {};

                                    return (
                                        <Grid size={{ xs: 6, sm: 6, md: 3 }} key={index}>
                                            <Card className="lead-status-card">
                                                <Box
                                                    display="flex"
                                                    justifyContent="center"
                                                    sx={{
                                                        py: isMobile ? 1.2 : 2.2,
                                                        px: isMobile ? 1.5 : 2.5,
                                                        borderRadius: 3,
                                                    }}
                                                    className={config.bgClass}
                                                >
                                                    <img src={config.icon} alt={lead.leadType} />
                                                </Box>

                                                <Box ml={isMobile ? 1 : 3}>
                                                    <Typography className={`georama-SemiBold ${isMobile ? "fs-16" : "fs-24"}`}>
                                                        {lead.count}
                                                    </Typography>

                                                    <Typography
                                                        className={`georama-Medium ${isMobile ? "fs-12" : "fs-14"} text-gray`}
                                                        pt={0.5}
                                                    >
                                                        {lead.leadType}
                                                    </Typography>
                                                </Box>
                                            </Card>
                                        </Grid>
                                    );
                                })}
                            </Grid>
                        </Box>


                        {/* Lead Conversion and Performance */}
                        <Grid mt={1.5} mb={isMobile ? 0.5 : 1.2} container spacing={1.6} size={{ xs: 12, sx: 12, md: 12, lg: 12 }} item xs={12} md={12}>
                            <Grid px={2} pt={2} borderRadius={2} sx={{ backgroundColor: '#ffffff' }} size={{ xs: 12, sx: 12, md: 5, lg: 5 }}>
                                <Box display={'flex'} alignItems="center" justifyContent={"start"}>
                                    <img src={performancesvg} alt="" />

                                    <Typography px={1} className="georama-SemiBold fs-14">Lead Conversion</Typography>
                                </Box>

                                <Paper elevation={0}
                                    sx={{
                                        width: "100%",
                                        // height: "200px"
                                    }}>
                                    <FunnelChart leadConversion={adminLeadConversion} />
                                </Paper>
                            </Grid>

                            <Grid p={2} borderRadius={2} sx={{ backgroundColor: '#ffffff' }} size={{ xs: 12, sx: 12, md: 7, lg: 7 }}>
                                <Box display={'flex'} alignItems="center" justifyContent={"space-between"} mb={2}>
                                    <Box display={'flex'} alignItems="center" >
                                        <img src={performancesvg} alt="" />

                                        <Typography px={1} className="georama-SemiBold fs-14">Conversion Trend by dealers</Typography>
                                    </Box>

                                    {/* <FormControl className='' size="small" sx={{ minWidth: 150, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                            <InputLabel>Lead Type</InputLabel>

                                            <Select
                                                value={region}
                                                label="Region"
                                                onChange={handleRegionChange}
                                                variant="outlined"
                                            >
                                            </Select>
                                        </FormControl> */}
                                </Box>

                                <Paper elevation={0}>
                                    <AdminPerformance adminPerformance={conversionTrendsData} />
                                </Paper>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </Box>

            <Box mx={1.6} mb={3} className="bg-white" borderRadius={2}>
                <Box p={2} display={'flex'} alignItems="center" justifyContent={"space-between"}>
                    <Box display={"flex"} alignItems="center">
                        <img src={InactiveLeadssvg} alt="" />
                        <Typography px={1} className="georama-SemiBold fs-14">Lead Movement Report</Typography>
                    </Box>
                    <Box>
                        <Button
                            sx={{ mr: 2 }}
                            // disabled={!rows.length}
                            onClick={downloadExcelData}
                            endIcon={<FileDownloadIcon />}
                            className="btn-common-red"
                        >
                            Download
                        </Button>
                        <Button className={`${isMobile ? 'fs-12' : 'fs-16'} highlight-red text-capitalize`}
                            onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/admindashboard/viewAll'))}`)}>
                            View All
                        </Button>
                    </Box>
                </Box>

                <TableContainer component={Box} sx={{ mt: 0, height: "350px" }}>
                    <Table>
                        <TableHead sx={{ position: 'sticky', top: 0, zIndex: 1, backgroundColor: '#f5f5f5' }}>
                            <TableRow>
                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Dealer Name</TableCell>

                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Location</TableCell>

                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Dealer Code</TableCell>

                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Total Leads</TableCell>

                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Assigned Leads</TableCell>

                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Leads Contacted</TableCell>

                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Leads Not-Contacted</TableCell>

                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Conversion Ratios</TableCell>

                                <TableCell sx={{ p: "10px", lineHeight: "1rem" }} className="georama-Medium body-formbg fw-none">Retention Ratios</TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody className="table-body-bg">
                            {inactiveLoading ? (
                                <TableRow>
                                    <TableCell
                                        colSpan={12}
                                        align="center"
                                    >
                                        Loading <CircularProgress size={18} sx={{
                                            ml: 1,
                                            color: "#e31837",
                                            backgroundColor: "rgb(255 255 255 / 50%)",
                                        }} />
                                    </TableCell>
                                </TableRow>
                            ) : InactiveLeads && InactiveLeads.length > 0 ? (
                                InactiveLeads?.map((deal, index) => (
                                    <TableRow key={index}>
                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14">{deal.DealName}</Typography>
                                        </TableCell>

                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14">{deal.DealLocation}</Typography>
                                        </TableCell>

                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14">{deal.DealCode}</Typography>
                                        </TableCell>

                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14">{deal.TotalLeads || 0}</Typography>
                                        </TableCell>

                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14">{deal.AssignedLeads || 0}</Typography>
                                        </TableCell>

                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14">{deal.LeadsContacted || 0}</Typography>
                                        </TableCell>

                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14"> <b>{deal.LeadsNotContacted}</b>

                                                ({deal.LeadsNotContactedPercentage || 0}%)</Typography>
                                        </TableCell>

                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14">{deal.WonLeadsPercentage || 0}%</Typography>
                                        </TableCell>
                                        <TableCell sx={{ p: "5px" }}>
                                            <Typography className="georama-Regular fs-14">{deal.RetentionRatio || 0}%</Typography>
                                        </TableCell>
                                    </TableRow>)
                                )) : (
                                <TableRow>
                                    <TableCell colSpan={12} align="center" sx={{ py: 3 }}>
                                        No data found
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Box>
        </Paper >
    );
};

export default AdminDashboard;
