import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { Box, Button, Checkbox, FormControl, InputLabel, MenuItem, Pagination, Paper, Select, Skeleton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography, useMediaQuery } from "@mui/material";
import { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import dateFilter from "../assets/images/dashboard/dateFilter.svg";
import tatImg from "../assets/images/tatImg.svg";
import CustomDateRange from "../components/DateRange/CustomDateRange";
import BackdropLoader from "../components/Loader/BackdropLoader";
import { downloadTatViewallExcel, fetchTaTData, filterTaTData } from "../services/api";
import { encryptRoute } from "../services/encrypt";
import { btnRed } from '../utils/Colors';

const AgentTATPerformance = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const navigate = useNavigate();
    const userBymanager = useSelector((state) => state.user.fetchUserByManager);

    const [renewalList, setRenewalcategory] = useState([])
    const [teamData, setTeamData] = useState([])
    const [zoneList, setZoneList] = useState([])
    const [stateList, setStateList] = useState([])
    const [dealerList, setDealerList] = useState([])
    const [branchList, setBranchList] = useState([])
    const [sortField, setSortField] = useState("");
    const [sortOrder, setSortOrder] = useState("asc");
    const [dealerSearchText, setDealerSearchText] = useState("");

    const [limit, setLimit] = useState(10);
    const [count, setCount] = useState(0);
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);
    const userDetails = useSelector((state) => state.user.loggedData);
    const [search, setSearch] = useState('');
    const location = useLocation();
    const viewAlltype = location.state?.type || {};

    const [agentData, setAgentPerformance] = useState([]);
    const [paginationCount, setPaginationCount] = useState(0);
    const [selectedZones, setselectedZones] = useState([]);
    const [selectedStates, setselectedStates] = useState([]);
    const [selectedDealers, setselectedDealers] = useState([]);
    const [selectedBranches, setselectedBranches] = useState([]);
    const [open, setOpen] = useState(false);
    const anchorRef = useRef(null);
    const [dateSelected, setDateSelected] = useState();

    const [stateSelectionOpen, setStateSelectionOpen] = useState(false);
    const [zoneSelectOpen, setZoneSelectOpen] = useState(false);
    const [dealerSelectOpen, setDealerSelectOpen] = useState(false);
    const [branchSelectOpen, setBranchSelectOpen] = useState(false);
    const [filtersVersion, setFiltersVersion] = useState(0);


    // Filter dealer list by search
    const filteredDealers = dealerList?.filter((d) =>
        d?.dealer_name?.toLowerCase()?.includes(dealerSearchText?.toLowerCase())
    );

    const adminLeadStatusData = [
        {
            "Name": "Dealers",
            "Count": 2
        },
        {
            "Name": "Branch",
            "Count": 2
        }
    ]
    const adminLeadStatus = adminLeadStatusData ? Object.entries(adminLeadStatusData)?.map(([key, value]) => ({
        leadType: value?.Name || key.replace(/_/g, ' '),
        count: value?.Count ?? 0
    })) : [];


    // for Renewal category
    const [selectedRenewals, setSelectedRenewals] = useState([]);
    const [renewalSelectOpen, setRenewalSelectOpen] = useState(false);

    // for renewal
    const handleRenewalChange = (event) => {
        const value = event.target.value;

        if (value.includes("all")) {
            if (selectedRenewals.length === renewalList.length) {
                setSelectedRenewals([]);
            } else {
                setSelectedRenewals(renewalList?.map((item) => item.renewal_year));
            }
        } else {
            setSelectedRenewals(value);
        }
    };
    const handleRenewalToggle = (renewal) => {
        if (renewal === "all") {
            if (selectedRenewals.length === renewalList.length) {
                setSelectedRenewals([]);
            } else {
                setSelectedRenewals(renewalList?.map((item) => item.id));
            }
        } else {
            const currentIndex = selectedRenewals.indexOf(renewal);
            const newSelected = [...selectedRenewals];

            if (currentIndex === -1) {
                newSelected.push(renewal);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedRenewals(newSelected);
        }
    };

    // for zone 
    const handleZoneChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList?.map(zone => zone.Zone));
            }
        } else {
            setselectedZones(value);
        }
    };
    const handleZoneToggle = (zone) => {
        if (zone === 'all') {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList?.map(zone => zone.Zone));
            }
        } else {
            const currentIndex = selectedZones.indexOf(zone);
            const newSelected = [...selectedZones];

            if (currentIndex === -1) {
                newSelected.push(zone);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedZones(newSelected);
        }
    };

    // for state 
    const handleStateChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList?.map(data => data.State));
            }
        } else {
            setselectedStates(value);
        }
    };
    const handleStateToggle = (state) => {
        if (state === 'all') {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList?.map(data => data.State));
            }
        } else {
            const currentIndex = selectedStates.indexOf(state);
            const newSelected = [...selectedStates];

            if (currentIndex === -1) {
                newSelected.push(state);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedStates(newSelected);
        }
    };

    // for dealer 
    const handleDealerChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedDealers.length === dealerList.length) {
                setselectedDealers([]);
            } else {
                setselectedDealers(dealerList?.map(data => data.dealer_id));
            }
        } else {
            setselectedDealers(value);
        }
    };
    const handleDealerToggle = (dealerId) => {
        if (dealerId === 'all') {
            if (selectedDealers.length === dealerList.length) {
                setselectedDealers([]);
            } else {
                setselectedDealers(dealerList?.map(data => data.dealer_id));
            }
        } else {
            const currentIndex = selectedDealers.indexOf(dealerId);
            const newSelected = [...selectedDealers];

            if (currentIndex === -1) {
                newSelected.push(dealerId);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedDealers(newSelected);
        }
    };

    // for branch 
    const handleBranchChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedBranches.length === branchList.length) {
                setselectedBranches([]);
            } else {
                setselectedBranches(branchList?.map(data => data.loc_code));
            }
        } else {
            setselectedBranches(value);
        }
    };
    const handleBranchToggle = (loc_code) => {
        if (loc_code === 'all') {
            if (selectedBranches.length === branchList.length) {
                setselectedBranches([]);
            } else {
                setselectedBranches(branchList?.map(data => data.loc_code));
            }
        } else {
            const currentIndex = selectedBranches.indexOf(loc_code);
            const newSelected = [...selectedBranches];

            if (currentIndex === -1) {
                newSelected.push(loc_code);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedBranches(newSelected);
        }
    };

    // team member state
    const [selectedSegments, setSelectedSegments] = useState([]);
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);

    const handleSegmentToggle = (id) => {
        if (id === "all") {
            if (selectedSegments.length === teamData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(teamData?.map(t => t.teamMemberId));
            }
            return;
        }

        setSelectedSegments(prev =>
            prev.includes(id)
                ? prev.filter(item => item !== id)
                : [...prev, id]
        );
    };

    const filterDashboard = async (dateParam) => {
        if (!userDetails?.user_id) return;

        const date = dateParam !== undefined ? dateParam : dateSelected;

        try {
            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            let payload;

            if (userDetails?.roleType === "MIBL") {
                const isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedZones.length === 0 &&
                    selectedStates.length === 0 &&
                    selectedDealers.length === 0 &&
                    selectedSegments.length === 0 &&
                    isDateEmpty;

                payload = {
                    loginUserId: userDetails?.user_id,
                    roleType: userDetails?.roleType,
                    type: isFilterEmpty ? "" : "tatDashboardfilter",
                    zone: selectedZones.join(","),
                    state: selectedStates.join(","),
                    dealerCode: selectedDealers.join(","),
                    dealer: selectedDealers.join(","),
                    fromDate: date?.startDate || "",
                    toDate: date?.endDate || "",
                    teamId: selectedSegments.join(","),
                    renewalCategory: selectedRenewalNames.join(","),
                    limit: limit,
                    offset: page,
                    searchName: search
                };
            } else {
                const isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedSegments.length === 0 && isDateEmpty;

                payload = {
                    loginUserId: userDetails?.user_id,
                    roleType: userDetails?.roleType,
                    type: isFilterEmpty ? "" : "tatDashboardfilter",
                    dealerCode: userDetails?.dealerCode,
                    fromDate: date?.startDate || "",
                    toDate: date?.endDate || "",
                    teamId: selectedSegments.join(","),
                    renewalCategory: selectedRenewalNames.join(","),
                    limit: limit,
                    offset: page,
                    searchName: search
                };
            }

            setLoading(true);

            const response = await filterTaTData(payload);

            if (
                response?.status_code === "200" ||
                response?.status_message === "TAT filter dashboard details fetched"
            ) {

                const { result4, result5, result8, result9, result10, result11 } = response;
                setRenewalcategory(result8)
                setStateList(result10)
                setDealerList(result11)
                setAgentPerformance(result4 || {});
                setPaginationCount(result5[0]?.dealerWiseFollowUpCount);

                if (userDetails?.roleType === "DEALER") {
                    setTeamData(result9 || []);
                }
                if (userDetails?.roleType === "MIBL") {
                    setZoneList(result9 || []);
                }
                setStateList(result10 || []);
                setDealerList(result11 || []);
            }

        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const fetchDashboardData = async () => {
        if (!userDetails?.user_id) return;

        try {
            const payload = {
                dealerCode: userDetails?.dealerCode,
                fromDate: "",
                toDate: "",
                type: "",
                limit: limit,
                offset: page,
                roleType: userDetails?.roleType,
                loginUserId: userDetails?.user_id,
                searchName: search
            }

            setLoading(true);
            const response = await fetchTaTData(payload);

            if (response?.status_code === "200" || response?.status_message === "TAT Dashboard Details fetched") {
                const { result4, result5, result8, result9, result10, result11 } = response;
                setRenewalcategory(result8)
                if (userDetails?.roleType === "MIBL") {
                    setZoneList(result9 || []);
                }
                setStateList(result10)
                setDealerList(result11)
                setAgentPerformance(result4 || {});
                if (userDetails?.roleType === "DEALER") {
                    setTeamData(result9 || []);
                }
                setPaginationCount(result5[0]?.dealerWiseFollowUpCount);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const selectedRenewalNames = renewalList
        .filter((item) => selectedRenewals.includes(item.id))
        ?.map((item) => item.renewal_year);

    const getIsDateEmpty = (date) =>
        !date ||
        !date.startDate ||
        !date.endDate ||
        date.startDate === "Invalid Date" ||
        date.endDate === "Invalid Date";

    const getIsFilterEmpty = () => {
        const isDateEmpty = getIsDateEmpty(dateSelected);

        if (userDetails?.roleType === "MIBL") {
            return (
                selectedRenewals.length === 0 &&
                selectedZones.length === 0 &&
                selectedStates.length === 0 &&
                selectedDealers.length === 0 &&
                selectedSegments.length === 0 &&
                isDateEmpty
            );
        }

        return selectedRenewals.length === 0 && selectedSegments.length === 0 && isDateEmpty;
    };

    const handleClearFilters = (type) => {
        const resetters = {
            renewal: setSelectedRenewals,
            zone: setselectedZones,
            state: setselectedStates,
            dealer: setselectedDealers,
            branch: setselectedBranches,
            segment: setSelectedSegments,
        };

        if (resetters[type]) {
            resetters[type]([]);
            setPage(1);
            setFiltersVersion((v) => v + 1);
        }
    };

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            if (!userDetails?.user_id) return;

            if (getIsFilterEmpty()) fetchDashboardData();
            else filterDashboard();
        }, 300);

        return () => clearTimeout(delayDebounce);
    }, [userDetails?.user_id, search, limit, page, dateSelected, filtersVersion]);


    const downloadExcelData = async (dateParam) => {
        if (!userDetails?.user_id) return;

        const date = dateParam !== undefined ? dateParam : dateSelected;

        try {
            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            setLoading(true);

            let payload;

            if (userDetails?.roleType === "MIBL") {
                const isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedZones.length === 0 &&
                    selectedStates.length === 0 &&
                    selectedDealers.length === 0 && isDateEmpty;

                payload = {
                    searchName: search,
                    // type: "",
                    type: isFilterEmpty ? "" : "tatDashboardfilter",
                    zone: selectedZones.join(","),
                    state: selectedStates.join(","),
                    dealerCode: selectedDealers.join(","),
                    dealer: selectedDealers.join(","),
                    fromDate: date?.startDate || "",
                    toDate: date?.endDate || "",
                    teamId: selectedSegments.join(","),
                    renewalCategory: selectedRenewalNames.join(","),
                    // dealerCode: userDetails?.roleType === "MIBL" ? "" : userDetails?.dealerCode,
                    dealerLocCode: "",
                    roleType: userDetails?.roleType,
                    loginUserId: userDetails?.user_id,
                    checkType: viewAlltype === "dealerWise" ? "dealerWise" : "dealerWiseFollowUps"
                };
            } else {
                const isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedSegments.length === 0 && isDateEmpty;

                payload = {
                    searchName: search,
                    // type: "",
                    type: isFilterEmpty ? "" : "tatDashboardfilter",
                    zone: selectedZones.join(","),
                    state: selectedStates.join(","),
                    dealerCode: userDetails?.dealerCode,
                    dealer: selectedDealers.join(","),
                    fromDate: date?.startDate || "",
                    toDate: date?.endDate || "",
                    teamId: selectedSegments.join(","),
                    renewalCategory: selectedRenewalNames.join(","),
                    // dealerCode: userDetails?.roleType === "MIBL" ? "" : userDetails?.dealerCode,
                    dealerLocCode: "",
                    roleType: userDetails?.roleType,
                    loginUserId: userDetails?.user_id,
                    checkType: viewAlltype === "dealerWise" ? "dealerWise" : "dealerWiseFollowUps"
                };
            }




            const result = await downloadTatViewallExcel(payload);

            if (result?.data) {
                const blob = new Blob([result.data], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                });

                const url = window.URL.createObjectURL(blob);
                const link = document.createElement("a");

                link.href = url;
                const sheetName = `${userDetails?.roleType === "MIBL" ? "Dealer" : "Agent"}_Wise_Follow_Up_Performance.xlsx`;

                link.download = sheetName;

                document.body.appendChild(link);
                link.click();

                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error("Error downloading Excel file:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Paper className="body-formbg table-auto-width" elevation={0} sx={{ boxShadow: 'none' }}>
                <BackdropLoader loading={loading} />
                <Box display={'flex'} flexWrap={"wrap"} justifyContent="space-between" alignItems="center" mb={isMobile ? 0 : 1.2} mt={isMobile ? 0 : 1}>
                    <Box display='flex' alignItems="center" justifyContent="space-between">
                        <Typography display={"flex"} m={2} gap={0.5} className={`${isMobile ? 'fs-12' : 'fs-16'} georama-SemiBold`}>
                            Follow Up Efficiency Dashboard
                        </Typography>
                    </Box>
                    <Box display="flex" gap={1} flexWrap={"wrap"}>
                        <FormControl
                            size="small"
                            sx={{
                                width: 300,
                                minWidth: 170,
                                maxWidth: 170,
                                backgroundColor: "#ffffff",
                                borderRadius: 2,
                            }}
                        >
                            <InputLabel id="renewal-label" className="dropdown-label">
                                Renewal Category
                            </InputLabel>

                            <Select
                                className="georama-Medium"
                                labelId="renewal-label"
                                id="renewal-select"
                                multiple
                                value={selectedRenewals}
                                label="Renewal Category"
                                open={renewalSelectOpen}
                                onClose={() => setRenewalSelectOpen(false)}
                                onOpen={() => setRenewalSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === renewalList.length) return "All";

                                    return renewalList
                                        .filter((data) => selected.includes(data.id))
                                        ?.map((data) => data.renewal_year)
                                        .join(", ");
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            position: "fixed",
                                            zIndex: 1500,
                                        },
                                    },
                                }}
                            >

                                <MenuItem
                                    disableGutters
                                    sx={{ py: 0, px: 1, m: 0 }}
                                    value="all"
                                    onClick={() => handleRenewalToggle("all")}
                                >
                                    <Checkbox
                                        sx={{
                                            "&.Mui-checked": { color: "#e53935" },
                                            "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                        }}
                                        checked={selectedRenewals.length === renewalList.length}
                                        indeterminate={
                                            selectedRenewals.length > 0 &&
                                            selectedRenewals.length < renewalList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: "auto",
                                        pr: 1,
                                    }}
                                >
                                    {renewalList?.map((data) => (
                                        <MenuItem
                                            disableGutters
                                            sx={{ py: 0, px: 1, m: 0 }}
                                            key={data.id}
                                            value={data.id}
                                            onClick={() => handleRenewalToggle(data.id)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    "&.Mui-checked": { color: "#e53935" },
                                                }}
                                                checked={selectedRenewals.includes(data.id)}
                                            />
                                            {data.renewal_year}
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        size="small"
                                        onClick={() => {
                                            handleClearFilters("renewal");
                                            setRenewalSelectOpen(false);
                                        }}
                                        sx={{
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: "none",
                                            px: 1,
                                            my: 1,
                                            mx: 1,
                                            color: "black",
                                            backgroundColor: "transparent",
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        className="btn-common-red"
                                        size="small"
                                        sx={{
                                            mx: 2,
                                            my: 1,
                                            ...btnRed,
                                        }}
                                        onClick={() => {
                                            setPage(1);
                                            setFiltersVersion((v) => v + 1);
                                            setRenewalSelectOpen(false);
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>

                            </Select>
                        </FormControl>

                        {userDetails.roleType === "DEALER" && userBymanager?.length > 0 && (
                            <FormControl
                                size="small"
                                sx={{
                                    width: 250,
                                    minWidth: 150,
                                    maxWidth: 150,
                                    backgroundColor: "#ffffff",
                                    borderRadius: 2,
                                }}
                            >
                                <InputLabel id="segment-label" className="dropdown-label">
                                    Team Member
                                </InputLabel>

                                <Select
                                    className="georama-Medium"
                                    labelId="segment-label"
                                    id="segment-select"
                                    multiple
                                    value={selectedSegments}
                                    label="Team Member"
                                    open={segmentSelectOpen}
                                    onClose={() => setSegmentSelectOpen(false)}
                                    onOpen={() => setSegmentSelectOpen(true)}

                                    renderValue={(selected) => {
                                        if (selected.length === teamData?.length) return "All";

                                        return teamData
                                            .filter((seg) => selected.includes(seg.teamMemberId))
                                            ?.map((seg) => seg.teamMemberName)
                                            .join(", ");
                                    }}

                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                position: "fixed",
                                                zIndex: 1500,
                                                scrollbarWidth: "thin",
                                                scrollbarColor: "rgba(221,220,220,1) #faf3f3ff",
                                            },
                                            sx: {
                                                "&::-webkit-scrollbar": {
                                                    width: "4px",
                                                },
                                                "&::-webkit-scrollbar-track": {
                                                    backgroundColor: "#f1f1f1",
                                                    borderRadius: "4px",
                                                },
                                                "&::-webkit-scrollbar-thumb": {
                                                    backgroundColor: "#d0cac9ff",
                                                    borderRadius: "4px",
                                                },
                                                "&::-webkit-scrollbar-thumb:hover": {
                                                    backgroundColor: "#d32f2f",
                                                },
                                            },
                                        },
                                    }}
                                >

                                    <MenuItem
                                        disableGutters
                                        sx={{ py: 0, px: 1 }}
                                        value="all"
                                        onClick={() => handleSegmentToggle("all")}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                                "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                            }}
                                            checked={selectedSegments.length === teamData?.length}
                                            indeterminate={
                                                selectedSegments.length > 0 &&
                                                selectedSegments.length < teamData?.length
                                            }
                                        />

                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: "auto",
                                            pr: 1,
                                        }}
                                    >
                                        {teamData?.map((seg) => (
                                            <MenuItem
                                                key={seg.teamMemberId}
                                                disableGutters
                                                sx={{ py: 0, px: 1 }}
                                                value={seg.teamMemberId}
                                                onClick={() => handleSegmentToggle(seg.teamMemberId)}
                                            >

                                                <Checkbox
                                                    sx={{
                                                        "&.Mui-checked": { color: "#e53935" },
                                                    }}
                                                    checked={selectedSegments.includes(seg.teamMemberId)}
                                                />

                                                {seg.teamMemberName}

                                            </MenuItem>
                                        ))}

                                    </Box>

                                    <Box display="flex" justifyContent="end">

                                        <Button
                                            fullWidth
                                            variant="contained"
                                            size="small"
                                            onClick={() => {
                                                handleClearFilters("segment");
                                                setSegmentSelectOpen(false);
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: "none",
                                                px: 1,
                                                my: 1,
                                                mx: 1,
                                                color: "black",
                                                backgroundColor: "transparent",
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className="btn-common-red"
                                            size="small"
                                            sx={{ mx: 2, my: 1, ...btnRed }}
                                            onClick={() => {
                                                setPage(1);
                                                setFiltersVersion((v) => v + 1);
                                                setSegmentSelectOpen(false);
                                            }}
                                        >
                                            Apply
                                        </Button>

                                    </Box>

                                </Select>
                            </FormControl>
                        )}

                        {userDetails.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel id="zone-label" className="dropdown-label">Zone</InputLabel>

                            <Select
                                className='georama-Medium'
                                labelId="zone-label"
                                id="zone-select"
                                multiple
                                value={selectedZones}
                                label="Zone"
                                onChange={handleZoneChange}
                                open={zoneSelectOpen}
                                onClose={() => setZoneSelectOpen(false)}
                                onOpen={() => setZoneSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === zoneList?.length) return "All";
                                    return zoneList
                                        .filter(zone => selected.includes(zone.Zone))
                                        ?.map(zone => zone.Zone)
                                        .join(',');
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            // maxHeight: 300,
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                            >
                                <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                    onClick={() => handleZoneToggle('all')}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedZones.length === zoneList?.length}
                                        indeterminate={
                                            selectedZones.length > 0 &&
                                            selectedZones.length < zoneList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {zoneList && zoneList?.map((zone, index) => (
                                        <MenuItem
                                            className={selectedZones.includes(zone.Zone) ? 'georama- fs-14' : ''}
                                            disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                            key={index}
                                            value={zone.Zone}
                                            onClick={() => handleZoneToggle(zone.Zone)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedZones.includes(zone.Zone)}
                                            />

                                            {zone.Zone}
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        fullWidth
                                        size="small"
                                        onClick={() => {
                                            if (selectedZones.length > 0) {
                                                handleClearFilters("zone");
                                                setZoneSelectOpen(false);
                                            }
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        variant="contained"
                                        fullWidth
                                        className='btn-common-red'
                                        size="small"
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedZones.length > 0) {
                                                setPage(1);
                                                setFiltersVersion((v) => v + 1);
                                                setZoneSelectOpen(false);
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>}

                        {userDetails.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel id="state-label" className="dropdown-label">State</InputLabel>

                            <Select
                                className='georama-Medium'
                                labelId="state-label"
                                id="state-select"
                                multiple
                                value={selectedStates}
                                label="State"
                                onChange={handleStateChange}
                                open={stateSelectionOpen}
                                onClose={() => setStateSelectionOpen(false)}
                                onOpen={() => setStateSelectionOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === stateList?.length) return "All";
                                    return stateList
                                        .filter(data => selected.includes(data.State))
                                        ?.map(data => data.State)
                                        .join(',');
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                            >
                                <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                    onClick={() => handleStateToggle('all')}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedStates.length === stateList?.length}
                                        indeterminate={
                                            selectedStates.length > 0 &&
                                            selectedStates.length < stateList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {stateList && stateList?.map((data, index) => (
                                        <MenuItem
                                            className={selectedStates.includes(data.State) ? 'georama- fs-14' : ''}
                                            disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                            key={index}
                                            value={data.State}
                                            onClick={() => handleStateToggle(data.State)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedStates.includes(data.State)}
                                            />

                                            {data.State}
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        size="small"
                                        fullWidth
                                        onClick={() => {
                                            if (selectedStates.length > 0) {
                                                handleClearFilters("state");
                                                setStateSelectionOpen(false);
                                            }
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        className='btn-common-red'
                                        fullWidth
                                        size="small"
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedStates.length > 0) {
                                                setPage(1);
                                                setFiltersVersion((v) => v + 1);
                                                setStateSelectionOpen(false);
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>}

                        {userDetails.roleType === "MIBL" && <FormControl
                            size="small"
                            sx={{
                                width: 300,
                                minWidth: 100,
                                maxWidth: 100,
                                backgroundColor: "#ffffff",
                                borderRadius: 2,
                            }}
                        >
                            <InputLabel id="dealer-label" className="dropdown-label">
                                Dealer
                            </InputLabel>

                            <Select
                                className="georama-Medium"
                                labelId="dealer-label"
                                id="dealer-select"
                                multiple
                                value={selectedDealers}
                                label="Dealer"
                                open={dealerSelectOpen}
                                onClose={() => setDealerSelectOpen(false)}
                                onOpen={() => setDealerSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === dealerList?.length) return "All";
                                    return dealerList
                                        .filter((data) => selected.includes(data.dealer_id))
                                        ?.map((data) => data.dealer_name)
                                        .join(", ");
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            position: "fixed",
                                            zIndex: 1500,
                                            // width: 300,
                                        },
                                    },
                                }}
                            >
                                <Box
                                    sx={{
                                        p: 1,
                                        position: "sticky",
                                        top: 0,
                                        background: "#fff",
                                        zIndex: 2,
                                    }}
                                >
                                    <input
                                        type="text"
                                        placeholder="Search dealer..."
                                        value={dealerSearchText}
                                        onChange={(e) => setDealerSearchText(e.target.value)}
                                        onKeyDown={(e) => e.stopPropagation()}
                                        style={{
                                            width: "90%",
                                            padding: "6px 8px",
                                            borderRadius: "6px",
                                            border: "1px solid #ccc",
                                            fontSize: "13px",
                                        }}
                                    />
                                </Box>

                                <MenuItem
                                    disableGutters
                                    sx={{ py: 0, px: 1, m: 0 }}
                                    value="all"
                                    onClick={() => handleDealerToggle("all")}
                                >
                                    <Checkbox
                                        sx={{
                                            "&.Mui-checked": { color: "#e53935" },
                                            "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                        }}
                                        checked={selectedDealers.length === dealerList?.length}
                                        indeterminate={
                                            selectedDealers.length > 0 &&
                                            selectedDealers.length < dealerList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: "auto",
                                        pr: 1,
                                    }}
                                >
                                    {filteredDealers && filteredDealers.length > 0 ? (
                                        filteredDealers?.map((data, index) => (
                                            <MenuItem
                                                disableGutters
                                                sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={data.dealer_id}
                                                onClick={() => handleDealerToggle(data.dealer_id)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        "&.Mui-checked": { color: "#e53935" },
                                                        "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                    }}
                                                    checked={selectedDealers.includes(data.dealer_id)}
                                                />
                                                {data.dealer_name}
                                            </MenuItem>
                                        ))
                                    ) : (
                                        <MenuItem disabled>No results found</MenuItem>
                                    )}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        fullWidth
                                        size="small"
                                        onClick={() => {
                                            if (selectedDealers.length > 0) {
                                                handleClearFilters("dealer");
                                                setDealerSelectOpen(false);
                                                setDealerSearchText("");
                                            }
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        className="btn-common-red"
                                        size="small"
                                        fullWidth
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedDealers.length > 0) {
                                                setPage(1);
                                                setFiltersVersion((v) => v + 1);
                                                setDealerSelectOpen(false);
                                                setDealerSearchText("");
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>}

                        <Box>
                            <Button className='bg-white text-gray text-capitalize border-light-gray border-radius-8' ref={anchorRef} onClick={() => setOpen(true)}>
                                <img className='px-1' src={dateFilter} alt="" />

                                <Typography className="dropdown-label" mt={0.5} px={1}>Date Range</Typography>
                            </Button>

                            <CustomDateRange
                                open={open}
                                anchorRef={anchorRef}
                                setOpen={setOpen}
                                setDate={setDateSelected}
                                onChange={undefined}
                                clearDate={() => {
                                    setDateSelected("");
                                    setOpen(false);
                                    setPage(1);
                                    setFiltersVersion((v) => v + 1);
                                }}
                            />
                        </Box>
                        <Button className="highlight-red text-capitalize" sx={{ mr: 2 }}
                            onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/tatMonitoring'))}`)}>
                            {"<"} Back
                        </Button>
                    </Box>
                </Box>
                <Box mx={1.6} mb={3} className="bg-white" borderRadius={2}>
                    <Box px={2} py={1} display='flex' flexWrap={"wrap"} alignItems="center" justifyContent="space-between">
                        <Box py={2} display='flex' alignItems="center" justifyContent="space-between">
                            <Typography display={"flex"} gap={0.5} className={`${isMobile ? 'fs-12' : 'fs-16'} georama-SemiBold`}>
                                <img src={tatImg} alt="" />
                                {userDetails?.roleType === "MIBL" ? 'Dealer' : 'Agent'}-Wise Follow-Up Performance
                            </Typography>
                        </Box>

                        <Box display="flex" justifyContent="space-between" alignItems="center">
                            <Box display="flex" justifyContent="space-between" alignItems="center" mt={isDesktop ? "" : 1}>
                                <Button sx={{ mr: 1 }}
                                    // disabled={!rows.length}
                                    onClick={() => downloadExcelData(dateSelected)}
                                    endIcon={<FileDownloadIcon />}
                                    className="btn-common-red"
                                >
                                    Download
                                </Button>
                                <TextField className="custom-textfield body-formbg"
                                    fullWidth
                                    size="small" placeholder="Search"
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value.trimStart().replace(/[^a-zA-Z0-9.,\s]/g, '').replace(/\s+/g, ' ').slice(0, 50)) || setPage(1)}
                                    sx={{
                                        width: isDesktop ? '22ch' : isMobile ? '21ch' : '21ch',
                                        px: 2,
                                        '& .MuiOutlinedInput-root': {
                                            borderRadius: 3,
                                            '&.Mui-focused fieldset': {
                                                borderColor: 'black',
                                            },
                                        },
                                        float: 'right'
                                    }}
                                />
                            </Box>

                        </Box>
                    </Box>

                    <TableContainer component={Box} sx={{ mt: 0 }}>
                        <Table sx={{ tableLayout: 'auto', width: '100%' }}>
                            <TableHead>
                                <TableRow>
                                    <TableCell
                                        className={`${isMobile ? 'fs-12 p-2' : 'fs-14 p-3'} georama-Regular text-gray body-formbg fw-none`}
                                    >
                                        {userDetails?.roleType === "MIBL" ? "Dealer Name" : "Agent Name"}
                                    </TableCell>

                                    <TableCell
                                        className={`${isMobile ? 'fs-12 p-2' : 'fs-14 p-3'} georama-Regular text-gray body-formbg fw-none`}
                                    >
                                        Follow-Up Compliance (%)
                                    </TableCell>

                                    <TableCell
                                        className={`${isMobile ? 'fs-12 p-2' : 'fs-14 p-3'} georama-Regular text-gray body-formbg fw-none`}
                                    >
                                        Total Assigned Leads
                                    </TableCell>

                                    <TableCell
                                        className={`${isMobile ? 'fs-12 p-2' : 'fs-14 p-3'} georama-Regular text-gray body-formbg fw-none`}
                                    >
                                        Total Leads Breached
                                    </TableCell>
                                </TableRow>
                            </TableHead>

                            <TableBody className="table-body-bg">
                                {loading ? (
                                    [...Array(8)].map((_, idx) => (
                                        <TableRow key={idx}>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        </TableRow>
                                    ))
                                ) : (agentData && agentData.length > 0 ? (
                                    agentData?.map((item, index) => (
                                        <TableRow sx={{ "&:hover": { backgroundColor: "#f5f5f5" } }}>
                                            <TableCell>
                                                <span className="georama-Medium fs-14 text-truncate">
                                                    {item?.agentName}
                                                </span>
                                            </TableCell>
                                            <TableCell className="georama-Regular fs-14">
                                                {item?.percentage || 0}%
                                            </TableCell>
                                            <TableCell className="georama-Regular fs-12">
                                                {item?.totalLeadsContacted || 0}
                                            </TableCell>
                                            <TableCell className="georama-Regular fs-12">
                                                {item?.totalLeadsBreached || 0}
                                            </TableCell>
                                        </TableRow>
                                    ))
                                ) : (!agentData || !agentData?.length) && !loading && (
                                    <TableRow>
                                        <TableCell colSpan={4} align="center" sx={{ py: 3 }}>
                                            No Data found
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <Box className="table-body-bg border-radius-bottom-8" display="flex" justifyContent="space-between" alignItems="end" p={2} px={2.5}>
                        {!!paginationCount && <Pagination
                            className="bg-white"
                            size="medium"
                            count={Math.ceil(paginationCount / limit)}
                            page={page} onChange={(e, v) => setPage(v)}
                            shape="rounded"
                            sx={{
                                float: 'right',
                                ml: "auto",
                                '& .MuiPaginationItem-root': {
                                    borderRadius: 3,
                                },
                            }}
                        />}
                    </Box>
                </Box>
            </Paper>

            <ToastContainer autoClose={1000} />
        </>
    )
}

export default AgentTATPerformance