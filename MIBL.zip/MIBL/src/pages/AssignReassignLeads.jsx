import { KeyboardArrowDownOutlined, Straight, Tune } from "@mui/icons-material";
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import SearchIcon from '@mui/icons-material/Search';
import { Box, Button, Checkbox, Chip, ClickAwayListener, Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, Pagination, Paper, Popper, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, ToggleButton, ToggleButtonGroup, Typography } from "@mui/material";
import Skeleton from '@mui/material/Skeleton';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import BackdropLoader from "../components/Loader/BackdropLoader";
import AdvancedSearchFields from "../modals/AdvancedSearchFields";
import BulkReassignModal from "../modals/BulkAssignModal";
import LeadAssignModal from "../modals/LeadAssignModal";
import ReopenLeadModal from "../modals/ReopenLeadModal";
import { downloadExcel, filterLeadList, filterSearch, getLeadAssignDetails } from "../services/api";
import { useAuth } from '../services/useAuth';
import { bgGray100, bgGray500, btnRed, selectedTabCount, tabselectedBg } from '../utils/Colors';
export { KeyboardArrowDownOutlined, Replay, Search, Straight, Tune } from '@mui/icons-material';

const AssignReassignLeads = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    const [openMobileSearch, setOpenMobileSearch] = useState(false);
    const [selectedRows, setSelectedRows] = useState([]);
    const [rows, setRows] = useState([]);
    const [columns, setColumns] = useState();
    const [tableData, setTableData] = useState([]);
    const [limit, setLimit] = useState(10);
    const [search, setSearch] = useState({
        name: '',
        phoneNumber: '',
        vinNumber: '',
        registrationNo: '',
        policyNo: '',
        policyTenure: '',
        policyType: '',
        make: '',
        model: '',
        variant: '',
        vehicleClass: '',
        engineNo: ''
    });
    const [count, setCount] = useState(0);
    const [paginationCount, setPaginationCount] = useState(0);
    const [page, setPage] = useState(1);
    const navigate = useNavigate();
    const [sortField, setSortField] = useState('');
    const [sortDir, setSortDir] = useState('');
    const [showAdvanced, setShowAdvanced] = useState(false);
    const [clearBulkModalvalues, setclearBulkModalvalues] = useState(false);
    const roleId = useAuth().user?.roleId;
    const [loading, setLoading] = useState(true);
    // const data = useSelector((state) => state.user.loggedData);
    const userdetails = useSelector((state) => state.user.loggedData);
    // userdetails.user_id = 1
    // userdetails.dealerCode = 1

    const handleToggleAdvanced = () => setShowAdvanced(!showAdvanced);

    const [anchorEl, setAnchorEl] = useState(null);
    const [activeFilterField, setActiveFilterField] = useState(null);
    const [filterType, setFilterType] = useState(null);

    const [agentCheckboxOptions, setAgentCheckboxOptions] = useState([]);
    const [categoryCheckboxOptions, setCategoryCheckboxOptions] = useState([]);

    const [filterInput, setFilterInput] = useState('');
    const [agentData, setAgentData] = useState([]);
    const [agentDataModal, setAgentDataModal] = useState([]);
    const [renewelMastList, setRenewalMasterlist] = useState([]);
    const [selectedAgentIds, setSelectedAgentIds] = useState([]);
    const [selectedRenewalCategories, setSelectedRenewalCategories] = useState([]);
    const [selectedReopenData, setSelectedReopenData] = useState([]);

    const clearSearchFields = () => {
        fetchData();
    }

    const handleFilterClick = (event, column) => {
        setAnchorEl(event.currentTarget);
        setActiveFilterField(column.inputName);

        if (column.inputName === "Agent Name") {
            setFilterType("checkbox");
            setAgentCheckboxOptions(agentData);
        } else if (column.inputName === "Renewal Category") {
            setFilterType("checkbox");
            if (renewelMastList) {
                const categories = renewelMastList.map(item => item.renewalCategory);
                setCategoryCheckboxOptions(categories);
            }
        } else if (column.inputName === "Expiry Days") {
            setFilterType("input");
        } else {
            setFilterType("");
        }
    };

    const [assignType, setAssignType] = useState('assigned');

    // const isAllSelected = rows.length > 0 && selectedRows.length === rows.length;

    const normalizedRows = rows.map(row => ({
        leadId: row.leadId,
        agentId: row.agentId || '',
        agentName: row.agentName || '',
        customerId: row.customerId || '',
    }));

    const isAllSelected =
        normalizedRows.length > 0 && normalizedRows.every(row =>
            selectedRows.some(selected =>
                selected.leadId === row.leadId && selected.agentId === row.agentId
            )
        );

    const handleSelectAll = (event) => {
        if (event.target.checked) {
            const allRows = normalizedRows.map(row => ({
                leadId: row.leadId,
                agentId: row.agentId,
                agentName: row.agentName,
                customerId: row.customerId
            }));
            setSelectedRows(allRows);
        } else {
            setSelectedRows([]);
        }
    };

    const handleSelectRow = (leadId, agentId = '', agentName = '', customerId) => {
        setSelectedRows(prevSelected => {
            const exists = prevSelected.some(
                row => row.leadId === leadId && row.agentId === agentId
            );

            if (exists) {
                return prevSelected.filter(
                    row => !(row.leadId === leadId && row.agentId === agentId)
                );
            } else {
                return [...prevSelected, { leadId, agentId, agentName, customerId }];
            }
        });
    };

    const handleToggleChange = (event, newType) => {
        // setSearch({
        //     name: '',
        //     phoneNumber: '',
        //     vinNumber: '',
        //     registrationNo: ''
        // });
        setPage(1);
        setSelectedRenewalCategories([]);
        setSelectedAgentIds([]);
        setFilterInput("");
        // setSelectedRows([]);

        // if (newType !== null) {
        setAssignType(newType);
        setSelectedRows([]);
        // }
    };


    const [openmodal, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClosemodal = () => {
        setOpen(false);
    };

    const [Reopenmodal, setReOpen] = useState(false);
    const handleReopen = (row) => {
        setSelectedReopenData(row);
        setReOpen(true);
    }
    const handleCloseReopen = () => {
        setReOpen(false);
    };

    const showMessage = (msg, type = 'success') => {
        if (type === 'success') {
            toast.success(msg);
            setPage(1);
            setSelectedRows([]);
            fetchData();
        } else {
            toast.error(msg);
        }
    };

    const showMessageBulk = (msg, type = 'success') => {
        if (type === 'success') {
            toast.success(msg);
            setPage(1);
            setSelectedRows([]);
            fetchData();
        } else {
            toast.error(msg);
        }
    };

    // useEffect(() => {
    //     handleClearFilters();
    // }, [search]);

    const [openbulkmodal, setopenbulkmodal] = useState(false);
    const handleBulkOpen = () => setopenbulkmodal(true);

    const sortIcon = (cell) => {
        return cell.inputName === sortField ?
            <Straight sx={{ opacity: 0.5, ml: 0.7, transform: `rotate(${sortDir === 'asc' ? 180 : 0}deg)`, fontSize: 18 }} />
            : <KeyboardArrowDownOutlined />
    }

    const [assignOptions, setAssignOptions] = useState([
        { label: 'Assigned Leads', value: 'assigned', countKey: 'assignedCount', count: 0, },
        { label: 'Unassigned Leads', value: 'unassigned', countKey: 'unassignedCount', count: 0 },
        { label: 'My Leads', value: 'myleads', countKey: 'myLeadCount', count: 0 },
        { label: 'Lost Leads', value: 'lostLeads', countKey: 'lostLeadCount', count: 0 }
    ]);

    const handleClearFilters = () => {
        setSelectedRenewalCategories([]);
        setSelectedAgentIds([]);
        setFilterInput("");
        setSearch({ name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: '' })
        setPage(1);
        fetchData();
    };


    const handleClearSearch = () => {
        setSearch({ name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: '' })
        // setSelectedRenewalCategories([]);
        // setSelectedAgentIds([]);
        // setFilterInput("");
        // fetchData();
        setPage(1);
        if (Object.values(search).some(val => val?.trim() === '')) {
            filterSearchList({ name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: '' });
        }
    };

    const handleSearchInput = (key, value) => {
        let isValid = false;

        switch (key) {
            case 'name':
                isValid = /^[A-Za-z .]{0,30}$/.test(value);
                if ((value === '' || isValid) && value.length <= 30) {
                    setSearch(prev => ({ ...prev, [key]: value }));
                }
                break;

            case 'phoneNumber':
                isValid = /^[0-9]{0,10}$/.test(value);
                if (value === '' || isValid) {
                    setSearch(prev => ({ ...prev, [key]: value }));
                }
                break;

            case 'vinNumber':
                isValid = /^[A-Za-z0-9]{0,17}$/.test(value);
                if (value === '' || isValid) {
                    setSearch(prev => ({ ...prev, [key]: value }));
                }
                break;

            case 'registrationNo':
                isValid = /^[A-Za-z0-9-]{0,50}$/.test(value);
                if (value === '' || isValid) {
                    setSearch(prev => ({ ...prev, [key]: value }));
                }
                break;

            default:
                setSearch(prev => ({ ...prev, [key]: value }));
        }
    };

    const filterSearchList = async (inputData) => {
        try {
            const filteredvalue =
            {
                customerName: inputData.name,
                customerPhone: inputData.phoneNumber,
                chassisNo: inputData.vinNumber,
                vehicleRegNo: inputData.registrationNo,
                policyNo: inputData.policyNo,
                policyTenure: inputData.policyTenure,
                policyType: inputData.policyType,
                make: inputData.make,
                model: inputData.model,
                variant: inputData.variant,
                vehicleClass: inputData.vehicleClass,
                engineNo: inputData.engineNo,
                type: assignType,
                limit: 10,
                offset: page,
                userId: userdetails.user_id,
                pageId: 3,
                dealerCode: userdetails.dealerCode
            }

            setLoading(true);
            const result = await filterSearch(filteredvalue);
            const response = result.data;
            if (response?.statusCode == "200" || response?.message == "Fetched successfully") {
                if (!response.leadList.length) {
                    // setNodataFound(true);
                    // setColumns([]);
                    setRows([]);
                    setPaginationCount(response.paginationCount[0].paginationCount);
                    setAssignOptions((prevOptions) =>
                        prevOptions.map((opt) => ({
                            ...opt,
                            count: Number(response?.leadCount[0][opt.countKey] || 0),
                        }))
                    );
                } else {
                    // setNodataFound(false);
                    setColumns(response.inputModel.map(o => o.inputName));
                    setRows(response.leadList);
                    setPaginationCount(response?.paginationCount[0].paginationCount);
                    setAssignOptions((prevOptions) =>
                        prevOptions.map((opt) => ({
                            ...opt,
                            count: Number(response?.leadCount[0][opt.countKey] || 0),
                        }))
                    );
                }
            } else if (response.statusCode == "404" || response.statusMessage == "No Reccord Found..") {
                // setNodataFound(true)
                setColumns([]);
                setRows([]);
            } else if (response.statusCode == "500" || response.statusMessage == "Failed to fetch assigned details due to an exception.") {
                // setNodataFound(true)
                setColumns([]);
                setRows([]);
            }
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    }

    const handleSearch = () => {
        // setIsSearching(true);
        const hasAnySearchValue = Object.values(search).some(val => val?.trim() !== '');
        setShowAdvanced(false);
        setPage(1);
        if (hasAnySearchValue) {
            filterSearchList(search);
        } else {
            fetchData();
        }
    }

    const filterLeadListData = async () => {
        setLoading(true);
        try {
            const filteredvalue =
            {
                "flag": assignType,
                "agentId": selectedAgentIds.join(","),
                "renewalCategory": selectedRenewalCategories.join(","),
                "expiry_days": filterInput,
                "userId": userdetails.user_id,
                "limit": 10,
                "offset": page,
                "dealerCode": userdetails.dealerCode,
                "customerName": "",
                "customerPhone": "",
                "vin": "",
                "type": "leadFilterData"
            }

            const result = await filterLeadList(filteredvalue);
            const response = result.data;
            if (response?.statusCode == "200" || response?.statusMessage == "Fetched the assigned details.") {
                if (response.leadList.length == 0) {
                    // setNodataFound(true);
                    setRows(response.leadList);
                    setPaginationCount(response.paginationCount);
                } else {
                    // setNodataFound(false);
                    setRows(response.leadList);
                    setPaginationCount(response.paginationCount);
                }
            } else if (response.statusCode == "404" || response.statusMessage == "No Reccord Found..") {
                // setNodataFound(true);
                setColumns([]);
                setRows([]);
            } else if (response.statusCode == "500" || response.statusMessage == "Failed to fetch assigned details due to an exception.") {
                // setNodataFound(true);
                setColumns([]);
                setRows([]);
            }
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    }

    const applyFilter = (field, value) => {
        setPage(1);
        if (selectedRenewalCategories || selectedAgentIds || filterInput) {
            filterLeadListData();
        }
    };

    const fetchData = async () => {
        try {
            setLoading(true);
            const result = await getLeadAssignDetails({ limit, page, roleId: userdetails.roleId, userId: userdetails.user_id, assignType, dealerCode: userdetails.dealerCode });
            const response = result.data;
            if (response?.statusCode == "200") {
                setColumns(response.inputModel);
                setRows(response.leadList);
                setCount(response.leadCount);
                setAgentData(response.agentFilterList);
                setAgentDataModal(response.assignMastList);
                setRenewalMasterlist(response.renewelMastList);
                setPaginationCount(response.paginationCount);
                setAssignOptions((prevOptions) =>
                    prevOptions.map((opt) => ({
                        ...opt,
                        count: Number(response.leadCount[opt.countKey] || 0),
                    }))
                );
            } else if (response.statusCode == "404" || response.statusMessage == "No Reccord Found..") {
                // setNodataFound(true);
                setColumns([]);
                setRows([]);
            } else if (response.statusCode == "500" || response.statusMessage == "Failed to fetch assigned details due to an exception.") {
                // setNodataFound(true);
                setColumns([]);
                setRows([]);
            }
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    const downloadExcelData = async () => {
        try {
            setLoading(true);
            const result = await downloadExcel({
                flag: assignType,
                dealerCode: userdetails.dealerCode,
                expiry_days: filterInput,
                customerName: search.name,
                customerPhone: search.phoneNumber,
                vin: search.vinNumber,
                vehicleRegNo: search.registrationNo,
                renewalCategory: selectedRenewalCategories.join(","),
                userId: userdetails.user_id,
                agentId: selectedAgentIds.join(","),
                type: "DownloadFilterData"
                // renewalCategory: renewalCategory,
                // agentId: agentId || 1
            });

            if (result && result.data) {
                // Create a download link
                const blob = new Blob([result.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', 'Lead_Report.xlsx'); // Set your file name
                document.body.appendChild(link);
                link.click();
                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error('Error downloading Excel file:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const hasFilters =
            (Array.isArray(selectedRenewalCategories) && selectedRenewalCategories.length > 0) ||
            (Array.isArray(selectedAgentIds) && selectedAgentIds.length > 0) ||
            (filterInput !== null && filterInput !== undefined && filterInput !== '');

        if (assignType) {
            if (hasFilters) {
                filterLeadListData();
            } else if (Object.values(search).join('') !== '') {
                filterSearchList(search);
            } else {
                fetchData();
            }
        } else {
            fetchData();
        }
    }, [assignType, limit, page]);

    const handleSubmit = () => {
        fetchData();
        setOpen(false);
    };

    const handlebulkSubmit = () => {
        fetchData();
    };

    const handleClosebulkmodal = () => {
        // fetchData();
        setopenbulkmodal(false);
        setclearBulkModalvalues(true);
    }

    const handleSort = (field) => {
        let sDir = 'asc';
        let sField = field;
        if (sortField && sortDir) {
            if (sortField === field) {
                sDir = sortDir === 'asc' ? 'desc' : '';
                sField = sDir === '' ? '' : field;
            }
        }
        setSortField(sField);
        setSortDir(sDir);
        if (sField) {
            let tempRows = sDir === 'asc' ?
                callQueueData.toSorted((a, b) => {
                    if (a[field] < b[field]) return -1;
                    if (a[field] > b[field]) return 1;
                    return 0;
                }) :
                callQueueData.toSorted((a, b) => {
                    if (a[field] > b[field]) return -1;
                    if (a[field] < b[field]) return 1;
                    return 0;
                });
            setRows(tempRows);
        }
        else setRows(callQueueData);
    }

    return (
        <>
            <BackdropLoader loading={loading} />
            {/* <MarqueeInfo /> */}

            <Dialog
                open={openMobileSearch}
                onClose={() => setOpenMobileSearch(false)}
                fullWidth
                maxWidth="md"
            >
                <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography>
                        Advanced Search
                    </Typography>
                    {Object.values(search).some(val => val != "") &&
                        <Button
                            className="text-capitalize highlight-red"
                            sx={{ width: "100px", p: 0, m: 0, fontWeight: "bold" }}
                            onClick={() => {
                                setSearch({
                                    name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: ''
                                });
                            }}
                        >
                            Clear All
                        </Button>}
                </DialogTitle>

                <DialogContent className="advanced-search-modal">
                    <AdvancedSearchFields
                        search={search}
                        handleSearchInput={handleSearchInput}
                        isMobile={true}
                        handleToggleAdvanced={handleToggleAdvanced}
                        handleSearch={handleSearch}
                        setSearch={setSearch}
                        clearSearchFields={clearSearchFields}
                    />
                </DialogContent>

                <DialogActions>
                    <Button className="highlight-red" onClick={() => setOpenMobileSearch(false)}>
                        Cancel
                    </Button>
                    <Button
                        className="btn-common-red"
                        onClick={() => {
                            handleSearch(1);
                            setOpenMobileSearch(false);
                        }}
                    >
                        Apply Search
                    </Button>
                </DialogActions>
            </Dialog>

            <Stack width={'inherit'} className="">
                <Paper className="body-formbg" sx={{ borderTop: '1px solid rgb(211, 203, 203)', boxShadow: 'none' }}>
                    <Box position="relative">
                        {isMobile && (
                            <Button
                                className="btn-common-red"
                                sx={{
                                    width: "90%",
                                    mt: 1,
                                    mx: 2
                                }}
                                onClick={() => setOpenMobileSearch(true)}
                                startIcon={<SearchIcon />}
                            >
                                Search
                            </Button>
                        )}
                        {!isMobile && (
                            <AdvancedSearchFields
                                search={search}
                                handleSearchInput={handleSearchInput}
                                isMobile={false}
                                handleSearch={handleSearch}
                                setSearch={setSearch}
                                handleToggleAdvanced={handleToggleAdvanced}
                                showAdvanced={showAdvanced}
                                clearSearchFields={clearSearchFields}
                            />
                        )}
                    </Box>
                </Paper >
                <>
                    <Paper sx={{
                        px: 3, py: 0.5, ...bgGray100, boxShadow: 'none'
                    }}>
                        <Box
                            display="flex"
                            alignItems="center"
                            justifyContent="space-between"
                            flexWrap="wrap"
                            gap={2}
                            sx={{
                                overflow: {
                                    xs: "scroll", // mobile
                                    sm: "scroll", // small tablets
                                    md: "visible", // from medium screens (desktop) onwards
                                },
                            }}
                        >
                            <Box display="flex" alignItems="center" gap={2} mt={0.5} mb={0.8}>
                                <ToggleButtonGroup
                                    value={assignType}
                                    exclusive
                                    onChange={(e, v) => {
                                        if (v !== null) handleToggleChange(e, v);
                                    }}
                                    sx={{ display: 'flex', gap: 1, border: 'none' }}
                                >
                                    {assignOptions?.map((item) => (
                                        <ToggleButton
                                            className="toggle-button"
                                            key={item.value}
                                            value={item.value}
                                        >
                                            {item.label}
                                            <Chip
                                                className="font-size-10 custom-chip-height"
                                                label={item.count}
                                                sx={{
                                                    backgroundColor: assignType === item.value ? tabselectedBg : selectedTabCount,
                                                    color: assignType === item.value ? 'white' : 'white',
                                                    ml: 1,
                                                    borderRadius: 10,
                                                }}
                                            />
                                        </ToggleButton>
                                    ))}
                                </ToggleButtonGroup>
                            </Box>

                            {assignType === "lostLeads" && <Box display="flex" alignItems="center" gap={1} overflow={"hidden"}>
                                <>
                                    {selectedRows?.length > 0 && (
                                        <Button
                                            className="btn-common-red"
                                            onClick={handleReopen}>
                                            Reopen
                                        </Button>
                                    )}
                                </>
                            </Box>}

                            {assignType !== "lostLeads" &&
                                <Box display="flex" alignItems="center" gap={1} overflow={"hidden"}>
                                    <>
                                        {selectedRows?.length > 0 && (
                                            <Button className="btn-assign assign-txt" onClick={handleOpen}>
                                                Assign to
                                            </Button>
                                        )}
                                    </>
                                    {(
                                        (Array.isArray(selectedRenewalCategories) && selectedRenewalCategories.length > 0) ||
                                        (Array.isArray(selectedAgentIds) && selectedAgentIds.length > 0) ||
                                        (filterInput !== null && filterInput !== undefined && filterInput !== '') ||
                                        Object.values(search).some(val => val?.trim() !== '')
                                    ) && (
                                            <Button
                                                onClick={handleClearFilters}
                                                sx={{
                                                    py: 0.3,
                                                    borderRadius: 8,
                                                    border: "1px solid red",
                                                    px: 1,
                                                    color: "red",
                                                    backgroundColor: 'transparent',
                                                }}
                                                endIcon={<Tune />}
                                            >
                                                Clear Filters
                                            </Button>
                                        )}
                                    <Button
                                        disabled={!rows.length}
                                        onClick={downloadExcelData}
                                        endIcon={<FileDownloadIcon />}
                                        className="btn-common-red"
                                    >
                                        Download
                                    </Button>

                                    <Button
                                        // disabled={!rows.length}
                                        onClick={handleBulkOpen}
                                        className={`btn-common-gray`}
                                    >
                                        Bulk Reassign
                                    </Button>
                                </Box>}
                        </Box>

                        <>
                            <TableContainer component={Box} sx={{ mt: 0.5 }}>
                                <Table sx={{ borderCollapse: 'separate', borderSpacing: '0px 4px' }} stickyHeader>
                                    <TableHead>
                                        {columns && columns?.length > 0 && (
                                            <>
                                                <TableRow className="bg-white">
                                                    {loading ? (
                                                        <>
                                                            <TableCell className="custom-table-cell-header bg-white fs-14">
                                                                <Skeleton variant="rectangular" width={24} height={24} />
                                                            </TableCell>
                                                            {[...Array(5)].map((_, i) => (
                                                                <TableCell key={i} >
                                                                    <Skeleton variant="text" width="80%" />
                                                                </TableCell>
                                                            ))}
                                                        </>
                                                    ) : (
                                                        <>
                                                            <TableCell
                                                                className="custom-table-cell-header bg-white fs-14"
                                                                sx={{
                                                                    borderBottom: 'none',
                                                                    borderTopLeftRadius: 8,
                                                                    borderBottomLeftRadius: 8,
                                                                }}
                                                            >
                                                                <Checkbox
                                                                    sx={{
                                                                        '&.Mui-checked': { color: '#e53935' },
                                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                                    }}
                                                                    checked={isAllSelected}
                                                                    onChange={handleSelectAll}
                                                                    indeterminate={
                                                                        selectedRows.length > 0 &&
                                                                        selectedRows.length < normalizedRows.length
                                                                    }
                                                                />
                                                            </TableCell>

                                                            {columns && columns.length > 0 && columns?.map((cell, index) => (
                                                                <TableCell
                                                                    className="custom-table-cell-header bg-white fs-14"
                                                                    key={index}
                                                                    sx={{
                                                                        cursor: cell.filter === '1' ? 'pointer' : 'default',
                                                                        backgroundColor: bgGray500,
                                                                        color: 'black',
                                                                        borderBottom: 'none',
                                                                        borderTopRightRadius: index === columns.length - 1 ? 8 : 0,
                                                                        borderBottomRightRadius: index === columns.length - 1 ? 8 : 0,
                                                                    }}
                                                                >
                                                                    <Box display="flex" pr={isMobile ? 10 : 0} alignItems="center" justifyContent={"start"} gap={0}>
                                                                        <span className="ar-py-2 fs-14 text-dark georama-Medium">{cell.inputName || cell}</span>
                                                                        <span className="pt-2" onClick={cell.filter === '1' ? (e) => handleFilterClick(e, cell) : undefined}>
                                                                            {cell.filter === "1" && !(assignType === "myleads" && cell.inputName === "Agent Name") && sortIcon(cell)}
                                                                        </span>
                                                                    </Box>
                                                                </TableCell>
                                                            ))}
                                                        </>
                                                    )}
                                                </TableRow>

                                                {/* {(!rows || !rows.length) && !loading && <TableRow>
                                                    <TableCell colSpan={!columns.length ? 0 : columns.length+1} className="no-data-found"><Box className="center-text">No Records Found.</Box></TableCell>
                                                </TableRow>} */}
                                            </>
                                        )}
                                    </TableHead>
                                    <TableBody>
                                        {loading ? (
                                            [...Array(8)].map((_, idx) => (
                                                <TableRow key={idx}>
                                                    <TableCell><Skeleton variant="rectangular" width={24} height={24} /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                </TableRow>
                                            ))
                                        ) : (
                                            rows && rows?.length > 0 ? rows?.map((row, index) => (
                                                <TableRow
                                                    key={index}
                                                    sx={{
                                                        backgroundColor: 'white',
                                                        borderRadius: 2,
                                                        marginBottom: '4px',
                                                        borderBottom: 'none',
                                                        boxShadow: '0px 2px 6px rgba(0, 0, 0, 0.05)',
                                                        '& td:first-of-type': {
                                                            borderTopLeftRadius: '8px',
                                                            borderBottomLeftRadius: '8px',
                                                        },
                                                        '& td:last-of-type': {
                                                            borderTopRightRadius: '8px',
                                                            borderBottomRightRadius: '8px',
                                                        },
                                                    }}
                                                >
                                                    <TableCell className="custom-table-cell-p">
                                                        <Checkbox
                                                            sx={{
                                                                '&.Mui-checked': { color: '#e53935' },
                                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                            }}
                                                            checked={selectedRows.some(
                                                                selected => selected.leadId === row.leadId && selected.agentId === (row.agentId || '')
                                                            )}
                                                            onChange={() => handleSelectRow(row.leadId, row.agentId || '', row.agentName || '', row.customerId)}
                                                        />
                                                    </TableCell>

                                                    <TableCell className="custom-table-cell-p" pr={isMobile ? 5 : 0}>
                                                        <span className="text-dark georama-Medium fs-12 text-truncate">
                                                            {row?.customerName}
                                                        </span>
                                                        <br />
                                                        <small className="fs-10 text-gray">Lead Id {row?.leadId}</small>
                                                    </TableCell>

                                                    {assignType === "lostLeads" ?
                                                        Object.keys(row).slice(2, -1).map((f, idx) => (
                                                            <>
                                                                <TableCell
                                                                    className={`georama-Regular fs-14 custom-table-cell-p ${idx === Object.keys(row).slice(2, -2).length - 1 ? 'expiry_days' : ''}`}
                                                                    key={f}
                                                                    sx={{ padding: "1px !important" }}
                                                                >
                                                                    {idx === Object.keys(row).slice(2, -2).length ?
                                                                        (
                                                                            <>
                                                                                <Button
                                                                                    disabled={selectedRows.length > 0}
                                                                                    className="btn-common-red"
                                                                                    onClick={() => handleReopen(row)}>
                                                                                    Reopen
                                                                                </Button>
                                                                            </>
                                                                        ) :
                                                                        (
                                                                            row[f] != "" ? row[f] : ""
                                                                        )}
                                                                </TableCell>
                                                            </>
                                                        )) :
                                                        Object.keys(row).slice(2, -2).map((f, idx) => (
                                                            <TableCell
                                                                pr={isMobile ? 3 : 0}
                                                                className={`georama-Regular fs-14 custom-table-cell-p ${idx === Object.keys(row).slice(2, -2).length - 1 ? 'expiry_days' : ''}`}
                                                                key={f}
                                                                sx={{ pr: isMobile ? "0px 8px !important" : "1px !important" }}
                                                            >
                                                                {idx === Object.keys(row).slice(2, -2).length - 1 ? (
                                                                    <span className={`pr-2 ${row[f] || row[f] == 0 ? "expiry-pill" : ""} `}>{row[f]}</span>
                                                                ) : (
                                                                    <span className="text-gray fs-12" >{row[f] != "" ? row[f] : ""}</span>
                                                                )}
                                                            </TableCell>
                                                        ))
                                                    }
                                                </TableRow>
                                            )) :
                                                ((!rows || !rows?.length) && !loading && <TableRow>
                                                    <TableCell colSpan={!columns?.length ? 0 : columns?.length + 1} className="no-data-found"><Box className="center-text">No Records Found.</Box></TableCell>
                                                </TableRow>)
                                        )}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                            <Box>
                                {paginationCount > 0 && <Pagination size="medium" count={Math.ceil(paginationCount / limit)} page={page} onChange={(e, v) => setPage(v)} shape="rounded"
                                    sx={{
                                        float: 'right', mx: 1,
                                        '& .MuiPaginationItem-root': {
                                            borderRadius: 3,
                                        }
                                    }} />}
                            </Box>
                        </>
                    </Paper >
                    {/* --------------------- Call Queue Table ** code ends ------------------------------ */}
                </>
            </Stack >

            <ReopenLeadModal
                open={Reopenmodal}
                selectedReopenData={selectedReopenData}
                onClose={handleCloseReopen}
                onInfo={showMessage}
                onSubmit={handleSubmit}
                selectedRows={selectedRows}
            />

            <LeadAssignModal
                open={openmodal}
                onClose={handleClosemodal}
                onInfo={showMessage}
                onSubmit={handleSubmit}
                assign={true}
                agentDataModal={agentDataModal}
                leadIds={selectedRows}
            />

            <BulkReassignModal
                clearBulkModalvalues={clearBulkModalvalues}
                openbulkmodal={openbulkmodal}
                handleClosebulkmodal={handleClosebulkmodal}
                handlebulkSubmit={handlebulkSubmit}
                onInfo={showMessageBulk}
            />

            {/* Filter code on Table Row  */}
            <Popper open={Boolean(anchorEl)} anchorEl={anchorEl} placement="bottom-start" style={{ zIndex: 1300 }}>
                <ClickAwayListener onClickAway={() => setAnchorEl(null)}>
                    <Paper sx={{ minWidth: 150 }}>
                        {filterType === 'checkbox' && (
                            <>
                                <Box sx={{
                                    maxHeight: 180,
                                    overflowY: 'auto',
                                    '&::-webkit-scrollbar': { width: '2px' },
                                    '&::-webkit-scrollbar-thumb': { backgroundColor: '#e53935', borderRadius: '2px' },
                                    '&::-webkit-scrollbar-track': { backgroundColor: '#f1f1f1' },
                                }}>
                                    {activeFilterField === 'Agent Name' && (
                                        <>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        sx={{
                                                            mx: 1.5,
                                                            color: '#e53935',
                                                            '&.Mui-checked': { color: '#e53935' },
                                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                        }}
                                                        indeterminate={
                                                            selectedAgentIds.length > 0 &&
                                                            selectedAgentIds.length < agentCheckboxOptions.length
                                                        }
                                                        checked={
                                                            agentCheckboxOptions.length > 0 &&
                                                            selectedAgentIds.length === agentCheckboxOptions.length
                                                        }
                                                        onChange={(e) => {
                                                            const allIds = agentCheckboxOptions.map((a) => a.agentId);
                                                            setSelectedAgentIds(e.target.checked ? allIds : []);
                                                        }}
                                                    />
                                                }
                                                label="All"
                                            />

                                            {agentCheckboxOptions.map((agent) => (
                                                <FormControlLabel
                                                    key={agent.agentId}
                                                    control={
                                                        <Checkbox
                                                            sx={{ color: '#e53935', '&.Mui-checked': { color: '#e53935' } }}
                                                            checked={selectedAgentIds.includes(agent.agentId)}
                                                            onChange={(e) => {
                                                                const updated = e.target.checked
                                                                    ? [...selectedAgentIds, agent.agentId]
                                                                    : selectedAgentIds.filter((id) => id !== agent.agentId);
                                                                setSelectedAgentIds(updated);
                                                            }}
                                                        />
                                                    }
                                                    label={agent.agentName}
                                                    sx={{ px: 1.5, display: 'block' }}
                                                />
                                            ))}
                                        </>
                                    )}

                                    {activeFilterField === 'Renewal Category' && (
                                        <>
                                            <FormControlLabel
                                                control={
                                                    <Checkbox
                                                        sx={{
                                                            mx: 1.5,
                                                            color: '#e53935',
                                                            '&.Mui-checked': { color: '#e53935' },
                                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                        }}
                                                        indeterminate={
                                                            selectedRenewalCategories.length > 0 &&
                                                            selectedRenewalCategories.length < categoryCheckboxOptions.length
                                                        }
                                                        checked={
                                                            categoryCheckboxOptions.length > 0 &&
                                                            selectedRenewalCategories.length === categoryCheckboxOptions.length
                                                        }
                                                        onChange={(e) => {
                                                            setSelectedRenewalCategories(
                                                                e.target.checked ? [...categoryCheckboxOptions] : []
                                                            );
                                                        }}
                                                    />
                                                }
                                                label="All"
                                            />

                                            {categoryCheckboxOptions.map((category, idx) => (
                                                <FormControlLabel
                                                    key={idx}
                                                    control={
                                                        <Checkbox
                                                            sx={{ color: '#e53935', '&.Mui-checked': { color: '#e53935' } }}
                                                            checked={selectedRenewalCategories.includes(category)}
                                                            onChange={(e) => {
                                                                const updated = e.target.checked
                                                                    ? [...selectedRenewalCategories, category]
                                                                    : selectedRenewalCategories.filter((val) => val !== category);
                                                                setSelectedRenewalCategories(updated);
                                                            }}
                                                        />
                                                    }
                                                    label={category}
                                                    sx={{ px: 1.5, display: 'block' }}
                                                />
                                            ))}
                                        </>
                                    )}

                                </Box>
                            </>
                        )}

                        {filterType === 'input' && (
                            <TextField
                                sx={{ m: 1 }}
                                size="small"
                                label={`Enter ${activeFilterField}`}
                                value={filterInput}
                                slotProps={{
                                    input: {
                                        min: 1,
                                        max: 60,
                                        step: 1,
                                    },
                                }}
                                onChange={(e) => setFilterInput(e.target.value.replace(/\D/g, '').slice(0, 2) > 60 ? '60' : e.target.value.replace(/\D/g, '').slice(0, 2))}
                            />
                        )}
                        <Box display={"flex"} justifyContent={"end"}>
                            <Button
                                disabled={!filterInput && !selectedAgentIds.length && !selectedRenewalCategories.length}
                                className="btn-common-red"
                                variant="contained"
                                size="small"
                                sx={{ mx: 2, mb: 1, ...btnRed }}
                                onClick={() => {
                                    setAnchorEl(null);
                                    if (activeFilterField === 'Agent Name') {
                                        applyFilter(activeFilterField, selectedAgentIds);
                                    } else if (activeFilterField === 'Renewal Category') {
                                        applyFilter(activeFilterField, selectedRenewalCategories);
                                    } else if (filterType === 'input') {
                                        applyFilter(activeFilterField, filterInput.trim());
                                    }
                                }}
                            >
                                Apply
                            </Button>
                        </Box>
                    </Paper>
                </ClickAwayListener>
            </Popper>

            {/* <ToastContainer autoClose={1000} /> */}
        </>
    )
}

export default AssignReassignLeads