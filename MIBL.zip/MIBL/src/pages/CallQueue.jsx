import KeyboardArrowDownOutlinedIcon from '@mui/icons-material/KeyboardArrowDownOutlined';
import NorthIcon from '@mui/icons-material/North';
import SearchIcon from '@mui/icons-material/Search';
import SouthIcon from '@mui/icons-material/South';
import TuneIcon from '@mui/icons-material/Tune';
import { Box, Button, Checkbox, Chip, ClickAwayListener, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormControlLabel, Grid, IconButton, MenuItem, Pagination, Paper, Popover, Popper, Select, Skeleton, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, ToggleButton, ToggleButtonGroup, Typography, useMediaQuery } from "@mui/material";
import Tooltip from '@mui/material/Tooltip';
import { addDays, addYears, format, isAfter, isBefore, parseISO, startOfMonth, subDays, subMonths } from 'date-fns';
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import message from '../assets/images/customer/message.svg';
import phone from '../assets/images/customer/phone.svg';
import sorting from '../assets/images/sorting.svg';
import AdvancedFilter from '../components/AdvancedFilter';
import CommunicationHistoryDrawer from "../components/Drawers/CommunicationDrawer";
import Disposition from "../components/Drawers/Disposition";
import BackdropLoader from "../components/Loader/BackdropLoader";
import AdvancedSearchFields from "../modals/AdvancedSearchFields";
import FilterModal from "../modals/SaveFilterModal";
import { setActiveFilterField, setCallQueueType, setCallToggle, setCount, setFilterName, setFilters, setFilterValues, setFromDate, setMIBLcount, setPage, setSearch, setSearchType, setSelectedFilter, setSelectedFilters, setSortField, setSortOrder, setToDate, setTodayCount } from "../redux/slices/callQueueSlice";
import { applyCQFilter, getCallQueueDetails, getFilterValue, getHeaders, getHistory, getSavedFilter, saveLeadFilter, searchCallQueue } from "../services/api";
import { decryptRoute, encryptRoute } from "../services/encrypt";
import { transformDate } from "../services/transformDate";
import { bgGray100, bluebg, btnRed, cursorpointer, greenbg, orangebg, pinkbg, selectedTabCount, tabselectedBg } from '../utils/Colors';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import CustomDateRange from '../components/DateRange/CustomDateRange';

const CallQueue = () => {
    const { encrypted } = useParams();
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const fetchUserByManager = useSelector((state) => state.user.fetchUserByManager);
    const showToggle = decryptRoute(decodeURIComponent(encrypted)) === '/callqueue';
    const userdata = useSelector((state) => state?.user?.loggedData);
    const caller = userdata?.callingFlag === 'Y';

    const [openMobileSearch, setOpenMobileSearch] = useState(false);
    const [loading, setLoading] = useState(false);

    const highlightStatuses = [
        "Quote Shared",
        "Insurer Selected",
        "Declaration Acknowledged",
        "CKYC Completed",
        "Proposal Confirmed",
        "Payment Completed",
        "Policy Issued",
        "Policy Booked"
    ];
    const minAllowedDate = useMemo(() => startOfMonth(subMonths(new Date(), 1)), []);
    const maxAllowedDate = useMemo(() => addYears(new Date(), 1), []);
    // const [fromDate, setFromDate] = useState(null);
    // const [toDate, setToDate] = useState(null);
    const selectedDate = (date) => {
        date?.startDate ? dispatch(setFromDate(date?.startDate)) : dispatch(setFromDate(null));
        date?.endDate ? dispatch(setToDate(date?.endDate)) : dispatch(setToDate(null));
    };
    const anchorRef = useRef(null);

    const [rows, setRows] = useState([]);
    const [columns, setColumns] = useState([]);
    const [limit, setLimit] = useState(10);
    // const [search, setSearch] = useState({
    //     name: '',
    //     phoneNumber: '',
    //     vinNumber: '',
    //     registrationNo: '',
    //     policyNo: '',
    //     policyTenure: '',
    //     policyType: '',
    //     make: '',
    //     model: '',
    //     variant: '',
    //     vehicleClass: '',
    //     engineNo: ''
    // });
    // const [count, setCount] = useState(0);
    // const [todayCount, setTodayCount] = useState(0);
    // const [callQueueType, setCallQueueType] = useState('');
    // const [page, setPage] = useState(1);
    // const [callToggle, setCallToggle] = useState(['', 'current']);
    // const [filterName, setFilterName] = useState('');
    // const [filters, SetFilters] = useState({});
    // const [activeFilterField, setActiveFilterField] = useState(null);
    // const [selectedFilters, setSelectedFilters] = useState({});
    // const [selectedFilter, setSelectedFilter] = useState('');
    // const [searchType, setSearchType] = useState('');
    const navigate = useNavigate();
    const [showAdvanced, setShowAdvanced] = useState(false);
    const [anchorFN, setAnchorFN] = useState(null);
    const open = Boolean(anchorFN);
    const isCaller = useSelector((state) => state.user.isCaller);
    const [openDrawer, setOpenDrawer] = useState(false);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [dispositionData, setDispositionData] = useState(null);
    const [communicationData, setCommunicationData] = useState([]);
    const dispatch = useDispatch();

    const handleToggleAdvanced = () => setShowAdvanced(!showAdvanced);

    // useEffect(() => {
    //     setSearch({
    //         name: '',
    //         phoneNumber: '',
    //         vinNumber: '',
    //         registrationNo: '',
    //         policyNo: '',
    //         policyTenure: '',
    //         policyType: '',
    //         make: '',
    //         model: '',
    //         variant: '',
    //         vehicleClass: '',
    //         engineNo: ''
    //     });
    // }, [])

    // const [filterValues, setFilterValues] = useState({
    //     'Renewal Category': [],
    //     'Expiry Days': '',
    //     'Recent Updates': [],
    //     'Status': [],
    //     'Lead': ["Hot", "Warm", "Cold"],
    // });

    const {
        search,
        count,
        todayCount,
        miblCount,
        callQueueType,
        page,
        selectedFilters,
        selectedFilter,
        searchType,
        callToggle,
        filterName,
        filters,
        activeFilterField,
        filterValues,
        sortField,
        sortOrder,
        ebmColorList,
        fromDate,
        toDate
    } = useSelector(state => state.callQueue);


    const showMessage = (msg, type = 'success') => {
        if (type === 'success') {
            toast.success(msg);
            refresh();
        } else {
            toast.error(msg);
        }
    };

    const handleDrawerOpen = (row) => {
        fetchCommunication(row);
        setIsDrawerOpen(true);
    };

    const fetchCommunication = async (row) => {
        let response = await getHistory({ leadId: row.leadId, clusterId: row.clusterId, vehicleName: row.vehicleName, type: 'communication' });
        setCommunicationData(response.communication);
    }

    const handleOpenDrawer = (row) => {
        setDispositionData(row);
        setOpenDrawer(true);
    };

    const handleCloseDrawer = () => {
        setOpenDrawer(false);
        setDispositionData(null);
    };

    const handleDrawerClose = () => {
        setIsDrawerOpen(false);
        setCommunicationData(null);
    };

    const handleSearchInput = (key, value) => {
        let isValid = false;

        switch (key) {
            case 'name':
                isValid = /^[A-Za-z .]{0,30}$/.test(value);
                if ((value === '' || isValid) && value.length <= 30) {
                    dispatch(setSearch({ ...search, [key]: value }));
                }
                break;

            case 'phoneNumber':
                isValid = /^[0-9]{0,10}$/.test(value);
                if (value === '' || isValid) {
                    dispatch(setSearch({ ...search, [key]: value }));
                }
                break;

            case 'vinNumber':
                isValid = /^[A-Za-z0-9]{0,17}$/.test(value);
                if (value === '' || isValid) {
                    dispatch(setSearch({ ...search, [key]: value }));
                }
                break;

            case 'registrationNo':
                isValid = /^[A-Za-z0-9-]{0,50}$/.test(value);
                if (value === '' || isValid) {
                    dispatch(setSearch({ ...search, [key]: value }));
                }
                break;

            default:
                dispatch(setSearch({ ...search, [key]: value }));
        }
    };

    const handleClick = (event) => {
        setAnchorFN(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorFN(null);
    };
    const [openDialog, setOpenDialog] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null);
    const { user_id, roleId, dealerCode } = useSelector((state) => state?.user?.loggedData);

    const navigate360Page = (row) => {
        navigate(`/${encodeURIComponent(encryptRoute('/callqueue/customerdetails'))}`, { state: { row, callType: callQueueType } });
    }

    const handleSearch = async (offset = page) => {
        setShowAdvanced(false);
        if (Object.values(search).join('') === '') {
            if (searchType) fetchData();
            dispatch(setSearchType(''));
        }
        else {
            searchData(offset);
        }
    }

    const searchData = async (offset) => {
        offset = offset ?? page;
        dispatch(setSearchType('search'));
        try {
            setLoading(true);
            const result = await searchCallQueue({
                limit, offset, search, userId: user_id, type: isCaller, callQueueType: isCaller === 'caller' ? callQueueType : isCaller, sortField, sortOrder, dealerCode
            });
            setRows(callQueueType ? result?.data?.todayList : result?.data?.totalList);
            dispatch(setCount(result?.data?.totalCount[0]?.total));
            if (isCaller === 'caller') dispatch(setTodayCount(result?.data?.todayCount[0]?.total));
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    const handleFilterSelect = (e) => {
        dispatch(setSelectedFilter(e.target.value));
        dispatch(setSelectedFilters(filters[e.target.value]));
        applyFilter(1, filters[e.target.value]);
    }

    const handleFilterClick = (event, column) => {
        setAnchorEl(event.currentTarget);
        dispatch(setActiveFilterField(column));
    };

    const validateFilterName = async () => {
        try {
            setLoading(true);
            const data = await getSavedFilter(user_id, dealerCode);
            let filterNames = [...new Set(data.map(item => item.filterName))];
            if (filterNames.includes(filterName)) {
                toast.error(`${filterName} already exits.`);
            }
            else {
                saveFilter();
            }
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    const saveFilter = async () => {
        setOpenDialog(!filterName);
        let filters = [];
        if (filterName) {
            Object.keys(selectedFilters).map((filter) => {
                if (filter === 'Expiry Days' || filter === 'Expiry Date From' || filter === 'Expiry Date To') {
                    filters.push({
                        userId: user_id,
                        dealerCode: dealerCode,
                        filterName: filterName,
                        filterType: filter,
                        filterValue: selectedFilters[filter],
                    })
                }
                else if (selectedFilters[filter].length > 0) {
                    selectedFilters[filter].map((sv) => filters.push({
                        userId: user_id,
                        dealerCode: dealerCode,
                        filterName: filterName,
                        filterType: filter,
                        filterValue: sv,
                    }));
                }
            });
            let response = await saveLeadFilter(filters);
            if (response) {
                handleClose();
                dispatch(setFilterName(''));
                getSavedFilters();
                applyFilter(1);
            }
        }
    };

    const getSavedFilters = async () => {
        try {
            setLoading(true);
            const res = await getSavedFilter(user_id, dealerCode);
            let resFilter = {};
            res.forEach(({ filterName, filterType, filterValue }) => {
                if (!resFilter[filterName]) {
                    resFilter[filterName] = {};
                }
                if (!resFilter[filterName][filterType]) {
                    resFilter[filterName][filterType] = [];
                }
                if (!resFilter[filterName][filterType].includes(filterValue)) {
                    resFilter[filterName][filterType].push(filterValue);
                }
                if (filterType === 'Expiry Days' || filterType === 'Expiry Date From' || filterType === 'Expiry Date To') {
                    resFilter[filterName][filterType] = filterValue
                }
            });
            dispatch(setFilters(resFilter));
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    const fetchPage = async () => {
        try {
            setLoading(true);
            const result = await getHeaders({ pageId: 2, user_id, accessType: isCaller === 'noncaller' ? isCaller : 'caller' });
            const response = result.data;
            setColumns(response?.inputModel.filter(f => f.parentId === null).map((f) => ({ field: f.inputName, filter: f.filter })));
            if (filters && Object.keys(filters).length === 0) {
                fetchFilterData();
                getSavedFilters();
            }
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false)
        }
    };

    const fetchData = async () => {
        dispatch(setSearchType(''));
        try {
            setLoading(true);
            const result = await getCallQueueDetails({
                limit, page, userId: user_id, dealerCode,
                callQueueType:
                    isCaller === "caller"
                        ? callQueueType === "mibl"
                            ? "callCenter"
                            : callQueueType
                        : isCaller,
                // callQueueType: isCaller === 'caller' ? callQueueType : isCaller,
                sortField, sortOrder
            });
            const response = result.data;
            if (response.statusCode === '200') {
                setRows(response.result0);
                dispatch(setCount(response.result1[0].totalCallQueue));
                dispatch(setTodayCount(response?.result2?.[0]?.currentCallQueue ?? 0));
                dispatch(setMIBLcount(response?.result3?.[0]?.miblCallQueue ?? 0));
                // setRows(response.callQueueDetails);
                // dispatch(setCount(response.totalCallQueue));
                // dispatch(setTodayCount(response.currentCallQueue));
                // setTableData(response.callQueueDetails);
            }
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    const fetchFilterData = async () => {
        try {
            setLoading(true);
            const response = await getFilterValue();
            let filters = { ...filterValues };
            filters['Renewal Category'] = response.renewalCategories?.map(f => f.renewalCategoryName);
            filters['Status'] = response.dispositionStatus?.map(f => f.nextStatus);
            filters['Recent Updates'] = response.dispositionStatuses?.map(f => f.stepName);
            filters['EBM'] = response.ebmStatus?.map(f => f.ebmStatus);
            dispatch(setFilterValues(filters));
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleClearFilters = () => {
        dispatch(setFromDate(null));
        dispatch(setToDate(null));
        dispatch(setSelectedFilter(''));
        dispatch(setSelectedFilters({}));
        dispatch(setSearchType(''));
        dispatch(setPage(1));
        fetchData();
        handleClose();
    }

    const applyFilter = async (offset = page, filterApply = selectedFilters) => {
        if (Object.values(filterApply).join('') === '' && !(fromDate && toDate)) {
            handleClearFilters();
        }
        else {
            dispatch(setPage(offset));
            dispatch(setSearchType('filter'));
            let filters = [];
            Object.keys(filterApply).map((filter) => {
                if (filter === 'Expiry Days' || filter === 'Expiry Date From' || filter === 'Expiry Date To') {
                    filters.push({
                        filterType: filter,
                        filterValue: filterApply[filter],
                    })
                }
                else if (filterApply[filter].length > 0) {
                    filterApply[filter].map((sv) => filters.push({
                        filterType: filter,
                        filterValue: sv,
                    }));
                }
            });
            if (fromDate && toDate) {
                filters.push({
                    filterType: "Expiry Date From",
                    filterValue: fromDate,
                });
                filters.push({
                    filterType: "Expiry Date To",
                    filterValue: toDate,
                });
            }
            try {
                setLoading(true);
                const response = await applyCQFilter({
                    limit, page: offset || page, search, userId: user_id, dealerCode, type: isCaller, filters, callQueueType, sortField, sortOrder
                });
                setRows(response?.LeadFilter ?? []);
                dispatch(setCount(response?.totalCount?.[0]?.total ?? 0));
                if (isCaller === 'caller') dispatch(setTodayCount(response?.todayCount?.[0]?.total ?? 0));
            } catch (error) {
                console.error(error);
            } finally {
                setLoading(false);
            }
        }
        setAnchorFN(null);
    }

    useEffect(() => {
        if (isCaller === 'caller') {
            dispatch(setCallToggle(['', 'current', 'mibl']));
        }

        if (isCaller === 'noncaller') {
            dispatch(setCallToggle(['']));
            dispatch(setCallQueueType(''));
        }

        fetchPage();

        if (columns?.length) refresh();
    }, [isCaller]);

    useEffect(() => {
        fetchFilterData();
    }, []);

    const clearSearchFields = () => {
        dispatch(setSearch({
            name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: ''
        }));
        dispatch(setSearchType(''));
        dispatch(setPage(1));
        fetchData();
        // fetchData();
    }

    useEffect(() => {
        refresh();
    }, [page, sortField, sortOrder, callQueueType, fromDate, toDate]);

    const refresh = () => {
        if (searchType === 'search') {
            handleSearch();
        }
        else if (searchType === 'filter' || (fromDate && toDate)) {
            applyFilter();
        }
        else {
            fetchData();
        }
    }

    const handleSort = (field) => {
        if (sortField === field) {
            dispatch(setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc'));
        } else {
            dispatch(setSortField(field));
            dispatch(setSortOrder('asc'));
        }
    };

    return (
        <>
            <BackdropLoader loading={loading} />
            {/* <MarqueeInfo /> */}

            <Dialog
                // className="advanced-search-dialog"
                open={openMobileSearch}
                onClose={() => setOpenMobileSearch(false)}
                fullWidth
                maxWidth="md"
            >
                <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography>
                        Advanced Search
                    </Typography>
                    {Object.values(search).some(val => val != "") &&
                        <Button
                            className="text-capitalize highlight-red"
                            sx={{ width: "100px", p: 0, m: 0, fontWeight: "bold" }}
                            onClick={() => {
                                // setSearch({
                                //     name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: ''
                                // });
                                dispatch(setSearch({
                                    name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: ''
                                }));
                                dispatch(setSearchType(''));
                                dispatch(setPage(1));
                                fetchData();
                            }}
                        >
                            Clear All
                        </Button>}
                </DialogTitle>

                <DialogContent className="advanced-search-modal">
                    <AdvancedSearchFields
                        search={search}
                        handleSearchInput={handleSearchInput}
                        isMobile={true}
                        handleToggleAdvanced={handleToggleAdvanced}
                        handleSearch={handleSearch}
                        setSearch={() => { }}
                        clearSearchFields={clearSearchFields}
                    />
                </DialogContent>

                <DialogActions>
                    <Button className="highlight-red" onClick={() => setOpenMobileSearch(false)}>
                        Cancel
                    </Button>
                    <Button
                        className="btn-common-red"
                        onClick={() => {
                            handleSearch(1);
                            setOpenMobileSearch(false);
                        }}
                    >
                        Apply Search
                    </Button>
                </DialogActions>
            </Dialog>

            <Stack width={'inherit'}>
                <Paper className="body-formbg" sx={{ borderTop: '1px solid rgb(211, 203, 203)', boxShadow: 'none' }}>
                    <Box position="relative">
                        {isMobile && (
                            <Button
                                className="btn-common-red"
                                sx={{
                                    width: "90%",
                                    mt: 4,
                                    mx: 2
                                }}
                                onClick={() => setOpenMobileSearch(true)}
                                startIcon={<SearchIcon />}
                            >
                                Search
                            </Button>
                        )}
                        {!isMobile && (
                            <AdvancedSearchFields
                                search={search}
                                handleSearchInput={handleSearchInput}
                                isMobile={false}
                                handleSearch={handleSearch}
                                setSearch={setSearch}
                                handleToggleAdvanced={handleToggleAdvanced}
                                showAdvanced={showAdvanced}
                                clearSearchFields={clearSearchFields}
                            />
                        )}
                    </Box>
                </Paper>

                <Paper elevation={0} sx={{
                    px: isMobile ? 1 : 2.5, py: 1, ...bgGray100, boxShadow: 'none'
                }}>
                    <Box
                        display="flex"
                        alignItems="center"
                        justifyContent="space-between"
                        flexWrap="wrap"
                        gap={2}
                        mb={1}
                    >
                        {/* Left Side: Labels */}
                        <Box display="flex" alignItems="center" gap={2}>
                            <ToggleButtonGroup
                                value={callQueueType}
                                exclusive
                                onChange={(e, newValue) => {
                                    if (newValue !== null) dispatch(setCallQueueType(newValue));
                                }}
                                sx={{ display: 'flex', gap: 1, border: 'none' }}>
                                {callToggle?.map((v, index) => (
                                    <ToggleButton
                                        exclusive
                                        className="toggle-button"
                                        key={v}
                                        value={v}
                                    >
                                        {v === ''
                                            ? "Call Queue"
                                            : v === "current"
                                                ? "Today Call"
                                                : "MIBL Call Center Cases"}
                                        <Chip
                                            className="font-size-8 custom-chip-height"
                                            label={
                                                v === ''
                                                    ? count
                                                    : v === "current"
                                                        ? todayCount
                                                        : v === "mibl"
                                                            ? miblCount
                                                            : 0
                                            }
                                            sx={{
                                                backgroundColor:
                                                    callQueueType === v ? tabselectedBg : selectedTabCount,
                                                color: "white",
                                                ml: 1,
                                                borderRadius: 10,
                                            }}
                                        />
                                    </ToggleButton>
                                ))}
                            </ToggleButtonGroup>
                        </Box>

                        {/* Right Side: Filters & Marquee */}
                        <Box display="flex" alignItems="center" gap={1} overflow={"hidden"}>
                            {(Object.values(selectedFilters).join('') || fromDate || toDate) && <Button
                                onClick={handleClearFilters}
                                sx={{
                                    border: "1px solid red",
                                    px: 1,
                                    py: 0.5,
                                    color: "red",
                                    backgroundColor: 'transparent',
                                }}
                                endIcon={<TuneIcon />}
                            >
                                Clear Filters
                            </Button>}

                            <FormControl size="small">
                                <Select onChange={handleFilterSelect}
                                    defaultValue=""
                                    value={selectedFilter}
                                    displayEmpty
                                    sx={{
                                        p: 0,
                                        m: 0,
                                        fontSize: '14px',
                                        borderRadius: 2,
                                        backgroundColor: '#fff',
                                    }}
                                >
                                    <MenuItem disabled value="">Saved Filter</MenuItem>
                                    {filters && Object.keys(filters).map(f => <MenuItem value={f}>{f}</MenuItem>)}
                                </Select>
                            </FormControl>

                            <>
                                <Button onClick={handleClick}
                                    size="small"
                                    variant="outlined"
                                    startIcon={<TuneIcon />}
                                    sx={{
                                        borderRadius: 2,
                                        py: 0.8,
                                        textTransform: 'none',
                                        borderColor: '#ccc',
                                        color: 'black',
                                        backgroundColor: '#fff',
                                    }}
                                >
                                    Filters
                                </Button>
                                <Popover
                                    open={open}
                                    anchorEl={anchorFN}
                                    onClose={handleClose}
                                    anchorOrigin={{
                                        vertical: 'bottom',
                                        horizontal: 'left',
                                    }}
                                    PaperProps={{ sx: { mt: 1 } }}
                                >
                                    <AdvancedFilter saveFilter={saveFilter} applyFilter={() => applyFilter(1)} resetFilter={handleClearFilters} />
                                </Popover>
                            </>

                            {/* <Box sx={{ width: 500, backgroundColor: "#fff", py: 1, border: "1px solid #555", borderColor: '#ccc', borderRadius: 2, color: "red" }}>
                                <Marquee
                                    gradient={false}
                                    speed={50}
                                    pauseOnHover
                                    style={{ gap: "200px" }}>
                                    Mahindra offers various insurance policies for new vehicles with potential discounts and offers.
                                </Marquee>
                            </Box> */}
                        </Box>
                    </Box>

                    <TableContainer component={Box} sx={{ mt: 0 }}>
                        <Table sx={{ minWidth: 1200, borderCollapse: 'separate', borderSpacing: '0 4px' }} stickyHeader>
                            <TableHead>
                                <TableRow className="bg-white">
                                    {columns?.map((cell, index) => (
                                        <TableCell className="custom-table-cell-header bg-white fs-14"
                                            key={index}
                                            sx={{
                                                borderBottom: 'none',
                                                borderTopLeftRadius: index === 0 ? 6 : 0,
                                                borderTopRightRadius: index === columns.length - 1 ? 6 : 0,
                                                borderBottomLeftRadius: index === 0 ? 6 : 0,
                                                borderBottomRightRadius: index === columns.length - 1 ? 6 : 0,
                                            }}
                                        >
                                            <Box className="cq-ps-2" display="flex" alignItems="center" sx={{}}>
                                                {(cell.field.slice(0, 6).toLowerCase() === 'expiry' || cell.field.slice(0, 8).toLowerCase() === 'customer'
                                                    || cell.field.slice(0, 6).toLowerCase() === 'status' || cell.field.slice(0, 7).toLowerCase() === 'vehicle'
                                                    || cell.field.slice(0, 7).toLowerCase() === 'renewal') &&
                                                    sortField === cell.field ? (
                                                    sortOrder === 'asc' ? <NorthIcon className='cursor-pointer' fontSize="1" onClick={() => handleSort(cell.field)} />
                                                        : <SouthIcon className='cursor-pointer' fontSize="1" onClick={() => handleSort(cell.field)} />
                                                ) : ((cell.field.slice(0, 6).toLowerCase() === 'expiry' || cell.field.slice(0, 8).toLowerCase() === 'customer'
                                                    || cell.field.slice(0, 6).toLowerCase() === 'status' || cell.field.slice(0, 7).toLowerCase() === 'vehicle'
                                                    || cell.field.slice(0, 7).toLowerCase() === 'renewal')
                                                    &&
                                                    <img className='cursor-pointer' src={sorting} alt="sort" onClick={() => handleSort(cell.field)} />
                                                )}
                                                <span className="cq-py-2 cq-px-1 fs-14 text-dark georama-Medium">{cell.field}</span>
                                                {cell.filter === "1" && <KeyboardArrowDownOutlinedIcon className='cursor-pointer'
                                                    onClick={cell.filter === "1" ? (e) => handleFilterClick(e, cell.field) : undefined} ref={cell.field === 'Expiry Date' ? anchorRef : null} />}
                                            </Box>
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>

                            <TableBody>
                                {loading ? (
                                    [...Array(8)].map((_, idx) => (
                                        <TableRow key={idx}>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        </TableRow>
                                    ))
                                ) : (rows && rows?.length > 0 ? rows?.map((row, index) => (
                                    <TableRow
                                        key={index}
                                        sx={{
                                            backgroundColor: 'white',
                                            borderRadius: 2,
                                            borderBottom: 'none',
                                            boxShadow: '0px 2px 6px rgba(0, 0, 0, 0.05)',
                                            overflow: 'hidden',
                                            '& td:first-of-type': {
                                                borderTopLeftRadius: '8px',
                                                borderBottomLeftRadius: '8px',
                                            },
                                            '& td:last-of-type': {
                                                borderTopRightRadius: '8px',
                                                borderBottomRightRadius: '8px',
                                            },
                                        }}
                                    >
                                        <TableCell onClick={() => navigate360Page(row)} sx={{
                                            // ...fonts.GeoramaRegular,
                                            ...cursorpointer,
                                            borderLeft: `4px solid ${row.leadType?.trim().toLowerCase() === 'hot'
                                                ? '#e53935'
                                                : row.leadType?.trim().toLowerCase() === 'cold'
                                                    ? '#1e88e5' :
                                                    row.leadType?.trim().toLowerCase() === 'warm' ? '#f07d2d' : 'transparent'
                                                }`,
                                        }} className="georama-Regular fs-14 custom-table-cell-p pr-2 pl-2">
                                            <span className="text-dark georama-Medium fs-12 text-truncate">{row?.customerName}</span><br />
                                            <small className="fs-10 text-gray">Lead Id {row?.leadId}</small>
                                        </TableCell>
                                        <TableCell className="georama-Regular fs-14 custom-table-cell-p">
                                            <span className="text-dark georama-Medium fs-12 text-truncate">{row?.vehicleName}</span><br />
                                            <small className="fs-10 text-gray">{row?.vehicleRegNo ? <>Reg No : <b>{row?.vehicleRegNo}</b></> : ""}</small>
                                        </TableCell>
                                        {
                                            Object.keys(row).slice(5, -6).map((f) => <TableCell className="georama-Regular font-size-14 custom-table-cell-p" key={f}>{
                                                f.slice(0, 6).toLowerCase() === 'recent' && row[f] ? transformDate(row[f]).split('\n').map((line, index) => (
                                                    <React.Fragment key={index}>
                                                        <span className="text-gray fs-12">
                                                            {line.trim()}
                                                        </span>
                                                        <br />
                                                    </React.Fragment>
                                                ))
                                                    : f.slice(0, 6).toLowerCase() === 'expiry'
                                                        ? <><span className="text-gray fs-12 ">{format(parseISO(row[f]), 'dd MMM yyyy')}</span>
                                                            <br />
                                                            <span className="highlight-red fs-12 ">Exp Days {String(row.expiryDays).padStart(2, '0')} days</span></>
                                                        :
                                                        <span className={f === "renewalCategory" ? "pl-2 text-dark georama-Medium fs-12" : "pl-2 text-gray fs-12"}>{row[f]}</span>
                                            }</TableCell>)
                                        }
                                        <TableCell className="georama-Regular font-size-14 custom-table-cell-p pl-2">
                                            <Box
                                                component="span"
                                                className="pl-2"
                                                sx={{
                                                    padding: '4px 12px',
                                                    borderRadius: '12px',
                                                    fontSize: '12px',
                                                    fontWeight: 500,
                                                    color: 'white',
                                                    backgroundColor:
                                                        row?.recentUpdates?.startsWith('Callback Scheduled')
                                                            ? greenbg
                                                            : row?.recentUpdates?.startsWith('Interested')
                                                                ? pinkbg
                                                                : row?.recentUpdates?.startsWith('Follow-Up')
                                                                    ? orangebg : (!!row?.status && row?.status !== '(0)') ? bluebg : 'transparent',
                                                }}
                                            >
                                                {row.status}
                                            </Box>
                                        </TableCell>
                                        <TableCell className="georama-Regular fs-12 custom-table-cell-p pl-2">
                                            <Box
                                                component="span"
                                                className="pl-2"
                                                sx={{
                                                    padding: '4px 12px',
                                                    borderRadius: '12px',
                                                    fontWeight: 600,
                                                    backgroundColor: 'white',
                                                    color: highlightStatuses.includes(row.ebmStatus)
                                                        ? ebmColorList[row.ebmStatus]
                                                        : "var(--gray-color-700)",
                                                    //  
                                                    border: highlightStatuses.includes(row.ebmStatus)
                                                        ? `2px solid ${ebmColorList[row.ebmStatus]}`
                                                        : `1.5px solid var(--gray-color-700)`,
                                                    // color: row.ebmStatusColor,
                                                    // border: `2px solid ${row.ebmStatusColor}`,
                                                }}
                                            >
                                                {row.ebmStatus === "" ? "N/A" : row.ebmStatus}
                                            </Box>
                                        </TableCell>
                                        <TableCell className="georama-Regular font-size-14 custom-table-cell-p pl-2">
                                            <Stack direction="row" spacing={1}>
                                                {/* <Tooltip title="Call">
                                                    <IconButton sx={{ ...callbg, width: 35, height: 35 }}>
                                                        <PhoneRoundedIcon sx={{ color: '#4b4bc7' }} />
                                                    </IconButton>
                                                </Tooltip>
                                                <Tooltip title="Message">
                                                    <IconButton sx={{ ...messagebg, width: 35, height: 35 }}>
                                                        <MessageRoundedIcon sx={{ color: '#3cb371' }} />
                                                    </IconButton>
                                                </Tooltip> */}
                                                {isCaller === 'caller' &&
                                                    <Tooltip title="Update Disposition" onClick={() => handleOpenDrawer(row)}>
                                                        <IconButton sx={{ width: 30, height: 30, border: '1px solid #ccc' }}>
                                                            <img src={phone} alt="Update Disposition" />
                                                        </IconButton>
                                                    </Tooltip>}
                                                {/* <PhoneInTalkIcon sx={{ color: '#f07d2d' }} /> */}
                                                <Tooltip title="Communication" onClick={() => handleDrawerOpen(row)}>
                                                    <IconButton sx={{ width: 30, height: 30, border: '1px solid #ccc' }}>
                                                        {/* <ForumRoundedIcon sx={{ color: '#1ca6d4' }} /> */}
                                                        <img src={message} alt="Communication" />
                                                    </IconButton>
                                                </Tooltip>
                                            </Stack>
                                        </TableCell>
                                    </TableRow>
                                )) :
                                    ((!rows || !rows?.length) && <TableRow>
                                        <TableCell colSpan={!columns?.length ? 0 : columns?.length + 1} className='no-data-found'><Box className="center-text">No Records Found.</Box></TableCell>
                                    </TableRow>)
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>

                    <Box>
                        {/* <Typography display={'inline'}>Show result: </Typography>
                        <Select size="small" sx={{ width: 75, borderRadius: 3, m: 1 }} value={limit} onChange={(e) => setLimit(e.target.value) || setPage(1)}>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={20}>20</MenuItem>
                            <MenuItem value={50}>50</MenuItem>
                            <MenuItem value={100}>100</MenuItem>
                        </Select> */}

                        {(callQueueType === "mibl" ? miblCount : callQueueType === "current" ? todayCount : count) > 0 && <Pagination size="medium" count={Math.ceil((callQueueType === "mibl" ? miblCount : callQueueType === "current" ? todayCount : count) / limit)} page={page} onChange={(e, v) => dispatch(setPage(v))} shape="rounded"
                            sx={{
                                float: 'right', m: 1,
                                '& .MuiPaginationItem-root': {
                                    borderRadius: 3,
                                }
                            }} />}
                    </Box>
                </Paper>
                <Popper open={(anchorEl && !(activeFilterField === "Expiry Date"))} anchorEl={anchorEl} placement="bottom-start" style={{ zIndex: 1400 }}>
                    <ClickAwayListener onClickAway={() => setAnchorEl(null)}>
                        <Paper sx={{ minWidth: 150 }}>
                            {activeFilterField === 'Recent Updates' && (
                                <>
                                    <Box sx={{
                                        maxHeight: 180,
                                        overflowY: 'auto',
                                        '&::-webkit-scrollbar': { width: '2px' },
                                        '&::-webkit-scrollbar-thumb': { backgroundColor: '#e53935', borderRadius: '2px' },
                                        '&::-webkit-scrollbar-track': { backgroundColor: '#f1f1f1' },
                                    }}>

                                        {(
                                            <>
                                                <FormControlLabel
                                                    control={
                                                        <Checkbox
                                                            sx={{
                                                                mx: 1,
                                                                color: '#e53935',
                                                                '&.Mui-checked': { color: '#e53935' },
                                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                            }}
                                                            indeterminate={
                                                                selectedFilters?.['Recent Updates'] &&
                                                                selectedFilters?.['Recent Updates']?.length > 0 &&
                                                                selectedFilters?.['Recent Updates']?.length < filterValues['Recent Updates']?.length
                                                            }
                                                            checked={
                                                                (selectedFilters?.['Recent Updates'] || []).length === filterValues['Recent Updates']?.length
                                                            }
                                                            onChange={(e) => {
                                                                const updated = e.target.checked ? [...filterValues['Recent Updates']] : [];
                                                                dispatch(setSelectedFilters({ ...selectedFilters, ['Recent Updates']: updated }));
                                                            }}
                                                        />
                                                    }
                                                    label="All"
                                                />

                                                {filterValues['Recent Updates']?.map((category) => (
                                                    <FormControlLabel
                                                        key={category}
                                                        control={
                                                            <Checkbox
                                                                sx={{ color: '#e53935', '&.Mui-checked': { color: '#e53935' } }}
                                                                checked={(selectedFilters?.['Recent Updates'] || [])?.includes(category)}
                                                                onChange={() => {
                                                                    const current = selectedFilters['Recent Updates'] || [];
                                                                    const updated = current.includes(category)
                                                                        ? current.filter((v) => v !== category)
                                                                        : [...current, category];
                                                                    dispatch(setSelectedFilters({ ...selectedFilters, ['Recent Updates']: updated }));
                                                                }}
                                                            />
                                                        }
                                                        label={category}
                                                        sx={{ px: 1, display: 'block' }}
                                                    />
                                                ))}
                                            </>
                                        )}

                                    </Box>
                                </>
                            )}

                            {/* {activeFilterField === 'Expiry Date' && (
                                <LocalizationProvider dateAdapter={AdapterDateFns}>
                                    <Stack container p={1}>
                                        <Stack>
                                            <Typography className="text-labels" m={1}>
                                                From Date <span className="important-fields">*</span>
                                            </Typography>
                                            <DatePicker
                                                value={fromDate}
                                                onChange={handleFromDateChange}
                                                minDate={minAllowedDate}
                                                maxDate={toDate || maxAllowedDate}
                                                format="yyyy-MM-dd"
                                                slotProps={{
                                                    textField: { fullWidth: true, size: "small" },
                                                    field: {
                                                        readOnly: true,
                                                        onKeyDown: (e) => e.preventDefault(),
                                                        onPaste: (e) => e.preventDefault(),
                                                        inputMode: "none",
                                                        style: { caretColor: "transparent" },
                                                    },
                                                }}
                                            />
                                        </Stack>
        
                                        <Stack>
                                            <Typography className="text-labels" m={1}>
                                                To Date <span className="important-fields">*</span>
                                            </Typography>
                                            <DatePicker
                                                value={toDate}
                                                onChange={handleToDateChange}
                                                minDate={fromDate || minAllowedDate}
                                                maxDate={maxAllowedDate}
                                                format="yyyy-MM-dd"
                                                slotProps={{
                                                    textField: { fullWidth: true, size: "small" },
                                                    field: {
                                                        readOnly: true,
                                                        onKeyDown: (e) => e.preventDefault(),
                                                        onPaste: (e) => e.preventDefault(),
                                                        inputMode: "none",
                                                        style: { caretColor: "transparent" },
                                                    },
                                                }}
                                            />
                                        </Stack>
                                    </Stack>
                                </LocalizationProvider>
                            )} */}
                            <Box display={"flex"} justifyContent={"end"}>
                                <Button
                                    className='btn-common-red'
                                    variant="contained"
                                    size="small"
                                    sx={{ mx: 2, mb: 1, ...btnRed }}
                                    onClick={() => {
                                        setAnchorEl(null);
                                        if (activeFilterField === 'Recent Updates') {
                                            applyFilter(1);
                                        } else if (activeFilterField === 'Expiry Date') {
                                            applyFilter(1);
                                        }
                                    }}
                                >
                                    Apply
                                </Button>
                            </Box>
                        </Paper>
                    </ClickAwayListener>
                </Popper>
                <CustomDateRange
                    open={Boolean(anchorEl && activeFilterField === "Expiry Date")}
                    setOpen={() => setAnchorEl(null)}
                    anchorRef={anchorRef}
                    setDate={selectedDate}
                    onChange={()=>{}}
                    clearDate={() => handleClearFilters()}
                    minDate={minAllowedDate}
                />
                <FilterModal open={openDialog} onClose={() => setOpenDialog(false)} filterName={filterName} setFilterName={(value) => dispatch(setFilterName(value))}
                    validateFilterName={validateFilterName} />
            </Stack>
            <Disposition open={openDrawer} onClose={handleCloseDrawer} dispositionData={dispositionData} showMessage={showMessage} />
            <CommunicationHistoryDrawer open={isDrawerOpen} onClose={handleDrawerClose} communication={communicationData} />
            <ToastContainer autoClose={1000} />
        </>
    )
}

export default CallQueue;