import { Grid, Autocomplete, Typography, Box, Button, TextField, Paper, Stack, Divider, FormControlLabel, FormHelperText, CircularProgress, useMediaQuery } from '@mui/material';
import WestIcon from '@mui/icons-material/West';
import { borderRed, bgGray100, checkBoxRed, btnRed, colorRed } from '../utils/Colors';
import FormLabel from '@mui/material/FormLabel';
import Checkbox from '@mui/material/Checkbox';
import { useEffect, useState } from 'react';
import { dealerList, editDealerDetails, getDealerDetails, newDealerSetUp, saveOutletSetup } from '../services/api';
import { policyDetails } from '../sampleJSON';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import SetUpAccordion from '../components/MISPSetup/SetUpAccordion';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { useSelector } from 'react-redux';
import { encryptRoute } from '../services/encrypt';

const CreateDealer = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    const [dealerNames, setDealerNames] = useState([]);
    const [zones, setZones] = useState([]);
    const [states, setStates] = useState([]);
    const [dealerDetails, setDealerDetails] = useState([]);
    const [locations, setLocations] = useState([]);
    const [crossAllocations, setCrossAllocations] = useState([]);
    const [customTemplates, setCustomTemplates] = useState([]);
    const [accordion, setAccordion] = useState(null);
    const [mappingSaved, setMappingSaved] = useState({});
    const [columnMapping, setColumnMapping] = useState([]);
    const [selectedTemplates, setSelectedTemplates] = useState([]);
    const navigate = useNavigate();
    const dealerInfo = useState({});
    const [dealerAddress, setDealerAddress] = useState('');
    const accordionLabels = ['Policy', 'Claim', 'Service', 'Sales Data', 'Add On'];
    const accordionData = ['policy', 'claim', 'service', 'sales', 'addOn'];
    const userdetails = useSelector((state) => state.user.loggedData);
    const [createNew, setCreateNew] = useState(true);
    const [loading, setLoading] = useState(false);

    const fetchData = async (dealerId, parentId) => {
        try {
            const result = await getDealerDetails(dealerId, parentId);
            // setDealerDetails(result);
            setLocations(result.dealerLocations.map((loc) => ({ label: loc.dealerLocName, id: loc.dealerId, ...loc })));
            setCrossAllocations(result.dealerLocations.map((loc) => ({ label: loc.dealerLocName, id: loc.dealerId })));
            // setCustomTemplates(result.templateLocations);
        } catch (error) {
            console.error('Failed to fetch dealer details:', error);
        }
    }

    const fetchNewDealerSetUp = async () => {
        try {
            const result = await newDealerSetUp();
            if (result.status === 200 && result?.data?.statusCode) {
                setZones(result?.data?.dealerAllDetails?.map(z => z.zone));
                setStates(result?.data?.dealerLocations?.map(s => s.state));
            }
        } catch (error) {
            console.error('Failed to fetch dealer details:', error);
        }
    }

    useEffect(() => {
        fetchNewDealerSetUp();
    }, []);

    // --------- Form validate ------
    const [formValues, setFormValues] = useState({
        dealerName: '',
        mobileNo: '',
        ebmCode: dealerInfo?.ebmCode,
        dealerId: dealerInfo?.dealerId,
        parentId: dealerInfo?.parentId,
        zone: null,
        state: null,
        map: null,
        otpFlag: false,
        // existingMap: null,
        leadAssignment: null,
        crossAllocation: [],
        communication: [],
        dealerLocName: '',
        dealerAddress: '',
        policyFlag: "policy_system",
        claimFlag: "claim_system",
        serviceFlag: "service_system",
        salesFlag: "sales_system",
        addOnFlag: "addon_system"
    });

    const [formErrors, setFormErrors] = useState({});

    useEffect(() => {
        if (!formValues.dealerName) {
            setDealerNames([]);
            return;
        }

        const handler = setTimeout(() => {
            let active = true;

            const fetchDealerNames = async () => {
                setLoading(true);
                try {
                    const result = await dealerList({
                        userId: userdetails?.user_id,
                        roleId: userdetails?.roleId,
                        type: 'checkDealerExists',
                        dealerName: formValues.dealerName,
                    });

                    if (active) {
                        const dealers = result?.data?.dealerAllDetails || [];
                        setDealerNames(dealers);

                        const matchedDealer = dealers.find(
                            (d) => d.dealerName?.toLowerCase() === formValues.dealerName?.toLowerCase()
                        );

                        if (matchedDealer?.parentId) {
                            setFormValues((prev) => ({
                                ...prev,
                                parentId: matchedDealer.parentId,
                            }));
                            fetchData("", matchedDealer.parentId);
                        } else {
                            setFormValues((prev) => ({
                                ...prev,
                                parentId: "",
                            }));
                            setLocations([]);
                            setCrossAllocations([]);
                            handleInputChange('map', null);
                        }
                    }
                } catch (error) {
                    console.error('Error fetching dealer names:', error);
                } finally {
                    setLoading(false);
                }
            };

            fetchDealerNames();

            return () => {
                active = false;
            };
        }, 500);

        return () => clearTimeout(handler);
    }, [formValues.dealerName]);

    const handleInputChange = (field, value) => {
        setFormValues(prev => ({
            ...prev,
            [field]: value,
        }));
        if (!value && field === 'map') {
            setCreateNew(true)
            setFormValues(prev => ({
                ...prev,
                ['leadAssignment']: '',
                ['crossAllocation']: [],
                ['communication']: [],
                ['policyFlag']: 'policy_system',
                ['claimFlag']: 'claim_system',
                ['serviceFlag']: 'service_system',
                ['salesFlag']: 'sales_system',
                ['addOnFlag']: 'addon_system',
                ['otpFlag']: false,
            }));
        };
        if (value && field === 'map') {
            setCreateNew(value.id === "" || value.id === dealerInfo?.dealerId);
            if (value.id !== "" && value.id !== dealerInfo?.dealerId) {
                setFormValues(prev => ({
                    ...prev,
                    ['leadAssignment']: value.leadAssignment,
                    ['crossAllocation']: value.crossAllocation.split(','),
                    ['communication']: value.communication.split(','),
                    ['policyFlag']: value.policyFlag,
                    ['claimFlag']: value.claimFlag,
                    ['serviceFlag']: value.serviceFlag,
                    ['salesFlag']: value.salesFlag,
                    ['addOnFlag']: value.addOnFlag,
                    ['otpFlag']: value?.otpFlag === 'Yes',
                }));
            } else {
                setFormValues(prev => ({
                    ...prev,
                    ['leadAssignment']: '',
                    ['crossAllocation']: [],
                    ['communication']: [],
                    ['policyFlag']: 'policy_system',
                    ['claimFlag']: 'claim_system',
                    ['serviceFlag']: 'service_system',
                    ['salesFlag']: 'sales_system',
                    ['addOnFlag']: 'addon_system',
                    ['otpFlag']: false,
                }));
                // accordionData.forEach((field) => {
                //     setMappingSaved(prev => ({
                //         ...prev,
                //         [`${field}Flag`]: 0
                //     }));
                // });
            }
            if (value && field === 'leadAssignment' && value !== 'Manual') {
                setFormValues(prev => ({
                    ...prev,
                    ['crossAllocation']: [],
                }));
            }
            setDealerAddress(value.dealerAddress);
            handleInputChange('crossAllocation', value.id === dealerInfo?.dealerId || value.id === "" ? [] : [...formValues.crossAllocation.filter(loc => loc !== value)]);
        }
        else if (!value && field === 'map') {
            setDealerAddress('');
        }
        setFormErrors((prev) => ({ ...prev, [field]: '' }));
        // setFormValues((prev) => ({ ...prev, [field]: value }));
    };

    const handleCheckboxChange = (event) => {
        const { value, checked } = event.target;
        setFormValues((prev) => ({
            ...prev,
            communication: checked
                ? [...prev.communication, value]
                : prev.communication.filter((v) => v !== value),
        }));
    };

    const validateForm = () => {
        const errors = {};

        if (!formValues.dealerName) errors.dealerName = 'Dealer Name is required';
        if (!/^[6-9]\d{9}$/.test(formValues.mobileNo)) errors.mobileNo = "Invalid Mobile No";
        if (!formValues?.mobileNo?.trim()) errors.mobileNo = "Mobile No is required";
        if (!formValues?.dealerLocName?.trim()) errors.dealerLocName = "Location is required";
        if (!formValues?.dealerAddress?.trim()) errors.dealerAddress = "Address is required";
        if (!formValues.map) errors.map = 'Map selection is required';
        if (formValues.map?.id === dealerInfo?.dealerId) {
            if (!formValues.leadAssignment) errors.leadAssignment = 'Lead Assignment is required';
            // accordionData.forEach((field, index) => {
            //     if (formValues?.[`${field}Flag`] !== `${field.toLowerCase()}_system` && (!mappingSaved?.[`${field}Flag`] || mappingSaved?.[`${field}Flag`] < 1)) {
            //         errors[`${field}Flag`] = `Fields Mapping not saved for ${accordionLabels[index]}`;
            //         toast.warning(`Fields Mapping not saved for ${accordionLabels[index]}`);
            //     }
            // });
        }
        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const handleSubmit = async () => {
        if (validateForm()) {
            let formData = { ...formValues };
            formData.communication = formValues?.communication?.join(',');
            formData.map = formValues.map.id;
            formData.mobileNo = formValues.mobileNo;
            formData.dealerAddress = formValues.dealerAddress;
            formData.otpFlag = formValues.otpFlag ? 'Yes' : 'No';
            // formData.existingMap = formValues.existingMap ?? formValues.map.id;
            formData.dealerLocName = formValues.map.id === '' ? formValues.dealerLocName.trim() : '';
            formData.leadAssignment = formValues.leadAssignment;
            formData.crossAllocation = formValues?.crossAllocation?.map(item => item.id).join(',');
            formData.userId = userdetails.user_id;
            formData.flag = 'addNewDealer';
            let response = await saveOutletSetup(formData);
            if (response.statusCode === '200') {
                toast.success('Outlet Setup saved successfully!');
                navigate(`/${encodeURIComponent(encryptRoute('/editmispoutlet'))}`)
            }
            else {
                toast.error('Failed to save Outlet Setup!');
            }
        }
        // else {
        //     accordionData.forEach((field) => {
        //         if (formErrors[`${field}Flag`]) toast.warning(formErrors[`${field}Flag`]);
        //     });
        // }
    };
    // --------- Form validate ------

    const leadData = ['Auto', 'Manual'];

    return (
        <Paper className='body-formbg' sx={{ boxShadow: 'none', m: isMobile ? 1.5 : 2.7, width: 'inherit', height: 'auto', pb: 2, borderRadius: 3 }}>
            <Box className="bg-white  border-radius-8" p={isMobile ? 1 : 2}>
                <Box>
                    <Stack
                        px={1.5}
                        direction="row"
                        sx={{ justifyContent: 'space-between', alignItems: 'center' }}
                    >
                        <Stack>
                            <Typography gutterBottom className='georama-SemiBold fs-20 text-capitalize' component="div">
                                New Dealer
                            </Typography>
                        </Stack>

                        <Button className='text-capitalize georama-medium-selected custom-starticon'
                            startIcon={<ChevronLeftIcon />}
                            onClick={() => navigate(-1)}>
                            Back
                        </Button>
                    </Stack>

                    <Divider />
                </Box>

                <Box p={1.5}>
                    <Grid container rowSpacing={2} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <FormLabel className='text-labels'>Dealer Name <span className="important-fields">*</span></FormLabel>

                            <Autocomplete
                                freeSolo
                                className='form-control-input'
                                size="small"
                                options={dealerNames}
                                getOptionLabel={(option) => option.dealerName}
                                loading={loading}
                                inputValue={formValues.dealerName}
                                onInputChange={(event, value) => {
                                    if (value != 'undefined') {
                                        setFormValues((prev) => ({
                                            ...prev,
                                            dealerName: value,
                                        }));
                                    }
                                }}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        placeholder="Dealer Name"
                                        error={!!formErrors.map}
                                        InputProps={{
                                            ...params.InputProps,
                                            endAdornment: (
                                                <>
                                                    {loading ? <CircularProgress size={20} /> : null}
                                                    {params.InputProps.endAdornment}
                                                </>
                                            ),
                                        }}
                                    />
                                )}
                            />

                            <FormHelperText className='important-fields'>{formErrors.dealerName}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <FormLabel className='text-labels'>Mobile No <span className="important-fields">*</span></FormLabel>

                            <TextField
                                fullWidth
                                size="small"
                                className='form-control-input border-radius-8'
                                required
                                placeholder="Enter Mobile No"
                                value={formValues.mobileNo}
                                onInput={(e) => {
                                    e.target.value = e.target.value.replace(/[^0-9]/g, "");
                                    handleInputChange('mobileNo', e.target.value);
                                }}
                                inputProps={{
                                    inputMode: "numeric",
                                    minLength: 10,
                                    maxLength: 10
                                }}
                                error={!!formErrors.mobileNo}
                            />

                            <FormHelperText className='important-fields'>{formErrors.mobileNo}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <Typography className='text-labels' required>Zone <span className="important-fields">*</span></Typography>

                            <Autocomplete
                                className='form-control-input'
                                size="small"
                                options={zones}
                                value={formValues.zone || null}
                                onChange={(_, value) => handleInputChange('zone', value)}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        placeholder="Select Zone"
                                        error={!!formErrors.zone}
                                    />
                                )}
                            />

                            <FormHelperText className='important-fields'>{formErrors.zone}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <Typography className='text-labels' required>State <span className="important-fields">*</span></Typography>

                            <Autocomplete
                                className='form-control-input'
                                size="small"
                                options={states}
                                value={formValues.state || null}
                                onChange={(_, value) => handleInputChange('state', value)}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        placeholder="Select State"
                                        error={!!formErrors.state}
                                    />
                                )}
                            />

                            <FormHelperText className='important-fields'>{formErrors.state}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <FormLabel className='text-labels'>Location <span className="important-fields">*</span></FormLabel>
                            <TextField
                                className='form-control-input border-radius-8'
                                fullWidth required
                                size="small" placeholder='Enter Location'
                                value={formValues.dealerLocName}
                                onChange={(e) => handleInputChange('dealerLocName',
                                    e.target.value.trimStart().replace(/[^a-zA-Z\s]/g, '').replace(/\s+/g, ' ').slice(0, 50))}
                                error={!!formErrors.dealerLocName}
                            />
                            <FormHelperText className='important-fields'>{formErrors.dealerLocName}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <FormLabel className='text-labels'>Address <span className="important-fields">*</span></FormLabel>
                            <TextField
                                className='form-control-input border-radius-8'
                                fullWidth multiline minRows={2} maxRows={3} required
                                placeholder='Enter Address' size='small'
                                value={formValues.dealerAddress}
                                onChange={(e) => handleInputChange('dealerAddress',
                                    e.target.value.trimStart().slice(0, 500))}
                                error={!!formErrors.dealerAddress}
                            />
                            <FormHelperText className='important-fields'>{formErrors.dealerAddress}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <Typography className='text-labels' required>Map <span className="important-fields">*</span></Typography>

                            <Autocomplete
                                className='form-control-input'
                                size="small"
                                options={(locations.length === 0 || (locations.length > 0 && locations.filter((loc) => loc.id === dealerInfo?.dealerId).length === 0) ?
                                    [{ label: 'Create New', id: dealerInfo?.dealerId ?? "", dealerAddress: formValues?.dealerAddress }] : []).concat([...locations])}
                                value={formValues.map || null}
                                onChange={(_, value) => handleInputChange('map', value)}
                                isOptionEqualToValue={(option, value) => option.id === value.id}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        placeholder="Select Location"
                                        error={!!formErrors.map}
                                    />
                                )}
                            />

                            <FormHelperText className='important-fields'>{formErrors.map}</FormHelperText>
                        </Grid>

                        {createNew &&
                            <>
                                <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                                    <Typography className='text-labels' color="initial" required>Lead Assignment <span className="important-fields">*</span></Typography>

                                    <Autocomplete
                                        className='form-control-input'
                                        size="small"
                                        options={leadData}
                                        value={formValues.leadAssignment || null}
                                        onChange={(_, value) => handleInputChange('leadAssignment', value)}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                placeholder="Select"
                                                error={!!formErrors.leadAssignment}
                                            />
                                        )}
                                    />

                                    <FormHelperText className='important-fields'>{formErrors.leadAssignment}</FormHelperText>
                                </Grid>

                                <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                                    <Typography className='text-labels' color="initial">Cross Allocation</Typography>

                                    <Autocomplete multiple
                                        className='form-control-input'
                                        size="small"
                                        options={crossAllocations.filter((loc) => loc.id !== dealerInfo?.dealerLocCode && loc.id !== formValues.map?.id)}
                                        value={formValues.crossAllocation}
                                        disabled={formValues.leadAssignment !== 'Manual'}
                                        onChange={(_, value) => handleInputChange('crossAllocation', value)}
                                        isOptionEqualToValue={(option, value) => option.id === value.id}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                placeholder="Select"
                                            />
                                        )}
                                    />
                                </Grid>

                                <Grid size={{ lg: 4, md: 8, sm: 12, xs: 6 }}>
                                    <Typography className='text-labels' color="initial">Communication</Typography>

                                    <Stack spacing={2} className="">
                                        {['Email', 'SMS', 'WhatsApp'].map((label) => (
                                            <Box key={label} className="communication-box">
                                                <FormControlLabel
                                                    className="communication-label"
                                                    control={
                                                        <Checkbox
                                                            className="communication-checkbox"
                                                            value={label}
                                                            checked={formValues.communication?.includes(label)}
                                                            onChange={handleCheckboxChange}
                                                        />
                                                    }
                                                    label={label}
                                                />
                                            </Box>
                                        ))}
                                    </Stack>
                                </Grid>

                                <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                                    <Typography className='text-labels' color="initial">OTP Access</Typography>

                                    <Stack spacing={2} direction="row" width="100%" className="">
                                        <Box className="communication-box" width='100%'>
                                            <FormControlLabel
                                                className="communication-label"
                                                control={
                                                    <Checkbox
                                                        className="communication-checkbox"
                                                        value='Yes'
                                                        checked={formValues.otpFlag}
                                                        onChange={() => handleInputChange('otpFlag', !formValues.otpFlag)}
                                                    />
                                                }
                                                label="OTP"
                                            />
                                        </Box>
                                    </Stack>
                                </Grid>

                            </>}

                        {/* <Grid size={4} sx={{ visibility: formValues.map && formValues.map.id === '' ? 'visible' : 'hidden' }}>
                        <FormLabel>Map Location</FormLabel>
                        <TextField
                            className='form-control-input'
                            fullWidth
                            variant="filled"
                            value={formValues.dealerLocName}
                            onChange={(e) => handleInputChange('dealerLocName',
                                e.target.value.trimStart().replace(/[^a-zA-Z\s]/g, '').replace(/\s+/g, ' ').slice(0, 50))}
                            error={!!formErrors.dealerLocName}
                        />
                        <Typography color='error' mx={1.9} fontSize={'0.75rem'}>{formErrors.dealerLocName}</Typography>
                    </Grid> */}
                        <Grid size={12}>
                            {dealerAddress && <Typography className='text-labels' color="initial">Address</Typography>}

                            <Typography className='text-gray georama-semiBold fs-16 dark-black'>{dealerAddress}</Typography>

                            {/* <TextField fullWidth value={dealerAddress}
                                variant="filled"
                                inputProps={{ readOnly: true, sx: { pt: '10px' } }}
                                sx={{
                                    border: `0.3px solid rgb(186, 179, 179)`,
                                    borderRadius: 1,
                                    bgcolor: bgGray100,
                                    '& .MuiFilledInput-root': {
                                        border: 'none',
                                        outline: 'none',
                                        boxShadow: 'none',
                                    },
                                    '& .MuiFilledInput-root:before': {
                                        borderBottom: 'none',
                                    },
                                    '& .MuiFilledInput-root:after': {
                                        borderBottom: 'none',
                                    },
                                    '& .MuiFilledInput-root.Mui-focused': {
                                        outline: 'none',
                                        boxShadow: 'none',
                                        backgroundColor: bgGray100,
                                    }
                                }} /> */}
                        </Grid>
                    </Grid>
                </Box>
            </Box>

            {!!dealerInfo?.parentId && !!dealerInfo?.dealerId && createNew &&
                <>
                    <Box mt={2} mb={1}>
                        <Stack
                            direction="row"
                            sx={{ justifyContent: 'space-between', alignItems: 'center' }}
                        >
                            <Typography className='georama-Medium fs-18'>
                                Fields Mapping
                            </Typography>
                        </Stack>
                    </Box>

                    <Stack spacing={1.5}>
                        {accordionLabels.map((item, index) => (
                            <SetUpAccordion className='bg-white' key={item} label={item} accordion={accordion} setAccordion={setAccordion} data={accordionData[index]} dealerInfo={dealerInfo} dealerDetails={dealerDetails[`${accordionData[index]}DbColName`]} mappingSaved={mappingSaved}
                                setMappingSaved={setMappingSaved} formValues={formValues} handleInputChange={handleInputChange} customTemplates={customTemplates}
                                columnMapping={columnMapping} setColumnMapping={setColumnMapping} selectedTemplates={selectedTemplates} isEdit={false} />
                        ))}
                    </Stack></>}

            <Box display={'flex'} justifyContent={'end'}>
                <Button sx={{ ...btnRed, mt: 2, mr: 2, py: 1, px: 2 }} onClick={handleSubmit}>Submit </Button>
            </Box>

            <ToastContainer />
        </Paper>
    );
};

export default CreateDealer;