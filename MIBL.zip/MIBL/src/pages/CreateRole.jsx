import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import CloseIcon from '@mui/icons-material/Close';
import { Autocomplete, Box, Button, Checkbox, Divider, FormControlLabel, FormHelperText, Grid, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography, useMediaQuery } from "@mui/material";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import FormControl from '@mui/material/FormControl';
import IconButton from '@mui/material/IconButton';
import { styled } from '@mui/material/styles';
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import BackdropLoader from '../components/Loader/BackdropLoader';
import { getNewDealerForRoleMappings, getReportingRoleByDealer, getRoleFeatureView, submitFeatureAccess, updateFeatureAccess } from "../services/api";
import { decryptRoute, encryptRoute } from "../services/encrypt";

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

export default function CreateRole() {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    const { encrypted } = useParams();
    const navigate = useNavigate();
    const [dealerData, setDealerData] = useState([]);
    const [featuresData, setFeatures] = useState([]);
    const [checkboxesShow, setCheckboxesShow] = useState([]);
    const [reportRole, setReportRole] = useState([]);
    const userDetails = useSelector((state) => state.user.loggedData);
    const [permissionsTable, setPermissionsTable] = useState([]);
    const [accessData, setAccessData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [filterType, setFilterType] = useState([]);
    const [systemConfigData, setSystemConfigData] = useState([]);
    const [isOpen, setIsOpen] = useState(false);
    const [selectedFeatures, setSelectedFeatures] = useState([]);
    const [locationList, setlocationList] = useState([]);
    const [systemCheckedData, setSystemCheckedData] = useState([]);
    const featureAccess = useSelector((state) => state.user.featureAccess.filter(f => f.Url && f.Url.startsWith('/role')));

    const handleCheckboxChangeSystem = (feature) => {
        setSelectedFeatures((prev) =>
            prev.includes(feature)
                ? prev.filter((item) => item !== feature)
                : [...prev, feature]
        );
    };

    useEffect(() => {
        if (systemConfigData?.length) {
            const matchedIds = systemConfigData.filter((configItem) =>
                systemCheckedData.some((checkedItem) =>
                    checkedItem.feature_id === configItem.id &&
                    checkedItem.status === "1" &&
                    checkedItem.parent_feature_id === configItem.parent_feature_id
                )
            ).map((item) => item.id);
            setSelectedFeatures(matchedIds);
        }
    }, [systemConfigData, systemCheckedData]);

    const location = useLocation();
    const isEdit = location.state?.isEdit || false;
    const roleData = location.state?.roleData || null;

    const [formValues, setFormValues] = useState({
        roleType: '',
        dealer: '',
        rolename: '',
        role: '',
        parentCode: '',
        location: ''
    });

    const handleAddSystemConfig = () => {

    };

    const [formErrors, setFormErrors] = useState({
        dealer: '',
        rolename: '',
        role: '',
        roleType: '',
        location: ''
    });

    const getRoleFeature = async () => {
        const payload = {
            type: ""
        }
        try {
            const response = await getNewDealerForRoleMappings(payload)
            if (response) {
                setFilterType(response.result0);
                // Assume second API call gives userSelections
                const userSelectionsResponse = await getRoleFeatureView({ roleName: roleData.roleName, parentCode: roleData.parent_code });
                const userSelections = userSelectionsResponse?.result2 || [];
                setSystemCheckedData(userSelectionsResponse.result2);
                const allFeatures = response.result1.filter(f => userSelectionsResponse.result0.some(sf => sf.id === f.id));
                const allAccess = response.result2.filter(f => userSelectionsResponse.result1.some(sf => sf.id === f.id));
                const allowedMap = {};

                response.result3.forEach(entry => {
                    const accessIds = entry.access_id.split(',').map(id => parseInt(id));
                    allowedMap[entry.feature_id] = accessIds;
                });

                const tableData = buildPermissionsTable(
                    allFeatures,
                    allAccess,
                    allowedMap,
                    userSelections
                );

                setAccessData(allAccess);
                setFeatures(allFeatures);
                setPermissionsTable(tableData);
                setSystemConfigData(userSelectionsResponse.result3);
            }
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        if (isEdit) {
            getRoleFeature();
        }
    }, [isEdit])

    useEffect(() => {
        if (isEdit && roleData) {
            setFormValues({
                dealer: roleData.dealerName || '',
                rolename: roleData.roleName || '',
                role: roleData?.reportingRole ?? '',
                roleType: roleData?.role_type === 'MIBL' ? 1 : roleData?.role_type === 'DEALER' ? 2 : undefined,
                parentCode: roleData?.parent_code,
                location: roleData?.role_location,
            });
        }
    }, [isEdit, roleData]);

    const getReportingRole = async (dealer) => {
        try {
            const response = await getReportingRoleByDealer({
                dealerName: dealer,
                type: !isEdit ? filterType.find(rt => rt.id === formValues.roleType)?.role_type : roleData?.role_type,
                parentCode: formValues.parentCode,
                dealerCode: userDetails?.dealerCode ?? ''
            });
            if (response.status_code === "200" || response.status_message === "Fresh dealer-role mappings fetched successfully") {
                setReportRole(response?.result1 || []);
                setlocationList(response?.result0 || []);
                if (userDetails?.roleType === "DEALER") {
                    setFormValues((prev) => ({
                        ...prev,
                        ['location']: response?.result0?.[0].loc_name
                    }));
                }
            }
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        if (formValues?.dealer) {
            getReportingRole(formValues?.dealer)
        }
    }, [formValues?.dealer]);

    const handleChange = (field) => (e) => {
        setFormValues((prev) => ({
            ...prev,
            [field]: field === 'rolename' ?
                e.target.value.trimStart().replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, ' ').slice(0, 50) : e.target.value,
        }));

        setFormErrors((prev) => ({
            ...prev,
            [field]: '',
        }));
    };

    const initializePermissions = () => {
        return featuresData.map(feature => {
            const allowedAccessIds = checkboxesShow
                .find(item => item.feature_id === feature.id)?.access_id
                ?.split(',').map(id => parseInt(id)) || [];

            const permissions = accessData.reduce((acc, access) => {
                const isAllowed = allowedAccessIds.includes(access.id);
                acc[access.access_name] = access.access_name === "Yes" && isAllowed ? true : false;
                return acc;
            }, {});

            // Ensure "No" is false if both Yes and No exist
            if (permissions["Yes"] && "No" in permissions) {
                permissions["No"] = false;
            }

            return {
                ...feature,
                allowedAccessIds,
                permissions
            };
        });
    };

    useEffect(() => {
        if (isOpen) {
            setSelectedFeatures([])
        }
    }, [isOpen]);


    useEffect(() => {
        if (featuresData?.length && accessData.length && checkboxesShow.length) {
            const initialized = initializePermissions();
            setPermissionsTable(initialized);
        }
    }, [featuresData, accessData]);

    const buildPermissionsTable = (allFeatures, allAccess, allowedMap, userSelections) => {
        return allFeatures.map((feature) => {
            const allowedAccessIds = allowedMap[feature.id] || [];

            // Build permissions object
            const permissions = {};
            allAccess.forEach(access => {
                const matched = userSelections.find(
                    u =>
                        (u.parent_feature_id ? u.parent_feature_id : u.feature_id) === feature.id &&
                        u.access_id === access.id &&
                        u.status === "1"
                );
                permissions[access.access_name] = matched ? true : false;
            });

            return {
                id: feature.id,
                features: feature.features,
                allowedAccessIds,
                permissions,
            };
        });
    };

    const getData = async () => {
        const payload = {
            type: formValues?.roleType ? filterType.find(rt => rt.id === formValues.roleType)?.role_type : ''
        }
        try {
            setLoading(true);
            const response = await getNewDealerForRoleMappings(payload);
            if (response.StatusCode === "200" || response.status_message === "New dealer-role mappings fetched successfully") {
                let dealers;
                let features;
                let access;
                let accessMap;
                if (formValues?.roleType === 1) {
                    setReportRole(response.result0);
                }
                if (!formValues?.roleType) {
                    let allowedRoles = featureAccess.filter(f => f.Url === decryptRoute(decodeURIComponent(encrypted))).map(f => f.FeatureName.slice(0, -5));
                    setFilterType(response.result0.filter(rt => allowedRoles.some(ar => ar.toUpperCase() === rt.role_type)));
                    if (response.result0.filter(rt => allowedRoles.some(ar => ar.toUpperCase() === rt.role_type)).length === 1) {
                        setFormValues(prev => ({
                            ...prev,
                            roleType: response.result0.find(rt => allowedRoles.some(ar => ar.toUpperCase() === rt.role_type)).id
                        }));
                    }
                    features = response.result1;
                    access = response.result2;
                    accessMap = response.result3;
                }
                if (formValues?.roleType && filterType.find(rt => rt.id === formValues?.roleType)?.role_type === "DEALER") {
                    dealers = userDetails?.parentCode ? response.result0.filter(d => d.parent_code === userDetails?.parentCode)
                        : response.result0;
                    features = response.result1;
                    access = response.result2;
                    accessMap = response.result3;
                }
                if (formValues?.roleType && filterType.find(rt => rt.id === formValues?.roleType)?.role_type === "MIBL") {
                    features = response.result1;
                    access = response.result2;
                    accessMap = response.result3;
                }

                setDealerData(dealers);
                if (userDetails?.parentCode) setFormValues(prev => ({
                    ...prev,
                    dealer: dealers?.find(d => d.parent_code === userDetails?.parentCode)?.dealer_name,
                    parentCode: userDetails?.parentCode
                }));
                setFeatures(features);
                setAccessData(access);
                if (isEdit) {
                    setSystemConfigData(response.result4);
                } else {
                    setSystemConfigData(response.result4);
                }

                if (!isEdit) {
                    const initialized = features?.map(feature => {
                        const accessEntry = accessMap.find(entry => entry.feature_id === feature.id);
                        const allowedAccessIds = accessEntry ? accessEntry.access_id.split(',').map(Number) : [];

                        const permissions = {};
                        access.forEach(a => {
                            permissions[a.access_name] = false;
                        });

                        return {
                            id: feature.id,
                            features: feature.features,
                            allowedAccessIds,
                            permissions
                        };
                    });
                    setPermissionsTable(initialized);
                }
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (!isEdit) {
            setLoading(true);
            getData();
        }
    }, []);

    useEffect(() => {
        if (formValues.roleType && filterType.length > 0) {
            if (!isEdit) setFormValues(prev => ({
                ...prev, dealer: '', role: '', location: ''
            }));
            getData();
        }
    }, [formValues.roleType, filterType.length])

    const handleToggleAllCheckboxes = () => {
        const areAllChecked = permissionsTable.every(row => {
            const allowedAccessNames = accessData
                .filter(a => row.allowedAccessIds.includes(a.id))
                .map(a => a.access_name);

            return allowedAccessNames.filter(name => name !== 'No').every(name => row.permissions[name]);
        });

        setPermissionsTable(prev => {
            return prev.map(row => {
                const allowedAccessNames = accessData
                    .filter(a => row.allowedAccessIds.includes(a.id) || areAllChecked)
                    .map(a => a.access_name);

                const newPermissions = { ...row.permissions };

                allowedAccessNames.forEach(name => {
                    if (name === "Yes") {
                        newPermissions["Yes"] = !areAllChecked;
                        newPermissions["No"] = false;
                    } else if (name === "No") {
                        if (!newPermissions["Yes"]) {
                            newPermissions["No"] = !areAllChecked;
                        }
                    } else {
                        newPermissions[name] = !areAllChecked;
                    }
                });

                return {
                    ...row,
                    permissions: newPermissions
                };
            });
        });
        // const areAllChecked = permissionsTable.every(row =>
        //     Object.keys(row.permissions).filter(p => p !== 'No').every(a => row.permissions[a] === true)
        // );

        // const updatedTable = permissionsTable.map(row => ({
        //     ...row,
        //     permissions: Object.fromEntries(
        //         Object.keys(row.permissions).map(key => [key, areAllChecked ? !areAllChecked : key !== 'No'])
        //     )
        // }));
        // setPermissionsTable(updatedTable);
    };

    const handleCheckboxChange = (rowIndex, accessName, row) => {
        if (systemConfigData) {
            if (row.id === systemConfigData[0]?.parent_feature_id && !isEdit) {
                if (row.permissions[accessName] !== true) setIsOpen(true);
            }
            if (isEdit && row.id === systemConfigData[0].parent_feature_id) setIsOpen(true);
        }
        setPermissionsTable((prev) => {
            const updated = [...prev];
            const row = updated[rowIndex];
            const newPermissions = { ...row.permissions };

            const toggledValue = !newPermissions[accessName];
            newPermissions[accessName] = toggledValue;

            // Radio-like logic between Yes/No
            if (accessName === "Yes" && toggledValue) {
                newPermissions["No"] = false;
            } else if (accessName === "No" && toggledValue) {
                newPermissions["Yes"] = false;
            }

            // Auto-checking logic
            if (accessName === "Edit" && toggledValue) newPermissions["View"] = true;
            if (accessName === "Download") newPermissions["View"] = toggledValue;
            if (accessName === "View") newPermissions["Download"] = toggledValue;
            if (accessName === "Create" && toggledValue) newPermissions["View"] = true;
            if (accessName === "View" && !toggledValue) newPermissions["View"] = newPermissions["Edit"] || newPermissions["Create"];

            updated[rowIndex] = {
                ...row,
                permissions: newPermissions
            };

            return updated;
        });
    };

    const handleFeatureToggleAll = (rowIndex, row) => {
        if (systemConfigData) {
            if (row.id === systemConfigData[0].parent_feature_id) {
                if (row.permissions.Edit !== true) {
                    setIsOpen(true);
                }
            }
        }
        setPermissionsTable(prev => {
            const updated = [...prev];
            const row = updated[rowIndex];

            const allowedAccessNames = accessData
                .filter(a => row.allowedAccessIds.includes(a.id))
                .map(a => a.access_name);

            const newPermissions = { ...row.permissions };

            const allSelected = allowedAccessNames.length === 2 && allowedAccessNames.every(name => name === 'Yes' || name === 'No')
                ? allowedAccessNames.some(name => row.permissions[name]) : allowedAccessNames.every(name => row.permissions[name]);

            allowedAccessNames.forEach(name => {
                // Apply toggle logic with Yes/No handling
                if (name === "Yes") {
                    newPermissions["Yes"] = !allSelected;
                    newPermissions["No"] = false;
                } else if (name === "No") {
                    if (!newPermissions["Yes"]) newPermissions["No"] = !allSelected;
                } else {
                    newPermissions[name] = !allSelected;
                }
            });

            updated[rowIndex] = {
                ...row,
                permissions: newPermissions
            };

            return updated;
        });
    };

    const buildFinalPayload = () => {
        const mappings = [];

        permissionsTable.forEach(row => {
            const featureId = row.id;

            Object.entries(row.permissions).forEach(([accessName, isChecked]) => {
                if (isChecked) {
                    // if (featureId === 4) {
                    // For featureId === 4, loop over selectedFeatures for featureId
                    const accessObj = accessData.find(a => a.access_name === accessName);
                    if (featureId === 4 && accessObj) {
                        selectedFeatures.forEach(sfId => {
                            mappings.push({
                                featureId: sfId,        // from selectedFeatures
                                accessId: accessObj.id  // from permissions
                            });
                        });
                    } else {
                        const accessObj = accessData.find(a => a.access_name === accessName);
                        if (accessObj) {
                            mappings.push({
                                featureId,
                                accessId: accessObj.id
                            });
                        }
                    }
                    // }
                }
            });
        });

        let payload;
        if (!isEdit) {
            payload = {
                userId: userDetails.user_id,
                roleName: formValues.rolename,
                parentCode: formValues.dealer,
                reportingRole: formValues.role,
                roleTypeId: formValues.roleType,
                location: formValues.location,
                type: formValues.roleType ? filterType.find(rt => rt.id === formValues.roleType).role_type : '',
                featureAccessMappings: mappings
            };

        } else if (isEdit) {
            payload = {
                userId: userDetails.user_id,
                roleName: formValues.rolename,
                parentCode: formValues.parentCode,
                location: formValues.location,
                featureAccessMappings: mappings,
                reportingRoleName: formValues?.role,
                roleId: roleData?.role_id,
            };
        }
        return payload;
    };

    const handleSubmit = async () => {
        if (isEdit) {
            const errors = {};
            const payload = buildFinalPayload();
            if (!/^[A-Za-z]{2}[A-Za-z0-9 ]*$/.test(formValues.rolename?.trim())) errors.rolename = "Role Name must be atleast 2 characters long";
            if (!formValues.rolename.trim()) errors.rolename = "Role Name is required";
            if (userDetails?.roleType === 'DEALER') {
                if (!formValues.role) {
                    errors.role = "Report Role is required";
                }
            }

            setFormErrors(errors);

            if (payload.featureAccessMappings.length < 1) {
                toast.warning("Select atleast one Feature or access")
                return;
            }

            if (Object.keys(errors).length > 0) {
                return;
            }

            try {
                setLoading(true);
                const response = await updateFeatureAccess(payload);
                if (response.StatusCode === "200" || response.Message === "Role feature and access updated successfully.") {
                    setTimeout(() => {
                        navigate(`/${encodeURIComponent(encryptRoute('/role'))}`);
                    }, 2500);
                    toast.success("Role edited successfully");
                } else if (response.StatusCode === "300" && response.Message === "Role Already Present.") {
                    toast.error(response.Message);
                } else {
                    toast.error(response.Message);
                }
            } catch (error) {
                toast.error("Something went wrong");
                throw error;
            } finally {
                setLoading(false);
            }
        } else {
            const errors = {};
            if (!/^[A-Za-z]{2}[A-Za-z0-9 ]*$/.test(formValues.rolename?.trim())) errors.rolename = "Role Name must be atleast 2 characters long";
            if (!formValues.rolename.trim()) errors.rolename = "Role Name is required";
            if (!formValues.roleType) {
                errors.roleType = "Role Source is required";
            }
            if (formValues.roleType == 2) {
                if (!formValues.dealer) {
                    errors.dealer = "Dealer Name is required";
                }
                if (!formValues.location) {
                    errors.location = "Location is required";
                }
                if (!formValues.role && userDetails?.roleType === 'DEALER') {
                    errors.role = "Report Role is required";
                }
            }

            setFormErrors(errors);

            const payload = buildFinalPayload();
            if (payload.featureAccessMappings.length < 1) {
                toast.warning("Select atleast one Feature or access");
                return;
            }

            if (Object.keys(errors).length > 0) {
                return;
            }

            try {
                setLoading(true);
                const response = await submitFeatureAccess(payload);
                if (response.StatusCode == "200" || response.Message == "Feature access mappings inserted successfully.") {
                    setTimeout(() => {
                        navigate(`/${encodeURIComponent(encryptRoute('/role'))}`);
                    }, 2500);
                    toast.success("Role created successfully");
                    // setFormValues({
                    //     dealer: '',
                    //     rolename: ''
                    // });
                    setPermissionsTable([]);
                } else if (response.StatusCode === "300" && response.Message === "Role Already Present.") {
                    toast.error(response.Message);
                } else {
                    toast.error(response.Message);
                }
            } catch (error) {
                toast.error("Something went wrong");
                throw error;
            } finally {
                setLoading(false);
            }
        }

    };

    const checkboxStyles = {
        "&.Mui-checked": { color: "#e53935" },
        "&.MuiCheckbox-indeterminate": { color: "#e53935" },
    };

    return (
        <>
            <BackdropLoader loading={loading} />
            <Paper className="table-auto-width" elevation={0} sx={{ borderRadius: 3, m: isMobile ? 1.5 : 3, width: 'inherit' }}>
                <Box sx={{ borderRadius: 2 }}>
                    <Box display="flex" justifyContent="space-between" alignItems="center" px={isMobile ? 1.5 : 3} my={2}>
                        <Typography className={`georama-SemiBold ${isMobile ? 'fs-16' : 'fs-20'}`}>
                            {isEdit ? "Edit Role & Permissions" : "Create Role & Permissions"}
                        </Typography>
                        <Button
                            className='text-capitalize georama-medium-selected custom-starticon'
                            startIcon={<ChevronLeftIcon />}
                            onClick={() => navigate(-1)}>
                            Back
                        </Button>
                    </Box>
                    <Divider sx={{ mb: 2 }} />


                    <Grid container spacing={2} px={3} mb={3}>
                        {isEdit ? (
                            <>
                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Role Name <span className="important-fields">*</span>
                                    </Typography>
                                    <TextField
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        placeholder="Enter Role Name"
                                        value={formValues.rolename}
                                        onChange={handleChange("rolename")}
                                        error={!!formErrors.rolename}
                                    />
                                    <FormHelperText className="important-fields">{formErrors.rolename}</FormHelperText>
                                </Grid>
                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Role Source <span className="important-fields">*</span>
                                    </Typography>
                                    <FormControl
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth required error={!!formErrors.roleType}>
                                        <Select
                                            value={formValues.roleType}
                                            onChange={handleChange("roleType")}
                                            displayEmpty
                                            disabled={userDetails?.roleType === "DEALER" || isEdit}
                                        >
                                            <MenuItem value="" selected disabled>Select</MenuItem>
                                            {filterType && filterType?.map((dat, index) => (
                                                <MenuItem key={index} value={dat.id}>
                                                    {dat.role_type}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                    <FormHelperText className="important-fields">{formErrors.roleType}</FormHelperText>
                                </Grid>
                                {formValues.roleType === 2 && <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Dealer Name <span className="important-fields">*</span>
                                    </Typography>
                                    <TextField
                                        className='form-control-input border-radius-8 cursor-nodrop'
                                        size="small"
                                        fullWidth
                                        value={formValues.dealer}
                                        disabled
                                    />
                                </Grid>}
                                {formValues.roleType === 2 && <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Location <span className="important-fields">*</span>
                                    </Typography>
                                    <TextField
                                        className='form-control-input border-radius-8 cursor-nodrop'
                                        size="small"
                                        fullWidth
                                        value={formValues.location}
                                        disabled
                                    />
                                </Grid>}
                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' fontWeight={500} mb={0.5}>
                                        Report Role {userDetails?.roleType === 'DEALER' && <span className="important-fields">*</span>}
                                    </Typography>
                                    <FormControl
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth required error={!!formErrors.role}>
                                        <Select
                                            value={formValues.role}
                                            onChange={handleChange("role")}
                                            displayEmpty
                                        >
                                            <MenuItem value="" selected disabled>Select</MenuItem>
                                            {reportRole && reportRole?.filter(r => r.role_id !== roleData?.role_id).map((data, index) => (
                                                <MenuItem key={index} value={data?.role}>
                                                    {data?.role}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                    <FormHelperText className="important-fields">{formErrors.role}</FormHelperText>
                                </Grid>
                            </>
                        ) : (
                            <>
                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Role Name <span className="important-fields">*</span>
                                    </Typography>
                                    <TextField
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        placeholder="Enter Role Name"
                                        value={formValues.rolename}
                                        onChange={handleChange("rolename")}
                                        error={!!formErrors.rolename}
                                    // disabled={isEdit}
                                    />
                                    <FormHelperText className="important-fields">{formErrors.rolename}</FormHelperText>
                                </Grid>
                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Role Source <span className="important-fields">*</span>
                                    </Typography>
                                    <FormControl
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth required error={!!formErrors.roleType}>
                                        <Select
                                            value={formValues.roleType}
                                            onChange={handleChange("roleType")}
                                            displayEmpty
                                            disabled={userDetails?.roleType === "DEALER" || isEdit}
                                        >
                                            <MenuItem value="" selected disabled>Select</MenuItem>
                                            {filterType && filterType?.map((dat, index) => (
                                                <MenuItem key={index} value={dat.id}>
                                                    {dat.role_type}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                    <FormHelperText className="important-fields">{formErrors.roleType}</FormHelperText>
                                </Grid>

                                {formValues.roleType && filterType.find(rt => rt.id === formValues.roleType).role_type === "DEALER" &&
                                    <>
                                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                            <Typography className='text-labels' mb={0.5}>
                                                Dealer Name <span className="important-fields">*</span>
                                            </Typography>
                                            <FormControl
                                                className='form-control-input border-radius-8'
                                                size="small"
                                                fullWidth required error={!!formErrors.dealer}>
                                                <Autocomplete size="small"
                                                    options={dealerData?.filter(d => !!d.dealer_name) || []}
                                                    getOptionLabel={(option) => option?.dealer_name || ""}
                                                    value={dealerData?.find(d => d.dealer_name === formValues.dealer) || null}
                                                    onChange={(event, value) => {
                                                        if (value) {
                                                            setFormValues((prev) => ({
                                                                ...prev,
                                                                dealer: value.dealer_name,
                                                                parentCode: value.parent_code
                                                            }));
                                                            setFormErrors((prev) => ({
                                                                ...prev,
                                                                dealer: '',
                                                                type: ''
                                                            }));
                                                        }
                                                    }}
                                                    renderInput={(params) => (
                                                        <TextField
                                                            {...params}
                                                            placeholder="Select Dealer Name"
                                                            error={!!formErrors.dealer}
                                                        />
                                                    )}
                                                    disabled={userDetails?.roleType === "DEALER" || isEdit}
                                                    disableClearable
                                                    isOptionEqualToValue={(option, value) => option.dealer_name === value.dealer_name}
                                                />
                                            </FormControl>
                                            <FormHelperText className="important-fields">{formErrors.dealer}</FormHelperText>
                                        </Grid>
                                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                            <Typography className='text-labels' mb={0.5}>
                                                Location <span className="important-fields">*</span>
                                            </Typography>
                                            <FormControl
                                                className='form-control-input border-radius-8'
                                                size="small"
                                                fullWidth required error={!!formErrors.location}>
                                                <Select
                                                    value={formValues.location}
                                                    onChange={handleChange("location")}
                                                    displayEmpty
                                                    disabled={userDetails?.roleType === "DEALER" || isEdit}
                                                >
                                                    <MenuItem value="" disabled>
                                                        Select Location
                                                    </MenuItem>
                                                    {locationList && locationList.map((loc, index) => (
                                                        <MenuItem key={index} value={loc.loc_name}>
                                                            {loc.loc_name}
                                                        </MenuItem>
                                                    ))}
                                                </Select>
                                            </FormControl>
                                            <FormHelperText className="important-fields">{formErrors.location}</FormHelperText>
                                        </Grid>
                                    </>
                                }

                                {formValues.roleType && <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' fontWeight={500} mb={0.5}>
                                        Report Role {userDetails?.roleType === 'DEALER' && <span className="important-fields">*</span>}
                                    </Typography>
                                    <FormControl
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth required error={!!formErrors.role}>
                                        <Select
                                            value={formValues.role}
                                            onChange={handleChange("role")}
                                            displayEmpty
                                            disabled={isEdit}
                                        >
                                            <MenuItem value="" selected disabled>Select</MenuItem>
                                            {reportRole && reportRole?.map((data, index) => (
                                                <MenuItem key={index} value={data?.role}>
                                                    {data?.role}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                    <FormHelperText className="important-fields">{formErrors.role}</FormHelperText>
                                </Grid>}
                            </>
                        )}
                    </Grid>
                    {(formValues.roleType || isEdit) && <>
                        <Box px={2}>
                            <Box >
                                <Typography >Access Permissions</Typography>
                            </Box>
                            <TableContainer component={Box} sx={{ mt: 0 }}>
                                <Table sx={{ tableLayout: 'auto', width: '100%' }}>
                                    <TableHead className="body-formbg role-table-head">
                                        <TableRow>
                                            <TableCell >
                                                <Checkbox
                                                    sx={checkboxStyles}
                                                    checked={permissionsTable?.every(row =>
                                                        Object.values(row.permissions).every(Boolean)
                                                    )}
                                                    indeterminate={
                                                        permissionsTable?.some(row =>
                                                            Object.values(row.permissions).some(Boolean)
                                                        ) &&
                                                        !permissionsTable?.every(row =>
                                                            Object.values(row.permissions).every(Boolean)
                                                        )
                                                    }
                                                    onChange={handleToggleAllCheckboxes}
                                                />
                                                Features
                                            </TableCell>
                                            {accessData?.map((access, index) => (
                                                <TableCell sx={{ textAlign: 'center' }} key={access.id} >
                                                    {access.access_name}
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    </TableHead>
                                    <TableBody className="role-table-body">
                                        {permissionsTable?.map((row, rowIndex) => {
                                            const allowedAccessNames = accessData
                                                .filter(access => row?.allowedAccessIds?.includes(access.id))
                                                .map(access => access.access_name);

                                            const checkedCount = allowedAccessNames.filter(name => row.permissions[name]).length;
                                            const isAllChecked = checkedCount === allowedAccessNames.length;
                                            const isIndeterminate = checkedCount > 0 && !isAllChecked;

                                            return (
                                                <TableRow key={row.id}>
                                                    <TableCell >
                                                        <Checkbox
                                                            sx={checkboxStyles}
                                                            checked={isAllChecked}
                                                            indeterminate={isIndeterminate}
                                                            onChange={() => handleFeatureToggleAll(rowIndex, row)}
                                                        />
                                                        {row.features}
                                                    </TableCell>

                                                    {accessData && accessData?.map((access) => {
                                                        const isYes = access.access_name === "Yes";
                                                        const isNo = access.access_name === "No";
                                                        const isYesChecked = row.permissions["Yes"];
                                                        const isNoChecked = row.permissions["No"];

                                                        const shouldBeChecked =
                                                            isYes ? isYesChecked :
                                                                isNo ? isNoChecked :
                                                                    row.permissions[access.access_name];

                                                        const styleOverride =
                                                            (isYes && isNoChecked) || (isNo && isYesChecked)
                                                                ? {
                                                                    // "& .MuiSvgIcon-root": {
                                                                    //     backgroundColor: "#ede8e8",
                                                                    //     borderRadius: "4px"
                                                                    // }
                                                                }
                                                                : {};

                                                        return (
                                                            <TableCell sx={{ textAlign: 'center' }} key={access.id} >
                                                                {row.allowedAccessIds.includes(access.id) && (
                                                                    <Checkbox
                                                                        sx={{ ...checkboxStyles, ...styleOverride }}
                                                                        checked={shouldBeChecked}
                                                                        onChange={() =>
                                                                            handleCheckboxChange(rowIndex, access.access_name, row)
                                                                        }
                                                                    />
                                                                )}
                                                            </TableCell>
                                                        );
                                                    })}
                                                </TableRow>
                                            );
                                        })}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Box>

                        <Box display="flex" mx={5} my={2} justifyContent="flex-end">
                            <Button className="btn-common-red" onClick={handleSubmit} disabled={loading}>
                                Submit
                            </Button>
                        </Box>
                    </>}
                </Box>
            </Paper >

            <BootstrapDialog
                fullWidth
                maxWidth="xs"
                onClose={() => setIsOpen(false)}
                aria-labelledby="customized-dialog-title"
                open={isOpen}
            >
                <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
                    System Configuration
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={() => setIsOpen(false)}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent>
                    <Grid container spacing={3}>
                        {systemConfigData && systemConfigData.map((item) => (
                            <Grid item xs={12} key={item.id}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            sx={{ ...checkboxStyles }}
                                            checked={selectedFeatures.includes(item.id)}
                                            onChange={() => handleCheckboxChangeSystem(item.id)}
                                        />
                                    }
                                    label={item.features}
                                />
                            </Grid>
                        ))}
                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Button fullWidth autoFocus onClick={() => setIsOpen(false)} className="btn-assign assign-txt">
                        Close
                    </Button>

                    <Button
                        className="btn-common-red"
                        disabled={!selectedFeatures.length}
                        fullWidth onClick={() => {
                            handleAddSystemConfig()
                            setIsOpen(false)
                        }}>Add
                    </Button>
                </DialogActions>
            </BootstrapDialog>

            <ToastContainer autoClose={1000} />
        </>
    );
}