import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { Autocomplete, Box, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, Divider, FormControlLabel, FormHelperText, Grid, ListItemText, MenuItem, Paper, Radio, RadioGroup, Select, Switch, TextField, Typography, useMediaQuery } from "@mui/material";
import FormControl from '@mui/material/FormControl';
import { styled } from '@mui/material/styles';
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import BackdropLoader from '../components/Loader/BackdropLoader';
import LockUserModal from "../modals/LockUserModal";
import { addNewUser, fetchUserCreationValues, getUserDetailsById, updateUserById } from "../services/api";
import { decryptRoute, encryptRoute } from "../services/encrypt";

const IOSSwitch = styled((props) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
    width: 55,
    height: 26,
    padding: 0,
    '& .MuiSwitch-switchBase': {
        padding: 0,
        margin: 2,
        transitionDuration: '300ms',
        '&.Mui-checked': {
            transform: 'translateX(27px)',
            color: '#fff',
            '& + .MuiSwitch-track': {
                backgroundColor: '#65C466',
                opacity: 1,
                border: 0,
                ...theme.applyStyles('dark', {
                    backgroundColor: '#2ECA45',
                }),
            },
            '&.Mui-disabled + .MuiSwitch-track': {
                opacity: 0.5,
            },
        },
        '&.Mui-focusVisible .MuiSwitch-thumb': {
            color: '#33cf4d',
            border: '6px solid #fff',
        },
        '&.Mui-disabled .MuiSwitch-thumb': {
            color: theme.palette.grey[100],
            ...theme.applyStyles('dark', {
                color: theme.palette.grey[600],
            }),
        },
        '&.Mui-disabled + .MuiSwitch-track': {
            opacity: 0.7,
            ...theme.applyStyles('dark', {
                opacity: 0.3,
            }),
        },
    },
    '& .MuiSwitch-thumb': {
        boxSizing: 'border-box',
        width: 22,
        height: 22,
    },
    '& .MuiSwitch-track': {
        borderRadius: 26 / 2,
        backgroundColor: '#E9E9EA',
        opacity: 1,
        transition: theme.transitions.create(['background-color'], {
            duration: 500,
        }),
        ...theme.applyStyles('dark', {
            backgroundColor: '#39393D',
        }),
    },
}));

export default function CreateUser() {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    const { encrypted } = useParams();
    const navigate = useNavigate();
    const userData = useSelector((state) => state.user.loggedData);
    const [dealers, setDealers] = useState();
    const [dealersName, setDealersName] = useState();
    const [locations, setLocations] = useState();
    const [roles, setRoles] = useState();
    const [managers, setManagers] = useState();
    const [fieldsDisabled, setFieldsDisabled] = useState(true);
    const [loading, setLoading] = useState(false);
    const [isFormValid, setIsFormValid] = useState(false);
    const [leadPoolOptions, setLeadPoolOptions] = useState([]);
    const [editValues, setEditValues] = useState([]);
    const location = useLocation();
    const isEditMode = location.state?.edit || false;
    const existingUser = location.state?.user || {};
    const [formErrors, setFormErrors] = useState({});
    const [lockopen, setlockOpen] = useState(false);
    const featureAccess = useSelector((state) => state.user.featureAccess.filter(f => f.Url && f.Url.startsWith('/userManagement')));
    const [openModal, setOpenModal] = useState(false);
    const [modalMessage, setModalMessage] = useState("");

    const lockonClose = (data) => {
        if (data) {
            setFormValues((prev) => ({
                ...prev,
                ['status']: data,
            }));
        }
        setlockOpen(false);
    }

    const [formValues, setFormValues] = useState({
        reportingManagerId: "",
        roleType: "",
        firstName: "",
        lastName: "",
        contactInfo: "",
        email: "",
        status: "",
        dealer: "",
        location: "",
        role: "",
        manager: "",
        adFlag: "",
        callingFlag: "",
        viewLeads: false,
        leadsFlag: "",
        leadPool: [""],
        teamEmail: "",
        sapCode: "",
    });

    useEffect(() => {
        if (isEditMode && editValues) {
            setFormValues({
                firstName: editValues.first_name || "",
                lastName: editValues.last_name || "",
                contactInfo: editValues.mobile_no || "",
                email: editValues.email_id || "",
                status: editValues.status === "1" ? "1" : "0",
                dealer: editValues.dealer_name || "",
                location: formValues?.location || editValues.address || "",
                role: editValues.role || "",
                roleType: editValues.role_type,
                manager: editValues.reportingManager || "",
                adFlag: editValues.adFlag === "Y" ? "yes" : editValues.adFlag === "N" ? "no" : "no",
                callingFlag: editValues.calling_flag === "Y" ? "yes" : editValues.calling_flag === "N" ? "no" : "",
                isGroup: editValues.isGroup || "",
                viewLeads: editValues.calling_flag === "N",
                leadPool: editValues?.bucket_name ? editValues?.bucket_name : [""],
                leadsFlag: editValues.lead_flag || "",
                teamEmail: editValues.team_email_flag || "",
                sapCode: editValues.sapCode || ""
            });
        }
    }, [editValues, isEditMode, roles]);
    // roles, leadPoolOptions, formValues.callingFlag


    const [dropdownDisabled, setDropdownDisabled] = useState({
        location: true,
        role: true,
        manager: true,
    });

    const getUserDetailsEdit = async (id) => {
        try {
            setLoading(true);
            const response = await getUserDetailsById(id, existingUser?.parentCode);
            if (response.status_code === "200" || response.status_message === "User Details By ID") {
                let res = response.result0[0];
                if (res?.bucket_name) {
                    res["bucket_name"] = response.result0.filter(user => user?.bucket_name).map(user => user?.bucket_name);
                }
                setEditValues(res);
            }
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        if (isEditMode && existingUser) {
            getUserDetailsEdit(existingUser.id);
        }
    }, [isEditMode, existingUser]);

    const validateForm = () => {
        const errors = {};
        if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(formValues.email)) {
            errors.email = "Invalid Email";
        }

        if (!formValues.contactInfo.trim()) {
            errors.contactInfo = "Mobile No is required";
        } else if (formValues.contactInfo.length !== 10) {
            errors.contactInfo = "Mobile No must be 10 digits";
        } else if (!/^[6-9]\d{9}$/.test(formValues.contactInfo)) {
            errors.contactInfo = "Enter a valid 10-digit mobile number";
        }
        if (!/^\d{10}$/.test(formValues.contactInfo)) errors.contactInfo = "Invalid Mobile No";
        if (!formValues.contactInfo.trim()) errors.contactInfo = "Mobile No is required";
        if (userData?.roleType === "DEALER" && !formValues.manager) errors.manager = "Reporting Manager is required"

        if (!formValues.firstName.trim().length > 2) errors.firstName = "First Name must be atleast 2 characters long";
        if (!formValues.lastName.trim().length > 3) errors.lastName = "Last Name must be atleast 3 characters long";
        if (!formValues.firstName.trim()) errors.firstName = "First Name is required";
        if (!formValues.lastName.trim()) errors.lastName = "Last Name is required";
        if (!formValues.email.trim()) errors.email = "Email is required";
        if (!formValues.status) errors.status = "Status is required";
        if (!formValues.role) errors.role = "Role Assignment is required";
        if (!formValues.roleType) errors.roleType = "Role Source is required";
        if (!formValues.isGroup) errors.isGroup = "Group Email is required";
        if (formValues.roleType !== "DEALER") {
            if (!formValues.adFlag) errors.adFlag = "AD flag is required";
        }
        if (formValues.roleType === "MIBL") {
            if (!formValues.sapCode) {
                errors.sapCode = "SAP Code is required";
            } else if (!/^\d{8}$/.test(formValues.sapCode)) {
                errors.sapCode = "SAP Code must be exactly 8 digits";
            } else if (/^(\d)\1{7}$/.test(formValues.sapCode)) {
                errors.sapCode = "Invalid SAP Code (cannot be all same digits)";
            }
        }
        if (formValues.roleType === "DEALER") {
            if (!formValues.dealer) errors.dealer = "Dealer is required";
            if (!formValues.location) errors.location = "Location is required";
            if (!formValues.callingFlag) errors.callingFlag = "Calling flag is required";
            if (formValues.callingFlag === "yes" && !formValues.leadPool) {
                // errors.leadPool = "Lead Pool is required";
            }
            if (formValues.callingFlag === "yes" && !formValues.leadPool) {
                // errors.leadPool = "Lead Pool is required";
            }
            if (formValues.callingFlag === "no" && formValues.viewLeads && !formValues.leadsFlag) {
                errors.leadsFlag = "Leads Flag is required";
            };
        }
        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    }

    const handleSubmit = async () => {
        if (isEditMode && existingUser) {
            const isValid = validateForm();
            setIsFormValid(isValid);

            if (!isValid) return;

            const data = {
                "createduserId": userData.user_id,
                "userId": existingUser.id,
                "firstname": formValues.firstName,
                "lastname": formValues.lastName,
                "contactinfo": formValues.contactInfo,
                "emailid": formValues.email,
                "status": formValues.status,
                "parentCode": existingUser.parentCode || "",
                "dealerCode": formValues.dealer || "",
                "roleType": formValues.roleType,
                "location": editValues.address || "",
                "roleID": userData.roleId,
                "roleName": formValues.role,
                "adFlag": formValues.adFlag === "yes" ? "Y" : formValues.adFlag === "no" ? "N" : "",
                "callingFlag": formValues.callingFlag === "yes" ? "Y" : formValues.callingFlag === "no" ? "N" : '',
                "leadPool": formValues.callingFlag === "yes" ? formValues.leadPool : "",
                "leadsFlag": formValues.callingFlag !== "yes" && formValues.viewLeads ? formValues.leadsFlag : "",
                "role": formValues.role || editValues.role || "",
                "teamEmail": formValues.teamEmail || "",
                "sapCode": formValues.sapCode,
                "isGroup": formValues.isGroup,
                // "manager": formValues.manager || "",
                "manager": formValues.manager || "",
                "reportingManagerId": formValues.reportingManagerId
            }
            try {
                setLoading(true);
                const response = await updateUserById(existingUser.id, data);
                if (response.status_code === "200" || response.status_message === "User details updated successfully.") {
                    toast.success("User Updated Successfully");
                    setTimeout(() => {
                        navigate(`/${encodeURIComponent(encryptRoute('/userManagement'))}`);
                    }, 1500);
                    // setFormValues({
                    //     firstName: "",
                    //     lastName: "",
                    //     contactInfo: "",
                    //     email: "",
                    //     status: 0,
                    //     dealer: "",
                    //     location: "",
                    //     role: "",
                    //     manager: "",
                    //     callingFlag: "",
                    //     viewLeads: false,
                    //     leadsFlag: "",
                    //     leadPool: "",
                    // })
                } else if (response.status_code === "304" || response.status_code === "404" || response.status_code === "400" || response.status_message === "No fields were updated.") {
                    toast.error("No fields were updated. Please check the form.");
                }
                else if (response.status_code === "300" && response.status_message === "Mobile Number Already Exists") {
                    toast.error("Mobile Number Already Exists");
                } else toast.error("Something Went Wrong!")
            } catch (error) {
                console.log(error);
                toast.error("Something went wrong.");
            } finally {
                setLoading(false);
            }
        } else {
            const isValid = validateForm();
            setIsFormValid(isValid);

            if (!isValid) return;

            const data = {
                "userId": userData.user_id,
                "firstname": formValues.firstName.trim(),
                "lastname": formValues.lastName.trim(),
                "contactinfo": formValues.contactInfo.trim(),
                "emailid": formValues.email.trim(),
                "status": formValues.status,
                "location": formValues.location,
                "roleID": userData.roleId,
                "roleName": formValues.role,
                "manager": formValues.manager || "",
                "roleType": formValues.roleType,
                "dealerCode": formValues.roleType === "MIBL" ? "" : formValues.dealer,
                "adFlag": formValues.adFlag === "yes" ? "Y" : "N",
                "callingFlag": formValues.roleType === "MIBL" ? "" : formValues.callingFlag === "yes" ? "Y" : "N",
                "leadPool": formValues.roleType === "MIBL" ? "" : formValues.callingFlag === "yes" ? formValues.leadPool : "",
                "leadsFlag": formValues.roleType === "MIBL" ? "" : formValues.callingFlag !== "yes" && formValues.viewLeads ? formValues.leadsFlag : "",
                "teamEmail": formValues.teamEmail || "",
                "sapCode": formValues.sapCode,
                "isGroup": formValues.isGroup,
                "reportingManagerId": formValues.reportingManagerId
            }
            try {
                setLoading(true);
                const response = await addNewUser(data);
                if (response.status_code === "200" || response.status_message === "Data inserted successfully.") {
                    if (formValues.roleType === "MIBL") {
                        setModalMessage("User Created Successfully.");
                    }
                    else {
                        setModalMessage("User Created Successfully. Credentials for accessing the CRM has been sent to registered Mobile Number.");
                    }
                    setOpenModal(true);
                    // toast.success(response.status_message);
                    setFormValues({
                        firstName: "",
                        lastName: "",
                        contactInfo: "",
                        email: "",
                        status: "",
                        dealer: "",
                        location: "",
                        role: "",
                        manager: "",
                        adFlag: "",
                        callingFlag: "",
                        viewLeads: false,
                        leadsFlag: "",
                        leadPool: "",
                        teamEmail: "",
                    });
                    // setTimeout(() => {
                    //     navigate(`/${encodeURIComponent(encryptRoute('/userManagement'))}`);
                    // }, 1500);
                } else if (response.status_code === "300" && response.status_message === "Operation completed with warnings.") {
                    toast.error("Fields are missing, please check the form.");
                } else if (response.status_code === "300" && response.status_message === "Email ID Already Exists") {
                    toast.error("Email already exists. Please use a different email.");
                } else if (response.status_code === "300" && response.status_message === "Mobile Number Already Exists") {
                    toast.error("Mobile Number Already Exists");
                } else if (response.status_code === "300" && response.status_message === "SAP Code Already Exists") {
                    toast.error("SAP Code Already Exists");
                } else toast.error("Something Went Wrong!")
            } catch (error) {
                console.log(error);
                toast.error("Something went wrong.");
            } finally {
                setLoading(false);
            }
        }
    }

    useEffect(() => {
        fetchValues("dealer");
    }, []);

    useEffect(() => {
        if (formValues.roleType && isEditMode) {
            fetchValues("dealerName");
        } else if (formValues.roleType) {
            fetchValues("dealerName");
            setFormValues(prev => ({
                ...prev,
                dealer: "",
                location: "",
                role: "",
                manager: "",
            }));
            setDropdownDisabled({
                location: true,
                role: formValues.roleType ? true : false,
                // role: formValues.roleType === "DEALER" ? true : false,.
                manager: true,
            });
        }
    }, [formValues.roleType]);

    // fetch locations when dealer is selected
    useEffect(() => {
        if (formValues.dealer && isEditMode) {
            fetchValues("location");
            setFormValues(prev => ({
                ...prev,
                location: formValues?.location,
                role: "",
                manager: "",
            }));
            setDropdownDisabled({
                location: false,
                role: true,
                manager: true,
            });
        }
        else if (formValues.dealer) {
            fetchValues("location");
            setFormValues(prev => ({
                ...prev,
                location: "",
                role: "",
                manager: "",
            }));
            setDropdownDisabled({
                location: false,
                role: true,
                manager: true,
            });
        }
    }, [formValues.dealer]);

    const fetchValues = async (type) => {
        const data = {
            roleId: userData.roleId,
            roleName: formValues.role !== "" ? formValues.role : existingUser?.role,
            roleType: formValues.roleType !== "" ? formValues.roleType : (isEditMode && existingUser.dealer == null ? "MIBL" : "DEALER"),
            type: !formValues.role && formValues.roleType === "MIBL" ? "Role Assignment" : type,
            dealerCode: userData?.dealerCode ?? '',
            // type: type,
            // type: formValues.roleType === "MIBL" ? "Role Assignment" : type === "Reporting Manager" ? "Reporting Manager" : "",
            dealerName: formValues.dealer,
            location: formValues.location,
            parentCode: userData?.parentCode || '',
            editUserId: existingUser?.id || ""
        };

        try {
            setLoading(true);
            const response = await fetchUserCreationValues(data);
            if (type === "dealer" && response.dealer) {
                let allowedRoles = featureAccess.filter(f => f.Url === decryptRoute(decodeURIComponent(encrypted))).map(f => f.FeatureName.slice(0, -5));
                setDealers(response.dealer.filter(rt => allowedRoles.some(ar => ar.toUpperCase() === rt.role_type)));
                if (response.dealer.filter(rt => allowedRoles.some(ar => ar.toUpperCase() === rt.role_type)).length === 1) {
                    setFormValues(prev => ({
                        ...prev,
                        roleType: response.dealer.find(rt => allowedRoles.some(ar => ar.toUpperCase() === rt.role_type)).role_type
                    }));
                    setDropdownDisabled(prev => ({ ...prev, roleType: true }));
                }
            }
            if (type === "dealerName" && response.dealerName) {
                setDealersName(response.dealerName);
                if (userData?.parentCode) {
                    setFormValues(prev => ({
                        ...prev,
                        dealer: response.dealerName[0]?.dealer_name
                    }));
                }
                setDropdownDisabled(prev => ({ ...prev, role: !isEditMode, manager: !isEditMode }))
            }

            if (type === "location" && response.location) {
                setLocations(response.location);
                if (userData?.roleType === "MIBL") {
                    setDropdownDisabled(prev => ({ ...prev, location: false }));
                } else if (userData?.roleType === "DEALER") {
                    setFormValues(prev => ({
                        ...prev,
                        location: response.location?.[0]?.loc_name
                    }));
                    setDropdownDisabled(prev => ({ ...prev, location: true }));
                }
            }

            if (response["Role Assignment"]) {
                setRoles(response["Role Assignment"]);
                setDropdownDisabled(prev => ({ ...prev, role: false }));
            }

            if (type === "Reporting Manager" && response["Reporting Manager"]) {
                setManagers(response["Reporting Manager"]);
                setDropdownDisabled(prev => ({ ...prev, manager: false }));
            }

            if (type === "Yes" && response["Lead Pool"]) {
                setLeadPoolOptions(response["Lead Pool"]);
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (formValues.callingFlag === "yes") {
            fetchValues("Yes");
            setFormValues(prev => ({
                ...prev,
                leadPool: [""],
            }));
        }
    }, [formValues.callingFlag]);

    // fetch roles when location is selected
    useEffect(() => {
        if (formValues.location === editValues.address || editValues || formValues.location) {
            fetchValues("Role Assignment");
            setFormValues(prev => ({
                ...prev,
                role: isEditMode && editValues.role ? editValues.role : "",
                manager: "",
            }));
            setDropdownDisabled(prev => ({ ...prev, role: false, manager: true }));
        }
        else {
            setFormValues(prev => ({
                ...prev,
                role: "",
                manager: "",
            }));
        }
    }, [formValues.location]);

    // fetch managers when role is selected
    // useEffect(() => {
    //     if (formValues.role === editValues.role || editValues || formValues.role) {
    //         fetchValues("Reporting Manager");
    //         setFormValues(prev => ({
    //             ...prev,
    //             manager: isEditMode && editValues.reportingManager ? editValues.reportingManager : "",
    //         }));
    //         setDropdownDisabled(prev => ({ ...prev, manager: false }));
    //     }
    //     else setFormValues(prev => ({
    //         ...prev,
    //         manager: "",
    //     }));
    // }, [formValues.role]);

    useEffect(() => {
        if (!formValues.role) return;

        fetchValues("Reporting Manager");

        // Only clear when role actually changes (not on edit load)
        // if (!isEditMode) {
        //     setFormValues(prev => ({
        //         ...prev,
        //         manager: "",
        //         reportingManagerId: ""
        //     }));
        // }

        setFormValues(prev => ({
            ...prev,
            manager:
                isEditMode && formValues.role === editValues?.role
                    ? editValues?.reportingManager || ""
                    : "", // 👈 clear when role changed
        }));

        setDropdownDisabled(prev => ({ ...prev, manager: false }));
    }, [formValues.role]);

    const handleChange = (field) => async (e) => {
        // console.log("-field-", field, "-e-", e.target.value)
        // formValues.manager = ""
        const value = field === "viewLeads" ? e.target.checked : e.target.value;

        if (field === "manager") {
            const selectedManager = managers.find(
                (mgr) => mgr.name === value
            );

            setFormValues((prev) => ({
                ...prev,
                manager: value,
                reportingManagerId: selectedManager?.id || "",
            }));

            return;
        }

        if (field !== "status" || !isEditMode)
            setFormValues((prev) => ({
                ...prev,
                [field]: field === "leadPool" ? value.filter(lp => !!lp) : value,

                // 👇 reset manager when role changes
                ...(field === "role" && { manager: "" }),
            }));

        setFormErrors((prev) => ({
            ...prev,
            [field]: "",
        }));

        if (field === "status" && isEditMode) setlockOpen(true);

        if (field === 'callingFlag' && value === 'no') {
            setFormValues((prev) => ({
                ...prev,
                ['viewLeads']: value === 'no',
            }));
        }
    };

    return (
        <>
            <BackdropLoader loading={loading} />

            <Paper elevation={0} sx={{ borderRadius: 3, m: isMobile ? 1.5 : 3, width: 'inherit' }}>
                <Box sx={{ borderRadius: 2 }}>
                    {/* Header */}

                    <Box display="flex" justifyContent="space-between" alignItems="center" px={isMobile ? 1.5 : 3} my={2}>
                        <Typography className={`georama-SemiBold ${isMobile ? 'fs-16' : 'fs-20'}`}>
                            {isEditMode && existingUser ? "Edit User" : "Create New User"}
                        </Typography>

                        <Button
                            className='text-capitalize georama-medium-selected custom-starticon'
                            startIcon={<ChevronLeftIcon />}
                            onClick={() => navigate(-1)}>
                            Back
                        </Button>
                    </Box>

                    <Divider sx={{ mb: 2 }} />

                    {/* Personal Details */}

                    <Grid container spacing={2} px={2} mb={2}>
                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                            <Typography className='text-labels' mb={0.5}>
                                First Name <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                className='form-control-input border-radius-8'
                                size="small"
                                fullWidth
                                required
                                placeholder="Enter First Name"
                                value={formValues.firstName}
                                onInput={(e) => {
                                    e.target.value = e.target.value.trimStart().replace(/[^a-zA-Z]/g, '').slice(0, 30);
                                }}
                                onChange={handleChange("firstName")}
                                error={!!formErrors.firstName}
                            />

                            <FormHelperText className="important-fields">{formErrors.firstName}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Last Name <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                className='form-control-input border-radius-8'
                                size="small"
                                fullWidth
                                required
                                placeholder="Enter Last Name"
                                value={formValues.lastName}
                                onInput={(e) => {
                                    e.target.value = e.target.value.trimStart().replace(/[^a-zA-Z]/g, '').slice(0, 30);
                                }}
                                onChange={handleChange("lastName")}
                                error={!!formErrors.lastName}
                            />

                            <FormHelperText className="important-fields">{formErrors.lastName}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                            <Typography className="text-labels" mb={0.5}>
                                Mobile No <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                fullWidth
                                size="small"
                                className="form-control-input border-radius-8"
                                required
                                placeholder="Enter Mobile No"
                                value={formValues.contactInfo}
                                onChange={(e) =>
                                    handleChange("contactInfo")({
                                        target: {
                                            value: e.target.value.replace(/\D/g, ""),
                                        },
                                    })
                                }
                                error={
                                    (formValues.contactInfo.length === 10 &&
                                        !/^[6-9]\d{9}$/.test(formValues.contactInfo)) ||
                                    !!formErrors.contactInfo
                                }
                                inputProps={{ maxLength: 10, inputMode: "numeric" }}
                            />

                            <FormHelperText className="important-fields">
                                {formValues.contactInfo.length === 10 &&
                                    !/^[6-9]\d{9}$/.test(formValues.contactInfo)
                                    ? "Enter a valid 10-digit mobile number"
                                    : formErrors.contactInfo}
                            </FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Email ID <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                size="small"
                                className={`form-control-input border-radius-8 ${(isEditMode && existingUser) ? "disabled-fields" : ""}`}
                                disabled={isEditMode && existingUser}
                                fullWidth required
                                placeholder="Enter Email Id"
                                value={formValues.email}
                                onChange={handleChange("email")}
                                error={!!formErrors.email}
                            />

                            <FormHelperText className="important-fields">{formErrors.email}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                            <Typography className='text-labels' mb={1}>
                                Status <span className="important-fields">*</span>
                            </Typography>

                            {/* <FormGroup>
                                <FormControlLabel
                                    control={<IOSSwitch onChange={handleChange("status")} sx={{ m: 1 }} checked={formValues.status == 1} />}
                                />
                            </FormGroup> */}

                            <FormControl required error={!!formErrors.status}>
                                <RadioGroup
                                    className="radio-button-box"
                                    row
                                    value={formValues.status}
                                    onChange={handleChange("status")}
                                >
                                    <FormControlLabel
                                        className="radio-button-label"
                                        checked={formValues.status === "1"}
                                        value={1}
                                        control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                        label="Active"
                                    />

                                    <FormControlLabel
                                        className="radio-button-label"
                                        checked={formValues.status === "0"}
                                        value={0}
                                        control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                        label="Inactive"
                                    />
                                </RadioGroup>
                            </FormControl>

                            <FormHelperText className="important-fields">{formErrors.status}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                            <Typography className='text-labels' mb={1}>
                                Group Email <span className="important-fields">*</span>
                            </Typography>

                            {/* <FormGroup>
                                <FormControlLabel
                                    control={<IOSSwitch onChange={handleChange("status")} sx={{ m: 1 }} checked={formValues.status == 1} />}
                                />
                            </FormGroup> */}

                            <FormControl required error={!!formErrors.isGroup}>
                                <RadioGroup
                                    className="radio-button-box"
                                    row
                                    value={formValues.isGroup}
                                    onChange={handleChange("isGroup")}
                                >
                                    <FormControlLabel
                                        className="radio-button-label"
                                        checked={formValues.isGroup === "Y"}
                                        value={"Y"}
                                        control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                        label="Yes"
                                    />

                                    <FormControlLabel
                                        className="radio-button-label"
                                        checked={formValues.isGroup === "N"}
                                        value={"N"}
                                        control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                        label="No"
                                    />
                                </RadioGroup>
                            </FormControl>

                            <FormHelperText className="important-fields">{formErrors.isGroup}</FormHelperText>
                        </Grid>

                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                            <Typography className='text-labels' mb={1}>
                                Team Email
                            </Typography>

                            <FormControl >
                                <RadioGroup
                                    className="radio-button-box"
                                    row
                                    value={formValues.teamEmail}
                                    onChange={handleChange("teamEmail")}
                                >
                                    <FormControlLabel
                                        className="radio-button-label"
                                        value="Y"
                                        checked={formValues.teamEmail === "Y"}
                                        control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                        label="Yes"
                                    />

                                    <FormControlLabel
                                        className="radio-button-label"
                                        value="N"
                                        checked={formValues.teamEmail === "N"}
                                        control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                        label="No"
                                    />
                                </RadioGroup>
                            </FormControl>
                        </Grid>
                    </Grid>

                    <Divider />

                    {/* Top Select Fields */}

                    <Grid container spacing={2} px={3} mt={2} mb={3}>
                        {userData?.userDetail?.parentCode !== "" &&
                            <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                <Typography className='text-labels' mb={0.5}>
                                    Role Source <span className="important-fields">*</span>
                                </Typography>

                                <FormControl
                                    className='form-control-input border-radius-8'
                                    size="small"
                                    fullWidth required error={!!formErrors.roleType}
                                    disabled={userData?.roleType === "DEALER" || isEditMode || dropdownDisabled.roleType}>
                                    <Select
                                        value={formValues.roleType} displayEmpty
                                        onChange={handleChange("roleType")}
                                    >
                                        <MenuItem value="" disabled>
                                            Select
                                        </MenuItem>

                                        {dealers && dealers?.map((data, index) => (
                                            <MenuItem key={index} value={data.role_type}>
                                                {data.role_type}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>

                                <FormHelperText className="important-fields">{formErrors.roleType}</FormHelperText>
                            </Grid>}

                        {formValues.roleType === "MIBL" &&
                            <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                <Typography className='text-labels' mb={0.5}>
                                    SAP Code <span className="important-fields">*</span>
                                </Typography>

                                <TextField
                                    className='form-control-input border-radius-8'
                                    size="small"
                                    fullWidth
                                    required
                                    placeholder="Enter 8-digit SAP Code"
                                    value={formValues.sapCode}
                                    // onInput={(e) => {
                                    //     e.target.value = e.target.value.trimStart().replace(/[^0-9]/g, '').slice(0, 10);
                                    // }}
                                    onInput={(e) => {
                                        e.target.value = e.target.value
                                            .trimStart()
                                            .replace(/[^0-9]/g, '') // Only digits
                                            .slice(0, 8); // Limit to 8 digits max
                                    }}
                                    onChange={(e) => {
                                        handleChange("sapCode")(e);
                                    }}
                                    error={!!formErrors.sapCode}
                                    inputProps={{ maxLength: 8, minLength: 8, inputMode: 'numeric' }}
                                />

                                <FormHelperText className="important-fields">{formErrors.sapCode}</FormHelperText>
                            </Grid>}

                        {formValues.roleType === "DEALER" &&
                            <>
                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Dealer <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        className={`form-control-input border-radius-8 ${(isEditMode && existingUser) ? "disabled-fields" : ""}`}
                                        size="small"
                                        fullWidth
                                        required error={!!formErrors.dealer} disabled={isEditMode && existingUser}>
                                        <Autocomplete size="small"
                                            options={dealersName?.filter(dn => dn && dn?.dealer_name)?.map((item) => item?.dealer_name)}
                                            value={formValues.dealer || ""}
                                            onChange={(event, value) => {
                                                value ? handleChange("dealer")({ target: { value: value } }) : undefined;
                                            }}
                                            renderInput={(params) => (
                                                <TextField {...params} placeholder="Select Dealer" />
                                            )}
                                            disableClearable
                                            disabled={userData?.roleType === "DEALER" || isEditMode && existingUser}
                                            getOptionLabel={(option) => option || ""}
                                            isOptionEqualToValue={(option, value) => option === value}
                                        />
                                    </FormControl>

                                    <FormHelperText className="important-fields">{formErrors.dealer}</FormHelperText>
                                </Grid>

                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Location <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        className={`form-control-input border-radius-8 ${(dropdownDisabled.location) ? "disabled-fields" : ""}`}
                                        size="small"
                                        fullWidth
                                        required error={!!formErrors.location}
                                        disabled={userData?.roleType === "DEALER" || dropdownDisabled.location}
                                    >
                                        <Select
                                            value={formValues?.location || ""}
                                            onChange={handleChange("location")}
                                            displayEmpty
                                            disabled={dropdownDisabled.location}
                                        >
                                            <MenuItem value="" disabled>Select</MenuItem>
                                            {locations && locations?.map((loc, i) => (
                                                <MenuItem key={i} value={loc.loc_name}>
                                                    {loc.loc_name}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>

                                    <FormHelperText className="important-fields">{formErrors.location}</FormHelperText>
                                </Grid>
                            </>}

                        {(formValues.roleType === "MIBL" || formValues.roleType === "DEALER") &&
                            <>
                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Role Assignment <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        className="form-control-input border-radius-8"
                                        size="small"
                                        fullWidth required error={!!formErrors.role}>
                                        <Select
                                            value={formValues?.role}
                                            onChange={handleChange("role")}
                                            displayEmpty
                                            disabled={dropdownDisabled.role}
                                        >
                                            <MenuItem value="" disabled>Select</MenuItem>
                                            {roles && roles?.map((data, index) => (
                                                <MenuItem key={index} value={data.role}>
                                                    {data.role}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                    <FormHelperText className="important-fields">{formErrors.role}</FormHelperText>
                                </Grid>

                                {(formValues.roleType === "DEALER" || (managers && managers?.length > 0)) &&
                                    <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                        <Typography className='text-labels' mb={0.5}>
                                            Reporting Manager {userData?.roleType === "DEALER" && <span className="important-fields">*</span>}
                                        </Typography>

                                        <FormControl fullWidth
                                            className="form-control-input border-radius-8"
                                            size="small">
                                            <Select
                                                value={formValues.manager || ""}
                                                onChange={handleChange("manager")}
                                                displayEmpty
                                                // disabled={fieldsDisabled}
                                                disabled={dropdownDisabled.manager}
                                            >
                                                <MenuItem value="" disabled>Select</MenuItem>

                                                {managers && managers.map((mgr, i) => (
                                                    <MenuItem key={i} value={mgr.name}>
                                                        {mgr.name}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                        {userData?.roleType === "DEALER" && <FormHelperText className="important-fields">{formErrors.manager}</FormHelperText>}
                                    </Grid>}
                            </>
                        }
                        {formValues.roleType !== "DEALER" && formValues.roleType && <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                            <Typography className='text-labels'>
                                AD Flag <span className="important-fields">*</span>
                            </Typography>

                            <Box display="flex" flexDirection="row" alignItems={"baseline"} mt={0.5}>
                                <FormControl required error={!!formErrors.adFlag}>
                                    <RadioGroup
                                        className="radio-button-box"
                                        row
                                        value={formValues.adFlag}
                                        onChange={handleChange("adFlag")}
                                    >
                                        <FormControlLabel
                                            className="radio-button-label"
                                            value="yes"

                                            control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                            label="Yes"
                                        />

                                        <FormControlLabel
                                            className="radio-button-label"
                                            value="no"
                                            control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                            label="No"
                                        />
                                    </RadioGroup>
                                </FormControl>
                            </Box>

                            <FormHelperText className="important-fields">{formErrors.adFlag}</FormHelperText>
                        </Grid>}

                        {formValues.roleType === "DEALER" &&
                            <>

                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels'>
                                        Calling Flag <span className="important-fields">*</span>
                                    </Typography>

                                    <Box display="flex" flexDirection="row" alignItems={"baseline"} mt={0.5}>
                                        <FormControl required error={!!formErrors.callingFlag}>
                                            <RadioGroup
                                                className="radio-button-box"
                                                row
                                                value={formValues.callingFlag}
                                                onChange={handleChange("callingFlag")}
                                            >
                                                <FormControlLabel
                                                    className="radio-button-label"
                                                    value="yes"
                                                    control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                                    label="Yes"
                                                />

                                                <FormControlLabel
                                                    className="radio-button-label"
                                                    value="no"
                                                    control={<Radio sx={{ "&.Mui-checked": { color: "#e53935" } }} />}
                                                    label="No"
                                                />
                                            </RadioGroup>
                                        </FormControl>
                                    </Box>

                                    <FormHelperText className="important-fields">{formErrors.callingFlag}</FormHelperText>
                                </Grid>
                            </>}

                        {(formValues.callingFlag === "no" || editValues.callingFlag === "N") && (
                            <Grid size={3}><Typography className='text-labels'>View Leads</Typography>
                                <Box display="flex" flexDirection="row" alignItems={"baseline"} mt={0.5} className="communication-box" >
                                    <FormControlLabel
                                        className="communication-label"
                                        control={
                                            <Checkbox
                                                className="communication-checkbox"
                                                checked={formValues.viewLeads}
                                                disabled
                                                onChange={handleChange("viewLeads")}
                                                sx={{
                                                    "&.Mui-checked": { color: "#e53935" },
                                                    "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                }}
                                            />
                                        }
                                        label="View Leads"
                                    />
                                </Box>
                            </Grid>
                        )}

                        {formValues.callingFlag === "yes" && (
                            <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                <Box fullWidth>
                                    <Typography className='text-labels' mb={0.5}>
                                        Lead Pool
                                    </Typography>

                                    <FormControl
                                        size="small"
                                        fullWidth
                                        className="form-control-input border-radius-8"
                                    >
                                        <Select
                                            multiple
                                            displayEmpty
                                            value={formValues?.leadPool || []}
                                            onChange={handleChange("leadPool")}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 300,
                                                    },
                                                },
                                            }}
                                            renderValue={(selected) =>
                                                selected.length === 0 ? (
                                                    <span style={{ color: "#aaa" }}>Select</span>
                                                ) : (
                                                    selected.join(", ")
                                                )
                                            }
                                        >
                                            {leadPoolOptions &&
                                                leadPoolOptions?.map((item, index) => (
                                                    <MenuItem key={index} value={item?.bucket_name}>
                                                        <Checkbox
                                                            checked={formValues.leadPool?.includes(item?.bucket_name)}
                                                            sx={{
                                                                color: '#e53935',
                                                                '&.Mui-checked': {
                                                                    color: '#e53935',
                                                                },
                                                            }}
                                                        />
                                                        <ListItemText primary={item?.bucket_name} />
                                                    </MenuItem>
                                                ))}
                                        </Select>
                                    </FormControl>

                                    {/* <FormControl size="small" fullWidth className="form-control-input border-radius-8" >
                                        <Select
                                            value={formValues?.leadPool}
                                            onChange={handleChange("leadPool")}
                                            displayEmpty
                                            multiple
                                        >
                                            <MenuItem value="" disabled selected>Select</MenuItem>

                                            {leadPoolOptions && leadPoolOptions?.map((item, index) => (
                                                <MenuItem key={index} value={item.bucket_name}>
                                                    {item.bucket_name}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl> */}
                                </Box >
                            </Grid>
                        )}

                        {formValues?.callingFlag === "no" && formValues?.viewLeads && (
                            <Grid size={4} item xs={12} md={4}>
                                <Box>
                                    <FormControl required error={!!formErrors.leadsFlag}>
                                        <Typography className='text-labels' mb={0.5}>
                                            Leads Flag <span className="important-fields">*</span>
                                        </Typography>

                                        <RadioGroup
                                            className="radio-button-box"
                                            row
                                            value={formValues?.leadsFlag || editValues?.lead_flag}
                                            onChange={handleChange("leadsFlag")}
                                        >
                                            <FormControlLabel
                                                className="radio-button-label"
                                                value="All Leads"
                                                control={<Radio sx={{ '&.Mui-checked': { color: '#e53935' } }} />}
                                                label="All Leads"
                                            />

                                            <FormControlLabel
                                                className="radio-button-label"
                                                value="My Team Leads"
                                                control={<Radio sx={{ '&.Mui-checked': { color: '#e53935' } }} />}
                                                label="My Team Leads"
                                            />
                                        </RadioGroup>

                                        <FormHelperText>{formErrors.leadsFlag}</FormHelperText>
                                    </FormControl>
                                </Box>
                            </Grid>
                        )}
                    </Grid>

                    <Box display="flex" mx={5} mb={2} justifyContent="flex-end">
                        {/* <Button variant="contained" color="error" onClick={handleSubmit} disabled={!isFormValid}> */}

                        <Button className="btn-common-red" disabled={loading} onClick={handleSubmit}>
                            Submit
                        </Button>
                    </Box>
                </Box>
            </Paper >

            <ToastContainer autoClose={1000} />

            <LockUserModal userId={existingUser.id} lockopen={lockopen} lockonClose={lockonClose} editUser={isEditMode} email={formValues.email} userStatus={formValues.status === "1" ? "0" : "1"} />

            <Dialog open={openModal} onClose={() => setOpenModal(false)}>
                <DialogTitle>User Created</DialogTitle>
                <DialogContent>
                    {modalMessage}
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={() => {
                            setOpenModal(false);
                            navigate(`/${encodeURIComponent(encryptRoute('/userManagement'))}`);
                        }}
                        variant="contained"
                    >
                        OK
                    </Button>
                </DialogActions>
            </Dialog>

        </>
    );
}