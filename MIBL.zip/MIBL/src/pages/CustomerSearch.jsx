import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import SearchIcon from '@mui/icons-material/Search';
import { Box, Button, Collapse, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Pagination, Paper, Skeleton, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, useMediaQuery } from "@mui/material";
import Tooltip from '@mui/material/Tooltip';
import React, { useEffect, useState } from "react";
import { useSelector } from 'react-redux';
import 'react-toastify/dist/ReactToastify.css';
import searchImg from "../assets/images/callqueue/search-view-records.svg";
import nodata1 from "../assets/images/target/noData3.svg";
import CustomerSearchDetail from "../components/CustomerSearchDetail";
import BackdropLoader from "../components/Loader/BackdropLoader";
import AdvancedSearchFields from "../modals/AdvancedSearchFields";
import { customerSearch } from "../services/api";
import { bgGray100, cursorpointer } from '../utils/Colors';

const CustomerSearch = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [rows, setRows] = useState([]);
    const [openMobileSearch, setOpenMobileSearch] = useState(false);
    const [columns, setColumns] = useState([]);
    const [limit, setLimit] = useState(10);
    // const [search, setSearch] = useState({ name: '', phoneNumber: '', vinNumber: '', registrationNo: '' });
    const [search, setSearch] = useState({
        name: '',
        phoneNumber: '',
        vinNumber: '',
        registrationNo: '',
        policyNo: '',
        policyTenure: '',
        policyType: '',
        make: '',
        model: '',
        variant: '',
        vehicleClass: '',
        engineNo: '',
        insuranceCompany: '',
        vehicleRegNo: '',
        yom: '',
        fuelType: '',
        addonName: ''
    });
    const [count, setCount] = useState(0);
    const [callQueueType, setCallQueueType] = useState('');
    const [page, setPage] = useState(1);
    const isCaller = useSelector((state) => state.user.isCaller);
    const { user_id, roleId, dealerCode } = useSelector((state) => state.user.loggedData);
    const [customerInfo, setCustomerInfo] = useState();
    const [loading, setLoading] = useState(false);
    const [noDataText, setNoDataText] = useState(false);
    const [showAdvanced, setShowAdvanced] = useState(false);

    const handleToggleAdvanced = () => setShowAdvanced(!showAdvanced);

    useEffect(() => {
        setCallQueueType('');
    }, [isCaller]);

    const [openRow, setOpenRow] = useState(null);

    const handleToggleAccordion = (index, row) => {
        setCustomerInfo(row);
        setOpenRow((prev) => (prev === index ? null : index));
    };

    const handleSearch = async () => {
        try {
            setLoading(true);
            setShowAdvanced(false);
            if (Object.values(search).join('')) {
                const result = await customerSearch({ limit, page: page, search, userId: user_id, callQueueType: "customersearch" });
                setRows(result.policyDetails);
                setNoDataText(Object.values(search).join('') ? true : false);
                setCount(Object.values(search).join('') ? result?.policyDetails?.length : 0);
                setPage(1);
            }
            else {
                setRows([]);
                setCount(0);
                setNoDataText(false);
            }
            setOpenRow(null);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    const handleSearchInput = (key, value) => {
        let isValid = false;

        switch (key) {
            case 'name':
                isValid = /^[A-Za-z .]{0,30}$/.test(value);
                if ((value === '' || isValid) && value.length <= 30) {
                    setSearch(prev => ({ ...prev, [key]: value }));
                }
                break;

            case 'phoneNumber':
                isValid = /^[0-9]{0,10}$/.test(value);
                if (value === '' || isValid) {
                    setSearch(prev => ({ ...prev, [key]: value }));
                }
                break;

            case 'vinNumber':
                isValid = /^[A-Za-z0-9]{0,17}$/.test(value);
                if (value === '' || isValid) {
                    setSearch(prev => ({ ...prev, [key]: value }));
                }
                break;

            case 'registrationNo':
                isValid = /^[A-Za-z0-9-]{0,50}$/.test(value);
                if (value === '' || isValid) {
                    setSearch(prev => ({ ...prev, [key]: value }));
                }
                break;

            default:
                setSearch(prev => ({ ...prev, [key]: value }));
        }
    };

    const clearSearchFields = () => {
        setSearch({
            name: '',
            phoneNumber: '',
            vinNumber: '',
            registrationNo: '',
            policyNo: '',
            policyTenure: '',
            policyType: '',
            make: '',
            model: '',
            variant: '',
            vehicleClass: '',
            engineNo: '',
            insuranceCompany: '',
            vehicleRegNo: '',
            yom: '',
            fuelType: '',
            addonName: ''
        });
        setRows([]);
        setCount(0);
        setNoDataText(false);
    }

    const fetchPage = async () => {
        try {
            // const result = await getHeaders({ pageId: 2, roleId, accessType: 'caller' });
            // const response = result.data;
            // setColumns(response.inputModel.filter(f => f.parentId === null).map((f) => ({ field: f.inputName, filter: f.filter })));
            setColumns(['Customer Name', 'Customer Address', 'Customer Email', "Vehicle Reg No.", 'Chassis No.', '']);
        } catch (error) {
            console.error('Error posting data:', error);
        }
    };

    const fetchData = async () => {
        try {
            setLoading(true);
            const result = await customerSearch({ limit, page: page, search, userId: user_id, callQueueType: "customersearch" });
            setRows(result.policyDetails);
            setNoDataText(Object.values(search).join('') ? true : false);
            setCount(Object.values(search).join('') ? result?.policyDetails?.length : 0);
            setPage(1);
            setOpenRow(null);
            setCustomerInfo();
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchPage();
    }, [isCaller])

    useEffect(() => {
        setOpenRow(null);
        setCustomerInfo();
    }, [page])

    useEffect(() => {
        if (Object.values(search).join('')) {
            handleSearch();
        }
        else {
            setRows([]);
            setCount(0);
            setNoDataText(false);
        }
    }, [callQueueType, limit, isCaller]);

    return (
        <>
            <BackdropLoader loading={loading} />
            {/* <MarqueeInfo /> */}

            <Dialog
                open={openMobileSearch}
                onClose={() => setOpenMobileSearch(false)}
                fullWidth
                maxWidth="md"
            >
                <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography>
                        Advanced Search
                    </Typography>
                    {Object.values(search).some(val => val != "") &&
                        <Button
                            className="text-capitalize highlight-red"
                            sx={{ width: "100px", p: 0, m: 0, fontWeight: "bold" }}
                            onClick={() => {
                                setSearch({
                                    name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: ''
                                });
                                // dispatch(setSearch({
                                //     name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: ''
                                // }));
                                // dispatch(setSearchType(''));
                                // dispatch(setPage(1));
                                // fetchData();
                            }}
                        >
                            Clear All
                        </Button>}
                </DialogTitle>

                <DialogContent className="advanced-search-modal">
                    <AdvancedSearchFields
                        search={search}
                        handleSearchInput={handleSearchInput}
                        isMobile={true}
                        handleToggleAdvanced={handleToggleAdvanced}
                        handleSearch={handleSearch}
                        setSearch={setSearch}
                        clearSearchFields={clearSearchFields}
                    />
                </DialogContent>

                <DialogActions>
                    <Button className="highlight-red" onClick={() => setOpenMobileSearch(false)}>
                        Cancel
                    </Button>
                    <Button
                        className="btn-common-red"
                        onClick={() => {
                            handleSearch(1);
                            setOpenMobileSearch(false);
                        }}
                    >
                        Apply Search
                    </Button>
                </DialogActions>
            </Dialog>

            <Stack width={'inherit'}>
                <Paper className="body-formbg" sx={{ borderTop: '1px solid rgb(211, 203, 203)', boxShadow: 'none' }}>
                    <Box position="relative">
                        {isMobile && (
                            <Button
                                className="btn-common-red"
                                sx={{
                                    width: "90%",
                                    mt: 1,
                                    mx: 2
                                }}
                                onClick={() => setOpenMobileSearch(true)}
                                startIcon={<SearchIcon />}
                            >
                                Search
                            </Button>
                        )}
                        {!isMobile && (
                            <AdvancedSearchFields
                                search={search}
                                handleSearchInput={handleSearchInput}
                                isMobile={false}
                                handleSearch={handleSearch}
                                setSearch={setSearch}
                                handleToggleAdvanced={handleToggleAdvanced}
                                showAdvanced={showAdvanced}
                                clearSearchFields={clearSearchFields}
                            />
                        )}
                    </Box>
                </Paper >

                {/* --------------------- Customer Search Table ** code starts ------------------------------ */}
                <Paper sx={{
                    px: 3, py: 0, ...bgGray100, boxShadow: 'none'
                }}>
                    <Box
                        display="flex"
                        alignItems="center"
                        justifyContent="space-between"
                        flexWrap="wrap"
                        gap={2}
                        mb={1}
                    >
                        {/* Left Side: Labels */}
                        <Box >
                            <Typography mt={isMobile ? 1 : 2} className={`georama-SemiBold ${isMobile ? 'fs-18' : 'fs-24'}`}>
                                Customer Search
                            </Typography>
                        </Box>

                        {/* Right Side: Filters & Marquee */}
                        {/* <Box display="flex" alignItems="center" gap={1} overflow={"hidden"}>
                        <Button sx={{ ...btnRed, px: 3, mx: 2 }} startIcon={<PersonAddIcon />} onClick={handleSearch}>
                            New Customer
                        </Button>
                    </Box> */}
                    </Box>
                    <TableContainer component={Box} sx={{ mt: 0, boxShadow: "none" }}>
                        <Table
                            sx={{ minWidth: 1200, borderCollapse: 'separate', boxShadow: "none", borderSpacing: '0px 4px' }} stickyHeader>
                            <TableHead>
                                <TableRow className="bg-white">
                                    {loading ? (
                                        // Render Skeletons instead of real headers
                                        [...Array(7)].map((_, index) => (
                                            <TableCell key={index} className="custom-table-cell-header fs-14">
                                                <Skeleton variant="text" width="80%" height={24} />
                                            </TableCell>
                                        ))
                                    ) : (
                                        rows && columns && columns.map((cell, index) => (
                                            <TableCell className="georama-Medium custom-table-cell-header bg-white fs-14"
                                                key={index}
                                                sx={{
                                                    ...cursorpointer,
                                                    borderTopLeftRadius: index === 0 ? 8 : 0,
                                                    borderTopRightRadius: index === columns.length - 1 ? 8 : 0,
                                                    borderBottomLeftRadius: index === 0 ? 8 : 0,
                                                    borderBottomRightRadius: index === columns.length - 1 ? 8 : 0,
                                                }}
                                            // onClick={cell.sort === true ? () => handleSort(cell.field) : undefined}
                                            >
                                                <Box display="flex" alignItems="center" gap={1} className={`${index === 0 ? '' : ''}`}>
                                                    <span className="cs-py-2 fs-14 text-dark georama-Medium">{cell}</span>
                                                </Box>
                                                {/* {cell.field}
                                            {cell.filter === "1" && (
                                                <IconButton
                                                    aria-label="expand row"
                                                    size="small"
                                                >
                                                    <KeyboardArrowDownIcon />
                                                </IconButton>)} */}
                                            </TableCell>
                                        )))}
                                </TableRow>
                            </TableHead>

                            <TableBody>
                                {loading ? (
                                    // Show 5 rows of skeletons
                                    [...Array(5)].map((_, rowIndex) => (
                                        <TableRow key={rowIndex}>
                                            {[...Array(7)].map((_, colIndex) => (
                                                <TableCell key={colIndex}>
                                                    <Skeleton variant="text" width="100%" height={28} />
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    ))
                                ) : (
                                    rows && rows.length > 0 ? rows?.slice(
                                        limit * (page - 1), page === Math.ceil(count / limit) ? undefined : limit * page
                                    ).map((row, index) => (
                                        <React.Fragment key={index}>
                                            <TableRow
                                                sx={{
                                                    backgroundColor: 'white',
                                                    borderRadius: 2,
                                                    // boxShadow: '0px 2px 6px rgba(0, 0, 0, 0.05)',
                                                    boxShadow: 'none',
                                                    '& td': {
                                                        borderBottom: 'none',
                                                        paddingBottom: 0, // remove bottom padding
                                                    },
                                                    '& td:first-of-type': {
                                                        borderTopLeftRadius: '8px',
                                                        borderBottomLeftRadius: openRow === index ? 0 : '8px',
                                                    },
                                                    '& td:last-of-type': {
                                                        borderTopRightRadius: '8px',
                                                        borderBottomRightRadius: openRow === index ? 0 : '8px',
                                                    },
                                                }}
                                            >
                                                {/* <TableCell className="custom-table-cell-p pl-3">
                                                <b>{row.customerName}</b><br />
                                                <small>Lead Id {row.leadId}</small>
                                            </TableCell> */}

                                                {/* {Object.keys(row).slice(3, -3).map((f) => (
                                            <TableCell key={f}>{row[f]}</TableCell>
                                        ))} */}
                                                {/* {
                                                Object.keys(row).slice(3, -3).map((f) => <TableCell key={f} className="custom-table-cell-p">{
                                                    f.slice(0, 6).toLowerCase() === 'recent' ? transformDate(row[f]).split('\n').map((line, index) => (
                                                        <React.Fragment key={index}>
                                                            {line.trim()}
                                                            <br />
                                                        </React.Fragment>
                                                    ))
                                                        : f.slice(0, 6).toLowerCase() === 'expiry'
                                                            ? <>{format(parseISO(row[f]), 'dd MMM yyyy')}<br />
                                                                <Typography variant="caption" color="error">Exp Days {String(row.expiryDays).padStart(2, '0')} days</Typography></>
                                                            : row[f]
                                                }</TableCell>)
                                            } */}

                                                {/* <TableCell className="custom-table-cell-p">
                                                <Box
                                                    component="span"
                                                    sx={{
                                                        padding: '4px 12px',
                                                        borderRadius: '12px',
                                                        fontSize: '12px',
                                                        fontWeight: 500,
                                                        color: 'white',
                                                        backgroundColor:
                                                            row?.status?.toLowerCase() === 'customer visit planned'
                                                                ? greenbg
                                                                : row?.status?.slice(0, 9).toLowerCase() === 'try again' && row?.status?.length > 15
                                                                    ? pinkbg
                                                                    : row?.status?.slice(0, 9).toLowerCase() === 'try again'
                                                                        ? orangebg
                                                                        : bluebg,
                                                    }}
                                                >
                                                    {row.status}
                                                </Box>
                                            </TableCell> */}

                                                <TableCell className="georama-Regular fs-12 custom-table-cell-p pl-3 text-truncate">
                                                    <span className="text-truncate pl-3" >
                                                        {row.customer_name}
                                                    </span>
                                                </TableCell>
                                                <TableCell className="georama-Regular fs-12 custom-table-cell-p pl-3">{row.customer_address}</TableCell>
                                                <TableCell className="georama-Regular fs-12 custom-table-cell-p pl-3">{row.customer_email}</TableCell>
                                                <TableCell className="georama-Regular fs-12 custom-table-cell-p pl-3">{row.vehicle_reg_no}</TableCell>
                                                <TableCell className="georama-Regular fs-12 custom-table-cell-p pl-3">{row.chassis_no}</TableCell>
                                                <TableCell className="georama-Regular fs-12 custom-table-cell-p pl-3">
                                                    <Stack direction="row" spacing={1}>
                                                        <Tooltip title="More Details">
                                                            <IconButton onClick={() => {
                                                                handleToggleAccordion(index, row)
                                                            }}>
                                                                {openRow === index ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                                                            </IconButton>
                                                        </Tooltip>
                                                    </Stack>
                                                </TableCell>
                                            </TableRow>

                                            {/* Collapsible Row */}
                                            <TableCell colSpan={10} sx={{ border: "none", p: 0, m: 0, backgroundColor: 'white', padding: "0px !important" }} className="georama-Regular fs-14 custom-table-cell-p" >
                                                <Collapse sx={{ padding: "0px !important" }} in={openRow === index} timeout="auto" unmountOnExit>
                                                    <Box
                                                        sx={{
                                                            backgroundColor: 'white',
                                                            px: 2,
                                                            pt: 1,
                                                            // pb: 2,
                                                            borderRadius: 2,
                                                            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
                                                        }}
                                                    >
                                                        <CustomerSearchDetail customerInfo={customerInfo} />
                                                        {/* <CustomerDetailsPage /> */}
                                                    </Box>
                                                </Collapse>
                                            </TableCell>
                                        </React.Fragment>
                                    )) : (
                                        <TableRow>
                                            <TableCell sx={{ pl: "0px !important" }} colSpan={isMobile ? 1 : columns?.length}>
                                                <Box className="center-text" display={"flex"} justifyContent={"center"} alignItems={"center"}>
                                                    {noDataText ? <img width={400} src={nodata1} alt="No Data" /> : <img width={isMobile ? 180 : 370} src={searchImg} alt="Search image" />}
                                                </Box>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                            </TableBody>

                        </Table>
                    </TableContainer>
                    <Box>

                        {!!count && <Pagination size="medium" count={Math.ceil(count / limit)} page={page} onChange={(e, v) => setPage(v)} shape="rounded"
                            sx={{
                                float: 'right', m: 1,
                                '& .MuiPaginationItem-root': {
                                    borderRadius: 3,
                                }
                            }} />}
                    </Box>
                </Paper >
                {/* --------------------- Customer Search Table ** code ends ------------------------------ */}
                {/* <ToastContainer autoClose={1000} /> */}
            </Stack>
        </>
    )
}

export default CustomerSearch;