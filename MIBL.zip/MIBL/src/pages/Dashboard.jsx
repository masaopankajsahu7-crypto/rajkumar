import { Card, Paper, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, Chip, Typography, Box, Grid } from '@mui/material';
import { Doughnut, Line, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, LineElement, PointElement, CategoryScale, LinearScale, BarElement, LineController, BarController, PieController, ScatterController, DoughnutController } from 'chart.js';

import { users } from '../utils/userData';
import { Select, MenuItem, FormControl, InputLabel } from '@mui/material';
import { useState } from 'react';

import dealerImg from '../assets/images/dashboard/dealer.svg';
import branchImg from '../assets/images/dashboard/branch.svg';
import userImg from '../assets/images/dashboard/users.svg';
import agentImg from '../assets/images/dashboard/agents.svg';

// ChartJS Registration
ChartJS.register(
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    CategoryScale,
    LinearScale,
    BarElement, LineController, BarController, PieController, ScatterController, DoughnutController
);

const Dashboard = () => {

    // At the top of the component
    const [region, setRegion] = useState('');
    const [zone, setZone] = useState('');

    const handleRegionChange = (e) => setRegion(e.target.value);
    const handleZoneChange = (e) => setZone(e.target.value);

    // Summary cards data
    const summaryCards = [
        { title: 'Dealers', value: 56, icon: dealerImg, color: 'dashboard-pink' },
        { title: 'Branch', value: 48, icon: branchImg, color: 'dashboard-orange' },
        { title: 'Users', value: 65, icon: userImg, color: 'dashboard-green' },
        { title: 'Agents', value: 26, icon: agentImg, color: 'dashboard-blue' }
    ];

    // Pie chart data
    const pieData = {
        labels: ['Dealers', 'Branch', 'Agents', 'Users'],
        datasets: [{
            data: [56, 48, 26, 65],
            backgroundColor: ['#f44336', '#FF9800', '#2196F3', '#8E44AD']
        }]
    };

    // Line chart data
    const lineData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [
            {
                label: '% Conversion week-over-week',
                data: [20, 25, 22, 35, 50, 45, 60, 70, 65, 80, 90, 95],
                borderColor: '#FF9F40',
                fill: false,
                tension: 0.3
            },
            {
                label: 'Month-over-month',
                data: [15, 18, 25, 30, 40, 60, 70, 75, 80, 85, 95, 100],
                borderColor: '#36A2EB',
                fill: false,
                tension: 0.3
            }
        ]
    };

    // Bar chart data
    const barData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [
            {
                label: '% Conversion week-over-week',
                backgroundColor: '#FF9F40',
                data: [40, 55, 45, 70, 65, 30, 40, 60, 70, 80, 75, 90]
            },
            {
                label: 'Month-over-month',
                backgroundColor: '#36A2EB',
                data: [35, 50, 40, 60, 70, 40, 50, 65, 60, 85, 70, 95]
            }
        ]
    };



    return (
        <>
            <Paper className="body-formbg" elevation={0} sx={{ p: 2, width: "inherit", boxShadow: 'none' }}>
                <Box p={1}>
                    <Box display={'flex'} justifyContent="space-between" alignItems="center" mb={3}>
                        <Typography className="georama-SemiBold fs-20" mb={3}>Pan-India Lead Status</Typography>
                        <Box display="flex" gap={2} mb={1}>
                            <FormControl className='' size="small" sx={{ minWidth: 150, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel>Region</InputLabel>
                                <Select
                                    value={region}
                                    label="Region"
                                    onChange={handleRegionChange}
                                    variant="outlined"
                                >
                                    <MenuItem value=""><em>None</em></MenuItem>
                                    <MenuItem value="North">North</MenuItem>
                                    <MenuItem value="South">South</MenuItem>
                                    <MenuItem value="East">East</MenuItem>
                                    <MenuItem value="West">West</MenuItem>
                                </Select>
                            </FormControl>

                            <FormControl size="small" sx={{ minWidth: 150, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel>Zone</InputLabel>
                                <Select
                                    value={zone}
                                    label="Zone"
                                    onChange={handleZoneChange}
                                    variant="outlined"
                                >
                                    <MenuItem value=""><em>None</em></MenuItem>
                                    <MenuItem value="Zone 1">Zone 1</MenuItem>
                                    <MenuItem value="Zone 2">Zone 2</MenuItem>
                                    <MenuItem value="Zone 3">Zone 3</MenuItem>
                                </Select>
                            </FormControl>
                        </Box>
                    </Box>

                    {/* Summary Cards */}
                    <Grid container spacing={2} >
                        {summaryCards.map((card, index) => (
                            <Grid size={3} item xs={12} sm={6} md={3} key={index}>
                                <Card sx={{ p: 2, display: 'flex', justifyContent: 'space-evenly', flexDirection: 'row', alignItems: 'center', }}>
                                    <Box display={'flex'} justifyContent={"center"} sx={{ py: 2, px: 2, borderRadius: 3 }} className={card.color}>
                                        <img
                                            src={card.icon}
                                            style={{
                                                color: "red",
                                                width: 24,
                                                height: 24,
                                            }}
                                        />
                                    </Box>
                                    <Box>
                                        <Typography className="georama-SemiBold font-size-32">{card.value}</Typography>
                                        <Typography className='georama-Medium'>{card.title}</Typography>
                                    </Box>
                                </Card>
                            </Grid>
                        ))}
                    </Grid>

                    {/* Charts */}
                    <Grid container spacing={3} mt={2}>
                        <Grid sx={{ bgcolor: '#ffffff' }} item xs={12} md={4}>
                            <Typography variant="subtitle1" mb={1}>Pan-India Lead Status</Typography>
                            <Doughnut data={pieData} />
                        </Grid>

                        <Grid sx={{ bgcolor: '#ffffff' }} item xs={12} md={4}>
                            <Typography variant="subtitle1" mb={1}>Conversion Trend by Dealers</Typography>
                            <Line data={lineData} />
                        </Grid>

                        <Grid sx={{ bgcolor: '#ffffff' }} item xs={12} md={4}>
                            <Typography variant="subtitle1" mb={1}>Agents</Typography>
                            <Bar data={barData} />
                        </Grid>
                    </Grid>
                </Box>

                <TableContainer component={Box} sx={{ mt: 0 }}>
                    <Table>
                        <TableHead>
                            <TableRow >
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">Name</TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">Mobile No</TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">Role</TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">Dealer</TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">Location</TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">Reporting Manager</TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">Status</TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">Action</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody className="table-body-bg">
                            {users && users.length > 0 && users?.map((user, index) => (
                                <TableRow key={index}>
                                    <TableCell className="georama-Regular p-10" >
                                        <Typography>{user.name}</Typography>
                                        <Typography variant="caption">#{user.id}</Typography>
                                    </TableCell>
                                    <TableCell className="georama-Regular p-10" >
                                        {(() => {
                                            const [email, phone] = user.contactInfo?.split(' ') || [];
                                            return (
                                                <>
                                                    <Typography variant="">{phone}</Typography>
                                                    <br />
                                                    <Typography variant="">{email}</Typography>
                                                </>
                                            );
                                        })()}
                                    </TableCell>
                                    <TableCell className="georama-Regular p-10" >{user.role}</TableCell>
                                    <TableCell className="georama-Regular p-10" >{user.dealer}</TableCell>
                                    <TableCell className="georama-Regular p-10" >{user.location}</TableCell>
                                    <TableCell className="georama-Regular p-10" >{user.ReportingManager}</TableCell>
                                    <TableCell className="georama-Regular p-10" >
                                        <Chip
                                            label={user.status === "1" ? "Active" : "Inactive"}
                                            size="small"
                                            sx={{
                                                backgroundColor: user.status === "1" ? "#e0f7ea" : "#fdecea",
                                                color: user.status === "1" ? "#388e3c" : "#d32f2f",
                                                fontWeight: "bold",
                                            }}
                                        />
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Paper>
        </>
    );
};

export default Dashboard;
