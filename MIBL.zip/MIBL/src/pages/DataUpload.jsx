import { Box, Button, createTheme, LinearProgress, Grid, Divider, IconButton, Paper, ThemeProvider, Typography, FormControl, Select, MenuItem, Autocomplete, TextField } from "@mui/material";
import { btnRed, colorRed, secondaryGray, borderRed } from "../utils/Colors";
import { useEffect, useRef, useState } from "react";
import uploadIcon from '../assets/images/upload.svg';
import excelSheetimg from '../assets/images/excelSheetimg.svg';
import CloseIcon from '@mui/icons-material/Close';
import { dataUpload, downloadErrFile, downloadInvalidData, downloadTemplateExcel, fetchDealerNames, fetchLocation } from "../services/api";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useSelector } from "react-redux";
import BackdropLoader from "../components/Loader/BackdropLoader";
import DataUploadModal from "../modals/DataUploadModal";
import excelIcon from '../assets/images/excel.svg';
import useMediaQuery from '@mui/material/useMediaQuery';


const customTheme = createTheme({
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    variants: [
                        {
                            props: { variant: 'dashed', color: 'primary' },
                            style: ({ theme }) => ({
                                textTransform: 'none',
                                border: `2px dashed gray`,
                                color: 'gray',
                            }),
                        },
                    ],
                },
            },
        },
    },
});

const DataUpload = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const fileInputRef = useRef(null);
    const [dragOver, setDragOver] = useState(false);
    const [uploadedFile, setUploadedFile] = useState(null);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [fileSize, setFileSize] = useState(0);
    const [validateData, setValidateData] = useState(null);
    const [caseId, setCaseId] = useState(null);
    const [uploadedSize, setUploadedSize] = useState('');
    const [uploadType, setUploadType] = useState('');
    const [dealerNames, setDealerNames] = useState([]);
    const [locations, setLocations] = useState([]);
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);

    // useEffect(() => {
    //     if (clearBulkModalvalues) {

    //         setUploadedFile(null);
    //         setUploadProgress(0);
    //         setValidateData(null);
    //     }
    // }, [clearBulkModalvalues])

    const userData = useSelector((state) => state?.user?.loggedData);
    const [data, setData] = useState(useSelector((state) => state?.user?.loggedData));

    const handleFileUpload = (e) => {
        if (e.target.files.length) {
            setUploadedFile(e.target.files[0]);
        }
    };

    const fileMap = {
        policy: "policy.xlsx",
        claim: "claim.xlsx",
        service: "service.xlsx",
        sales: "sales.xlsx",
        addon: "addOn.xlsx"
    };

    // Determine the correct file to download
    const fileToDownload = uploadType ? fileMap[uploadType] : null;

    const onClose = () => setOpen(false);

    useEffect(() => {
        if (userData?.roleType === "MIBL") {
            fetchDealerNames().then(result => {
                if (result?.statusCode === '200') {
                    setDealerNames(result?.dealerAllDetails);
                }
            });
        }
    }, [userData?.roleType]);

    useEffect(() => {
        if (userData?.roleType === "MIBL" && data?.parentCode) {
            fetchLocation(dealerNames.find(dn => dn.parentCode === data?.parentCode)).then(result => {
                if (result?.statusCode === '200') setLocations(result?.dealerAllDetails);
            });
        }
    }, [data?.parentCode]);

    const clearValues = () => {
        setUploadedFile(null);
        setUploadProgress(0);
        setValidateData(null);
    }

    const isValidFile = (file) => {
        const validTypes = [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-excel',
            'text/csv',
        ];
        return validTypes.includes(file.type);
    };

    const formatFileSize = (bytes) => {
        if (bytes < 1024) {
            return `${bytes} B`;
        } else if (bytes < 1024 * 1024) {
            return `${(bytes / 1024).toFixed(1)} KB`;
        } else {
            return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
        }
    };

    const handleFile = (file) => {
        if (file && isValidFile(file)) {
            const sizeBytes = file.size;
            // if (sizeBytes > 15 * 1024 * 1024) {
            //     toast.error(`File size exceeds 15 MB. Please select a smaller file.`)
            //     return;
            // }
            const formattedSize = formatFileSize(sizeBytes);
            setUploadedFile(file);
            setFileSize(formattedSize);
            setUploadProgress(0);
            simulateUploadProgress(sizeBytes);
            setValidateData(null);
        }
    };

    const handleExcelUpload = (e, type) => {
        e.preventDefault();
        // if (uploadedFile) {// if file is already uploaded and user Uploads file again.
        //     toast.warning('Please remove Uploaded File before Uploading.');
        //     return;
        // }
        let file;
        if (type === 'drop') {
            file = e.dataTransfer.files[0];
        } else {
            file = e.target.files[0];
        }
        if (file.size > 15 * 1024 * 1024) {
            toast.error(`File size exceeds 15 MB. Please select a smaller file.`)
            return;
        }
        if (type !== 'drop') handleFile(file);
        if (!isValidFile(file)) {
            toast.error('Please upload a valid Excel or CSV file.');
            return;
        }
        setUploadedFile(file);
        const sizeBytes = file.size;
        setFileSize(formatFileSize(sizeBytes));
        setUploadProgress(0);
        simulateUploadProgress(sizeBytes);
        e.target.value = '';
    };


    const validateExcel = async () => {
        try {
            setLoading(true);
            const response = await dataUpload({ userId: data?.user_id, dealerId: data?.dealerCode, parentId: data?.parentCode, customtype: uploadType, flag: 'validate', file: uploadedFile });
            // const response = await dataUpload({ dealerId: 2, parentId: 'MAH001', customtype: uploadType, flag: 'validate', file: uploadedFile });
            if (response.statusCode === "200") {
                setValidateData(response);
            } else {
                console.warn(response);
                toast.error(response.statusMessage);
            }
        } catch (error) {
            console.error('Upload failed:', error);
            toast.error("Failed to Upload");
        } finally {
            setLoading(false);
        }
    }

    const saveExcel = async () => {
        let response;
        try {
            setLoading(true);
            response = await dataUpload({ userId: data?.user_id, dealerId: data?.dealerCode, parentId: data?.parentCode, customtype: uploadType, flag: 'upload', file: uploadedFile });
            // response = await dataUpload({ dealerId: 2, parentId: 'MAH001', customtype: uploadType, flag: 'upload', file: uploadedFile });
            setCaseId(response?.caseId || '');
            if (response.statusCode === "200") {
                toast.success(response.statusMessage);
                setUploadType('');
                handleCancelUpload();
                setData(userData);
            } else {
                console.warn(response);
                setValidateData(response);
                setOpen(true);
                // toast.error(response.statusMessage);
            }
        } catch (error) {
            console.error('Upload failed:', error);
            toast.error("Failed to Upload");
        } finally {
            setLoading(false);
        }
    }

    const downloadErrorRecord = async () => {
        try {
            setLoading(true);
            const response = await dataUpload({ userId: data?.user_id, dealerId: data?.dealerCode, parentId: data?.parentCode, customtype: uploadType, flag: 'download', missingColumns: validateData.missingColumns });
            // const response = await dataUpload({ dealerId: 2, parentId: 'MAH001', customtype: uploadType, flag: 'download', missingColumns: validateData.missingColumns });
            if (response && response.data) {
                // Create a download link
                const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', 'DataUpload_Error_Report.xlsx'); // Set your file name
                document.body.appendChild(link);
                link.click();
                link.remove();
                window.URL.revokeObjectURL(url);
            }
            // setValidateData(response)
        } catch (error) {
            console.error('Upload failed:', error);
        } finally {
            setLoading(false);
        }
    }

    const downloadErrorFile = async () => {
        try {
            setLoading(true);
            const response = await downloadErrFile({
                caseId: caseId || "", type: userData?.roleType, userId: data?.user_id, dealerId: data?.dealerCode, parentId: data?.parentCode, customtype: uploadType,
                //  flag: 'downloadInvalidRows', 
                invalidRows: validateData?.invalidRows
            });
            if (response && response.data) {
                // Create a download link
                const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', uploadType + '_Error_Records.xlsx'); // Set your file name
                document.body.appendChild(link);
                link.click();
                link.remove();
                window.URL.revokeObjectURL(url);
            }
            // setValidateData(response)
        } catch (error) {
            console.error('Upload failed:', error);
        } finally {
            setLoading(false);
        }
    }

    const handleContinue = () => {
        if (!uploadedFile) return;
        validateExcel();
    }

    const uploadValidatedExcel = () => {
        if (!uploadedFile) return;
        saveExcel();
    }

    const handleDrop = (e) => {
        e.preventDefault();
        // if (uploadedFile) {// if file is already uploaded and user Uploads file again.
        //     toast.warning('Please remove Uploaded File before Uploading.');
        //     setDragOver(false);
        //     return;
        // }
        const file = e.dataTransfer.files[0];
        if (file.size > 15 * 1024 * 1024) {
            toast.error(`File size exceeds 15 MB. Please select a smaller file.`)
            setDragOver(false);
            return;
        }
        handleExcelUpload(e, 'drop');
        setDragOver(false);
        handleFile(file);
    };

    const simulateUploadProgress = (totalBytes) => {
        let uploaded = 0;
        const interval = setInterval(() => {
            uploaded += 3000000; // 30KB chunks
            const progress = Math.min(uploaded / totalBytes, 1) * 100;
            setUploadProgress(progress);
            const currentFormatted = formatFileSize(Math.min(uploaded, totalBytes));
            const totalFormatted = formatFileSize(totalBytes);
            setUploadedSize(`${currentFormatted} of ${totalFormatted}`);
            if (uploaded >= totalBytes) clearInterval(interval);
        }, 100);
    };


    const getExtensionFromContentType = (contentType) => {
        switch (contentType) {
            case 'text/csv':
                return 'csv';
            case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
                return 'xlsx';
            case 'application/vms-excel':
                return 'xls';
        }
    };


    const downloadExcel = async () => {
        if (uploadType) {

        }

    };

    // const downloadExcel = async () => {
    //     try {
    //         const response = await downloadTemplateExcel(
    //             {
    //                 parentId: data?.parentCode,
    //                 dealerId: data?.dealerCode,
    //                 customtype: uploadType,
    //                 mapping_dealer_code: data?.dealerCode
    //             });

    //         if (response?.data?.message === "No file found.") {
    //             toast.error("No Sample File Found");
    //             return;
    //         } else if (response && response.data) {
    //             const contentType = response.headers['content-type'];
    //             const extension = getExtensionFromContentType(contentType);
    //             const filename = `${data}_Template.${extension}`;

    //             const blob = new Blob([response.data], { type: contentType });
    //             const url = window.URL.createObjectURL(blob);
    //             const link = document.createElement('a');
    //             link.href = url;
    //             link.setAttribute('download', filename);
    //             document.body.appendChild(link);
    //             link.click();
    //             document.body.removeChild(link);
    //             window.URL.revokeObjectURL(url);
    //         }
    //     } catch (error) {
    //         console.error('Download failed:', error);

    //         if (error?.error === "No File Found") {
    //             toast.warning("No File Found");
    //         } else {
    //             toast.error("Something went wrong while downloading file");
    //         }
    //     }
    // };


    const handleFileClick = () => {
        fileInputRef.current.click();
    };

    const handleCancelUpload = () => {
        setValidateData(null);
        setUploadedFile(null);
        setUploadProgress(0);
    };

    return (
        <Paper elevation={0} sx={{ width: 'inherit', m: isMobile ? 1.5 : 2, borderRadius: 2 }}>
            <BackdropLoader loading={loading} />
            <Box display="flex" justifyContent="space-between" alignItems="center" px={isMobile ? 1.5 : 2.5} py={2}>
                <Typography className={`${isMobile ? 'fs-18' : 'fs-24'} georama-SemiBold`}>Data Upload</Typography>
                {/* <Typography className="georama-SemiBold fs-24">Data Upload</Typography> */}
            </Box>
            <Divider sx={{ mb: 2 }} />
            <Grid container spacing={2} mb={1.5} px={isMobile ? 1.5 : 2.5}>
                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                    <Typography className="georama-Medium fs-14" mb={0.5}>
                        Upload File Selector <span style={colorRed}>*</span>
                    </Typography>
                    <FormControl
                        className="form-control-input border-radius-8"
                        fullWidth required size="small">
                        <Select size="small"
                            value={uploadType}
                            displayEmpty
                            onChange={(e) => { setUploadType(e.target.value); handleCancelUpload(); setData(userData); }}
                        >
                            <MenuItem value="" disabled>Select</MenuItem>
                            <MenuItem value="policy">Policy</MenuItem>
                            <MenuItem value="claim">Claim</MenuItem>
                            <MenuItem value="service">Service</MenuItem>
                            <MenuItem value="sales">Sales Data</MenuItem>
                            <MenuItem value="addon">Add On</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                {userData?.roleType === "MIBL" &&
                    <>
                        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                            <Typography className="text-labels georama-Medium fs-14" mb={0.5}>
                                Select Dealer <span className="important-fields">*</span>
                            </Typography>
                            <FormControl
                                className="form-control-input border-radius-8"
                                fullWidth required size="small">
                                <Autocomplete
                                    size="small"
                                    options={dealerNames}
                                    getOptionLabel={(option) => option.dealerName || ''}
                                    value={dealerNames.find(dn => dn.parentCode === data?.parentCode) || null}
                                    onChange={(event, newValue) => {
                                        setData((prev) => ({
                                            ...prev,
                                            parentCode: newValue?.parentCode || '',
                                            dealerCode: '',
                                        }));
                                        handleCancelUpload();
                                    }}
                                    renderInput={(params) => (
                                        <TextField {...params} placeholder="Select" />
                                    )}
                                    isOptionEqualToValue={(option, value) => option.parentCode === value.parentCode}
                                    ListboxProps={{
                                        className: "small-scrollbar"
                                    }}
                                />
                            </FormControl>
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                            <Typography className="georama-Medium fs-14" mb={0.5}>
                                Select Location <span className="important-fields">*</span>
                            </Typography>
                            <FormControl
                                className="form-control-input border-radius-8"
                                fullWidth required size="small">
                                <Autocomplete
                                    size="small"
                                    options={locations}
                                    getOptionLabel={(option) => option.dealerLocName || ''}
                                    value={locations.find(loc => loc.dealerId === data?.dealerCode) || null}
                                    onChange={(event, newValue) => {
                                        setData((prev) => ({
                                            ...prev,
                                            dealerCode: newValue?.dealerId || '',
                                        }));
                                        handleCancelUpload();
                                    }}
                                    renderInput={(params) => (
                                        <TextField {...params} placeholder="Select" />
                                    )}
                                    isOptionEqualToValue={(option, value) => option.dealerId === value.dealerId}
                                />
                            </FormControl>
                        </Grid>
                    </>
                }
                {uploadType &&
                    <Grid size={{ xs: 12, sm: 6, md: 3 }} sx={{ display: "flex", alignItems: "flex-end", justifyContent: "flex-start" }}>
                        {/* <Button variant="outlined" onClick={() => downloadExcel()}
                                sx={{ ml: 1, borderColor: borderRed, textTransform: 'capitalize' }}>
                                <img src={excelIcon} alt="upload" />
                                Sample Data
                            </Button> */}
                        <Button
                            variant="outlined"
                            component="a"
                            href={fileToDownload ? `/public/${fileToDownload}` : undefined}
                            download
                            disabled={!fileToDownload}
                            sx={{ ml: 1, borderColor: borderRed, textTransform: 'capitalize' }}
                        >
                            <img src={excelIcon} alt="Excel" width={18} />
                            Sample Data
                        </Button>
                    </Grid>}

                {/* {data?.dealerCode && data?.parentCode && uploadType &&
                        < Grid size={3} item xs={12} md={6} sx={{ display: "flex", alignItems: "flex-end", justifyContent: "flex-start" }}>
                            <Button variant="outlined" onClick={() => downloadExcel()}
                                sx={{ ml: 1, borderColor: borderRed, textTransform: 'capitalize' }}>
                                <img src={excelIcon} alt="upload" />
                                Sample Data
                            </Button>
                        </Grid>
                    } */}
            </Grid>

            {
                uploadType && data?.dealerCode && data?.parentCode && <>
                    <ThemeProvider theme={customTheme}>
                        <Grid container spacing={isMobile ? 1 : 4} sx={{ mx: 2 }} alignItems={'center'}>
                            <Grid size={{ xs: 12, sm: 12, md: 5, lg: 5 }} sx={{ mt: 1.5 }}>
                                <Typography className="georama-Medium fs-14">Upload Data</Typography>
                                <input type="file" accept=".csv,.xls,.xlsx" ref={fileInputRef} onChange={handleExcelUpload} style={{ display: 'none' }} />
                                <Box>
                                    <Button
                                        sx={{
                                            border: '2px dashed #ccc',
                                            borderColor: dragOver ? 'primary.main' : '#ccc',
                                            borderRadius: 2,
                                            px: "auto",
                                            py: isMobile ? 1 : 2.5,
                                            cursor: 'pointer',
                                            width: '100%',
                                            textAlign: 'center',
                                            transition: '0.2s ease',
                                        }}
                                        component="span"
                                        variant="dashed"
                                        color="primary"
                                        accept=".csv,.xlsx,.xls"
                                        onClick={handleFileClick}
                                        onDrop={handleDrop}
                                        onDragOver={(e) => {
                                            e.preventDefault();
                                            setDragOver(true);
                                        }}
                                        onDragLeave={() => setDragOver(false)}
                                    >
                                        <Box display={isMobile ? "block" : "flex"}>
                                            <Box display={"flex"} alignItems="center" justifyContent="start">
                                                <img src={uploadIcon} alt="upload" className="mr-8" />
                                                <span className="georama-Medium fs-14">Drag and Drop or{' '}</span>
                                            </Box>
                                            <Box display={"flex"} mx={isMobile ? 3 : 1} alignItems="center" justifyContent="start">
                                                <span className="upload-img">
                                                    Click to Upload
                                                </span>
                                            </Box>
                                        </Box>
                                    </Button>
                                    <Typography variant="caption" className="fs-10" display="block" sx={{ float: 'right', mt: 0.2, ml: 3 }}>
                                        Excel/CSV accepted
                                    </Typography>
                                    <Typography variant="caption" className="fs-10" display="block" sx={{ mt: 0.2 }}>
                                        Please upload a file that is 15 MB or smaller
                                    </Typography>
                                </Box>
                            </Grid>
                            {uploadedFile && (
                                <>
                                    <Grid size={{ xs: 12, sm: 12, md: 8, lg: 4 }} sx={{ mt: isMobile ? 2 : 0 }}>
                                        <Typography className="georama-Medium fs-14" >
                                            Uploaded file
                                        </Typography>
                                        <Box
                                            sx={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                justifyItems: 'center',
                                                border: '1px solid #ccc',
                                                borderRadius: 2,
                                                py: 0.7,
                                                px: 1,
                                                mb: 1,
                                                position: 'relative',
                                            }}
                                        >
                                            <img
                                                src={excelSheetimg}
                                                alt="excel"
                                                style={{ width: 32, marginRight: 12 }}
                                            />
                                            <Box sx={{ flexGrow: 1 }}>
                                                <Typography variant="body2">{uploadedFile.name}</Typography>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={uploadProgress}
                                                    sx={{ height: 3, borderRadius: 1, mt: 0.5, color: 'gray', bgcolor: 'gray' }}
                                                />
                                                <Typography variant="caption" sx={{ mt: 0.5, display: 'block' }}>
                                                    {uploadedSize}
                                                    {/* {(fileSize * (uploadProgress / 100)).toFixed(1)} MB of {fileSize} MB */}
                                                </Typography>
                                            </Box>
                                            <IconButton
                                                onClick={handleCancelUpload}
                                                sx={{ position: 'absolute', top: 4, right: 4 }}
                                            >
                                                <CloseIcon fontSize="small" />
                                            </IconButton>
                                        </Box>
                                    </Grid>
                                    {!validateData &&
                                        <Grid size={{ xs: 12, sm: 12, md: 2, lg: 2 }} sx={{ mt: isMobile ? 1 : 3, mb: isMobile ? 2 : 0 }} alignItems={'center'}>
                                            <Button className="btn-common-red" onClick={handleContinue} sx={btnRed} variant="outlined">
                                                Validate
                                            </Button>
                                        </Grid>
                                    }
                                </>
                            )}
                        </Grid>
                    </ThemeProvider>
                    {
                        validateData && validateData != null &&
                        <Typography className='validation-msg georama-Regular fs-14' pl={3}>
                            {/* Header Columns Validated Successfully */}
                            Header Columns Validated with Success count{' '}
                            <span className='success-count'>{validateData.validColumns}</span> and Failure count{' '}
                            <span className='failure-count'>{validateData.invalidColumns}</span>
                        </Typography>
                    }

                    <Box
                        sx={{
                            display: 'flex',
                            justifyContent: 'right',
                            alignItems: 'center',
                            mt: isMobile ? 1 : 3,
                            px: 3,
                            py: 2,
                            borderTop: "1px solid rgb(238, 224, 224)"
                        }}
                    >
                        {validateData && validateData.invalidColumns > 0 &&
                            <Button
                                size="small"
                                variant="outlined"
                                disabled={!validateData}
                                sx={{
                                    borderRadius: 2,
                                    py: 0.8,
                                    textTransform: 'none',
                                    borderColor: '#ccc',
                                    color: '#fff',
                                    ...secondaryGray,
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 1,
                                }}
                                onClick={downloadErrorRecord}
                            >
                                <Typography className="bulk-assign-head ">Download Error Record</Typography>
                            </Button>}

                        <Button
                            className="btn-common-red"
                            variant="contained"
                            disabled={!validateData || validateData?.invalidColumns}
                            sx={{
                                backgroundColor: '#e53935',
                                px: 3,
                                pt: 1,
                                ml: 2,
                                borderRadius: 3,
                                textTransform: 'none',
                                '&:hover': {
                                    backgroundColor: '#d32f2f',
                                },
                            }}
                            onClick={uploadValidatedExcel}
                        >
                            Submit
                        </Button>
                    </Box>
                </>
            }
            <DataUploadModal open={open} onClose={onClose} validateData={validateData} downloadErrorFile={downloadErrorFile} />
            <ToastContainer autoClose={1000} />
        </Paper >
    )
}

export default DataUpload;