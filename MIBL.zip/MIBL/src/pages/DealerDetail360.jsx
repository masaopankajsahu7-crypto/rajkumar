import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import MarkunreadIcon from '@mui/icons-material/Markunread';
import PhoneIcon from '@mui/icons-material/Phone';
import { Box, Chip, FormControl, IconButton, MenuItem, Paper, Select, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, ToggleButton, ToggleButtonGroup, Tooltip, Typography, useMediaQuery } from '@mui/material';
import { useEffect, useState } from 'react';
import { InfoDisplay } from '../components/DealerInfo';
import { InfoCard } from '../components/DealerOverview';
import { cursorpointer, secondaryGray, tabselectedColor } from '../utils/Colors';
// import { Dealer_Overview_Data } from '../components/DealerOverviewCard';
import { ChevronRight, InfoOutline } from '@mui/icons-material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import { format, parseISO } from 'date-fns';
import { useRef } from "react";
import { useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import addonpremium from '../assets/images/customer/addonpremium.svg';
import chassisno from '../assets/images/customer/chassisno.svg';
import dateInvoice from '../assets/images/customer/dateInvoice.svg';
import dateregistration from '../assets/images/customer/dateregistration.svg';
import engineno from '../assets/images/customer/engine-no.svg';
import fueltype from '../assets/images/customer/fueltype.svg';
import make from '../assets/images/customer/make.svg';
import model from '../assets/images/customer/model.svg';
import ncbpercentage from '../assets/images/customer/ncbpercentage.svg';
import oddates from '../assets/images/customer/oddates.svg';
import oddiscount from '../assets/images/customer/oddiscount.svg';
import plantype from '../assets/images/customer/plantype.svg';
import premium from '../assets/images/customer/premium.svg';
import registrationno from '../assets/images/customer/registrationno.svg';
import renewallink from '../assets/images/customer/renewallink.svg';
import totalod from '../assets/images/customer/totalod.svg';
import totaltp from '../assets/images/customer/totaltp.svg';
import variant from '../assets/images/customer/variant.svg';
import vehicleclass from '../assets/images/customer/vehicle-class.svg';
import viewaddon from '../assets/images/customer/viewaddon.svg';
import group from '../assets/images/group.svg';
import AddOnDrawer from '../components/Drawers/AddOnDrawer';
import BackdropLoader from '../components/Loader/BackdropLoader';
import SideFloatingButtons from '../components/SideFloatingButtons';
import Inputmodal from '../modals/InputModal';
import { addCustomerContactDetails, fetchVehicleDetails, getCustomerDetails, getHistory } from '../services/api';
import { transformDate } from '../services/transformDate';
import { useAuth } from '../services/useAuth';

const CustomerDetailsPage = () => {
    const scrollRef = useRef(null);

    const scroll = (direction) => {
        if (!scrollRef.current) return;

        const scrollAmount = 200; // adjust based on UI
        scrollRef.current.scrollBy({
            left: direction === "left" ? -scrollAmount : scrollAmount,
            behavior: "smooth"
        });
    };

    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const location = useLocation();
    const navigate = useNavigate();
    const customerInfo = location.state?.row || {};
    const CallQueuetype = location.state?.callType || {};

    const { user_id, roleId, dealerCode } = useAuth().user;
    const [type, setType] = useState('policy');
    const [field, setField] = useState();
    const [openDrawer, setOpenDrawer] = useState(false);
    const [addonData, setAddonData] = useState(null);
    const ebmColorList = useSelector(state => state.callQueue).ebmColorList;
    const [communicationData, setCommunication] = useState(null);

    const handleOpenDrawer = (data) => {
        setOpenDrawer(true);
    };

    const handleCloseDrawer = () => {
        setOpenDrawer(false);
    };

    const [openDialog, setOpenDialog] = useState(false);
    const [phones, setPhones] = useState(['']);
    const [emails, setEmails] = useState(['']);
    const [selectedPhone, setSelectedPhone] = useState(phones[0]);
    const [selectedEmail, setSelectedEmail] = useState(emails[0]);
    const [rows, setRows] = useState({});
    const [response, setResponse] = useState({});
    const [loading, setLoading] = useState(false);

    const [vehicles, setVehicles] = useState([]);

    const [vehicle, setVehicle] = useState();
    // console.log("Vehicle=====", vehicle);
    const [addOnVehData, setAddOnVehicleData] = useState([]);

    const handleAddNewInput = () => {
        setOpenDialog(true);
    };
    const handleDialogClose = () => {
        setOpenDialog(false);
    };

    const handleAddFieldFromModal = async (newInput, field) => {
        if (response.overview.filter(c => c.customer_phone === newInput).length === 0
            && response.overview.filter(c => c.customer_email === newInput).length === 0) {
            let result = await addCustomerContactDetails({
                type: field === 'Mobile No.' ? 'mobile' : 'email', clusterId: customerInfo.clusterId, userId: user_id, dealerCode,
                vehicleName: customerInfo.vehicleName, mobile: field === 'Mobile No.' ? newInput : '', email: field === 'Email Id' ? newInput : ''
            });
            if (result.status_code === '200') {
                if (field === 'Mobile No.') {
                    setPhones((prev) => [...prev, newInput]);
                    setSelectedPhone(newInput);
                }
                if (field === 'Email Id') {
                    setEmails((prev) => [...prev, newInput]);
                    setSelectedEmail(newInput);
                }
                toast.success(`${field} added Successfully!`);
            }
            else toast.error(`Failed to Add ${field}`);
        } else {
            field === 'Mobile No.' ? setSelectedPhone(newInput) : setSelectedEmail(newInput);
            toast.error(`${field} Already Exists.`)
        }
    };

    const handleChangeVehicle = (event, newValue) => {
        // console.log("Selected Vehicle=====", newValue);
        if (!newValue) return;

        setVehicle(newValue);

        // const selected = vehicles.find(v => v.model === newVehicle);
        const selectedVehicle = vehicles.find((v) => v.chassisNo === newValue);
        if (selectedVehicle) {
            setTimeout(() => {
                fetchPage(true, selectedVehicle);
            }, 500);
        }
    };

    const fields = [
        { label: "Policy Details", type: "policy" },
        { label: "Service History", type: "service" },
        { label: "Claim History", type: "claim" },
        { label: "Sales History", type: "sales" },
        { label: "Reminder Renewal", type: "reminder" },
        { label: "MIBL Call Centre Cases Remarks", type: "remarks", showFor: "mibl" },
        { label: "Endorsement", type: "endorsement" }
    ].filter(f => !f.showFor || f.showFor === CallQueuetype);

    const columns = {
        "policy": {
            "Insurance Company": "insurance_company",
            "Policy No": "policy_no",
            "Tenure": "policy_tenure",
            "Type": "policy_type",
            "Effective Date": "policy_effective_date",
            "Expiry Date": "policy_expiry_date",
            "Plan Type": "plan_type",
            "YOM": "yom"
        },
        "service": {
            "Service Type": "service_type",
            "Repair Order No": "repair_order_no",
            "Service Category": "service_category",
            "RO Date": "ro_date",
            "Customer Mobile No.": "customer_mobile_no",
            "Service Advisor": "service_advisor"
        },
        "claim": {
            "Policy No": "policy_no",
            "Claim No": "claim_no",
            "Claim Intimation Date and Time": "claim_intimation_date_time",
            "Nature of Loss": "nature_of_loss",
            "Insurance Claim No": "insurance_claim_no",
            "Accident City": "accident_city",
            "Claim Status": "claim_status"
        },
        "sales": {
            "Invoice Number": "invoice_number",
            "Invoice Date and Time": "invoice_date_time",
            "Dealer Parent Code": "dealer_parent_code",
            "Dealer Parent Name": "dealer_parent_name",
            "Dealer Location Code": "dealer_location_code",
        },
        "reminder": {
            // "Policy ID": "policy_id",
            "Mode": "mode",
            "Reminder Frequency": "reminder_frequency",
            "Sent Date": "sent_date",
            // "Renewal Link": "renewal_link",
        },
        "endorsement": {
            "Endorsement Request Date": "endo_created_date",
            "Endorsement No": "endorsement_no",
            "Endorsement Type": "endorsement_type_description",
            "Effective Period of Endorsement": "approval_date",
            "Endorsement Premium": "total_prem_payable"
        }
    };

    const [customerDetails, setCustomerDetails] = useState({});
    // console.log("customerDetails", customerDetails)

    const fetchVehicles = async () => {
        // console.log("customerInfo.vehicleName", customerInfo)
        try {
            const response = await fetchVehicleDetails({
                clusterId: customerInfo.clusterId,
                vehicleName: customerInfo.vehicleName,
                leadId: customerInfo.leadId,
                type: "fetchVehicleDetails"
            });

            const vehicleList = response?.vehicleDetails || [];

            setVehicles(vehicleList);

            if (!vehicleList.length) return;

            // ✅ define selected properly
            const selected =
                vehicleList.find(v => v.chassisNo === customerInfo.chassisNo) ||
                vehicleList[0];

            // console.log("Selected Vehicle=====", selected);

            // ✅ set selected in UI
            setVehicle(selected.chassisNo);

            // ✅ call next API
            fetchPage(true, selected);

        } catch (error) {
            console.error(error);
        }
    };

    const fetchPage = async (refresh = true, selectedVehicle = null) => {
        try {
            const vehicleData = selectedVehicle || {};
            setAddOnVehicleData(vehicleData)

            let result = await getCustomerDetails({
                leadId: vehicleData.leadId,
                clusterId: customerInfo.clusterId,
                vehicleName: vehicleData.model || customerInfo.vehicleName,
                type: "init",
                chassisNo: vehicleData.chassisNo || customerInfo?.chassisNo,
            });

            setResponse(result);

            if (refresh) {
                setVehicle(vehicleData.chassisNo || customerInfo.vehicleName);
                setCustomerDetails(result?.overview?.find(o => o.lead_id === vehicleData.leadId));
                setPhones(result?.contactDetails.filter(c => c.customer_phone).map(c => c.customer_phone));
                setEmails(result?.contactDetails.filter(c => c.customer_email).map(c => c.customer_email));
                setSelectedPhone(vehicleData.customer_phone);
                setSelectedEmail(vehicleData.customer_email);
                setRows({ policy: result?.policyHistory });

                // setVehicles(
                //     result?.vehicleDetails.map((v) => ({
                //         model: v.model,
                //         expiry_days: v.expiry_days
                //     }))
                // );
            }
            setTimeout(() => {
                loadAllTabsData(vehicleData);
            }, 0);
        } catch (error) {
            console.error(error);
        }
    };

    // const fetchPage = async (refresh = true) => {
    //     try {
    //         let result = await getCustomerDetails({
    //             leadId: customerInfo.leadId,
    //             clusterId: customerInfo.clusterId,
    //             vehicleName: customerInfo.vehicleName,
    //             type: "init",
    //             chassisNo: customerInfo?.chassisNo,
    //         })
    //         setResponse(result);
    //         if (refresh) {
    //             setVehicle(customerInfo.vehicleName);
    //             setCustomerDetails(result?.overview?.find(o => o.lead_id === customerInfo.leadId));
    //             setPhones(result?.contactDetails.filter(c => c.customer_phone).map(c => c.customer_phone));
    //             setEmails(result?.contactDetails.filter(c => c.customer_email).map(c => c.customer_email));
    //             setSelectedPhone(result?.overview?.filter(c => c.customer_phone).at(-1).customer_phone);
    //             setSelectedEmail(result?.overview.filter(c => c.customer_email).at(-1).customer_email);
    //             setRows({ policy: result?.policyHistory });
    //             setVehicles(result?.vehicleDetails.map((v) => ({ model: v.model, expiry_days: v.expiry_days })));
    //             handleChangeVehicle(null, customerInfo.vehicleName);
    //         }
    //     } catch (error) {
    //         console.error(error);
    //     }
    // }

    const fetchAddon = (policyno = "") => {
        fetchData("addon", policyno, addOnVehData);
    }

    const fetchData = async (type, policyno = "", vehicleData = null) => {
        try {
            setLoading(true);
            let response = await getHistory({
                leadId: vehicleData ? vehicleData.leadId : customerInfo.leadId,
                chassisNo: vehicleData ? vehicleData.chassisNo : customerInfo?.chassisNo,
                clusterId: customerInfo.clusterId,
                vehicleName: vehicleData ? vehicleData.model : customerInfo?.vehicleName,
                type: type,
                policyno: policyno ? policyno : customerDetails?.policy_no,
                vehicleRegNo: customerInfo?.vehicleRegNo
            });
            if (response.addon && response.addon.length > 0) {
                setAddonData(response?.addon);
            }
            if (response.communication && response.communication.length > 0) {
                setCommunication(response)
            }
            return { type, data: response[type] || [] };
            // return response;
        } catch (error) {
            console.error(error);
            return { type, data: [] };
        } finally {
            setLoading(false);
        }
    }

    const Dealer_Overview_Data = [
        [
            { icon: <img src={make} alt="Make" />, label: 'Make', value: customerDetails?.make },
            { icon: <img src={model} alt="Model" />, label: 'Model', value: customerDetails?.model },
            { icon: <img src={variant} alt="Variant" />, label: 'Variant', value: customerDetails?.variant },
            { icon: <img src={fueltype} alt="Fuel Type" />, label: 'Fuel Type', value: customerDetails?.fuel_type },
            { icon: <img src={vehicleclass} alt="Vehicle Class" />, label: 'Vehicle Class', value: customerDetails?.vehicle_class },
        ],
        [
            { icon: <img src={registrationno} alt="Registration No" />, label: 'Registration no', value: customerDetails?.vehicle_reg_no },
            { icon: <img src={engineno} alt="Engine No" />, label: 'Engine No', value: customerDetails?.engine_no },
            { icon: <img src={chassisno} alt="Chassis No" />, label: 'Chassis No', value: customerDetails?.chassis_no },
            {
                icon: <img src={dateregistration} alt="Date of Registration" />, label: 'Date of Registration',
                value: `${customerDetails && customerDetails?.registration_date ? customerDetails?.registration_date : ''}`
                // value: `${customerDetails && customerDetails?.registration_date ? format(parseISO(customerDetails?.registration_date), 'dd-MM-yyyy') : ''}`
            },
            {
                icon: <img src={dateInvoice} alt="Date of Invoice" />, label: 'Date of Invoice',
                value: `${customerDetails && customerDetails?.invoice_date ? customerDetails?.invoice_date : ''}`
            },
            {
                icon: <img src={dateInvoice} alt="Total IDV" />, label: 'Total IDV', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.total_idv ?? 0)}`
            },
            // { icon: <img src={claimhistory} alt="Claim History" />, label: 'Claim History', value: `${customerDetails?.claim_history}` },
        ],
        [
            { icon: <img src={plantype} alt="Plan Type" />, label: 'Plan Type', value: customerDetails?.plan_type },
            {
                icon: <img src={oddates} alt="OD Dates" />, label: 'OD Dates', value: customerDetails?.odDates
                // customerDetails?.odDates?.split(' | ')?.map(d => format(parseISO(d), 'dd-MMM-yyyy')).join(' | ')}`
            },
            {
                icon: <img src={oddates} alt="TP Date" />, label: 'TP Date', value: customerDetails?.tpDates
                // customerDetails?.tpDates?.split(' | ')?.map(d => format(parseISO(d), 'dd-MMM-yyyy')).join(' | ')}`
            },
            {
                icon: <img src={renewallink} alt="Renewal Link" />, label: 'Renewal Link',
                value: <Box component="a" href={customerDetails?.renewal_Link} target='_blank' display={"flex"} alignItems={"center"}
                    sx={customerDetails?.renewal_Link ? { ...tabselectedColor, ...cursorpointer } : { ...cursorpointer }}>Renewal<ChevronRight /></Box>
            },
            {
                icon: <img src={viewaddon} alt="View Addon" />, label: 'View Addon',
                value: <Box display={"flex"} alignItems={"center"}
                    sx={addonData?.length > 0 ? { ...tabselectedColor, ...cursorpointer } : { ...cursorpointer }}
                    // sx={{ ...tabselectedColor, ...cursorpointer }}
                    onClick={addonData?.length > 0 ? () => {
                        handleOpenDrawer(); fetchAddon(customerDetails?.policy_no);
                    } : null}>View<ChevronRight /></Box>
                // onClick={handleOpenDrawer}>View<ChevronRight /></Box>
            },
            {
                icon: <img src={viewaddon} alt="Combi Products" />, label: 'Combi Products',
                value: customerDetails?.group_product
                // value: <Box display={"flex"} justifyItems={"center"} sx={{ ...tabselectedColor, ...cursorpointer }}>View<ChevronRight /></Box>
            },
        ],
        [
            { icon: <img src={ncbpercentage} alt="NCB Percentage" />, label: 'NCB Percentage', value: `${customerDetails?.ncb_percentage || "0"}` },
            { icon: <img src={oddiscount} alt="OD Discount %" />, label: 'OD Discount %', value: `${customerDetails?.od_discount || 0}%` },
            {
                icon: <img src={totalod} alt="Total OD" />, label: 'Total OD', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.totalod ?? 0)}`
            },
            {
                icon: <img src={totaltp} alt="Total TP" />, label: 'Total TP', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.totaltp ?? 0)}`
            },
            {
                icon: <img src={addonpremium} alt="Addon Premium" />, label: 'Addon Premium', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.addon_premium_amount ?? 0)}`
            },
            {
                icon: <img src={premium} alt="Premium" />, label: 'Premium', value: `${new Intl.NumberFormat('en-IN', {
                    maximumFractionDigits: 2,
                }).format(customerDetails?.net_premium ?? 0)}`
            },
        ]
    ];

    const loadAllTabsData = async (vehicleData) => {
        setLoading(true);
        try {
            const results = await Promise.all(fields.map(f => fetchData(f.type, "", vehicleData)));

            const rowsData = results.reduce((acc, { type, data }) => {
                acc[type] = data;
                return acc;
            }, {});
            setRows(rowsData);
        } catch (err) {
            console.error("Error fetching tab data:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchVehicles();
        // loadAllTabsData();
        // setFieldsData();
    }, []);

    useEffect(() => {
        fetchData("addon", "", addOnVehData);
    }, [customerDetails]);

    // const setFieldsData = async () => {
    //     for (const f of fields) {
    //         if (!rows[f.type]) {
    //             let typeRows = await fetchData(f.type);
    //             setRows(prev => ({
    //                 ...prev,
    //                 [f.type]: typeRows[f.type],
    //             }));
    //         }
    //     }
    // };

    const handleTypeChange = async (e, v) => {
        setType(v);
        if (!rows[v]) {
            let typeRows = await fetchData(v, "", "");
            setRows(prev => ({
                ...prev,
                [v]: typeRows[v],
            }));
        }
    };

    // const handleTypeChange = async (e, v) => {
    //     if (!v) return;
    //     setType(v);

    //     // fetch only if not already loaded
    //     if (!rows[v]) {
    //         setLoading(true);
    //         try {
    //             const { data } = await fetchData(v);
    //             setRows((prev) => ({
    //                 ...prev,
    //                 [v]: data,
    //             }));
    //         } finally {
    //             setLoading(false);
    //         }
    //     }
    // };

    // useEffect(() => {
    //     fetchPage();
    //     setFieldsData();
    //     fetchData("addon");
    // }, []);

    // const setFieldsData = () => {
    //     fields.forEach(async f => {
    //         if (!rows[f.type]) {
    //             let typeRows = await fetchData(f.type);
    //             setRows(prev => ({
    //                 ...prev,
    //                 [f.type]: typeRows[f.type],
    //             }));
    //         }
    //     });
    // };

    return (
        <>
            <BackdropLoader loading={loading} />
            <Stack width={'inherit'} className='body-formbg'>
                {/* ------------------ Header Section ----------------- */}
                <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap"
                    sx={{ backgroundColor: "white", px: 3, py: 1, borderTop: "1px solid rgb(222, 216, 216)" }
                    }>
                    <Box display="flex" alignItems="flex-start">
                        <ArrowBackIcon onClick={() => navigate(-1)} sx={{
                            ...cursorpointer, mr: 1, padding: '4px',
                        }} />
                        <Box p={0}>
                            <Typography variant="h6" className='georama-SemiBold' p={0}><b>{customerInfo.customerName}</b></Typography>
                            <Typography variant='caption' p={0}>{response?.policyDetails?.[0]?.customer_city} | {response?.policyDetails?.[0]?.customer_pincode}</Typography>
                        </Box>
                        {customerInfo?.leadType && <Chip size="small" label={`${customerInfo.leadType} Lead`}
                            color="error"
                            sx={{
                                backgroundColor:
                                    customerInfo.leadType?.toLowerCase() === "hot"
                                        ? "#e53935"
                                        : customerInfo.leadType?.toLowerCase() === "warm"
                                            ? "#f07d2d"
                                            : customerInfo.leadType?.toLowerCase() === "cold"
                                                ? "#1e88e5"
                                                : "#9e9e9e",
                                // ...bgRed500,
                                ml: 3, mt: 0.5, p: 0, fontSize: "10px"
                            }} />}
                    </Box>

                    <Box display="flex" flexWrap={"wrap"} alignItems="center" gap={1}>
                        <FormControl size="small">
                            <Box
                                display="flex"
                                alignItems="center"
                                sx={{
                                    backgroundColor: '#e53935',
                                    color: 'white',
                                    borderRadius: 7,
                                    border: 'none',
                                    outline: 'none',
                                }}
                            >
                                <PhoneIcon
                                    sx={{
                                        width: isMobile ? '12px' : '16px',
                                        height: isMobile ? '12px' : '16px',
                                        ml: isMobile ? 1 : 1,
                                        p: 0.3,
                                        backgroundColor: 'white',
                                        color: '#e53935',
                                        borderRadius: '100%',
                                    }}
                                />
                                <Select
                                    value={selectedPhone}
                                    onChange={(e) => { if (e.target.value) setSelectedPhone(e.target.value); }}
                                    displayEmpty
                                    renderValue={(selected) => <span>{selected}</span>}
                                    sx={{
                                        color: 'white',
                                        backgroundColor: 'transparent',
                                        fontSize: isMobile ? '12px !important' : '14px !important',
                                        border: 'none',
                                        outline: 'none',
                                        '& .MuiSelect-icon': {
                                            color: 'white',
                                        },
                                        '& .MuiOutlinedInput-notchedOutline': {
                                            border: 'none',
                                        },
                                        '&:focus': {
                                            border: 'none',
                                            outline: 'none',
                                        },
                                    }}
                                    MenuProps={{
                                        PaperProps: {
                                            sx: {
                                                borderRadius: 3,
                                                mt: 1,
                                                boxShadow: 3,
                                                minWidth: 160,
                                            },
                                        },
                                    }}
                                >
                                    <MenuItem
                                        value=""
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setField('Mobile No.')
                                            handleAddNewInput();
                                        }}
                                        sx={{
                                            color: '#e53935',
                                            fontWeight: 'bold',
                                            border: '1px solid #e53935',
                                            borderRadius: 2,
                                            justifyContent: 'center',
                                            mb: 1,
                                            mx: 1
                                        }}
                                    >
                                        + New Number
                                    </MenuItem>

                                    {phones.map((phone, index) => (
                                        <MenuItem key={index} value={phone}>
                                            {phone}
                                            {phone === selectedPhone && (
                                                <CheckCircleIcon
                                                    sx={{ ml: 'auto', color: '#e53935', fontSize: 16 }}
                                                />
                                            )}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </Box>
                        </FormControl>

                        <Inputmodal
                            open={openDialog}
                            onClose={handleDialogClose}
                            onSubmit={handleAddFieldFromModal}
                            field={field}
                        />

                        <FormControl size="small">
                            <Box display="flex" alignItems="center" sx={{ ...secondaryGray, color: 'white', borderRadius: 7, border: 'none', outline: "none" }}>
                                <MarkunreadIcon sx={{
                                    width: isMobile ? '12px' : '16px',
                                    height: isMobile ? '12px' : '16px',
                                    // width: "18px",
                                    // height: "18px",
                                    ml: 1,
                                    p: 0.3,
                                    backgroundColor: 'white',
                                    color: "GrayText",
                                    borderRadius: "100%"
                                }} />
                                <Select sx={{
                                    ...secondaryGray,
                                    color: 'white',
                                    backgroundColor: 'transparent',
                                    border: 'none',
                                    outline: 'none',
                                    '& .MuiSelect-icon': {
                                        color: 'white',
                                    },
                                    '& .MuiOutlinedInput-notchedOutline': {
                                        border: 'none',
                                    },
                                    '&:focus': {
                                        border: 'none',
                                        outline: 'none',
                                    },
                                }}
                                    value={selectedEmail}
                                    onChange={(e) => { if (e.target.value) setSelectedEmail(e.target.value); }}
                                    renderValue={(selected) => <span>{selected}</span>}
                                    MenuProps={{
                                        PaperProps: {
                                            sx: {
                                                borderRadius: 3,
                                                mt: 1,
                                                boxShadow: 3,
                                                minWidth: 160,
                                            },
                                        },
                                    }}>
                                    <MenuItem
                                        value=""
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setField('Email Id');
                                            handleAddNewInput();
                                        }}
                                        sx={{
                                            color: '#e53935',
                                            fontWeight: 'bold',
                                            border: '1px solid #e53935',
                                            borderRadius: 2,
                                            justifyContent: 'center',
                                            mb: 1,
                                            mx: 1
                                        }}
                                    >
                                        + Email Id
                                    </MenuItem>
                                    {emails.map((email, index) => (
                                        <MenuItem key={index} value={email}>
                                            {email}
                                            {email === selectedEmail && (
                                                <CheckCircleIcon
                                                    sx={{ ml: 'auto', color: '#e53935', fontSize: 16 }}
                                                />
                                            )}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </Box>
                        </FormControl>
                    </Box>
                </Box >
                {/* ------------------ Header Section ----------------- */}

                <Box sx={{ display: "flex" }}>
                    {/* ----------- Tab section Start---------- */}
                    <Box px={2} mb={1} sx={{ width: isMobile ? "87%" : "96%" }}>
                        {/* Vehicle Buttons */}
                        <Box display="flex" alignItems="center" gap={1} my={1}>
                            {vehicles && vehicles.length > 0 &&
                                <>
                                    {/* LEFT BUTTON */}
                                    <IconButton onClick={() => scroll("left")}>
                                        <ChevronLeftIcon />
                                    </IconButton>

                                    <ToggleButtonGroup
                                        ref={scrollRef}
                                        value={vehicle}
                                        exclusive
                                        onChange={handleChangeVehicle}
                                        sx={{
                                            display: 'flex',
                                            gap: 1,
                                            p: 0,
                                            // border: 'none',
                                            overflowX: "auto",
                                            flexWrap: "nowrap",
                                            width: "100%",

                                            // hide scrollbar
                                            scrollbarWidth: "none",
                                            "&::-webkit-scrollbar": { display: "none" }
                                        }}
                                    >
                                        {vehicles?.map((v, i) => (
                                            <ToggleButton className="toggle-button"
                                                key={v.chassisNo}
                                                value={v.chassisNo}
                                            >
                                                {v.model}
                                                {v.expiry_days && v.expiry_days < 61 &&
                                                    < img src={group} alt="" style={{ marginLeft: 10 }} />
                                                }
                                            </ToggleButton>
                                        ))}
                                    </ToggleButtonGroup>

                                    {/* RIGHT BUTTON */}
                                    <IconButton onClick={() => scroll("right")}>
                                        <ChevronRightIcon />
                                    </IconButton>
                                </>

                            }
                        </Box>

                        <InfoDisplay
                            data={{
                                policyNo: `${customerDetails?.policy_no}`,
                                insuranceCompany: response?.policyDetails ? response.policyDetails?.[0]?.insurance_company : '',
                                customerType: response?.policyDetails ? response.policyDetails?.[0]?.customer_type : '',
                                expiryDate: customerDetails?.policy_expiry_date ? `${format(parseISO(customerDetails?.policy_expiry_date), 'dd MMM yyyy')}` : '',
                                // expiryDate: `${format(parseISO(customerInfo.expiryDate), 'dd MMM yyyy')}`,
                                recentUpdate: `${response?.callDispositionDetails && response?.callDispositionDetails[0]?.recentupdates ? transformDate(response?.callDispositionDetails?.[0]?.recentupdates) : ''}`,
                                status: response?.callDispositionDetails && response?.callDispositionDetails?.[0]?.next_status !== '(0)' ? response?.callDispositionDetails[0]?.next_status : '',
                                ebmStatus: `${response?.overview?.[0]?.ebmStatus}`,
                                // ebmStatusColor: `${response?.overview?.[0]?.ebmStatusColor}`,
                                ebmStatusColor: `${ebmColorList[response?.overview?.[0]?.ebmStatus]}`,
                            }}
                        />

                        <Box sx={{ py: 1.5, borderRadius: 2, }}>
                            {/* <Typography variant="h6">Overview</Typography> */}
                            <Box display="flex" justifyItems={"center"} gap={1.5} flexWrap="wrap">
                                {Dealer_Overview_Data.map((card, index) => (
                                    <InfoCard key={index} items={card} />
                                ))}
                            </Box>
                        </Box>

                        <Box sx={{ backgroundColor: "white", borderRadius: 2, }}>
                            <Box display="flex" flexWrap={"wrap"} gap={1}>
                                <ToggleButtonGroup
                                    value={type}
                                    exclusive
                                    onChange={(e, v) => { if (v) handleTypeChange(e, v) }}
                                    sx={{
                                        display: 'flex',
                                        flexWrap: "wrap",
                                        gap: 1,
                                        p: 0,
                                        border: 'none',
                                    }}
                                >
                                    {fields && fields?.map((fieldData) => (
                                        <ToggleButton className="toggle-button"
                                            key={fieldData.type}
                                            value={fieldData.type}
                                        >
                                            {fieldData.label}{(fieldData.type === 'claim' && customerDetails?.claim_history === 'Yes') || (fieldData.type === 'endorsement' && customerDetails?.endorsementData === 'Yes') &&
                                                <img style={{ marginLeft: 5 }} src={group} />}
                                        </ToggleButton>
                                    ))}
                                </ToggleButtonGroup>
                            </Box>

                            {/* Table Section */}
                            <TableContainer component={Paper} elevation={0} sx={{ maxHeight: 280, overflowY: "scroll" }}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            {/* {Object?.keys(columns[type])?.map((col, i) =>  */}
                                            {Object.keys(columns?.[type] || {}).map((col, i) =>
                                                <TableCell key={i}>{col}{type === 'reminder' &&
                                                    col === 'Reminder Frequency' && <Tooltip title="T-Policy Expiry Date" sx={{ ml: 1 }} placement="top" arrow>
                                                        <InfoOutline fontSize='1em' />
                                                    </Tooltip>}</TableCell>)}
                                            {type === 'policy' && <TableCell>Add on</TableCell>}
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {rows && rows[type] && rows[type]?.map((row, index) => (
                                            <TableRow key={index}>
                                                {
                                                    // Object.values(columns[type])?.map((f) => (
                                                    Object.values(columns?.[type] || {})?.map((f) => (
                                                        f.slice(-4) === 'time' ? <TableCell key={f}>
                                                            {/* {format(parseISO(row[f]), 'dd-MM-yyyy HH:mm')} */}
                                                            {row[f]}
                                                        </TableCell>
                                                            : f.slice(-4) === 'date' ? <TableCell key={f}>
                                                                {row[f]}
                                                                {/* {row[f] ? {row[f]} `${type === 'policy' ? 'dd-MMM-yy' : type === 'reminder' ? 'dd-MM-yyyy' : 'dd-MM-yyyy HH:mm'}` : ''} */}
                                                                {/* // format(parseISO(row[f]), */}

                                                            </TableCell>
                                                                : f === 'renewal_link' ? <TableCell>
                                                                    <b><Box display={"flex"} alignItems={"center"} component="a" href={row[f]} target='_blank' sx={row[f] ? { ...tabselectedColor, ...cursorpointer } : { ...cursorpointer }}>Renwal<ChevronRight /></Box></b>
                                                                </TableCell> : <TableCell key={f}>{row[f]}</TableCell>
                                                    ))}
                                                {type === 'policy' && <TableCell>
                                                    <b><Box display={"flex"} alignItems={"center"}
                                                        sx={addonData?.length > 0 ? { ...tabselectedColor, ...cursorpointer } : { ...cursorpointer }}
                                                        onClick={
                                                            addonData?.length > 0
                                                                ? () => {
                                                                    handleOpenDrawer(row);
                                                                    fetchAddon(row?.policy_no);
                                                                }
                                                                : null
                                                        }
                                                    // onClick={addonData?.length > 0 ? handleOpenDrawer : null}
                                                    // sx={{ ...tabselectedColor, ...cursorpointer }}
                                                    // onClick={() => handleOpenDrawer(row)}
                                                    // onClick={() => fetchAddon(row?.policy_no)}
                                                    // sx={{ ...tabselectedColor, ...cursorpointer }}
                                                    >
                                                        View
                                                        <ChevronRight /></Box></b>
                                                </TableCell>}
                                                {type === "remarks" && (
                                                    <TableCell
                                                        sx={{
                                                            pr: 1
                                                        }}>
                                                        <Box>
                                                            <Typography
                                                                variant="body2"
                                                                sx={{
                                                                    color: "#6b7280",
                                                                    fontSize: "13px",
                                                                    mb: 0
                                                                }}
                                                            >
                                                                {row.created_date}
                                                            </Typography>

                                                            <Typography
                                                                variant="body2"
                                                                sx={{
                                                                    color: "#374151",
                                                                    fontSize: "14px",
                                                                }}
                                                            >
                                                                {row.remarks}
                                                            </Typography>
                                                        </Box>
                                                    </TableCell>
                                                )}
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Box>
                    </Box>
                    {/* ----------- Tab section Ends ---------- */}

                    {/* Sidebar menu Disposition and Communication */}
                    <SideFloatingButtons MobileNumber={selectedPhone} communicationData={customerInfo} dispositionData={customerInfo}
                        // refresh={() => fetchPage(false)} sx={{ width: isMobile ? "5%" : "2%" }}
                        refresh={() => fetchVehicles()} sx={{ width: isMobile ? "5%" : "2%" }}
                        quotationData={{
                            leadId: customerInfo.leadId,
                            policyNo: customerDetails?.policy_no,
                            clusterId: customerInfo?.clusterId,
                            ebmStatus: customerInfo?.ebmStatus,
                            phone: customerDetails?.crm_user_phone_no,
                            email: selectedEmail,
                            assigned_agent_ebm_user_id: customerDetails?.assigned_agent_ebm_user_id,
                            proposal_no: customerDetails?.proposal_no,
                            renewal_Link: customerDetails?.renewal_Link,
                        }} />
                </Box>
            </Stack >
            <AddOnDrawer open={openDrawer} onClose={handleCloseDrawer} addonData={addonData} />
            <ToastContainer autoClose={1000} />
        </>
    );
};

export default CustomerDetailsPage;