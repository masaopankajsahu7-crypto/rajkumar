import NorthIcon from '@mui/icons-material/North';
import SouthIcon from '@mui/icons-material/South';
import { Box, Button, FormControlLabel, FormGroup, Pagination, Paper, Skeleton, Switch, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from "@mui/material";
import { styled } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from 'react-router-dom';
import sorting from '../assets/images/sorting.svg';
import BackdropLoader from "../components/Loader/BackdropLoader";
import { editOutletDetails, getHeaders } from "../services/api";
import { encryptRoute } from "../services/encrypt";
import { btnRed, cursorpointer } from "../utils/Colors";


const IOSSwitch = styled((props) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
    width: 54,
    height: 27,
    padding: 0,
    '& .MuiSwitch-switchBase': {
        padding: 0,
        margin: 2,
        transitionDuration: '300ms',
        '&.Mui-checked': {
            transform: 'translateX(27px)',
            color: '#fff',
            '& + .MuiSwitch-track': {
                backgroundColor: '#e31837',
                opacity: 1,
                border: 0,
                ...theme.applyStyles('dark', {
                    backgroundColor: '#e31837',
                }),
            },
            '&.Mui-disabled + .MuiSwitch-track': {
                opacity: 0.5,
            },
        },
        '&.Mui-focusVisible .MuiSwitch-thumb': {
            color: '#e31837',
            border: '5px solid #fff',
        },
        '&.Mui-disabled .MuiSwitch-thumb': {
            color: theme.palette.grey[100],
            ...theme.applyStyles('dark', {
                color: theme.palette.grey[600],
            }),
        },
        '&.Mui-disabled + .MuiSwitch-track': {
            opacity: 0.7,
            ...theme.applyStyles('dark', {
                opacity: 0.3,
            }),
        },
    },
    '& .MuiSwitch-thumb': {
        boxSizing: 'border-box',
        width: 23,
        height: 23,
    },
    '& .MuiSwitch-track': {
        borderRadius: 27 / 2,
        backgroundColor: '#E9E9EA',
        opacity: 1,
        transition: theme.transitions.create(['background-color'], {
            duration: 500,
        }),
        ...theme.applyStyles('dark', {
            backgroundColor: '#39393D',
        }),
    },
}));

const EditMISPOutlet = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    const [rows, setRows] = useState([]);
    const [columns, setColumns] = useState([]);
    const [limit, setLimit] = useState(10);
    const [search, setSearch] = useState('');
    const [count, setCount] = useState(0);
    const [page, setPage] = useState(1);
    const navigate = useNavigate();
    const allowedUrls = useSelector((state) => state?.user?.featureAccess.map(fa => fa.Url));
    const userData = useSelector((state) => state?.user?.loggedData);
    const [loading, setLoading] = useState(false);
    const [sortField, setSortField] = useState('');
    const [sortOrder, setSortOrder] = useState('');

    const fetchPage = async () => {
        try {
            setLoading(true);
            const result = await getHeaders({ pageId: 1, user_id: userData?.user_id });
            const response = result.data;
            setColumns(response.inputModel.map((f) => f.inputName));
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSort = (field) => {
        if (sortField === field) {
            setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
        } else {
            setSortField(field);
            setSortOrder('asc');
        }
    };

    const fetchData = async () => {
        try {
            setLoading(true);
            const result = await editOutletDetails({ limit, page, search, sortField, sortOrder });
            const response = result.data;
            setCount(response.totalDealerDetails);
            setRows(response.dealerAllDetails);
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            fetchData();
        }, 300);

        return () => clearTimeout(delayDebounce);
    }, [search, limit, page, sortField, sortOrder])

    useEffect(() => {
        fetchPage();
    }, [])

    return (
        <>
            <BackdropLoader loading={loading} />
            <Paper className='table-auto-width' sx={{ borderRadius: 3, m: isMobile ? 1.5 : 2, width: 'inherit', boxShadow: "none" }}>
                <Box px={2} py={2} display='flex' flexWrap={"wrap"} alignItems="center" justifyContent="space-between">
                    <Box display='flex' alignItems="center">
                        <Typography className="georama-SemiBold fs-20" >Dealer List</Typography>
                        <Box sx={{ bgcolor: '#5d6673', color: 'white', mx: 2, px: 1, py: 0.5, borderRadius: 2, fontWeight: 'bold' }}>{count}</Box>
                    </Box>

                    <Box display="flex" flexWrap={"wrap"} justifyContent="space-between" alignItems="center">
                        <Button sx={{ m: 1 }} className="btn-common-red"
                            onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/editmispoutlet/create'))}`)}
                        >
                            Add New Dealer
                        </Button>
                        <TextField className="custom-textfield body-formbg" size="small" placeholder="Search" value={search} onChange={(e) => setSearch(e.target.value.trimStart().replace(/[^a-zA-Z0-9.,\s]/g, '').replace(/\s+/g, ' ').slice(0, 50)) || setPage(1)}
                            fullWidth
                            sx={{
                                width: isDesktop ? '22ch' : isMobile ? '22ch' : '22ch',
                                px: 2,
                                '& .MuiOutlinedInput-root': {
                                    borderRadius: 3,
                                    '&.Mui-focused fieldset': {
                                        borderColor: 'black',
                                    },
                                },
                                float: 'right'
                            }}
                        />
                    </Box>
                </Box>

                <TableContainer component={Box}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                {columns?.map((cell, index) => (
                                    <TableCell className="mispHead p-10 georama-Medium body-formbg fw-none"
                                        onClick={() => index < columns.length - 1 && handleSort(cell)} key={index} sx={{ ...cursorpointer }}>
                                        {cell} {index < columns.length - 1 && sortField === cell ? (
                                            sortOrder === 'asc' ? <NorthIcon fontSize="1" /> : <SouthIcon fontSize="1" />
                                        ) : (
                                            index < columns.length - 1 && <img src={sorting} alt="sort" />
                                        )}
                                    </TableCell>
                                ))}
                                {columns && !loading && <TableCell className="p-10 georama-Medium body-formbg fw-none">
                                    Status
                                </TableCell>}
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {loading ? (
                                [...Array(8)].map((_, idx) => (
                                    <TableRow key={idx}>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                    </TableRow>
                                ))) : (rows && rows.length > 0 ? (rows?.map((row, index) => (
                                    <TableRow key={index} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                        {Object.keys(row).slice(0, -3).map((field) => (
                                            <TableCell className="georama-Regular" key={field}>
                                                <span className={field === 'dealerName' ? 'text-truncate' : ''}>
                                                    {row[field]}
                                                </span>
                                            </TableCell>
                                        ))}

                                        <TableCell className="p-10 georama-Medium">
                                            {allowedUrls.includes('/editmispoutlet/edit') && <Button className="btn-edit" sx={btnRed} size="small" variant="contained"
                                                onClick={() =>
                                                    navigate(`/${encodeURIComponent(encryptRoute('/editmispoutlet/edit'))}`, {
                                                        state: { ...row, edit: true }
                                                    })
                                                }
                                            >Edit</Button>}
                                        </TableCell>

                                        <TableCell className="p-10 georama-Medium">
                                            <FormGroup>
                                                <FormControlLabel
                                                    control={<IOSSwitch checked={true} />}
                                                />
                                            </FormGroup>
                                        </TableCell>
                                    </TableRow>))
                                ) : (!rows || !rows?.length) && !loading && (
                                    <TableRow>
                                        <TableCell colSpan={columns.length}><Box className="center-text">No Records Found.</Box></TableCell>
                                    </TableRow>
                                ))}
                        </TableBody>
                    </Table>
                </TableContainer>

                <Box>
                    {/* <Typography display={'inline'}>Show result: </Typography>
                <Select size="small" sx={{ width: 75, borderRadius: 3, m: 1 }} value={limit} onChange={(e) => setLimit(e.target.value) || setPage(1)}>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={20}>20</MenuItem>
                    <MenuItem value={50}>50</MenuItem>
                    <MenuItem value={100}>100</MenuItem>
                </Select> */}

                    {rows && rows.length > 0 && <Pagination size="medium" count={Math.ceil(count / limit)} page={page} onChange={(e, v) => setPage(v)} shape="rounded"
                        sx={{
                            float: 'right', m: 1,
                            '& .MuiPaginationItem-root': {
                                borderRadius: 3,
                            }
                        }} />}
                </Box>
            </Paper>
        </>
    );
};

export default EditMISPOutlet;