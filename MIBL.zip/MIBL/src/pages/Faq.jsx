import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Accordion, AccordionDetails, AccordionSummary, Box, Button, Paper, TextField, Typography, useMediaQuery } from "@mui/material";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import BackdropLoader from "../components/Loader/BackdropLoader";
import { setFaqData } from "../redux/slices/userSlice";
import { fetchFaq } from "../services/api";
import { encryptRoute } from '../services/encrypt';

export default function FAQ() {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [expanded, setExpanded] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    // const [faqList, setFaqList] = useState([]);
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const userdetails = useSelector((state) => state.user.loggedData);
    const faqList = useSelector((state) => state.user.faqData);
    const dispatch = useDispatch();

    const handleChange = (faqId) => (event, isExpanded) => {
        setExpanded(isExpanded ? faqId : null);
    };

    const fetchFaqData = async () => {
        try {
            setLoading(true);
            const response = await fetchFaq();
            if (response?.status_code === "200" || response?.status_message === "FAQ records fetched successfully") {
                // setFaqList(response?.data?.faqs || []);
                dispatch(setFaqData(response?.data?.faqs || []));
            } else {
                console.error("Failed to load FAQ data");
            }
        } catch (error) {
            console.error("Error fetching FAQ:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (!faqList || faqList.length === 0) {
            fetchFaqData();
        }
    }, [faqList]);

    // ✅ Filter FAQs based on search
    const filteredFaqs = faqList.filter((faq) =>
        faq.question.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <>
            <BackdropLoader loading={loading} />
            <Paper
                elevation={2}
                sx={{ m: isMobile ? 1.5 : 2, width: "inherit", boxShadow: "none", borderRadius: 2 }}
            >
                <Box
                    className="table-body-bg border-radius-top-8"
                    display="flex"
                    flexDirection="column"
                    py={2}
                >
                    <Box pb={isDesktop ? 2 : 1} px={2} display={!isMobile ? "flex" : ""} flexWrap={isMobile ? "wrap" : ""} justifyContent={"space-between"} mb={2} textAlign={"center"} alignItems={"center"}
                        sx={{ borderBottom: '0.2px solid #ccc' }}>
                        <Box display={isMobile ? "flex" : ""} justifyContent={isMobile ? "space-between" : ""}>
                            <Typography className={`georama-SemiBold fs-24`}>
                                FAQ
                            </Typography>
                            {isMobile && <Button sx={{ ml: 2 }} className='text-capitalize georama-medium-selected custom-starticon'
                                startIcon={<ChevronLeftIcon />}
                                onClick={() => {
                                    if (userdetails.roleType === "DEALER") {
                                        navigate(`/${encodeURIComponent(encryptRoute('/managerdashboard'))}`)
                                    } else if (userdetails.roleType === "MIBL") {
                                        navigate(`/${encodeURIComponent(encryptRoute('/admindashboard'))}`)
                                    }
                                }
                                }>
                                Back
                            </Button>}
                        </Box>

                        <Box display={"flex"} alignItems={"center"}>
                            <TextField
                                className="custom-textfield body-formbg" size="small"
                                fullWidth
                                placeholder="Search..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                sx={{
                                    // width: "20ch",
                                    px: 2,
                                    // ml: 1,
                                    // mb: 1,
                                    '& .MuiOutlinedInput-root': {
                                        borderRadius: 3,
                                        '&.Mui-focused fieldset': {
                                            borderColor: 'black',
                                        },
                                    },
                                }}
                            />
                            {!isMobile && <Button sx={{ ml: 2 }} className='text-capitalize georama-medium-selected custom-starticon'
                                startIcon={<ChevronLeftIcon />}
                                onClick={() => {
                                    if (userdetails.roleType === "DEALER") {
                                        navigate(`/${encodeURIComponent(encryptRoute('/managerdashboard'))}`)
                                    } else if (userdetails.roleType === "MIBL") {
                                        navigate(`/${encodeURIComponent(encryptRoute('/admindashboard'))}`)
                                    }
                                }
                                }>
                                Back
                            </Button>}
                        </Box>
                    </Box>

                    <Box px={isMobile ? 1 : 2}>
                        {loading ? (
                            <Typography align="center" color="text.secondary" mt={2}>
                                Loading FAQs...
                            </Typography>
                        ) : filteredFaqs?.length > 0 ? (
                            filteredFaqs?.map((faq) => (
                                <Accordion
                                    key={faq.faq_id}
                                    expanded={expanded === faq.faq_id}
                                    onChange={handleChange(faq.faq_id)}
                                    sx={{
                                        border: '0px solid #ccc',
                                        bgcolor: "#EEEEEE",
                                        backgroundColor: "#EEEEEE",
                                        overflow: 'hidden',
                                        boxShadow: "none",
                                        mb: 1,
                                        borderRadius: 2,
                                        "&:before": { display: "none" }
                                    }}
                                >
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        sx={{
                                            backgroundColor: "#EEEEEE",
                                            borderBottom: expanded === faq.faq_id ? "0.2px solid #ccc" : "none",
                                            // transition: "border-bottom 0.3s ease",
                                        }}
                                    >
                                        <Typography
                                            className={`georama-SemiBold ${isMobile ? "fs-14" : "fs-18"}`}
                                            sx={{
                                                color: expanded === faq.faq_id ? "#e31837 !important" : "#101014 !important",
                                                fontWeight: 500,
                                            }}
                                        >
                                            {faq.question}
                                        </Typography>
                                    </AccordionSummary>


                                    <AccordionDetails
                                        sx={{
                                            borderTop: expanded === faq.faq_id ? "none" : "0.2px solid #eee",
                                            backgroundColor: "#EEEEEE",
                                        }}>
                                        <Typography
                                            className={`text-gray ${isMobile ? "fs-14" : ""}`}
                                            sx={{
                                                whiteSpace: "pre-line",
                                                color: "text.secondary",
                                                lineHeight: 1.6
                                            }}
                                        >
                                            {faq.answer}
                                        </Typography>
                                    </AccordionDetails>
                                </Accordion>
                            ))
                        ) : (
                            <Typography color="text.secondary" align="center" mt={3}>
                                No matching FAQs found.
                            </Typography>
                        )}
                    </Box>
                </Box>
            </Paper >
        </>
    );
}
