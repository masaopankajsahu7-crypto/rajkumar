import { useState, useEffect, useRef } from 'react';
import insurance from '../assets/images/insurance.svg'
// import logo from '../assets/images/logo.svg'
import logo from '../assets/images/logoMySaathi.svg'
import { Container, Paper, Box, Stack, TextField, Typography, Button, IconButton, Grid, FormHelperText } from '@mui/material';
import { VisibilityOffOutlined, VisibilityOutlined } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { sendOTP, verifyOTP } from '../services/api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import passwordReset from "../assets/images/passwordReset.svg";
import useMediaQuery from '@mui/material/useMediaQuery';
import BackdropLoader from '../components/Loader/BackdropLoader';

const Forgot = () => {
  const isDesktop = useMediaQuery('(min-width:626px)');
  const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState({ otp: "" });
  const [isEmailSent, setIsEmailSent] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const prevEmail = useRef('');
  const navigate = useNavigate();
  const [forgotScreen, setForgotScreen] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [rePassword, setRePassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [otpTouched, setOtpTouched] = useState(false);

  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes = 120 seconds
  const [isResendEnabled, setIsResendEnabled] = useState(false);

  // const handleOtpChange = (e) => {
  //   setOtp(e.target.value.slice(0, 6));
  //   setOtpTouched(false); // Reset error display while typing
  // };

  useEffect(() => {
    if (timeLeft <= 0) {
      setIsResendEnabled(true);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const formatTime = (seconds) => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };


  const handleResend = () => {
    setTimeLeft(120);
    setIsResendEnabled(false);
    handleSendOtp();
  };

  const handlePasswordChange = (e) => {
    const value = e.target.value.slice(0, 20);
    setPassword(value);
  };

  const handleRePasswordChange = (e) => {
    const value = e.target.value.slice(0, 20);
    setRePassword(value);
  };

  const validateEmail = () => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const mobileRegex = /^[6-9]\d{9}$/;

    if (!email) return 'Email Id / Mobile Number is required.';
    if (emailRegex.test(email)) return "";
    if (mobileRegex.test(email)) return "";

    return "Enter a valid Email Id or Mobile No.";
  };

  // const validateEmail = () => {
  //   const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  //   if (!email) return 'Email is required.';
  //   if (!emailRegex.test(email)) return 'Invalid email address.';
  //   return '';
  // };

  const validatePassword = () => {
    if (password.length < 9) return 'Password must be at least 9 characters.';

    if (!password) return 'Password is required.';

    if (password.length < 9 || password.length > 20) {
      return 'Password must be 9-20 characters long.';
    }

    const hasUpperCase = /[A-Z]/.test(password);
    // const hasAlphabet = /[a-zA-Z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecialChar = /[^A-Za-z0-9]/.test(password);

    if (!hasUpperCase || !hasNumber || !hasSpecialChar) {
      return 'Password must contain at least 1 uppercase letter, 1 number, and 1 special character.';
    }
    return '';
  };

  const handleSendOtp = async () => {
    const emailError = validateEmail();
    if (emailError) {
      setErrors({ email: emailError });
      return;
    }
    try {
      setLoading(true);
      const data = await sendOTP(email);
      if (data.data?.success) {
        setTimeLeft(120);
        setTimeout(() => {
          toast.success("OTP sent Successful.");
          setIsResendEnabled(false);
        }, 1000);
      } else if (data.status === 401) {
        toast.error(data.msg || 'Invalid email');
        return;
      }
      setIsEmailSent(true);
      setStep(2);

    } catch (error) {
      toast.error('Error While Sending OTP:', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    setOtpTouched(true);

    // if (timeLeft <= 0) {
    //   toast.info("OTP expired. Please request a new one.");
    //   return;
    // }

    const passwordError = validatePassword();
    const otpError = otp.length !== 6 ? 'OTP must be 6 digits.' : '';
    const rePasswordError = password !== rePassword ? 'Passwords do not match.' : '';

    const currentErrors = {
      otp: otpError,
      password: passwordError,
      rePassword: rePasswordError,
    };

    setErrors(currentErrors);

    const hasErrors = Object.values(currentErrors).some(Boolean);
    if (hasErrors) {
      // // 🔓 Temporarily show both passwords if there are errors
      // setShowPassword(true);
      // setShowRePassword(true);

      // // Optional: Hide passwords again after a delay
      // setTimeout(() => {
      //   setShowPassword(false);
      //   setShowRePassword(false);
      // }, 5000); // 5 seconds
      return;
    }

    // Proceed with actual password reset logic here

    try {
      setLoading(true);
      const response = await verifyOTP({ email, otp, password });
      if (response.status_message === "Enter Valid OTP") {
        toast.error(response.status_message);
      } else if (response.status_code === "200" || response.message === "OTP verified and your password changed Successfully") {
        setStep(3);
        setTimeout(() => {
          toast.success('OTP verified successfully!');
        }, 1000);
      } else {
        toast.error(response.status_message);
        return;
      }
    } catch (error) {
      toast.error('An error occurred during OTP verification. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // const handleResetPassword = async () => {
  //   const pwdError = validatePassword();
  //   const confirmError = password !== confirmPassword ? 'Passwords do not match.' : '';

  //   if (pwdError || confirmError) {
  //     setErrors({ password: pwdError, confirmPassword: confirmError });
  //     return;
  //   }

  //   try {
  //     const data = await resetPasswordUser(email, password, confirmPassword);
  //     if (data.status === 400) {
  //       toast.error('Password reset failed. Try Again.');
  //       return;
  //     } else {
  //       toast.success('Password changed successfully for:', email);
  //       navigate('/');
  //     }
  //   } catch (error) {
  //     toast.error('An error occurred during Password Reset. Please try again.');
  //   }
  // };

  useEffect(() => {
    const emailChanged = email != prevEmail.current;

    if (isEmailSent && emailChanged && validateEmail() == '') {
      prevEmail.current = email;
      setIsEmailSent(false);
    }
    if (errors.email) {
      let tempErrors = errors;
      tempErrors.email = validateEmail();
      setErrors(tempErrors)
    }
  }, [email]);

  useEffect(() => {
    if (!!errors.password || !!errors.confirmPassword || errors.password == '') {
      let tempErrors = {
        password: validatePassword(),
        confirmPassword: password !== confirmPassword ? 'Passwords do not match.' : ''
      };
      setErrors(tempErrors);
    }
  }, [password, confirmPassword]);

  return (
    <>
      <BackdropLoader loading={loading} />

      <Container sx={{ height: isDesktop ? '100vh' : '85vh', alignContent: 'center' }}>
        <Paper elevation={0} sx={{ borderRadius: 3 }}>
          <Grid container spacing={isMobile ? 0 : 0}>
            {/* Screen left */}

            <Grid size={{ xs: 12, sm: 6.2, md: 5.5 }} sx={{ justifyContent: "space-evenly", alignItems: "stretch" }}>
              <Paper elevation={0} sx={{
                backgroundColor: '#FFEAED', margin: 2,
                minHeight: { xs: '15vh', sm: '25vh', md: '75vh' },
                display: 'flex', justifyContent: 'space-around', alignItems: 'center', borderRadius: 3
              }} >
                <Stack spacing={12} py={3}>
                  <Box>
                    <img src={logo} width='70%' className='center-image'></img>
                    {/* <Typography sx={{ lineHeight: 1.1 }} textAlign={'center'} mt={1} className={`georama-Regular ${isDesktop ? 'fs-22' : 'fs-18'}`}>Motor Insurance Policy<br />Renewals</Typography> */}
                  </Box>

                  <Box sx={{ display: { xs: 'none', sm: 'block', md: 'block' } }}>
                    <img src={insurance} width={isMobile ? "65%" : "100%"} className='center-image'></img>
                  </Box>
                </Stack>
              </Paper>
            </Grid>

            {step == 1 && <Grid size={{ xs: 12, sm: 5.8, md: 6.5 }} sx={{ display: 'flex', justifyContent: "space-around", alignItems: "center" }}>
              <Stack spacing={2} sx={{ p: 1, width: { xs: '90%', sm: '90%', md: '60%' } }}>
                <Box display={"flex"} flexDirection={'column'} alignItems="center" justifyContent={"center"}>
                  <Typography sx={{ my: 1, mx: "auto", lineHeight: "35px !important" }} className={`georama-SemiBold text-dark ${isMobile ? 'fs-24' : 'fs-32'}`}>Forgot Password?</Typography>

                  <Typography sx={{ mb: 2, mt: 1 }} className='georama-Medium font-size-16 text-gray'>No worries, we'll send you reset instructions</Typography>
                </Box>

                <Box item xs={12} md={4} sx={{ my: 2 }}>
                  <Box item xs={12} md={4}>
                    <Typography className="text-labels" mb={0.5}>
                      Email Id / Mobile No <span className="important-fields">*</span>
                      {/* Email Id <span className="important-fields">*</span> */}
                    </Typography>

                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      value={email}
                      // placeholder="Enter Email Id"
                      placeholder="Enter Email Id / Mobile No"
                      disabled={step > 2}
                      onChange={(e) => setEmail(e.target.value.slice(0, 50))}
                    />

                    {errors.email && (
                      <FormHelperText className="important-fields">{errors.email}</FormHelperText>
                    )}

                    <Button sx={{ mt: 2, mb: 1, width: "100%" }} className="btn-common-red border-radius-32" onClick={handleSendOtp}>
                      Reset password
                    </Button>
                  </Box>

                  <Button sx={{ mx: 'auto', width: "100%" }}
                    className='text-capitalize georama-medium-selected custom-starticon'
                    startIcon={<ChevronLeftIcon />}
                    onClick={() => navigate(-1)}>
                    Back to Login
                  </Button>
                </Box>
              </Stack>
            </Grid>
            }

            {step == 2 && <Grid size={{ xs: 12, sm: 5.8, md: 6.5 }} sx={{ display: 'flex', justifyContent: "space-around", alignItems: "center" }}>
              <Stack spacing={2} sx={{ p: 1, width: { xs: '90%', sm: '90%', md: '60%' } }}>
                <Box display={"flex"} flexDirection={'column'} alignItems="center" justifyContent={"center"}>
                  <Typography sx={{ my: 1, mx: "auto" }} className={`georama-SemiBold ${isMobile ? 'fs-24' : 'fs-32'} text-dark`}>Check your email</Typography>
                  <Typography sx={{ mb: 2, mt: 1 }}
                    className='georama-Medium font-size-16 text-gray center-text'>
                    Please enter your 6-digit code. Then create and
                    confirm your new password.</Typography>
                </Box>


                <>
                  <Box item size={4} xs={12} md={4}>
                    <Typography className="text-labels" mb={0.5}>
                      6 Digit Code <span className="important-fields">*</span>
                    </Typography>

                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <TextField
                        className="form-control-input border-radius-8"
                        size="small"
                        fullWidth
                        required
                        placeholder="Enter 6 Digit OTP"
                        value={otp}
                        onChange={(e) => {
                          const value = e.target.value;
                          // Allow only numbers and max 6 digits
                          if (/^\d{0,6}$/.test(value)) {
                            setOtp(value);
                          }
                        }}
                        inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}
                        type="text"
                        InputProps={{ disableUnderline: true }}
                      />
                    </Box>

                    {otpTouched && errors.otp && <FormHelperText className="important-fields">{errors.otp}</FormHelperText>}

                    {/* Timer & Resend */}
                    <Box display="flex" justifyContent={"space-between"} gap={1}>
                      <Typography className='highlight-red fs-10' pt={0.5} pl={0.2}>
                        OTP is valid for 10 minutes
                      </Typography>
                      {isResendEnabled ? (
                        <Button className='highlight-red fs-12' onClick={handleResend}>
                          Resend OTP
                        </Button>
                      ) : (
                        <Typography className='highlight-red fs-12'>
                          Resend in {formatTime(timeLeft)}
                        </Typography>
                      )}
                    </Box>
                  </Box>


                  <Box size={4} item xs={12} md={4}>
                    <Typography className='text-labels' mb={0.5}>
                      New Password <span className="important-fields">*</span>
                    </Typography>

                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <TextField
                        className="form-control-input border-radius-8"
                        size="small"
                        fullWidth
                        required
                        placeholder="Enter New Password"
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={handlePasswordChange}
                        InputProps={{
                          endAdornment: (
                            <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                              {showPassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                            </IconButton>
                          ),
                          disableUnderline: true,
                        }}
                      />
                    </Box>

                    {errors.password && otpTouched && (
                      <FormHelperText className="important-fields">{errors.password}</FormHelperText>
                    )}
                  </Box>

                  <Box size={4} item xs={12} md={4}>
                    <Typography className='text-labels' mb={0.5}>
                      Re-Enter New Password <span className="important-fields">*</span>
                    </Typography>

                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <TextField
                        className="form-control-input border-radius-8"
                        size="small"
                        fullWidth
                        required
                        placeholder="Re-Enter New Password"
                        type={showRePassword ? 'text' : 'password'}
                        value={rePassword}
                        onChange={handleRePasswordChange}
                        InputProps={{
                          endAdornment: (
                            <IconButton onClick={() => setShowRePassword(!showRePassword)} edge="end">
                              {showRePassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                            </IconButton>
                          ),
                          disableUnderline: true,
                        }}
                      />
                    </Box>

                    {errors.rePassword && otpTouched && (
                      <FormHelperText className="important-fields">{errors.rePassword}</FormHelperText>
                    )}
                  </Box>

                  <Button
                    sx={{ mt: 1 }} className="btn-common-red border-radius-32"
                    fullWidth onClick={handleVerifyOtp} >
                    Reset Password
                  </Button>

                  <Button sx={{ mx: 'auto', width: "100%" }}
                    className='text-capitalize georama-medium-selected custom-starticon'
                    startIcon={<ChevronLeftIcon />}
                    onClick={() => navigate(-1)}>
                    Back to Login
                  </Button>
                </>
              </Stack>
            </Grid>
            }

            {step == 3 && <Grid size={{ xs: 12, sm: 5.8, md: 6.5 }} sx={{ display: 'flex', justifyContent: "space-around", alignItems: "center" }}>
              <Stack spacing={2} sx={{ p: 1, width: { xs: '90%', sm: '90%', md: '60%' } }}>
                <Box display={"flex"} flexDirection={'column'} alignItems="center" justifyContent={"center"}>
                  <img src={passwordReset} className='password-reset-image' width={"280px"} height={"96px"}></img>

                  <Box display={"flex"} flexDirection={'column'} alignItems="center" justifyContent={"center"}>
                    <Typography sx={{ my: 1, mx: "auto" }} className='georama-SemiBold text-dark fs-32'>Password Reset</Typography>

                    <Typography sx={{ mb: 2, mt: 2 }}
                      className='georama-Medium font-size-16 text-gray center-text'>
                      Your password has been successfully reset. <br />
                      Click below to log in.</Typography>
                  </Box>

                  <Button
                    sx={{ mt: 1 }} className="btn-common-red border-radius-32"
                    fullWidth onClick={() => navigate(-1)} >
                    Back to Login
                  </Button>
                </Box>

              </Stack>
            </Grid>
            }


            {/* {step === 3 && (
              <>
                <Typography mb={1}>Set your new password:</Typography>

                <Box sx={{
                  display: 'flex', p: 0.5, outline: 1, mx: '0',
                  outlineColor: !errors.password ? '#d32f2f' : 'black'
                }} borderRadius={3}>
                  <LockOutlineRounded sx={{ m: 1.5 }} />

                  <Divider orientation="vertical" variant="middle" sx={{ mr: 1.5, bgcolor: 'black' }} flexItem />

                  <TextField id="password" label="Password" fullWidth variant="standard"
                    type={showPass ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value.slice(0, 50))}
                    InputProps={{ disableUnderline: true }}
                    InputLabelProps={{
                      shrinks: "true",
                      sx: {
                        color: 'black',
                        transform: 'translateY(50%)',
                        '&.MuiInputLabel-shrink': {
                          transform: 'translateY(0)',
                          color: 'black',
                          fontSize: 'smaller'
                        }
                      }
                    }} />

                  <IconButton onClick={() => setShowPass(!showPass)}>
                    {showPass ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                  </IconButton>
                </Box>

                {errors.password && <Typography color="error" fontSize={'small'} mt={0.7}>{errors.password}</Typography>}

                <Box sx={{
                  display: 'flex', p: 0.5, outline: 1, mx: '0',
                  outlineColor: !errors.confirmPassword ? '#d32f2f' : 'black'
                }} borderRadius={3}>
                  <LockOutlineRounded sx={{ m: 1.5 }} />

                  <Divider orientation="vertical" variant="middle" sx={{ mr: 1.5, bgcolor: 'black' }} flexItem />

                  <TextField id="confirmPassword" label="Confirm Password" fullWidth variant="standard"
                    type={showConfirmPass ? 'text' : 'password'} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value.slice(0, 50))}
                    InputProps={{ disableUnderline: true }}
                    InputLabelProps={{
                      shrinks: "true",
                      sx: {
                        color: 'black',
                        transform: 'translateY(50%)',
                        '&.MuiInputLabel-shrink': {
                          transform: 'translateY(0)',
                          color: 'black',
                          fontSize: 'smaller'
                        }
                      }
                    }} />

                  <IconButton onClick={() => setShowConfirmPass(!showConfirmPass)}>
                    {showConfirmPass ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                  </IconButton>
                </Box>

                {errors.confirmPassword && <Typography color="error" fontSize={'small'} mt={0.7}>{errors.confirmPassword}</Typography>}

                <Button variant="contained" color='error' fullWidth onClick={handleResetPassword} sx={{ py: 1.5 }}>
                  <LockOutlineRounded sx={{ mr: 1 }} /> Reset Password
                </Button>

               <ToastContainer autoClose={1000} />
              </>
            )} */}

          </Grid>

        </Paper >
        <ToastContainer autoClose={1000} />
      </Container >

    </>
  );
};

export default Forgot;