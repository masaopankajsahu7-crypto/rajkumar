import { Container, Paper, Typography, Button, Stack, Box } from '@mui/material';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
// import { useLocation } from 'react-router-dom';
import Header, { DrawerHeader } from '../components/Header';
import Table from '../components/DataTable/Table';
import { bgGray100 } from '../utils/Colors';
import { useEffect, useState } from 'react';
import axios from 'axios';


const Home = () => {
  // const location = useLocation();
  // const email = location.state?.email;

  const [products, setProducts] = useState([]);
  
  const fetchData = async () => {
    try {
      const response = await axios.get('https://dummyjson.com/products');
      setProducts(response.data.products);
    } catch (error) {
      console.error('Failed to fetch products:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <>
      <Box sx={{ display: 'flex' }}>
        <div className={bgGray100}>
          <Box>
            <Table products={products} />
          </Box>
        </div>
      </Box>


      {/* <Header /> */}
      {/* <Container sx={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Paper elevation={3} sx={{ p: 5, borderRadius: 4, textAlign: 'center', maxWidth: 400, width: '100%' }}>
        <Stack spacing={3} alignItems="center">
          <CheckCircleRoundedIcon color="success" sx={{ fontSize: 60 }} />
          <Typography variant="h5"><b>Login Successful</b></Typography>
          {email && (
            <Typography variant="body1" color="text.secondary">
              Welcome back, <b>{email}</b>
            </Typography>
          )}
        </Stack>
      </Paper>
    </Container> */}

    </>
  );
};

export default Home;
