import FileDownloadIcon from '@mui/icons-material/FileDownload';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { Box, Button, Checkbox, Divider, FormControl, Grid, IconButton, InputLabel, MenuItem, Pagination, Paper, Select, Skeleton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, ToggleButton, ToggleButtonGroup, Tooltip, Typography } from '@mui/material';
import LinearProgress from '@mui/material/LinearProgress';
import useMediaQuery from '@mui/material/useMediaQuery';
import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import dateFilter from "../assets/images/dashboard/dateFilter.svg";
import bronzsvg from '../assets/images/leaderboard/bronze.svg';
import churchSvg from "../assets/images/leaderboard/church.svg";
import goldsvg from '../assets/images/leaderboard/gold.svg';
import leaderBoardSvg from "../assets/images/leaderboard/leaderBoard.svg";
import rankSvg from '../assets/images/leaderboard/rank.svg';
import silversvg from '../assets/images/leaderboard/silver.svg';
import CustomDateRange from '../components/DateRange/CustomDateRange';
import { clearLeaderboardCache, pruneLeaderboardCache, setLeaderboardCacheEntry } from '../redux/slices/leaderboardCacheSlice';
import { downloadLeaderBoardExcel, fetchLeaderBoardBestDealer, fetchLeaderBoardData } from '../services/api';
import { btnRed } from '../utils/Colors';


const LeaderBoard = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const dispatch = useDispatch();
    const userDetails = useSelector((state) => state.user.loggedData);
    const leaderboardCacheEntries = useSelector((state) => state.leaderboardCache?.entries || {});

    const adminLeadStatusData = useSelector((state) => state.dashboard?.adminLeadStatus);
    const [animateProgress, setAnimateProgress] = useState(false);
    const [limit, setLimit] = useState(10);
    const [count, setCount] = useState(0);
    const [page, setPage] = useState(1);
    const [leaderboardLoading, setLeaderboardLoading] = useState(true);

    const [agentPage, setAgentPage] = useState({});
    const agentLimit = 10;

    useEffect(() => {
        const timer = setTimeout(() => {
            setAnimateProgress(true);
        }, 200);

        return () => clearTimeout(timer);
    }, []);

    const [renewalList, setRenewalcategory] = useState([])
    const [zoneList, setZoneList] = useState([])
    const [stateList, setStateList] = useState([])
    const [dealerList, setDealerList] = useState([])
    const [segmentData, setSegmentList] = useState([])

    const [selectedSegments, setSelectedSegments] = useState([]);
    const [selectedZones, setselectedZones] = useState([]);
    const [selectedStates, setselectedStates] = useState([]);
    const [selectedDealers, setselectedDealers] = useState([]);
    const [open, setOpen] = useState(false);
    const anchorRef = useRef(null);
    const [dateSelected, setDateSelected] = useState("");
    const [filtersVersion, setFiltersVersion] = useState(0);
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);
    const [stateSelectionOpen, setStateSelectionOpen] = useState(false);
    const [zoneSelectOpen, setZoneSelectOpen] = useState(false);
    const [dealerSelectOpen, setDealerSelectOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [dealerPagination, setDealerPagination] = useState(0);
    const [agentPagination, setAgentPagination] = useState(0);

    const [ratioType, setRatioType] = useState("Conversion Rate");
    const [rankFilter, setRankFilter] = useState("");

    const [bestinIndia, setBestinIndia] = useState([]);
    const [bestinZone, setBestinZone] = useState([]);

    const [bestinIndiaPenetration, setBestinIndiaPenetration] = useState([]);
    const [bestinZonePenetration, setBestinZonePenetration] = useState([]);

    const [dealerListData, setDealerListData] = useState([]);

    const [dealerSearchText, setDealerSearchText] = useState("");

    // Filter dealer list by search
    const filteredDealers = dealerList?.filter((d) =>
        d?.dealer_name?.toLowerCase()?.includes(dealerSearchText?.toLowerCase())
    );

    const [openRow, setOpenRow] = useState(null);
    const [dealerAgents, setDealerAgents] = useState({});
    const inFlightRequestsRef = useRef({});

    // for Renewal category
    const [selectedRenewals, setSelectedRenewals] = useState([]);
    const [renewalSelectOpen, setRenewalSelectOpen] = useState(false);
    const isFirstRender = useRef(true);
    const isDateClearingRef = useRef(false);

    const sortPayloadKeys = (value) => {
        if (Array.isArray(value)) {
            return value.map(sortPayloadKeys);
        }
        if (value && typeof value === "object") {
            return Object.keys(value)
                .sort()
                .reduce((acc, key) => {
                    acc[key] = sortPayloadKeys(value[key]);
                    return acc;
                }, {});
        }
        return value;
    };

    const makeCacheKey = (scope, payload) => `${scope}::${JSON.stringify(sortPayloadKeys(payload))}`;

    const isValidApiResponse = (response) => (
        response?.status_code === "200" ||
        response?.status_message === "LeaderBoard details fetched"
    );

    const getCachedResponse = (scope, payload) => {
        const key = makeCacheKey(scope, payload);
        const entry = leaderboardCacheEntries[key];
        if (!entry) return null;
        if ((entry.expiresAt || 0) <= Date.now()) return null;
        return entry.data;
    };

    const getOrFetchWithCache = async (scope, payload, apiCall, options = {}) => {
        const { ttlMs = 5 * 60 * 1000, force = false } = options;
        const cacheKey = makeCacheKey(scope, payload);

        if (!force) {
            const cachedResponse = getCachedResponse(scope, payload);
            if (cachedResponse) return cachedResponse;

            if (inFlightRequestsRef.current[cacheKey]) {
                return inFlightRequestsRef.current[cacheKey];
            }
        }

        const requestPromise = (async () => {
            const response = await apiCall(payload);
            if (isValidApiResponse(response)) {
                dispatch(setLeaderboardCacheEntry({ key: cacheKey, data: response, ttlMs }));
            }
            return response;
        })().finally(() => {
            delete inFlightRequestsRef.current[cacheKey];
        });

        inFlightRequestsRef.current[cacheKey] = requestPromise;
        return requestPromise;
    };

    useEffect(() => {
        // Force a fresh API cycle whenever this page mounts (reload/hot reload/navigation),
        // then keep caching for subsequent interactions.
        dispatch(clearLeaderboardCache());
        dispatch(pruneLeaderboardCache());
    }, [dispatch]);

    // for renewal
    const handleRenewalToggle = (renewal) => {
        if (renewal === "all") {
            if (selectedRenewals.length === renewalList.length) {
                setSelectedRenewals([]);
            } else {
                setSelectedRenewals(renewalList?.map((item) => item.id));
            }
        } else {
            const currentIndex = selectedRenewals.indexOf(renewal);
            const newSelected = [...selectedRenewals];

            if (currentIndex === -1) {
                newSelected.push(renewal);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedRenewals(newSelected);
        }
        // setPage(1);
        // isFilterChangeRef.current = true;
    };

    // for zone 
    const handleZoneChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList?.map(zone => zone.Zone));
            }
        } else {
            setselectedZones(value);
        }
        // setPage(1);
        // isFilterChangeRef.current = true;
    };
    const handleZoneToggle = (zone) => {
        if (zone === 'all') {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList?.map(zone => zone.Zone));
            }
        } else {
            const currentIndex = selectedZones.indexOf(zone);
            const newSelected = [...selectedZones];

            if (currentIndex === -1) {
                newSelected.push(zone);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedZones(newSelected);
        }
        // setPage(1);
        // isFilterChangeRef.current = true;
    };

    // for state 
    const handleStateChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList?.map(data => data.State));
            }
        } else {
            setselectedStates(value);
        }
        // setPage(1);
        // isFilterChangeRef.current = true;
    };
    const handleStateToggle = (state) => {
        if (state === 'all') {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList?.map(data => data.State));
            }
        } else {
            const currentIndex = selectedStates.indexOf(state);
            const newSelected = [...selectedStates];

            if (currentIndex === -1) {
                newSelected.push(state);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedStates(newSelected);
        }
        // setPage(1);
        // isFilterChangeRef.current = true;
    };

    // for dealer 
    const handleDealerToggle = (dealerId) => {
        if (dealerId === 'all') {
            if (selectedDealers.length === dealerList.length) {
                setselectedDealers([]);
            } else {
                setselectedDealers(dealerList?.map(data => data.dealer_id));
            }
        } else {
            const currentIndex = selectedDealers.indexOf(dealerId);
            const newSelected = [...selectedDealers];

            if (currentIndex === -1) {
                newSelected.push(dealerId);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedDealers(newSelected);
        }
        // setPage(1);
        // isFilterChangeRef.current = true;
    };

    // for segment 
    const handleSegmentChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData?.map(seg => seg.segment));
            }
        } else {
            setSelectedSegments(value);
        }
        // setPage(1);
        // isFilterChangeRef.current = true;
    };
    const handleSegmentToggle = (segment) => {
        if (segment === 'all') {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData?.map(seg => seg.segment));
            }
        } else {
            const currentIndex = selectedSegments.indexOf(segment);
            const newSelected = [...selectedSegments];

            if (currentIndex === -1) {
                newSelected.push(segment);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedSegments(newSelected);
        }
        // setPage(1);
        // isFilterChangeRef.current = true;
    };

    const fetchMiblLeaderBoard = async () => {
        setOpenRow(null);
        if (!userDetails?.user_id) return;

        try {
            const payload = {
                type: "LeaderBoard",
                renewalCategory: "",
                zone: "",
                state: "",
                dealerCode: "",
                dealerLocCode: "",
                fromDate: "",
                toDate: "",
                roleType: userDetails?.roleType,
                loginUserId: userDetails?.user_id,
                segment: "",
                checkType: "",
                limit: limit,
                offset: page,
                checkRatio: ratioType,
                rankFilter: rankFilter
            }

            const cachedResponse = getCachedResponse("leaderboard-data", payload);
            if (!cachedResponse) setLoading(true);
            const response = await getOrFetchWithCache(
                "leaderboard-data",
                payload,
                fetchLeaderBoardData,
                { ttlMs: 2 * 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "LeaderBoard details fetched") {
                const { result0, result1, result2, result3, result4, result5, result6 } = response;
                setDealerListData(result0);
                setRenewalcategory(result1 || []);
                setZoneList(result2 || []);
                setStateList(result3 || []);
                setDealerList(result4 || []);
                setSegmentList(result5 || []);
                setDealerPagination(result6[0]?.["dealerCount"] || 0);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const fetchLeaderBoardBestDealerData = async () => {
        setOpenRow(null);
        if (!userDetails?.user_id) return;

        try {
            const payload = {
                type: "LeaderBoard",
                renewalCategory: "",
                zone: "",
                state: "",
                dealerCode: "",
                dealerLocCode: "",
                fromDate: "",
                toDate: "",
                roleType: userDetails?.roleType,
                loginUserId: userDetails?.user_id,
                segment: "",
                checkType: "",
                limit: limit,
                offset: page,
                checkRatio: ratioType,
                rankFilter: rankFilter
            }

            const cachedResponse = getCachedResponse("leaderboard-best-dealer", payload);
            if (!cachedResponse) {
                setLoading(true);
                setLeaderboardLoading(true);
            }
            const response = await getOrFetchWithCache(
                "leaderboard-best-dealer",
                payload,
                fetchLeaderBoardBestDealer,
                { ttlMs: 2 * 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "LeaderBoard details fetched") {
                // const result0 = [
                //     {
                //         "Name": "Best in India",
                //         "dealer": "AGARWAL AUTO SALES",
                //         "dealer_code": "D100",
                //         "penetration_percentage": 0,
                //         "agent_rank": 1
                //     },
                //     {
                //         "Name": "Best in India",
                //         "dealer": "CAI AUTO INDUSTRIES PRIVATE LIMITED",
                //         "dealer_code": "D101",
                //         "penetration_percentage": null,
                //         "agent_rank": 2
                //     },
                //     {
                //         "Name": "Best in India",
                //         "dealer": "BHAVNA AUTOMOBILES PVT LTD",
                //         "dealer_code": "D102",
                //         "penetration_percentage": null,
                //         "agent_rank": 3
                //     },
                //     {
                //         "Name": "Best in India",
                //         "dealer": "Dealer5",
                //         "dealer_code": "D105",
                //         "penetration_percentage": null,
                //         "agent_rank": 4
                //     },
                //     {
                //         "Name": "Best in Zone",
                //         "dealer": "Dealer0",
                //         "dealer_code": "D100",
                //         "penetration_percentage": 0,
                //         "agent_rank": 1
                //     },
                //     {
                //         "Name": "Best in Zone",
                //         "dealer": "RANDHAWA AUTOMOBILES ENGINEERING PVT LTD",
                //         "dealer_code": "D101",
                //         "penetration_percentage": null,
                //         "agent_rank": 2
                //     },
                //     {
                //         "Name": "Best in Zone",
                //         "dealer": "SL ROKLAND MOTORE LLP",
                //         "dealer_code": "D102",
                //         "penetration_percentage": null,
                //         "agent_rank": 3
                //     },
                //     {
                //         "Name": "Best in Zone",
                //         "dealer": "Krishna Autosales Pvt Ltd",
                //         "dealer_code": "D109",
                //         "penetration_percentage": null,
                //         "agent_rank": 4
                //     }
                // ]

                const { result0 } = response;

                const indiaData = result0?.filter(
                    item => item.Name === "Best in India"
                );

                const zoneData = result0?.filter(
                    item => item.Name === "Best in Zone"
                );

                // Set ranking cards data
                setBestinIndia(indiaData || []);
                setBestinZone(zoneData || []);

                // Set penetration chart data
                setBestinIndiaPenetration(indiaData || []);
                setBestinZonePenetration(zoneData || []);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
            setLeaderboardLoading(false);
        }
    };

    const fetchDealerLeaderBoard = async () => {
        if (!userDetails?.user_id) return;

        try {
            const payload = {
                type: "LeaderBoard",
                renewalCategory: "",
                dealerCode: userDetails?.dealerCode || "",
                fromDate: "",
                toDate: "",
                roleType: userDetails?.roleType,
                segment: "",
                limit: limit,
                offset: page,
                checkRatio: ratioType,
                loginUserId: userDetails?.user_id,
                rankFilter: rankFilter
            };

            const cachedResponse = getCachedResponse("leaderboard-data", payload);
            if (!cachedResponse) setLoading(true);
            const response = await getOrFetchWithCache(
                "leaderboard-data",
                payload,
                fetchLeaderBoardData,
                { ttlMs: 2 * 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "LeaderBoard details fetched") {
                const { result0, result1, result2, result3 } = response;
                setDealerListData(result0);
                setRenewalcategory(result1 || []);
                setSegmentList(result2 || []);
                setDealerPagination(result3[0]?.["agentCount"] || 0);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const selectedRenewalNames = renewalList
        .filter((item) => selectedRenewals.includes(item.id))
        ?.map((item) => item.renewal_year);

    // NOTE: Keep all API calls centralized in one effect; UI handlers only bump `filtersVersion`.

    const filterMiblLeaderBoard = async (dateParam) => {
        setOpenRow(null);
        if (!userDetails?.user_id) return;

        const date = dateParam !== undefined ? dateParam : dateSelected;

        try {
            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            const isFilterEmpty =
                selectedRenewals.length === 0 &&
                selectedZones.length === 0 &&
                selectedStates.length === 0 &&
                selectedDealers.length === 0 &&
                selectedSegments.length === 0 && isDateEmpty;

            const payload = {
                type: isFilterEmpty ? "LeaderBoard" : "LeaderBoardfilter",
                renewalCategory: selectedRenewalNames.join(","),
                zone: selectedZones.join(","),
                state: selectedStates.join(","),
                dealerLocCode: "",
                dealerCode: selectedDealers.join(","),
                fromDate: date?.startDate || "",
                toDate: date?.endDate || "",
                roleType: userDetails?.roleType,
                loginUserId: userDetails?.user_id,
                segment: selectedSegments.join(","),
                checkType: "",
                limit: limit,
                offset: page,
                checkRatio: ratioType,
                rankFilter: rankFilter
            }

            const cachedResponse = getCachedResponse("leaderboard-data", payload);
            if (!cachedResponse) setLoading(true);
            const response = await getOrFetchWithCache(
                "leaderboard-data",
                payload,
                fetchLeaderBoardData,
                { ttlMs: 2 * 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "LeaderBoard details fetched") {
                const { result0, result1, result2, result3, result4, result5, result6 } = response;
                setDealerListData(result0);
                setRenewalcategory(result1 || []);
                setZoneList(result2 || []);
                setStateList(result3 || []);
                setDealerList(result4 || []);
                setSegmentList(result5 || []);
                setDealerPagination(result6[0]?.["dealerCount"] || 0);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const filterDealerLeaderBoard = async (dateParam) => {
        if (!userDetails?.user_id) return;

        const date = dateParam !== undefined ? dateParam : dateSelected;
        try {
            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            const isFilterEmpty =
                selectedRenewals.length === 0 &&
                selectedSegments.length === 0 && isDateEmpty;

            const payload = {
                type: isFilterEmpty ? "LeaderBoard" : "LeaderBoardfilter",
                renewalCategory: selectedRenewalNames.join(","),
                dealerCode: userDetails?.dealerCode || "",
                fromDate: date?.startDate || "",
                toDate: date?.endDate || "",
                roleType: userDetails?.roleType,
                segment: selectedSegments.join(","),
                limit: limit,
                offset: page,
                rankFilter: rankFilter,
                checkRatio: ratioType,
                loginUserId: userDetails?.user_id
            }

            const cachedResponse = getCachedResponse("leaderboard-data", payload);
            if (!cachedResponse) setLoading(true);
            const response = await getOrFetchWithCache(
                "leaderboard-data",
                payload,
                fetchLeaderBoardData,
                { ttlMs: 2 * 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "LeaderBoard details fetched") {
                const { result0, result1, result2, result3 } = response;
                // setBestinIndia(result0);
                // setBestinZone(result1);
                // setBestinIndiaPenetration(result2);
                // setBestinZonePenetration(result3);

                setDealerListData(result0);
                setRenewalcategory(result1 || []);
                setSegmentList(result2 || []);
                setDealerPagination(result3[0]?.["agentCount"] || 0);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const fetchDealerAgents = async (dealerCode, dateParam, page = 1, limit = 10) => {
        if (!userDetails?.user_id) return;

        const date = dateParam !== undefined ? dateParam : dateSelected;

        const isDateEmpty =
            !date ||
            !date.startDate ||
            !date.endDate ||
            date.startDate === "Invalid Date" ||
            date.endDate === "Invalid Date";

        const isFilterEmpty =
            selectedRenewals.length === 0 &&
            selectedZones.length === 0 &&
            selectedStates.length === 0 &&
            selectedDealers.length === 0 &&
            selectedSegments.length === 0 && isDateEmpty;

        try {
            const payload = {
                type: isFilterEmpty ? "" : "LeaderBoardfilter",
                renewalCategory: selectedRenewalNames.join(","),
                zone: selectedZones.join(","),
                state: selectedStates.join(","),
                dealerCode: dealerCode,
                dealerLocCode: "",
                fromDate: date?.startDate || "",
                toDate: date?.endDate || "",
                roleType: userDetails?.roleType,
                loginUserId: userDetails?.user_id,
                segment: selectedSegments.join(","),
                checkType: "FetchDealerAgent",
                limit: limit,
                offset: page,
                checkRatio: ratioType,
                rankFilter: rankFilter
            };

            const cachedResponse = getCachedResponse("leaderboard-agents", payload);
            if (!cachedResponse) setLoading(true);

            const response = await getOrFetchWithCache(
                "leaderboard-agents",
                payload,
                fetchLeaderBoardData,
                { ttlMs: 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "LeaderBoard details fetched") {

                const { result0, result6 } = response;

                setDealerAgents(prev => ({
                    ...prev,
                    [dealerCode]: result0
                }));
                setAgentPagination(result6[0]?.["agentCount"] || []);
            } else {
                console.error("Failed to fetch agents:", response);
            }

        } catch (err) {
            console.error("Error fetching agents:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            const date = dateSelected !== undefined ? dateSelected : dateSelected;

            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            let isFilterEmpty;

            if (userDetails?.roleType === "MIBL") {
                isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedZones.length === 0 &&
                    selectedStates.length === 0 &&
                    selectedDealers.length === 0 &&
                    selectedSegments.length === 0 &&
                    isDateEmpty;

                if (isFilterEmpty) {
                    console.log("fetching MIBL LeaderBoard");

                    // Parallel API calls
                    await Promise.all([
                        fetchMiblLeaderBoard(),
                        fetchLeaderBoardBestDealerData(),
                    ]);
                } else {
                    await filterMiblLeaderBoard();
                }
            } else {
                isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedSegments.length === 0 &&
                    isDateEmpty;

                if (isFilterEmpty) {
                    await Promise.all([
                        fetchDealerLeaderBoard(),
                        fetchLeaderBoardBestDealerData(),
                    ]);
                } else {
                    await filterDealerLeaderBoard();
                }
            }
        };

        fetchData();
    }, [page, limit, dateSelected, filtersVersion, userDetails?.user_id]);

    useEffect(() => {
        if (isFirstRender.current) {
            isFirstRender.current = false;
            return; // skip first render
        }

        setPage(1);
        setFiltersVersion((v) => v + 1);
    }, [rankFilter, ratioType]);

    const handleClearFilters = (type) => {
        const resetters = {
            renewal: setSelectedRenewals,
            zone: setselectedZones,
            state: setselectedStates,
            dealer: setselectedDealers,
            segment: setSelectedSegments,
        };

        if (resetters[type]) {
            resetters[type]([]);
            setPage(1);
            setFiltersVersion((v) => v + 1);
        }
    };

    const handleToggleAccordion = async (index, row) => {
        setAgentPage({})
        // let currentPage;
        // currentPage = 1
        if (openRow === index) {
            setOpenRow(null);
            return;
        }

        setOpenRow(index);

        const currentPage = 1;

        // prevent refetch if already loaded
        // if (dealerAgents[row.dealerCode]) return;

        await fetchDealerAgents(row.dealerCode, dateSelected, currentPage, agentLimit);
    };

    const rankConfig = {
        1: { icon: goldsvg, class: "gold-col", color: "#F3B404" },
        2: { icon: silversvg, class: "silver-col", color: "#8B8B8B" },
        3: { icon: bronzsvg, class: "bronze-col", color: "#CE7A41" }
    };

    const india_ranks = userDetails?.roleType === "DEALER" && bestinIndia.length > 3 ? [1, 2, 3, 4] : [1, 2, 3];
    const zone_ranks = userDetails?.roleType === "DEALER" && bestinZone.length > 3 ? [1, 2, 3, 4] : [1, 2, 3];

    const indiaData = india_ranks.map(rank => {
        const dealer = bestinIndia?.find(d => d.agent_rank === rank);
        return {
            ...dealer,
            agent_rank: rank,
            dealer: dealer?.dealer || "N/A"
        };
    });

    const zoneData = zone_ranks.map(rank => {
        const dealer = bestinZone?.find(d => d.agent_rank === rank);
        return {
            ...dealer,
            agent_rank: rank,
            dealer: dealer?.dealer || "N/A"
        };
    });

    const penetrationData = bestinIndiaPenetration?.map((item, index) => ({
        label: item.dealer,
        value: Number(item.penetration_percentage || 0),
        color: rankConfig[index + 1]?.color || "#000"
    }));

    const zonePenetrationData = bestinZonePenetration?.map((item, index) => ({
        label: item.dealer,
        value: Number(item.penetration_percentage || 0),
        color: rankConfig[index + 1]?.color || "#000"
    }));

    const downloadExcelData = async (date = dateSelected) => {
        try {
            setLoading(true);
            let isFilterEmpty;

            const isDateEmpty =
                !dateSelected ||
                !dateSelected.startDate ||
                !dateSelected.endDate ||
                dateSelected.startDate === "Invalid Date" ||
                dateSelected.endDate === "Invalid Date";

            if (userDetails?.roleType === "MIBL") {
                isFilterEmpty = selectedRenewalNames.length === 0 &&
                    selectedZones.length === 0 &&
                    selectedStates.length === 0 &&
                    selectedDealers.length === 0 &&
                    selectedSegments.length === 0 && isDateEmpty
            } else {
                isFilterEmpty = selectedRenewalNames.length === 0 &&
                    selectedSegments.length === 0 && isDateEmpty
            }

            const payload = {
                type: isFilterEmpty ? "downloadLeaderBoardData" : "downloadLeaderBoardFilteredData",
                renewalCategory: isFilterEmpty ? "" : selectedRenewalNames.join(","),
                segment: isFilterEmpty ? "" : selectedSegments.join(","),
                dealerCode: userDetails?.roleType === "MIBL" ? selectedDealers.join(",") : userDetails?.dealerCode || "",
                zone: isFilterEmpty ? "" : selectedZones.join(","),
                state: isFilterEmpty ? "" : selectedStates.join(","),
                fromDate: dateSelected ? dateSelected?.startDate == "Invalid Date" ? "" : dateSelected?.startDate : "",
                toDate: dateSelected ? dateSelected?.endDate == "Invalid Date" ? "" : dateSelected?.endDate : "",
                roleType: userDetails?.roleType,
                limit,
                offset: page,
                checkRatio: ratioType,
                rankFilter: rankFilter
            };


            const result = await downloadLeaderBoardExcel(payload);

            if (result?.data) {
                const blob = new Blob([result.data], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                });

                const url = window.URL.createObjectURL(blob);
                const link = document.createElement("a");

                link.href = url;
                link.download = "Leaderboard_Data.xlsx";

                document.body.appendChild(link);
                link.click();

                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error("Error downloading Excel file:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Paper className="body-formbg table-auto-width" elevation={0} sx={{ boxShadow: 'none' }}>
                {/* <BackdropLoader loading={loading} /> */}
                <Box py={isMobile ? 1.3 : 0.5} px={isMobile ? 1.5 : 2}>
                    <Box display={'flex'} flexWrap={"wrap"} justifyContent="space-between" alignItems="center" mb={1.2} mt={1}>
                        <Box display={'flex'} alignItems="center" justifyContent={"start"} mb={1}>
                            <Typography px={1} className={`georama-SemiBold ${isMobile ? "fs-16" : "fs-20"}`}>Leaderboard</Typography>
                        </Box>

                        <Box display="flex" gap={1} flexWrap={"wrap"}>
                            <FormControl
                                size="small"
                                sx={{
                                    width: 300,
                                    minWidth: 170,
                                    maxWidth: 170,
                                    backgroundColor: "#ffffff",
                                    borderRadius: 2,
                                }}
                            >
                                <InputLabel id="renewal-label" className="dropdown-label">
                                    Renewal Category
                                </InputLabel>

                                <Select
                                    className="georama-Medium"
                                    labelId="renewal-label"
                                    id="renewal-select"
                                    multiple
                                    value={selectedRenewals}
                                    label="Renewal Category"
                                    open={renewalSelectOpen}
                                    onClose={() => setRenewalSelectOpen(false)}
                                    onOpen={() => setRenewalSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === renewalList.length) return "All";

                                        return renewalList
                                            .filter((data) => selected.includes(data.id))
                                            ?.map((data) => data.renewal_year)
                                            .join(", ");
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                position: "fixed",
                                                zIndex: 1500,
                                            },
                                        },
                                    }}
                                >

                                    {/* All Option */}
                                    <MenuItem
                                        disableGutters
                                        sx={{ py: 0, px: 1, m: 0 }}
                                        value="all"
                                        onClick={() => handleRenewalToggle("all")}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                                "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                            }}
                                            checked={selectedRenewals.length === renewalList.length}
                                            indeterminate={
                                                selectedRenewals.length > 0 &&
                                                selectedRenewals.length < renewalList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    {/* Renewal Category List */}
                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: "auto",
                                            pr: 1,
                                        }}
                                    >
                                        {renewalList?.map((data) => (
                                            <MenuItem
                                                disableGutters
                                                sx={{ py: 0, px: 1, m: 0 }}
                                                key={data.id}
                                                value={data.id}
                                                onClick={() => handleRenewalToggle(data.id)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        "&.Mui-checked": { color: "#e53935" },
                                                    }}
                                                    checked={selectedRenewals.includes(data.id)}
                                                />
                                                {data.renewal_year}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    {/* Buttons */}
                                    <Box display={"flex"} justifyContent={"end"} gap={1}>
                                        <Button
                                            fullWidth
                                            size="small"
                                            onClick={() => {
                                                handleClearFilters("renewal");
                                                setRenewalSelectOpen(false);
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: "none",
                                                // px: 1,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: "transparent",
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className="btn-common-red"
                                            fullWidth
                                            size="small"
                                            sx={{
                                                mr: 1,
                                                my: 1,
                                                ...btnRed,
                                            }}
                                            onClick={() => {
                                                setPage(1);
                                                setFiltersVersion((v) => v + 1);
                                                setRenewalSelectOpen(false);
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>
                            {userDetails.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel id="zone-label" className="dropdown-label">Zone</InputLabel>

                                <Select
                                    className='georama-Medium'
                                    labelId="zone-label"
                                    id="zone-select"
                                    multiple
                                    value={selectedZones}
                                    label="Zone"
                                    onChange={handleZoneChange}
                                    open={zoneSelectOpen}
                                    onClose={() => setZoneSelectOpen(false)}
                                    onOpen={() => setZoneSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === zoneList?.length) return "All";
                                        return zoneList
                                            .filter(zone => selected.includes(zone.Zone))
                                            ?.map(zone => zone.Zone)
                                            .join(',');
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                // maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                >
                                    <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                        onClick={() => handleZoneToggle('all')}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedZones.length === zoneList?.length}
                                            indeterminate={
                                                selectedZones.length > 0 &&
                                                selectedZones.length < zoneList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {zoneList && zoneList?.map((zone, index) => (
                                            <MenuItem
                                                className={selectedZones.includes(zone.Zone) ? 'georama- fs-14' : ''}
                                                disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={zone.Zone}
                                                onClick={() => handleZoneToggle(zone.Zone)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedZones.includes(zone.Zone)}
                                                />

                                                {zone.Zone}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"} gap={1}>
                                        <Button
                                            // disabled={selectedZones.length === 0}
                                            fullWidth
                                            size="small"
                                            onClick={() => {
                                                if (selectedZones.length > 0) {
                                                    handleClearFilters("zone");
                                                    setZoneSelectOpen(false);
                                                }
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 2,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            // disabled={selectedZones.length === 0}
                                            variant="contained"
                                            fullWidth
                                            className='btn-common-red'
                                            size="small"
                                            sx={{ textAlign: "center", mr: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedZones.length > 0) {
                                                    setPage(1);
                                                    setFiltersVersion((v) => v + 1);
                                                    setZoneSelectOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            {userDetails.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel id="state-label" className="dropdown-label">State</InputLabel>

                                <Select
                                    className='georama-Medium'
                                    labelId="state-label"
                                    id="state-select"
                                    multiple
                                    value={selectedStates}
                                    label="State"
                                    onChange={handleStateChange}
                                    open={stateSelectionOpen}
                                    onClose={() => setStateSelectionOpen(false)}
                                    onOpen={() => setStateSelectionOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === stateList?.length) return "All";
                                        return stateList
                                            .filter(data => selected.includes(data.State))
                                            ?.map(data => data.State)
                                            .join(',');
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                // maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                >
                                    <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                        onClick={() => handleStateToggle('all')}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedStates.length === stateList?.length}
                                            indeterminate={
                                                selectedStates.length > 0 &&
                                                selectedStates.length < stateList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {stateList && stateList?.map((data, index) => (
                                            <MenuItem
                                                className={selectedStates.includes(data.State) ? 'georama- fs-14' : ''}
                                                disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={data.State}
                                                onClick={() => handleStateToggle(data.State)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedStates.includes(data.State)}
                                                />

                                                {data.State}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"} gap={1}>
                                        <Button
                                            // disabled={selectedStates.length === 0}
                                            size="small"
                                            fullWidth
                                            onClick={() => {
                                                if (selectedStates.length > 0) {
                                                    handleClearFilters("state");
                                                    setStateSelectionOpen(false);
                                                }
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 2,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className='btn-common-red'
                                            fullWidth
                                            // disabled={selectedStates.length === 0}
                                            size="small"
                                            sx={{ textAlign: "center", mr: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedStates.length > 0) {
                                                    setPage(1);
                                                    setFiltersVersion((v) => v + 1);
                                                    setStateSelectionOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            {userDetails.roleType === "MIBL" && <FormControl
                                size="small"
                                sx={{
                                    width: 300,
                                    minWidth: 100,
                                    maxWidth: 100,
                                    backgroundColor: "#ffffff",
                                    borderRadius: 2,
                                }}
                            >
                                <InputLabel id="dealer-label" className="dropdown-label">
                                    Dealer
                                </InputLabel>

                                <Select
                                    className="georama-Medium"
                                    labelId="dealer-label"
                                    id="dealer-select"
                                    multiple
                                    value={selectedDealers}
                                    label="Dealer"
                                    open={dealerSelectOpen}
                                    onClose={() => setDealerSelectOpen(false)}
                                    onOpen={() => setDealerSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === dealerList?.length) return "All";
                                        return dealerList
                                            .filter((data) => selected.includes(data.dealer_id))
                                            ?.map((data) => data.dealer_name)
                                            .join(", ");
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                position: "fixed",
                                                zIndex: 1500,
                                                // width: 300,
                                            },
                                        },
                                    }}
                                >
                                    {/* 🔍 Search input (Autocomplete-like) */}
                                    <Box
                                        sx={{
                                            p: 1,
                                            position: "sticky",
                                            top: 0,
                                            background: "#fff",
                                            zIndex: 2,
                                        }}
                                    >
                                        <input
                                            type="text"
                                            placeholder="Search dealer..."
                                            value={dealerSearchText}
                                            onChange={(e) => setDealerSearchText(e.target.value)}
                                            onKeyDown={(e) => e.stopPropagation()}
                                            style={{
                                                width: "90%",
                                                padding: "6px 8px",
                                                borderRadius: "6px",
                                                border: "1px solid #ccc",
                                                fontSize: "13px",
                                            }}
                                        />
                                    </Box>

                                    {/* “All” Option */}
                                    <MenuItem
                                        disableGutters
                                        sx={{ py: 0, px: 1, m: 0 }}
                                        value="all"
                                        onClick={() => handleDealerToggle("all")}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                                "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                            }}
                                            checked={selectedDealers.length === dealerList?.length}
                                            indeterminate={
                                                selectedDealers.length > 0 &&
                                                selectedDealers.length < dealerList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    {/* Filtered Dealers */}
                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: "auto",
                                            pr: 1,
                                        }}
                                    >
                                        {filteredDealers && filteredDealers.length > 0 ? (
                                            filteredDealers?.map((data, index) => (
                                                <MenuItem
                                                    disableGutters
                                                    sx={{ py: 0, px: 1, m: 0 }}
                                                    key={index}
                                                    value={data.dealer_id}
                                                    onClick={() => handleDealerToggle(data.dealer_id)}
                                                >
                                                    <Checkbox
                                                        sx={{
                                                            "&.Mui-checked": { color: "#e53935" },
                                                            "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                        }}
                                                        checked={selectedDealers.includes(data.dealer_id)}
                                                    />
                                                    {data.dealer_name}
                                                </MenuItem>
                                            ))
                                        ) : (
                                            <MenuItem disabled>No results found</MenuItem>
                                        )}
                                    </Box>

                                    {/* Buttons */}
                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            fullWidth
                                            size="small"
                                            onClick={() => {
                                                if (selectedDealers.length > 0) {
                                                    handleClearFilters("dealer");
                                                    setDealerSelectOpen(false);
                                                    setDealerSearchText("");
                                                }
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                mx: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className="btn-common-red"
                                            size="small"
                                            fullWidth
                                            sx={{ textAlign: "center", mx: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedDealers.length > 0) {
                                                    setPage(1);
                                                    setFiltersVersion((v) => v + 1);
                                                    setDealerSelectOpen(false);
                                                    setDealerSearchText("");
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            <FormControl className='' size="small" sx={{ minWidth: 110, maxWidth: 110, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel id="segment-label" className="dropdown-label">segment</InputLabel>

                                <Select
                                    className='georama-Medium'
                                    labelId="segment-label"
                                    id="segment-select"
                                    multiple
                                    value={selectedSegments}
                                    label="segment"
                                    onChange={handleSegmentChange}
                                    open={segmentSelectOpen}
                                    onClose={() => setSegmentSelectOpen(false)}
                                    onOpen={() => setSegmentSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === segmentData?.length) return "All";
                                        return segmentData
                                            .filter(seg => selected.includes(seg.segment))
                                            ?.map(seg => seg.segment)
                                            .join(',');
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                // maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                >
                                    <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                        onClick={() => handleSegmentToggle('all')}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedSegments.length === segmentData?.length}
                                            indeterminate={
                                                selectedSegments.length > 0 &&
                                                selectedSegments.length < segmentData.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {segmentData && segmentData?.map((seg, index) => (
                                            <MenuItem
                                                className={selectedSegments.includes(seg.segment) ? 'georama- fs-14' : ''}
                                                disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={seg.segment}
                                                onClick={() => handleSegmentToggle(seg.segment)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedSegments.includes(seg.segment)}
                                                />

                                                {seg.segment}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"} gap={1}>
                                        <Button
                                            // disabled={selectedSegments.length === 0}
                                            fullWidth
                                            variant="contained"
                                            size="small"
                                            onClick={() => {
                                                if (selectedSegments.length > 0) {
                                                    handleClearFilters("segment");
                                                    setSegmentSelectOpen(false);
                                                }
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 2,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent',
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            // disabled={selectedSegments.length === 0}
                                            fullWidth
                                            className='btn-common-red'
                                            size="small"
                                            sx={{ mr: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedSegments.length > 0) {
                                                    setPage(1);
                                                    setFiltersVersion((v) => v + 1);
                                                    setSegmentSelectOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>

                            <Box>
                                <Button className='bg-white text-gray text-capitalize border-light-gray border-radius-8' ref={anchorRef} onClick={() => setOpen(true)}>
                                    <img className='px-1' src={dateFilter} alt="" />
                                    <Typography className="dropdown-label" mt={0.5} px={1}>Date Range</Typography>
                                </Button>

                                <CustomDateRange
                                    open={open}
                                    anchorRef={anchorRef}
                                    setOpen={setOpen}
                                    setDate={(date) => {
                                        setPage(1);
                                        setDateSelected(date);
                                        setFiltersVersion((v) => v + 1);
                                    }}
                                    onChange={undefined}
                                    clearDate={() => {
                                        isDateClearingRef.current = true;
                                        setPage(1);
                                        setDateSelected("");
                                        setFiltersVersion((v) => v + 1);
                                        setOpen(false);
                                        // fetchapi({ isReset: true });
                                    }}
                                />
                            </Box>
                        </Box>
                    </Box>
                </Box>

                <Box mx={isMobile ? 1.5 : 2} mb={1.5} className="bg-white border-radius-8">
                    <Box display={"flex"} flexWrap={"wrap"} mr={2} alignItems={"center"} justifyContent={"space-between"} py={1}>
                        <Box display={'flex'} alignItems="center" justifyContent={"space-between"} ml={2}>
                            <img src={leaderBoardSvg} alt="Leaderboard" />
                            <Typography px={1} className={`georama-SemiBold ${isMobile ? "fs-12" : "fs-16"}`}>Leaderboard Summary</Typography>
                        </Box>
                        <Box display={'flex'} gap={isMobile ? 1 : 0} flexWrap={"wrap"} alignItems="center" justifyContent={isMobile ? "start" : "space-between"} ml={2}>
                            <Button
                                sx={{ mt: isMobile ? 1 : 0 }}
                                // disabled={!rows.length}
                                onClick={() => downloadExcelData("")}
                                endIcon={<FileDownloadIcon />}
                                className="btn-common-red"
                            >
                                Download
                            </Button>
                            <ToggleButtonGroup
                                exclusive
                                size="small"
                                value={ratioType}
                                onChange={(e, value) => {
                                    if (!value) return;

                                    if (value === "Conversion Rate") {
                                        setRatioType("Conversion Rate");
                                    } else {
                                        setRatioType("Retention Rate");
                                    }
                                }}
                                sx={{ bgcolor: "#C4C5CC", display: "inline-flex", mx: isMobile ? 0 : 2, border: '1px solid #cccccc', borderRadius: '100px !important' }}
                            >
                                <ToggleButton
                                    value="Conversion Rate"
                                    className="text-capitalize fw-500 georama-Medium fs-13"
                                    sx={{
                                        width: 130,
                                        minWidth: 130,
                                        py: 0.5,
                                        px: 2.5,
                                        m: 0.3,
                                        textTransform: "none",
                                        borderRadius: "100px !important",
                                        border: "0 !important",
                                        color: "black",
                                        display: "flex",
                                        flexDirection: "row",
                                        alignItems: "center",
                                        justifyContent: "space-between",
                                        gap: 1,
                                        "&.Mui-selected": {
                                            backgroundColor: "#E31837 !important",
                                            color: "#fff !important",
                                        },
                                    }}
                                >
                                    <Typography className='fs-12 fw-500' lineHeight={1.2}>
                                        Conversion Ratio (%)
                                    </Typography>
                                    <Tooltip title="(Policy Secured Against Leads Contacted / Leads Contacted) × 100" arrow>
                                        <InfoOutlinedIcon sx={{ fontSize: 14 }} />
                                    </Tooltip>
                                </ToggleButton>

                                <ToggleButton
                                    value="Retention Rate"
                                    className="text-capitalize  fs-13"
                                    sx={{
                                        width: 130,
                                        minWidth: 130,
                                        py: 0.5,
                                        px: 2.5,
                                        m: 0.3,
                                        textTransform: "none",
                                        borderRadius: "100px !important",
                                        border: "0 !important",
                                        color: "black",
                                        display: "flex",
                                        flexDirection: "row",
                                        alignItems: "center",
                                        justifyContent: "space-between",
                                        gap: 1,
                                        "&.Mui-selected": {
                                            backgroundColor: "#E31837 !important",
                                            color: "#fff !important",
                                        },
                                    }}
                                >
                                    <Typography className='fs-12 fw-500' lineHeight={1.2}>
                                        Retention Ratio (%)
                                    </Typography>
                                    <Tooltip title="(Policies Secured / Eligible Leads) × 100" arrow>
                                        <InfoOutlinedIcon sx={{ fontSize: 14 }} />
                                    </Tooltip>
                                </ToggleButton>
                            </ToggleButtonGroup>
                            <FormControl size="small" sx={{ minWidth: 230, maxWidth: 230 }}>
                                {/* <InputLabel>Filter</InputLabel> */}
                                <Select
                                    value={rankFilter}
                                    // label="Filter"
                                    onChange={(e) => setRankFilter(e.target.value)}
                                    displayEmpty
                                    sx={{
                                        "& .MuiOutlinedInput-notchedOutline": {
                                            border: "1px solid #E0E0E0",
                                        },
                                        "&:hover .MuiOutlinedInput-notchedOutline": {
                                            border: "1px solid #E0E0E0",
                                        },
                                        "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                            border: "1px solid #E0E0E0",
                                        },
                                    }}
                                >
                                    {/* Default option */}
                                    <MenuItem value="">
                                        <span>Select</span>
                                    </MenuItem>

                                    <MenuItem value="Top Converter / Conversion Rate">
                                        Top Converter / Conversion Rate
                                    </MenuItem>

                                    <MenuItem value="Swift Converter">
                                        Swift Converter
                                    </MenuItem>

                                    <MenuItem value="AddOn Sales">
                                        Top Add-on Seller Number of Add-ons
                                        and Add-On Premium
                                    </MenuItem>

                                    <MenuItem value="Net Premium Leader">
                                        Net Premium Leader
                                    </MenuItem>

                                    <MenuItem value="Follow-up">
                                        Follow-up
                                    </MenuItem>
                                </Select>
                            </FormControl>
                        </Box>
                    </Box>

                    <Divider />

                    <Box position="relative" overflow={'hidden'}>
                        {/* ===================== TABLE ===================== */}
                        <TableContainer
                            component={Box}
                            sx={{
                                mt: 1,
                                // px: 1,
                                overflowX: "auto",
                                // overflow: 'hidden',
                                maxWidth: userDetails?.roleType === "MIBL" ? "1250px" : "100%",
                                minWidth: "100%",

                                /* Force smooth scrolling */
                                WebkitOverflowScrolling: "touch",

                                /* ===== Scrollbar ===== */
                                "&::-webkit-scrollbar": {
                                    height: "1px",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                    backgroundColor: "#999",
                                    borderRadius: "10px",
                                },
                                "&::-webkit-scrollbar-track": {
                                    background: "transparent",
                                },

                                "&:hover::-webkit-scrollbar-thumb": {
                                    backgroundColor: "#999",
                                },

                                scrollbarColor: "#999 transparent",
                            }}>
                            <Table
                                sx={{
                                    px: 1,
                                    // minWidth: 1200,
                                    // overflow: 'hidden',
                                    borderCollapse: "separate",
                                    borderSpacing: "0 4px",
                                }}
                                stickyHeader
                            >

                                {/* -------- Header -------- */}
                                <TableHead>
                                    <TableRow
                                        sx={{
                                            "& th": {
                                                lineHeight: "1.3em",
                                                borderBottom: "none",
                                                backgroundColor: "#fff",
                                            },
                                            "& th:first-of-type": {
                                                borderTopLeftRadius: "8px",
                                                borderBottomLeftRadius: "8px",
                                            },
                                            "& th:last-of-type": {
                                                borderTopRightRadius: "8px",
                                                borderBottomRightRadius: "8px",
                                            },
                                        }}
                                    >
                                        <TableCell sx={{ minWidth: 150, maxWidth: 150 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            {userDetails?.roleType === "DEALER" ? "Agent Name" : "Dealer Name"}
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Leads Assigned
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Leads Contacted
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Policies Converted
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Net Premium Collected (INR)
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Follow up efficiency (%)
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 40, maxWidth: 40 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            {ratioType === "Conversion Rate" ? "Conversion Ratio (%)" : "Retention Ratio (%)"}
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Rank
                                        </TableCell>

                                    </TableRow>
                                </TableHead>

                                {/* -------- Body -------- */}
                                <TableBody>
                                    {loading ? (
                                        [...Array(8)].map((_, idx) => (
                                            <TableRow key={idx}>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            </TableRow>
                                        ))
                                    ) : (dealerListData && dealerListData.length > 0 ? (
                                        dealerListData?.map((row, index) => (
                                            <React.Fragment key={index}>
                                                {/* -------- Dealer Row -------- */}
                                                <TableRow
                                                    // hover
                                                    sx={{
                                                        backgroundColor: openRow === index ? "#F0F1F5" : "#FFF",
                                                        borderRadius: 2,
                                                        boxShadow: 'none',
                                                        border: openRow === index ? "1px solid #DADDE5" : "1px solid #F0F1F5",
                                                        transition: "all 0.2s ease",
                                                        "& td": {
                                                            borderTop: "1px solid #F0F1F5",
                                                            borderBottom: "1px solid #F0F1F5"
                                                        },
                                                        "& td:first-of-type": {
                                                            borderLeft: "1px solid #F0F1F5",
                                                            borderTopLeftRadius: "8px",
                                                            borderBottomLeftRadius: openRow === index ? "0px" : "8px"
                                                        },
                                                        "& td:last-of-type": {
                                                            borderRight: "1px solid #F0F1F5",
                                                            borderTopRightRadius: "8px",
                                                            borderBottomRightRadius: openRow === index ? "0px" : "8px"
                                                        }
                                                    }}
                                                >
                                                    <TableCell sx={{ minWidth: 150, maxWidth: 150, backgroundColor: openRow === index ? "#F0F1F5" : "#FFF" }} className="georama-Regular fs-12">
                                                        <Box display="flex" alignItems="center" gap={1}>
                                                            {userDetails?.roleType !== "DEALER" && (
                                                                <IconButton
                                                                    size="small"
                                                                    onClick={() => handleToggleAccordion(index, row)}>
                                                                    {openRow === index
                                                                        ? <KeyboardArrowUpIcon fontSize="small" />
                                                                        : <KeyboardArrowDownIcon fontSize="small" />}
                                                                </IconButton>
                                                            )}
                                                            <span>
                                                                {userDetails?.roleType === "DEALER"
                                                                    ? row.agentName
                                                                    : row.dealerName}
                                                            </span>
                                                        </Box>
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                        {row.leadsAssigned || 0}
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                        {row.leadsContacted || 0}
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                        {row.policiesConverted || 0}
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                        {row.netPremium || 0}
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                        {row.followup || 0}%
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 40, maxWidth: 40 }} className="georama-Regular fs-12">
                                                        {row.conversionRatio || 0}%
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                        {row.rankPosition || 0}
                                                    </TableCell>

                                                </TableRow>

                                                {/* -------- Accordion Row -------- */}
                                                {openRow === index && dealerAgents[row.dealerCode] && (() => {

                                                    const currentPage = agentPage[row.dealerCode] || 1;

                                                    const paginatedAgents = dealerAgents[row.dealerCode] || [];

                                                    return (
                                                        <TableRow className="td-table"
                                                            sx={{
                                                                position: "relative",
                                                                top: "-4px",
                                                                zIndex: 1,
                                                            }}>
                                                            <TableCell colSpan={12} sx={{ p: 0, m: 0 }}>
                                                                <Table
                                                                    size="small"
                                                                    sx={{
                                                                        width: "100%",
                                                                    }}
                                                                >
                                                                    <TableBody>
                                                                        {paginatedAgents && paginatedAgents.length > 0 ? (
                                                                            paginatedAgents?.map((agent, i) => (
                                                                                <TableRow key={i}
                                                                                    sx={{
                                                                                        border: "1px solid #F0F1F5"
                                                                                    }}
                                                                                >
                                                                                    <TableCell sx={{ minWidth: 150, maxWidth: 150 }} className="georama-Regular fs-12">
                                                                                        {agent.agentName}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                                                        {agent.leadsAssigned || 0}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                                                        {agent.leadsContacted || 0}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                                                        {agent.policiesConverted || 0}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                                                        {agent.netPremium || 0}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                                                        {agent.followup || 0}%
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 40, maxWidth: 40 }} className="georama-Regular fs-12">
                                                                                        {agent.conversionRatio || 0}%
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                                                        {agent.rankPosition || 0}
                                                                                    </TableCell>
                                                                                </TableRow>
                                                                            ))
                                                                        ) : (
                                                                            <TableRow className='no-td'>
                                                                                <TableCell colSpan={12} align="center" sx={{ py: 3, borderBottom: agentPagination == 0 ? "none" : "" }}>
                                                                                    No Data found
                                                                                </TableCell>
                                                                            </TableRow>
                                                                        )}
                                                                    </TableBody>
                                                                </Table>

                                                                {/* -------- Agent Pagination -------- */}
                                                                {!!agentPagination && (
                                                                    <Box
                                                                        display="flex"
                                                                        justifyContent="flex-end"
                                                                        alignItems="center"
                                                                        p={1.5}
                                                                    >
                                                                        <Pagination
                                                                            size="small"
                                                                            count={Math.ceil(agentPagination / agentLimit)}
                                                                            page={currentPage}
                                                                            onChange={(e, v) => {
                                                                                setAgentPage(prev => ({
                                                                                    ...prev,
                                                                                    [row.dealerCode]: v
                                                                                }))
                                                                                fetchDealerAgents(row.dealerCode, dateSelected, v, agentLimit);
                                                                            }
                                                                            }
                                                                            shape="rounded"
                                                                            sx={{
                                                                                '& .MuiPaginationItem-root': {
                                                                                    borderRadius: 3
                                                                                }
                                                                            }}
                                                                        />
                                                                    </Box>
                                                                )}
                                                            </TableCell>
                                                        </TableRow>
                                                    );
                                                })()}
                                            </React.Fragment>
                                        ))
                                    ) : (!dealerListData || !dealerListData?.length) && (
                                        <TableRow>
                                            <TableCell colSpan={12} align="center" sx={{ py: 3, borderBottom: dealerPagination == 0 ? "none" : "" }}>
                                                No Data found
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>

                        {/* ===================== PAGINATION ===================== */}
                        {!!dealerPagination && <Box className="table-body-bg border-radius-bottom-8" display="flex" justifyContent="space-between" alignItems="end" p={1.5} px={2.5}>
                            <Pagination
                                className="bg-white"
                                size="medium"
                                count={Math.ceil(dealerPagination / limit)}
                                page={page} onChange={(e, v) => setPage(v)}
                                shape="rounded"
                                sx={{
                                    float: 'right',
                                    ml: "auto",
                                    '& .MuiPaginationItem-root': {
                                        borderRadius: 3,
                                    },
                                }}
                            />
                        </Box>}
                    </Box>

                    {/* ===================== PAGINATION ===================== */}
                </Box>

                <Box px={1} mx={isMobile ? 0.5 : 1}>
                    <Grid container rowSpacing={0.5} columnSpacing={1.8}>
                        <Grid size={{ xs: 12, md: 6, lg: 6 }}>
                            <Grid py={1.8} my={isMobile ? 0.3 : 0.7} borderRadius={2} className="bg-white" size={12} item xs={12} md={12}>
                                <Box>
                                    {/* Header */}
                                    <Box display={'flex'} textAlign={"center"} alignItems={'center'} gap={1} mb={2} mx={2}>
                                        <img src={churchSvg} alt="" />
                                        <Typography className="georama-SemiBold fs-14">
                                            Best In India (Dealers)
                                        </Typography>
                                    </Box>
                                    <Divider />
                                    <Grid
                                        container
                                        spacing={2.5}
                                        mx={2}
                                        sx={{
                                            mt: 2,
                                            display: "flex",
                                            alignItems: isMobile ? "start" : "center",
                                            justifyContent: "space-between",
                                            flexWrap: "wrap"
                                        }}
                                    >
                                        {leaderboardLoading
                                            ? Array.from({
                                                length: bestinIndia.length > 3 ? 4 : 3
                                            }).map((_, index) => (
                                                <Grid
                                                    key={index}
                                                    size={{
                                                        xs: 12,
                                                        sm: 6,
                                                        md: bestinIndia.length > 3 ? 3 : 4
                                                    }}
                                                >
                                                    <Box
                                                        sx={{
                                                            height: 220,
                                                            border: "1px solid #FFF5D6",
                                                            borderRadius: 2,
                                                            display: "flex",
                                                            flexDirection: isMobile ? "row" : "column",
                                                            alignItems: "center",
                                                            justifyContent: "center",
                                                            gap: 1.5,
                                                            my: 1,
                                                            py: 3,
                                                            px: 2
                                                        }}
                                                    >
                                                        {/* Rank */}
                                                        <Skeleton
                                                            variant="text"
                                                            width={80}
                                                            height={30}
                                                        />

                                                        {/* Medal/Icon */}
                                                        <Skeleton
                                                            variant="circular"
                                                            width={60}
                                                            height={60}
                                                        />

                                                        {/* Dealer Name */}
                                                        <Box width="100%">
                                                            <Skeleton
                                                                variant="text"
                                                                width="100%"
                                                                height={28}
                                                            />
                                                            <Skeleton
                                                                variant="text"
                                                                width="80%"
                                                                height={28}
                                                                sx={{ mx: "auto" }}
                                                            />
                                                        </Box>
                                                    </Box>
                                                </Grid>
                                            ))
                                            : indiaData?.map((item, index) => {
                                                const rank = item.agent_rank || index + 1;

                                                const borderColor =
                                                    userDetails?.dealerCode === item?.dealer_code
                                                        ? rankConfig[rank]?.color
                                                        : null;

                                                return (
                                                    <Grid
                                                        key={rank}
                                                        size={{
                                                            xs: 12,
                                                            sm: 6,
                                                            md: bestinIndia.length > 3 ? 3 : 4
                                                        }}
                                                        sx={{
                                                            height: 220,
                                                            border: "1px solid #FFF5D6",
                                                            borderTop: borderColor
                                                                ? `5px solid ${borderColor}`
                                                                : "1px solid #FFF5D6",
                                                            borderRadius: 2,
                                                            display: "flex",
                                                            flexDirection: isMobile
                                                                ? "row"
                                                                : "column",
                                                            alignItems: isMobile
                                                                ? "start"
                                                                : "center",
                                                            justifyContent: "center",
                                                            gap: 1,
                                                            my: 1,
                                                            py: 3,
                                                            px: 1
                                                        }}
                                                    >
                                                        <Typography
                                                            className={`georama-Medium fs-14 ${rankConfig[rank]?.class || ""
                                                                }`}
                                                        >
                                                            Rank {rank}
                                                        </Typography>

                                                        <Box>
                                                            <img
                                                                src={
                                                                    index == 3
                                                                        ? rankSvg
                                                                        : rankConfig[rank]?.icon
                                                                }
                                                                alt=""
                                                            />
                                                        </Box>

                                                        <Typography
                                                            className="georama-SemiBold fs-14 text-center"
                                                            sx={{
                                                                maxWidth: isMobile
                                                                    ? "100%"
                                                                    : 140,
                                                                minHeight: 60,
                                                                wordBreak: "break-word",
                                                                textAlign: isMobile
                                                                    ? "left"
                                                                    : "center"
                                                            }}
                                                        >
                                                            {item?.dealer || "N/A"}
                                                        </Typography>
                                                    </Grid>
                                                );
                                            })}
                                    </Grid>
                                    <Box sx={{ mx: 2 }}>
                                        <Typography className="georama-Medium fs-14" mb={1}>
                                            Penetration level
                                        </Typography>

                                        {penetrationData?.map((item, index) => (
                                            <Box key={index} mb={2}>
                                                <Box
                                                    display="flex"
                                                    justifyContent="space-between"
                                                    alignItems="center"
                                                    mb={0.5}
                                                >
                                                    <Typography className="georama-Regular fs-12 text-gray">
                                                        {item.label}
                                                    </Typography>

                                                    <Typography
                                                        className="georama-Medium fs-12"
                                                        sx={{ color: item.color }}
                                                    >
                                                        {item.value}%
                                                    </Typography>
                                                </Box>

                                                <LinearProgress
                                                    variant="determinate"
                                                    value={animateProgress ? item.value : 0}
                                                    sx={{
                                                        height: 6,
                                                        borderRadius: 10,
                                                        backgroundColor: "#eeeeee",
                                                        "& .MuiLinearProgress-bar": {
                                                            backgroundColor: item.color,
                                                            borderRadius: 10,
                                                            transition: "transform 1.2s ease-in-out"
                                                        }
                                                    }}
                                                />

                                            </Box>
                                        ))}
                                    </Box>
                                </Box>
                            </Grid>
                        </Grid>
                        <Grid size={{ xs: 12, md: 6, lg: 6 }}>
                            <Grid py={1.8} my={isMobile ? 0.3 : 0.7} borderRadius={2} className="bg-white" size={12} item xs={12} md={12}>
                                <Box>
                                    <Box display={'flex'} gap={1} mb={2} mx={2}>
                                        <img src={churchSvg} alt="" />
                                        <Typography className="georama-SemiBold fs-14">Best In Zone/State (Dealers)</Typography>
                                    </Box>
                                    <Divider />
                                    <Grid
                                        container
                                        spacing={2.5}
                                        mx={2}
                                        sx={{
                                            mt: 2,
                                            display: "flex",
                                            alignItems: isMobile ? "start" : "center",
                                            justifyContent: "space-between",
                                            flexWrap: "wrap",
                                        }}
                                    >
                                        {leaderboardLoading
                                            ? Array.from({
                                                length: bestinZone.length > 3 ? 4 : 3
                                            }).map((_, index) => (
                                                <Grid
                                                    key={index}
                                                    size={{
                                                        xs: 12,
                                                        sm: 6,
                                                        md: bestinZone.length > 3 ? 3 : 4
                                                    }}
                                                >
                                                    <Box
                                                        sx={{
                                                            height: 220,
                                                            border: "1px solid #FFF5D6",
                                                            borderRadius: 2,
                                                            display: "flex",
                                                            flexDirection: isMobile ? "row" : "column",
                                                            alignItems: "center",
                                                            justifyContent: "center",
                                                            gap: 1.5,
                                                            mb: 1,
                                                            py: 3,
                                                            px: 2
                                                        }}
                                                    >
                                                        {/* Rank */}
                                                        <Skeleton
                                                            variant="text"
                                                            width={80}
                                                            height={30}
                                                        />

                                                        {/* Medal/Icon */}
                                                        <Skeleton
                                                            variant="circular"
                                                            width={60}
                                                            height={60}
                                                        />

                                                        {/* Dealer Name */}
                                                        <Box width="100%">
                                                            <Skeleton
                                                                variant="text"
                                                                width="100%"
                                                                height={28}
                                                            />
                                                            <Skeleton
                                                                variant="text"
                                                                width="80%"
                                                                height={28}
                                                                sx={{ mx: "auto" }}
                                                            />
                                                        </Box>
                                                    </Box>
                                                </Grid>
                                            ))
                                            : zoneData?.map((item, index) => {
                                                const rank = item.agent_rank || index + 1;

                                                const borderColor =
                                                    userDetails?.dealerCode === item?.dealer_code
                                                        ? rankConfig[rank]?.color
                                                        : null;

                                                return (
                                                    <Grid
                                                        key={rank}
                                                        size={{
                                                            xs: 12,
                                                            sm: 6,
                                                            md: bestinZone.length > 3 ? 3 : 4
                                                        }}
                                                        sx={{
                                                            height: 220,
                                                            border: "1px solid #FFF5D6",
                                                            borderTop: borderColor
                                                                ? `5px solid ${borderColor}`
                                                                : "1px solid #FFF5D6",
                                                            borderRadius: 2,
                                                            display: "flex",
                                                            flexDirection: isMobile
                                                                ? "row"
                                                                : "column",
                                                            alignItems: isMobile
                                                                ? "start"
                                                                : "center",
                                                            justifyContent: "center",
                                                            gap: 1,
                                                            mb: 1,
                                                            py: 3,
                                                            px: 1
                                                        }}
                                                    >
                                                        <Typography
                                                            className={`georama-Medium fs-14 ${rankConfig[rank]?.class || ""
                                                                }`}
                                                        >
                                                            Rank {rank}
                                                        </Typography>

                                                        <Box>
                                                            <img
                                                                src={
                                                                    index == 3
                                                                        ? rankSvg
                                                                        : rankConfig[rank]?.icon
                                                                }
                                                                alt=""
                                                            />
                                                        </Box>

                                                        <Typography
                                                            className="georama-SemiBold fs-14 text-center"
                                                            sx={{
                                                                maxWidth: isMobile
                                                                    ? "100%"
                                                                    : 140,
                                                                minHeight: 60,
                                                                wordBreak: "break-word",
                                                                textAlign: isMobile
                                                                    ? "left"
                                                                    : "center"
                                                            }}
                                                        >
                                                            {item?.dealer || "N/A"}
                                                        </Typography>
                                                    </Grid>
                                                );
                                            })}
                                    </Grid>
                                    <Box sx={{ mx: 2 }}>
                                        <Typography className="georama-Medium fs-14" mb={1}>
                                            Penetration level
                                        </Typography>

                                        {zonePenetrationData?.map((item, index) => (
                                            <Box key={index} mb={2}>

                                                <Box
                                                    display="flex"
                                                    justifyContent="space-between"
                                                    alignItems="center"
                                                    mb={0.5}
                                                >

                                                    <Typography className="georama-Regular fs-12 text-gray">
                                                        {item.label}
                                                    </Typography>

                                                    <Typography
                                                        className="georama-Medium fs-12"
                                                        sx={{ color: item.color }}
                                                    >
                                                        {item.value}%
                                                    </Typography>

                                                </Box>

                                                <LinearProgress
                                                    variant="determinate"
                                                    value={animateProgress ? item.value : 0}
                                                    sx={{
                                                        height: 6,
                                                        borderRadius: 10,
                                                        backgroundColor: "#eeeeee",
                                                        "& .MuiLinearProgress-bar": {
                                                            backgroundColor: item.color,
                                                            borderRadius: 10,
                                                            transition: "transform 1.2s ease-in-out"
                                                        }
                                                    }}
                                                />
                                            </Box>
                                        ))}
                                    </Box>
                                </Box>
                            </Grid>
                        </Grid>
                    </Grid>
                </Box>
            </Paper>
        </>
    );
};

export default LeaderBoard;