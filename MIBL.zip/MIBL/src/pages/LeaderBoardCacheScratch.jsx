import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { setLeaderboardCacheEntry } from "../redux/slices/leaderboardCacheSlice";
import { fetchLeaderBoardData } from "../services/api";

const normalize = (value) => {
    if (Array.isArray(value)) return value.map(normalize);
    if (value && typeof value === "object") {
        return Object.keys(value).sort().reduce((acc, key) => {
            acc[key] = normalize(value[key]);
            return acc;
        }, {});
    }
    return value;
};

const buildKey = (scope, payload) => `${scope}::${JSON.stringify(normalize(payload))}`;

const isFresh = (entry) => entry && (entry.expiresAt || 0) > Date.now();

const LeaderBoardCacheScratch = () => {
    const dispatch = useDispatch();
    const cacheEntries = useSelector((state) => state.leaderboardCache?.entries || {});

    const getLeaderboardWithCache = async (payload) => {
        const key = buildKey("leaderboard-data", payload);
        const cached = cacheEntries[key];
        if (isFresh(cached)) {
            return cached.data;
        }

        const response = await fetchLeaderBoardData(payload);
        if (response?.status_code === "200") {
            dispatch(setLeaderboardCacheEntry({
                key,
                data: response,
                ttlMs: 2 * 60 * 1000
            }));
        }
        return response;
    };

    const onApplyFilters = async () => {
        const payload = {
            type: "LeaderBoardfilter",
            renewalCategory: "",
            zone: "",
            state: "",
            dealerCode: "",
            fromDate: "",
            toDate: "",
            roleType: "MIBL",
            loginUserId: 123,
            segment: "",
            limit: 10,
            offset: 1
        };

        const response = await getLeaderboardWithCache(payload);
        console.log("Leaderboard response:", response);
    };

    return (
        <div>
            <h3>Leaderboard Cache Scratch</h3>
            <button onClick={onApplyFilters}>Apply Filters</button>
        </div>
    );
};

export default LeaderBoardCacheScratch;
