import { Box, Button, IconButton, Pagination, Paper, Skeleton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, useMediaQuery } from "@mui/material";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { deleteBucket, getBucketList } from "../services/api";
import { useAuth } from "../services/useAuth";
import { useSelector } from "react-redux";
import { encryptRoute } from "../services/encrypt";
import BackdropLoader from "../components/Loader/BackdropLoader";
import viewImg from "../assets/images/viewImg.svg";
import editUser from "../assets/images/editUser.svg";
import { toast, ToastContainer } from "react-toastify";
import DeleteIcon from '@mui/icons-material/Delete';
import { Dialog, DialogTitle, DialogContent, DialogActions } from "@mui/material";


export default function LeadPoolList() {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const navigate = useNavigate();
    const [leadPoolData, setLeadPoolData] = useState([]);
    const [limit, setLimit] = useState(10);
    const [count, setCount] = useState(0);
    const [page, setPage] = useState(1);
    const { user_id, roleId, dealerCode, parentCode, roleType } = useAuth().user;
    const allowedUrls = useSelector((state) => state?.user?.featureAccess.map(fa => fa.Url));
    const [loading, setLoading] = useState(false);

    const [open, setOpen] = useState(false);
    const [selectedId, setSelectedId] = useState(null);

    const handleOpenModal = (id) => {
        setSelectedId(id);
        setOpen(true);
    };

    const handleCloseModal = () => {
        setOpen(false);
        setSelectedId(null);
    };


    useEffect(() => {
        fetchData();
    }, [page]);

    const fetchData = async () => {
        let payload = {};
        if (roleType === 'MIBL') payload = { roleType, limit, offset: page };
        else payload = { dealerCode, parentCode, limit, offset: page };

        setLoading(true);
        try {
            let response = await getBucketList(payload);
            if (response.statusCode === '200') {
                setLeadPoolData(response?.data?.dealerBuckets);
                if (response?.data?.dealerBucketsCount[0]?.bucket_count) setCount(response?.data?.dealerBucketsCount[0]?.bucket_count);
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    const handleConfirmDelete = async () => {
        try {
            const response = await deleteBucket({ bucketId: selectedId }, selectedId);

            if (response.status_code === "200") {
                toast.success(response.status_message);
                fetchData();
            } else {
                toast.error("Failed to delete");
            }
        } catch (error) {
            console.error(error);
            toast.error("Something went wrong!");
        } finally {
            handleCloseModal();
        }
    };

    return (
        <>
            <BackdropLoader loading={loading} />

            <Paper className="table-auto-width" sx={{ m: isMobile ? 1.5 : 2, borderRadius: 2, boxShadow: "none" }}>
                <Box px={2} py={2} display='flex' alignItems="center" justifyContent="space-between">
                    <Typography className={`${isMobile ? 'fs-16' : 'fs-24'} georama-SemiBold`}>
                        Lead Pool List
                    </Typography>

                    {allowedUrls.includes('/leadpool/create') &&
                        <Button className="btn-common-red"
                            onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/leadpool/create'))}`)}
                        >
                            Add New
                        </Button>
                    }
                </Box>

                <TableContainer component={Box} sx={{ mt: 0 }}>
                    <Table sx={{ tableLayout: 'auto', width: '100%' }}>
                        <TableHead>
                            <TableRow>
                                <TableCell
                                    className={`${isMobile ? 'fs-12 p-3' : 'fs-16'} georama-Medium body-formbg fw-none`}
                                >
                                    Lead Pool Name
                                </TableCell>

                                <TableCell
                                    className={`${isMobile ? 'fs-12 p-3' : 'fs-16'} georama-Medium body-formbg fw-none`}
                                >
                                    Location
                                </TableCell>

                                <TableCell
                                    className={`${isMobile ? 'fs-12 p-3' : 'fs-16'} georama-Medium body-formbg fw-none`}
                                >
                                    Action
                                </TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody className="table-body-bg">
                            {loading ? (
                                [...Array(8)].map((_, idx) => (
                                    <TableRow key={idx}>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                    </TableRow>
                                ))) : (leadPoolData && leadPoolData.length > 0 ?
                                    leadPoolData?.map((item, index) => (
                                        <TableRow key={index} sx={{ "&:hover": { backgroundColor: "#f5f5f5" } }}>
                                            <TableCell
                                                className=""
                                            >
                                                <span className="georama-Medium fs-14 text-truncate">
                                                    {item.bucket_name}
                                                </span>
                                            </TableCell>

                                            <TableCell
                                                className="georama-Regular"
                                            >
                                                {item.bucket_location}
                                            </TableCell>

                                            <TableCell
                                                sx={{ display: isMobile ? 'flex' : '' }}
                                                className="georama-Regular"
                                            >
                                                {
                                                    allowedUrls.includes('/leadpool/edit') &&
                                                    <IconButton sx={{ p: 0.5 }} onClick={() => navigate(
                                                        `/${encodeURIComponent(encryptRoute('/leadpool/edit'))}`, { state: { ...item, isEdit: true, isView: false } })}>
                                                        <img
                                                            src={editUser}
                                                            alt="edit"
                                                            style={{
                                                                width: 18,
                                                                height: 18,
                                                                transition: 'filter 0.2s ease',
                                                            }}
                                                        />
                                                    </IconButton>}
                                                {
                                                    allowedUrls.includes('/leadpool/view') &&
                                                    <IconButton sx={{ p: 0.5 }} onClick={() => navigate(
                                                        `/${encodeURIComponent(encryptRoute('/leadpool/view'))}`, { state: { ...item, isView: true } })}>
                                                        <img
                                                            src={viewImg}
                                                            alt="view"
                                                            style={{
                                                                width: 18,
                                                                height: 18,
                                                                transition: 'filter 0.2s ease',
                                                            }}
                                                        />
                                                    </IconButton>}

                                                <IconButton sx={{ p: 0.5 }} onClick={() => handleOpenModal(item.bucket_id)}>
                                                    <DeleteIcon />
                                                </IconButton>
                                            </TableCell>
                                        </TableRow>
                                    )) :
                                    (!leadPoolData || !leadPoolData?.length) && !loading && (
                                        <TableRow>
                                            <TableCell colSpan={3}><Box className="center-text">No Records Found.</Box></TableCell>
                                        </TableRow>
                                    ))}
                        </TableBody>
                    </Table>
                </TableContainer>

                <Box>
                    {/* <Typography display={'inline'}>Show result: </Typography>
                <Select size="small" sx={{ width: 75, borderRadius: 3, m: 1 }} value={limit} onChange={(e) => setLimit(e.target.value) || setPage(1)}>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={20}>20</MenuItem>
                    <MenuItem value={50}>50</MenuItem>
                    <MenuItem value={100}>100</MenuItem>
                </Select> */}

                    {!!count && <Pagination size="medium" count={Math.ceil(count / limit)} page={page} onChange={(e, v) => setPage(v)} shape="rounded"
                        sx={{
                            float: 'right', m: 1,
                            '& .MuiPaginationItem-root': {
                                borderRadius: 3,
                            }
                        }} />}
                </Box>
            </Paper>

            <ToastContainer autoClose={1000} />

            <Dialog open={open} onClose={handleCloseModal}>
                <DialogTitle>Confirm Delete</DialogTitle>
                <DialogContent>
                    Are you sure you want to delete this bucket?
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseModal}>Cancel</Button>
                    <Button onClick={handleConfirmDelete} color="error" variant="contained">
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
}