import { VisibilityOffOutlined, VisibilityOutlined } from '@mui/icons-material';
import CancelIcon from '@mui/icons-material/Cancel';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { Box, Button, Dialog, DialogContent, DialogTitle, FormHelperText, Grid, IconButton, Paper, Stack, TextField, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import logo from '../assets/images/M-BizDesk-logo.png';
import policyImg from '../assets/images/M-BizDesk-banner.jpg';
import BackdropLoader from "../components/Loader/BackdropLoader";
import { setCredFlag, setFetchUserByManager, setInputUser, setIsCaller, setLogin } from "../redux/slices/userSlice";
import { changePasswordUser, login, otpVerification, resetPasswordUser, sendOTP } from '../services/api';
import { encryptRoute } from '../services/encrypt';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiPaper-root': {
    borderRadius: 12,
    overflow: 'hidden',
  },
  '& .MuiDialogContent-root': {
    padding: theme.spacing(3),
    paddingTop: theme.spacing(2),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(2),
    justifyContent: 'center',
  },
}));

const DialogTitleWrapper = styled(DialogTitle)(({ theme }) => ({
  backgroundColor: '#e53935',
  color: '#fff',
  padding: theme.spacing(2),
  fontWeight: 600,
}));

const Login = () => {
  const isMobile = useMediaQuery('(min-width:600px)');
  const isMobileView = useMediaQuery('(min-width:320px) and (max-width:625px)');
  const isTabView = useMediaQuery('(min-width:626px) and (max-width:900px)');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({ email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [resetPassword, setResetPassword] = useState(false);
  const [changePassword, setChangePassword] = useState(false);
  const [otpShow, setOtpShow] = useState(false);
  const [rePassword, setRePassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const [forgotScreen, setForgotScreen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [openBox, setopenBox] = useState(false);
  const [loginType, setLoginType] = useState("Dealer");
  const [token, setToken] = useState("");

  const navigate = useNavigate();

  const user = useSelector((state) => state.user.loggedData);
  const isLoggedIn = useSelector((state) => state.user.loggedIn);
  // const token = useSelector((state) => state.user.token);
  const dispatch = useDispatch();

  const prevEmail = useRef('');
  const prevPassword = useRef('');

  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes
  const [isResendEnabled, setIsResendEnabled] = useState(false);

  useEffect(() => {
    dispatch({ type: 'RESET_ALL_STATE' });
  }, []);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft((prev) => prev - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setIsResendEnabled(true);
    }
  }, [timeLeft]);

  // useEffect(() => {
  //   if (timeLeft <= 0) {
  //     setIsResendEnabled(true);
  //     return;
  //   }

  //   const timer = setInterval(() => {
  //     setTimeLeft((prev) => prev - 1);
  //   }, 1000);

  //   return () => clearInterval(timer);
  // }, [timeLeft]);

  // const handleResend = () => {
  //   setTimeLeft(120); // reset timer
  //   setIsResendEnabled(false);
  //   handleSendOtp(); // your API call
  // };

  const formatTime = (seconds) => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };

  const handlePasswordChange = (e) => {
    const value = e.target.value.slice(0, 50);
    setPassword(value);

    const error = validatePassword(value);
    setErrors((prev) => ({ ...prev, password: error }));

    // If rePassword is already typed, re-validate match
    if (rePassword && value !== rePassword) {
      setErrors((prev) => ({ ...prev, rePassword: 'Passwords do not match.' }));
    } else {
      setErrors((prev) => ({ ...prev, rePassword: '' }));
    }
  };

  const handleRePasswordChange = (e) => {
    const value = e.target.value.slice(0, 50);
    setRePassword(value);

    if (value !== password) {
      setErrors((prev) => ({ ...prev, rePassword: 'Passwords do not match.' }));
    } else {
      setErrors((prev) => ({ ...prev, rePassword: '' }));
    }
  };

  const validateEmail = () => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const mobileRegex = /^[6-9]\d{9}$/;

    if (!email) return 'Email Id / Mobile Number is required.';
    // if (emailRegex.test(email)) return "";
    // if (mobileRegex.test(email)) return "";

    return "";
    // return "Enter a valid Email Id or Mobile No.";
  };

  const validateSAPCode = (sapCode = "") => {
    const trimmedCode = sapCode.trim();

    if (!trimmedCode) {
      return "SAP Code is required";
    }

    // if (!/^[0-9]+$/.test(trimmedCode)) {
    //   return "SAP Code must contain only numbers (0-9)";
    // }

    // if (trimmedCode.length < 1) {
    //   return "SAP Code must be at least 6 digits";
    // }
    // if (trimmedCode.length > 10) {
    //   return "SAP Code cannot exceed 10 digits";
    // }

    return "";
  };

  const validatePassword = () => {
    if (!password) return 'Password is required.';

    // if (password.length < 9 || password.length > 20) {
    if (password.length < 9) {
      return 'Password must be 9-20 characters long.';
      // return 'Password must be 9-20 characters long.';
    }

    // const hasUpperCase = /[A-Z]/.test(password);
    const hasAlphabet = /[a-zA-Z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecialChar = /[^A-Za-z0-9]/.test(password);

    if (!hasAlphabet || !hasNumber || !hasSpecialChar) {
      return 'Password must contain at least 1 uppercase letter, 1 number, and 1 special character.';
    }
    return '';
  };

  const validate = () => {
    let tempErrors;
    if (loginType === "Dealer") {
      tempErrors = {
        email: validateEmail(),
        password: validatePassword()
      };
    }
    if (loginType === "MIBL") {
      tempErrors = {
        email: validateSAPCode(email),
        password: validatePassword()
      };
    }
    setErrors(tempErrors);
    return Object.values(tempErrors).every(x => x === '');
  };

  useEffect(() => {
    if (Object.values(errors).join('')) {
      const emailChanged = email != prevEmail.current;
      const passwordChanged = password != prevPassword.current;

      if (emailChanged && passwordChanged) {
        validate();
      } else if (emailChanged) {
        setErrors({ email: validateEmail(), password: errors.password });
      } else if (passwordChanged) {
        setErrors({ email: errors.email, password: validatePassword() });
      }
      prevEmail.current = email;
      prevPassword.current = password;
    }
  }, [email, password]);

  const handleLogin = async (event, forceLogin = false) => {
    if (!validate()) return;

    try {
      setLoading(true);
      const response = await login(
        {
          // checkLoginType: loginType,
          checkLoginType: "Dealer",
          email,
          password,
          forceLogin,
        });
      // console.log("login response", response)
      if (response.status == "401") {
        toast.error(response?.response?.data?.msg || 'Invalid email or password');
        // toast.error(response.msg || 'Invalid email or password');
        return;
      }
      // response.msg == "User already logged in. Do you want to logout previous session?"
      if (response.status == 409 && !forceLogin) {
        setopenBox(true);
        return;
      }

      if (response.status == "200") {
        if (response.userDetail?.lastLoginDate === null) {
          setPassword('');
          setErrors({});
          setChangePassword(true);
        }
        else if (response.userDetail.otp === "Yes") {
          setTimeLeft(120);
          dispatch({ type: 'RESET_ALL_STATE' });
          setToken(response.token);
          // dispatch(setLogin({
          //   user: response.userDetail,
          //   token: response.token,
          //   loggedIn: true,
          //   featureAccess: response.FeatureAccess
          // }));
          // dispatch(setInputUser(email));
          setErrors({});
          setOtpShow(true);
        }
        else {
          const lastLoginDateStr = response.userDetail?.lastLoginDate;

          if (lastLoginDateStr !== null) {
            const lastLoginDate = new Date(lastLoginDateStr);
            const currentDate = new Date();

            const diffInTime = currentDate.getTime() - lastLoginDate.getTime();
            const diffInDays = diffInTime / (1000 * 3600 * 24);

            if (diffInDays > 15) {
              setPassword('');
              setErrors({});
              setResetPassword(true);
            } else {
              dispatch({ type: 'RESET_ALL_STATE' });
              dispatch(setInputUser(email));
              dispatch(setLogin({
                user: response.userDetail,
                token: response.token,
                loggedIn: true,
                featureAccess: response.FeatureAccess
              }));
              dispatch(setFetchUserByManager(response.fetchUserByManager));
              dispatch(setIsCaller(response.userDetail.callingFlag === 'Y' ? 'caller' : 'noncaller'));
              sessionStorage.removeItem("dashboard_last_fetch_time");
              navigate(`/${encodeURIComponent(encryptRoute('/dashboard'))}`);
            }
          }
        }
      }
      else {
        toast.error(response.msg || 'Invalid email or password');
      }
    } catch (err) {
      console.log(err);
      toast.error('An error occurred during login. Please try again.', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async () => {
    const passwordError = validatePassword();
    const rePasswordError = password !== rePassword ? 'Passwords do not match.' : '';

    setErrors({ password: passwordError, rePassword: rePasswordError });

    if (passwordError || rePasswordError) return;

    try {
      setLoading(true);
      if (changePassword) {
        const res = await changePasswordUser({ email: email, password: password, confirmPassword: rePassword });
        if (res.status_code === "200") {
          toast.success('Password Updated Successfully');
          setChangePassword(false);
          setEmail('');
          setPassword('');
          setErrors({});
        } else if (res.status_code !== "200") toast.error(res.status_message);
      } else if (resetPassword) {
        const res = await resetPasswordUser({ email: email, password: password, confirmPassword: rePassword });
        if (res.status_code === "200") {
          toast.success('Password Updated Successfully');
          setResetPassword(false);
          setEmail('');
          setPassword('');
          setErrors({});
        } else if (res.status_code !== "200") toast.error(res.status_message);
      }
    } catch (error) {
      toast.error('An error occurred during login. Please try again.', error);
    } finally {
      setLoading(false);
    }
  };

  const [otp, setOtp] = useState(new Array(6).fill(""));

  // --- OTP handlers ---
  const handleOtpChange = (value, index) => {
    if (/^[0-9]?$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // auto-focus next
      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-input-${index + 1}`);
        if (nextInput) nextInput.focus();
      }
    }
  };

  const handleResend = () => {
    setIsResendEnabled(false);
    handleResendCode();
  };

  const handleOtpKeyDown = (e, index) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-input-${index - 1}`);
      if (prevInput) prevInput.focus();
    }

    if (e.key === "Enter") {
      const otpValue = otp.join("");
      if (otpValue.length === 6) {
        handleVerifyOtp();
      }
    }
  };

  const handleVerifyOtp = async () => {

    // if (timeLeft <= 0) {
    //   toast.info("OTP expired. Please request a new one.");
    //   return;
    // }

    const otpValue = otp.join("");
    const payload = { email: email, password: password, otp: otpValue, token: token }
    if (otpValue.length !== 6) {
      toast.error("Please enter a valid 6-digit OTP");
      return;
    }
    try {
      setLoading(true);
      const response = await otpVerification(payload);
      if (response.status === "200") {
        dispatch({ type: 'RESET_ALL_STATE' });
        dispatch(setLogin({
          user: response.userDetail,
          token: response.token,
          loggedIn: true,
          featureAccess: response.FeatureAccess
        }));
        dispatch(setInputUser(email));
        dispatch(setFetchUserByManager(response.fetchUserByManager));
        dispatch(setIsCaller(response.userDetail.callingFlag === 'Y' ? 'caller' : 'noncaller'));
        navigate(`/${encodeURIComponent(encryptRoute('/dashboard'))}`);
      } else {
        toast.error(response.msg || "Token is expired");
      }
    } catch (error) {
      console.log("error", error)
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    try {
      setOtp(Array(6).fill(""));
      setLoading(true);
      const data = await sendOTP(email, token);
      if (data.data.success === "OTP Sent Sucessful") {
        setTimeout(() => {
          toast.success("OTP Sent Sucessful");
          setTimeLeft(120);
        }, 1000);
      }
    } catch (error) {
      toast.error('Error While Sending OTP:', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleChange = (event, newValue) => {
    if (!newValue) return;

    setLoginType(newValue);

    if (newValue === "Dealer") {
      // fetchDealerData();
    } else if (newValue === "MIBL") {
      // fetchMiblData();
    }
  };


  return (
    <>
      <BackdropLoader loading={loading} />

      <Paper elevation={0} >
        <Grid container >
          {/* Screen left */}
          <Grid size={{ xs: 12, sm: 12, md: 4 }}>
            <Box
              //  elevation={0} 
              className={`login-side-panel ${isMobileView || isTabView ? 'login-side-panel--centered' : ''}`}>
              <Box className="login-policy-wrap">
                <img loading="lazy" src={policyImg} className={`center-image login-policy-img ${isTabView ? 'login-policy-img--tab' : ''}`} alt="Commercial Lines Insurance" />
              </Box>
            </Box>
          </Grid>

          {/* Screen right */}
          {!(resetPassword || changePassword || otpShow) &&
            <Grid size={{ xs: 12, sm: 12, md: 7 }} className="login-form-grid">
              <Stack spacing={2} className={`login-form-stack ${isMobileView ? '' : 'login-form-stack--offset'}`}>
                <Box className="login-brand-desktop-shell">
                  <img loading="lazy" src={logo} className="login-brand-floating-img" alt="M-BizDesk logo" />
                </Box>
                <Box>
                  <Typography sx={{ my: 1 }} className='georama-SemiBold fs-32' textAlign={'center'}>Welcome</Typography>

                  <Typography sx={{ my: 2 }} className='nav-text text-gray' textAlign={'center'}>Please Log in to your account</Typography>
                </Box>

                {/* <Box display="flex" alignItems="center" mt={0.5} mb={0.8}>
                  <ToggleButtonGroup

                    className='login-toggle-group'
                    value={loginType}
                    exclusive
                    onChange={(e, v) => {
                      if (v !== null) handleToggleChange(e, v);
                    }}
                    sx={{ display: 'flex', gap: 0.5, border: 'none', p: 0.2 }}
                  >
                    <ToggleButton
                      className="login-toggle-button"
                      value="Dealer"
                      sx={{
                        textTransform: 'none',
                        fontWeight: 500,
                        px: 2,
                        borderRadius: 2,
                        color: loginType === 'Dealer' ? '#fff' : '#000',
                        backgroundColor: loginType === 'Dealer' ? '#e53935' : '#f5f5f5',
                        '&:hover': {
                          backgroundColor: loginType === 'Dealer' ? '#c62828' : '#e0e0e0',
                        },
                      }}
                    >
                      Dealer
                    </ToggleButton>

                    <ToggleButton
                      className="login-toggle-button"
                      value="MIBL"
                      sx={{
                        textTransform: 'none',
                        fontWeight: 500,
                        px: 2,
                        borderRadius: 2,
                        color: loginType === 'MIBL' ? '#fff' : '#000',
                        backgroundColor: loginType === 'MIBL' ? '#e53935' : '#f5f5f5',
                        '&:hover': {
                          backgroundColor: loginType === 'MIBL' ? '#c62828' : '#e0e0e0',
                        },
                      }}
                    >
                      MIBL
                    </ToggleButton>
                  </ToggleButtonGroup>
                </Box> */}


                {loginType === "Dealer" &&
                  <Box item xs={12} md={4}>
                    <Typography className="text-labels" mb={0.5}>
                      Username <span className="important-fields">*</span>
                    </Typography>

                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter Username"
                      value={email}
                      onChange={(e) => setEmail(e.target.value.trim().slice(0, 50))}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                    // InputProps={{
                    //   disableUnderline: true,
                    //   sx: { fontWeight: 'bold' },
                    // }}
                    />

                    {errors.email && (
                      <FormHelperText className="important-fields">{errors.email}</FormHelperText>
                    )}
                  </Box>}


                {loginType === "MIBL" &&
                  <Box item xs={12} md={4}>
                    <Typography className="text-labels" mb={0.5}>
                      SAP Code <span className="important-fields">*</span>
                    </Typography>

                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter SAP Code"
                      value={email}
                      onChange={(e) => setEmail(e.target.value.trim().slice(0, 10))}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                    />

                    {errors.email && (
                      <FormHelperText className="important-fields">{errors.email}</FormHelperText>
                    )}
                  </Box>}

                <Box item xs={12} md={4} mt={2}>
                  <Typography className="text-labels" mb={0.5}>
                    Password <span className="important-fields">*</span>
                  </Typography>

                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter Password"
                      type={showPass ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value.slice(0, 50))}
                      onKeyDown={(e) => e.key === 'Enter' && !resetPassword && !changePassword && !otpShow && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={() => setShowPass(!showPass)} edge="end">
                            {showPass ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  {errors.password && (
                    <FormHelperText className="important-fields">{errors.password}</FormHelperText>
                  )}

                </Box>

                <Box className="login-submit-wrap">
                  <Button className="btn-common-red border-radius-32 login-submit-button"
                    onClick={handleLogin} disabled={loading}>
                    Log In
                  </Button>
                </Box>
              </Stack>
            </Grid>}

          {/* -----------------  OTP Flag Yes then show this  -----------------  */}
          {otpShow &&
            <Grid size={{ xs: 12, sm: 12, md: 6.8 }}>
              <Button className='text-capitalize georama-medium-selected custom-starticon'
                sx={{ mr: isMobile ? 2 : 2, mt: isMobile ? 2 : -5, float: "right" }}
                startIcon={<ChevronLeftIcon />}
                onClick={() => {
                  setOtpShow(false);
                  setOtp(new Array(6).fill(""));
                }}>
                Back
              </Button>
              <Grid size={{ xs: 12, sm: 12, md: 12 }} sx={{ display: 'flex', justifyContent: "space-around", alignItems: "center" }}>
                <Stack spacing={3} sx={{ my: isMobile ? 3 : 0, p: 1, width: { xs: '90%', sm: '90%', md: '60%' } }}>
                  <Box>
                    <Typography my={2} sx={{ lineHeight: "30px !important" }} textAlign={'center'} className={`georama-SemiBold ${isMobile ? 'fs-32' : 'fs-24'} center-text`} >Check your email</Typography>
                    <Typography my={isMobile ? 1 : 0} textAlign={'center'} className={`georama-Regular ${isMobile ? 'fs-16' : 'fs-12'} center-text`} >
                      Enter the verification code sent your
                    </Typography>
                    <Typography mt={isMobile ? 1 : 0} textAlign={'center'} className={`georama-SemiBold ${isMobile ? 'fs-16' : 'fs-12'} center-text`} >
                      {email}
                    </Typography>
                  </Box>

                  <Box size={4} item xs={12} md={4}>
                    <Box display="flex" alignItems={"center"} justifyContent={"space-between"} gap={1.5}>
                      {otp.map((digit, i) => (
                        <TextField
                          className="form-control-input border-radius-8"
                          key={i}
                          id={`otp-input-${i}`}
                          value={digit}
                          onChange={(e) => handleOtpChange(e.target.value, i)}
                          onKeyDown={(e) => handleOtpKeyDown(e, i)}
                          inputProps={{
                            maxLength: 1,
                            inputMode: "numeric",
                            style: {
                              textAlign: "center",
                              fontSize: "20px",
                              width: "26px",
                              height: "16px",
                              borderRadius: "8px"
                            },
                          }}
                        />
                      ))}
                    </Box>
                    {/* Resend Section */}
                    <Box display="flex" justifyContent={"space-between"} gap={1}>
                      <Typography className='highlight-red fs-10' pt={0.5} pl={0.2}>
                        OTP is valid for 10 minutes
                      </Typography>
                      {isResendEnabled ? (
                        <Typography variant="body2" pt={0.5} className="georama-Regular fs-12">
                          Didn’t get a code?{" "}
                          <Typography
                            component="span"
                            className="georama-Medium fs-12"
                            sx={{ color: "red", cursor: "pointer" }}
                            onClick={handleResend}
                          >
                            Resend
                          </Typography>
                        </Typography>
                        // <Button className='highlight-red fs-12' onClick={handleResend}>
                        //   Didn’t get a code?{" "} Resend OTP
                        // </Button>
                      ) : (
                        <Typography className='highlight-red fs-12'>
                          Resend in {formatTime(timeLeft)}
                        </Typography>
                      )}
                    </Box>
                    {/* <Box mt={2} textAlign="center">
                        <Typography variant="body2" className="georama-Regular fs-12">
                          Didn’t get a code?{" "}
                          <Typography
                            component="span"
                            className="georama-Medium fs-12"
                            sx={{ color: "red", cursor: "pointer" }}
                            onClick={handleResendCode}
                          >
                            Resend
                          </Typography>
                        </Typography>
                      </Box> */}
                  </Box>

                  <Button
                    className='btn-common-red'
                    onClick={handleVerifyOtp}
                    disabled={otp.join("").length !== 6}
                  >
                    Verify Email
                  </Button>
                </Stack>
              </Grid>
            </Grid>}
          {/* -----------------  OTP Flag Yes then show this  ----------------- */}


          {/* ------------------ Change Password Screen --------- */}
          {(resetPassword || changePassword) &&
            <Grid size={{ xs: 12, sm: 12, md: 6.8 }} sx={{ display: 'flex', justifyContent: "space-around", alignItems: "center" }}>
              <Stack spacing={3.7} sx={{ p: 1, width: { xs: '90%', sm: '90%', md: '60%' } }}>
                <Box>
                  <Typography my={2} textAlign={'center'} fontSize={24} className='georama-SemiBold fs-32 center-text' >Change Password</Typography>
                </Box>

                <Box size={4} item xs={12} md={4}>
                  <Typography className='text-labels' mb={0.5}>
                    New Password <span className="important-fields">*</span>
                  </Typography>

                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Enter New Password"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={handlePasswordChange}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                            {showPassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  <FormHelperText className="important-fields">{errors.password}</FormHelperText>
                </Box>

                <Box size={4} item xs={12} md={4}>
                  <Typography className='text-labels' mb={0.5}>
                    Re-Enter New Password <span className="important-fields">*</span>
                  </Typography>

                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TextField
                      className="form-control-input border-radius-8"
                      size="small"
                      fullWidth
                      required
                      placeholder="Re-Enter New Password"
                      type={showRePassword ? 'text' : 'password'}
                      value={rePassword}
                      onChange={handleRePasswordChange}
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                      InputProps={{
                        endAdornment: (
                          <IconButton onClick={() => setShowRePassword(!showRePassword)} edge="end">
                            {showRePassword ? <VisibilityOffOutlined /> : <VisibilityOutlined />}
                          </IconButton>
                        ),
                        disableUnderline: true,
                      }}
                    />
                  </Box>

                  <FormHelperText className="important-fields">{errors.rePassword}</FormHelperText>
                </Box>

                <Button className="btn-common-red border-radius-32" onClick={handleChangePassword}>
                  Reset password
                </Button>
              </Stack>
            </Grid>}
        </Grid>
      </Paper>

      <BootstrapDialog open={openBox} onClose={() => setopenBox(false)}>
        <DialogContent sx={{ mx: isMobileView ? 1 : 5, my: isMobileView ? 2 : 6 }}>
          <>
            <Typography mb={3}>
              An account with this email is already logged in. Do you want to continue and log in anyway?
            </Typography>
            <Box display="flex" justifyContent="center" gap={4}>
              <Button
                variant="contained"
                color="success"
                startIcon={<CheckCircleIcon />}
                onClick={(e) => {
                  dispatch(setCredFlag(true));
                  setopenBox(false);
                  handleLogin(e, true);
                }}
              >
                Yes
              </Button>
              <Button
                variant="outlined"
                color="error"
                startIcon={<CancelIcon />}
                onClick={() => setopenBox(false)}
              >
                No
              </Button>
            </Box>
          </>
        </DialogContent>
      </BootstrapDialog>
      <ToastContainer autoClose={1000} />
    </>
  )
};

export default Login;
