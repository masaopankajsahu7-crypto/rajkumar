import NorthIcon from '@mui/icons-material/North';
import SouthIcon from '@mui/icons-material/South';
import { Box, Button, Pagination, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from "@mui/material";
import useMediaQuery from '@mui/material/useMediaQuery';
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from 'react-router-dom';
import sorting from '../assets/images/sorting.svg';
import BackdropLoader from "../components/Loader/BackdropLoader";
import { getHeaders, getMISPOutletDetails } from "../services/api";
import { encryptRoute } from "../services/encrypt";
import { btnRed, cursorpointer } from "../utils/Colors";


const MISPOutlet = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    // const isMobile = useMediaQuery('(min-width:420px)');

    const [rows, setRows] = useState([]);
    const [columns, setColumns] = useState([]);
    const [limit, setLimit] = useState(10);
    const [search, setSearch] = useState('');
    const [count, setCount] = useState(0);
    const [page, setPage] = useState(1);
    const navigate = useNavigate();
    const userData = useSelector((state) => state?.user?.loggedData);
    const allowedUrls = useSelector((state) => state?.user?.featureAccess.map(fa => fa.Url));
    const [loading, setLoading] = useState(false);
    const [sortField, setSortField] = useState('');
    const [sortOrder, setSortOrder] = useState('');

    // const columns = [
    //     { field: 'ebmCode', headerName: 'EBM Code' },
    //     { field: 'dealerName', headerName: 'Name' },
    //     { field: 'dealerLocCode', headerName: 'Mobile No' },
    //     { field: 'dealerLocName', headerName: 'Location' },
    //     { field: 'dealerAddress', headerName: 'Address' },
    //     { headerName: 'Action' },
    // ];

    const fetchPage = async () => {
        try {
            setLoading(true);
            const result = await getHeaders({ pageId: 1, user_id: userData?.user_id });
            const response = result?.data;
            setColumns(response?.inputModel?.map((f) => f?.inputName));
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSort = (field) => {
        if (sortField === field) {
            setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
        } else {
            setSortField(field);
            setSortOrder('asc');
        }
    };

    const fetchData = async () => {
        try {
            setLoading(true);
            const result = await getMISPOutletDetails({ limit, page, search, sortField, sortOrder });
            const response = result?.data;
            setCount(response?.totalDealerDetails);
            setRows(response?.dealerAllDetails);
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            fetchData();
        }, 300);
        return () => clearTimeout(delayDebounce);
    }, [search, limit, page, sortField, sortOrder]);

    useEffect(() => {
        fetchPage();
    }, []);

    return (
        <>
            <BackdropLoader loading={loading} />
            <Paper className='table-auto-width' sx={{ borderRadius: 3, m: isMobile ? 1.5 : 2, width: 'inherit', boxShadow: 'none' }}>
                <Box px={2} py={2} display='flex' flexWrap={"wrap"} alignItems="center" justifyContent="space-between">
                    <Box display='flex' alignItems="center">
                        <Typography className={`georama-SemiBold ${isMobile ? 'fs-20' : 'fs-16'} `}>
                            Dealer Setup
                        </Typography>
                        <Box className={`${isMobile ? 'fs-14' : 'fs-12'} georama-Medium ml-2`}
                            sx={{ bgcolor: '#5d6673', color: 'white', mx: 1, px: 2, py: 0.5, borderRadius: 50, fontWeight: 'bold' }}>{count}</Box>
                    </Box>

                    <Box display="flex" justifyContent="space-between" alignItems="center" mt={isDesktop ? "" : 1}>
                        <TextField className="custom-textfield body-formbg"
                            fullWidth
                            size="small" placeholder="Search"
                            value={search}
                            onChange={(e) => setSearch(e.target.value.trimStart().replace(/[^a-zA-Z0-9.,\s]/g, '').replace(/\s+/g, ' ').slice(0, 50)) || setPage(1)}
                            sx={{
                                width: isDesktop ? '22ch' : isMobile ? '21ch' : '21ch',
                                px: 2,
                                '& .MuiOutlinedInput-root': {
                                    borderRadius: 3,
                                    '&.Mui-focused fieldset': {
                                        borderColor: 'black',
                                    },
                                },
                                float: 'right'
                            }}
                        />
                    </Box>
                </Box>
                <TableContainer component={Box}
                // id="no-more-tables"
                >
                    <Table
                        stickyHeader
                    // className="tablemisp"
                    >
                        <TableHead>
                            <TableRow>
                                {columns && columns.map((cell, index) => (
                                    <TableCell
                                        // className="mispHead p-10 georama-Medium body-formbg fw-none"
                                        className="p-10 georama-Medium body-formbg fw-none"
                                        onClick={() => index < columns.length - 1 && handleSort(cell)}
                                        key={index}
                                        sx={{ ...cursorpointer }}
                                    >
                                        {cell}
                                        {index < columns.length - 1 && sortField === cell ? (
                                            sortOrder === 'asc' ? <NorthIcon fontSize="1" /> : <SouthIcon fontSize="1" />
                                        ) : (
                                            index < columns.length - 1 && <img src={sorting} alt="sort" />
                                        )}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows && rows.length > 0 ? (
                                rows?.map((row, rowIndex) => (
                                    <TableRow
                                        key={rowIndex}
                                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                    >
                                        {columns && columns?.map((colName, colIndex) => (
                                            <TableCell
                                                sx={{ padding: isDesktop ? '16px' : '8px' }}
                                                key={colIndex}
                                                className="georama-Regular"
                                            // data-title={colName}
                                            >
                                                {colIndex < columns?.length - 1 ? (
                                                    <>
                                                        <span
                                                            className={
                                                                Object.keys(row)[colIndex] === "dealerName"
                                                                    ? "text-truncate"
                                                                    : Object.keys(row)[colIndex] === "dealerAddress"
                                                                        ? "customTable-width-100"
                                                                        : ""
                                                            }
                                                        >
                                                            {row[Object.keys(row)[colIndex]]}
                                                        </span>

                                                        {/* <span className={Object.keys(row)[colIndex] === "dealerName" ? "text-truncate" : "dealerAddress" ? "customTable-width-100" : "" : ""}>
                                                        {row[Object.keys(row)[colIndex]]}
                                                    </span> */}
                                                    </>
                                                ) : (
                                                    allowedUrls.includes('/mispoutlet/create') && (
                                                        <Button
                                                            className="btn-common-red"
                                                            sx={btnRed}
                                                            size="small"
                                                            variant="contained"
                                                            onClick={() => {
                                                                navigate(
                                                                    `/${encodeURIComponent(encryptRoute('/mispoutlet/create'))}`,
                                                                    { state: row }
                                                                );
                                                            }}
                                                        >
                                                            Add
                                                        </Button>
                                                    )
                                                )}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={columns?.length}>
                                        <Box className="center-text">No Records Found.</Box>
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
                <Box>
                    {/* <Typography display={'inline'}>Show result: </Typography>
                <Select size="small" sx={{ width: 75, borderRadius: 3, m: 1 }} value={limit} onChange={(e) => setLimit(e.target.value) || setPage(1)}>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={20}>20</MenuItem>
                    <MenuItem value={50}>50</MenuItem>
                    <MenuItem value={100}>100</MenuItem>
                </Select> */}

                    {rows && rows.length > 0 && <Pagination size="medium" count={Math.ceil(count / limit)} page={page} onChange={(e, v) => setPage(v)} shape="rounded"
                        sx={{
                            float: 'right', m: 1,
                            '& .MuiPaginationItem-root': {
                                borderRadius: 3,
                            }
                        }} />}
                </Box>
            </Paper >
        </>
    );
};

export default MISPOutlet;