import { Box, Button, Card, Checkbox, FormControl, Grid, InputLabel, MenuItem, Paper, Select, Typography } from '@mui/material';
import useMediaQuery from '@mui/material/useMediaQuery';
import { ArcElement, BarController, BarElement, CategoryScale, Chart as ChartJS, DoughnutController, Legend, LinearScale, LineController, LineElement, PieController, PointElement, ScatterController, Tooltip } from 'chart.js';
import { useEffect, useRef, useState, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import coldLeadImg from '../assets/images/dashboard/coldLeadImg.svg';
import dateFilter from "../assets/images/dashboard/dateFilter.svg";
import hotLeadImg from '../assets/images/dashboard/hotLeadImg.svg';
import totalLeadImg from '../assets/images/dashboard/totalLeadImg.svg';
import warmLeadImg from '../assets/images/dashboard/warmLeadImg.svg';
import myleadssvg from "../assets/images/managerdashboard/myleads.svg";
import DashboardLayout from '../components/DashboardLayout';
import CustomDateRange from '../components/DateRange/CustomDateRange';
import DispositionSummary from '../components/DispositionSummary';
import FunnelChart from '../components/FunnelChartComponent';
import BackdropLoader from "../components/Loader/BackdropLoader";
import { setDispositionSummary, setLeadConversion, setLeadSummary, setRecentlyConverted, setSegmentData, setSubDispositionSummary, setTeamMembersData } from '../redux/slices/dashboardSlice';
import { downloadDashboardExcel, fetchDashboard, fetchFilteredDashboard } from '../services/api';
import { btnRed } from '../utils/Colors';
// import { downloadDispositionSummaryExcel } from '../services/api';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import dispositionsvg from "../assets/images/managerdashboard/disposition.svg";
import { useQuery, useMutation } from "@tanstack/react-query";

// ChartJS Registration
ChartJS.register(
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    CategoryScale,
    LinearScale,
    BarElement, LineController, BarController, PieController, ScatterController, DoughnutController
);

const ManagerDashboard = () => {
    const isDesktop = useMediaQuery('(min-width:1024px)');
    const isTab = useMediaQuery('(min-width:600px)');
    const isMobile = useMediaQuery('(min-width:320px)');

    const dispatch = useDispatch();
    const fetchUserByManager = useSelector((state) => state.user.fetchUserByManager);
    const userDetails = useSelector((state) => state.user.loggedData);
    // const userDetails = { ...useSelector((state) => state.user.loggedData), dealerCode: "1" };

    // const leadSummary = useSelector((state) => state.dashboard.leadSummary);
    // const dispositionSummary = useSelector((state) => state.dashboard.dispositionSummary);
    // const subDispositionSummary = useSelector((state) => state.dashboard.subDispositionSummary);
    // const leadConversiondata = useSelector((state) => state.dashboard.leadConversiondata);
    // const teamMembersData = useSelector((state) => state.dashboard.teamMembersData);
    // const segmentData = useSelector((state) => state.dashboard.segmentData);
    const [selectedSegments, setSelectedSegments] = useState([]);
    const [selectedTeamMembers, setSelectedTeamMembers] = useState([]);
    const [open, setOpen] = useState(false);
    const anchorRef = useRef(null);
    const [dateRange, setDateRange] = useState("");
    const [converted, setConverted] = useState();
    const [dateSelected, setDateSelected] = useState();
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);
    const [TeamSelectOpen, setTeamSelectOpen] = useState(false);
    // const [loading, setLoading] = useState(false);
    const [isClearing, setIsClearing] = useState(false);

    // =========================
    // DASHBOARD QUERY
    // =========================

    const dashboardQuery = useQuery({
        queryKey: [
            "dashboard",
            userDetails?.user_id,
            userDetails?.dealerCode,
        ],

        queryFn: async () => {
            const payload = {
                dealerCode: userDetails.dealerCode,
                userId: userDetails.user_id,
                roleId: userDetails.roleId,
                type: "fetchDashboard",
            };

            const response = await fetchDashboard(payload);

            if (
                response?.statusCode === "200" ||
                response?.statusMessage ===
                "Fetched Dashboard Details."
            ) {
                return response.data;
            }

            throw new Error("Failed to fetch dashboard");
        },

        enabled: !!userDetails?.user_id,

        staleTime: 1000 * 60 * 5, // 5 mins cache
        refetchOnWindowFocus: false,
    });

    // =========================
    // FILTER MUTATION
    // =========================

    const filterMutation = useMutation({
        mutationFn: async ({
            date = dateSelected,
            filteredSegments = selectedSegments,
            filteredTeamMembers = selectedTeamMembers,
            isConversion = false,
        }) => {
            const filtertype = isConversion
                ? "filterConversion"
                : "filterData";

            const startDate =
                !date ||
                    date === "" ||
                    date?.startDate === "Invalid Date"
                    ? ""
                    : date.startDate;

            const endDate =
                !date ||
                    date === "" ||
                    date?.endDate === "Invalid Date"
                    ? ""
                    : date.endDate;

            const payload = {
                dealerCode: userDetails.dealerCode,
                roleId: userDetails.roleId,
                type: filtertype,
                userId: userDetails.user_id,

                segment:
                    filteredSegments.join(",") || "",

                teamMemberId:
                    filteredTeamMembers.join(",") || "",

                startDate,
                endDate,

                conversion:
                    converted || "Converted",
            };

            const response =
                await fetchFilteredDashboard(payload);

            if (
                response?.statusCode === "200" ||
                response?.statusMessage ===
                "Fetched  Filter Dashboard Details."
            ) {
                return {
                    data: response.data,
                    filtertype,
                };
            }

            throw new Error(
                "Failed to fetch filtered dashboard"
            );
        },
    });

    // =========================
    // FILTER EFFECTS
    // =========================

    useEffect(() => {
        if (dateSelected) {
            filterMutation.mutate({
                date: dateSelected,
            });
        }
    }, [dateSelected]);

    useEffect(() => {
        if (converted !== undefined) {
            filterMutation.mutate({
                isConversion: true,
            });
        }
    }, [converted]);

    // =========================
    // FINAL DATA SOURCE
    // =========================

    const dashboardData = useMemo(() => {
        // Filtered data
        if (filterMutation.data?.data) {
            return filterMutation.data.data;
        }

        // Original dashboard data
        return dashboardQuery.data;
    }, [dashboardQuery.data, filterMutation.data]);

    // =========================
    // EXTRACT RESULTS
    // =========================

    const leadSummary =
        dashboardData?.result0 || [];

    const dispositionSummary =
        dashboardData?.result1 || [];

    const subDispositionSummary =
        dashboardData?.result2 || [];

    const leadConversiondata =
        dashboardData?.result3 || [];

    const recentlyConverted =
        dashboardData?.result4 || [];

    const segmentData =
        dashboardQuery.data?.result5 || [];

    const teamMembersData =
        dashboardQuery.data?.result6 || [];

    // =========================
    // LOADING
    // =========================

    const loading =
        dashboardQuery.isLoading ||
        filterMutation.isPending;

    // =========================
    // ERROR
    // =========================

    const error =
        dashboardQuery.error ||
        filterMutation.error;

    // =========================
    // HANDLERS
    // =========================

    const selectedDateHandler = (date) => {
        setDateSelected(date);
    };

    const conversionType = (type) => {
        setConverted(type);
    };

    // =========================
    // JSX
    // =========================

    // if (loading) {
    //     return <div>Loading...</div>;
    // }

    // if (error) {
    //     return <div>Error loading dashboard</div>;
    // }

    // const fetchDashboardData = async () => {
    //     if (!userDetails?.user_id) return;

    //     try {
    //         const payload = {
    //             dealerCode: userDetails.dealerCode,
    //             userId: userDetails.user_id,
    //             roleId: userDetails.roleId,
    //             type: "fetchDashboard",
    //         };

    //         setLoading(true);
    //         const response = await fetchDashboard(payload);

    //         if (response?.statusCode === "200" || response?.statusMessage === "Fetched Dashboard Details.") {
    //             const { result0, result1, result2, result3, result4, result5, result6 } = response.data;
    //             dispatch(setLeadSummary(result0));
    //             dispatch(setDispositionSummary(result1));
    //             dispatch(setSubDispositionSummary(result2));
    //             dispatch(setLeadConversion(result3));
    //             dispatch(setRecentlyConverted(result4));
    //             dispatch(setSegmentData(result5));
    //             dispatch(setTeamMembersData(result6));
    //         } else {
    //             console.error("Failed to fetch dashboard:", response);
    //         }
    //     } catch (err) {
    //         console.error("Error fetching dashboard data:", err);
    //     } finally {
    //         setLoading(false);
    //     }
    // };

    // useEffect(() => {
    //     fetchDashboardData();
    // }, [dispatch, userDetails?.user_id, userDetails?.dealerCode]);

    const selectedDate = (date) => {
        setDateSelected(date);
    };

    // useEffect(() => {
    //     if (dateSelected) {
    //         filterDashboard();
    //     }
    // }, [dateSelected]);

    // const filterDashboard = async (date = dateSelected, filteredSegments = selectedSegments, filteredTeamMembers = selectedTeamMembers, isConversion = false) => {
    //     if (filteredSegments.length > 0 || filteredTeamMembers.length > 0 || isConversion || converted !== "Converted") {
    //         if (!userDetails?.user_id) return;

    //         let filtertype;
    //         if (!isConversion) {
    //             filtertype = "filterData";
    //         } else {
    //             filtertype = "filterConversion";
    //         }

    //         try {
    //             const startDate = !date || date === "" || date?.startDate === "Invalid Date" ? "" : date.startDate;
    //             const endDate = !date || date === "" || date?.endDate === "Invalid Date" ? "" : date.endDate;

    //             const payload = {
    //                 dealerCode: userDetails.dealerCode,
    //                 roleId: userDetails.roleId,
    //                 type: filtertype,
    //                 userId: userDetails.user_id,
    //                 // dealerCode: "1",
    //                 // roleId: "3",
    //                 // segment: filteredSegments.length > 0 ? filteredSegments.join(",") : "",
    //                 // teamMemberId: filteredTeamMembers.length > 0 ? filteredTeamMembers.join(",") : "",
    //                 segment: selectedSegments.join(",") || "",
    //                 teamMemberId: selectedTeamMembers.join(",") || "",
    //                 startDate,
    //                 endDate,
    //                 // startDate: dateSelected ? dateSelected.startDate : "",
    //                 // endDate: dateSelected ? dateSelected.endDate : "",
    //                 conversion: converted ? converted : "Converted"    // Converted or NonConverted - send {type: "filterConversion"}
    //             };

    //             setLoading(true);
    //             const response = await fetchFilteredDashboard(payload);

    //             if (response?.statusCode === "200" || response?.statusMessage === "Fetched  Filter Dashboard Details.") {
    //                 if (filtertype === "filterConversion") {
    //                     const { result0, result1 } = response.data;
    //                     dispatch(setDispositionSummary(result0));
    //                     dispatch(setSubDispositionSummary(result1));
    //                 } else {
    //                     const { result0, result1, result2, result3, result4 } = response.data;
    //                     dispatch(setLeadSummary(result0));
    //                     dispatch(setDispositionSummary(result1));
    //                     dispatch(setSubDispositionSummary(result2));
    //                     dispatch(setLeadConversion(result3));
    //                     dispatch(setRecentlyConverted(result4));
    //                 }
    //             } else {
    //                 console.error("Failed to fetch dashboard:", response);
    //             }
    //         } catch (err) {
    //             console.error("Error fetching dashboard data:", err);
    //         } finally {
    //             setLoading(false);
    //         }
    //     } else {
    //         fetchDashboardData();
    //     }
    // }

    // const conversionType = (type) => {
    //     setConverted(type);
    // };

    // useEffect(() => {
    //     if (converted !== undefined) {
    //         filterDashboard(selectedSegments, selectedTeamMembers, true);
    //     }
    // }, [converted]);

    // useEffect(() => {
    //     if (isClearing) {
    //         filterDashboard(selectedSegments, selectedTeamMembers);
    //         setIsClearing(false);
    //     }
    // }, [selectedSegments, selectedTeamMembers, isClearing]);

    const handleClearFilters = (type) => {

        if (type === "segment") {

            setSelectedSegments([]);

            filterMutation.mutate({
                filteredSegments: [],
                filteredTeamMembers: selectedTeamMembers,
            });

        } else if (type === "teammembers") {

            setSelectedTeamMembers([]);

            filterMutation.mutate({
                filteredSegments: selectedSegments,
                filteredTeamMembers: [],
            });
        }
    };

    const handleSegmentChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData.map(seg => seg.segment));
            }
        } else {
            setSelectedSegments(value);
        }
    };

    const handleSegmentToggle = (segment) => {
        if (segment === 'all') {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData.map(seg => seg.segment));
            }
        } else {
            const currentIndex = selectedSegments.indexOf(segment);
            const newSelected = [...selectedSegments];

            if (currentIndex === -1) {
                newSelected.push(segment);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedSegments(newSelected);
        }
    };

    const handleTeamMembersChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedTeamMembers.length === teamMembersData.length) {
                setSelectedTeamMembers([]);
            } else {
                setSelectedTeamMembers(teamMembersData.map(team => team.teamMemberId));
            }
        } else {
            setSelectedTeamMembers(value);
        }
    };

    const downloadDispositionSummary = async (dateParam) => {
        try {
            // let filtertype;
            // if (!isConversion) {
            //     filtertype = "filterData";
            // } else {
            //     filtertype = "filterConversion";
            // }

            setLoading(true);
            let payload;

            const date = dateParam && dateParam.startDate ? dateParam : dateSelected;

            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            const startDate = date?.startDate || "";
            const endDate = date?.endDate || "";

            const isFilterEmpty =
                selectedTeamMembers.length === 0 &&
                selectedSegments.length === 0 && isDateEmpty;

            if (isFilterEmpty) {
                payload = {
                    dealerCode: userDetails.dealerCode,
                    userId: userDetails.user_id,
                    roleId: userDetails.roleId,
                    type: "downloadExcel",
                    // type: "fetchDashboard",
                };
            } else {
                payload = {
                    // type: filtertype,
                    dealerCode: userDetails.dealerCode,
                    roleId: userDetails.roleId,
                    userId: userDetails.user_id,
                    segment: selectedSegments.join(",") || "",
                    teamMemberId: selectedTeamMembers.join(",") || "",
                    startDate,
                    endDate,
                    conversion: converted ? converted : "Converted"
                };
            }

            const result = await downloadDashboardExcel(payload);

            if (result?.data) {
                const blob = new Blob([result.data], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                });

                const url = window.URL.createObjectURL(blob);
                const link = document.createElement("a");

                link.href = url;
                link.download = "Disposition_Summary.xlsx";

                document.body.appendChild(link);
                link.click();

                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error("Error downloading Excel file:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <BackdropLoader loading={loading} />
            {/* <MarqueeInfo /> */}
            <Paper className="body-formbg" elevation={0} sx={{ m: 1, px: isTab ? 2 : 0.5, width: "inherit", boxShadow: 'none' }}>
                <Box display={'flex'} justifyContent="space-between" flexWrap="wrap" alignItems="center" mb={0.5}>
                    <Typography className={`georama-SemiBold ${isTab ? 'fs-24' : 'fs-20'}`}>Dashboard</Typography>

                    <Box display="flex" flexWrap="wrap" gap={isTab ? 1.5 : 0.5} mb={1} mt={1}>
                        <FormControl size="small" sx={{ minWidth: isMobile ? 100 : 110, maxWidth: isMobile ? 70 : 110, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel id="segment-label" className="dropdown-label">Segment</InputLabel>
                            <Select
                                className='georama-Medium'
                                labelId="segment-label"
                                id="segment-select"
                                multiple
                                value={selectedSegments}
                                label="Segment"
                                onChange={handleSegmentChange}
                                open={segmentSelectOpen}
                                onClose={() => setSegmentSelectOpen(false)}
                                onOpen={() => setSegmentSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === segmentData?.length) return "All";
                                    return segmentData
                                        .filter(seg => selected.includes(seg.segment))
                                        .map(seg => seg.segment)
                                        .join(',');
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            // maxHeight: 300,
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                            >
                                <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                    onClick={() => handleSegmentToggle('all')}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedSegments.length === segmentData?.length}
                                        indeterminate={
                                            selectedSegments.length > 0 &&
                                            selectedSegments.length < segmentData.length
                                        }
                                    />
                                    <span className='georama-Regular'>All</span>
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {segmentData && segmentData.map((seg, index) => (
                                        <MenuItem
                                            className={selectedSegments.includes(seg.segment) ? 'georama- fs-14' : ''}
                                            disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                            key={index}
                                            value={seg.segment}
                                            onClick={() => handleSegmentToggle(seg.segment)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedSegments.includes(seg.segment)}
                                            />

                                            <span className='georama-Regular'>{seg.segment}</span>
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        disabled={selectedSegments.length === 0}
                                        fullWidth
                                        variant="contained"
                                        size="small"
                                        onClick={() => {
                                            handleClearFilters("segment");
                                            setSegmentSelectOpen(false);
                                        }}
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        fullWidth
                                        className='btn-common-red'
                                        disabled={selectedSegments.length === 0}
                                        variant="contained"
                                        size="small"
                                        sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={() => {
                                            filterMutation.mutate({
                                                filteredSegments: selectedSegments,
                                                filteredTeamMembers: selectedTeamMembers,
                                            });

                                            setSegmentSelectOpen(false);
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>

                        {!!fetchUserByManager?.length && teamMembersData?.length > 0 &&
                            <FormControl size="small" sx={{ minWidth: isMobile ? 130 : 140, maxWidth: isMobile ? 130 : 150, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel className="dropdown-label">Team Member</InputLabel>
                                <Select
                                    multiple
                                    value={selectedTeamMembers}
                                    label="Team Member"
                                    onChange={handleTeamMembersChange}
                                    open={TeamSelectOpen}
                                    onClose={() => setTeamSelectOpen(false)}
                                    onOpen={() => setTeamSelectOpen(true)}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                    renderValue={(selected) => {
                                        if (selected.length === teamMembersData.length) return "All";
                                        return teamMembersData
                                            .filter(seg => selected.includes(seg.teamMemberId))
                                            .map(seg => seg.teamMemberName)
                                            .join(',');
                                    }}
                                >
                                    <MenuItem sx={{ py: 0, m: 0 }} value="all">
                                        <Checkbox
                                            sx={{
                                                mr: 1,
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedTeamMembers.length === teamMembersData?.length}
                                            indeterminate={
                                                selectedTeamMembers.length > 0 &&
                                                selectedTeamMembers.length < teamMembersData.length
                                            }
                                        />
                                        <span className='georama-Regular'>All</span>
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {teamMembersData && teamMembersData.map((seg, index) => (
                                            <MenuItem
                                                sx={{ py: 0, m: 0 }}
                                                key={index}
                                                value={seg.teamMemberId}
                                                className={selectedSegments.includes(seg.teamMemberName) ? 'georama- fs-14' : ''}
                                                onClick={() => {
                                                    const currentIndex = selectedTeamMembers.indexOf(seg.teamMemberId);
                                                    let newSelected = [...selectedTeamMembers];

                                                    if (currentIndex === -1) {
                                                        newSelected.push(seg.teamMemberId);
                                                    } else {
                                                        newSelected.splice(currentIndex, 1);
                                                    }
                                                    setSelectedTeamMembers(newSelected);
                                                }}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        mr: 1,
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedTeamMembers.includes(seg.teamMemberId)}
                                                />

                                                <span className='georama-Regular'>{seg.teamMemberName}</span>
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            disabled={selectedTeamMembers.length === 0}
                                            fullWidth
                                            variant="contained"
                                            size="small"
                                            onClick={() => {
                                                handleClearFilters("teammembers");
                                                setTeamSelectOpen(false);
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                mx: 1,
                                                color: "black",
                                                backgroundColor: 'transparent',
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            fullWidth
                                            disabled={selectedTeamMembers.length === 0}
                                            variant="contained"
                                            size="small"
                                            sx={{ mr: 1, my: 1, ...btnRed, borderRadius: 8, }}
                                            onClick={() => {
                                                filterMutation.mutate({
                                                    filteredSegments: selectedSegments,
                                                    filteredTeamMembers: selectedTeamMembers,
                                                });

                                                setSegmentSelectOpen(false);
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                        <Button className='bg-white text-gray text-capitalize border-light-gray border-radius-8' ref={anchorRef} onClick={() => setOpen(true)}>
                            <img className='px-1' src={dateFilter} alt="" />
                            <Typography className="dropdown-label" mt={0.5} px={0.5}>Date Range</Typography>
                        </Button>

                        <CustomDateRange
                            open={open}
                            anchorRef={anchorRef}
                            setOpen={setOpen}
                            setDate={selectedDate}
                            onChange={() => setDateSelected("")}
                            clearDate={() => {
                                setDateSelected("");
                                filterMutation.mutate({
                                    date: "",
                                    filteredSegments: selectedSegments,
                                    filteredTeamMembers: selectedTeamMembers,
                                });
                                setOpen(false);
                            }}
                        />
                    </Box>
                </Box>

                <Grid container spacing={isTab ? 2 : 1.5}>
                    <Grid size={{ xs: 12, sm: 12, md: 12, lg: 8 }}>
                        <Grid px={isMobile ? 1.2 : 2} py={1.3} borderRadius={2} className="bg-white" size={12} item xs={12} md={12}>
                            <Box display={'flex'} justifyContent="space-between" alignItems="center" my={1} mb={2}>
                                <Box display={'flex'} alignItems="center" justifyContent={"center"} gap={1}>
                                    <img src={myleadssvg} alt="" />
                                    <Typography className="georama-SemiBold font-size-16">My Leads Summary</Typography>
                                </Box>
                            </Box>

                            {/* Summary Cards */}
                            <Grid container spacing={1.4}>
                                {leadSummary && leadSummary?.map((lead, index) => (
                                    <Grid size={{ xs: 6, sm: 3, md: 3 }} key={index}>
                                        <Card
                                            sx={{
                                                py: isMobile ? 1.2 : 1.5,
                                                display: 'flex',
                                                gap: isMobile ? 0.8 : 1,
                                                justifyContent: 'start',
                                                flexDirection: 'row',
                                                alignItems: 'center',
                                                boxShadow: 'none',
                                                border: '1px solid #DCDDE0',
                                                borderRadius: 2.5
                                            }}>
                                            <Box display={'flex'} justifyContent={"center"} ml={isDesktop ? 1.8 : 1.2}
                                                sx={{ py: isDesktop ? 1.8 : 1.4, px: isDesktop ? 1.8 : 1.5, borderRadius: 3.5 }}
                                                className={lead.leadType === 'Total Leads' ? 'dashboard-purple' :
                                                    lead.leadType === 'Hot Leads' ? 'dashboard-red' :
                                                        lead.leadType === 'Warm Leads' ? 'dashboard-orange' : 'dashboard-blue'
                                                }>
                                                <img
                                                    src={lead.leadType === 'Total Leads' ? totalLeadImg :
                                                        lead.leadType === 'Hot Leads' ? hotLeadImg :
                                                            lead.leadType === 'Warm Leads' ? warmLeadImg : coldLeadImg}
                                                />
                                            </Box>
                                            <Box pl={0.7}>
                                                <Typography pb={0.3} className={`georama-SemiBold ${isDesktop ? 'fs-22' : 'fs-18'}`}>{lead.Count}</Typography>
                                                <Typography className={`georama-Medium text-gray ${isDesktop ? 'fs-14' : 'fs-12'}`}>{lead?.leadType}</Typography>
                                            </Box>
                                        </Card>
                                    </Grid>
                                ))}
                            </Grid>
                        </Grid>

                        {/* Disposition summary */}
                        <Grid px={isMobile ? 1 : 2} py={1.3} my={1.5} borderRadius={2} className="bg-white" size={12} item xs={12} md={12}>
                            <Box display={'flex'} alignItems="center" justifyContent={"space-between"} gap={1}>
                                <Box display={'flex'} alignItems="center" gap={1}>
                                    <img src={dispositionsvg} alt="" />
                                    <Typography className="georama-SemiBold fs-14">Disposition Summary</Typography>
                                </Box>
                                <Box display="flex" justifyContent="space-between" alignItems="center" mb={1.3}>
                                    <Button sx={{ mr: 1 }}
                                        // disabled={!rows.length}
                                        onClick={() => downloadDispositionSummary(dateSelected)}
                                        endIcon={<FileDownloadIcon />}
                                        className="btn-common-red"
                                    >
                                        Download
                                    </Button>
                                </Box>
                            </Box>
                            <DispositionSummary dispositiondata={dispositionSummary} subDispositiondata={subDispositionSummary} conversionType={conversionType} />
                        </Grid>

                        {/* Lead Conversion and Performance */}
                        <Grid my={0} container spacing={2}>
                            <Grid p={2} borderRadius={2} className="bg-white" size={{ xs: 12, md: 6, lg: 6 }}>
                                <Box display={'flex'} alignItems="center" justifyContent={"start"}>
                                    <img src={myleadssvg} alt="" />

                                    <Typography px={1} className="georama-SemiBold fs-14">Lead Conversion</Typography>
                                </Box>

                                <Paper elevation={0}>
                                    <FunnelChart leadConversion={leadConversiondata} />
                                </Paper>
                            </Grid>

                            {/* <Grid p={2} borderRadius={2} className="bg-white" size={{ xs: 12, md: 6, lg: 6 }}>
                                <Box display={'flex'} alignItems="center" justifyContent={"space-between"} mb={4}>
                                    <Box display={'flex'} alignItems="center" >
                                        <img src={performancesvg} alt="" />

                                        <Typography px={1} className="georama-SemiBold fs-14">My Performance</Typography>
                                    </Box>

                                </Box>

                                <Paper elevation={0} >
                                    <PerformanceBarChart />
                                </Paper>
                            </Grid> */}
                        </Grid>
                    </Grid>

                    <Grid size={{ xs: 12, sm: 12, md: 12, lg: 4 }}>
                        <DashboardLayout />
                    </Grid>
                </Grid>
            </Paper >
        </>
    );
};

export default ManagerDashboard;
