import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Accordion, AccordionDetails, AccordionSummary, Autocomplete, Box, Button, Checkbox, Divider, FormControl, FormControlLabel, FormHelperText, Grid, Paper, TextField, Typography, useMediaQuery } from "@mui/material";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { editPreferencesByBucket, getBucketDetails, getPreferencesByBucket, saveBucketDetails } from "../services/api";
import { encryptRoute } from "../services/encrypt";
import { useAuth } from "../services/useAuth";
import { colorRed } from '../utils/Colors';


export default function LeadPoolForm() {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');

    const [accordionData, setAccordionData] = useState([
        {
            title: "Insurance Companies",
            options: [],
        },
        {
            title: "Renewal Category",
            options: [],
        },
        {
            title: "Vehicle Class",
            options: [],
        },
        {
            title: "Data Pull",
            options: []
        },
        {
            title: "Add On",
            options: [],
        },
    ]);
    const navigate = useNavigate();
    const { user_id, roleId, dealerCode, parentCode } = useAuth().user;
    const location = useLocation();
    const row = location.state || {};
    const isViewMode = row?.isView || false;
    const [leadPoolData, setLeadPoolData] = useState({});
    const [locations, setLocations] = useState([]);
    const [dealersCode, setDealerCode] = useState("");
    const [dealers, setDealers] = useState([]);
    const userData = useSelector((state) => state.user.loggedData);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        if (isViewMode) {
            let response = await getPreferencesByBucket(row.bucket_id, { dealerCode, parentCode });
            setFormData((prev) => ({ ...prev, ['location']: response?.location }));
            const fetchedSections = [
                {
                    title: 'Insurance Companies',
                    options: response.insurance.filter(s => s.status === "1").map((i) => ({ id: i.ic_code, label: i.ic_name }))
                },
                {
                    title: 'Renewal Category',
                    options: response.renewal.filter(s => s.status === "1").map((rc) => ({ id: rc.renewal_category_id, label: rc.renewal_year }))
                },
                {
                    title: 'Vehicle Class',
                    options: response.segment.filter(s => s.status === "1").map((v) => ({ id: v.segment_id, label: v.segment_name }))
                },
                {
                    title: 'Data Pull',
                    options: response.datapull.filter(s => s.status === "1").map((dp) => ({ id: dp.datapull_id, label: dp.datapull_name }))
                },
                {
                    title: 'Add On',
                    options: response.addon.filter(s => s.status === "1").map((ao) => ({ id: ao.addon_id, label: ao.addon_description }))
                }
            ];
            setAccordionData(fetchedSections);
        }
        else {
            let response = await getBucketDetails({
                dealerCode, parentCode,
                roleType: userData?.roleType,
                dealerName: formData?.dealer || '',
                type: formData?.dealer ? 'location' : ''
            });
            if (response.statusCode === '200') {
                setDealers(response.data?.result5 ? Object.values(response.data?.result5) : []);
                if (userData?.roleType !== "DEALER") {
                    setDealerCode(response.data?.result5);
                }
                if (userData?.roleType === "DEALER") {
                    setLocations(response.data?.result5 ? Object.values(response.data?.result5) : []);
                }
                if (formData?.dealer) {
                    setLocations(response.data?.result6 ? Object.values(response.data?.result6) : []);
                }
                const fetchedSections = [
                    {
                        title: 'Insurance Companies',
                        options: parseOptions(response.data.result0 || {})
                    },
                    {
                        title: 'Renewal Category',
                        options: parseOptions(response.data.result1 || {})
                    },
                    {
                        title: 'Vehicle Class',
                        options: parseOptions(response.data.result2 || {})
                    },
                    {
                        title: 'Data Pull',
                        options: parseOptions(response.data.result3 || {})
                    },
                    {
                        title: 'Add On',
                        options: parseOptions(response.data.result4 || {})
                    }
                ];
                setAccordionData(fetchedSections);
            }
            if (row?.isEdit) {
                let res = await getPreferencesByBucket(row.bucket_id, { dealerCode, parentCode });
                setFormData((prev) => ({ ...prev, ['location']: res?.location, ['dealer']: res?.dealerName[0]?.dealer_name }));
                setFormData((prev) => ({
                    ...prev,
                    sections: {
                        ...prev.sections,
                        ['Insurance Companies']: res?.insurance?.filter(s => s.status === "1").map(i => String(i.ic_code)) || [],
                        ['Renewal Category']: res?.renewal?.filter(s => s.status === "1").map(rc => String(rc.renewal_category_id)) || [],
                        ['Vehicle Class']: res?.segment?.filter(s => s.status === "1").map(v => String(v.segment_id)) || [],
                        ['Add On']: res?.addon?.filter(s => s.status === "1").map(ao => String(ao.addon_id)) || [],
                        ['Data Pull']: res?.datapull?.filter(s => s.status === "1").map(ao => String(ao.datapull_id)) || [],
                    },
                }));
                setFormData((prev) => ({ ...prev, ['bucketName']: row?.bucket_name }));
            }
        }
    }

    const parseOptions = (dataObj) =>
        Object.entries(dataObj).map(([id, label]) => ({ id, label }));

    const [formData, setFormData] = useState({
        bucketName: '',
        dealer: "",
        location: "",
        sections: {},
        parentCode: ""
    });

    const fetchDataLocations = async () => {
        let response = await getBucketDetails({
            dealerCode, parentCode,
            roleType: userData?.roleType,
            dealerName: formData?.dealer || '',
            type: formData?.dealer ? 'location' : ''
        });
        if (response.statusCode === '200') {
            setLocations(response.data?.result6 ? Object.values(response.data?.result6) : []);
        }
    }

    useEffect(() => {
        if (formData?.dealer) {
            fetchDataLocations();
        }
    }, [formData?.dealer]);

    const [errors, setErrors] = useState({});
    const [expanded, setExpanded] = useState(null);

    useEffect(() => {
        if (leadPoolData) {
            setFormData({
                bucketName: leadPoolData.name || '',
                location: leadPoolData.location || [],
                sections: leadPoolData.sections || {},
            });
        }
    }, [leadPoolData]);

    const handleFieldChange = (field) => (e) => {
        setFormData((prev) => ({
            ...prev, [field]: field === 'bucketName' ?
                e.target.value.trimStart().replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, ' ').slice(0, 30) : e.target.value
        }));
        setErrors((prev) => ({ ...prev, [field]: '' }));
    };

    const handleAccordionChange = (panelIndex) => (_, isExpanded) => {
        setExpanded(isExpanded ? panelIndex : null);
    };

    const handleHeaderCheck = (sectionTitle, isChecked, options) => {
        setFormData((prev) => ({
            ...prev,
            sections: {
                ...prev.sections,
                [sectionTitle]: isChecked ? options.map(o => o.id) : [],
            },
        }));
    };

    const handleItemCheck = (sectionTitle, option, isChecked) => {
        setFormData((prev) => {
            const prevOptions = prev.sections[sectionTitle] || [];
            const updatedOptions = isChecked
                ? [...prevOptions, option.id]
                : prevOptions.filter((opt) => opt !== option.id);

            return {
                ...prev,
                sections: {
                    ...prev.sections,
                    [sectionTitle]: updatedOptions,
                },
            };
        });
    };

    const handleSubmit = async () => {
        const newErrors = { sections: {} };
        if (!formData.bucketName?.trim()) {
            newErrors.bucketName = "Lead Pool Name is required";
        } else if (!/^[A-Za-z][A-Za-z0-9 ]*$/.test(formData.bucketName.trim())) {
            newErrors.bucketName = "Lead Pool Name must start with an alphabet";
        }
        // if (!/^[A-Za-z]{2}[A-Za-z0-9 ]*$/.test(formData.bucketName?.trim())) newErrors.bucketName = "Lead Pool Name must start with alphabets";
        // if (!formData.bucketName?.trim()) newErrors.bucketName = "Lead Pool Name is required";

        if (userData?.roleType === "MIBL" && !formData.location?.length) newErrors.location = "Location is required";
        if (userData?.roleType !== "DEALER") {
            if (!formData.dealer?.trim()) newErrors.dealer = "Dealer Name is required";
        }
        if (!formData?.sections?.['Insurance Companies']?.length) newErrors.sections['Insurance Companies'] = "Please select atleast one Insurance Companies.";
        if (!formData?.sections?.['Renewal Category']?.length) newErrors.sections['Renewal Category'] = "Please select atleast one Renewal Category.";
        if (!formData?.sections?.['Vehicle Class']?.length) newErrors.sections['Vehicle Class'] = "Please select atleast one Vehicle Class.";
        if (!formData?.sections?.['Data Pull']?.length) newErrors.sections['Data Pull'] = "Please select atleast one Data Pull.";
        if (Object.keys(newErrors).length > 1 || Object.keys(newErrors.sections).join('') !== '') {
            setErrors(newErrors);
            if (Object.keys(newErrors.sections).length) {
                Object.keys(newErrors.sections).forEach((sec) => toast.warning(newErrors.sections[sec]));
            }
            return;
        }
        else {
            try {
                const location = Object.values(locations);

                setLoading(true);
                let response = row?.isEdit ?
                    await editPreferencesByBucket(row?.bucket_id, {
                        userId: userData.user_id,
                        dealerCode: userData?.roleType === "DEALER" ? dealerCode : formData?.dealer,
                        locationNames: formData.location,
                        insuranceIds: formData?.sections?.['Insurance Companies'],
                        renewalCategoryIds: formData?.sections?.['Renewal Category'],
                        segmentIds: formData?.sections?.['Vehicle Class'],
                        addonIds: formData?.sections?.['Add On'],
                        dataPullIds: formData?.sections?.['Data Pull']
                    }) :
                    await saveBucketDetails({
                        roleType: userData?.roleType,
                        userId: userData.user_id,
                        bucketName: formData.bucketName,
                        location: userData?.roleType === "DEALER" ? location : formData.location,
                        dealerCode: userData?.roleType === "DEALER" ? dealerCode : "",
                        parentCode: userData?.roleType === "DEALER" ? parentCode : formData.parentCode,
                        icCodes: formData?.sections?.['Insurance Companies'],
                        renewalCategoryIds: formData?.sections?.['Renewal Category'],
                        segmentIds: formData?.sections?.['Vehicle Class'],
                        addonIds: formData?.sections?.['Add On'],
                        dataPullIds: formData?.sections?.['Data Pull']
                    });
                if (response.statusCode === "200") {
                    toast.success(row?.isEdit ? "Lead Pool Updated Successfully." : "Lead Pool Created Successfully.");
                    setTimeout(() => {
                        navigate(`/${encodeURIComponent(encryptRoute('/leadpool'))}`);
                    }, 2500);
                }
                else toast.error(response?.statusMessage);
            } catch (error) {
                toast.error("Something went wrong");
                throw error;
            } finally {
                setLoading(false);
            }
        }
    };

    return (
        <>
            <Paper elevation={0} className="body-formbg" sx={{ width: 'inherit' }}>
                <Paper elevation={0} sx={{ mx: isMobile ? 1.5 : 2.5, mt: 2, borderRadius: 2, py: 1 }}>
                    <Box display="flex" justifyContent="space-between" alignItems="center" px={3} py={1}>
                        <Box>
                            <Typography className={`georama-SemiBold ${isMobile ? 'fs-16' : 'fs-20'}`}>
                                {isViewMode ? row?.bucket_name : `${row?.isEdit ? 'Edit' : 'New'} Lead Pool`}
                            </Typography>

                            <Typography variant="subtitle2">{isViewMode && <>{formData.location?.toString()}</>}</Typography>
                        </Box>

                        <Button
                            className='text-capitalize georama-medium-selected custom-starticon'
                            startIcon={<ChevronLeftIcon />}
                            onClick={() => navigate(-1)}
                        >
                            Back
                        </Button>
                    </Box>

                    {!isViewMode && <Divider sx={{ mb: 2 }} />}

                    {!isViewMode && (
                        <Grid container spacing={2} mb={1.5} px={2.5}>
                            <Grid size={{ xs: 12, sm: 12, md: 4, lg: 4 }}>
                                <Typography className='text-labels' mb={0.5}>
                                    Lead Pool Name <span style={colorRed}>*</span>
                                </Typography>

                                <TextField
                                    className='form-control-input border-radius-8'
                                    size="small"
                                    fullWidth
                                    required
                                    placeholder="Enter Lead Pool Name"
                                    value={formData.bucketName}
                                    onChange={handleFieldChange("bucketName")}
                                    error={Boolean(errors.bucketName)}
                                    InputProps={{ readOnly: row?.isEdit }}
                                />
                                <FormHelperText className='important-fields'>{errors.bucketName}</FormHelperText>
                            </Grid>

                            {userData?.roleType !== "DEALER" &&
                                <Grid size={{ xs: 12, sm: 12, md: 4, lg: 4 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Dealer <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        error={!!errors.dealer}
                                    >
                                        <Autocomplete
                                            className='form-control-input border-radius-8'
                                            size="small"
                                            fullWidth
                                            options={Object.values(dealersCode)}
                                            value={formData.dealer || null}
                                            onChange={(e, newValue) => {
                                                const parentCode = Object.keys(dealersCode).find(
                                                    (key) => dealersCode[key] === newValue
                                                );

                                                setFormData((prev) => ({
                                                    ...prev,
                                                    dealer: newValue || "",
                                                    parentCode: parentCode || "",
                                                    location: []
                                                }));
                                                setErrors((prev) => ({ ...prev, dealer: "" }));
                                            }}
                                            // onChange={(e, newValue) => {
                                            //     setFormData(prev => ({
                                            //         ...prev,
                                            //         dealer: newValue || "",
                                            //     }));
                                            //     setErrors(prev => ({ ...prev, dealer: "" }));
                                            // }}
                                            renderInput={(params) => (
                                                <TextField
                                                    {...params}
                                                    placeholder={formData.dealer ? "" : "Enter Dealer"}
                                                    required
                                                    error={Boolean(errors.dealer)}
                                                />
                                            )}
                                        />
                                    </FormControl>

                                    <FormHelperText className="important-fields">{errors.dealer}</FormHelperText>
                                </Grid>}

                            {userData?.roleType !== "DEALER" &&
                                <Grid size={{ xs: 12, sm: 12, md: 4, lg: 4 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Location <span className="important-fields">*</span>
                                    </Typography>

                                    <Autocomplete
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth multiple
                                        required
                                        // readOnly={row?.isEdit}
                                        error={!!errors.location}
                                        options={locations}
                                        value={Array.isArray(formData.location) ? formData.location : []}
                                        onChange={(e, newValue) => {
                                            setFormData(prev => ({
                                                ...prev,
                                                location: Array.isArray(newValue) ? newValue : [],
                                            }));
                                            setErrors(prev => ({ ...prev, location: "" }));
                                        }}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                placeholder={formData.location ? "" : "Enter Location"}
                                                required
                                                error={Boolean(errors.location)}
                                            />
                                        )}
                                    />
                                    <FormHelperText className="important-fields">{errors.location}</FormHelperText>
                                </Grid>}
                        </Grid>
                    )}
                </Paper>

                {accordionData.map((section, index) => {
                    const isOpen = expanded === index;
                    const selectedOptions = formData.sections[section.title] || [];
                    const allChecked = selectedOptions.length === section.options.length;
                    const someChecked = selectedOptions.length > 0 && !allChecked;

                    return (
                        <Accordion
                            key={section.title}
                            expanded={isOpen}
                            onChange={handleAccordionChange(index)}
                            sx={{
                                borderRadius: 2,
                                boxShadow: "none",
                                my: 1.5,
                                mx: isMobile ? 1.5 : 2.5,
                                p: 0,
                                '&::before': { display: 'none' },
                                '&.Mui-expanded': { mx: isMobile ? 1.5 : 2.5, p: 0 },
                                '& .MuiAccordionSummary-content.Mui-expanded': { m: 0 },
                            }}
                        >
                            <AccordionSummary sx={{ px: 1.5 }} expandIcon={<ExpandMoreIcon />}>
                                {isOpen && !isViewMode ? (
                                    <FormControlLabel
                                        control={
                                            <Checkbox
                                                checked={allChecked}
                                                indeterminate={someChecked}
                                                onChange={(e) => handleHeaderCheck(section.title, e.target.checked, section.options)}
                                                onClick={(e) => e.stopPropagation()}
                                                sx={{ '&.Mui-checked': { color: '#e53935' }, '&.MuiCheckbox-indeterminate': { color: '#e53935' } }}
                                            />
                                        }
                                        label={<Typography fontWeight="bold">{section.title}</Typography>}
                                        sx={{ mx: 0 }}
                                    />
                                ) : (
                                    <Typography fontWeight="bold">{section.title}</Typography>
                                )}
                            </AccordionSummary>

                            {isOpen && <Divider />}

                            <AccordionDetails>
                                <Grid container spacing={isMobile ? 0 : 0.5} ml={isMobile ? 0.5 : 0.5} mt={isMobile ? 0 : 0}>
                                    {section.options.map((opt) => (
                                        <Grid size={{ lg: 4, md: 4, sm: 12, xs: 12 }} key={opt.id}>
                                            {!isViewMode ? <FormControlLabel
                                                slotProps={{
                                                    typography: {
                                                        sx: {
                                                            fontSize: isMobile ? "14px" : "16px",
                                                            my: 1
                                                        },
                                                    },
                                                }}
                                                control={
                                                    <Checkbox
                                                        value={opt.id}
                                                        checked={selectedOptions.includes(opt.id)}
                                                        disabled={isViewMode}
                                                        onChange={(e) =>
                                                            handleItemCheck(section.title, opt, e.target.checked)
                                                        }
                                                        sx={{ '&.Mui-checked': { color: '#e53935' } }}
                                                    />
                                                }
                                                label={opt.label}
                                            /> : <Typography sx={{ mb: 1, fontSize: isMobile ? "14px" : "16px" }}>{opt.label}</Typography>
                                            }
                                        </Grid>
                                    ))}
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                    );
                })}

                {!isViewMode && (
                    <Box display="flex" justifyContent="flex-end" my={1} mx={2}>
                        <Button disabled={loading} className="btn-common-red" onClick={handleSubmit}>
                            Submit
                        </Button>
                    </Box>
                )}
            </Paper>

            <ToastContainer autoClose={1000} />
        </>
    );
}