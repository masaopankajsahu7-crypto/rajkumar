import AddIcon from "@mui/icons-material/Add";
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import RemoveIcon from "@mui/icons-material/Remove";
import { Box, Button, Checkbox, Divider, FormControl, IconButton, InputLabel, MenuItem, Pagination, Paper, Select, Skeleton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import useMediaQuery from '@mui/material/useMediaQuery';
import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import dateFilter from "../assets/images/dashboard/dateFilter.svg";
import performanceSvg from '../assets/images/performance/performance.svg';
import CustomDateRange from '../components/DateRange/CustomDateRange';
import BackdropLoader from "../components/Loader/BackdropLoader";
import { clearLeaderboardCache, pruneLeaderboardCache, setLeaderboardCacheEntry } from '../redux/slices/leaderboardCacheSlice';
import { downloadPerformanceExcel, fetchPerformanceDashboardData } from '../services/api';
import { btnRed } from '../utils/Colors';

const PerformanceDashboard = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const dispatch = useDispatch();
    const userDetails = useSelector((state) => state.user.loggedData);
    const leaderboardCacheEntries = useSelector((state) => state.leaderboardCache?.entries || {});

    const [agentPage, setAgentPage] = useState({});
    const [page, setPage] = useState(1);
    const [limit, setLimit] = useState(10);
    const agentLimit = 10;
    const [count, setCount] = useState(0);

    const [dealerPagination, setDealerPagination] = useState(0);
    const [agentPagination, setAgentPagination] = useState(0);

    const [showExtraColumns, setShowExtraColumns] = useState(false);

    const [selectedSegments, setSelectedSegments] = useState([]);
    const [selectedZones, setselectedZones] = useState([]);
    const [selectedStates, setselectedStates] = useState([]);
    const [selectedDealers, setselectedDealers] = useState([]);
    const [selectedBranches, setselectedBranches] = useState([]);
    const [open, setOpen] = useState(false);
    const anchorRef = useRef(null);
    const [dateSelected, setDateSelected] = useState();
    const [filtersVersion, setFiltersVersion] = useState(0);
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);
    const [stateSelectionOpen, setStateSelectionOpen] = useState(false);
    const [zoneSelectOpen, setZoneSelectOpen] = useState(false);
    const [dealerSelectOpen, setDealerSelectOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [openRow, setOpenRow] = useState(null);

    const [dealerListData, setDealerListData] = useState([]);

    const [dealerSearchText, setDealerSearchText] = useState(""); // 👈 search text state
    const [dealerAgents, setDealerAgents] = useState({});

    // for Renewal category
    const [selectedRenewals, setSelectedRenewals] = useState([]);
    const [renewalSelectOpen, setRenewalSelectOpen] = useState(false);
    const [renewalList, setRenewalcategory] = useState([])
    const [zoneList, setZoneList] = useState([])
    const [stateList, setStateList] = useState([])
    const [dealerList, setDealerList] = useState([])
    const [segmentData, setSegmentData] = useState([]);
    const isDateClearingRef = useRef(false);
    const prevFiltersVersionRef = useRef(filtersVersion);
    const inFlightRequestsRef = useRef({});

    const sortPayloadKeys = (value) => {
        if (Array.isArray(value)) return value.map(sortPayloadKeys);
        if (value && typeof value === "object") {
            return Object.keys(value).sort().reduce((acc, key) => {
                acc[key] = sortPayloadKeys(value[key]);
                return acc;
            }, {});
        }
        return value;
    };

    const makeCacheKey = (scope, payload) => `${scope}::${JSON.stringify(sortPayloadKeys(payload))}`;

    const isValidApiResponse = (response) => (
        response?.status_code === "200" ||
        response?.status_code === "400" ||
        response?.status_message === "Dealer Performance Dashboard Fetched Successfully" ||
        response?.status_message === "Agent Performance Dashboard Fetched Successfully" ||
        response?.status_message === "Dealers Performance Dashboard Fetched Successfully" ||
        response?.status_message === "LeaderBoard details fetched"
    );

    const getCachedResponse = (scope, payload) => {
        const key = makeCacheKey(scope, payload);
        const entry = leaderboardCacheEntries[key];
        if (!entry) return null;
        if ((entry.expiresAt || 0) <= Date.now()) return null;
        return entry.data;
    };

    const getOrFetchWithCache = async (scope, payload, apiCall, options = {}) => {
        const { ttlMs = 5 * 60 * 1000, force = false } = options;
        const cacheKey = makeCacheKey(scope, payload);

        if (!force) {
            const cachedResponse = getCachedResponse(scope, payload);
            if (cachedResponse) return { response: cachedResponse, fromCache: true };

            if (inFlightRequestsRef.current[cacheKey]) {
                const response = await inFlightRequestsRef.current[cacheKey];
                return { response, fromCache: false };
            }
        }

        const requestPromise = (async () => {
            const response = await apiCall(payload);
            if (isValidApiResponse(response)) {
                dispatch(setLeaderboardCacheEntry({ key: cacheKey, data: response, ttlMs }));
            }
            return response;
        })().finally(() => {
            delete inFlightRequestsRef.current[cacheKey];
        });

        inFlightRequestsRef.current[cacheKey] = requestPromise;
        const response = await requestPromise;
        return { response, fromCache: false };
    };

    useEffect(() => {
        // Keep fresh API call on reload/hot-reload, then cache for interactions.
        dispatch(clearLeaderboardCache());
        dispatch(pruneLeaderboardCache());
    }, [dispatch]);


    // for renewal
    const handleRenewalToggle = (renewal) => {
        if (renewal === "all") {
            if (selectedRenewals.length === renewalList.length) {
                setSelectedRenewals([]);
            } else {
                setSelectedRenewals(renewalList?.map((item) => item.id));
            }
        } else {
            const currentIndex = selectedRenewals.indexOf(renewal);
            const newSelected = [...selectedRenewals];

            if (currentIndex === -1) {
                newSelected.push(renewal);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedRenewals(newSelected);
        }
    };

    // for zone 
    const handleZoneChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList?.map(zone => zone.Zone));
            }
        } else {
            setselectedZones(value);
        }
    };
    const handleZoneToggle = (zone) => {
        if (zone === 'all') {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList?.map(zone => zone.Zone));
            }
        } else {
            const currentIndex = selectedZones.indexOf(zone);
            const newSelected = [...selectedZones];

            if (currentIndex === -1) {
                newSelected.push(zone);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedZones(newSelected);
        }
    };

    // for state 
    const handleStateChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList?.map(data => data.State));
            }
        } else {
            setselectedStates(value);
        }
    };
    const handleStateToggle = (state) => {
        if (state === 'all') {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList?.map(data => data.State));
            }
        } else {
            const currentIndex = selectedStates.indexOf(state);
            const newSelected = [...selectedStates];

            if (currentIndex === -1) {
                newSelected.push(state);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedStates(newSelected);
        }
    };

    const handleDealerToggle = (dealerId) => {
        if (dealerId === 'all') {
            if (selectedDealers.length === dealerList.length) {
                setselectedDealers([]);
            } else {
                setselectedDealers(dealerList?.map(data => data.dealer_id));
            }
        } else {
            const currentIndex = selectedDealers.indexOf(dealerId);
            const newSelected = [...selectedDealers];

            if (currentIndex === -1) {
                newSelected.push(dealerId);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedDealers(newSelected);
        }
    };

    // for segment 
    const handleSegmentChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData?.map(seg => seg.segment));
            }
        } else {
            setSelectedSegments(value);
        }
    };
    const handleSegmentToggle = (segment) => {
        if (segment === 'all') {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData?.map(seg => seg.segment));
            }
        } else {
            const currentIndex = selectedSegments.indexOf(segment);
            const newSelected = [...selectedSegments];

            if (currentIndex === -1) {
                newSelected.push(segment);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedSegments(newSelected);
        }
    };

    // Filter dealer list by search
    const filteredDealers = dealerList?.filter((d) =>
        d?.dealer_name?.toLowerCase()?.includes(dealerSearchText?.toLowerCase())
    );

    // NOTE: Keep API calls centralized in one effect; UI handlers only bump `filtersVersion`.

    const handleToggleAccordion = async (index, row) => {
        setAgentPage({})
        if (openRow === index) {
            setOpenRow(null);
            return;
        }

        setOpenRow(index);
        const currentPage = 1;

        // prevent refetch if already loaded
        // if (dealerAgents[row.dealerId]) return;

        await fetchDealerAgents(row.dealerId, dateSelected, currentPage, agentLimit);
    };

    const selectedRenewalNames = renewalList
        .filter((item) => selectedRenewals.includes(item.id))
        ?.map((item) => item.renewal_year);

    const fetchMiblPerformanceDash = async () => {

        if (!userDetails?.user_id) return;
        setOpenRow(null);

        try {
            const payload = {
                dealerCode: userDetails?.dealerCode || "",
                userId: userDetails?.user_id || "",
                roleType: userDetails?.roleType === "MIBL" ? "mibl" : "dealer",
                type: "PerformanceBoard",
                limit: limit,
                offset: page,
                startDate: "",
                endDate: "",
                renewalCategory: "",
                zone: "",
                state: "",
                dealerLocCode: "",
                segment: "",
                checkType: ""
            }

            const cachedResponse = getCachedResponse("performance-main", payload);
            if (!cachedResponse) setLoading(true);
            const { response } = await getOrFetchWithCache(
                "performance-main",
                payload,
                fetchPerformanceDashboardData,
                { ttlMs: 2 * 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "Dealer Performance Dashboard Fetched Successfully") {
                const { result0, result1, result2, result3, result4, result5, result6, result7, result8, result9, result10 } = response;
                setSegmentData(result0 || []);
                setRenewalcategory(result1 || []);
                setZoneList(result2 || []);
                setStateList(result3 || []);
                setDealerList(result4 || []);
                setDealerListData(result5 || []);
                setDealerPagination(result6[0]?.["dealerCount"] || 0);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const fetchDealerPerformanceDash = async () => {

        if (!userDetails?.user_id) return;

        try {
            const payload = {
                dealerCode: userDetails?.dealerCode || "",
                userId: userDetails?.user_id || "",
                roleType: userDetails?.roleType === "MIBL" ? "mibl" : "dealer",
                type: "PerformanceBoard",
                limit: limit,
                offset: page,
                startDate: "",
                endDate: "",
                renewalCategory: "",
                zone: "",
                state: "",
                dealerLocCode: "",
                segment: ""
            }

            const cachedResponse = getCachedResponse("performance-main", payload);
            if (!cachedResponse) setLoading(true);
            const { response } = await getOrFetchWithCache(
                "performance-main",
                payload,
                fetchPerformanceDashboardData,
                { ttlMs: 2 * 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "Agent Performance Dashboard Fetched Successfully") {
                if (userDetails?.roleType === "MIBL") {
                    const { result0, result1 } = response;
                    setDealerListData(result0);
                    setDealerListData(result1[0]?.paginationCount);
                } else {
                    const { result0, result1, result2, result3, result4, result5, result6, result7, result8, result9, result10 } = response;
                    setSegmentData(result0 || []);
                    setRenewalcategory(result1 || []);
                    setZoneList(result2 || []);
                    setStateList(result3 || []);
                    setDealerList(result4 || []);
                    setDealerListData(result5 || []);
                    setDealerPagination(result6[0]?.["agentCount"] || 0);
                }
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const filterMiblPerformanceDash = async (dateParam) => {
        setOpenRow(null);
        if (!userDetails?.user_id) return;

        const date = dateParam !== undefined ? dateParam : dateSelected;

        try {
            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            let isFilterEmpty;
            if (userDetails?.roleType === "MIBL") {
                isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedZones.length === 0 &&
                    selectedStates.length === 0 &&
                    selectedDealers.length === 0 &&
                    selectedSegments.length === 0 && isDateEmpty;
            } else {
                isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedSegments.length === 0 && isDateEmpty;
            }

            const payload = {
                type: isFilterEmpty ? "PerformanceBoard" : "performanceFilter",
                renewalCategory: selectedRenewalNames.join(","),
                zone: selectedZones.join(","),
                state: selectedStates.join(","),
                segment: selectedSegments.join(","),
                dealerLocCode: "",
                dealerCode: userDetails?.roleType === 'MIBL' ? selectedDealers.join(",") : userDetails?.dealerCode,
                startDate: date?.startDate || "",
                endDate: date?.endDate || "",
                roleType: userDetails?.roleType === "MIBL" ? "mibl" : "dealer",
                limit: limit,
                userId: userDetails?.user_id,
                offset: page,
                checkType: ""
            }

            const cachedResponse = getCachedResponse("performance-main", payload);
            if (!cachedResponse) setLoading(true);
            const { response } = await getOrFetchWithCache(
                "performance-main",
                payload,
                fetchPerformanceDashboardData,
                { ttlMs: 2 * 60 * 1000 }
            );

            if (response?.status_code === "200" || response?.status_message === "LeaderBoard details fetched") {
                const { result0, result1, result2, result3, result4, result5, result6, result7, result8, result9, result10 } = response;
                setSegmentData(result0 || []);
                setRenewalcategory(result1 || []);
                setZoneList(result2 || []);
                setStateList(result3 || []);
                setDealerList(result4 || []);
                setDealerListData(result5 || []);
                setDealerPagination(userDetails?.roleType === "MIBL" ? result6[0]?.["dealerCount"] : result6[0]?.["agentCount"] || 0);
            } else if (response?.status_code === "400") {
                const { result0, result1, result2, result3, result4, result5, result6, result7, result8, result9, result10 } = response;
                setSegmentData(result0 || []);
                setRenewalcategory(result1 || []);
                setZoneList(result2 || []);
                setStateList(result3 || []);
                setDealerList(result4 || []);
                setDealerListData(result5 || []);
                setDealerPagination(result6[0]?.["dealerCount"] || 0);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const fetchDealerAgents = async (dealerCode, dateParam, page = 1, limit = 10) => {

        if (!userDetails?.user_id) return;

        const date = dateParam !== undefined ? dateParam : dateSelected;

        const isDateEmpty =
            !date ||
            !date.startDate ||
            !date.endDate ||
            date.startDate === "Invalid Date" ||
            date.endDate === "Invalid Date";

        try {
            const isFilterEmpty =
                selectedRenewals.length === 0 &&
                selectedZones.length === 0 &&
                selectedStates.length === 0 &&
                selectedDealers.length === 0 &&
                selectedSegments.length === 0 && isDateEmpty;

            const payload = {
                dealerCode: dealerCode,
                userId: userDetails?.user_id || "",
                type: isFilterEmpty ? "PerformanceBoard" : "performanceFilter",
                roleType: userDetails?.roleType === "MIBL" ? "mibl" : "dealer",
                limit: limit,
                offset: page,
                startDate: date?.startDate || "",
                endDate: date?.endDate || "",
                renewalCategory: selectedRenewalNames.join(","),
                zone: selectedZones.join(","),
                state: selectedStates.join(","),
                dealerLocCode: "",
                segment: selectedSegments.join(","),
                checkType: "FetchDealerAgent"
            }

            const cachedResponse = getCachedResponse("performance-agents", payload);
            if (!cachedResponse) setLoading(true);

            const { response } = await getOrFetchWithCache(
                "performance-agents",
                payload,
                fetchPerformanceDashboardData,
                { ttlMs: 60 * 1000 }
            );

            if (
                response?.status_code === "200" ||
                response?.status_message === "Dealers Performance Dashboard Fetched Successfully"
            ) {
                const { result5, result6 } = response;
                setDealerAgents(prev => ({
                    ...prev,
                    [dealerCode]: result5
                }));
                setAgentPagination(result6[0]?.["agentCount"] || []);
            } else {
                console.error("Failed to fetch agents:", response);
            }

        } catch (err) {
            console.error("Error fetching agents:", err);
        } finally {
            setLoading(false);
        }
    };

    const getIsDateEmpty = (date) =>
        !date ||
        !date.startDate ||
        !date.endDate ||
        date.startDate === "Invalid Date" ||
        date.endDate === "Invalid Date";

    const getIsFilterEmpty = () => {
        const isDateEmpty = getIsDateEmpty(dateSelected);

        if (userDetails?.roleType === "MIBL") {
            return (
                selectedRenewals.length === 0 &&
                selectedZones.length === 0 &&
                selectedStates.length === 0 &&
                selectedDealers.length === 0 &&
                selectedSegments.length === 0 &&
                isDateEmpty
            );
        }

        return selectedRenewals.length === 0 && selectedSegments.length === 0 && isDateEmpty;
    };

    // Single loader effect (prevents duplicate API calls)
    useEffect(() => {
        if (!userDetails?.user_id) return;

        // When user applies/changes filters (or date), always restart main listing from offset 1.
        if (prevFiltersVersionRef.current !== filtersVersion) {
            prevFiltersVersionRef.current = filtersVersion;
            if (page !== 1) {
                setPage(1);
                return;
            }
        }

        if (getIsFilterEmpty()) {
            if (userDetails?.roleType === "MIBL") fetchMiblPerformanceDash();
            else fetchDealerPerformanceDash();
        } else {
            filterMiblPerformanceDash();
        }
    }, [page, limit, dateSelected, filtersVersion, dispatch, userDetails?.user_id]);

    const handleClearFilters = (type) => {
        const resetters = {
            renewal: setSelectedRenewals,
            zone: setselectedZones,
            state: setselectedStates,
            dealer: setselectedDealers,
            branch: setselectedBranches,
            segment: setSelectedSegments,
        };

        if (resetters[type]) {
            resetters[type]([]);
            setPage(1);
            setFiltersVersion((v) => v + 1);
        }
    };

    const downloadPerformance = async (type, dateParam) => {
        try {
            setLoading(true);
            let payload;

            const date = dateParam && dateParam.startDate ? dateParam : dateSelected;

            const isDealer = userDetails?.roleType === "DEALER";

            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            const isDealerFilterEmpty =
                selectedRenewals.length === 0 &&
                selectedSegments.length === 0 && isDateEmpty;

            const isMiblFilterEmpty =
                selectedRenewals.length === 0 &&
                selectedZones.length === 0 &&
                selectedStates.length === 0 &&
                selectedDealers.length === 0 &&
                selectedSegments.length === 0 && isDateEmpty;

            const downloadTypeValue = isDealer
                ? (isDealerFilterEmpty ? "dealerExcel" : "dealerFilterExcel")
                : (isMiblFilterEmpty ? "miblExcel" : "miblFilterExcel");

            payload = {
                type: downloadTypeValue,
                dealerCode: userDetails?.dealerCode || "",
                userId: userDetails?.user_id || "",
                roleType: userDetails?.roleType === "DEALER" ? "dealer" : "mibl",
                downloadType: type,
                startDate: !isDateEmpty ? date.startDate : "",
                endDate: !isDateEmpty ? date.endDate : "",
                renewalCategory: selectedRenewalNames.join(","),
                zone: selectedZones.join(","),
                state: selectedStates.join(","),
                dealerLocCode: selectedDealers.join(","),
                segment: selectedSegments.join(",")
            }

            const result = await downloadPerformanceExcel(payload);

            if (result?.data) {
                const blob = new Blob([result.data], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                });

                const url = window.URL.createObjectURL(blob);
                const link = document.createElement("a");

                link.href = url;
                link.download = type === "static" ? "Performance_Score.xlsx" : "Performance_Score_MIS.xlsx";

                document.body.appendChild(link);
                link.click();

                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error("Error downloading Excel file:", error);
        } finally {
            setLoading(false);
        }
    };

    const stickyFirstCol = {
        position: "sticky",
        left: 0,
        zIndex: 3,
        background: "#fff",
    };

    return (
        <>
            <Paper className="body-formbg table-auto-width" elevation={0} sx={{ boxShadow: 'none' }}>
                <BackdropLoader loading={loading} />
                <Box py={isMobile ? 1.3 : 0.5} px={isMobile ? 1.5 : 2}>
                    <Box display={'flex'} flexWrap={"wrap"} justifyContent="space-between" alignItems="center" mb={1.2} mt={1}>
                        <Box display={'flex'} alignItems="center" justifyContent={"start"} mb={1}>
                            <Typography px={1} className={`georama-SemiBold ${isMobile ? "fs-16" : "fs-20"}`}>Performance Dashboard</Typography>
                        </Box>

                        <Box display="flex" gap={1} flexWrap={"wrap"}>
                            <FormControl
                                size="small"
                                sx={{
                                    width: 300,
                                    minWidth: 170,
                                    maxWidth: 170,
                                    backgroundColor: "#ffffff",
                                    borderRadius: 2,
                                }}
                            >
                                <InputLabel id="renewal-label" className="dropdown-label">
                                    Renewal Category
                                </InputLabel>

                                <Select
                                    className="georama-Medium"
                                    labelId="renewal-label"
                                    id="renewal-select"
                                    multiple
                                    value={selectedRenewals}
                                    label="Renewal Category"
                                    open={renewalSelectOpen}
                                    onClose={() => setRenewalSelectOpen(false)}
                                    onOpen={() => setRenewalSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === renewalList.length) return "All";

                                        return renewalList
                                            .filter((data) => selected.includes(data.id))
                                            ?.map((data) => data.renewal_year)
                                            .join(", ");
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                position: "fixed",
                                                zIndex: 1500,
                                            },
                                        },
                                    }}
                                >

                                    {/* All Option */}
                                    <MenuItem
                                        disableGutters
                                        sx={{ py: 0, px: 1, m: 0 }}
                                        value="all"
                                        onClick={() => handleRenewalToggle("all")}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                                "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                            }}
                                            checked={selectedRenewals.length === renewalList.length}
                                            indeterminate={
                                                selectedRenewals.length > 0 &&
                                                selectedRenewals.length < renewalList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    {/* Renewal Category List */}
                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: "auto",
                                            pr: 1,
                                        }}
                                    >
                                        {renewalList?.map((data) => (
                                            <MenuItem
                                                disableGutters
                                                sx={{ py: 0, px: 1, m: 0 }}
                                                key={data.id}
                                                value={data.id}
                                                onClick={() => handleRenewalToggle(data.id)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        "&.Mui-checked": { color: "#e53935" },
                                                    }}
                                                    checked={selectedRenewals.includes(data.id)}
                                                />
                                                {data.renewal_year}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    {/* Buttons */}
                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            size="small"
                                            onClick={() => {
                                                handleClearFilters("renewal");
                                                setRenewalSelectOpen(false);
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: "none",
                                                px: 1,
                                                my: 1,
                                                mx: 1,
                                                color: "black",
                                                backgroundColor: "transparent",
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className="btn-common-red"
                                            size="small"
                                            sx={{
                                                mx: 2,
                                                my: 1,
                                                ...btnRed,
                                            }}
                                            onClick={() => {
                                                setPage(1);
                                                setFiltersVersion((v) => v + 1);
                                                setRenewalSelectOpen(false);
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>

                                </Select>
                            </FormControl>

                            {userDetails.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel id="zone-label" className="dropdown-label">Zone</InputLabel>

                                <Select
                                    className='georama-Medium'
                                    labelId="zone-label"
                                    id="zone-select"
                                    multiple
                                    value={selectedZones}
                                    label="Zone"
                                    onChange={handleZoneChange}
                                    open={zoneSelectOpen}
                                    onClose={() => setZoneSelectOpen(false)}
                                    onOpen={() => setZoneSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === zoneList?.length) return "All";
                                        return zoneList
                                            .filter(zone => selected.includes(zone.Zone))
                                            ?.map(zone => zone.Zone)
                                            .join(',');
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                // maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                >
                                    <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                        onClick={() => handleZoneToggle('all')}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedZones.length === zoneList?.length}
                                            indeterminate={
                                                selectedZones.length > 0 &&
                                                selectedZones.length < zoneList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {zoneList && zoneList?.map((zone, index) => (
                                            <MenuItem
                                                className={selectedZones.includes(zone.Zone) ? 'georama- fs-14' : ''}
                                                disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={zone.Zone}
                                                onClick={() => handleZoneToggle(zone.Zone)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedZones.includes(zone.Zone)}
                                                />

                                                {zone.Zone}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            // disabled={selectedZones.length === 0}
                                            fullWidth
                                            size="small"
                                            onClick={() => {
                                                if (selectedZones.length > 0) {
                                                    handleClearFilters("zone");
                                                    setZoneSelectOpen(false);
                                                }
                                            }}
                                            sx={{
                                                width: "50%",
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            // disabled={selectedZones.length === 0}
                                            variant="contained"
                                            fullWidth
                                            className='btn-common-red'
                                            size="small"
                                            sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedZones.length > 0) {
                                                    setPage(1);
                                                    setFiltersVersion((v) => v + 1);
                                                    setZoneSelectOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            {userDetails.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel id="state-label" className="dropdown-label">State</InputLabel>

                                <Select
                                    className='georama-Medium'
                                    labelId="state-label"
                                    id="state-select"
                                    multiple
                                    value={selectedStates}
                                    label="State"
                                    onChange={handleStateChange}
                                    open={stateSelectionOpen}
                                    onClose={() => setStateSelectionOpen(false)}
                                    onOpen={() => setStateSelectionOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === stateList?.length) return "All";
                                        return stateList
                                            .filter(data => selected.includes(data.State))
                                            ?.map(data => data.State)
                                            .join(',');
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                // maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                >
                                    <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                        onClick={() => handleStateToggle('all')}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedStates.length === stateList?.length}
                                            indeterminate={
                                                selectedStates.length > 0 &&
                                                selectedStates.length < stateList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {stateList && stateList?.map((data, index) => (
                                            <MenuItem
                                                className={selectedStates.includes(data.State) ? 'georama- fs-14' : ''}
                                                disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={data.State}
                                                onClick={() => handleStateToggle(data.State)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedStates.includes(data.State)}
                                                />

                                                {data.State}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            // disabled={selectedStates.length === 0}
                                            size="small"
                                            fullWidth
                                            onClick={() => {
                                                if (selectedStates.length > 0) {
                                                    handleClearFilters("state");
                                                    setStateSelectionOpen(false);
                                                }
                                            }}
                                            sx={{
                                                width: "50%",
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className='btn-common-red'
                                            fullWidth
                                            // disabled={selectedStates.length === 0}
                                            size="small"
                                            sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedStates.length > 0) {
                                                    setPage(1);
                                                    setFiltersVersion((v) => v + 1);
                                                    setStateSelectionOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            {userDetails.roleType === "MIBL" && <FormControl
                                size="small"
                                sx={{
                                    width: 300,
                                    minWidth: 100,
                                    maxWidth: 100,
                                    backgroundColor: "#ffffff",
                                    borderRadius: 2,
                                }}
                            >
                                <InputLabel id="dealer-label" className="dropdown-label">
                                    Dealers
                                </InputLabel>

                                <Select
                                    className="georama-Medium"
                                    labelId="dealer-label"
                                    id="dealer-select"
                                    multiple
                                    value={selectedDealers}
                                    label="Dealer"
                                    open={dealerSelectOpen}
                                    onClose={() => setDealerSelectOpen(false)}
                                    onOpen={() => setDealerSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === dealerList?.length) return "All";
                                        return dealerList
                                            .filter((data) => selected.includes(data.dealer_id))
                                            ?.map((data) => data.dealer_name)
                                            .join(", ");
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                position: "fixed",
                                                zIndex: 1500,
                                                // width: 300,
                                            },
                                        },
                                    }}
                                >
                                    {/* 🔍 Search input (Autocomplete-like) */}
                                    <Box
                                        sx={{
                                            p: 1,
                                            position: "sticky",
                                            top: 0,
                                            background: "#fff",
                                            zIndex: 2,
                                        }}
                                    >
                                        <input
                                            type="text"
                                            placeholder="Search dealer..."
                                            value={dealerSearchText}
                                            onChange={(e) => setDealerSearchText(e.target.value)}
                                            onKeyDown={(e) => e.stopPropagation()}
                                            style={{
                                                width: "90%",
                                                padding: "6px 8px",
                                                borderRadius: "6px",
                                                border: "1px solid #ccc",
                                                fontSize: "13px",
                                            }}
                                        />
                                    </Box>

                                    {/* “All” Option */}
                                    <MenuItem
                                        disableGutters
                                        sx={{ py: 0, px: 1, m: 0 }}
                                        value="all"
                                        onClick={() => handleDealerToggle("all")}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                                "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                            }}
                                            checked={selectedDealers.length === dealerList?.length}
                                            indeterminate={
                                                selectedDealers.length > 0 &&
                                                selectedDealers.length < dealerList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    {/* Filtered Dealers */}
                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: "auto",
                                            pr: 1,
                                        }}
                                    >
                                        {filteredDealers && filteredDealers.length > 0 ? (
                                            filteredDealers?.map((data, index) => (
                                                <MenuItem
                                                    disableGutters
                                                    sx={{ py: 0, px: 1, m: 0 }}
                                                    key={index}
                                                    value={data.dealer_id}
                                                    onClick={() => handleDealerToggle(data.dealer_id)}
                                                >
                                                    <Checkbox
                                                        sx={{
                                                            "&.Mui-checked": { color: "#e53935" },
                                                            "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                        }}
                                                        checked={selectedDealers.includes(data.dealer_id)}
                                                    />
                                                    {data.dealer_name}
                                                </MenuItem>
                                            ))
                                        ) : (
                                            <MenuItem disabled>No results found</MenuItem>
                                        )}
                                    </Box>

                                    {/* Buttons */}
                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            fullWidth
                                            size="small"
                                            onClick={() => {
                                                if (selectedDealers.length > 0) {
                                                    handleClearFilters("dealer");
                                                    setDealerSelectOpen(false);
                                                    setDealerSearchText("");
                                                }
                                            }}
                                            sx={{
                                                width: "50%",
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className="btn-common-red"
                                            size="small"
                                            fullWidth
                                            sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedDealers.length > 0) {
                                                    setPage(1);
                                                    setFiltersVersion((v) => v + 1);
                                                    setDealerSelectOpen(false);
                                                    setDealerSearchText("");
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            <FormControl className='' size="small" sx={{ minWidth: 110, maxWidth: 110, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel id="segment-label" className="dropdown-label">Segment</InputLabel>

                                <Select
                                    className='georama-Medium'
                                    labelId="segment-label"
                                    id="segment-select"
                                    multiple
                                    value={selectedSegments}
                                    label="segment"
                                    onChange={handleSegmentChange}
                                    open={segmentSelectOpen}
                                    onClose={() => setSegmentSelectOpen(false)}
                                    onOpen={() => setSegmentSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === segmentData?.length) return "All";
                                        return segmentData
                                            .filter(seg => selected.includes(seg.segment))
                                            ?.map(seg => seg.segment)
                                            .join(',');
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                // maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                >
                                    <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                        onClick={() => handleSegmentToggle('all')}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedSegments.length === segmentData?.length}
                                            indeterminate={
                                                selectedSegments.length > 0 &&
                                                selectedSegments.length < segmentData.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {segmentData && segmentData?.map((seg, index) => (
                                            <MenuItem
                                                className={selectedSegments.includes(seg.segment) ? 'georama- fs-14' : ''}
                                                disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={seg.segment}
                                                onClick={() => handleSegmentToggle(seg.segment)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedSegments.includes(seg.segment)}
                                                />

                                                {seg.segment}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            // disabled={selectedSegments.length === 0}
                                            fullWidth
                                            variant="contained"
                                            size="small"
                                            onClick={() => {
                                                if (selectedSegments.length > 0) {
                                                    handleClearFilters("segment");
                                                    setSegmentSelectOpen(false);
                                                }
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                mx: 1,
                                                color: "black",
                                                backgroundColor: 'transparent',
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            // disabled={selectedSegments.length === 0}
                                            className='btn-common-red'
                                            size="small"
                                            sx={{ mx: 2, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedSegments.length > 0) {
                                                    setPage(1);
                                                    setFiltersVersion((v) => v + 1);
                                                    setSegmentSelectOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>


                            <Box>
                                <Button className='bg-white text-gray text-capitalize border-light-gray border-radius-8' ref={anchorRef} onClick={() => setOpen(true)}>
                                    <img className='px-1' src={dateFilter} alt="" />

                                    <Typography className="dropdown-label" mt={0.5} px={1}>Date Range</Typography>
                                </Button>

                                <CustomDateRange
                                    open={open}
                                    anchorRef={anchorRef}
                                    setOpen={setOpen}
                                    setDate={(date) => {
                                        setPage(1);
                                        setDateSelected(date);
                                        setFiltersVersion((v) => v + 1);
                                    }}
                                    onChange={undefined}
                                    clearDate={() => {
                                        isDateClearingRef.current = true;
                                        setPage(1);
                                        setDateSelected("");
                                        setFiltersVersion((v) => v + 1);
                                        setOpen(false);
                                        // fetchapi({ isReset: true });
                                    }}
                                />
                            </Box>
                        </Box>
                    </Box>
                </Box>
                <Box mx={isMobile ? 1 : 2} mb={1.5} className="bg-white border-radius-8">
                    <Box p={1} display={'flex'} flexWrap={"wrap"} alignItems="center" justifyContent={"space-between"}>
                        <Box display={'flex'} alignItems="center" justifyContent={"space-between"} >
                            <img src={performanceSvg} alt="Performance" />
                            <Typography px={1} className={`georama-SemiBold ${isMobile ? "fs-14" : "fs-16"}`}>Performance Score</Typography>
                        </Box>
                        <Box display={"flex"} flexWrap={"wrap"} mr={isMobile ? 0 : 2} gap={isMobile ? 0.5 : 1.5}
                            alignItems={"center"} justifyContent={"center"} mt={1}>
                            <Button
                                sx={{ fontSize: isMobile ? 10 : 14 }}
                                onClick={() => downloadPerformance("static", "")}
                                endIcon={<FileDownloadIcon />}
                                className="btn-common-red"
                            >
                                Download
                            </Button>
                            <Button
                                sx={{ fontSize: isMobile ? 10 : 14 }}
                                onClick={() => downloadPerformance("dynamic", "")}
                                endIcon={<FileDownloadIcon />}
                                className="btn-common-red"
                            >
                                Download MIS
                            </Button>
                        </Box>
                    </Box>

                    <Divider />

                    {/* ===================== TABLE ===================== */}

                    <Box position="relative" overflow={'hidden'} mx={1}>
                        {/* ===================== TABLE ===================== */}
                        <TableContainer
                            component={Box}
                            sx={{
                                mt: 1,
                                overflowX: "auto",
                                // maxWidth: userDetails?.roleType === "MIBL" ? "1248px" : "1500px",
                                maxWidth: userDetails?.roleType === "MIBL" ? "1235px" : "100%",
                                minWidth: "100%",

                                /* Force smooth scrolling */
                                WebkitOverflowScrolling: "touch",

                                /* ===== Scrollbar ===== */
                                "&::-webkit-scrollbar": {
                                    height: "1px",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                    backgroundColor: "#999",
                                    borderRadius: "10px",
                                },
                                "&::-webkit-scrollbar-track": {
                                    background: "transparent",
                                },

                                "&:hover::-webkit-scrollbar-thumb": {
                                    backgroundColor: "#999",
                                },

                                scrollbarColor: "#999 transparent",
                            }}
                        >
                            <Table
                                sx={{
                                    // px: 1,
                                    // minWidth: 1200,
                                    // overflow: 'hidden',
                                    borderCollapse: "separate",
                                    borderSpacing: "0 4px",
                                }} stickyHeader>
                                {/* -------- Header -------- */}
                                <TableHead>
                                    <TableRow
                                        sx={{
                                            "& th": {
                                                borderBottom: "none",
                                                backgroundColor: "#fff",
                                            },
                                            "& th:first-of-type": {
                                                borderTopLeftRadius: "8px",
                                                borderBottomLeftRadius: "8px",
                                            },
                                            "& th:last-of-type": {
                                                borderTopRightRadius: "8px",
                                                borderBottomRightRadius: "8px",
                                            },
                                        }}
                                    >
                                        <TableCell sx={{ minWidth: 150, maxWidth: 150, ...stickyFirstCol, }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            {userDetails?.roleType === "DEALER" ? "Agent Name" : "Dealer Name"}
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Leads Assigned
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Leads Contacted
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Policies Converted
                                        </TableCell>

                                        <TableCell sx={{ minWidth: showExtraColumns ? 120 : isMobile ? 120 : 90, maxWidth: showExtraColumns ? 120 : 90 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Net Premium Collected (INR)
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Conversion Ratio (%)
                                        </TableCell>
                                        <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Retention Ratio (%)
                                        </TableCell>

                                        <TableCell sx={{ minWidth: 100, maxWidth: 100 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Follow-up Efficiency (%)
                                        </TableCell>

                                        {showExtraColumns && (
                                            <>
                                                <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                                    Performance Score
                                                </TableCell>

                                                <TableCell sx={{ minWidth: 160, maxWidth: 160 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                                    Dynamic Performance Score
                                                </TableCell>

                                                <TableCell sx={{ minWidth: 100, maxWidth: 100 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                                    Overall Score
                                                </TableCell>
                                            </>
                                        )}

                                        <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="fw-none p-3 text-dark georama-Medium fs-14 body-formbg">
                                            Rank
                                        </TableCell>

                                        <IconButton
                                            onClick={() => setShowExtraColumns(!showExtraColumns)}
                                            sx={{
                                                position: "absolute",
                                                right: 30,
                                                top: 30,
                                                zIndex: 5,
                                                background: "#2E3A59",
                                                color: "#fff",
                                                width: 20,
                                                height: 20,
                                                "&:hover": { background: "#1f2a44" }
                                            }}
                                        >
                                            {showExtraColumns ? <RemoveIcon fontSize="small" /> : <AddIcon fontSize="small" />}
                                        </IconButton>

                                    </TableRow>
                                </TableHead>

                                {/* -------- Body -------- */}
                                <TableBody>
                                    {loading ? (
                                        [...Array(8)].map((_, idx) => (
                                            <TableRow key={idx}>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                            </TableRow>
                                        ))
                                    ) : (dealerListData && dealerListData.length > 0 ? (
                                        dealerListData?.map((row, index) => (
                                            <React.Fragment key={index}>
                                                {/* -------- Dealer Row -------- */}
                                                <TableRow
                                                    // hover
                                                    sx={{
                                                        backgroundColor: openRow === index ? "#F0F1F5" : "#FFF",
                                                        borderRadius: 2,
                                                        border: openRow === index ? "1px solid #DADDE5" : "1px solid #F0F1F5",
                                                        transition: "all 0.2s ease",
                                                        "& td": {
                                                            borderTop: "1px solid #F0F1F5",
                                                            borderBottom: "1px solid #F0F1F5"
                                                        },
                                                        "& td:first-of-type": {
                                                            borderLeft: "1px solid #F0F1F5",
                                                            borderTopLeftRadius: "8px",
                                                            borderBottomLeftRadius: openRow === index ? "0px" : "8px"
                                                        },
                                                        "& td:last-of-type": {
                                                            borderRight: "1px solid #F0F1F5",
                                                            borderTopRightRadius: "8px",
                                                            borderBottomRightRadius: openRow === index ? "0px" : "8px"
                                                        }
                                                    }}
                                                >
                                                    <TableCell sx={{ minWidth: 150, maxWidth: 150, ...stickyFirstCol, backgroundColor: openRow === index ? "#F0F1F5" : "#FFF" }} className="georama-Regular fs-12">
                                                        <Box display="flex" alignItems="center" gap={1}>
                                                            {userDetails?.roleType !== "DEALER" && (
                                                                <IconButton
                                                                    size="small"
                                                                    onClick={() => handleToggleAccordion(index, row)}
                                                                >
                                                                    {openRow === index
                                                                        ? <KeyboardArrowUpIcon fontSize="small" />
                                                                        : <KeyboardArrowDownIcon fontSize="small" />}
                                                                </IconButton>
                                                            )}

                                                            <span>
                                                                {userDetails?.roleType === "DEALER"
                                                                    ? row.agentName
                                                                    : row.dealerName}
                                                            </span>

                                                        </Box>
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                        {row.leadsAssigned || 0}
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                        {row.leadsContacted || 0}
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                        {row.policiesConverted || 0}
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: showExtraColumns ? 120 : 90, maxWidth: showExtraColumns ? 120 : 90 }} className="georama-Regular fs-12">
                                                        {row?.netPremiumCollected || 0}
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                        {row?.conversionRate || 0}%
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                        {row?.retentionRate || 0}%
                                                    </TableCell>

                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                        {row?.followUpEfficiency || 0}%
                                                    </TableCell>

                                                    {showExtraColumns && (
                                                        <>
                                                            <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                                {row?.performanceScore || 0}
                                                            </TableCell>

                                                            <TableCell sx={{ minWidth: 160, maxWidth: 160 }} className="georama-Regular fs-12">
                                                                {row?.dynamicPerformanceScore || 0}
                                                            </TableCell>

                                                            <TableCell sx={{ minWidth: 100, maxWidth: 100 }} className="georama-Regular fs-12">
                                                                {row?.overallScore || 0}
                                                            </TableCell>
                                                        </>
                                                    )}

                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                        {row.rank || 0}
                                                    </TableCell>

                                                </TableRow>

                                                {/* -------- Accordion Row -------- */}
                                                {openRow === index && dealerAgents[row.dealerId] && (() => {

                                                    const currentPage = agentPage[row.dealerId] || 1;

                                                    const paginatedAgents = dealerAgents[row.dealerId] || [];

                                                    return (
                                                        <TableRow className="td-table"
                                                            sx={{
                                                                position: "relative",
                                                                top: "-4px",
                                                                zIndex: 1,
                                                            }}>
                                                            <TableCell colSpan={12} sx={{ p: 0, m: 0 }}>
                                                                <Table
                                                                    size="small"
                                                                    sx={{
                                                                        width: "100%",
                                                                    }}
                                                                >
                                                                    <TableBody>
                                                                        {paginatedAgents && paginatedAgents.length > 0 ? (
                                                                            paginatedAgents?.map((agent, i) => (
                                                                                <TableRow key={i}
                                                                                    sx={{
                                                                                        border: "1px solid #F0F1F5"
                                                                                    }}
                                                                                >

                                                                                    <TableCell sx={{ minWidth: 150, maxWidth: 150, ...stickyFirstCol }} className="georama-Regular fs-12">
                                                                                        {agent.agentName}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                                                        {agent.leadsAssigned || 0}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                                                        {agent.leadsContacted || 0}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 60, maxWidth: 60 }} className="georama-Regular fs-12">
                                                                                        {agent.policiesConverted || 0}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: showExtraColumns ? 120 : 90, maxWidth: showExtraColumns ? 120 : 90 }} className="georama-Regular fs-12">
                                                                                        {agent?.netPremiumCollected || 0}
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                                                        {agent?.conversionRate || 0}%
                                                                                    </TableCell>
                                                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                                                        {agent?.retentionRate || 0}%
                                                                                    </TableCell>

                                                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                                                        {agent?.followUpEfficiency || 0}%
                                                                                    </TableCell>

                                                                                    {showExtraColumns && (
                                                                                        <>
                                                                                            <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                                                                {agent?.performanceScore || 0}
                                                                                            </TableCell>

                                                                                            <TableCell sx={{ minWidth: 160, maxWidth: 160 }} className="georama-Regular fs-12">
                                                                                                {agent?.dynamicPerformanceScore || 0}
                                                                                            </TableCell>

                                                                                            <TableCell sx={{ minWidth: 100, maxWidth: 100 }} className="georama-Regular fs-12">
                                                                                                {agent?.overallScore || 0}
                                                                                            </TableCell>
                                                                                        </>
                                                                                    )}
                                                                                    <TableCell sx={{ minWidth: 80, maxWidth: 80 }} className="georama-Regular fs-12">
                                                                                        {agent.rank || 0}
                                                                                    </TableCell>
                                                                                </TableRow>
                                                                            ))
                                                                        ) : (
                                                                            <TableRow className='no-td'>
                                                                                <TableCell colSpan={4} align="center" sx={{ py: 3, borderBottom: agentPagination == 0 ? "none" : "" }}>
                                                                                    No Data found
                                                                                </TableCell>
                                                                            </TableRow>
                                                                        )}
                                                                    </TableBody>
                                                                </Table>

                                                                {/* -------- Agent Pagination -------- */}
                                                                {!!agentPagination && <Box
                                                                    display="flex"
                                                                    justifyContent="flex-end"
                                                                    alignItems="center"
                                                                    p={1.5}
                                                                >
                                                                    <Pagination
                                                                        size="small"
                                                                        count={Math.ceil(agentPagination / agentLimit)}
                                                                        page={currentPage}
                                                                        onChange={(e, v) => {
                                                                            setAgentPage(prev => ({
                                                                                ...prev,
                                                                                [row.dealerId]: v
                                                                            }))
                                                                            fetchDealerAgents(row.dealerId, dateSelected, v, agentLimit);
                                                                        }
                                                                        }
                                                                        shape="rounded"
                                                                        sx={{
                                                                            '& .MuiPaginationItem-root': {
                                                                                borderRadius: 3
                                                                            }
                                                                        }}
                                                                    />
                                                                </Box>}
                                                            </TableCell>
                                                        </TableRow>
                                                    );
                                                })()}
                                            </React.Fragment>
                                        ))
                                    ) : (!dealerListData || !dealerListData?.length) && !loading && (
                                        <TableRow>
                                            <TableCell colSpan={12} align="center" sx={{ py: 3, borderBottom: dealerPagination == 0 ? "none" : "" }}>
                                                No Data found
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>

                        {/* ===================== PAGINATION ===================== */}
                        {!!dealerPagination && <Box className="table-body-bg border-radius-bottom-8" display="flex" justifyContent="space-between" alignItems="end" p={1.5} px={2.5}>
                            <Pagination
                                className="bg-white"
                                size="medium"
                                count={Math.ceil(dealerPagination / limit)}
                                page={page} onChange={(e, v) => setPage(v)}
                                shape="rounded"
                                sx={{
                                    float: 'right',
                                    ml: "auto",
                                    '& .MuiPaginationItem-root': {
                                        borderRadius: 3,
                                    },
                                }}
                            />
                        </Box>}
                    </Box>
                </Box>
            </Paper>
        </>
    );
};

export default PerformanceDashboard;