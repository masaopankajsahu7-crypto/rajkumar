import { Paper, Typography, Box, Grid, FormControl, InputLabel, Select, MenuItem, Checkbox, Button, TextField, Stack } from '@mui/material';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, LineElement, PointElement, CategoryScale, LinearScale, BarElement, LineController, BarController, PieController, ScatterController, DoughnutController } from 'chart.js';
import { useCallback, useEffect, useRef, useState } from 'react';
import { fetchRenewalDashboard, fetchRenewalFilterData } from '../services/api';
import { useDispatch, useSelector } from 'react-redux';
import { setRenewalDisposition, setRenewalLeadsAssigned, setDailyWeeklyTrends, setDealerListData, setSegmentDataList, setTeamMembersData } from '../redux/slices/dashboardSlice';
import RenewalDisposition from '../components/RenewalDisposition';
import LeadsAssignedBar from '../components/LeadsAssignedBar';
import dispositionsvg from "../assets/images/managerdashboard/disposition.svg";
import TrendsChart from '../components/TrendsChart';
import useMediaQuery from '@mui/material/useMediaQuery';
import FilterDialog from '../modals/FilterDialog';
import { Card, TableContainer, Table, TableHead, TableRow, TableCell, TableBody } from '@mui/material';
import dealerImg from '../assets/images/dashboard/dealer.svg';
import branchImg from '../assets/images/dashboard/branch.svg';
import userImg from '../assets/images/dashboard/users.svg';
import agentImg from '../assets/images/dashboard/agents.svg';
import FunnelChart from '../components/FunnelChartComponent';
import myleadssvg from "../assets/images/managerdashboard/myleads.svg";
import performancesvg from "../assets/images/managerdashboard/leadconversion.svg";
import InactiveLeadssvg from "../assets/images/dashboard/InactiveLeads.svg";
import { fetchAdminDashboard, filterAdminDashboard } from '../services/api';
import { setAdminLeadConversion, setAdminLeadStatus, setBranchList, setConversionTrends, setDealerList, setDispositionSummary, setInactiveLeadsList, setLeadSummary, setSegmentList, setStateList, setSubDispositionSummary, setZoneList } from '../redux/slices/dashboardSlice';
import { btnRed } from '../utils/Colors';
import CustomDateRange from '../components/DateRange/CustomDateRange';
import dateFilter from "../assets/images/dashboard/dateFilter.svg";
import AdminPerformance from '../components/AdminPerformance';
import BackdropLoader from "../components/Loader/BackdropLoader";

// ChartJS Registration
ChartJS.register(
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    CategoryScale,
    LinearScale,
    BarElement, LineController, BarController, PieController, ScatterController, DoughnutController
);

const RenewalDashboard = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [report, setReports] = useState('Daily');
    const [filterModalOpen, setFilterModalOpen] = useState(false);
    const fetchUserByManager = useSelector((state) => state.user.fetchUserByManager);

    const dispatch = useDispatch();
    const userDetails = useSelector((state) => state.user.loggedData);
    // const userDetails = { ...useSelector((state) => state.user.loggedData), dealerCode: "1" };
    const dispositionSummary = useSelector((state) => state.dashboard.renewaldispositionSummary);
    const renewalLeadsAssigned = useSelector((state) => state.dashboard.renewalLeadsAssigned);
    const renewalDailyWeeklyTrends = useSelector((state) => state.dashboard.renewalDailyWeeklyTrends);

    const [selectedSegments, setSelectedSegments] = useState([]);
    const [selectedZones, setselectedZones] = useState([]);
    const [selectedStates, setselectedStates] = useState([]);
    const [selectedDealers, setselectedDealers] = useState([]);
    const [selectedBranches, setselectedBranches] = useState([]);
    const [open, setOpen] = useState(false);
    const anchorRef = useRef(null);
    const [dateSelected, setDateSelected] = useState();
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);
    const [stateSelectionOpen, setStateSelectionOpen] = useState(false);
    const [zoneSelectOpen, setZoneSelectOpen] = useState(false);
    const [dealerSelectOpen, setDealerSelectOpen] = useState(false);
    const [branchSelectOpen, setBranchSelectOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [clearType, setClearType] = useState(null);

    const adminLeadStatusData = useSelector((state) => state.dashboard?.adminLeadStatus);
    const adminLeadConversion = useSelector((state) => state.dashboard.adminLeadConversion);
    const teamMembersData = useSelector((state) => state.dashboard.teamMembersData);
    // const segmentData = useSelector((state) => state.dashboard.segmentData);
    const zoneList = useSelector((state) => state.dashboard.zoneList);
    const stateList = useSelector((state) => state.dashboard.stateList);
    const dealerList = useSelector((state) => state.dashboard.dealerList);
    const branchList = useSelector((state) => state.dashboard.branchList);
    const segmentData = useSelector((state) => state.dashboard.segment);
    const InactiveLeads = useSelector((state) => state.dashboard.InactiveLeads);
    const conversionTrendsData = useSelector((state) => state.dashboard?.conversionTrendsData);
    const [selectedTeamMembers, setSelectedTeamMembers] = useState([]);
    const [TeamSelectOpen, setTeamSelectOpen] = useState(false);
    const [dealerSearchText, setDealerSearchText] = useState("");

    // useEffect(() => {
    //     if (selectedDealers.length > 0) {
    //         const payload = {
    //             type: "filterfetchDashboard",
    //             parentCodes: selectedDealers
    //         };
    //         fetchDealerRelatedData(payload);
    //     }
    // }, [selectedDealers]);

    // const fetchDealerRelatedData = async (payload) => {
    //     try {
    //         const response = await fetchRenewalFilterData(payload);
    //         if (response.statusCode === "200" || response.statusMessage === "Data fetched successfully") {
    //         }
    //     } catch (error) {
    //         console.error("Error fetching filter data:", error);
    //     }
    // };

    useEffect(() => {
        if (clearType) {
            filterDashboard();
            setClearType(null);
        }
    }, [selectedZones, selectedStates, selectedDealers, selectedBranches, selectedSegments, selectedTeamMembers, clearType]);


    // const handleClearFiltersTeamMem = (type) => {
    //     if (type === "segment") {
    //         setSelectedSegments([]);
    //         filterDashboard([], selectedTeamMembers);
    //     } else if (type === "teammembers") {
    //         setSelectedTeamMembers([]);
    //         filterDashboard(selectedSegments, []);
    //     }
    // };

    const handleClearFilters = (type) => {
        const resetters = {
            zone: setselectedZones,
            state: setselectedStates,
            dealer: setselectedDealers,
            branch: setselectedBranches,
            segment: setSelectedSegments,
            teammembers: setSelectedTeamMembers
        };

        if (resetters[type]) {
            resetters[type]([]);
            setClearType(type);
        }
    };

    const handleTeamMembersChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedTeamMembers.length === teamMembersData.length) {
                setSelectedTeamMembers([]);
            } else {
                setSelectedTeamMembers(teamMembersData.map(team => team.teamMemberId));
            }
        } else {
            setSelectedTeamMembers(value);
        }
    };

    // for zone 
    const handleZoneChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList.map(zone => zone.Zone));
            }
        } else {
            setselectedZones(value);
        }
    };
    const handleZoneToggle = (zone) => {
        if (zone === 'all') {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList.map(zone => zone.Zone));
            }
        } else {
            const currentIndex = selectedZones.indexOf(zone);
            const newSelected = [...selectedZones];

            if (currentIndex === -1) {
                newSelected.push(zone);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedZones(newSelected);
        }
    };

    // for state 
    const handleStateChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList.map(data => data.State));
            }
        } else {
            setselectedStates(value);
        }
    };
    const handleStateToggle = (state) => {
        if (state === 'all') {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList.map(data => data.State));
            }
        } else {
            const currentIndex = selectedStates.indexOf(state);
            const newSelected = [...selectedStates];

            if (currentIndex === -1) {
                newSelected.push(state);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedStates(newSelected);
        }
    };

    const [searchTerm, setSearchTerm] = useState("");

    // Filter dealers based on search input
    const filteredDealers = dealerList?.filter((dealer) =>
        dealer?.dealer_name?.toLowerCase()?.includes(searchTerm?.toLowerCase())
    );

    const handleDealerToggle = (dealerId) => {
        if (dealerId === "all") {
            if (selectedDealers.length === dealerList.length) {
                setselectedDealers([]);
            } else {
                setselectedDealers(dealerList.map((d) => d.dealer_id));
            }
        } else {
            setselectedDealers((prev) =>
                prev.includes(dealerId)
                    ? prev.filter((id) => id !== dealerId)
                    : [...prev, dealerId]
            );
        }
    };

    // for branch 
    const handleBranchChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedBranches.length === branchList.length) {
                setselectedBranches([]);
            } else {
                setselectedBranches(branchList.map(data => data.loc_code));
            }
        } else {
            setselectedBranches(value);
        }
    };
    const handleBranchToggle = (loc_code) => {
        if (loc_code === 'all') {
            if (selectedBranches.length === branchList.length) {
                setselectedBranches([]);
            } else {
                setselectedBranches(branchList.map(data => data.loc_code));
            }
        } else {
            const currentIndex = selectedBranches.indexOf(loc_code);
            const newSelected = [...selectedBranches];

            if (currentIndex === -1) {
                newSelected.push(loc_code);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedBranches(newSelected);
        }
    };

    // for Segment 
    const handleSegmentChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData.map(seg => seg.Segment));
            }
        } else {
            setSelectedSegments(value);
        }
    };
    const handleSegmentToggle = (segment) => {
        if (segment === 'all') {
            if (selectedSegments.length === segmentData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(segmentData.map(seg => seg.Segment));
            }
        } else {
            const currentIndex = selectedSegments.indexOf(segment);
            const newSelected = [...selectedSegments];

            if (currentIndex === -1) {
                newSelected.push(segment);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedSegments(newSelected);
        }
    };

    const handleApplyFilters = useCallback(async (filters) => {
        const payload = {
            ...filters,
            type: "fetchRenewalDashboard",
        };
        try {
            const response = await fetchRenewalDashboard(payload);
            if (response?.statusCode === "200" || response?.statusMessage === "Fetched Renewal Dashboard Details") {
                const { result0, result1, result2 } = response.data;
                dispatch(setRenewalDisposition(result0));
                dispatch(setRenewalLeadsAssigned(result1));
                dispatch(setDailyWeeklyTrends(result2));
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (error) {
            console.error("Error applying filters:", error);
        }
    }, []);

    const fetchData = async () => {
        let payload;

        if (userDetails?.roleType === "MIBL") {
            payload = {
                type: userDetails?.roleType
            }
        }
        if (userDetails?.roleType === "DEALER") {
            payload = {
                type: userDetails?.roleType,
                parentCodes: userDetails?.parentCode,
                userId: userDetails?.user_id,
                dealerId: userDetails?.dealerCode
            }
        }

        try {
            setLoading(true);
            const response = await fetchRenewalFilterData(payload);
            if (response.statusCode === "200" && userDetails?.roleType === "MIBL") {
                dispatch(setSegmentDataList(response.data.result0));
                dispatch(setZoneList(response.data.result1));
                dispatch(setStateList(response.data.result2));
                dispatch(setDealerList(response.data.result3));
            }
            if (response.statusCode === "200" && userDetails?.roleType === "DEALER") {
                dispatch(setSegmentDataList(response.data.result0));
                dispatch(setTeamMembersData(response.data.result1));
            }
        } catch (error) {
            console.error("Error fetching filter data:", error);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        fetchData();
    }, []);

    useEffect(() => {
        if (dateSelected && dateSelected !== "") {
            filterDashboard();
        }
    }, [dateSelected]);

    const filterDashboard = async (date = dateSelected) => {
        if (!userDetails?.user_id) return;

        try {
            const startDate = !date || date === "" || date?.startDate === "Invalid Date" ? "" : date.startDate;
            const endDate = !date || date === "" || date?.endDate === "Invalid Date" ? "" : date.endDate;

            const payload2 = {
                userId: userDetails.user_id,
                roleId: userDetails.roleId,
                roleType: userDetails.roleType,
                zone: selectedZones.join(","),
                segment: selectedSegments.join(","),
                startDate,
                endDate,
                dealerLocCode: selectedBranches.join(","),
                state: selectedStates.join(","),
                dealerId: userDetails.roleType === "DEALER" ? userDetails?.dealerCode : selectedDealers.join(","),
                type: "filterfetchDashboard",
                teamMemberId: selectedTeamMembers.join(",")

                // "dealerName": selectedDealers.join(","),
                // dealerCode: selectedDealers
            }

            setLoading(true);
            const response = await fetchRenewalDashboard(payload2);

            if (response?.statusCode === "200" || response?.statusMessage === "Fetched Filter Dashboard Details.") {
                const { result0, result1, result2 } = response.data;
                dispatch(setRenewalDisposition(result0));
                dispatch(setRenewalLeadsAssigned(result1));
                dispatch(setDailyWeeklyTrends(result2));
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    }

    const fetchDashboardData = async () => {
        if (!userDetails?.user_id) return;

        try {
            const payload = {
                "type": "fetchDashboard",
                "roleId": userDetails.roleId,
                "userId": userDetails.user_id,
                "dealerId": userDetails.dealerCode,
                "roleType": userDetails.roleType
            }

            const response = await fetchRenewalDashboard(payload);

            if (response?.statusCode === "200" || response?.statusMessage === "Fetched Renewal Dashboard Details") {
                const { result0, result1, result2 } = response.data;
                dispatch(setRenewalDisposition(result0));
                dispatch(setRenewalLeadsAssigned(result1));
                dispatch(setDailyWeeklyTrends(result2));
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        }
    };

    const handleChangeReports = (event) => {
        setReports(event.target.value);
    };

    useEffect(() => {
        fetchDashboardData();
    }, [dispatch]);




    return (
        <Paper className="body-formbg table-auto-width" elevation={0} sx={{ px: isMobile ? 0.5 : 1, boxShadow: 'none' }}>
            <BackdropLoader loading={loading} />
            <Box  px={1} pt={isMobile ? 1.3 : 0.5} display={"flex"} flexWrap={"wrap"} alignItems="center" textAlign={"center"} justifyContent={"space-between"}>
                <Box display={'flex'} alignItems="center" textAlign={"center"} justifyContent={"start"}>
                    <img src={myleadssvg} alt="" />
                    <Typography px={1} className="georama-SemiBold fs-16">Renewal Dashboard</Typography>
                </Box>
                <Box display="flex" gap={1} pt={1} pr={1} flexWrap={"wrap"} justifyContent={isMobile ? "start" : "end"}>

                    {userDetails?.roleType === "MIBL" &&
                        <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel id="zone-label" className="dropdown-label">Zone</InputLabel>

                            <Select
                                className='georama-Medium'
                                labelId="zone-label"
                                id="zone-select"
                                multiple
                                value={selectedZones}
                                label="Zone"
                                onChange={handleZoneChange}
                                open={zoneSelectOpen}
                                onClose={() => setZoneSelectOpen(false)}
                                onOpen={() => setZoneSelectOpen(true)}
                                renderValue={(selected) => {
                                    if (selected.length === zoneList?.length) return "All";
                                    return zoneList
                                        .filter(zone => selected.includes(zone.Zone))
                                        .map(zone => zone.Zone)
                                        .join(',');
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            // maxHeight: 300,
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                            >
                                <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                    onClick={() => handleZoneToggle('all')}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedZones.length === zoneList?.length}
                                        indeterminate={
                                            selectedZones.length > 0 &&
                                            selectedZones.length < zoneList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {zoneList && zoneList.map((zone, index) => (
                                        <MenuItem
                                            className={selectedZones.includes(zone.Zone) ? 'georama- fs-14' : ''}
                                            disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                            key={index}
                                            value={zone.Zone}
                                            onClick={() => handleZoneToggle(zone.Zone)}
                                        >
                                            <Checkbox
                                                sx={{
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedZones.includes(zone.Zone)}
                                            />

                                            {zone.Zone}
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        // disabled={selectedZones.length === 0}
                                        size="small"
                                        onClick={() => {
                                            if (selectedZones.length > 0) {
                                                handleClearFilters("zone");
                                                setZoneSelectOpen(false);
                                            }
                                        }}
                                        sx={{
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            mx: 1,
                                            color: "black",
                                            backgroundColor: 'transparent',
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        // disabled={selectedZones.length === 0}
                                        variant="contained"
                                        className='btn-common-red'
                                        size="small"
                                        sx={{ mx: 2, my: 1, ...btnRed }}
                                        onClick={() => {
                                            if (selectedZones.length > 0) {
                                                filterDashboard("");
                                                setZoneSelectOpen(false);
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>
                    }

                    {userDetails?.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                        <InputLabel id="state-label" className="dropdown-label">State</InputLabel>

                        <Select
                            className='georama-Medium'
                            labelId="state-label"
                            id="state-select"
                            multiple
                            value={selectedStates}
                            label="State"
                            onChange={handleStateChange}
                            open={stateSelectionOpen}
                            onClose={() => setStateSelectionOpen(false)}
                            onOpen={() => setStateSelectionOpen(true)}
                            renderValue={(selected) => {
                                if (selected.length === stateList?.length) return "All";
                                return stateList
                                    .filter(data => selected.includes(data.State))
                                    .map(data => data.State)
                                    .join(',');
                            }}
                            MenuProps={{
                                disableScrollLock: true,
                                PaperProps: {
                                    style: {
                                        // maxHeight: 300,
                                        position: 'fixed',
                                        zIndex: 1500,
                                        scrollbarWidth: 'thin',
                                        scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                    },
                                    sx: {
                                        '&::-webkit-scrollbar': {
                                            width: '4px',
                                        },
                                        '&::-webkit-scrollbar-track': {
                                            backgroundColor: '#f1f1f1',
                                            borderRadius: '4px',
                                        },
                                        '&::-webkit-scrollbar-thumb': {
                                            backgroundColor: '#d0cac9ff',
                                            borderRadius: '4px',
                                        },
                                        '&::-webkit-scrollbar-thumb:hover': {
                                            backgroundColor: '#d32f2f',
                                        },
                                    }
                                },
                                getContentAnchorEl: null,
                            }}
                        >
                            <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                onClick={() => handleStateToggle('all')}
                            >
                                <Checkbox
                                    sx={{
                                        '&.Mui-checked': { color: '#e53935' },
                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                    }}
                                    checked={selectedStates.length === stateList?.length}
                                    indeterminate={
                                        selectedStates.length > 0 &&
                                        selectedStates.length < stateList.length
                                    }
                                />
                                All
                            </MenuItem>

                            <Box
                                sx={{
                                    maxHeight: 150,
                                    overflowY: 'auto',
                                    pr: 1,
                                }}
                            >
                                {stateList && stateList.map((data, index) => (
                                    <MenuItem
                                        className={selectedStates.includes(data.State) ? 'georama- fs-14' : ''}
                                        disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                        key={index}
                                        value={data.State}
                                        onClick={() => handleStateToggle(data.State)}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedStates.includes(data.State)}
                                        />

                                        {data.State}
                                    </MenuItem>
                                ))}
                            </Box>

                            <Box display={"flex"} justifyContent={"end"}>
                                <Button
                                    // disabled={selectedStates.length === 0}
                                    size="small"
                                    fullWidth
                                    onClick={() => {
                                        if (selectedStates.length > 0) {
                                            handleClearFilters("state");
                                            setStateSelectionOpen(false);
                                        }
                                    }}
                                    sx={{
                                        border: "1px solid gray",
                                        borderRadius: 8,
                                        boxShadow: 'none',
                                        px: 2,
                                        my: 1,
                                        mx: 1,
                                        color: "black",
                                        backgroundColor: 'transparent',
                                    }}
                                >
                                    Clear
                                </Button>

                                <Button
                                    className='btn-common-red'
                                    fullWidth
                                    // disabled={selectedStates.length === 0}
                                    size="small"
                                    sx={{ mx: 1, my: 1 }}
                                    onClick={() => {
                                        if (selectedStates.length > 0) {
                                            filterDashboard("");
                                            setStateSelectionOpen(false);
                                        }
                                    }}
                                >
                                    Apply
                                </Button>
                            </Box>
                        </Select>
                    </FormControl>}

                    {userDetails?.roleType === "MIBL" && (
                        <FormControl
                            size="small"
                            sx={{
                                minWidth: 120,
                                maxWidth: 120,
                                backgroundColor: "#fff",
                                borderRadius: 2,
                            }}
                        >
                            <InputLabel id="dealer-label" className="dropdown-label">
                                Dealer
                            </InputLabel>

                            <Select
                                labelId="dealer-label"
                                id="dealer-select"
                                multiple
                                open={dealerSelectOpen}
                                onClose={() => setDealerSelectOpen(false)}
                                onOpen={() => setDealerSelectOpen(true)}
                                value={selectedDealers}
                                label="Dealer"
                                renderValue={(selected) => {
                                    if (selected.length === dealerList?.length) return "All";
                                    return dealerList
                                        .filter((d) => selected.includes(d.dealer_id))
                                        .map((d) => d.dealer_name)
                                        .join(", ");
                                }}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            position: "fixed",
                                            zIndex: 1500,
                                            scrollbarWidth: "thin",
                                        },
                                    },
                                }}
                            >
                                {/* 🔍 Search Input (does not trigger auto-select) */}
                                <Box sx={{ p: 1 }}>
                                    <TextField
                                        size="small"
                                        placeholder="Search dealer..."
                                        fullWidth
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        // 🛑 IMPORTANT: Stop propagation for both click (to prevent closing)
                                        // AND keydown (to prevent keyboard search/selection interference).
                                        onClick={(e) => e.stopPropagation()}
                                        onKeyDown={(e) => e.stopPropagation()}
                                    />
                                </Box>

                                {/* “All” checkbox stays always visible */}
                                <MenuItem disableGutters sx={{ py: 0, px: 1 }} value="all" onClick={() => handleDealerToggle("all")}>
                                    <Checkbox
                                        sx={{
                                            "&.Mui-checked": { color: "#e53935" },
                                            "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                        }}
                                        checked={selectedDealers.length === dealerList?.length}
                                        indeterminate={
                                            selectedDealers.length > 0 &&
                                            selectedDealers.length < dealerList.length
                                        }
                                    />
                                    All
                                </MenuItem>

                                {/* Filtered dealer options */}
                                <Box sx={{ maxHeight: 150, overflowY: "auto", pr: 1 }}>
                                    {filteredDealers?.length > 0 ? (
                                        filteredDealers.map((data) => (
                                            <MenuItem
                                                key={data.dealer_id}
                                                disableGutters
                                                sx={{ py: 0, px: 1 }}
                                                value={data.dealer_id}
                                                onClick={() => handleDealerToggle(data.dealer_id)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        "&.Mui-checked": { color: "#e53935" },
                                                        "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                    }}
                                                    checked={selectedDealers.includes(data.dealer_id)}
                                                />
                                                {data.dealer_name}
                                            </MenuItem>
                                        ))
                                    ) : (
                                        <MenuItem disabled>No dealers found</MenuItem>
                                    )}
                                </Box>

                                {/* Clear and Apply Buttons */}
                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        size="small"
                                        onClick={() => {
                                            handleClearFilters("dealer");
                                            setDealerSelectOpen(false);
                                            setSearchTerm("");
                                        }}
                                        sx={{
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            px: 1,
                                            my: 1,
                                            mx: 1,
                                            color: "black",
                                            backgroundColor: "transparent",
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        className="btn-common-red"
                                        size="small"
                                        sx={{
                                            mx: 2,
                                            my: 1,
                                            backgroundColor: "#e53935",
                                            color: "#fff",
                                            borderRadius: 8,
                                            "&:hover": { backgroundColor: "#c62828" },
                                        }}
                                        onClick={() => {
                                            filterDashboard("");
                                            setDealerSelectOpen(false);
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>
                    )}

                    {/* {selectedDealers && selectedDealers?.length > 0 && branchList?.length > 0 && <FormControl className='' size="small" sx={{ minWidth: 110, maxWidth: 110, backgroundColor: '#ffffff', borderRadius: 2 }}>
                    <InputLabel id="branch-label" className="dropdown-label">Branch</InputLabel>
                    <Select
                        className='georama-Medium'
                        labelId="branch-label"
                        id="branch-select"
                        multiple
                        value={selectedBranches}
                        label="Branch"
                        onChange={handleBranchChange}
                        open={branchSelectOpen}
                        onClose={() => setBranchSelectOpen(false)}
                        onOpen={() => setBranchSelectOpen(true)}
                        renderValue={(selected) => {
                            if (selected.length === branchList?.length) return "All";
                            return branchList
                                .filter(data => selected.includes(data.loc_code))
                                .map(data => data.loc_name)
                                .join(',');
                        }}
                        MenuProps={{
                            disableScrollLock: true,
                            PaperProps: {
                                style: {
                                    // maxHeight: 300,
                                    position: 'fixed',
                                    zIndex: 1500,
                                    scrollbarWidth: 'thin',
                                    scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                },
                                sx: {
                                    '&::-webkit-scrollbar': {
                                        width: '4px',
                                    },
                                    '&::-webkit-scrollbar-track': {
                                        backgroundColor: '#f1f1f1',
                                        borderRadius: '4px',
                                    },
                                    '&::-webkit-scrollbar-thumb': {
                                        backgroundColor: '#d0cac9ff',
                                        borderRadius: '4px',
                                    },
                                    '&::-webkit-scrollbar-thumb:hover': {
                                        backgroundColor: '#d32f2f',
                                    },
                                }
                            },
                            getContentAnchorEl: null,
                        }}
                    >
                        <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                            onClick={() => handleBranchToggle('all')}
                        >
                            <Checkbox
                                sx={{
                                    '&.Mui-checked': { color: '#e53935' },
                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                }}
                                checked={selectedBranches.length === branchList?.length}
                                indeterminate={
                                    selectedBranches.length > 0 &&
                                    selectedBranches.length < branchList.length
                                }
                            />
                            All
                        </MenuItem>

                        <Box
                            sx={{
                                maxHeight: 150,
                                overflowY: 'auto',
                                pr: 1,
                            }}
                        >
                            {branchList && branchList.map((data, index) => (
                                <MenuItem
                                    className={selectedBranches.includes(data.loc_name) ? 'georama- fs-14' : ''}
                                    disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                    key={index}
                                    value={data.loc_code}
                                    onClick={() => handleBranchToggle(data.loc_code)}
                                >
                                    <Checkbox
                                        sx={{
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedBranches.includes(data.loc_code)}
                                    />

                                    {data.loc_name}
                                </MenuItem>
                            ))}
                        </Box>

                        <Box display={"flex"} justifyContent={"end"}>
                            <Button
                                // disabled={selectedBranches.length === 0}
                                variant="contained"
                                size="small"
                                onClick={() => {
                                    if (selectedBranches.length > 0) {
                                        handleClearFilters("branch");
                                        setBranchSelectOpen(false);
                                    }
                                }}
                                sx={{
                                    border: "1px solid gray",
                                    borderRadius: 8,
                                    boxShadow: 'none',
                                    px: 1,
                                    my: 1,
                                    mx: 1,
                                    color: "black",
                                    backgroundColor: 'transparent',
                                }}
                            >
                                Clear
                            </Button>

                            <Button
                                className='btn-common-red'
                                // disabled={selectedBranches.length === 0}
                                size="small"
                                sx={{ mx: 2, my: 1, ...btnRed }}
                                onClick={() => {
                                    if (selectedBranches.length > 0) {
                                        filterDashboard("");
                                        setBranchSelectOpen(false);
                                    }
                                }}
                            >
                                Apply
                            </Button>
                        </Box>
                    </Select>
                </FormControl>} */}

                    <FormControl className='' size="small" sx={{ minWidth: 110, maxWidth: 110, backgroundColor: '#ffffff', borderRadius: 2 }}>
                        <InputLabel id="segment-label" className="dropdown-label">Segment</InputLabel>

                        <Select
                            className='georama-Medium'
                            labelId="segment-label"
                            id="segment-select"
                            multiple
                            value={selectedSegments}
                            label="Segment"
                            onChange={handleSegmentChange}
                            open={segmentSelectOpen}
                            onClose={() => setSegmentSelectOpen(false)}
                            onOpen={() => setSegmentSelectOpen(true)}
                            renderValue={(selected) => {
                                if (selected.length === segmentData?.length) return "All";
                                return segmentData
                                    .filter(seg => selected.includes(seg.Segment))
                                    .map(seg => seg.Segment)
                                    .join(',');
                            }}
                            MenuProps={{
                                disableScrollLock: true,
                                PaperProps: {
                                    style: {
                                        // maxHeight: 300,
                                        position: 'fixed',
                                        zIndex: 1500,
                                        scrollbarWidth: 'thin',
                                        scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                    },
                                    sx: {
                                        '&::-webkit-scrollbar': {
                                            width: '4px',
                                        },
                                        '&::-webkit-scrollbar-track': {
                                            backgroundColor: '#f1f1f1',
                                            borderRadius: '4px',
                                        },
                                        '&::-webkit-scrollbar-thumb': {
                                            backgroundColor: '#d0cac9ff',
                                            borderRadius: '4px',
                                        },
                                        '&::-webkit-scrollbar-thumb:hover': {
                                            backgroundColor: '#d32f2f',
                                        },
                                    }
                                },
                                getContentAnchorEl: null,
                            }}
                        >
                            <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                onClick={() => handleSegmentToggle('all')}
                            >
                                <Checkbox
                                    sx={{
                                        '&.Mui-checked': { color: '#e53935' },
                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                    }}
                                    checked={selectedSegments.length === segmentData?.length}
                                    indeterminate={
                                        selectedSegments.length > 0 &&
                                        selectedSegments.length < segmentData.length
                                    }
                                />
                                All
                            </MenuItem>

                            <Box
                                sx={{
                                    maxHeight: 150,
                                    overflowY: 'auto',
                                    pr: 1,
                                }}
                            >
                                {segmentData && segmentData?.map((seg, index) => (
                                    <MenuItem
                                        className={selectedSegments.includes(seg.Segment) ? 'georama- fs-14' : ''}
                                        disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                        key={index}
                                        value={seg.Segment}
                                        onClick={() => handleSegmentToggle(seg.Segment)}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedSegments.includes(seg.Segment)}
                                        />

                                        {seg.Segment}
                                    </MenuItem>
                                ))}
                            </Box>

                            <Box display={"flex"} justifyContent={"end"}>
                                <Button
                                    // disabled={selectedSegments.length === 0}
                                    fullWidth
                                    variant="contained"
                                    size="small"
                                    onClick={() => {
                                        if (selectedSegments.length > 0) {
                                            handleClearFilters("segment");
                                            setSegmentSelectOpen(false);
                                        }
                                    }}
                                    sx={{
                                        border: "1px solid gray",
                                        borderRadius: 8,
                                        boxShadow: 'none',
                                        px: 1,
                                        my: 1,
                                        mx: 1,
                                        color: "black",
                                        backgroundColor: 'transparent',
                                    }}
                                >
                                    Clear
                                </Button>

                                <Button
                                    // disabled={selectedSegments.length === 0}
                                    className='btn-common-red'
                                    size="small"
                                    sx={{ mx: 2, my: 1, ...btnRed }}
                                    onClick={() => {
                                        if (selectedSegments.length > 0) {
                                            filterDashboard("");
                                            setSegmentSelectOpen(false);
                                        }
                                    }}
                                >
                                    Apply
                                </Button>
                            </Box>
                        </Select>
                    </FormControl>

                    {!!fetchUserByManager?.length && teamMembersData?.length > 0 &&
                        <FormControl size="small" sx={{ minWidth: isMobile ? 130 : 140, maxWidth: isMobile ? 130 : 150, backgroundColor: '#ffffff', borderRadius: 2 }}>
                            <InputLabel className="dropdown-label">Team Member</InputLabel>
                            <Select
                                multiple
                                value={selectedTeamMembers}
                                label="Team Member"
                                onChange={handleTeamMembersChange}
                                open={TeamSelectOpen}
                                onClose={() => setTeamSelectOpen(false)}
                                onOpen={() => setTeamSelectOpen(true)}
                                MenuProps={{
                                    disableScrollLock: true,
                                    PaperProps: {
                                        style: {
                                            maxHeight: 300,
                                            position: 'fixed',
                                            zIndex: 1500,
                                            scrollbarWidth: 'thin',
                                            scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                        },
                                        sx: {
                                            '&::-webkit-scrollbar': {
                                                width: '4px',
                                            },
                                            '&::-webkit-scrollbar-track': {
                                                backgroundColor: '#f1f1f1',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb': {
                                                backgroundColor: '#d0cac9ff',
                                                borderRadius: '4px',
                                            },
                                            '&::-webkit-scrollbar-thumb:hover': {
                                                backgroundColor: '#d32f2f',
                                            },
                                        }
                                    },
                                    getContentAnchorEl: null,
                                }}
                                renderValue={(selected) => {
                                    if (selected.length === teamMembersData.length) return "All";
                                    return teamMembersData
                                        .filter(seg => selected.includes(seg.teamMemberId))
                                        .map(seg => seg.teamMemberName)
                                        .join(',');
                                }}
                            >
                                <MenuItem sx={{ py: 0, m: 0 }} value="all">
                                    <Checkbox
                                        sx={{
                                            mr: 1,
                                            '&.Mui-checked': { color: '#e53935' },
                                            '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                        }}
                                        checked={selectedTeamMembers.length === teamMembersData?.length}
                                        indeterminate={
                                            selectedTeamMembers.length > 0 &&
                                            selectedTeamMembers.length < teamMembersData.length
                                        }
                                    />
                                    <span className='georama-Regular'>All</span>
                                </MenuItem>

                                <Box
                                    sx={{
                                        maxHeight: 150,
                                        overflowY: 'auto',
                                        pr: 1,
                                    }}
                                >
                                    {teamMembersData && teamMembersData.map((seg, index) => (
                                        <MenuItem
                                            sx={{ py: 0, m: 0 }}
                                            key={index}
                                            value={seg.teamMemberId}
                                            className={selectedSegments.includes(seg.teamMemberName) ? 'georama- fs-14' : ''}
                                            onClick={() => {
                                                const currentIndex = selectedTeamMembers.indexOf(seg.teamMemberId);
                                                let newSelected = [...selectedTeamMembers];

                                                if (currentIndex === -1) {
                                                    newSelected.push(seg.teamMemberId);
                                                } else {
                                                    newSelected.splice(currentIndex, 1);
                                                }
                                                setSelectedTeamMembers(newSelected);
                                            }}
                                        >
                                            <Checkbox
                                                sx={{
                                                    mr: 1,
                                                    '&.Mui-checked': { color: '#e53935' },
                                                    '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                }}
                                                checked={selectedTeamMembers.includes(seg.teamMemberId)}
                                            />

                                            <span className='georama-Regular'>{seg.teamMemberName}</span>
                                        </MenuItem>
                                    ))}
                                </Box>

                                <Box display={"flex"} justifyContent={"end"}>
                                    <Button
                                        disabled={selectedTeamMembers.length === 0}
                                        fullWidth
                                        variant="contained"
                                        size="small"
                                        onClick={() => {
                                            handleClearFilters("teammembers");
                                            setTeamSelectOpen(false);
                                        }}
                                        sx={{
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            mx: 1,
                                            color: "black",
                                            backgroundColor: 'transparent',
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        fullWidth
                                        disabled={selectedTeamMembers.length === 0}
                                        variant="contained"
                                        size="small"
                                        sx={{ mr: 1, my: 1, ...btnRed, borderRadius: 8, }}
                                        onClick={() => {
                                            filterDashboard("");
                                            setTeamSelectOpen();
                                        }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>}

                    <Box>
                        <Button className='bg-white text-gray text-capitalize border-light-gray border-radius-8' ref={anchorRef} onClick={() => setOpen(true)}>
                            <img className='px-1' src={dateFilter} alt="" />

                            <Typography className="dropdown-label" mt={0.5} px={1}>Date Range</Typography>
                        </Button>

                        <CustomDateRange
                            open={open}
                            anchorRef={anchorRef}
                            setOpen={setOpen}
                            setDate={setDateSelected}
                            onChange={() => setDateSelected("")}
                            clearDate={() => {
                                setDateSelected("");
                                setOpen(false);
                                filterDashboard("");
                            }}
                        />
                    </Box>
                </Box>
            </Box>
            <Box px={1}>
                <Grid container rowSpacing={0.3} columnSpacing={1.7}>
                    <Grid size={12} item xs={12} md={12}>
                        <Grid px={2} py={1.3} my={1.5} borderRadius={2} className="bg-white" size={12} item xs={12} md={12}>
                            <RenewalDisposition dispositiondata={dispositionSummary}
                            // onApplyFilters={handleApplyFilters} 
                            />
                        </Grid>
                    </Grid>
                    <Grid size={{ xs: 12, sm: 12, md: 6, lg: 6 }}>
                        <Box className="bg-white" borderRadius={2} p={2}>
                            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                <Box display={'flex'} alignItems="center" justifyContent={"center"} gap={1}>
                                    <img src={dispositionsvg} alt="" />
                                    <Typography className="georama-SemiBold font-size-14">Total Leads Assigned</Typography>
                                </Box>
                            </Box>

                            <LeadsAssignedBar leadsAssigned={renewalLeadsAssigned} />
                        </Box>
                    </Grid>
                    <Grid size={{ xs: 12, sm: 12, md: 6, lg: 6 }}>
                        <Box className="bg-white" borderRadius={2} mb={2} p={2} mt={isMobile ? 1.5 : 0}>
                            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                <Box display="flex" alignItems="center" justifyContent="center" gap={1}>
                                    <img src={dispositionsvg} alt="" />
                                    <Typography className="georama-SemiBold font-size-14">Weekly Trends</Typography>
                                </Box>
                                {/* <Box display="flex" flexWrap="wrap" alignItems="center" justifyContent="center" gap={1}>
                                    <FormControl
                                        className="bg-white"
                                        size="small"
                                        sx={{ minWidth: isMobile ? 100 : 110, maxWidth: isMobile ? 100 : 110, borderRadius: 2 }}
                                    >
                                        <InputLabel id="menu-select-label" className="dropdown-label fs-10">
                                            Select
                                        </InputLabel>
                                        <Select
                                            className="fs-12"
                                            labelId="menu-select-label"
                                            id="menu-select"
                                            value={report}
                                            label="Select Menu"
                                            onChange={handleChangeReports}
                                        >
                                            <MenuItem className="fs-12" selected value="Daily">
                                                Daily
                                            </MenuItem>
                                            <MenuItem className="fs-12" value="Weekly">
                                                Weekly
                                            </MenuItem>
                                        </Select>
                                    </FormControl>
                                </Box> */}
                            </Box>

                            <TrendsChart renewalDailyWeeklyTrends={renewalDailyWeeklyTrends} metricType={report} />
                        </Box>
                    </Grid>
                </Grid>
            </Box>
        </Paper >
    );
};

export default RenewalDashboard;
