import { Box, Button, Checkbox, Divider, FormControl, FormHelperText, Grid, MenuItem, Paper, Select, TextField, Typography, useMediaQuery } from "@mui/material";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { addDays, differenceInDays, format, isAfter, isBefore, isValid, subDays, subYears } from 'date-fns';
import { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { ToastContainer, toast } from 'react-toastify';
import BackdropLoader from "../components/Loader/BackdropLoader";
import { downloadReports, reportsOnLoad } from "../services/api";


const Reports = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [formErrors, setFormErrors] = useState({});
    const [formValues, setFormValues] = useState({ report: "", dealer: "" });

    const [fromDate, setFromDate] = useState(null);
    const [toDate, setToDate] = useState(null);

    const [reportData, setReportData] = useState([]);
    const [dealerData, setDealersData] = useState([]);
    const [selectedDealerData, setSelectedDealers] = useState([]);
    const [subReportSelectOpen, setDealerSelectOpen] = useState(false);
    const userDetails = useSelector((state) => state.user.loggedData);
    const [loading, setLoading] = useState(false);
    const [dealerSelectOpen, setDealersSelectOpen] = useState(false);
    const [dealerSearch, setDealerSearch] = useState("");

    // const minAllowedDate = new Date("2024-01-01");

    // --- Date Constraints ---
    // const minAllowedDate = useMemo(() => subYears(new Date(), 5), []);
    // const today = new Date();

    // const maxDateForFrom = useMemo(() => {
    //     if (toDate) return subDays(toDate, 30);
    //     return today;
    // }, [toDate]);

    // const maxDateForTo = useMemo(() => {
    //     if (fromDate) return addDays(fromDate, 30);
    //     return today;
    // }, [fromDate]);


    const minAllowedDate = useMemo(() => subYears(new Date(), 5), []);
    const today = new Date();

    const maxDateForFrom = useMemo(() => {
        if (toDate) return subDays(toDate, 30);
        return today;
    }, [toDate]);

    const maxDateForTo = useMemo(() => {
        if (fromDate) return addDays(fromDate, 30);
        return today;
    }, [fromDate]);

    // ✅ Keep handlers simple — just update state
    const handleFromDateChange = (newValue) => {
        setFromDate(newValue instanceof Date ? newValue : new Date(newValue));
    };

    const handleToDateChange = (newValue) => {
        setToDate(newValue instanceof Date ? newValue : new Date(newValue));
    };

    // ✅ Centralized validation (reactive + consistent)
    useEffect(() => {
        if (!fromDate || !toDate) return;

        if (isAfter(fromDate, toDate)) {
            toast.error("From Date cannot be later than To Date.");
            return;
        }

        const minDate = subYears(new Date(), 5);
        const diffDays = differenceInDays(toDate, fromDate);

        if (isBefore(fromDate, minDate)) {
            toast.error("From Date cannot be older than 5 years.");
            return;
        }

        if (isAfter(toDate, today)) {
            toast.error("To Date cannot be in the future.");
            return;
        }

        if (diffDays > 30) {
            toast.error("Date range cannot exceed 30 days.");
            return;
        }
    }, [fromDate, toDate]);


    const handleDealerChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedDealerData.length === dealerData.length) {
                setSelectedDealers([]);
            } else {
                setSelectedDealers(dealerData?.map(data => data.dealer_code));
            }
        } else {
            setSelectedDealers(value);
        }
    };
    const handleDealerToggle = (dealer) => {
        if (dealer === 'all') {
            if (selectedDealerData.length === dealerData.length) {
                setSelectedDealers([]);
            } else {
                setSelectedDealers(dealerData?.map(data => data.dealer_code));
            }
        } else {
            const currentIndex = selectedDealerData.indexOf(dealer);
            const newSelected = [...selectedDealerData];

            if (currentIndex === -1) {
                newSelected.push(dealer);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedDealers(newSelected);
        }
    };

    const fetchReportData = async () => {
        let payload;
        payload = {
            type: "onloadReportType",
            roleId: userDetails.roleId,
            userId: userDetails.user_id,
            roleType: userDetails.roleType
        }
        try {
            const response = await reportsOnLoad(payload);
            if (response.data.SP_STATUS === "200" || response.data.MESSAGE === "Fetched Report types successfully") {
                setDealersData(response.data.result1);
                setReportData(response.data.result0);
            }
        } catch (err) {
            console.log(err);
        }
    }

    useEffect(() => {
        fetchReportData();
    }, []);



    const downloadReportData = async () => {
        if (!fromDate || !toDate) {
            toast.error("Please select both From Date and To Date.");
            return;
        }

        const formatDate = (date) => (isValid(date) ? format(date, "yyyy-MM-dd") : "");

        const date1 = new Date(fromDate);
        const date2 = new Date(toDate);

        const minAllowedDate = subYears(new Date(), 5);
        const today = new Date();

        // ---- VALIDATION ----
        if (!isValid(date1) || !isValid(date2)) {
            toast.error("Please select valid From and To dates.");
            return;
        }

        if (isAfter(date1, date2)) {
            toast.error("From Date cannot be later than To Date.");
            return;
        }

        if (isBefore(date1, minAllowedDate)) {
            toast.error("From Date cannot be older than 5 years.");
            return;
        }

        if (isAfter(date2, today)) {
            toast.error("To Date cannot be in the future.");
            return;
        }

        const diffDays = differenceInDays(date2, date1);
        if (diffDays > 30) {
            toast.error("Date range cannot exceed 30 days.");
            return;
        }

        let payload;
        setLoading(true);

        if (userDetails.roleType === 'MIBL') {
            payload = {
                report_Id: formValues.report,
                dealerCode: selectedDealerData.join(","),
                roleType: userDetails.roleType,
                roleId: userDetails.roleId,
                userId: userDetails.user_id,
                startDate: formatDate(date1),
                endDate: formatDate(date2)
            };
        } else {
            payload = {
                report_Id: formValues.report,
                roleType: userDetails.roleType,
                dealerCode: userDetails?.dealerCode ?? '',
                roleId: userDetails.roleId,
                userId: userDetails.user_id,
                startDate: formatDate(date1),
                endDate: formatDate(date2)
            };
        }

        try {
            const response = await downloadReports(payload);
            // if (response && response.data) {
            //     // Create a download link
            //     const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            //     const url = window.URL.createObjectURL(blob);
            //     const link = document.createElement('a');
            //     link.href = url;
            //     link.setAttribute('download', 'Reports_Data.xlsx');
            //     document.body.appendChild(link);
            //     link.click();
            //     link.remove();
            //     window.URL.revokeObjectURL(url);
            // } for excel file

            if (response && response.data) {
                // Try to get the file name from the headers
                let filename = 'Reports_Data';
                const contentDisposition = response.headers['content-disposition'];
                if (contentDisposition) {
                    const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
                    if (filenameMatch?.[1]) {
                        filename = filenameMatch[1].replace(/['"]/g, '');
                    }
                }

                // Determine file type from the content-type header
                let fileExtension = '.xlsx'; // default
                let mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

                const contentType = response.headers['content-type'];
                if (contentType === 'application/zip') {
                    fileExtension = '.zip';
                    mimeType = 'application/zip';
                }

                const blob = new Blob([response.data], { type: mimeType });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', filename.endsWith(fileExtension) ? filename : filename + fileExtension);
                document.body.appendChild(link);
                link.click();
                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false);
        }
    };


    const filteredDealers = dealerData?.filter((dealer) =>
        dealer.dealer_name?.toLowerCase().includes(dealerSearch.toLowerCase())
    );

    return (
        <>
            <BackdropLoader loading={loading} />
            <Paper className="table-auto-width" elevation={0} sx={{ borderRadius: 3, m: isMobile ? 1.5 : 2, width: "inherit" }}>
                <Box sx={{ borderRadius: 2 }}>
                    <Box
                        display="flex"
                        justifyContent="space-between"
                        alignItems="center"
                        px={isMobile ? 2 : 3}
                        my={2}
                    >
                        <Typography className="georama-SemiBold fs-20">Report</Typography>
                    </Box>

                    <Divider sx={{ mb: 2 }} />

                    <Grid container spacing={2} px={isMobile ? 2 : 3} mb={2}>
                        <Grid item xs={12} sm={6} md={3} sx={{ minWidth: 220 }}>
                            <Typography className="text-labels" mb={0.5}>
                                Report <span className="important-fields">*</span>
                            </Typography>
                            <FormControl
                                className="form-control-input border-radius-8"
                                size="small"
                                required
                                fullWidth
                                error={!!formErrors.report}
                            >
                                <Select
                                    value={formValues.report}
                                    onChange={(e) => {
                                        const selectedReport = reportData?.find(d => d.report_id === e.target.value);
                                        setFormValues((prev) => ({
                                            ...prev,
                                            report: selectedReport.report_id,
                                        }));
                                    }}
                                    displayEmpty
                                >
                                    <MenuItem value="" disabled>Select</MenuItem>
                                    {reportData && reportData?.map((data, index) => (
                                        <MenuItem key={index} value={data.report_id}>
                                            {data.report_type}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            <FormHelperText className="important-fields">
                                {formErrors.report}
                            </FormHelperText>
                        </Grid>

                        {userDetails.roleType === 'MIBL' && (
                            <Grid item xs={12} sm={6} md={3} sx={{ minWidth: 220 }}>
                                <Typography className="text-labels" mb={0.5}>
                                    Dealer <span className="important-fields">*</span>
                                </Typography>

                                <FormControl
                                    sx={{ maxWidth: 220, backgroundColor: '#ffffff', borderRadius: 2 }}
                                    className="form-control-input border-radius-8"
                                    size="small"
                                    required
                                    fullWidth
                                    error={!!formErrors.dealer}
                                >
                                    <Select
                                        className="georama-Medium"
                                        labelId="Dealer-label"
                                        id="Dealer-select"
                                        multiple
                                        value={selectedDealerData}
                                        displayEmpty
                                        open={dealerSelectOpen}
                                        onClose={() => setDealersSelectOpen(false)}
                                        onOpen={() => setDealersSelectOpen(true)}
                                        renderValue={(selected) => {
                                            if (selected.length === 0) return 'Select';
                                            if (selected.length === dealerData?.length) return 'All';
                                            return dealerData
                                                .filter((d) => selected.includes(d.dealer_code))
                                                .map((d) => d.dealer_name)
                                                .join(', ');
                                        }}
                                        MenuProps={{
                                            disableScrollLock: true,
                                            PaperProps: {
                                                style: {
                                                    position: 'fixed',
                                                    zIndex: 1500,
                                                    scrollbarWidth: 'thin',
                                                    scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                                },
                                                sx: {
                                                    '&::-webkit-scrollbar': { width: '4px' },
                                                    '&::-webkit-scrollbar-track': { backgroundColor: '#f1f1f1', borderRadius: '4px' },
                                                    '&::-webkit-scrollbar-thumb': { backgroundColor: '#d0cac9ff', borderRadius: '4px' },
                                                    '&::-webkit-scrollbar-thumb:hover': { backgroundColor: '#d32f2f' },
                                                },
                                            },
                                        }}
                                    >
                                        <MenuItem disableRipple disableTouchRipple sx={{ py: 1, px: 1 }}>
                                            <TextField
                                                size="small"
                                                placeholder="Search dealer..."
                                                variant="outlined"
                                                fullWidth
                                                value={dealerSearch}
                                                onChange={(e) => setDealerSearch(e.target.value)}
                                                onClick={(e) => e.stopPropagation()}
                                                onKeyDown={(e) => e.stopPropagation()}
                                                InputProps={{
                                                    sx: { fontSize: 14, backgroundColor: '#fff' },
                                                }}
                                            />
                                        </MenuItem>

                                        {/* Show "All" only when search is empty */}
                                        {dealerSearch.trim() === "" && (
                                            <MenuItem
                                                disableGutters
                                                sx={{ py: 0, px: 1, m: 0 }}
                                                value="all"
                                                onClick={() => handleDealerToggle("all")}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        "&.Mui-checked": { color: "#e53935" },
                                                        "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                    }}
                                                    checked={selectedDealerData.length === dealerData?.length}
                                                    indeterminate={
                                                        selectedDealerData.length > 0 &&
                                                        selectedDealerData.length < dealerData.length
                                                    }
                                                />
                                                All
                                            </MenuItem>
                                        )}

                                        {/* Filtered Dealer List */}
                                        <Box sx={{ maxHeight: 150, overflowY: "auto", pr: 1 }}>
                                            {dealerData
                                                ?.filter((dealer) =>
                                                    dealer.dealer_name
                                                        ?.toLowerCase()
                                                        .includes(dealerSearch.toLowerCase())
                                                )
                                                .map((dealer) => (
                                                    <MenuItem
                                                        key={dealer.dealer_code}
                                                        value={dealer.dealer_code}
                                                        onClick={() => handleDealerToggle(dealer.dealer_code)}
                                                        disableGutters
                                                        sx={{ py: 0, px: 1, m: 0 }}
                                                    >
                                                        <Checkbox
                                                            sx={{
                                                                "&.Mui-checked": { color: "#e53935" },
                                                                "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                            }}
                                                            checked={selectedDealerData.includes(dealer.dealer_code)}
                                                        />
                                                        {dealer.dealer_name}
                                                    </MenuItem>
                                                ))}
                                        </Box>
                                    </Select>
                                </FormControl>

                                <FormHelperText className="important-fields">
                                    {formErrors.dealer}
                                </FormHelperText>
                            </Grid>
                        )}


                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                            <Grid container spacing={2}>
                                {/* From Date */}
                                <Grid item xs={12} sm={6}>
                                    <Typography className="text-labels" mb={0.5}>
                                        From Date <span className="important-fields">*</span>
                                    </Typography>
                                    <DatePicker
                                        value={fromDate}
                                        onChange={handleFromDateChange}
                                        minDate={minAllowedDate}
                                        maxDate={today}
                                        format="dd/MM/yyyy"
                                        slotProps={{
                                            textField: { fullWidth: true, size: "small" },
                                            field: {
                                                readOnly: true,
                                                onKeyDown: (e) => e.preventDefault(),
                                                onPaste: (e) => e.preventDefault(),
                                                inputMode: "none",
                                                style: { caretColor: "transparent" },
                                            },
                                        }}
                                    />
                                </Grid>

                                {/* To Date */}
                                <Grid item xs={12} sm={6}>
                                    <Typography className="text-labels" mb={0.5}>
                                        To Date <span className="important-fields">*</span>
                                    </Typography>
                                    <DatePicker
                                        value={toDate}
                                        onChange={handleToDateChange}
                                        minDate={fromDate || minAllowedDate}
                                        maxDate={today}
                                        format="dd/MM/yyyy"
                                        shouldDisableDate={(date) => {
                                            if (!fromDate) return false;
                                            return (
                                                isBefore(date, subDays(fromDate, 30)) ||
                                                isAfter(date, addDays(fromDate, 30))
                                            );
                                        }}
                                        slotProps={{
                                            textField: { fullWidth: true, size: "small" },
                                            field: {
                                                readOnly: true,
                                                onKeyDown: (e) => e.preventDefault(),
                                                onPaste: (e) => e.preventDefault(),
                                                inputMode: "none",
                                                style: { caretColor: "transparent" },
                                            },
                                        }}
                                    />
                                </Grid>

                                {/* Download Button */}
                                {/* <Grid item xs={12} sm={12} md={1.5} display="flex" alignItems="flex-end">
                                    <Button
                                        className="btn-common-red"
                                        onClick={downloadReportData}
                                        disabled={
                                            formValues.report === "" ||
                                            (userDetails?.roleType === "MIBL" && !selectedDealerData?.length)
                                        }
                                        fullWidth
                                    >
                                        Download
                                    </Button>
                                </Grid> */}
                            </Grid>
                        </LocalizationProvider>
                        {/* Download Button */}
                        <Grid item xs={12} sm={12} md={1.5} display="flex" alignItems="flex-end">
                            <Button
                                className="btn-common-red"
                                onClick={downloadReportData}
                                disabled={
                                    // !fromDate ||
                                    // !toDate ||
                                    formValues.report === "" ||
                                    (userDetails?.roleType === "MIBL" && !selectedDealerData.length)
                                }
                                // disabled={!fromDate || !toDate || formValues.report == "" || (userDetails?.roleType === "MIBL" ? !selectedDealerData.length : null) || fromDate > toDate || fromDate >= new Date()}
                                // disabled={
                                //     formValues.report === "" ||
                                //     (userDetails?.roleType === "MIBL" && !selectedDealerData.length) ||
                                //     !isDateRangeValid(fromDate, toDate)
                                // }
                                fullWidth
                            >
                                Download
                            </Button>
                        </Grid>
                    </Grid >
                </Box >
            </Paper >
            <ToastContainer autoClose={1000} />
        </>
    );
};

export default Reports;