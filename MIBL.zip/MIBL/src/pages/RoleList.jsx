import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import { Autocomplete, Box, Button, FormControl, FormControlLabel, FormGroup, IconButton, Pagination, Paper, Skeleton, styled, Switch, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, ToggleButton, ToggleButtonGroup, Typography, useMediaQuery } from "@mui/material";
import { useCallback, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import BackdropLoader from "../components/Loader/BackdropLoader";
import ViewRoles from "../modals/ViewRoles";
import { getMappedDealerRoles, updateRoleStatus } from "../services/api";
import { encryptRoute } from "../services/encrypt";

const IOSSwitch = styled((props) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
    width: 54,
    height: 27,
    padding: 0,
    '& .MuiSwitch-switchBase': {
        padding: 0,
        margin: 2,
        transitionDuration: '300ms',
        '&.Mui-checked': {
            transform: 'translateX(27px)',
            color: '#fff',
            '& + .MuiSwitch-track': {
                backgroundColor: '#e31837',
                opacity: 1,
                border: 0,
                ...theme.applyStyles('dark', {
                    backgroundColor: '#e31837',
                }),
            },
            '&.Mui-disabled + .MuiSwitch-track': {
                opacity: 0.5,
            },
        },
        '&.Mui-focusVisible .MuiSwitch-thumb': {
            color: '#e31837',
            border: '5px solid #fff',
        },
        '&.Mui-disabled .MuiSwitch-thumb': {
            color: theme.palette.grey[100],
            ...theme.applyStyles('dark', {
                color: theme.palette.grey[600],
            }),
        },
        '&.Mui-disabled + .MuiSwitch-track': {
            opacity: 0.7,
            ...theme.applyStyles('dark', {
                opacity: 0.3,
            }),
        },
    },
    '& .MuiSwitch-thumb': {
        boxSizing: 'border-box',
        width: 23,
        height: 23,
    },
    '& .MuiSwitch-track': {
        borderRadius: 27 / 2,
        backgroundColor: '#E9E9EA',
        opacity: 1,
        transition: theme.transitions.create(['background-color'], {
            duration: 500,
        }),
        ...theme.applyStyles('dark', {
            backgroundColor: '#39393D',
        }),
    },
}));

export default function RoleList() {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const navigate = useNavigate();
    const [limit, setLimit] = useState(10);
    const featureAccess = useSelector((state) => state.user.featureAccess.filter(f => f.Url && f.Url.startsWith('/role')));
    const [search, setSearch] = useState('');
    const [page, setPage] = useState(1);
    const [roleType, setRoleType] = useState(featureAccess.filter(f => f.Url && f.Url === '/role').map(f => f.FeatureName.slice(0, -5)).sort((a, b) => b.localeCompare(a))[0]);
    const roles = featureAccess.filter(f => f.Url && f.Url === '/role').map(f => f.FeatureName.slice(0, -5)).sort((a, b) => b.localeCompare(a));
    const [formValues, setFormValues] = useState({
        dealer: '',
    });
    const [openModal, setOpenModal] = useState(false);
    const [selectedItem, setSelectedItem] = useState(null);
    const [roleList, setRoleList] = useState();
    const userDetails = useSelector((state) => state?.user?.loggedData);
    const [dealersList, setDealersList] = useState([]);
    const [paginationCount, setPaginationCount] = useState(0);
    const [loading, setLoading] = useState(false);

    const handleViewRoles = (item) => {
        setSelectedItem(item);
        setOpenModal(true);
    };

    const handleEditRoles = (item) => {
        navigate(`/${encodeURIComponent(encryptRoute('/role/edit'))}`, {
            state: {
                isEdit: true,
                roleData: item
            }
        });
    };

    const handleCloseModal = () => {
        setOpenModal(false);
        setSelectedItem(null);
    };
    const toggleRoleStatus = async (row) => {
        let payload = {
            userId: userDetails.user_id,
            roleId: row.role_id,
            roleStatus: row.status === "1" ? "0" : "1"
        }
        try {
            setLoading(true);
            const res = await updateRoleStatus(payload);
            if (res.status_code === '200') {
                getRoleList();
                toast.success(res.status_message)
            } else {
                toast.error(res.status_message);
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    const getRoleList = useCallback(async () => {
        let payload;
        if (userDetails?.roleType === 'MIBL') {
            if (roleType === 'MIBL') {
                payload = { offset: page, limit: limit, roleType: roleType, searchName: search }
            } else {
                if (!formValues.dealer) {
                    payload = { offset: page, limit: limit, roleType: roleType, searchName: search }
                } else {
                    // payload = { offset: page, limit: limit, roleType: roleType, parentCode: formValues.parentCode, searchName: search }
                    payload = { offset: page, limit: limit, roleType: roleType, parentCode: formValues.dealer, searchName: search }
                }
            }
        }
        else if (userDetails?.roleType === 'DEALER') {
            // payload = { offset: page, limit: limit, roleType: roleType, parentCode: userDetails?.parentCode, searchName: search }
            payload = { offset: page, limit: limit, roleType: roleType, parentCode: userDetails?.dealerCode, searchName: search }
        }
        setLoading(true);
        try {
            const response = await getMappedDealerRoles(payload);
            if (response.status_code === "200") {
                if (userDetails?.roleType === 'MIBL') {
                    setRoleList(roleType === 'MIBL' || !formValues.dealer ? response.result1 : response.result0);
                    setPaginationCount(roleType === 'MIBL' || !formValues.dealer ? response.result2[0].paginationCount : response.result1[0].paginationCount);
                    if (roleType === 'MIBL' || !formValues.dealer) {
                        setDealersList(response.result0);
                    }
                } else if (userDetails?.roleType === 'DEALER') {
                    setRoleList(response.result0);
                    setPaginationCount(response.result1[0].paginationCount);
                }
            } else if (response.status_code == "404") {
                setRoleList([]);
                setPaginationCount(0);
            }
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false);
        }
    }, [limit, page, roleType, search, formValues.dealer]);

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            getRoleList();
        }, 300);

        return () => clearTimeout(delayDebounce);
    }, [limit, page, search, roleType, formValues.dealer]);

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            page === 1 ? {} : setPage(1)
        }, 0);

        return () => clearTimeout(delayDebounce);
    }, [roleType, formValues.dealer]);

    // useEffect(() => {
    //     page === 1 ? getRoleList() : setPage(1);
    // }, [formValues.dealer]);

    // useEffect(() => {
    //     page === 1 ? getRoleList() : setPage(1);
    // }, [roleType]);

    return (
        <>
            <BackdropLoader loading={loading} />
            <Paper className="table-auto-width" sx={{ m: isMobile ? 1.5 : 2, borderRadius: 2, boxShadow: "none" }}>
                <Box display="flex" flexWrap={"wrap"} justifyContent="space-between" alignItems="center" p={2} pt={2.5} pb={isMobile ? 0 : 2.5} px={2.5}>
                    <Typography className={`${isMobile ? 'fs-16' : 'fs-24'} georama-SemiBold`}>
                        Role Lists
                    </Typography>
                    <Box display="flex" flexWrap={"wrap"} justifyContent="space-between" alignItems="center">
                        {!!featureAccess.filter(f => f.Url === '/role/create' && f.FeatureName.startsWith(roleType)).length &&
                            <Button
                                sx={{ mt: isMobile ? 1 : 0 }}
                                className="btn-common-red"
                                onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/role/create'))}`)}
                            >
                                Add New Role
                            </Button>}
                        <TextField className="custom-textfield body-formbg" size="small" placeholder="Search" value={search} onChange={(e) => setSearch(e.target.value.trimStart().replace(/[^a-zA-Z0-9.@\s]/g, '').replace(/\s+/g, ' ').slice(0, 50)) || setPage(1)}
                            sx={{
                                mt: isMobile ? 1 : 0,
                                width: isMobile ? '50%' : '22ch',
                                px: 2,
                                ml: isMobile ? 0 : 1,
                                '& .MuiOutlinedInput-root': {
                                    borderRadius: 3,
                                    '&.Mui-focused fieldset': {
                                        borderColor: 'black',
                                    },
                                },
                            }}
                        />
                    </Box>
                </Box>
                {userDetails?.roleType === 'MIBL' &&
                    <Box display="flex" flexWrap={"wrap"} alignItems="center" justifyContent="space-between" gap={2} mb={1}>
                        {/* Left Side: Labels */}
                        <Box display="flex" alignItems="center" gap={2}>
                            <ToggleButtonGroup
                                value={roleType}
                                exclusive
                                onChange={(e, newValue) => {
                                    if (newValue !== null) setRoleType(newValue);
                                }}
                                sx={{ display: 'flex', gap: 1, border: 'none' }}>
                                {roles.map((v) => (
                                    <ToggleButton exclusive className="toggle-button"
                                        key={v} value={v}>
                                        {v}
                                    </ToggleButton>
                                ))}
                            </ToggleButtonGroup>
                        </Box>

                        {/* Right Side: Filters & Marquee */}
                        <Box sx={{ ml: 2 }} display="flex" alignItems="center" gap={1}>
                            {/* <Box sx={{ visibility: roleType === 'Dealer' ? 'visible' : 'hidden' }} display="flex" justifyContent="space-between" alignItems="center">
                            <TextField className="custom-textfield body-formbg" size="small" placeholder="Location"
                                value={search}
                                onChange={(e) => setSearch(e.target.value.trimStart().replace(/[^a-zA-Z0-9.,\s]/g, '').replace(/\s+/g, ' ').slice(0, 50)) || setPage(1)}
                                sx={{
                                    width: '22ch',
                                    px: 2,
                                    '& .MuiOutlinedInput-root': {
                                        borderRadius: 3,
                                        '&.Mui-focused fieldset': {
                                            borderColor: 'black',
                                        },
                                    },
                                    float: 'right'
                                }}
                            />
                        </Box> */}
                            <FormControl
                                sx={{ ms: 2, display: roleType === 'Dealer' ? 'block' : 'none', mr: 2, width: 250 }}
                                className='form-control-input border-radius-8'
                                size="small"
                                fullWidth
                            >
                                <Autocomplete
                                    size="small"
                                    options={dealersList || []}
                                    getOptionLabel={(option) => option.dealer_name || ''}
                                    value={dealersList.find(d => d.dealer_name === formValues.dealer) || null}
                                    onChange={(event, newValue) => {
                                        setFormValues((prev) => ({
                                            ...prev,
                                            dealer: newValue?.dealer_name || '',
                                            parentCode: newValue?.parent_code || ''
                                        }));
                                    }}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            placeholder="Select Dealer"
                                            size="small"
                                        />
                                    )}
                                    isOptionEqualToValue={(option, value) => option.dealer_name === value.dealer_name}
                                />
                            </FormControl>

                        </Box>
                    </Box>}

                <TableContainer>
                    <Table>
                        <TableHead>
                            <TableRow sx={{ backgroundColor: "#f1f1f1" }}>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">
                                    Role Name
                                </TableCell>

                                {/* if mibl logged In */}
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">
                                    {roleType === 'MIBL' ? 'Role Source' : 'Dealer Name'}
                                </TableCell>
                                {roleType === "Dealer" && <TableCell className="p-10 georama-Medium body-formbg fw-none">
                                    Location
                                </TableCell>}
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">
                                    Report Role
                                </TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">
                                    Action
                                </TableCell>
                                <TableCell className="p-10 georama-Medium body-formbg fw-none">
                                    Status
                                </TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {loading ? (
                                [...Array(8)].map((_, idx) => (
                                    <TableRow key={idx}>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                    </TableRow>
                                ))) : (roleList && roleList?.length > 0 ?
                                    (roleList?.map((item, index) => (
                                        <TableRow key={index} sx={{ "&:hover": { backgroundColor: "#f5f5f5" } }}>
                                            <TableCell className="p-10 georama-Medium text-truncate">
                                                {/* <span className="p-10 georama-Medium text-truncate"> */}
                                                {item.roleName}
                                                {/* </span> */}
                                            </TableCell>
                                            <TableCell className="p-10 georama-Medium">
                                                {roleType === 'MIBL' ? item.role_type : item.dealerName}
                                            </TableCell>

                                            {/* if dealer option is selected  */}
                                            {roleType === "Dealer" && <TableCell className="p-10 georama-Regular">
                                                {item.role_location}
                                            </TableCell>}

                                            <TableCell className="georama-Regular p-10">
                                                {item.reportingRole}
                                            </TableCell>
                                            <TableCell sx={{ display: isMobile ? "flex" : "" }} className="georama-Regular">
                                                {!!featureAccess.filter(f => f.Url === '/role/edit' && f.FeatureName.startsWith(roleType)).length && <IconButton
                                                    onClick={() => handleEditRoles(item)}>
                                                    <EditOutlinedIcon />
                                                </IconButton>}
                                                {<IconButton
                                                    onClick={() => handleViewRoles(item)}>
                                                    <VisibilityOutlinedIcon />
                                                </IconButton>}
                                            </TableCell>
                                            <TableCell>
                                                <FormGroup>
                                                    <FormControlLabel
                                                        control={<IOSSwitch checked={item.status === "1"} onChange={() => toggleRoleStatus(item)} />}
                                                    />
                                                </FormGroup>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                    ) : (!roleList || !roleList?.length) && (
                                        <TableRow>
                                            <TableCell colSpan={roleType === 'MIBL' ? 4 : 5}><Box className="center-text">No Records Found.</Box></TableCell>
                                        </TableRow>
                                    ))}
                        </TableBody>
                    </Table>
                </TableContainer>
                <Box className="table-body-bg border-radius-bottom-8" display="flex" justifyContent="space-between" alignItems="end" p={2} px={2.5}>
                    {!!paginationCount && <Pagination
                        className="bg-white"
                        size="medium"
                        count={Math.ceil(paginationCount / limit)}
                        page={page} onChange={(e, v) => setPage(v)} shape="rounded"
                        sx={{
                            float: 'right', ml: "auto",
                            '& .MuiPaginationItem-root': {
                                borderRadius: 3,
                            }
                        }} />}
                </Box>
            </Paper>

            <ViewRoles open={openModal} onClose={handleCloseModal} item={selectedItem} />
            <ToastContainer autoClose={1000} />
        </>
    );
}