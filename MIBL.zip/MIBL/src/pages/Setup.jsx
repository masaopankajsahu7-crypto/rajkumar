import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { Autocomplete, Box, Button, Divider, FormControlLabel, FormHelperText, Grid, Paper, Stack, TextField, Typography } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import FormLabel from '@mui/material/FormLabel';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import BackdropLoader from '../components/Loader/BackdropLoader';
import SetUpAccordion from '../components/MISPSetup/SetUpAccordion';
import { editDealerDetails, getDealerDetails, saveOutletSetup } from '../services/api';
import { encryptRoute } from '../services/encrypt';
import { bgGray100 } from '../utils/Colors';

const MISPsetup = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [dealerDetails, setDealerDetails] = useState([]);
    const [locations, setLocations] = useState([]);
    const [crossAllocations, setCrossAllocations] = useState([]);
    const [customTemplates, setCustomTemplates] = useState([]);
    const [accordion, setAccordion] = useState(null);
    const [mappingSaved, setMappingSaved] = useState({});
    const [columnMapping, setColumnMapping] = useState([]);
    const [selectedTemplates, setSelectedTemplates] = useState([]);
    const location = useLocation();
    const navigate = useNavigate();
    const dealerInfo = location.state || {};
    const isEdit = location.state?.edit || false;
    const [dealerAddress, setDealerAddress] = useState('');
    const accordionLabels = ['Policy', 'Claim', 'Service', 'Sales Data', 'Add On'];
    const accordionData = ['policy', 'claim', 'service', 'sales', 'addOn'];
    const userdetails = useSelector((state) => state.user.loggedData);
    const [createNew, setCreateNew] = useState(true);
    const [loading, setLoading] = useState(false);

    const fetchData = async (dealerId, parentId) => {
        try {
            setLoading(true);
            if (isEdit) {
                const res = await editDealerDetails(dealerInfo.ebmCode, dealerId, parentId);
                setDealerDetails(res);
                setLocations(res.dealerLocations.map((loc) => ({ label: loc.dealerLocName, id: loc.dealerId, ...loc })));
                setCrossAllocations(res.dealerLocations.map((loc) => ({ label: loc.dealerLocName, id: loc.dealerId })));
                setDealerAddress(res.dealerLocations.find(loc => loc.dealerId === res.dealerDetails.map)?.dealerAddress);
                setFormValues(prev => ({
                    ...prev,
                    ['map']: res.dealerLocations.map((loc) => ({ label: loc.dealerLocName, id: loc.dealerId }))
                        .find(loc => loc.id === res.dealerDetails.map),
                    // ['existingMap']: res.dealerDetails.map,
                    ['otpFlag']: res.dealerDetails?.otpFlag === 'Yes',
                    ['leadAssignment']: res.dealerDetails.leadAssignment,
                    ['crossAllocation']: res.dealerLocations.map((loc) => ({ label: loc.dealerLocName, id: loc.dealerId }))
                        .filter(loc => res.dealerDetails?.crossAllocation?.split(',').includes(loc.id)),
                    ['communication']: res.dealerDetails?.communication?.split(','),
                    ['policyFlag']: res.dealerDetails.policyFlag,
                    ['claimFlag']: res.dealerDetails.claimFlag,
                    ['serviceFlag']: res.dealerDetails.serviceFlag,
                    ['salesFlag']: res.dealerDetails.salesFlag,
                    ['addOnFlag']: res.dealerDetails.addOnFlag
                }));
                if (res.mappingColumns && res.mappingColumns.length > 0) {
                    setColumnMapping(res.mappingColumns);
                }
                if (res.templateLocations && res.templateLocations.length > 0) {
                    setCustomTemplates(res.templateLocations.concat(
                        res.selectedtemplates.filter(t => !res.templateLocations.some(st => st === t))));
                }
                if (res.selectedtemplates && res.selectedtemplates.length > 0) {
                    setSelectedTemplates(res.selectedtemplates);
                }
                setCreateNew(res.dealerDetails.map === dealerInfo.dealerId);
            }
            else {
                const result = await getDealerDetails(dealerId, parentId);
                setDealerDetails(result);
                setLocations(result.dealerLocations.map((loc) => ({ label: loc.dealerLocName, id: loc.dealerId, ...loc })));
                setCrossAllocations(result.dealerLocations.filter(loc => loc.dealerId != dealerInfo.dealerId).map((loc) => ({ label: loc.dealerLocName, id: loc.dealerId })));
                setCustomTemplates(result.templateLocations);
            }
        } catch (error) {
            console.error('Failed to fetch dealer details:', error);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        if (dealerInfo.dealerId) {
            fetchData(dealerInfo.dealerId, dealerInfo.parentId);
        }
    }, [dealerInfo]);

    // --------- Form validate ------
    const [formValues, setFormValues] = useState({
        ebmCode: dealerInfo.ebmCode,
        dealerId: dealerInfo.dealerId,
        parentId: dealerInfo.parentId,
        map: null,
        otpFlag: false,
        // existingMap: null,
        leadAssignment: null,
        crossAllocation: [],
        communication: [],
        dealerLocName: '',
        policyFlag: "policy_system",
        claimFlag: "claim_system",
        serviceFlag: "service_system",
        salesFlag: "sales_system",
        addOnFlag: "addon_system"
    });

    const [formErrors, setFormErrors] = useState({});

    const handleInputChange = (field, value) => {
        setFormValues(prev => ({
            ...prev,
            [field]: value,
        }));
        if (!value && field === 'map') setCreateNew(true);
        if (value && field === 'map') {
            setCreateNew(value.id === dealerInfo.dealerId);
            if (value.id !== dealerInfo.dealerId) {
                setFormValues(prev => ({
                    ...prev,
                    ['leadAssignment']: value.leadAssignment,
                    ['crossAllocation']: value.crossAllocation.split(','),
                    ['communication']: value.communication.split(','),
                    ['policyFlag']: value.policyFlag,
                    ['claimFlag']: value.claimFlag,
                    ['serviceFlag']: value.serviceFlag,
                    ['salesFlag']: value.salesFlag,
                    ['addOnFlag']: value.addOnFlag,
                    ['otpFlag']: value?.otpFlag === 'Yes',
                }));
            } else {
                setFormValues(prev => ({
                    ...prev,
                    ['leadAssignment']: '',
                    ['crossAllocation']: [],
                    ['communication']: [],
                    ['policyFlag']: 'policy_system',
                    ['claimFlag']: 'claim_system',
                    ['serviceFlag']: 'service_system',
                    ['salesFlag']: 'sales_system',
                    ['addOnFlag']: 'addon_system',
                    ['otpFlag']: false,
                }));
                accordionData.forEach((field) => {
                    setMappingSaved(prev => ({
                        ...prev,
                        [`${field}Flag`]: 0
                    }));
                });
            }
            setDealerAddress(value.dealerAddress);
            handleInputChange('crossAllocation', value.id === dealerInfo.dealerId ? [] : [...formValues.crossAllocation.filter(loc => loc !== value)]);
        }
        else if (!value && field === 'map') {
            setDealerAddress('');
        }
        if (value && field === 'leadAssignment' && value !== 'Manual') {
            setFormValues(prev => ({
                ...prev,
                ['crossAllocation']: [],
            }));
        }
        setFormErrors((prev) => ({ ...prev, [field]: '' }));
        // setFormValues((prev) => ({ ...prev, [field]: value }));
    };

    const handleCheckboxChange = (event) => {
        const { value, checked } = event.target;
        setFormValues((prev) => ({
            ...prev,
            communication: checked
                ? [...prev.communication, value]
                : prev.communication.filter((v) => v !== value),
        }));
    };

    const validateForm = () => {
        const errors = {};

        if (!formValues.map) errors.map = 'Map selection is required';
        if (formValues.map?.id === dealerInfo.dealerId) {
            if (!formValues.leadAssignment) errors.leadAssignment = 'Lead Assignment is required';
            accordionData.forEach((field, index) => {
                if (formValues?.[`${field}Flag`] !== `${field.toLowerCase()}_system` && (!mappingSaved?.[`${field}Flag`] || mappingSaved?.[`${field}Flag`] < 1)) {
                    errors[`${field}Flag`] = `Fields Mapping not saved for ${accordionLabels[index]}`;
                    toast.warning(`Fields Mapping not saved for ${accordionLabels[index]}`);
                }
            });
        }
        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const handleSubmit = async () => {
        try {
            setLoading(true);
            if (validateForm()) {
                let formData = { ...formValues };
                formData.communication = formValues?.communication?.join(',');
                formData.map = formValues.map.id;
                formData.otpFlag = formValues.otpFlag ? 'Yes' : 'No';
                // formData.existingMap = formValues.existingMap ?? formValues.map.id;
                formData.dealerLocName = formValues.map.id === '' ? formValues.dealerLocName.trim() : '';
                formData.leadAssignment = formValues.leadAssignment;
                formData.crossAllocation = formValues?.crossAllocation?.map(item => item.id).join(',');
                formData.userId = userdetails.user_id
                let response = await saveOutletSetup(formData);
                if (response.statusCode === '200') {
                    toast.success('Outlet Setup saved successfully!');
                    navigate(`/${encodeURIComponent(encryptRoute('/editmispoutlet'))}`)
                }
                else {
                    toast.error('Failed to save Outlet Setup!');
                }
            }
        } catch (error) {
            console.error(error)
        } finally {
            setLoading(false);
        }
        // else {
        //     accordionData.forEach((field) => {
        //         if (formErrors[`${field}Flag`]) toast.warning(formErrors[`${field}Flag`]);
        //     });
        // }
    };
    // --------- Form validate ------

    const leadData = ['Auto', 'Manual'];

    return (
        <Paper className='body-formbg' sx={{ boxShadow: 'none', m: isMobile ? 1.5 : 2, width: 'inherit', height: 'auto', pb: 2, borderRadius: 3 }}>
            <BackdropLoader loading={loading} />
            <Box className="bg-white  border-radius-8" px={1.5} py={1.5}>
                <Box>
                    <Stack
                        px={isMobile ? 0 : 1.5}
                        direction="row"
                        sx={{ justifyContent: 'space-between', alignItems: 'center' }}
                    >
                        <Stack>
                            <Typography gutterBottom className={`georama-SemiBold ${isDesktop ? 'fs-20' : 'fs-14'} text-capitalize`} component="div">
                                {dealerInfo?.dealerName}
                            </Typography>

                            <Typography gutterBottom className={`toggle-unselected ${isDesktop ? 'fs-14' : 'fs-12'} text-capitalize`} component="div">
                                {dealerInfo?.dealerMobileNo} |  {dealerInfo?.dealerLocName}
                            </Typography>
                        </Stack>

                        <Button className='text-capitalize georama-medium-selected custom-starticon'
                            startIcon={<ChevronLeftIcon />}
                            onClick={() => navigate(-1)}>
                            Back
                        </Button>
                    </Stack>

                    <Divider />
                </Box>

                <Box p={isMobile ? 0 : 1.5} py={1}>
                    <Grid container rowSpacing={isMobile ? 1.3 : 2} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                        <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                            <FormLabel className={`text-labels ${isMobile ? 'fs-12' : 'fs-14'} `}>Dealer Code <span className="important-fields">*</span></FormLabel>

                            <TextField
                                className={`disabled-input cursor-nodrop ${isMobile ? 'fs-12' : 'fs-14'}`}
                                size="small"
                                fullWidth
                                variant="filled"
                                value={formValues.dealerId}
                                // onChange={(e) => handleInputChange('ebmCode', e.target.value)}
                                error={!!formErrors.dealerId}
                                helperText={formErrors.dealerId}
                                inputProps={{ readOnly: true, sx: { pt: isMobile ? '4px' : '10px' } }}
                                sx={{
                                    // border: `0.3px solid rgb(186, 179, 179)`,
                                    // borderRadius: 1,
                                    // bgcolor: bgGray100,
                                    '& .MuiFilledInput-root': {
                                        border: 'none',
                                        outline: 'none',
                                        boxShadow: 'none',
                                    },
                                    '& .MuiFilledInput-root:before': {
                                        borderBottom: 'none',
                                    },
                                    '& .MuiFilledInput-root:after': {
                                        borderBottom: 'none',
                                    },
                                    '& .MuiFilledInput-root.Mui-focused': {
                                        outline: 'none',
                                        boxShadow: 'none',
                                        backgroundColor: bgGray100,
                                    }
                                }}
                            />
                        </Grid>

                        <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                            <Typography className={`text-labels ${isMobile ? 'fs-12' : 'fs-14'} `} required>Map <span className="important-fields">*</span></Typography>

                            <Autocomplete
                                className='form-control-input'
                                size="small"
                                options={(locations.length === 0 || (locations.length > 0 && locations.filter((loc) => loc.id === dealerInfo.dealerId).length === 0) ?
                                    [{ label: 'Create New', id: dealerInfo.dealerId, dealerAddress: dealerInfo.dealerAddress }] : []).concat([...locations])}
                                value={formValues.map || null}
                                onChange={(_, value) => handleInputChange('map', value)}
                                isOptionEqualToValue={(option, value) => option.id === value.id}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        placeholder="Select Location"
                                        error={!!formErrors.map}
                                    />
                                )}
                            />

                            <FormHelperText className='important-fields'>{formErrors.map}</FormHelperText>
                        </Grid>

                        {createNew &&
                            <>
                                <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                                    <Typography className={`text-labels ${isMobile ? 'fs-12' : 'fs-14'} `} color="initial" required>Lead Assignment <span className="important-fields">*</span></Typography>

                                    <Autocomplete
                                        className='form-control-input'
                                        size="small"
                                        options={leadData}
                                        value={formValues.leadAssignment || null}
                                        onChange={(_, value) => handleInputChange('leadAssignment', value)}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                placeholder="Select"
                                                error={!!formErrors.leadAssignment}
                                            />
                                        )}
                                    />
                                    <FormHelperText className='important-fields'>{formErrors.leadAssignment}</FormHelperText>
                                </Grid>

                                <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                                    <Typography className={`text-labels ${isMobile ? 'fs-12' : 'fs-14'} `} color="initial">Cross Allocation</Typography>

                                    <Autocomplete multiple
                                        className='form-control-input'
                                        size="small"
                                        options={crossAllocations.filter((loc) => loc.id !== dealerInfo.dealerLocCode && loc.id !== formValues.map?.id)}
                                        disabled={formValues.leadAssignment !== 'Manual'}
                                        value={formValues.crossAllocation}
                                        onChange={(_, value) => handleInputChange('crossAllocation', value)}
                                        isOptionEqualToValue={(option, value) => option.id === value.id}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                placeholder="Select"
                                            />
                                        )}
                                    />
                                </Grid>

                                <Grid size={{ xs: 12, sm: 6, md: 6 }}>
                                    <Typography className={`text-labels ${isMobile ? 'fs-12' : 'fs-14'} `} color="initial">Communication</Typography>

                                    <Stack spacing={isMobile ? 1 : 2} direction={`${isMobile ? 'column' : 'row'}`} width="100%" className="">
                                        {['Email', 'SMS', 'WhatsApp'].map((label) => (
                                            <Box key={label} className="communication-box" width='93%'>
                                                <FormControlLabel
                                                    className="communication-label"
                                                    control={
                                                        <Checkbox
                                                            className="communication-checkbox"
                                                            value={label}
                                                            checked={formValues.communication?.includes(label)}
                                                            onChange={handleCheckboxChange}
                                                        />
                                                    }
                                                    label={label}
                                                />
                                            </Box>
                                        ))}
                                    </Stack>
                                </Grid>

                                <Grid size={{ xs: 12, sm: 12, md: 3, lg: 2 }}>
                                    <Typography className={`text-labels ${isMobile ? 'fs-12' : 'fs-14'} `} color="initial">OTP Access</Typography>

                                    <Stack spacing={2} direction="row" width="100%" className="">
                                        <Box className="communication-box" width='100%'>
                                            <FormControlLabel
                                                className="communication-label"
                                                control={
                                                    <Checkbox
                                                        className="communication-checkbox"
                                                        value='Yes'
                                                        checked={formValues.otpFlag}
                                                        onChange={() => handleInputChange('otpFlag', !formValues.otpFlag)}
                                                    />
                                                }
                                                label="OTP"
                                            />
                                        </Box>
                                    </Stack>
                                </Grid>
                            </>}

                        {/* <Grid size={4} sx={{ visibility: formValues.map && formValues.map.id === '' ? 'visible' : 'hidden' }}>
                        <FormLabel>Map Location</FormLabel>
                        <TextField
                            className='form-control-input'
                            fullWidth
                            variant="filled"
                            value={formValues.dealerLocName}
                            onChange={(e) => handleInputChange('dealerLocName',
                                e.target.value.trimStart().replace(/[^a-zA-Z\s]/g, '').replace(/\s+/g, ' ').slice(0, 50))}
                            error={!!formErrors.dealerLocName}
                        />
                        <Typography color='error' mx={1.9} fontSize={'0.75rem'}>{formErrors.dealerLocName}</Typography>
                    </Grid> */}
                        <Grid size={12}>
                            {dealerAddress && <Typography className={`text-labels ${isMobile ? 'fs-12' : 'fs-14'} `} color="initial">Address</Typography>}

                            <Typography className={`text-gray georama-semiBold dark-black ${isMobile ? 'fs-12' : 'fs-16'}`}>{dealerAddress}</Typography>

                            {/* <TextField fullWidth value={dealerAddress}
                                variant="filled"
                                inputProps={{ readOnly: true, sx: { pt: '10px' } }}
                                sx={{
                                    border: `0.3px solid rgb(186, 179, 179)`,
                                    borderRadius: 1,
                                    bgcolor: bgGray100,
                                    '& .MuiFilledInput-root': {
                                        border: 'none',
                                        outline: 'none',
                                        boxShadow: 'none',
                                    },
                                    '& .MuiFilledInput-root:before': {
                                        borderBottom: 'none',
                                    },
                                    '& .MuiFilledInput-root:after': {
                                        borderBottom: 'none',
                                    },
                                    '& .MuiFilledInput-root.Mui-focused': {
                                        outline: 'none',
                                        boxShadow: 'none',
                                        backgroundColor: bgGray100,
                                    }
                                }} /> */}
                        </Grid>
                    </Grid>
                </Box>
            </Box>

            {createNew &&
                <>
                    <Box mt={2} mb={1}>
                        <Stack
                            direction="row"
                            sx={{ justifyContent: 'space-between', alignItems: 'center' }}
                        >
                            <Typography className={`georama-Medium ${isMobile ? 'fs-16' : 'fs-18'}`}>
                                Fields Mapping
                            </Typography>
                        </Stack>
                    </Box>

                    <Stack spacing={1.5}>
                        {accordionLabels.map((item, index) => (
                            <SetUpAccordion className='bg-white' key={item} label={item} accordion={accordion} setAccordion={setAccordion} data={accordionData[index]} dealerInfo={dealerInfo} dealerDetails={dealerDetails[`${accordionData[index]}DbColName`]} mappingSaved={mappingSaved}
                                setMappingSaved={setMappingSaved} formValues={formValues} handleInputChange={handleInputChange} customTemplates={customTemplates}
                                columnMapping={columnMapping} setColumnMapping={setColumnMapping} selectedTemplates={selectedTemplates} isEdit={isEdit} />
                        ))}
                    </Stack></>}

            <Box display={'flex'} justifyContent={'end'} mt={2} mb={1} px={isMobile ? 0 : 1.5}>
                <Button className='btn-common-red' onClick={handleSubmit}>Submit </Button>
            </Box>

            <ToastContainer autoClose={1000} />
        </Paper >
    );
};

export default MISPsetup;