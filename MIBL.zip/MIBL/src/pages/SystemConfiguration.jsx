import { useEffect, useState } from 'react';
import { Accordion, AccordionSummary, Checkbox, AccordionDetails, Box, Grid, MenuItem, Select, Switch, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography, Button, Paper, FormControl, FormHelperText, Divider, InputLabel, ListItemText, Chip, TableContainer } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { fetchSystemConfiguration, updateSystemConfiguration } from '../services/api';
import { useSelector } from 'react-redux';
import { ToastContainer, toast } from 'react-toastify';
import AddItemModal from '../components/AddItemModal';
import useMediaQuery from '@mui/material/useMediaQuery';

const SystemConfiguration = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const [formErrors, setFormErrors] = useState({});
    const [category, setCategory] = useState('');
    const [expandedAccordion, setExpandedAccordion] = useState(null);
    const [accordionLP, setAccordionLP] = useState(false);
    const [metricOptions, setMetricOptions] = useState([]);
    const [showCategories, setshowCategories] = useState(false);
    const [loading, setLoading] = useState(false);
    const userDetails = useSelector((state) => state.user.loggedData);

    const [hotColdWarmData, setHotColdWarmData] = useState([]);
    const [leadPoolData, setleadPoolData] = useState([]);
    const [thresholdData, setthresholdData] = useState([]);
    const [ncbFieldValues, setNcbFieldValues] = useState([]);
    const [selectedNCBValues, setSelectedNCBValues] = useState([]);
    const [sbFieldValues, setSbFieldValues] = useState([]);
    const [selectedSBValues, setSelectedSBValues] = useState([]);

    const [openModal, setOpenModal] = useState(false);
    const [modalConfig, setModalConfig] = useState({ title: "", fields: [] });
    const [rows, setRows] = useState([]);
    const [rows2, setRows2] = useState([]);

    const [editedRows, setEditedRows] = useState(new Set());
    const [editedRows2, setEditedRows2] = useState(new Set());

    const fetchData = async () => {
        try {
            const [leadCategorizeRes, leadPoolRes, thresholdRes] = await Promise.all([
                fetchSystemConfiguration({ roleId: userDetails.roleId, type: "leadCategorize" }),
                fetchSystemConfiguration({ roleId: userDetails.roleId, type: "leadpool" }),
                fetchSystemConfiguration({ roleId: userDetails.roleId, type: "Threshold" })
            ]);

            setHotColdWarmData(leadCategorizeRes);
            setleadPoolData(leadPoolRes);
            if (thresholdRes?.result1?.length > 0) {
                setthresholdData(thresholdRes);
            }
            processData(leadCategorizeRes);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const [totalPercent, setTotalPercent] = useState(0);

    useEffect(() => {
        let sum = 0;

        rows.forEach(([_, data]) => {
            if (data.percent) sum += Number(data.percent);
        });

        rows2.forEach(([_, data]) => {
            if (data.percent) sum += Number(data.percent);
        });

        setTotalPercent(sum);
    }, [rows, rows2]);

    const processData = (data) => {
        const grouped = {};
        const grouped2 = {};
        const ncb = { hot: [], warm: [], cold: [] };
        const ncbSelected = { hot: [], warm: [], cold: [] };
        const sb = { hot: [], warm: [], cold: [] };
        const sbSelected = { hot: [], warm: [], cold: [] };
        const metricOptions = {};

        const allNCBValues = data?.result1?.map(r => r.p_value) || [];

        const allSubDispositions = data?.result4?.map(r => r.sub_disposition) || [];

        data?.result2?.filter(p => !data?.result3.some(pe => pe.metric === p.metric))
            .forEach(({ metric, label_key, min_value, max_value, weight_percent, status }) => {
                const label = label_key.toLowerCase();
                if (metric === 'NCB') {
                    if (!ncb[label]) ncb[label] = [];
                    ncb[label].push({ min: min_value, max: max_value });
                    return;
                }
                if (metric === 'Customer Readiness to Buy') {
                    if (!sb[label]) sb[label] = [];
                    sb[label].push({ min: min_value, max: max_value });
                    return;
                }

                if (!grouped[metric]) {
                    grouped[metric] = { hot: {}, warm: {}, cold: {}, percent: weight_percent, status: status };
                }
                grouped[metric][label] = { min: min_value, max: max_value, status: status };
            });

        data?.result3?.forEach(({ metric, label_key, field_value, weight_percent, status }) => {
            const label = label_key.toLowerCase();
            if (!grouped2[metric]) {
                grouped2[metric] = { hot: '', warm: '', cold: '', percent: weight_percent, status: status };
            }
            grouped2[metric][label] = field_value;
        });

        data?.result3?.forEach(({ metric, label_key, field_value, weight_percent, status }) => {
            const label = label_key.toLowerCase();
            if (metric === "NCB") {
                if (!ncb[label]) ncb[label] = [];
                ncb[label] = allNCBValues;

                if (allNCBValues.includes(field_value)) {
                    ncbSelected[label] = [...ncbSelected[label], field_value];
                }
            } else if (metric === "Customer Readiness to Buy") {
                if (!sb[label]) sb[label] = [];
                sb[label] = allSubDispositions;

                if (allSubDispositions.includes(field_value)) {
                    sbSelected[label] = [...sbSelected[label], field_value];
                }
            } else {
                if (!grouped2[metric]) {
                    grouped2[metric] = { hot: '', warm: '', cold: '', percent: weight_percent, status: status };
                }
                grouped2[metric][label] = grouped2[metric][label] ? grouped2[metric][label] : field_value;
            }
        });

        setNcbFieldValues(ncb);
        setSelectedNCBValues(ncbSelected);

        setSbFieldValues(sb);
        setSelectedSBValues(sbSelected);

        setRows(Object.entries(grouped));
        setRows2(Object.entries(grouped2));
        setMetricOptions(metricOptions);
    };

    const handleSubmit = async () => {
        if (totalPercent > 100 || totalPercent < 100) {
            toast.error("Total % should be equal to 100. Please adjust values.");
            return;
        }
        const configurations = [];
        let hasInvalidRange = false;

        rows.forEach(([metric, data], index) => {
            if (!editedRows.has(index)) return;
            ['hot', 'warm', 'cold'].forEach(label => {
                const range = data[label];
                if (range?.min != null && range?.max != null) {
                    if (range.min >= range.max) {
                        hasInvalidRange = true;
                        toast.error(`For "${metric}" - "${label}", Min should be less than Max`);
                    }
                }
                // if (range?.min != null && range?.max != null) {
                configurations.push({
                    parameterName: metric,
                    labelKey: label,
                    minValue: String(range.min || "0"),
                    maxValue: String(range.max || "0"),
                    percentage: String(data.percent),
                    fieldStatus: data.status
                });
                // }
            });
        });

        rows2.forEach(([metric, data], index) => {
            if (!editedRows2.has(index)) return;
            ['hot', 'warm', 'cold'].forEach(label => {
                const val = data[label];
                if (metric === 'Customer Readiness to Buy' && val) {
                    configurations.push({
                        parameterName: metric,
                        labelKey: label.toUpperCase(),
                        dropdownValue: val,
                        percentage: String(data.percent),
                        fieldStatus: data.status
                    });
                } else if (metric !== 'NCB' && val) {
                    configurations.push({
                        parameterName: metric,
                        labelKey: label.toUpperCase(),
                        textValue: val,
                        percentage: String(data.percent),
                        fieldStatus: data.status
                    });
                }
            });
        });

        if (selectedNCBValues) {
            rows2.forEach(([metric, data], index) => {
                if (metric === "NCB") {
                    Object.entries(selectedNCBValues).forEach(([category, values]) => {
                        if (values && values.length > 0) {
                            configurations.push({
                                parameterName: "NCB",
                                labelKey: category.toUpperCase(),
                                dropdownValue: values.join(","),
                                percentage: String(data.percent),
                                fieldStatus: data.status
                            });
                        }
                    });
                }
            })
        }

        if (selectedSBValues) {
            rows2.forEach(([metric, data], index) => {
                if (metric === "Customer Readiness to Buy") {
                    Object.entries(selectedSBValues).forEach(([category, values]) => {
                        if (values && values.length > 0) {
                            configurations.push({
                                parameterName: "Customer Readiness to Buy",
                                labelKey: category.toUpperCase(),
                                dropdownValue: values.join(","),
                                percentage: String(data.percent),
                                fieldStatus: data.status
                            });
                        }
                    });
                }
            })
        }

        if (hasInvalidRange) {
            return;
        }


        try {
            setLoading(true);
            const response = await updateSystemConfiguration(
                {
                    userId: userDetails.user_id,
                    "configurations": configurations
                });
            if (response.status_code === "200" || response.status_message === "System configuration updated successfully") {
                toast.success("Configuration updated successfully!");
            } else {
                toast.error(response.status_message);
            }
        } catch (error) {
            console.log(error);
            toast.error("Something went wrong.");
        } finally {
            setLoading(false);
            fetchData();
        }
    };

    const markRowEdited = (index) => {
        setEditedRows(prev => new Set(prev).add(index));
    };

    const markRow2Edited = (index) => {
        setEditedRows2(prev => new Set(prev).add(index));
    };

    const handleOpenModal = (title, fields) => {
        setModalConfig({ title, fields });
        setOpenModal(true);
    };

    const handleCloseModal = () => setOpenModal(false);

    const showCategoryItems = () => {
        setshowCategories(true);
    }

    const handleModalSubmit = async (data) => {
        let payload = {
            "userId": userDetails.user_id,
            "leadPoolType": "leadPool"
        }

        if (data.title === "Add On") {
            payload.addonName = data.formData.name,
                payload.addonCode = data.formData.code
        } else if (data.title === "Vehicle") {
            payload.vehicleName = data.formData.name,
                payload.vehicleCode = data.formData.code
        } else if (data.title === "Renewal Category") {
            payload.renewalCategory = data.formData.renewal_year
        } else if (data.title === "Insurance Company") {
            payload.insuranceCompany = data.formData.name
        }

        try {
            setLoading(true);
            const result = await updateSystemConfiguration(payload);
            if (result.status_code === "200" || result.status_message === "System configuration updated successfully") {
                toast.success(result.status_message);
                fetchData();
            } else {
                toast.error(result.status_message);
            }
        } catch (error) {
            console.log(error)
            toast.error("Something went wrong.");
        } finally {
            setLoading(false);
        }
    };

    const [formValues, setFormValues] = useState({
        leadCaptureDays: "",
        userInactivityDays: "",
        userPasswordExpiryDays: "",
        lostBucketDays: "",
        leadRolloverYear: "",
        // resetPassword: ""
    });

    const handleCategoryChange = (event) => {
        const selected = event.target.value;
        setCategory(selected);
        setExpandedAccordion(selected);
        setshowCategories(false);
    };

    const thresholdMap = {
        lead_capture_interval_days: "leadCaptureDays",
        inactive_user_threshold_days: "userInactivityDays",
        password_expiry_days: "userPasswordExpiryDays",
        lost_bucket_threshold_days: "lostBucketDays",
        lead_rollover_threshold_year: "leadRolloverYear",
        // communication_config_days: "resetPassword",
    };

    const updateThresholdValues = (data) => {
        const updatedValues = { ...formValues };

        data?.result1?.forEach((item) => {
            const key = thresholdMap[item?.services_property];
            if (key) {
                updatedValues[key] = item?.services_value;
            }
        });

        setFormValues(updatedValues);
    };

    useEffect(() => {
        if (thresholdData) {
            updateThresholdValues(thresholdData);
        }
    }, [thresholdData]);

    const handleChangeThreshold = (fieldName) => (e) => {
        setFormValues((prev) => ({
            ...prev,
            [fieldName]: e.target.value
        }));
    };

    const handleSubmitThreshold = async () => {
        if (!formValues.leadCaptureDays || !formValues.userInactivityDays || !formValues.userPasswordExpiryDays || !formValues.lostBucketDays || !formValues.leadRolloverYear) {
            toast.error("Please fill all fields.");
            return;
        }
        formValues.userId = userDetails.user_id;
        try {
            const response = await updateSystemConfiguration(formValues);
            if (response.status_code === "200" || response.status_message === "System configuration updated successfully") {
                toast.success("System configuration updated successfully");
            } else {
                toast.error("Something went wrong. Please try again later");
            }

        } catch (error) {
            console.log(error)
        }
    };

    return (
        <>
            <Paper className='body-formbg table-auto-width' elevation={0} sx={{ borderRadius: 3, m: isMobile ? 1.5 : 2 }}>
                <Box
                    className="bg-white" borderRadius={2}>
                    <Typography className={`georama-SemiBold ${isMobile ? 'fs-16' : "fs-24"}`} p={2} py={2}>
                        System Configuration
                    </Typography>

                    <Divider />

                    <Grid container spacing={2} p={2} mb={2}>
                        <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Categories <span className="important-fields">*</span>
                            </Typography>

                            <Box display={"flex"} flexWrap={"wrap"} justifyContent={"start"} alignItems={"center"}>
                                <FormControl
                                    className="form-control-input border-radius-8"
                                    size="small"
                                    sx={{ minWidth: isMobile ? "auto" : 200, maxWidth: isMobile ? "auto" : 200 }}
                                    fullWidth
                                    required
                                    error={!!formErrors.category}
                                >
                                    <Select
                                        sx={{ display: "block", paddingRight: 2 }}
                                        size="small"
                                        value={category || "Select Category"}
                                        onChange={handleCategoryChange}
                                    >
                                        <MenuItem value="Select Category" selected>
                                            Select Category
                                        </MenuItem>

                                        {hotColdWarmData?.result0 && hotColdWarmData?.result0?.map((item, index) => (
                                            <MenuItem key={index} value={item.features}>
                                                {item.features}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>

                                <FormHelperText className="important-fields">{formErrors.category}</FormHelperText>

                                <Button sx={{ mx: isMobile ? 0 : 2, mt: 1 }} className="btn-common-red"
                                    onClick={showCategoryItems}>
                                    Submit
                                </Button>
                            </Box>
                        </Grid>
                    </Grid>
                </Box>

                {category === 'Hot Warm Cold' && showCategories &&
                    <>
                        <Accordion
                            borderRadius={2}
                            sx={{ mb: 2, borderRadius: 2, overflow: 'hidden', boxShadow: 'none' }}
                            expanded={expandedAccordion === 'Hot Warm Cold'}
                        >
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                sx={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                }}
                            >
                                <Typography>Hot Warm Cold</Typography>

                                <Box display="flex" alignItems="center" gap={1} ml={"auto"} mr={4}>
                                    <Typography>Total</Typography>
                                    <Chip
                                        className="fs-12 fs-12" color="success" size="small"
                                        label={`${totalPercent}%`}
                                        sx={{
                                            padding: "2px 5px",
                                            backgroundColor: totalPercent > 100 ? "red" : "green",
                                            color: "white",
                                            fontWeight: 600,
                                            borderRadius: 10,
                                        }}
                                    />
                                </Box>
                            </AccordionSummary>

                            <AccordionDetails>
                                <TableContainer
                                    sx={{ overflowX: 'auto' }}
                                >
                                    <Table size="small"
                                        sx={{ minWidth: 650 }}
                                    >
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Parameters</TableCell>

                                                <TableCell>Hot</TableCell>

                                                <TableCell>Warm</TableCell>

                                                <TableCell>Cold</TableCell>

                                                <TableCell>Percent %</TableCell>

                                                <TableCell>Status</TableCell>
                                            </TableRow>
                                        </TableHead>

                                        <TableBody sx={{ overflowX: "scroll" }}>
                                            {rows.map(([metric, data], i) => (
                                                <TableRow key={metric}>
                                                    <TableCell>{metric}</TableCell>

                                                    {['hot', 'warm', 'cold'].map(category => (
                                                        <TableCell key={category} className='sys-config'>
                                                            <Box display="flex" gap={0.6}>
                                                                <TextField
                                                                    sx={{ minWidth: isMobile ? 100 : 90, maxWidth: isMobile ? 100 : 90 }}
                                                                    className='form-control-input border-radius-8'
                                                                    size="small"
                                                                    type="number"
                                                                    label="Min"
                                                                    value={data[category]?.min ?? ''}
                                                                    onChange={(e) => {
                                                                        const value = Number(e.target.value);
                                                                        const updated = [...rows];
                                                                        updated[i][1][category] = {
                                                                            ...updated[i][1][category],
                                                                            min: value
                                                                        };
                                                                        setRows(updated);
                                                                        markRowEdited(i);

                                                                        // Debounced validation
                                                                        clearTimeout(updated[i][1][category]?.minTimer);
                                                                        updated[i][1][category].minTimer = setTimeout(() => {
                                                                            const minVal = updated[i][1][category]?.min ?? null;
                                                                            const maxVal = updated[i][1][category]?.max ?? null;
                                                                            if (minVal !== null && maxVal !== null && minVal >= maxVal) {
                                                                                toast.error(`Min should be less than Max for ${category}`);
                                                                                return;
                                                                            }
                                                                        }, 200);
                                                                    }}
                                                                    fullWidth
                                                                />

                                                                <TextField
                                                                    sx={{ px:0,  minWidth: isMobile ? 120 : 140, maxWidth: isMobile ? 100 : 130 }}
                                                                    className='form-control-input border-radius-8'
                                                                    size="small"
                                                                    type="number"
                                                                    label="Max"
                                                                    value={data[category]?.max ?? ''}
                                                                    onChange={(e) => {
                                                                        const value = Number(e.target.value);
                                                                        const updated = [...rows];
                                                                        updated[i][1][category] = {
                                                                            ...updated[i][1][category],
                                                                            max: value
                                                                        };
                                                                        setRows(updated);
                                                                        markRowEdited(i);

                                                                        clearTimeout(updated[i][1][category]?.maxTimer);
                                                                        updated[i][1][category].maxTimer = setTimeout(() => {
                                                                            const minVal = updated[i][1][category]?.min ?? null;
                                                                            const maxVal = updated[i][1][category]?.max ?? null;
                                                                            if (minVal !== null && maxVal !== null && maxVal <= minVal) {
                                                                                toast.error(`Max should be greater than Min for ${category}`);
                                                                                return;
                                                                            }
                                                                        }, 200);
                                                                    }}

                                                                    fullWidth
                                                                />
                                                            </Box>
                                                        </TableCell>
                                                    ))}

                                                    <TableCell>
                                                        <TextField
                                                            sx={{ maxWidth: 200 }}
                                                            className="form-control-input border-radius-8"
                                                            size="small"
                                                            // type="number"
                                                            label="%"
                                                            value={data.percent ?? ''}
                                                            inputProps={{ min: 0 }}
                                                            onChange={(e) => {
                                                                const val = Number(e.target.value);
                                                                if (val < 0) return;

                                                                let newTotal = totalPercent - (data.percent || 0) + val;

                                                                if (newTotal <= 100) {
                                                                    const updated = [...rows];
                                                                    updated[i][1].percent = val;
                                                                    setRows(updated);
                                                                    markRowEdited(i);
                                                                } else {
                                                                    toast.error("Total % cannot exceed 100");
                                                                }
                                                            }}
                                                            fullWidth
                                                            disabled={data.status !== "1"}
                                                        />
                                                    </TableCell>

                                                    <TableCell
                                                        sx={{ padding: isMobile ? 0 : '' }}
                                                    >
                                                        <Switch
                                                            checked={data.status === "1"}
                                                            onChange={(e) => {
                                                                const updated = [...rows];
                                                                if (e.target.checked) {
                                                                    updated[i][1].status = "1";
                                                                } else {
                                                                    updated[i][1].status = "0";
                                                                    updated[i][1].percent = 0;
                                                                }
                                                                setRows(updated);
                                                                markRowEdited(i);
                                                            }}
                                                        />
                                                    </TableCell>
                                                </TableRow>
                                            ))}

                                            {rows2.map(([metric, data], i) => (
                                                <TableRow key={metric}>
                                                    <TableCell>{metric}</TableCell>

                                                    {['hot', 'warm', 'cold'].map(category => (
                                                        <TableCell key={category}>
                                                            {metric == "Customer Readiness to Buy" ? (
                                                                <FormControl fullWidth size="small" sx={{ minWidth: 200, maxWidth: 200 }}>
                                                                    <InputLabel>Select {category}</InputLabel>
                                                                    <Select
                                                                        multiple
                                                                        className='form-control-input border-radius-8'
                                                                        value={selectedSBValues[category] || []}
                                                                        onChange={(e) => {
                                                                            setSelectedSBValues({
                                                                                ...selectedSBValues,
                                                                                [category]: e.target.value
                                                                            });
                                                                        }}
                                                                        renderValue={(selected) => selected.join(", ")}
                                                                    >
                                                                        {sbFieldValues[category].map((value) => (
                                                                            <MenuItem key={value} value={value}>
                                                                                <Checkbox checked={selectedSBValues[category]?.includes(value)} />
                                                                                <ListItemText primary={value} />
                                                                            </MenuItem>
                                                                        ))}
                                                                    </Select>
                                                                </FormControl>
                                                            ) : (
                                                                <>
                                                                    {metric === "NCB" ? (
                                                                        <FormControl fullWidth size="small" sx={{ minWidth: 200, maxWidth: 200 }}>
                                                                            <InputLabel>Select NCB</InputLabel>
                                                                            <Select
                                                                                className='form-control-input border-radius-8'
                                                                                multiple
                                                                                value={selectedNCBValues[category] || []}
                                                                                onChange={(e) => {
                                                                                    setSelectedNCBValues({
                                                                                        ...selectedNCBValues,
                                                                                        [category]: e.target.value
                                                                                    });
                                                                                }}
                                                                                renderValue={(selected) => selected.join(", ")}
                                                                            >
                                                                                {ncbFieldValues[category].map((value) => (
                                                                                    <MenuItem key={value} value={value}>
                                                                                        <Checkbox checked={selectedNCBValues[category]?.includes(value)} />
                                                                                        <ListItemText primary={value} />
                                                                                    </MenuItem>
                                                                                ))}
                                                                            </Select>
                                                                        </FormControl>
                                                                    ) :
                                                                        <TextField
                                                                            className='form-control-input border-radius-8'
                                                                            fullWidth
                                                                            size="small"
                                                                            placeholder={`Enter ${category}`}
                                                                            value={data[category]}
                                                                            onChange={(e) => {
                                                                                const updated = [...rows2];
                                                                                updated[i][1][category] = e.target.value;
                                                                                setRows2(updated);
                                                                                markRow2Edited(i);
                                                                            }}
                                                                        />
                                                                    }
                                                                </>
                                                            )}
                                                        </TableCell>
                                                    ))}

                                                    <TableCell>
                                                        <TextField
                                                            sx={{ minWidth: 50 }}
                                                            className="form-control-input border-radius-8"
                                                            size="small"
                                                            // type="number"
                                                            label="%"
                                                            value={data.percent ?? ''}
                                                            inputProps={{ min: 0 }}
                                                            onChange={(e) => {
                                                                const val = Number(e.target.value);
                                                                if (val < 0) return;

                                                                let newTotal = totalPercent - (data.percent || 0) + val;

                                                                if (newTotal <= 100) {
                                                                    const updated = [...rows2];
                                                                    updated[i][1].percent = val;
                                                                    setRows2(updated);
                                                                    markRow2Edited(i);
                                                                } else {
                                                                    toast.error("Total % cannot exceed 100");
                                                                }
                                                            }}
                                                            fullWidth
                                                            disabled={data.status !== "1"}
                                                        />
                                                    </TableCell>

                                                    <TableCell>
                                                        <Switch
                                                            checked={data.status === "1"}
                                                            onChange={(e) => {
                                                                const updated = [...rows2];
                                                                if (e.target.checked) {
                                                                    updated[i][1].status = "1";
                                                                } else {
                                                                    updated[i][1].status = "0";
                                                                    updated[i][1].percent = 0;
                                                                }
                                                                setRows2(updated);
                                                                markRow2Edited(i);
                                                            }}
                                                        />
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>

                                <Box textAlign="right" mt={2}>
                                    <Button className="btn-common-red" onClick={handleSubmit}>
                                        Submit
                                    </Button>
                                </Box>
                            </AccordionDetails>
                        </Accordion>
                    </>}

                {category === 'Lead Pool' && showCategories &&
                    <Accordion className='lead-pool-accordions' borderRadius={2} sx={{ mb: 2, borderRadius: 2, overflow: 'hidden', boxShadow: "none" }}
                        expanded={expandedAccordion === 'Lead Pool'}>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                            <Typography>Lead Pool</Typography>
                        </AccordionSummary>

                        <AccordionDetails>

                            {/* Insurance Companies */}

                            <Accordion sx={{ mb: 1.5, borderRadius: 2, overflow: 'hidden', boxShadow: "none", border: "1px solid #ccc" }}
                                expanded={accordionLP === 'insuranceCompanies'}
                                onChange={() => setAccordionLP(accordionLP === 'insuranceCompanies' ? false : 'insuranceCompanies')}>
                                <AccordionSummary expandIcon={<ExpandMoreIcon />}
                                    sx={{
                                        borderBottom: '1px solid #ccc',
                                        px: 2,
                                    }}
                                >
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                                        <Typography>Insurance Companies</Typography>

                                        <Button className="btn-common-red" sx={{ mr: 2 }}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleOpenModal("Insurance Company", [
                                                    { name: "name", label: "Insurance Company Name" },
                                                ]);
                                            }}
                                            onFocus={(e) => e.stopPropagation()}
                                        >
                                            Add
                                        </Button>
                                    </Box>
                                </AccordionSummary>

                                <AccordionDetails>
                                    <Grid container spacing={1}>
                                        {leadPoolData?.result1?.map((company) => (
                                            <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} key={company.ic_code}>
                                                <Typography className='georama-Regular fs-12 py-2' > {company.ic_name}</Typography>
                                            </Grid>
                                        ))}
                                    </Grid>
                                </AccordionDetails>
                            </Accordion>

                            {/* Renewal Category */}

                            <Accordion sx={{ mb: 1.5, borderRadius: 2, overflow: 'hidden', boxShadow: "none", border: '1px solid #ccc' }}
                                expanded={accordionLP === 'renewalCategories'}
                                onChange={() => setAccordionLP(accordionLP === 'renewalCategories' ? false : 'renewalCategories')}>
                                <AccordionSummary expandIcon={<ExpandMoreIcon />}
                                    sx={{
                                        borderBottom: '1px solid #ccc',
                                        px: 2,
                                    }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                                        <Typography>Renewal Category</Typography>

                                        {/* <Button className="btn-common-red" sx={{ mr: 2 }}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleOpenModal("Renewal Category", [
                                                    { name: "renewal_year", label: "Renewal Year" },
                                                ])
                                            }}
                                            onFocus={(e) => e.stopPropagation()}
                                        >
                                            Add
                                        </Button> */}
                                    </Box>
                                </AccordionSummary>

                                <AccordionDetails>
                                    <Grid container spacing={1}>
                                        {leadPoolData?.result2?.map((renewal) => (
                                            <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} key={renewal.id}>
                                                <Typography className='georama-Regular fs-12 py-2' > {renewal.renewal_year}</Typography>
                                            </Grid>
                                        ))}
                                    </Grid>
                                </AccordionDetails>
                            </Accordion>

                            {/* Vehicle */}

                            <Accordion sx={{ mb: 1.5, borderRadius: 2, overflow: 'hidden', boxShadow: "none", border: '1px solid #ccc' }}
                                expanded={accordionLP === 'vehicle'}
                                onChange={() => setAccordionLP(accordionLP === 'vehicle' ? false : 'vehicle')}>
                                <AccordionSummary expandIcon={<ExpandMoreIcon />}
                                    sx={{
                                        borderBottom: '1px solid #ccc', // Add border here
                                        px: 2, // Optional padding for spacing
                                    }}>

                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                                        <Typography>Vehicle</Typography>

                                        <Button className="btn-common-red" sx={{ mr: 2 }}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleOpenModal("Vehicle", [
                                                    { name: "code", label: "Vehicle Code" },
                                                    { name: "name", label: "Vehicle Name" },
                                                ])
                                            }}
                                            onFocus={(e) => e.stopPropagation()}
                                        >
                                            Add
                                        </Button>
                                    </Box>
                                </AccordionSummary>

                                <AccordionDetails>
                                    <Grid container spacing={1}>
                                        {leadPoolData?.result3?.map((vehicle) => (
                                            <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} key={vehicle.segment_id}>
                                                <Typography className='georama-Regular fs-12 py-2' > {vehicle.name}</Typography>
                                            </Grid>
                                        ))}
                                    </Grid>
                                </AccordionDetails>
                            </Accordion>

                            {/* Add On */}

                            <Accordion sx={{ mb: 1.5, borderRadius: 2, overflow: 'hidden', boxShadow: "none", border: '1px solid #ccc' }}
                                expanded={accordionLP === 'addOn'}
                                onChange={() => setAccordionLP(accordionLP === 'addOn' ? false : 'addOn')}>
                                <AccordionSummary expandIcon={<ExpandMoreIcon />}
                                    sx={{
                                        borderBottom: '1px solid #ccc', // Add border here
                                        px: 2, // Optional padding for spacing
                                    }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                                        <Typography>Add On</Typography>

                                        <Button className="btn-common-red" sx={{ mr: 2 }}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleOpenModal("Add On", [
                                                    { name: "code", label: "Addon Code" },
                                                    { name: "name", label: "Addon Name" },
                                                ])
                                            }}
                                            onFocus={(e) => e.stopPropagation()}
                                        >
                                            Add
                                        </Button>
                                    </Box>
                                </AccordionSummary>

                                <AccordionDetails>
                                    <Grid container spacing={1}>
                                        {leadPoolData?.result4?.map((addon) => (
                                            <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} key={addon.id}>
                                                <Typography className='georama-Regular fs-12 py-2' > {addon.addon_description}</Typography>
                                            </Grid>
                                        ))}
                                    </Grid>
                                </AccordionDetails>
                            </Accordion>

                            {/* <Button sx={{ ml: "auto", display: "flex", my: 2 }} className="btn-common-red" onClick={handleSubmitLeadpool}>
                            Submit
                        </Button> */}

                        </AccordionDetails>
                    </Accordion >}

                {category === 'Threshold' && showCategories &&
                    <Accordion borderRadius={2} sx={{ mb: 2, borderRadius: 2, overflow: 'hidden', boxShadow: "none" }}
                        expanded={expandedAccordion === 'Threshold'}>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                            <Typography>Threshold</Typography>
                        </AccordionSummary>

                        <AccordionDetails>
                            <Grid container spacing={2}>
                                <Grid size={{ xs: 12, sm: 12, md: 6, lg: 4 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Policy To Lead Duration <span className="important-fields">*</span>
                                    </Typography>

                                    <TextField
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        placeholder="Enter Lead Duration"
                                        value={formValues.leadCaptureDays}
                                        type="number"
                                        inputProps={{ min: 1, max: 5000 }}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            const num = Number(value);
                                            if (value === '' || (!isNaN(num) && num >= 1 && num <= 5000)) {
                                                handleChangeThreshold("leadCaptureDays")(e);
                                            }
                                        }}
                                        error={!!formErrors.leadCaptureDays}
                                    />

                                    <FormHelperText className="important-fields">{formErrors.leadCaptureDays}</FormHelperText>
                                </Grid>

                                <Grid size={{ xs: 12, sm: 12, md: 6, lg: 4 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        {/* User Inactive Days when not logged in  30 days <span className="important-fields">*</span> */}
                                        User Inactive Days <span className="important-fields">*</span>
                                    </Typography>

                                    <TextField
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        placeholder="Enter Days"
                                        value={formValues.userInactivityDays}
                                        type="number"
                                        inputProps={{ min: 1, max: 5000 }}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            const num = Number(value);
                                            if (value === '' || (!isNaN(num) && num >= 1 && num <= 5000)) {
                                                handleChangeThreshold("userInactivityDays")(e);
                                            }
                                        }}
                                        error={!!formErrors.userInactivityDays}
                                    />

                                    <FormHelperText className="important-fields">{formErrors.userInactivityDays}</FormHelperText>
                                </Grid>

                                <Grid size={{ xs: 12, sm: 12, md: 6, lg: 4 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Reset Password Duration <span className="important-fields">*</span>
                                    </Typography>

                                    <TextField
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        placeholder="Enter Reset Password Duration"
                                        value={formValues.userPasswordExpiryDays}
                                        type="number"
                                        inputProps={{ min: 1, max: 5000 }}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            const num = Number(value);
                                            if (value === '' || (!isNaN(num) && num >= 1 && num <= 5000)) {
                                                handleChangeThreshold("userPasswordExpiryDays")(e);
                                            }
                                        }}
                                        error={!!formErrors.userPasswordExpiryDays}
                                    />

                                    <FormHelperText className="important-fields">{formErrors.userPasswordExpiryDays}</FormHelperText>
                                </Grid>

                                <Grid size={{ xs: 12, sm: 12, md: 6, lg: 4 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Lost Bucket Threshold - days <span className="important-fields">*</span>
                                    </Typography>

                                    <TextField
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        placeholder="Enter Days"
                                        value={formValues.lostBucketDays}
                                        type="number"
                                        inputProps={{ min: 1, max: 5000 }}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            const num = Number(value);
                                            if (value === '' || (!isNaN(num) && num >= 1 && num <= 5000)) {
                                                handleChangeThreshold("lostBucketDays")(e);
                                            }
                                        }}
                                        error={!!formErrors.lostBucketDays}
                                    />

                                    <FormHelperText className="important-fields">{formErrors.lostBucketDays}</FormHelperText>
                                </Grid>

                                <Grid size={{ xs: 12, sm: 12, md: 6, lg: 4 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Rollover Threshold - Year <span className="important-fields">*</span>
                                    </Typography>

                                    <TextField
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        placeholder="Enter Years"
                                        value={formValues.leadRolloverYear}
                                        type="number"
                                        inputProps={{ min: 1, max: 5000 }}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            const num = Number(value);
                                            if (value === '' || (!isNaN(num) && num >= 1 && num <= 5000)) {
                                                handleChangeThreshold("leadRolloverYear")(e);
                                            }
                                        }}
                                        error={!!formErrors.leadRolloverYear}
                                    />

                                    <FormHelperText className="important-fields">{formErrors.leadRolloverYear}</FormHelperText>
                                </Grid>

                                {/* <Grid size={4} item xs={12} md={4}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Communication configuration <span className="important-fields">*</span>
                                    </Typography>

                                    <TextField
                                        className='form-control-input border-radius-8'
                                        size="small"
                                        fullWidth
                                        required
                                        placeholder="Enter Reset Password Duration"
                                        value={formValues.resetPassword}
                                        type="number"
                                        inputProps={{ min: 1, max: 5000 }}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            const num = Number(value);
                                            if (value === '' || (!isNaN(num) && num >= 1 && num <= 5000)) {
                                                handleChangeThreshold("resetPassword")(e);
                                            }
                                        }}
                                        error={!!formErrors.resetPassword}
                                    />

                                    <FormHelperText className="important-fields">{formErrors.resetPassword}</FormHelperText>
                                </Grid> */}

                            </Grid>
                            <Button
                                disabled={loading}
                                sx={{ ml: "auto", mt: 2, display: "flex", justifyContent: "end" }} className="btn-common-red" onClick={handleSubmitThreshold}>
                                Submit
                            </Button>
                        </AccordionDetails>
                    </Accordion>}
            </Paper>

            <ToastContainer autoClose={1000} />

            <AddItemModal
                open={openModal}
                onClose={handleCloseModal}
                onSubmit={handleModalSubmit}
                title={modalConfig.title}
                fields={modalConfig.fields}
            />
        </>
    );
};

export default SystemConfiguration;