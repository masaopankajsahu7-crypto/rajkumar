import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import NorthIcon from '@mui/icons-material/North';
import SouthIcon from '@mui/icons-material/South';
import { Box, Button, Card, Checkbox, Chip, FormControl, Grid, IconButton, InputLabel, MenuItem, Paper, Select, Skeleton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip, Typography, useMediaQuery } from '@mui/material';
import { ArcElement, BarController, Chart as ChartJS, DoughnutController, LineController, PieController, ScatterController } from 'chart.js';
import { useEffect, useRef, useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import downloadSvg from "../assets/images/bulkDowload.svg";
import dateFilter from "../assets/images/dashboard/dateFilter.svg";
import leadsBreach from '../assets/images/leadsBreach.svg';
import leadsBreachToday from '../assets/images/leadsBreachToday.svg';
import usermanagement from '../assets/images/sidenavbar/usermanagement.svg';
import sorting from '../assets/images/sorting.svg';
import hotSvg from "../assets/images/tat/hot.svg";
import InfoSvg from "../assets/images/tat/info.svg";
import warninSvg from "../assets/images/tat/warning.svg";
import tatImg from "../assets/images/tatImg.svg";
import CustomDateRange from "../components/DateRange/CustomDateRange";
import BackdropLoader from "../components/Loader/BackdropLoader";
import { downloadTATExcel, fetchTaTData, filterTaTData } from "../services/api";
import { encryptRoute } from "../services/encrypt";
import { btnRed } from '../utils/Colors';

ChartJS.register(ArcElement, LineController, BarController, PieController, ScatterController, DoughnutController);

const TATMonitoring = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const userDetails = useSelector((state) => state.user.loggedData);
    const userBymanager = useSelector((state) => state.user.fetchUserByManager);
    const [dealerSearchText, setDealerSearchText] = useState("");

    const [agentPerformance, setAgentPerformance] = useState([])
    const [teamLeadPerformance, setTeamLeadPerformance] = useState([]);

    const [renewalList, setRenewalcategory] = useState([])
    const [teamData, setTeamData] = useState([])
    const [zoneList, setZoneList] = useState([])
    const [stateList, setStateList] = useState([])
    const [dealerList, setDealerList] = useState([])
    const [sortField, setSortField] = useState("");
    const [sortOrder, setSortOrder] = useState("asc");

    const [followUpComp, setFollowUpComp] = useState({
        Name: "",
        FollowUpCompliance: 0,
        FollowUpNonCompliance: 0,
        totalLeadsContacted: 0,
        totalLeadsBreached: 0
    });

    const [leadsBreached, setLeadsBreached] = useState({
        Name: "",
        totalLeadsBreached: 0,
        totalLeadsBreachedToday: 0
    });

    const [leadsByCat, setLeadsByCat] = useState({
        Name: "",
        hotBreachedCases: 0,
        warmBreachedCases: 0
    });

    const [escalationSummary, setEscalationSummary] = useState([]);

    const compliance = followUpComp?.FollowUpCompliance || 0;
    const nonCompliance = followUpComp?.FollowUpNonCompliance || 0;

    const isEmpty = compliance === 0 && nonCompliance === 0;

    const data = {
        datasets: [
            {
                data: isEmpty ? [1] : [compliance, nonCompliance],
                backgroundColor: isEmpty ? ["#e5e7eb"] : ["#16a34a", "#d1d5db"],
                borderWidth: 0,
                cutout: "55%",
            },
        ],
    };

    const chartOptions = {
        plugins: {
            legend: { display: false },
            tooltip: { enabled: false },
        },
    };

    const navigate = useNavigate();
    const [selectedZones, setselectedZones] = useState([]);
    const [selectedStates, setselectedStates] = useState([]);
    const [selectedDealers, setselectedDealers] = useState([]);
    const [selectedBranches, setselectedBranches] = useState([]);
    const [open, setOpen] = useState(false);
    const anchorRef = useRef(null);
    const [dateSelected, setDateSelected] = useState();

    const [stateSelectionOpen, setStateSelectionOpen] = useState(false);
    const [zoneSelectOpen, setZoneSelectOpen] = useState(false);
    const [dealerSelectOpen, setDealerSelectOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    // Filter dealer list by search
    const filteredDealers = dealerList?.filter((d) =>
        d?.dealer_name?.toLowerCase()?.includes(dealerSearchText?.toLowerCase())
    );

    // for Renewal category
    const [selectedRenewals, setSelectedRenewals] = useState([]);
    const [renewalSelectOpen, setRenewalSelectOpen] = useState(false);

    // for renewal
    const handleRenewalToggle = (renewal) => {
        if (renewal === "all") {
            if (selectedRenewals.length === renewalList.length) {
                setSelectedRenewals([]);
            } else {
                setSelectedRenewals(renewalList?.map((item) => item.id));
            }
        } else {
            const currentIndex = selectedRenewals.indexOf(renewal);
            const newSelected = [...selectedRenewals];

            if (currentIndex === -1) {
                newSelected.push(renewal);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setSelectedRenewals(newSelected);
        }
    };

    // for zone 
    const handleZoneChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList?.map(zone => zone.Zone));
            }
        } else {
            setselectedZones(value);
        }
    };
    const handleZoneToggle = (zone) => {
        if (zone === 'all') {
            if (selectedZones.length === zoneList.length) {
                setselectedZones([]);
            } else {
                setselectedZones(zoneList?.map(zone => zone.Zone));
            }
        } else {
            const currentIndex = selectedZones.indexOf(zone);
            const newSelected = [...selectedZones];

            if (currentIndex === -1) {
                newSelected.push(zone);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedZones(newSelected);
        }
    };

    // for state 
    const handleStateChange = (event) => {
        const value = event.target.value;
        if (value.includes('all')) {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList?.map(data => data.State));
            }
        } else {
            setselectedStates(value);
        }
    };
    const handleStateToggle = (state) => {
        if (state === 'all') {
            if (selectedStates.length === stateList.length) {
                setselectedStates([]);
            } else {
                setselectedStates(stateList?.map(data => data.State));
            }
        } else {
            const currentIndex = selectedStates.indexOf(state);
            const newSelected = [...selectedStates];

            if (currentIndex === -1) {
                newSelected.push(state);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedStates(newSelected);
        }
    };

    // for dealer 
    const handleDealerToggle = (dealerId) => {
        if (dealerId === 'all') {
            if (selectedDealers.length === dealerList.length) {
                setselectedDealers([]);
            } else {
                setselectedDealers(dealerList?.map(data => data.dealer_id));
            }
        } else {
            const currentIndex = selectedDealers.indexOf(dealerId);
            const newSelected = [...selectedDealers];

            if (currentIndex === -1) {
                newSelected.push(dealerId);
            } else {
                newSelected.splice(currentIndex, 1);
            }

            setselectedDealers(newSelected);
        }
    };

    useEffect(() => {
        if (dateSelected && dateSelected !== "") {
            filterDashboard();
        }
    }, [dateSelected]);

    // team member state
    const [selectedSegments, setSelectedSegments] = useState([]);
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);

    const handleSegmentToggle = (id) => {
        if (id === "all") {
            if (selectedSegments.length === teamData.length) {
                setSelectedSegments([]);
            } else {
                setSelectedSegments(teamData?.map(t => t.teamMemberId));
            }
            return;
        }

        setSelectedSegments(prev =>
            prev.includes(id)
                ? prev.filter(item => item !== id)
                : [...prev, id]
        );
    };

    const filterDashboard = async (dateParam) => {
        if (!userDetails?.user_id) return;

        const date = dateParam !== undefined ? dateParam : dateSelected;

        try {
            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            let payload;

            if (userDetails?.roleType === "MIBL") {
                const isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedZones.length === 0 &&
                    selectedStates.length === 0 &&
                    selectedDealers.length === 0 && isDateEmpty;

                payload = {
                    loginUserId: userDetails?.user_id,
                    roleType: userDetails?.roleType,
                    type: isFilterEmpty ? "" : "tatDashboardfilter",
                    zone: selectedZones.join(","),
                    state: selectedStates.join(","),
                    dealerCode: selectedDealers.join(","),
                    dealer: selectedDealers.join(","),
                    fromDate: date?.startDate || "",
                    toDate: date?.endDate || "",
                    teamId: selectedSegments.join(","),
                    renewalCategory: selectedRenewalNames.join(","),
                    limit: 10,
                    offset: 1,
                };
            } else {
                const isFilterEmpty =
                    selectedRenewals.length === 0 &&
                    selectedSegments.length === 0 && isDateEmpty;

                payload = {
                    loginUserId: userDetails?.user_id,
                    roleType: userDetails?.roleType,
                    type: isFilterEmpty ? "" : "tatDashboardfilter",
                    dealerCode: userDetails?.dealerCode,
                    fromDate: date?.startDate || "",
                    toDate: date?.endDate || "",
                    teamId: selectedSegments.join(","),
                    renewalCategory: selectedRenewalNames.join(","),
                    limit: 10,
                    offset: 1,
                };
            }

            setLoading(true);

            const response = await filterTaTData(payload);

            if (response?.status_code === "200" || response?.status_message === "TAT filter dashboard details fetched") {

                const { result0, result1, result2, result3, result4, result6, result8, result9, result10, result11 } = response;
                setFollowUpComp(result0[0] || {});
                setLeadsBreached(result1[0] || {});
                setLeadsByCat(result2[0] || {});
                setEscalationSummary(result3 || []);
                setAgentPerformance(result4 || []);
                setTeamLeadPerformance(result6 || []);
                setRenewalcategory(result8 || []);
                if (userDetails?.roleType === "DEALER") {
                    setTeamData(result9 || []);
                }
                if (userDetails?.roleType === "MIBL") {
                    setZoneList(result9 || []);
                }
                setStateList(result10 || []);
                setDealerList(result11 || []);
            }

        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    const handleSort = (field) => {
        let order = "asc";

        if (sortField === field && sortOrder === "asc") {
            order = "desc";
        }

        setSortField(field);
        setSortOrder(order);

        // ✅ call API with updated values
        fetchDashboardData(field, order);
    };

    const fetchDashboardData = async (field = sortField, order = sortOrder) => {

        if (!userDetails?.user_id) return;

        try {
            const payload = {
                dealerCode: userDetails?.dealerCode || "",
                fromDate: "",
                toDate: "",
                type: "",
                limit: 10,
                offset: 1,
                roleType: userDetails?.roleType,
                loginUserId: userDetails?.user_id,
                searchName: "",
                sortField: field,
                sortOrder: order
            }

            setLoading(true);
            const response = await fetchTaTData(payload);

            if (response?.status_code === "200" || response?.status_message === "TAT Dashboard Details fetched") {
                const { result0, result1, result2, result3, result4, result6, result8, result9, result10, result11 } = response;
                setFollowUpComp(result0[0] || {});
                setLeadsBreached(result1[0] || {});
                setLeadsByCat(result2[0] || {});
                setEscalationSummary(result3 || []);
                setAgentPerformance(result4 || []);
                setTeamLeadPerformance(result6 || []);
                setRenewalcategory(result8 || []);
                if (userDetails?.roleType === "DEALER") {
                    setTeamData(result9 || []);
                }
                if (userDetails?.roleType === "MIBL") {
                    setZoneList(result9 || []);
                }
                setStateList(result10 || []);
                setDealerList(result11 || []);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (userDetails?.user_id) {
            fetchDashboardData();
        }
    }, [userDetails?.user_id]);

    const selectedRenewalNames = renewalList
        .filter((item) => selectedRenewals.includes(item.id))
        ?.map((item) => item.renewal_year);

    const [clearType, setClearType] = useState(null);

    useEffect(() => {
        if (clearType) {
            filterDashboard(dateSelected);
            setClearType(null);
        }
    }, [selectedRenewals, selectedZones, selectedStates, selectedDealers, selectedBranches, selectedSegments, clearType]);

    const handleClearFilters = (type) => {
        const resetters = {
            renewal: setSelectedRenewals,
            zone: setselectedZones,
            state: setselectedStates,
            dealer: setselectedDealers,
            branch: setselectedBranches,
            segment: setSelectedSegments,
        };

        if (resetters[type]) {
            resetters[type]([]);
            setClearType(type);
        }
    };

    const downloadExcelData = async (dateParam) => {
        const date = dateParam !== undefined ? dateParam : dateSelected;

        try {
            setLoading(true);

            const isDateEmpty =
                !date ||
                !date.startDate ||
                !date.endDate ||
                date.startDate === "Invalid Date" ||
                date.endDate === "Invalid Date";

            const isFiltered =
                selectedRenewals?.length ||
                selectedZones?.length ||
                selectedStates?.length ||
                selectedDealers?.length ||
                selectedSegments?.length || !isDateEmpty

            const payload = {
                roleType: userDetails?.roleType,
                type: isFiltered ? "downloadEscalationFilteredData" : "downloadEscalationData",
                loginUserId: userDetails?.user_id,
                ...(userDetails?.roleType === "DEALER" && {
                    dealerCode: userDetails?.dealerCode,
                }),
                ...(isFiltered && {
                    zone: selectedZones.join(",") || "",
                    state: selectedStates.join(",") || "",
                    dealerCode: userDetails?.dealerCode || "",
                    dealer: selectedDealers.join(",") || "",
                    teamId: selectedSegments.join(",") || "",
                    renewalCategory: selectedRenewalNames.join(",") || "",
                    fromDate: date?.startDate || "",
                    toDate: date?.endDate || ""
                })
            };

            const result = await downloadTATExcel(payload);

            if (result?.data) {
                const blob = new Blob([result.data], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                });

                const url = window.URL.createObjectURL(blob);
                const link = document.createElement("a");

                link.href = url;
                link.download = "Escalation_Summary.xlsx";

                document.body.appendChild(link);
                link.click();

                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error("Error downloading Excel file:", error);
        } finally {
            setLoading(false);
        }
    };

    const escalationMap = escalationSummary?.reduce((acc, item) => {
        acc[item.Name] = item.leadCount
        return acc
    }, {})

    return (
        <>
            <Paper className="body-formbg table-auto-width" elevation={0} sx={{ boxShadow: 'none' }}>
                <BackdropLoader loading={loading} />
                <Box py={isMobile ? 1.3 : 0.5} px={isMobile ? 1.5 : 2}>
                    <Box display={'flex'} flexWrap={"wrap"} justifyContent="space-between" alignItems="center" mb={isMobile ? 0 : 1.2} mt={isMobile ? 0 : 1}>
                        <Box display={'flex'} alignItems="center" justifyContent={"start"} mb={isMobile ? 0.5 : 0}>
                            <Typography px={isMobile ? 0 : 1} className={`${isMobile ? "fs-16" : "fs-20"} georama-SemiBold `} >Follow Up Efficiency Dashboard</Typography>
                        </Box>

                        <Box display="flex" gap={1} flexWrap={"wrap"}>
                            <FormControl
                                size="small"
                                sx={{
                                    width: 300,
                                    minWidth: 170,
                                    maxWidth: 170,
                                    backgroundColor: "#ffffff",
                                    borderRadius: 2,
                                }}
                            >
                                <InputLabel id="renewal-label" className="dropdown-label">
                                    Renewal Category
                                </InputLabel>

                                <Select
                                    className="georama-Medium"
                                    labelId="renewal-label"
                                    id="renewal-select"
                                    multiple
                                    value={selectedRenewals}
                                    label="Renewal Category"
                                    open={renewalSelectOpen}
                                    onClose={() => setRenewalSelectOpen(false)}
                                    onOpen={() => setRenewalSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === renewalList.length) return "All";

                                        return renewalList
                                            .filter((data) => selected.includes(data.id))
                                            ?.map((data) => data.renewal_year)
                                            .join(", ");
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                position: "fixed",
                                                zIndex: 1500,
                                            },
                                        },
                                    }}
                                >

                                    {/* All Option */}
                                    <MenuItem
                                        disableGutters
                                        sx={{ py: 0, px: 1, m: 0 }}
                                        value="all"
                                        onClick={() => handleRenewalToggle("all")}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                                "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                            }}
                                            checked={selectedRenewals.length === renewalList.length}
                                            indeterminate={
                                                selectedRenewals.length > 0 &&
                                                selectedRenewals.length < renewalList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    {/* Renewal Category List */}
                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: "auto",
                                            pr: 1,
                                        }}
                                    >
                                        {renewalList?.map((data) => (
                                            <MenuItem
                                                disableGutters
                                                sx={{ py: 0, px: 1, m: 0 }}
                                                key={data.id}
                                                value={data.id}
                                                onClick={() => handleRenewalToggle(data.id)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        "&.Mui-checked": { color: "#e53935" },
                                                    }}
                                                    checked={selectedRenewals.includes(data.id)}
                                                />
                                                {data.renewal_year}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    {/* Buttons */}
                                    <Box display={"flex"} gap={1} justifyContent={"end"}>
                                        <Button
                                        fullWidth
                                            size="small"
                                            onClick={() => {
                                                handleClearFilters("renewal");
                                                setRenewalSelectOpen(false);
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: "none",
                                                // px: 1,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: "transparent",
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button 
                                        fullWidth
                                            className="btn-common-red"
                                            size="small"
                                            sx={{
                                                mr: 1,
                                                my: 1,
                                                ...btnRed,
                                            }}
                                            onClick={() => {
                                                const selectedRenewalNames = renewalList
                                                    .filter((item) => selectedRenewals.includes(item.id))
                                                    ?.map((item) => item.renewal_year);

                                                filterDashboard();
                                                setRenewalSelectOpen(false);
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>

                                </Select>
                            </FormControl>

                            {userDetails.roleType === "DEALER" && userBymanager?.length > 0 && (
                                <FormControl
                                    size="small"
                                    sx={{
                                        width: 250,
                                        minWidth: 150,
                                        maxWidth: 150,
                                        backgroundColor: "#ffffff",
                                        borderRadius: 2,
                                    }}
                                >
                                    <InputLabel id="segment-label" className="dropdown-label">
                                        Team Member
                                    </InputLabel>

                                    <Select
                                        className="georama-Medium"
                                        labelId="segment-label"
                                        id="segment-select"
                                        multiple
                                        value={selectedSegments}
                                        label="Team Member"
                                        open={segmentSelectOpen}
                                        onClose={() => setSegmentSelectOpen(false)}
                                        onOpen={() => setSegmentSelectOpen(true)}

                                        renderValue={(selected) => {
                                            if (selected.length === teamData?.length) return "All";

                                            return teamData
                                                .filter((seg) => selected.includes(seg.teamMemberId))
                                                ?.map((seg) => seg.teamMemberName)
                                                .join(", ");
                                        }}

                                        MenuProps={{
                                            disableScrollLock: true,
                                            PaperProps: {
                                                style: {
                                                    position: "fixed",
                                                    zIndex: 1500,
                                                    scrollbarWidth: "thin",
                                                    scrollbarColor: "rgba(221,220,220,1) #faf3f3ff",
                                                },
                                                sx: {
                                                    "&::-webkit-scrollbar": {
                                                        width: "4px",
                                                    },
                                                    "&::-webkit-scrollbar-track": {
                                                        backgroundColor: "#f1f1f1",
                                                        borderRadius: "4px",
                                                    },
                                                    "&::-webkit-scrollbar-thumb": {
                                                        backgroundColor: "#d0cac9ff",
                                                        borderRadius: "4px",
                                                    },
                                                    "&::-webkit-scrollbar-thumb:hover": {
                                                        backgroundColor: "#d32f2f",
                                                    },
                                                },
                                            },
                                        }}
                                    >

                                        {/* ALL OPTION */}

                                        <MenuItem
                                            disableGutters
                                            sx={{ py: 0, px: 1 }}
                                            value="all"
                                            onClick={() => handleSegmentToggle("all")}
                                        >
                                            <Checkbox
                                                sx={{
                                                    "&.Mui-checked": { color: "#e53935" },
                                                    "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                }}
                                                checked={selectedSegments.length === teamData?.length}
                                                indeterminate={
                                                    selectedSegments.length > 0 &&
                                                    selectedSegments.length < teamData?.length
                                                }
                                            />

                                            All
                                        </MenuItem>


                                        {/* TEAM MEMBER LIST */}

                                        <Box
                                            sx={{
                                                maxHeight: 150,
                                                overflowY: "auto",
                                                pr: 1,
                                            }}
                                        >

                                            {teamData?.map((seg) => (
                                                <MenuItem
                                                    key={seg.teamMemberId}
                                                    disableGutters
                                                    sx={{ py: 0, px: 1 }}
                                                    value={seg.teamMemberId}
                                                    onClick={() => handleSegmentToggle(seg.teamMemberId)}
                                                >

                                                    <Checkbox
                                                        sx={{
                                                            "&.Mui-checked": { color: "#e53935" },
                                                        }}
                                                        checked={selectedSegments.includes(seg.teamMemberId)}
                                                    />

                                                    {seg.teamMemberName}

                                                </MenuItem>
                                            ))}

                                        </Box>


                                        {/* BUTTONS */}

                                        <Box display="flex" justifyContent="end">

                                            <Button
                                                fullWidth
                                                variant="contained"
                                                size="small"
                                                onClick={() => {
                                                    handleClearFilters("segment");
                                                    setSegmentSelectOpen(false);
                                                }}
                                                sx={{
                                                    border: "1px solid gray",
                                                    borderRadius: 8,
                                                    boxShadow: "none",
                                                    px: 1,
                                                    my: 1,
                                                    mx: 1,
                                                    color: "black",
                                                    backgroundColor: "transparent",
                                                }}
                                            >
                                                Clear
                                            </Button>

                                            <Button
                                                fullWidth
                                                className="btn-common-red"
                                                size="small"
                                                sx={{mr: 1.5, my: 1, ...btnRed }}
                                                onClick={() => {
                                                    filterDashboard();
                                                    setSegmentSelectOpen(false);
                                                }}
                                            >
                                                Apply
                                            </Button>

                                        </Box>

                                    </Select>
                                </FormControl>
                            )}

                            {userDetails.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel id="zone-label" className="dropdown-label">Zone</InputLabel>

                                <Select
                                    className='georama-Medium'
                                    labelId="zone-label"
                                    id="zone-select"
                                    multiple
                                    value={selectedZones}
                                    label="Zone"
                                    onChange={handleZoneChange}
                                    open={zoneSelectOpen}
                                    onClose={() => setZoneSelectOpen(false)}
                                    onOpen={() => setZoneSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === zoneList?.length) return "All";
                                        return zoneList
                                            .filter(zone => selected.includes(zone.Zone))
                                            ?.map(zone => zone.Zone)
                                            .join(',');
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                // maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                >
                                    <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                        onClick={() => handleZoneToggle('all')}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedZones.length === zoneList?.length}
                                            indeterminate={
                                                selectedZones.length > 0 &&
                                                selectedZones.length < zoneList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {zoneList && zoneList?.map((zone, index) => (
                                            <MenuItem
                                                className={selectedZones.includes(zone.Zone) ? 'georama- fs-14' : ''}
                                                disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={zone.Zone}
                                                onClick={() => handleZoneToggle(zone.Zone)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedZones.includes(zone.Zone)}
                                                />

                                                {zone.Zone}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            // disabled={selectedZones.length === 0}
                                            fullWidth
                                            size="small"
                                            onClick={() => {
                                                if (selectedZones.length > 0) {
                                                    handleClearFilters("zone");
                                                    setZoneSelectOpen(false);
                                                }
                                            }}
                                            sx={{
                                                width: "50%",
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            // disabled={selectedZones.length === 0}
                                            variant="contained"
                                            fullWidth
                                            className='btn-common-red'
                                            size="small"
                                            sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedZones.length > 0) {
                                                    filterDashboard();
                                                    setZoneSelectOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            {userDetails.roleType === "MIBL" && <FormControl className='' size="small" sx={{ minWidth: 100, maxWidth: 100, backgroundColor: '#ffffff', borderRadius: 2 }}>
                                <InputLabel id="state-label" className="dropdown-label">State</InputLabel>

                                <Select
                                    className='georama-Medium'
                                    labelId="state-label"
                                    id="state-select"
                                    multiple
                                    value={selectedStates}
                                    label="State"
                                    onChange={handleStateChange}
                                    open={stateSelectionOpen}
                                    onClose={() => setStateSelectionOpen(false)}
                                    onOpen={() => setStateSelectionOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === stateList?.length) return "All";
                                        return stateList
                                            .filter(data => selected.includes(data.State))
                                            ?.map(data => data.State)
                                            .join(',');
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                // maxHeight: 300,
                                                position: 'fixed',
                                                zIndex: 1500,
                                                scrollbarWidth: 'thin',
                                                scrollbarColor: 'rgba(221, 220, 220, 1) #faf3f3ff',
                                            },
                                            sx: {
                                                '&::-webkit-scrollbar': {
                                                    width: '4px',
                                                },
                                                '&::-webkit-scrollbar-track': {
                                                    backgroundColor: '#f1f1f1',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb': {
                                                    backgroundColor: '#d0cac9ff',
                                                    borderRadius: '4px',
                                                },
                                                '&::-webkit-scrollbar-thumb:hover': {
                                                    backgroundColor: '#d32f2f',
                                                },
                                            }
                                        },
                                        getContentAnchorEl: null,
                                    }}
                                >
                                    <MenuItem disableGutters sx={{ py: 0, px: 1, m: 0 }} value="all"
                                        onClick={() => handleStateToggle('all')}
                                    >
                                        <Checkbox
                                            sx={{
                                                '&.Mui-checked': { color: '#e53935' },
                                                '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                            }}
                                            checked={selectedStates.length === stateList?.length}
                                            indeterminate={
                                                selectedStates.length > 0 &&
                                                selectedStates.length < stateList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: 'auto',
                                            pr: 1,
                                        }}
                                    >
                                        {stateList && stateList?.map((data, index) => (
                                            <MenuItem
                                                className={selectedStates.includes(data.State) ? 'georama- fs-14' : ''}
                                                disableGutters sx={{ py: 0, px: 1, m: 0 }}
                                                key={index}
                                                value={data.State}
                                                onClick={() => handleStateToggle(data.State)}
                                            >
                                                <Checkbox
                                                    sx={{
                                                        '&.Mui-checked': { color: '#e53935' },
                                                        '&.MuiCheckbox-indeterminate': { color: '#e53935' },
                                                    }}
                                                    checked={selectedStates.includes(data.State)}
                                                />

                                                {data.State}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            // disabled={selectedStates.length === 0}
                                            size="small"
                                            fullWidth
                                            onClick={() => {
                                                if (selectedStates.length > 0) {
                                                    handleClearFilters("state");
                                                    setStateSelectionOpen(false);
                                                }
                                            }}
                                            sx={{
                                                width: "50%",
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className='btn-common-red'
                                            fullWidth
                                            // disabled={selectedStates.length === 0}
                                            size="small"
                                            sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedStates.length > 0) {
                                                    filterDashboard();
                                                    setStateSelectionOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            {userDetails.roleType === "MIBL" && <FormControl
                                size="small"
                                sx={{
                                    width: 300,
                                    minWidth: 100,
                                    maxWidth: 100,
                                    backgroundColor: "#ffffff",
                                    borderRadius: 2,
                                }}
                            >
                                <InputLabel id="dealer-label" className="dropdown-label">
                                    Dealer
                                </InputLabel>

                                <Select
                                    className="georama-Medium"
                                    labelId="dealer-label"
                                    id="dealer-select"
                                    multiple
                                    value={selectedDealers}
                                    label="Dealer"
                                    open={dealerSelectOpen}
                                    onClose={() => setDealerSelectOpen(false)}
                                    onOpen={() => setDealerSelectOpen(true)}
                                    renderValue={(selected) => {
                                        if (selected.length === dealerList?.length) return "All";
                                        return dealerList
                                            .filter((data) => selected.includes(data.dealer_id))
                                            ?.map((data) => data.dealer_name)
                                            .join(", ");
                                    }}
                                    MenuProps={{
                                        disableScrollLock: true,
                                        PaperProps: {
                                            style: {
                                                position: "fixed",
                                                zIndex: 1500,
                                                // width: 300,
                                            },
                                        },
                                    }}
                                >
                                    {/* 🔍 Search input (Autocomplete-like) */}
                                    <Box
                                        sx={{
                                            p: 1,
                                            position: "sticky",
                                            top: 0,
                                            background: "#fff",
                                            zIndex: 2,
                                        }}
                                    >
                                        <input
                                            type="text"
                                            placeholder="Search dealer..."
                                            value={dealerSearchText}
                                            onChange={(e) => setDealerSearchText(e.target.value)}
                                            onKeyDown={(e) => e.stopPropagation()}
                                            style={{
                                                width: "90%",
                                                padding: "6px 8px",
                                                borderRadius: "6px",
                                                border: "1px solid #ccc",
                                                fontSize: "13px",
                                            }}
                                        />
                                    </Box>

                                    {/* “All” Option */}
                                    <MenuItem
                                        disableGutters
                                        sx={{ py: 0, px: 1, m: 0 }}
                                        value="all"
                                        onClick={() => handleDealerToggle("all")}
                                    >
                                        <Checkbox
                                            sx={{
                                                "&.Mui-checked": { color: "#e53935" },
                                                "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                            }}
                                            checked={selectedDealers.length === dealerList?.length}
                                            indeterminate={
                                                selectedDealers.length > 0 &&
                                                selectedDealers.length < dealerList.length
                                            }
                                        />
                                        All
                                    </MenuItem>

                                    {/* Filtered Dealers */}
                                    <Box
                                        sx={{
                                            maxHeight: 150,
                                            overflowY: "auto",
                                            pr: 1,
                                        }}
                                    >
                                        {filteredDealers && filteredDealers.length > 0 ? (
                                            filteredDealers?.map((data, index) => (
                                                <MenuItem
                                                    disableGutters
                                                    sx={{ py: 0, px: 1, m: 0 }}
                                                    key={index}
                                                    value={data.dealer_id}
                                                    onClick={() => handleDealerToggle(data.dealer_id)}
                                                >
                                                    <Checkbox
                                                        sx={{
                                                            "&.Mui-checked": { color: "#e53935" },
                                                            "&.MuiCheckbox-indeterminate": { color: "#e53935" },
                                                        }}
                                                        checked={selectedDealers.includes(data.dealer_id)}
                                                    />
                                                    {data.dealer_name}
                                                </MenuItem>
                                            ))
                                        ) : (
                                            <MenuItem disabled>No results found</MenuItem>
                                        )}
                                    </Box>

                                    {/* Buttons */}
                                    <Box display={"flex"} justifyContent={"end"}>
                                        <Button
                                            fullWidth
                                            size="small"
                                            onClick={() => {
                                                if (selectedDealers.length > 0) {
                                                    handleClearFilters("dealer");
                                                    setDealerSelectOpen(false);
                                                    setDealerSearchText("");
                                                }
                                            }}
                                            sx={{
                                                width: "50%",
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: 'none',
                                                px: 1,
                                                my: 1,
                                                ml: 1,
                                                color: "black",
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className="btn-common-red"
                                            size="small"
                                            fullWidth
                                            sx={{ textAlign: "center", width: "50%", mx: 1, my: 1, ...btnRed }}
                                            onClick={() => {
                                                if (selectedDealers.length > 0) {
                                                    filterDashboard();
                                                    setDealerSelectOpen(false);
                                                    setDealerSearchText("");
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>
                                    </Box>
                                </Select>
                            </FormControl>}

                            <Box>
                                <Button className='bg-white text-gray text-capitalize border-light-gray border-radius-8' ref={anchorRef} onClick={() => setOpen(true)}>
                                    <img className='px-1' src={dateFilter} alt="" />

                                    <Typography className="dropdown-label" mt={0.5} px={1}>Date Range</Typography>
                                </Button>

                                <CustomDateRange
                                    open={open}
                                    anchorRef={anchorRef}
                                    setOpen={setOpen}
                                    setDate={setDateSelected}
                                    onChange={() => setDateSelected("")}
                                    clearDate={() => {
                                        setDateSelected("");
                                        setOpen(false);
                                        filterDashboard("");
                                    }}
                                />
                            </Box>
                        </Box>
                    </Box>
                </Box>

                <Box bgcolor={'#fff'} mx={isMobile ? 1.5 : 2} py={1.5} borderRadius={2}>
                    <Box display={'flex'} alignItems="center" justifyContent={"start"} gap={1} mx={3} mb={1.5}>
                        <img src={tatImg} alt="" />
                        <Typography className={`georama-SemiBold ${isMobile ? 'fs-12' : 'fs-16'}`}>Follow-Up Monitoring</Typography>
                    </Box>

                    <Box borderTop={"1px solid #F0F1F5"}></Box>

                    {/* Tat Monitoring Cards */}
                    <Grid mx={isMobile ? 1 : 2} mt={2} container spacing={isMobile ? 1 : 2.5}>
                        <Grid size={{ xs: 12, sm: 6, md: 6, lg: 3 }} p={1} className="border-light-gray border-radius-8">
                            {/* <Box sx={{ width: isMobile ? 45 : 60, height: isMobile ? 45 : 40, ml: 1 }}>
                            <Doughnut data={data} options={chartOptions} />
                        </Box> */}
                            <Box display="flex" alignItems="center" justifyContent="space-between">
                                <Typography className={`georama-SemiBold fw-600 ${isMobile ? 'fs-12' : 'fs-14'}`}>
                                    Follow-Up Compliance  <Tooltip title="(Complied Cases / Total Assigned Leads) x 100 " arrow>
                                        <IconButton size="small" sx={{ color: "#565866" }}>
                                            <InfoOutlinedIcon fontSize="10px" />
                                        </IconButton>
                                    </Tooltip>
                                </Typography>
                            </Box>

                            <Grid container alignItems="center" mt={2}>
                                <Grid size={{ xs: 3, sm: 3, md: 3 }} mr={isMobile ? 1.5 : 0}>
                                    <Box
                                        sx={{
                                            width: isMobile ? 60 : 50,
                                            height: isMobile ? 60 : 50
                                        }}
                                    >
                                        <Doughnut data={data} options={chartOptions} />
                                    </Box>
                                </Grid>

                                <Grid size={{ xs: 8, sm: 9, md: 9 }}>
                                    <Box display={"flex"} pl={1} gap={1} justifyContent={"center"} alignItems={"center"} >
                                        <Box>
                                            <Typography className="fs-11 georama-Medium text-gray" >
                                                Follow-Up Compliance
                                            </Typography>
                                            <Typography className="fs-16 georama-semiBold fw-500" color="#00B26E">
                                                {compliance}%
                                            </Typography>
                                        </Box>

                                        <Box>
                                            <Typography className="fs-11 georama-Medium text-gray" >
                                                Follow-Up Non-Compliance
                                            </Typography>
                                            <Typography className="fs-16 text-gray georama-semiBold">
                                                {nonCompliance}%
                                            </Typography>
                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>

                            <Box mt={2}>
                                <Box
                                    display="flex"
                                    justifyContent="space-between"
                                    alignItems="center"
                                    mb={1}
                                >
                                    <Typography className="georama-Medium fs-12 text-gray">
                                        Total Assigned Leads
                                    </Typography>
                                    <Chip
                                        label={followUpComp?.totalLeadsContacted}
                                        size="small"
                                        className="nav-text fs-12 fw-500 text-dark"
                                        sx={{
                                            backgroundColor: "#DCDDE0",
                                        }}
                                    />
                                </Box>

                                <Box display="flex" justifyContent="space-between" alignItems="center">
                                    <Typography className="georama-Medium fs-12 text-gray">
                                        Breached Leads
                                    </Typography>
                                    <Chip
                                        label={followUpComp?.totalLeadsBreached}
                                        size="small"
                                        className="georama-Medium fs-12 fw-500 text-dark"
                                        sx={{
                                            backgroundColor: "#DCDDE0",
                                        }}
                                    />
                                </Box>
                            </Box>
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6, md: 6, lg: 3 }} p={1} className="border-light-gray border-radius-8" >
                            <Typography px={2} className={`georama-SemiBold fw-600 ${isMobile ? 'fs-12' : 'fs-14'}`} pt={0.7} >
                                Leads Breached
                            </Typography>
                            <Box display={"flex"}>
                                <Card className='lead-status-card2' sx={{ ml: 1.5, mr: 0.2, my: 1, border: '1px solid #F0F1F5', }}>
                                    <Box display={"flex"} justifyContent={"center"} flexWrap={"wrap"} alignItems={"center"} textAlign={"center"}>
                                        <Box display={"flex"} justifyContent={"center"}
                                            sx={{ bgcolor: "#FFEFDD", width: 25, height: 25, p: 1, borderRadius: 3 }}
                                        >
                                            <img
                                                src={leadsBreach}
                                                alt={'Leads Breached - Today'}
                                            />
                                        </Box>
                                        <Box sx={{ display: "flex", mt: 0.8, justifyContent: "center", alignItems: "center", flexWrap: "wrap", textAlign: "center" }}>
                                            <Typography sx={{ lineHeight: "15px" }} className={`georama-Medium text-gray ${isMobile ? 'fs-10' : 'fs-12'}`}>Total Leads Breached</Typography>
                                            <Typography textAlign={"center"} mt={0.5} className={`georama-semiBold ${isMobile ? 'fs-16' : 'fs-20'}`}>{leadsBreached?.totalLeadsBreached}</Typography>
                                        </Box>
                                    </Box>
                                </Card>
                                <Card className='lead-status-card2' sx={{ ml: 0.8, mr: 1.5, my: 1, border: '1px solid #F0F1F5', }}>
                                    <Box display={"flex"} justifyContent={"center"} flexWrap={"wrap"} alignItems={"center"} textAlign={"center"}>
                                        <Box display={"flex"} justifyContent={"center"}
                                            sx={{ bgcolor: "#FFE4E4", width: 25, height: 25, p: 1, borderRadius: 3 }}
                                        >
                                            <img
                                                src={leadsBreachToday}
                                                alt={'Leads Breached - Today'}
                                            />
                                        </Box>
                                        <Box sx={{ display: "flex", mt: 0.8, justifyContent: "center", alignItems: "center", flexWrap: "wrap", textAlign: "center" }}>
                                            <Typography sx={{ lineHeight: "15px" }} className={`georama-Medium text-gray ${isMobile ? 'fs-10' : 'fs-12'}`}>Leads Breached - Today</Typography>
                                            <Typography textAlign={"center"} mt={0.5} className={`georama-semiBold ${isMobile ? 'fs-16' : 'fs-20'}`}>{leadsBreached?.totalLeadsBreachedToday}</Typography>
                                        </Box>
                                    </Box>
                                </Card>
                            </Box>
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6, md: 6, lg: 3 }} p={1} className="border-light-gray border-radius-8" >
                            <Typography px={2} className={`georama-SemiBold fw-600 ${isMobile ? 'fs-12' : 'fs-14'}`} pt={0.7}>
                                Leads Breached By Category
                            </Typography>
                            <Box display={"flex"}>
                                <Card className='lead-status-card2' sx={{ ml: 1.5, mr: 0.8, my: 1, border: '1px solid #F0F1F5', }}>
                                    <Box display={"flex"} justifyContent={"center"} flexWrap={"wrap"} alignItems={"center"} textAlign={"center"}>
                                        <Box display={"flex"} justifyContent={"center"}
                                            sx={{ bgcolor: "#FFE4E4", width: 25, height: 25, p: 1, borderRadius: 3 }}
                                        >
                                            <img
                                                src={leadsBreachToday}
                                                alt={'Leads Breached - Today'}
                                            />
                                        </Box>
                                        <Box sx={{ display: "flex", mt: 0.8, justifyContent: "center", alignItems: "center", flexWrap: "wrap", textAlign: "center" }}>
                                            <Typography sx={{ lineHeight: "15px" }} className={`georama-Medium text-gray ${isMobile ? 'fs-10' : 'fs-12'}`}>Hot Breached Cases</Typography>
                                            <Typography textAlign={"center"} mt={0.5} className={`georama-semiBold ${isMobile ? 'fs-16' : 'fs-20'}`}>{leadsByCat?.hotBreached || 0}</Typography>
                                        </Box>
                                    </Box>
                                </Card>
                                <Card className='lead-status-card2' sx={{ ml: 0.8, mr: 1.5, my: 1, border: '1px solid #F0F1F5', }}>
                                    <Box display={"flex"} justifyContent={"center"} flexWrap={"wrap"} alignItems={"center"} textAlign={"center"}>
                                        <Box display={"flex"} justifyContent={"center"}
                                            sx={{ bgcolor: "#FFEFDD", width: 25, height: 25, p: 1, borderRadius: 3 }}
                                        >
                                            <img
                                                src={leadsBreach}
                                                alt={'Leads Breached - Today'}
                                            />
                                        </Box>
                                        <Box sx={{ display: "flex", mt: 0.8, justifyContent: "center", alignItems: "center", flexWrap: "wrap", textAlign: "center" }}>
                                            <Typography sx={{ lineHeight: "15px" }} className={`georama-Medium text-gray ${isMobile ? 'fs-10' : 'fs-12'}`}>Warm Breached Cases</Typography>
                                            <Typography textAlign={"center"} mt={0.5} className={`georama-semiBold ${isMobile ? 'fs-16' : 'fs-20'}`}>{leadsByCat?.warmBreached || 0}</Typography>
                                        </Box>
                                    </Box>
                                </Card>
                            </Box>
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6, md: 6, lg: 3 }} p={1} className="border-light-gray border-radius-8">
                            <Box display={"flex"} px={1} justifyContent={"space-between"}>
                                <Typography className={`georama-SemiBold fw-600 ${isMobile ? 'fs-12' : 'fs-14'}`} pt={0.5}>
                                    Escalation Summary
                                </Typography>
                                <Button
                                    sx={{ px: 0, py: 0 }}
                                    onClick={() => downloadExcelData(dateSelected)}
                                    className="btn-common-red-sm"
                                >
                                    <img className="pr-2" src={downloadSvg} alt="" />
                                    Excel
                                </Button>
                            </Box>
                            <Card className='lead-status-card3' sx={{ py: isMobile ? 1 : 0 }}>
                                <Box display={"flex"} justifyContent={"space-around"} mt={1.5} gap={isMobile ? 1 : 0}>
                                    <Box
                                        sx={{
                                            height: "90px", bgcolor: '#FFFCF3', justifyContent: "center",
                                            alignItems: "center", border: "1px solid #FFF8E1", textAlign: 'center',
                                            pt: isMobile ? 2.5 : 3, pb: isMobile ? 1 : 2, px: isMobile ? 1.8 : 1, width: "22%", borderRadius: 3
                                        }}
                                        className={'dashboard-pink'}>
                                        <img src={InfoSvg} alt="" />
                                        <Typography className="georama-Medium fs-12" sx={{ color: "#E9B100", display: 'block' }}>Level 1</Typography>
                                        <Typography className="georama-semiBold fs-18" sx={{ color: "#E9B100", display: 'block' }}>{escalationMap?.["Level 1"] || 0}</Typography>
                                    </Box>
                                    <Box
                                        sx={{
                                            bgcolor: '#FFF9F5', border: "1px solid #FFEDE0", justifyContent: "center",
                                            alignItems: "center", textAlign: 'center',
                                            pt: isMobile ? 2.5 : 3, pb: isMobile ? 1 : 2, px: isMobile ? 1.8 : 1, width: "22%", borderRadius: 3
                                        }}
                                        className={'dashboard-pink'}>
                                        <img src={warninSvg} alt="" />
                                        <Typography className="georama-Medium fs-12" sx={{ color: '#F97109', display: 'block' }}>Level 2</Typography>
                                        <Typography className="georama-semiBold fs-18" sx={{ color: '#F97109', display: 'block' }}>{escalationMap?.["Level 2"] || 0}</Typography>
                                    </Box>
                                    <Box
                                        sx={{
                                            bgcolor: '#FFF0F0', border: "1px solid FFE1E1", justifyContent: "center",
                                            alignItems: "center", textAlign: 'center',
                                            pt: isMobile ? 2.5 : 3, pb: isMobile ? 1 : 2, px: isMobile ? 1.8 : 1, width: "22%", borderRadius: 3
                                        }}
                                        className={'dashboard-pink'}>
                                        <img src={hotSvg} alt="" />
                                        <Typography className="georama-Medium fs-12" sx={{ color: "#F22222", display: 'block' }}>Level 3</Typography>
                                        <Typography className="georama-semiBold fs-18" sx={{ color: '#F22222', display: 'block' }}>{escalationMap?.["Level 3"] || 0}</Typography>
                                    </Box>
                                </Box>
                            </Card>
                        </Grid>
                    </Grid>
                </Box>

                {/*  ----------------  Tables -----------------------------  */}
                <Grid container mx={isMobile ? 0 : 1} py={isMobile ? 0 : 1}>
                    <Grid size={{ xs: 12, sm: 12, md: 5 }}>
                        <Paper className="table-auto-width" sx={{ border: "1px solid #F0F1F5", mt: isMobile ? 0 : 1, mb: 1.5, mx: isMobile ? 1.5 : 1, borderRadius: 2, boxShadow: "none" }}>
                            <Box px={2} pt={1} display='flex' alignItems="center" justifyContent="space-between">
                                <Typography display={"flex"} gap={0.8} alignItems={"center"} className={`${isMobile ? 'fs-12' : 'fs-16'} georama-SemiBold`}>
                                    <img src={tatImg} alt="" />
                                    {userDetails?.roleType === "MIBL" ? "Dealer" : "Agent"}-Wise Follow-Up Performance
                                </Typography>
                                <Button className={`${isMobile ? 'fs-12' : 'fs-16'} highlight-red text-capitalize`}
                                    onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/tatMonitoring/tatviewAll'))}`, { state: { type: "dealerWise" } })}>
                                    View All
                                </Button>
                            </Box>

                            <TableContainer component={Box} sx={{ mt: 0.5, minHeight: 280, maxHeight: 280, overflow: "auto" }}>
                                <Table stickyHeader sx={{ tableLayout: 'auto', width: '100%' }}>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell
                                                className={`${isMobile ? 'fs-12 p-2' : 'fs-13 p-0'} georama-Regular text-gray light-bg fw-none tat-table-ht`}
                                            >
                                                {userDetails?.roleType === "MIBL" ? "Dealer Name" : "Agent Name"}
                                            </TableCell>

                                            <TableCell
                                                className={`${isMobile ? 'fs-12 p-2' : 'fs-13 p-0'} georama-Regular text-gray light-bg fw-none tat-table-ht`}
                                            >
                                                Follow-Up Compliance (%)
                                            </TableCell>

                                            <TableCell
                                                className={`${isMobile ? 'fs-12 p-2' : 'fs-13 p-0'} georama-Regular text-gray light-bg fw-none tat-table-ht`}
                                            >
                                                Total Leads Assigned
                                                {/* Contacted */}
                                            </TableCell>

                                            <TableCell
                                                className={`${isMobile ? 'fs-12 p-2' : 'fs-13 p-0'} georama-Regular text-gray light-bg fw-none tat-table-ht`}
                                            >
                                                Total Leads Breached
                                            </TableCell>
                                        </TableRow>
                                    </TableHead>

                                    <TableBody className="table-body-bg">
                                        {loading ? (
                                            [...Array(8)].map((_, idx) => (
                                                <TableRow key={idx}>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                </TableRow>
                                            ))) : (agentPerformance && agentPerformance.length > 0 ? (
                                                agentPerformance?.map((agent, index) => (
                                                    <TableRow key={index} sx={{ "&:hover": { backgroundColor: "#f5f5f5" } }}>
                                                        <TableCell className="p-1">
                                                            <span className={`georama-Medium ${isMobile ? 'fs-12' : 'fs-13'} text-truncate`}>
                                                                {agent?.agentName}
                                                            </span>
                                                        </TableCell>

                                                        <TableCell className={`p-1 georama-Regular ${isMobile ? 'fs-12' : 'fs-13'}`}>
                                                            {agent?.percentage}%
                                                        </TableCell>

                                                        <TableCell className={`p-1 georama-Regular ${isMobile ? 'fs-12' : 'fs-13'}`}>
                                                            {agent?.totalLeadsContacted}
                                                        </TableCell>

                                                        <TableCell className={`p-1 georama-Regular ${isMobile ? 'fs-12' : 'fs-13'}`}>
                                                            {agent?.totalLeadsBreached}
                                                        </TableCell>
                                                    </TableRow>
                                                ))
                                            ) : (!agentPerformance || !agentPerformance?.length) && !loading && (
                                                <TableRow>
                                                    <TableCell colSpan={4} align="center" sx={{ py: 3 }}>
                                                        No data found
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Paper>
                    </Grid>
                    <Grid size={{ xs: 12, sm: 12, md: 7 }}>
                        <Paper className="table-auto-width" sx={{ mt: isMobile ? 0 : 1, mb: 1.5, mx: isMobile ? 1.5 : 1, borderRadius: 2, boxShadow: "none" }}>
                            <Box px={2} pt={1} display='flex' alignItems="center" justifyContent="space-between">
                                <Typography display={"flex"} gap={0.8} alignItems={"center"} className={`${isMobile ? 'fs-12' : 'fs-16'} georama-SemiBold`}>
                                    <img src={usermanagement} alt="" />
                                    Follow-ups Pending
                                </Typography>
                                <Button className={`${isMobile ? 'fs-12' : 'fs-16'} highlight-red text-capitalize`}
                                    onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/tatMonitoring/teamleadviewAll'))}`)}>
                                    View All
                                </Button>
                            </Box>

                            <TableContainer component={Box} sx={{ mt: 0.5, minHeight: 280, maxHeight: 280, overflow: "auto" }}>
                                <Table stickyHeader sx={{
                                    borderCollapse: 'separate',
                                    borderSpacing: '0px 4px',
                                    tableLayout: 'auto',
                                    width: '100%'
                                }}>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell
                                                className={`${isMobile ? 'fs-12 p-3' : 'fs-13 p-1'} text-gray georama-Regular light-bg fw-none tat-table-ht`}
                                            >
                                                Customer Name
                                            </TableCell>

                                            <TableCell
                                                className={`${isMobile ? 'fs-12 p-3' : 'fs-13 p-1'} text-gray georama-Regular light-bg fw-none tat-table-ht`}
                                            >
                                                Agent Name
                                            </TableCell>
                                            {userDetails?.roleType === "MIBL" && <TableCell
                                                className={`${isMobile ? 'fs-12 p-3' : 'fs-13 p-1'} text-gray georama-Regular light-bg fw-none tat-table-ht`}
                                            >
                                                Dealer Name
                                            </TableCell>}

                                            <TableCell
                                                className={`${isMobile ? 'fs-12 p-3' : 'fs-13 p-1'} text-gray georama-Regular light-bg fw-none tat-table-ht`}
                                            >
                                                Renewal Category
                                            </TableCell>
                                            <TableCell
                                                className={`${isMobile ? 'fs-12 p-3' : 'fs-13 p-1'} text-gray georama-Regular light-bg fw-none tat-table-ht`}
                                            >
                                                <Box display="flex" alignItems="center" gap={1}>
                                                    Expiry Date

                                                    {/* ✅ No sort applied */}
                                                    {sortField !== "expiryDate" && (
                                                        <img
                                                            src={sorting}
                                                            alt="sort"
                                                            onClick={() => handleSort("expiryDate")}
                                                            style={{ cursor: "pointer", width: 14 }}
                                                        />
                                                    )}

                                                    {/* ✅ Asc */}
                                                    {sortField === "expiryDate" && sortOrder === "asc" && (
                                                        <NorthIcon
                                                            fontSize="small"
                                                            onClick={() => handleSort("expiryDate")}
                                                            style={{ cursor: "pointer" }}
                                                        />
                                                    )}

                                                    {/* ✅ Desc */}
                                                    {sortField === "expiryDate" && sortOrder === "desc" && (
                                                        <SouthIcon
                                                            fontSize="small"
                                                            onClick={() => handleSort("expiryDate")}
                                                            style={{ cursor: "pointer" }}
                                                        />
                                                    )}
                                                </Box>
                                            </TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody className="table-body-bg">
                                        {loading ? (
                                            [...Array(8)].map((_, idx) => (
                                                <TableRow key={idx}>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                    <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                                </TableRow>
                                            ))) : (teamLeadPerformance && teamLeadPerformance.length > 0 ? (
                                                teamLeadPerformance?.map((lead, index) => (
                                                    <TableRow
                                                        key={index}
                                                        sx={{
                                                            px: 2,
                                                            '& td': {
                                                                borderTop: '1px solid #e3e3eb',
                                                                borderBottom: '1px solid #e3e3eb',
                                                                backgroundColor: '#fff',
                                                            },
                                                            '& td:first-of-type': {
                                                                mx: 2,
                                                                borderTopLeftRadius: '8px',
                                                                borderBottomLeftRadius: '8px',
                                                            },
                                                            '& td:last-of-type': {
                                                                pr: 2,
                                                                mr: 2,
                                                                borderTopRightRadius: '8px',
                                                                borderBottomRightRadius: '8px',
                                                            },
                                                            '&:hover td': {
                                                                backgroundColor: '#f5f5f5',
                                                            },
                                                            "&:hover": { backgroundColor: "#f5f5f5" }
                                                        }}
                                                    >
                                                        <TableCell
                                                            className={`custom-td-tat georama-Medium ${isMobile ? 'fs-12' : 'fs-12'} text-truncate`}
                                                            sx={{ borderLeft: lead?.leadType === "Hot" ? `6px solid #e53935` : lead?.leadType === "Warm" ? `6px solid #f07d2d` : `6px solid #1e88e5` }}
                                                        >
                                                            {lead?.customerName}
                                                            <br />
                                                            <span className="text-gray">Lead Id {lead?.leadId}</span>
                                                        </TableCell>

                                                        <TableCell className={`custom-td-tat georama-Regular ${isMobile ? 'fs-12' : 'fs-12'}`}>
                                                            {lead?.agentName}
                                                        </TableCell>

                                                        {userDetails?.roleType === "MIBL" && (
                                                            <TableCell sx={{ p: 0, border: 'none' }} className={`custom-td-tat georama-Regular ${isMobile ? 'fs-12' : 'fs-12'}`}>
                                                                {lead?.dealerName}
                                                            </TableCell>
                                                        )}

                                                        <TableCell sx={{ p: 0, border: 'none' }} className={`custom-td-tat georama-Regular ${isMobile ? 'fs-12' : 'fs-12'}`}>
                                                            {lead?.renewalCategory}
                                                        </TableCell>

                                                        <TableCell sx={{ p: 0, border: 'none' }} className={`custom-td-tat georama-Regular ${isMobile ? 'fs-12' : 'fs-12'}`}>
                                                            {lead?.expiryDate}
                                                            <br />
                                                            <span className="highlight-red">Exp Days {lead?.expiryDays}</span>
                                                        </TableCell>
                                                    </TableRow>
                                                ))
                                            ) : (!teamLeadPerformance || !teamLeadPerformance?.length) && !loading && (
                                                <TableRow>
                                                    <TableCell
                                                        colSpan={userDetails?.roleType === "MIBL" ? 5 : 4}
                                                        align="center"
                                                        sx={{ py: 3 }}
                                                    >
                                                        No data found
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Paper>
                    </Grid>
                </Grid>
                {/*  ----------------  Tables -----------------------------  */}
            </Paper >
        </>
    )
}

export default TATMonitoring