import DownloadIcon from "@mui/icons-material/Download";
import SignalCellularAltIcon from '@mui/icons-material/SignalCellularAlt';
import UploadIcon from '@mui/icons-material/Upload';
import { Box, Button, Chip, FormControl, Grid, InputLabel, MenuItem, Pagination, Paper, Select, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, Typography, useMediaQuery } from "@mui/material";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { toast } from 'react-toastify';
import editSvg from "../assets/images/target/edit.svg";
import notesSvg from "../assets/images/target/notes.svg";
import personSvg from "../assets/images/target/person.svg";
import savingSvg from "../assets/images/target/saving.svg";
import BackdropLoader from "../components/Loader/BackdropLoader";
import BulkTargetModal from "../modals/UploadTarget";
import ViewNotes from "../modals/ViewNotes";
import { downloadTargetData, fetchTargetDetails, fetchTargetDetailsById, insertTargetDetails, updateTargetDetailsById } from "../services/api";
import { encryptRoute } from "../services/encrypt";
import {
    Checkbox,
    ListItemText
} from "@mui/material";

const Target = () => {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const isTab = useMediaQuery('(min-width:626px) and (max-width:991px)');

    const navigate = useNavigate();
    const [periodType, setPeriodType] = useState("");
    const [year, setYear] = useState("");
    const [month, setMonth] = useState("");
    const userDetails = useSelector((state) => state.user.loggedData);
    const [loading, setLoading] = useState(false);
    const [targetPreview, setTargetPreview] = useState([]);
    const [tab, setTab] = useState(0);
    const [clearBulkModalvalues, setclearBulkModalvalues] = useState(false);
    const [paginationCount, setPaginationCount] = useState(0);
    const [limit, setLimit] = useState(10);
    const [count, setCount] = useState(0);
    const [page, setPage] = useState(1);
    const [totalvalue, setTotalvalue] = useState(0);
    const [assigneesCount, setAssigneesCount] = useState(0);
    const [openNotesModal, setOpenNotesModal] = useState(false);
    const [selectedNotes, setSelectedNotes] = useState({});
    const [openbulkmodal, setopenbulkmodal] = useState(false);
    const handleBulkOpen = () => setopenbulkmodal(true);
    // const featureAccess = useSelector((state) => state.user.featureAccess.find(f => f.Url && f.Url.startsWith('/target')).AccessName.split(', '));
    const featureAccess = ['Create', 'Edit'];

    const handleReset = () => {
        const nextPage = 1;
        const nextTab = 0;
        const nextAgent = "";
        const nextSearch = "";

        const didChange =
            page !== nextPage ||
            tab !== nextTab ||
            agent !== nextAgent ||
            search !== nextSearch;

        if (page !== nextPage) setPage(nextPage);
        if (tab !== nextTab) setTab(nextTab);
        if (agent !== nextAgent) setAgent(nextAgent);
        if (search !== nextSearch) {
            setSearch(nextSearch);
            // keep debouncedSearch in sync so fetch doesn't reuse old search term
            setDebouncedSearch(nextSearch);
        }

        // If nothing changed, manually refetch with the current computed payload.
        if (!didChange) {
            fetchTargetData(requestPayload);
        }
    }

    const handlebulkSubmit = () => {
        // fetchData();
    };

    const showMessageBulk = (msg, type = 'success') => {
        if (type === 'success') {
            toast.success(msg, { autoClose: 1000 });
            // setPage(1);
            // setSelectedRows([]);
            handleClear();
            handleReset();
        } else {
            toast.error(msg);
        }
    };

    const handleClosebulkmodal = () => {
        // fetchData();
        setopenbulkmodal(false);
        setclearBulkModalvalues(true);
    }

    const [formValues, setFormValues] = useState({
        teamMember: "",
        segment: "",
        kpi: "",
        bucket: "",
        targetValue: "",
        notes: "",

        // dropdown data
        teamMembers: [],
        segments: [],
        kpis: [],
        buckets: []
    });

    const [agent, setAgent] = useState("");
    const [search, setSearch] = useState("");
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const [isEdit, setIsEdit] = useState(false);
    const [editId, setEditId] = useState(null);

    const months = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December"
    ];

    const [selectedMonths, setSelectedMonths] = useState([]);

    const handleMonthChange = (value) => {
        if (value === "All") {
            if (selectedMonths.length === months.length) {
                setSelectedMonths([]);
            } else {
                setSelectedMonths(months);
            }
        } else {
            const updatedMonths = selectedMonths.includes(value)
                ? selectedMonths.filter(m => m !== value)
                : [...selectedMonths, value];

            setSelectedMonths(updatedMonths);
        }
    };

    const isFormValid =
        formValues.teamMember?.length > 0 &&
        formValues.segment?.length > 0 &&
        formValues.kpi &&
        formValues.bucket?.length > 0 &&
        formValues.targetValue &&
        year &&
        (
            periodType === "Yearly" ||
            (
                periodType === "Monthly" &&
                selectedMonths?.length > 0
            )
        );

    const handleChange = (field) => (e) => {
        setFormValues((prev) => ({
            ...prev,
            [field]: e.target.value
        }));
    };

    const handleClear = () => {
        setFormValues((prev) => ({
            ...prev,
            teamMember: "",
            segment: "",
            kpi: "",
            bucket: "",
            targetValue: "",
            notes: ""
        }));

        setYear("");
        setMonth("");
        setPeriodType("");
        setIsEdit(false);
        setEditId(null);
    };

    const selectedKpi = formValues.kpis.find(
        (item) => item === formValues.kpi
    );

    const getSymbol = () => {
        if (!selectedKpi) return "";

        if (selectedKpi.includes("%")) {
            return "%";
        }

        return "₹";
    };

    const handleEdit = async (row) => {
        setIsEdit(true);
        setEditId(row.id);

        await fetchTargetDetailsByIdApi(row.id);
    };

    const fetchTargetDetailsByIdApi = async (id) => {
        try {
            setLoading(true);

            const payload = {
                dealerCode: userDetails?.dealerCode,
                id: id,
                type: ""
            };

            const response = await fetchTargetDetailsById(payload);

            if (response?.status_code === "200") {
                const data = response?.result0?.[0];

                const mappedPeriodType =
                    data?.period_type === "MONTH" ? "Monthly" : "Yearly";

                setPeriodType(mappedPeriodType);
                setYear(data?.year || "");

                // MONTH ARRAY
                setSelectedMonths(
                    data?.month
                        ? String(data.month)
                            .split(",")
                            .map((m) => m.trim())
                            .filter(Boolean)
                        : []
                );

                setFormValues((prev) => ({
                    ...prev,
                    teamMember: data?.teamMember
                        ? data.teamMember
                            .split(",")
                            .map((id) => id.trim())
                            .filter(Boolean)
                        : [],
                    segment: data?.segment
                        ? String(data.segment)
                            .split(",")
                            .map((seg) => seg.trim())
                            .filter(Boolean)
                        : [],
                    kpi: data?.kpi || "",
                    bucket: data?.target_bucket
                        ? String(data.target_bucket)
                            .split(",")
                            .map((b) => b.trim())
                            .filter(Boolean)
                        : [],

                    targetValue: data?.target_value || "",
                    notes: data?.notes || ""
                }));

                // setMonth(data?.month || "");
                // setFormValues((prev) => ({
                //     ...prev,
                //     teamMember: data?.teamMember || "",
                //     segment: data?.segment || "",
                //     kpi: data?.kpi || "",
                //     bucket: data?.target_bucket || "",
                //     targetValue: data?.target_value || "",
                //     notes: data?.notes || ""
                // }));
            }

        } catch (err) {
            console.error("Error fetching by id:", err);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async () => {
        if (loading) return;
        try {
            const kpi = formValues.kpi;
            const value = Number(formValues.targetValue);

            if (kpi === "Conversion Ratio %" || kpi === "Retention Ratio %") {
                if (isNaN(value)) {
                    toast.error("Please enter a valid number", { autoClose: 2000 });
                    return;
                }

                if (value <= 0 || value > 100) {
                    toast.error("Percentage must be between 1 and 100", { autoClose: 2000 });
                    return;
                }

                if (value.toString().length > 3) {
                    toast.error("Percentage cannot exceed 3 digits", { autoClose: 2000 });
                    return;
                }
            }
            setLoading(true);

            const basePayload = {
                dealerCode: userDetails?.dealerCode,
                periodType: periodType === "Monthly" ? "MONTH" : "YEAR",
                year: Number(year),
                month: periodType === "Monthly" ? selectedMonths : [],
                teamMember: String(formValues.teamMember)
                    .split(",")
                    .filter(Boolean),
                segment: formValues.segment || [],
                targetBucket: formValues.bucket || [],
                kpi: formValues.kpi,
                targetValue: Number(formValues.targetValue),
                notes: formValues.notes?.trim() || "",
                createdBy: String(userDetails?.user_id),
                loginUserId: String(userDetails?.user_id)
            };

            let response;
            if (isEdit) {
                const updatePayload = [{
                    ...basePayload,
                    id: editId
                }];
                response = await updateTargetDetailsById(updatePayload);
            }
            else {
                const insertPayload = [basePayload];
                console.log("insertPayload == ", insertPayload);
                response = await insertTargetDetails(insertPayload);
            }

            if (response?.status_code === "200" || response?.status_message?.includes("success")) {
                toast.success(isEdit ? "Target updated successfully!" : "Target details saved successfully!", { autoClose: 1000 });
                handleClear();
                setIsEdit(false);
                setEditId(null);
                handleReset();
            } else {
                toast.error(response?.status_message || "Something went wrong", { autoClose: 1000 });
            }
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (periodType && !isEdit) {
            setYear("")
            setMonth("")
        }
    }, [periodType])

    const years = useMemo(() => {
        const currentYear = new Date().getFullYear();
        return Array.from({ length: 3 }, (_, i) => String(currentYear + i));
    }, []);

    const rows = targetPreview?.map((item) => {
        const isMonthly = item.period_type?.toUpperCase() === "MONTH";

        return {
            period: isMonthly ? "Monthly" : "Yearly",
            id: item.id,

            // 👇 sub text (Month Year OR Year)
            sub: isMonthly
                ? `${item.month} ${item.year}`
                : item.year,

            name: item.teamMember, // later you can map to name if needed
            segment: item.segment,
            kpi: item.kpi,
            bucket: item.target_bucket,
            value: Number(item.target_value).toLocaleString(),
            notes: item.notes || ""
        };
    });

    const downloadTargetExcel = async () => {
        try {
            setLoading(true);
            const payload = {
                type: agent ? "downloadTargetFilter" : "downloadTarget",
                dealerCode: userDetails?.dealerCode,
                userId: userDetails?.user_id,
                limit: 10,
                offset: page,
                periodType: getPeriodType(tab),
                searchName: search || "",
                teamId: agent || ""
            }

            const result = await downloadTargetData(payload);

            if (result?.data) {
                const blob = new Blob([result.data], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                });

                const url = window.URL.createObjectURL(blob);
                const link = document.createElement("a");

                link.href = url;
                link.download = "Target_Data.xlsx";

                document.body.appendChild(link);
                link.click();

                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error("Error downloading Excel file:", error);
        } finally {
            setLoading(false);
        }
    };

    const getPeriodType = (tab) => {
        switch (tab) {
            case 1: return "YEAR";
            case 2: return "MONTH";
            default: return "ALL";
        }
    };

    const requestPayload = useMemo(() => {
        if (!userDetails?.user_id) return null;

        return {
            dealerCode: userDetails?.dealerCode,
            userId: userDetails?.user_id,
            periodType: getPeriodType(tab),
            teamId: agent || "",
            type: agent ? "targetFilter" : "",
            searchName: debouncedSearch || "",
            limit: limit,
            offset: page
        };
    }, [agent, debouncedSearch, limit, page, tab, userDetails?.dealerCode, userDetails?.user_id]);

    const fetchTargetData = useCallback(async (payload) => {
        if (!payload) return;

        try {
            setLoading(true);

            const response = await fetchTargetDetails(payload);

            if (response?.status_code === "200" || response?.status_message === "Target planning data fetched successfully") {
                const { result0, result1, result2, result3, result4, result5, result6, result7 } = response;
                setTotalvalue(result6?.[0]?.totalValue || 0);

                setFormValues((prev) => ({
                    ...prev,
                    teamMembers: result0?.map((item) => ({
                        id: item.teamMemberId,
                        name: item.teamMemberName
                    })) || [],
                    segments: result1?.map((item) => item.segment) || [],
                    kpis: result2?.map((item) => item.kpi_name) || [],
                    buckets: result3?.map((item) => item.target_bucket_name) || []
                }));
                setTargetPreview(result4 || []);
                setPaginationCount(result5?.[0]?.total_count || 0);
                setAssigneesCount(result7?.[0]?.teamAssigneeCount || 0);
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    }, []);

    // Debounce only search input (typing)
    useEffect(() => {
        const delay = setTimeout(() => {
            setDebouncedSearch(search);
        }, 500);

        return () => clearTimeout(delay);
    }, [search]);

    // Single source of truth for fetching
    useEffect(() => {
        fetchTargetData(requestPayload);
    }, [fetchTargetData, requestPayload]);

    return (
        <>
            <BackdropLoader loading={loading} />

            <Paper className="body-formbg table-auto-width" elevation={0} sx={{ mx: 2, boxShadow: 'none' }}>
                {/* Header */}
                <Box display={"flex"} alignItems={"center"} justifyContent={"space-between"} my={1}>
                    <Typography className="georama-semiBold fs-20">
                        Target Planning
                    </Typography>
                    <Box>
                        {featureAccess.includes('Create') && <Button
                            sx={{ mr: 2 }}
                            // disabled={!rows.length}
                            onClick={handleBulkOpen}
                            startIcon={<UploadIcon />}
                            className="btn-common-red"
                        >
                            Upload Target
                        </Button>}
                        <Button
                            onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/viewCharts'))}`)}
                            startIcon={< SignalCellularAltIcon />}
                            className="violet-btn"
                        >
                            View Chart
                        </Button>
                    </Box>
                </Box>

                {(featureAccess.includes('Create') || (featureAccess.includes('Edit') && isEdit)) &&
                    <>
                        {/* Header Section */}
                        <Paper elevation={0} sx={{ p: 2, mb: 2, borderRadius: 2 }}>
                            <Typography mb={2}>Header</Typography>

                            <Grid container spacing={2}>
                                {/* Period Type */}
                                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Period Type <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        fullWidth
                                        className="form-control-input border-radius-8"
                                        size="small"
                                        disabled={isEdit}
                                    >
                                        <Select
                                            value={periodType || ""}
                                            onChange={(e) => setPeriodType(e.target.value)}
                                            displayEmpty
                                        >
                                            <MenuItem value="" disabled>Select</MenuItem>
                                            <MenuItem value="Monthly">Monthly</MenuItem>
                                            <MenuItem value="Yearly">Yearly</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>

                                {/* Year */}
                                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Year <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        fullWidth
                                        disabled={isEdit}
                                        className="form-control-input border-radius-8"
                                        size="small"
                                    >
                                        <Select
                                            value={year || ""}
                                            onChange={(e) => setYear(e.target.value)}
                                            displayEmpty
                                        >
                                            <MenuItem value="" disabled>Select</MenuItem>
                                            {years.map((y, i) => (
                                                <MenuItem key={i} value={y}>
                                                    {y}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>

                                {/* Month (Conditional) */}
                                {periodType === "Monthly" && (
                                    <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                        <Typography className='text-labels' mb={0.5}>
                                            Month <span className="important-fields">*</span>
                                        </Typography>

                                        <FormControl fullWidth size="small">
                                            <Select
                                                multiple
                                                displayEmpty
                                                value={selectedMonths}
                                                renderValue={(selected) => {
                                                    if (selected.length === 0) {
                                                        return "Select Month";
                                                    }

                                                    if (selected.length === months.length) {
                                                        return "All Selected";
                                                    }

                                                    return selected.join(", ");
                                                }}

                                                sx={{
                                                    backgroundColor: "#f0f1f5",
                                                    borderRadius: "8px",

                                                    "& .MuiOutlinedInput-notchedOutline": {
                                                        border: "none"
                                                    },

                                                    "&:hover .MuiOutlinedInput-notchedOutline": {
                                                        border: "none"
                                                    },

                                                    "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                                        border: "none"
                                                    }
                                                }}
                                                MenuProps={{
                                                    PaperProps: {
                                                        style: {
                                                            maxHeight: 300,
                                                            borderRadius: 8
                                                        }
                                                    }
                                                }}
                                            >
                                                {/* All Option */}
                                                <MenuItem
                                                    onClick={() => handleMonthChange("All")}
                                                    sx={{
                                                        py: 0,
                                                        px: 0.5
                                                    }}
                                                >
                                                    <Checkbox
                                                        checked={
                                                            selectedMonths.length === months.length
                                                        }
                                                        indeterminate={
                                                            selectedMonths.length > 0 &&
                                                            selectedMonths.length < months.length
                                                        }
                                                        sx={{
                                                            color: "#e31837",
                                                            "&.Mui-checked": {
                                                                color: "#e31837"
                                                            },
                                                            "&.MuiCheckbox-indeterminate": {
                                                                color: "#e31837"
                                                            }
                                                        }}
                                                    />

                                                    <ListItemText primary="All" sx={{
                                                        py: 0,
                                                        px: 0.5
                                                    }} />
                                                </MenuItem>

                                                {/* Month Options */}
                                                {months.map((m, i) => (
                                                    <MenuItem
                                                        sx={{
                                                            py: 0,
                                                            px: 0.5
                                                        }}
                                                        key={i}
                                                        onClick={() => handleMonthChange(m)}
                                                    >
                                                        <Checkbox
                                                            checked={selectedMonths.includes(m)}
                                                            sx={{
                                                                color: "#e31837",
                                                                "&.Mui-checked": {
                                                                    color: "#e31837"
                                                                }
                                                            }}
                                                        />

                                                        <ListItemText primary={m} sx={{
                                                            py: 0,
                                                            px: 0.5
                                                        }} />
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    </Grid>
                                )}
                            </Grid>
                        </Paper>

                        {/* Target Definition */}
                        <Paper elevation={0} sx={{ p: 2, borderRadius: 2 }}>
                            <Box display="flex" justifyContent="space-between" mb={2}>
                                <Typography>Target Definition</Typography>

                                {/* <Button variant="contained" size="small">
                                + Add New Target
                            </Button> */}
                            </Box>

                            <Grid container spacing={2}>
                                {/* Team Member */}
                                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Team Member <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        fullWidth
                                        className="form-control-input border-radius-8"
                                        size="small"
                                        disabled={isEdit}
                                    >
                                        <Select
                                            multiple
                                            value={formValues.teamMember || []}
                                            onChange={(e) => {
                                                const value = e.target.value;

                                                // Handle All Selection
                                                if (value.includes("All")) {
                                                    setFormValues((prev) => ({
                                                        ...prev,
                                                        teamMember:
                                                            prev.teamMember.length === prev.teamMembers.length
                                                                ? []
                                                                : prev.teamMembers.map((tm) => String(tm.id))
                                                    }));
                                                } else {
                                                    setFormValues((prev) => ({
                                                        ...prev,
                                                        teamMember: value
                                                    }));
                                                }
                                            }}
                                            displayEmpty
                                            renderValue={(selected) => {
                                                if (!selected || selected.length === 0) {
                                                    return "Select";
                                                }

                                                if (
                                                    selected.length ===
                                                    formValues.teamMembers.length
                                                ) {
                                                    return "All Selected";
                                                }

                                                return formValues.teamMembers
                                                    .filter((tm) => selected.includes(String(tm.id)))
                                                    .map((tm) => tm.name)
                                                    .join(", ");
                                            }}
                                            sx={{
                                                backgroundColor: "#f0f1f5",
                                                borderRadius: "8px",

                                                "& .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                },

                                                "&:hover .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                },

                                                "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                }
                                            }}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 250,
                                                        overflowY: "auto",
                                                        borderRadius: 8
                                                    },
                                                },
                                            }}
                                        >
                                            {/* All Option */}
                                            <MenuItem value="All"
                                                sx={{
                                                    py: 0,
                                                    px: 0.5
                                                }}>
                                                <Checkbox
                                                    checked={
                                                        formValues.teamMember.length ===
                                                        formValues.teamMembers.length
                                                    }
                                                    indeterminate={
                                                        formValues.teamMember.length > 0 &&
                                                        formValues.teamMember.length <
                                                        formValues.teamMembers.length
                                                    }
                                                    sx={{
                                                        color: "#e31837",

                                                        "&.Mui-checked": {
                                                            color: "#e31837"
                                                        },

                                                        "&.MuiCheckbox-indeterminate": {
                                                            color: "#e31837"
                                                        }
                                                    }}
                                                />

                                                <ListItemText primary="All" sx={{
                                                    py: 0,
                                                    px: 0.5
                                                }} />
                                            </MenuItem>

                                            {/* Team Member Options */}
                                            {formValues?.teamMembers?.map((tm, i) => (
                                                <MenuItem key={i} value={String(tm.id)} sx={{
                                                    py: 0,
                                                    px: 0.5
                                                }}>
                                                    <Checkbox
                                                        checked={formValues.teamMember.includes(String(tm.id))}
                                                        sx={{
                                                            color: "#e31837",
                                                            "&.Mui-checked": {
                                                                color: "#e31837"
                                                            }
                                                        }}
                                                    />

                                                    <ListItemText sx={{ py: 0, px: 0.5 }} primary={tm.name} />
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>

                                {/* Segment */}
                                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Segment <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        fullWidth
                                        className="form-control-input border-radius-8"
                                        size="small"
                                    >
                                        <Select
                                            multiple
                                            value={formValues.segment || []}
                                            onChange={(e) => {
                                                const value = e.target.value;

                                                // Handle "All"
                                                if (value.includes("All")) {
                                                    setFormValues((prev) => ({
                                                        ...prev,
                                                        segment:
                                                            prev.segment.length === prev.segments.length
                                                                ? []
                                                                : [...prev.segments]
                                                    }));
                                                } else {
                                                    setFormValues((prev) => ({
                                                        ...prev,
                                                        segment: value
                                                    }));
                                                }
                                            }}
                                            displayEmpty
                                            renderValue={(selected) => {
                                                if (!selected || selected.length === 0) {
                                                    return "Select";
                                                }

                                                if (selected.length === formValues.segments.length) {
                                                    return "All Selected";
                                                }

                                                return selected.join(", ");
                                            }}
                                            sx={{
                                                backgroundColor: "#f0f1f5",
                                                borderRadius: "8px",

                                                "& .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                },

                                                "&:hover .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                },

                                                "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                }
                                            }}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 250,
                                                        overflowY: "auto",
                                                        borderRadius: 8
                                                    },
                                                },
                                            }}
                                        >
                                            {/* All Option */}
                                            <MenuItem value="All"
                                                sx={{
                                                    py: 0,
                                                    px: 0.5
                                                }}>
                                                <Checkbox
                                                    checked={
                                                        formValues.segment.length ===
                                                        formValues.segments.length
                                                    }
                                                    indeterminate={
                                                        formValues.segment.length > 0 &&
                                                        formValues.segment.length <
                                                        formValues.segments.length
                                                    }
                                                    sx={{
                                                        color: "#e31837",
                                                        "&.Mui-checked": {
                                                            color: "#e31837"
                                                        },
                                                        "&.MuiCheckbox-indeterminate": {
                                                            color: "#e31837"
                                                        }
                                                    }}
                                                />

                                                <ListItemText primary="All" sx={{
                                                    py: 0,
                                                    px: 0.5
                                                }} />
                                            </MenuItem>

                                            {/* Segment Options */}
                                            {formValues?.segments?.map((seg, i) => (
                                                <MenuItem key={i} value={seg}
                                                    sx={{
                                                        py: 0,
                                                        px: 0.5
                                                    }}>
                                                    <Checkbox
                                                        checked={formValues.segment.includes(seg)}
                                                        sx={{
                                                            color: "#e31837",
                                                            "&.Mui-checked": {
                                                                color: "#e31837"
                                                            }
                                                        }}
                                                    />

                                                    <ListItemText sx={{
                                                        py: 0,
                                                        px: 0.5
                                                    }} primary={seg} />
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>

                                {/* KPI */}
                                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        KPI <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl fullWidth className="form-control-input border-radius-8" size="small" disabled={isEdit}>
                                        <Select
                                            value={formValues.kpi || ""}
                                            onChange={handleChange("kpi")}
                                            displayEmpty
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 250,
                                                        overflowY: "auto",
                                                    },
                                                },
                                            }}
                                        >
                                            <MenuItem value="" disabled>Select</MenuItem>
                                            {formValues?.kpis?.map((k, i) => (
                                                <MenuItem key={i} value={k}>{k}</MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>

                                {/* Target Bucket */}
                                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Target Bucket <span className="important-fields">*</span>
                                    </Typography>

                                    <FormControl
                                        fullWidth
                                        className="form-control-input border-radius-8"
                                        size="small"
                                    >
                                        <Select
                                            multiple
                                            value={formValues.bucket || []}
                                            onChange={(e) => {
                                                const value = e.target.value;

                                                const allBuckets = formValues.buckets.filter(
                                                    (b) => b !== "Total Renewal"
                                                );

                                                // If Total Renewal selected
                                                if (value.includes("Total Renewal")) {

                                                    // already all selected -> unselect all
                                                    const isAllSelected =
                                                        formValues.bucket.length === allBuckets.length;

                                                    setFormValues((prev) => ({
                                                        ...prev,
                                                        bucket: isAllSelected
                                                            ? []
                                                            : allBuckets
                                                    }));

                                                } else {

                                                    // normal selection
                                                    setFormValues((prev) => ({
                                                        ...prev,
                                                        bucket: value.filter(
                                                            (v) => v !== "Total Renewal"
                                                        )
                                                    }));
                                                }
                                            }}
                                            displayEmpty
                                            renderValue={(selected) => {

                                                if (!selected || selected.length === 0) {
                                                    return "Select";
                                                }

                                                const allBuckets = formValues.buckets.filter(
                                                    (b) => b !== "Total Renewal"
                                                );

                                                if (selected.length === allBuckets.length) {
                                                    return "Total Renewal";
                                                }

                                                return selected.join(", ");
                                            }}
                                            sx={{
                                                backgroundColor: "#f0f1f5",
                                                borderRadius: "8px",

                                                "& .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                },

                                                "&:hover .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                },

                                                "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                                    border: "none"
                                                }
                                            }}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 250,
                                                        overflowY: "auto",
                                                        borderRadius: 8
                                                    },
                                                },
                                            }}
                                        >
                                            {formValues?.buckets?.map((b, i) => {

                                                const allBuckets = formValues.buckets.filter(
                                                    (x) => x !== "Total Renewal"
                                                );

                                                const isAllSelected =
                                                    formValues.bucket.length === allBuckets.length;

                                                return (
                                                    <MenuItem
                                                        key={i}
                                                        value={b}
                                                        sx={{
                                                            py: 0,
                                                            px: 0.5
                                                        }}
                                                    >
                                                        <Checkbox
                                                            checked={
                                                                b === "Total Renewal"
                                                                    ? isAllSelected
                                                                    : formValues.bucket.includes(b)
                                                            }
                                                            indeterminate={
                                                                b === "Total Renewal" &&
                                                                formValues.bucket.length > 0 &&
                                                                formValues.bucket.length < allBuckets.length
                                                            }
                                                            sx={{
                                                                color: "#e31837",

                                                                "&.Mui-checked": {
                                                                    color: "#e31837"
                                                                },

                                                                "&.MuiCheckbox-indeterminate": {
                                                                    color: "#e31837"
                                                                }
                                                            }}
                                                        />

                                                        <ListItemText
                                                            primary={b}
                                                            sx={{
                                                                py: 0,
                                                                px: 0.5
                                                            }}
                                                        />
                                                    </MenuItem>
                                                );
                                            })}
                                        </Select>
                                    </FormControl>
                                </Grid>

                                {/* Target Value */}
                                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Target Value <span className="text-labels">{getSymbol() === "%" ? "(%)" : "(₹)"}</span> <span className="important-fields">*</span>
                                    </Typography>

                                    <TextField
                                        fullWidth
                                        size="small"
                                        type="number"
                                        value={formValues.targetValue || ""}
                                        onChange={(e) => {
                                            let value = e.target.value;

                                            // Allow empty
                                            if (value === "") {
                                                handleChange("targetValue")(e);
                                                return;
                                            }

                                            const numValue = Number(value);

                                            // ❌ Block negative values
                                            if (numValue < 0) return;

                                            // ✅ If %
                                            if (getSymbol() === "%") {
                                                // Limit 0–100 and max 3 digits
                                                if (numValue > 100 || value.length > 3) return;
                                            }

                                            // ✅ If ₹
                                            else {
                                                // Example: allow up to 100 crore (1000000000)
                                                if (numValue > 1000000000) return;

                                                // Optional length restriction
                                                if (value.length > 12) return;
                                            }

                                            handleChange("targetValue")(e);
                                        }}
                                        placeholder="Enter Target Value"
                                        className="form-control-input border-radius-8"
                                        inputProps={{
                                            min: 0,
                                            max: getSymbol() === "%" ? 100 : 1000000000,
                                        }}
                                    />
                                </Grid>

                                {/* Notes */}
                                <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                    <Typography className='text-labels' mb={0.5}>
                                        Notes
                                    </Typography>

                                    <TextField
                                        fullWidth
                                        size="small"
                                        value={formValues.notes || ""}
                                        onChange={handleChange("notes")}
                                        placeholder="Enter Notes"
                                        className="form-control-input border-radius-8"
                                    />
                                </Grid>

                                {/* Buttons */}
                                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                    <Box mt={3} display="flex" justifyContent="flex-end" gap={2}>
                                        <Button
                                            fullWidth
                                            className="gray-color-500 border-gray-color-500"
                                            onClick={handleClear}>
                                            Clear Form
                                        </Button>
                                        <Button
                                            fullWidth
                                            className="btn-common-red"
                                            disabled={!isFormValid || loading}
                                            sx={{
                                                opacity: !isFormValid || loading ? 0.5 : 1,
                                                pointerEvents:
                                                    !isFormValid || loading
                                                        ? "none"
                                                        : "auto"
                                            }}
                                            onClick={handleSubmit}
                                        >
                                            {isEdit ? "Update Target" : "Save to Submit"}
                                        </Button>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Paper>
                    </>
                }

                <Paper elevation={0} sx={{ my: 2, p: 2, borderRadius: 3, mb: 3 }}>
                    {/* Header */}
                    <Box
                        borderBottom={"1px solid #e5e7eb"}
                        display="flex"
                        flexWrap={"wrap"}
                        justifyContent="space-between"
                        alignItems="center"
                        pt={1}
                        pb={2}
                    >
                        {/* Left */}
                        <Typography fontWeight={600}>Targets Preview</Typography>

                        {/* Right */}
                        <Box display="flex" alignItems="center" flexWrap={"wrap"}>
                            <Box display="flex" alignItems="center" gap={1} px={isMobile ? 1 : 2} my={isMobile ? 0.8 : 0}>
                                <Box
                                    sx={{
                                        background: "#e0ecff",
                                        borderRadius: 2,
                                        padding: 1,
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center"
                                    }}
                                >
                                    <img src={savingSvg} alt="" />
                                </Box>
                                <Box>
                                    <Typography fontSize={12} color="gray">
                                        Total Value
                                    </Typography>
                                    <Typography fontWeight={600} fontSize={isMobile ? 12 : 14}>
                                        ₹ {totalvalue.toLocaleString("en-IN")}
                                    </Typography>
                                </Box>
                            </Box>

                            <Box sx={{ width: "1px !important", height: 30, background: "#e5e7eb" }} />

                            <Box display="flex" alignItems="center" gap={1} px={isMobile ? 1 : 2} my={isMobile ? 0.8 : 0}>
                                <Box
                                    sx={{
                                        background: "#fdebd0",
                                        borderRadius: 2,
                                        padding: 1,
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center"
                                    }}
                                >
                                    <img src={personSvg} alt="" />
                                </Box>
                                <Box>
                                    <Typography fontSize={12} color="gray">
                                        Assignees
                                    </Typography>
                                    <Typography fontWeight={600} fontSize={isMobile ? 12 : 14}>
                                        {assigneesCount || 0} Team Members
                                    </Typography>
                                </Box>
                            </Box>

                            <Box display={isMobile ? 'none' : ""} sx={{ width: "1px !important", height: 30, background: "#e5e7eb" }} />

                            <Button
                                fullWidth={isMobile}
                                sx={{ ml: 1.5 }}
                                onClick={downloadTargetExcel}
                                endIcon={<DownloadIcon />}
                                className="btn-common-red"
                            >
                                Download
                            </Button>
                        </Box>
                    </Box>

                    {/* Tabs + Filters */}
                    <Box display="flex" flexWrap={'wrap'} mt={2} mb={2}>
                        <Box width={isTab ? "100%" : isMobile ? "100%" : "80%"} display={isTab ? "flex" : "flex"} justifyContent={'space-between'} gap={2} alignItems="center">
                            <Tabs
                                value={tab}
                                onChange={(e, newValue) => {
                                    if (newValue === tab) return;
                                    setPage(1);
                                    setTab(newValue);
                                }}
                                sx={{
                                    minHeight: "auto",
                                    "& .MuiTabs-indicator": {
                                        backgroundColor: "#ef4444", // red underline
                                        height: 2.5
                                    }
                                }}
                            >
                                {["All", "Yearly", "Monthly"].map((label, i) => (
                                    <Tab
                                        key={i}
                                        label={label}
                                        disableRipple
                                        sx={{
                                            textTransform: "none",
                                            fontSize: isMobile ? 13 : 14,
                                            minHeight: "auto",
                                            px: isMobile ? 0 : 2,
                                            minWidth: isMobile ? "65px" : 100,
                                            color: "#6b7280", // gray
                                            "&.Mui-selected": {
                                                color: "#111827", // dark text
                                                fontWeight: 500
                                            }
                                        }}
                                    />
                                ))}
                            </Tabs>
                            <FormControl size="small"
                                sx={{
                                    minWidth: isMobile ? 90 : 120,
                                    "& .MuiOutlinedInput-root": {
                                        borderRadius: "4px", // 👈 rounded corners
                                        bgcolor: " #ffffff",
                                        "& fieldset": {
                                            borderColor: "#9698a3", // 👈 default border color
                                        },
                                        "&:hover fieldset": {
                                            borderColor: "#9698a3", // 👈 on hover
                                        },
                                        "&.Mui-focused fieldset": {
                                            borderColor: "#9698a3", // 👈 on focus (primary blue)
                                        },
                                        "&.Mui-focused.Mui-active fieldset": {
                                            borderColor: "#9698a3",
                                        },
                                    },
                                }}
                            >
                                <InputLabel id="agent-label">Agent</InputLabel>

                                <Select
                                    labelId="agent-label"
                                    value={agent || ""}
                                    label="Agent"
                                    onChange={(e) => {
                                        const next = e.target.value;
                                        if (next === agent) return;
                                        setPage(1);
                                        setAgent(next);
                                    }}
                                >
                                    <MenuItem value="">
                                        All Agents
                                    </MenuItem>

                                    {formValues.teamMembers?.map((tm) => (
                                        <MenuItem key={tm.id} value={String(tm.id)}>
                                            {tm.name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Box>

                        <Box width={isTab ? "100%" : isMobile ? "100%" : "20%"} display={"flex"} gap={2} alignItems="center">
                            <TextField
                                fullWidth
                                className="custom-textfield body-formbg"
                                sx={{
                                    mt: isMobile ? 1 : isTab ? 1 : isDesktop ? 0 : 0,
                                    ml: isTab ? 1 : isDesktop ? 2 : 0,
                                    width: isDesktop ? '22ch' : isTab ? '100%' : '100%',
                                    px: 2,
                                    '& .MuiOutlinedInput-root': {
                                        borderRadius: 3,
                                        '&.Mui-focused fieldset': {
                                            borderColor: 'black',
                                        },
                                    },
                                    float: 'right'
                                }}
                                size="small"
                                placeholder="Search"
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                            />
                        </Box>
                    </Box>

                    {/* Table */}
                    <TableContainer>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell>Time Period</TableCell>
                                    <TableCell>Team Member</TableCell>
                                    <TableCell>Segment</TableCell>
                                    <TableCell>KPI</TableCell>
                                    <TableCell>Target Bucket</TableCell>
                                    <TableCell>Target Value</TableCell>
                                    <TableCell>Notes</TableCell>
                                    {featureAccess.includes('Edit') && <TableCell align="center">Action</TableCell>}
                                </TableRow>
                            </TableHead>

                            <TableBody>
                                {rows.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={8} align="center">
                                            <Typography color="gray" py={2}>
                                                No Data Found
                                            </Typography>
                                        </TableCell>
                                    </TableRow>
                                ) : (rows.map((row, index) => (
                                    <TableRow key={index} hover>

                                        {/* Time Period */}
                                        <TableCell>
                                            <Chip
                                                label={row.period}
                                                size="small"
                                                sx={{
                                                    bgcolor: row.period === "Monthly" ? "#FFE8CC" : "#D6EAF8",
                                                    color: row.period === "Monthly" ? "#D97706" : "#2563EB",
                                                    mb: 0.5
                                                }}
                                            />
                                            <Typography fontSize={12} color="gray">
                                                {row.sub}
                                            </Typography>
                                        </TableCell>

                                        <TableCell>{row.name}</TableCell>
                                        <TableCell>{row.segment}</TableCell>
                                        <TableCell>{row.kpi}</TableCell>
                                        <TableCell>{row.bucket}</TableCell>
                                        <TableCell>
                                            {row.kpi === "Conversion Ratio %" || row.kpi === "Retention Ratio %"
                                                ? `${row.value}%`
                                                : `₹${row.value}`}
                                        </TableCell>
                                        <TableCell>
                                            <>
                                                <img
                                                    src={notesSvg}
                                                    style={{
                                                        opacity: row.notes != "" ? 1 : 0.2,
                                                        cursor: row.notes != "" ? "pointer" : "not-allowed"
                                                    }}
                                                    // className="cursor-pointer"
                                                    alt="Notes"
                                                    onClick={() => {
                                                        if (row.notes == "") return;
                                                        setSelectedNotes(row);
                                                        setOpenNotesModal(true);
                                                    }}
                                                />
                                            </>
                                        </TableCell>

                                        {/* Actions */}
                                        {featureAccess.includes('Edit') && <TableCell TableCell align="center" >
                                            <img
                                                src={editSvg}
                                                className="cursor-pointer"
                                                alt="Edit"
                                                onClick={() => {
                                                    handleEdit(row)

                                                    window.scrollTo({
                                                        top: 0,
                                                        behavior: "smooth"
                                                    });
                                                }}
                                            />
                                        </TableCell>}

                                    </TableRow>
                                ))
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>

                    {/* Pagination */}
                    {!!paginationCount && <Box className="table-body-bg border-radius-bottom-8" display="flex" justifyContent="space-between" alignItems="end" p={1.5} px={2.5}>
                        <Pagination
                            className="bg-white"
                            size="medium"
                            count={Math.ceil(paginationCount / limit)}
                            page={page} onChange={(e, v) => setPage(v)}
                            shape="rounded"
                            sx={{
                                float: 'right',
                                ml: "auto",
                                '& .MuiPaginationItem-root': {
                                    borderRadius: 3,
                                },
                            }}
                        />
                    </Box>}
                </Paper >
            </Paper >

            <BulkTargetModal
                clearBulkModalvalues={clearBulkModalvalues}
                openbulkmodal={openbulkmodal}
                handleClosebulkmodal={handleClosebulkmodal}
                handlebulkSubmit={handlebulkSubmit}
                onInfo={showMessageBulk}
            />

            <ViewNotes
                open={openNotesModal}
                handleClose={() => setOpenNotesModal(false)}
                notes={selectedNotes}
            />
        </>
    );
};

export default Target;