import { Box, Chip, IconButton, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip, Typography, Pagination, Button, TextField, ToggleButtonGroup, ToggleButton, FormControl, Select, MenuItem, Autocomplete, useMediaQuery, Skeleton } from "@mui/material";
import { Edit, Refresh } from "@mui/icons-material";
import { useState, useEffect, useCallback, useMemo } from "react";
import ResetModal from "../modals/ResetPassword";
import { useNavigate } from "react-router-dom";
import { getUserDetails, searchUserDetails } from "../services/api";
import { ToastContainer } from 'react-toastify';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import { useSelector } from "react-redux";
import { encryptRoute } from "../services/encrypt";
import LockIcon from '@mui/icons-material/Lock';
import LockUserModal from "../modals/LockUserModal";
import BackdropLoader from "../components/Loader/BackdropLoader";
import editUser from "../assets/images/editUser.svg";
import resetPassword from "../assets/images/resetPassword.svg";
import unLockUser from "../assets/images/unLockUser.svg";
import lockUser from "../assets/images/lockUser.svg";

export default function UserTable() {
    const [formValues, setFormValues] = useState({ dealer: "", parentCode: "" });
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const navigate = useNavigate();
    const [userData, setUserData] = useState();
    // useEffect(() => {
    //     setUserData(users);
    // }, [])
    const [paginationCount, setPaginationCount] = useState(0);
    const [search, setSearch] = useState('');
    const [limit, setLimit] = useState(10);
    const [page, setPage] = useState(1);
    const [count, setCount] = useState(0);
    const handleChangePage = (event, newPage) => setPage(newPage);
    const handleSubmit = () => { }
    const createUser = () => { }
    const [open, setOpen] = useState(false);
    const [lockopen, setlockOpen] = useState(false);
    const [status, setStatus] = useState('');
    const [email, setEmail] = useState(null);
    const [userId, setUserId] = useState(null);
    const [mobileNo, setPhone] = useState(null);
    const userDetails = useSelector((state) => state?.user?.loggedData);
    const featureAccess = useSelector((state) => state.user.featureAccess.filter(f => f.Url && f.Url.startsWith('/userManagement')));
    const [roleType, setRoleType] = useState(featureAccess.filter(f => f.Url && f.Url === '/userManagement').map(f => f.FeatureName.slice(0, -5)).sort((a, b) => b.localeCompare(a))[0]);
    const roles = featureAccess.filter(f => f.Url && f.Url === '/userManagement').map(f => f.FeatureName.slice(0, -5)).sort((a, b) => b.localeCompare(a));
    const [dealersList, setDealersList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [debouncedSearch, setDebouncedSearch] = useState('');

    const openResetModal = (email, id, phone) => {
        setOpen(true);
        setEmail(email);
        setUserId(id);
        setPhone(phone);
    }
    const onClose = () => {
        setOpen(false);
    }
    const lockonClose = (data) => {
        setlockOpen(false);
        if (data === "success") {
            fetchUserData();
        }
    }

    const payload = useMemo(() => {
        if (userDetails?.roleType === 'MIBL') {
            if (roleType === 'MIBL') {
                return { offset: page, limit: limit, roleType: roleType, searchName: debouncedSearch };
            }

            if (!formValues.dealer) {
                return { offset: page, limit: limit, roleType: roleType, searchName: debouncedSearch };
            }

            return { offset: page, limit: limit, roleType: roleType, parentCode: formValues.parentCode, searchName: debouncedSearch };
        }

        if (userDetails?.roleType === 'DEALER') {
            return { offset: page, limit: limit, roleType: roleType, parentCode: userDetails?.parentCode, searchName: debouncedSearch };
        }

        return null;
    }, [debouncedSearch, formValues.dealer, formValues.parentCode, limit, page, roleType, userDetails?.parentCode, userDetails?.roleType]);

    const fetchUserData = useCallback(async (requestPayload) => {
        if (!requestPayload) return;
        setLoading(true);
        try {
            const response = await getUserDetails(requestPayload);
            if (response.status_code === "200") {
                if (userDetails?.roleType === 'MIBL') {
                    if (formValues.dealer) {
                        setUserData(roleType === 'MIBL' ? response.result1 : response.result0);
                        setPaginationCount(roleType === 'MIBL' ? response.result2[0].paginationCount : response.result1[0].paginationCount);
                    } else if (!formValues.dealer) {
                        setUserData(roleType === 'MIBL' ? response.result1 : response.result1);
                        setPaginationCount(roleType === 'MIBL' ? response.result2[0].paginationCount : response.result2[0].paginationCount);
                    }
                    if (!formValues.dealer) {
                        setDealersList(response.result0);
                    }
                }
                else if (userDetails?.roleType === 'DEALER') {
                    setUserData(response.result0);
                    setPaginationCount(response.result1[0].paginationCount);
                }

                // if (!formValues.dealer) {
                // const selectedDealer = dealersList.at(0);
                // setFormValues((prev) => ({
                //     ...prev,
                //     dealer: selectedDealer?.dealer_name,
                //     parentCode: selectedDealer?.parent_code
                // }));
                // }
                // setUserData(roleType === 'MIBL' ? response.result1 : response.result0);
                // setPaginationCount(roleType === 'MIBL' ? response.result2[0]?.paginationCount : response.result1[0]?.paginationCount);
            } else if (response.status_code == "404") {
                setUserData([]);
                setPaginationCount(0);
            }
        } catch (error) {
            console.error('Error posting data:', error);
        } finally {
            setLoading(false);
        }
    }, [formValues.dealer, roleType, userDetails?.roleType]);

    const deactivate = (status, email, id) => {
        setEmail(email);
        setStatus(status);
        setlockOpen(true);
        setUserId(id);
    };

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            setDebouncedSearch(search);
        }, 300);

        return () => clearTimeout(delayDebounce);
    }, [search]);

    useEffect(() => {
        setPage(1);
    }, [roleType, formValues?.dealer]);

    useEffect(() => {
        fetchUserData(payload);
    }, [fetchUserData, payload]);

    return (
        <>
            <BackdropLoader loading={loading} />
            <Paper className="table-auto-width" sx={{ m: isMobile ? 1.5 : 2, boxShadow: 'none' }}>
                <Box className="table-body-bg border-radius-top-8" display="flex" flexWrap={"wrap"} justifyContent="space-between" alignItems="center" pt={2} pb={1} px={2.5}>
                    <Typography className={`${isMobile ? 'fs-16' : 'fs-24'} georama-SemiBold`}>User Management</Typography>

                    <Box display="flex" flexWrap={"wrap"} justifyContent="space-between" alignItems="center">
                        {
                            !!featureAccess.filter(f => f.Url === '/userManagement/create' && f.FeatureName.startsWith(roleType)).length &&
                            <Button
                                sx={{ my: 1 }}
                                className="btn-common-red"
                                onClick={() => {
                                    navigate(`/${encodeURIComponent(encryptRoute('/userManagement/create'))}`, { state: { edit: false } });
                                    createUser();
                                }}
                            >
                                Add New User
                            </Button>}

                        <TextField className="custom-textfield body-formbg" size="small" placeholder="Search" value={search} onChange={(e) => {
                            setSearch(e.target.value.trimStart().replace(/[^a-zA-Z0-9.@\s]/g, '').replace(/\s+/g, ' ').slice(0, 50));
                            setPage(1);
                        }}
                            fullWidth
                            sx={{
                                width: isDesktop ? '22ch' : isMobile ? '22ch' : '22ch',
                                px: 2,
                                ml: 1, mt: 1,
                                '& .MuiOutlinedInput-root': {
                                    borderRadius: 3,
                                    '&.Mui-focused fieldset': {
                                        borderColor: 'black',
                                    },
                                },
                            }}
                        />
                    </Box>
                </Box>

                <Box
                    // display="flex"
                    // alignItems="center"
                    // justifyContent="space-between"
                    gap={2}
                    mb={1}
                >
                    {/* Left Side: Labels */}

                    <Box display="flex" flexWrap={"wrap"} justifyContent={"space-between"} alignItems="center" gap={2}>
                        {roles.length > 1 && <ToggleButtonGroup
                            value={roleType}
                            exclusive
                            onChange={(e, newValue) => {
                                if (newValue !== null) setRoleType(newValue);
                            }}
                            sx={{ display: 'flex', gap: 1, border: 'none' }}>
                            {roles.map((v) => (
                                <ToggleButton exclusive className="toggle-button"
                                    key={v} value={v}>
                                    {v}
                                </ToggleButton>
                            ))}
                        </ToggleButtonGroup>}
                        {userDetails?.roleType === 'MIBL' && roleType === 'Dealer' &&
                            <FormControl
                                sx={{ visibility: roleType === 'Dealer' ? 'visible' : 'hidden', mx: 2, width: 250 }}
                                className='form-control-input border-radius-8'
                                size="small"
                                fullWidth
                            >
                                <Autocomplete
                                    size="small"
                                    options={dealersList || []}
                                    getOptionLabel={(option) => option.dealer_name || ''}
                                    value={dealersList.find(d => d.dealer_name === formValues.dealer) || null}
                                    onChange={(event, newValue) => {
                                        setFormValues((prev) => ({
                                            ...prev,
                                            dealer: newValue?.dealer_name || '',
                                            parentCode: newValue?.parent_code || ''
                                        }));
                                    }}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            placeholder="Select Dealer"
                                            size="small"
                                        />
                                    )}
                                    isOptionEqualToValue={(option, value) => option.dealer_name === value.dealer_name}
                                />
                            </FormControl>
                        }
                    </Box>

                    {/* Right Side: Filters & Marquee */}

                    <Box display="flex" alignItems="center" gap={1}>

                        {/* <Box sx={{ visibility: roleType === 'Dealer' ? 'visible' : 'hidden' }} display="flex" justifyContent="space-between" alignItems="center">
                            <TextField className="custom-textfield body-formbg" size="small" placeholder="Location"
                                // value={search} 
                                // onChange={(e) => setSearch(e.target.value.trimStart().replace(/[^a-zA-Z0-9.,\s]/g, '').replace(/\s+/g, ' ').slice(0, 50)) || setPage(1)}
                                sx={{
                                    width: '22ch',
                                    px: 2,
                                    '& .MuiOutlinedInput-root': {
                                        borderRadius: 3,
                                        '&.Mui-focused fieldset': {
                                            borderColor: 'black',
                                        },
                                    },
                                    float: 'right'
                                }}
                            />
                        </Box> */}

                        {/* <FormControl sx={{ visibility: roleType === 'Dealer' ? 'visible' : 'hidden', mr: 3 }}
                            className='form-control-input border-radius-8'
                            size="small"

                        > */}
                        {/* <Select
                                value={formValues.dealer}
                                onChange={(e) => {
                                    const selectedDealer = dealersList.find(d => d?.dealer_name === e.target.value);
                                    setFormValues((prev) => ({
                                        ...prev,
                                        dealer: selectedDealer?.dealer_name,
                                        parentCode: selectedDealer?.parent_code
                                    }));
                                }}
                                displayEmpty
                            >
                                <MenuItem value="">
                                    Select Dealer
                                </MenuItem>

                                {dealersList && dealersList.map((dealer, index) => (
                                    <MenuItem key={index} value={dealer.dealer_name}>
                                        {dealer.dealer_name}
                                    </MenuItem>
                                ))}
                            </Select> */}

                        {/* <Select
                                                value={formValues.dealer}
                                                onChange={handleChange("dealer")}
                                                displayEmpty
                                            >
                                                <MenuItem value="" disabled>
                                                    Select Dealer
                                                </MenuItem>
                                                {dealersList && dealersList?.map((dealer, index) => (
                                                    <MenuItem key={index} value={dealer.dealer_name}>
                                                        {dealer.dealer_name}
                                                    </MenuItem>
                                                ))}
                                            </Select> */}
                        {/* </FormControl> */}
                    </Box>
                </Box>

                <TableContainer component={Box} sx={{ mt: 0 }}>
                    <Table sx={{ tableLayout: 'auto', width: '100%' }}>
                        <TableHead>
                            <TableRow>
                                <TableCell className="p-3 georama-Medium body-formbg fw-none">Name</TableCell>
                                <TableCell className="p-3 georama-Medium body-formbg fw-none">Contact Info</TableCell>
                                <TableCell className="p-3 georama-Medium body-formbg fw-none">Role</TableCell>

                                {roleType === "Dealer" &&
                                    <>
                                        <TableCell className="p-3 georama-Medium body-formbg fw-none">Dealer</TableCell>
                                        <TableCell className="p-3 georama-Medium body-formbg fw-none">Location</TableCell>
                                        <TableCell className="p-3 georama-Medium body-formbg fw-none">Reporting Manager</TableCell>
                                    </>
                                }

                                <TableCell className="p-3 georama-Medium body-formbg fw-none">Status</TableCell>
                                <TableCell className="p-3 georama-Medium body-formbg fw-none">Action</TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody className="table-body-bg">
                            {loading ? (
                                [...Array(8)].map((_, idx) => (
                                    <TableRow key={idx}>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                        <TableCell><Skeleton variant="text" width="80%" /></TableCell>
                                    </TableRow>
                                ))) : ((userData && userData.length > 0) ?
                                    userData?.map((user, index) => (
                                        <TableRow key={index}>
                                            <TableCell className="p-4" sx={{ whiteSpace: 'normal', textOverflow: 'clip' }}>
                                                <Typography className="">
                                                    <span className="georama-Medium fs-14 text-truncate">
                                                        {user.name}
                                                    </span>
                                                </Typography>
                                                <Typography className="georama-Regular fs-12" variant="caption">#{user.id}</Typography>
                                            </TableCell>

                                            <TableCell className="p-4">
                                                {(() => {
                                                    const [email, phone] = user.contactInfo?.split(' ') || [];
                                                    return (
                                                        <>
                                                            <Typography className="georama-Regular fs-14">{phone}</Typography>
                                                            <Typography className="georama-Regular fs-12" >{email}</Typography>
                                                        </>
                                                    );
                                                })()}
                                            </TableCell>

                                            <TableCell className="fs-14 p-4" >{user.role}</TableCell>

                                            {roleType === "Dealer" &&
                                                <>
                                                    <TableCell className="georama-Regular fs-14 p-4" >{user.dealer}</TableCell>

                                                    <TableCell className="georama-Regular fs-14 p-4" >{user.location}</TableCell>

                                                    <TableCell className="georama-Regular fs-14 p-4" >{user.ReportingManager}</TableCell>
                                                </>
                                            }

                                            <TableCell className="p-4" >
                                                <Chip
                                                    className="georama-Medium fs-12"
                                                    label={user.status === "1" ? "Active" : "Inactive"}
                                                    size="small"
                                                    sx={{
                                                        backgroundColor: user.status === "1" ? "#e0f7ea" : "#fdecea",
                                                        color: user.status === "1" ? "#388e3c" : "#d32f2f",
                                                        fontWeight: "bold",
                                                    }}
                                                />
                                            </TableCell>

                                            <TableCell className="georama-Regular fs-14 p-4" >
                                                {userDetails?.user_id !== user.id && <Box display="flex">
                                                    {
                                                        !!featureAccess.filter(f => f.Url === '/userManagement/edit' && f.FeatureName.startsWith(roleType)).length &&
                                                        <Tooltip title="Edit" >
                                                            <IconButton onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/userManagement/edit'))}`,
                                                                { state: { user: user, edit: true } })}>
                                                                <img
                                                                    src={editUser}
                                                                    alt="edit"
                                                                    style={{
                                                                        width: 16,
                                                                        height: 16,
                                                                        // filter: isActive ? 'brightness(0) invert(1)' : 'none',
                                                                        transition: 'filter 0.2s ease',
                                                                    }}
                                                                />
                                                            </IconButton>
                                                        </Tooltip>}

                                                    {user.status === "1" && (() => {
                                                        const [email, phone] = user.contactInfo?.split(' ') || [];

                                                        return (
                                                            <Tooltip
                                                                title={user.lockStatus === "U" ? "Lock" : "Unlock"}
                                                                onClick={() => deactivate(user.lockStatus === "U" ? "Unlocked" : "Locked", email, user.id)}
                                                            >
                                                                <IconButton>
                                                                    {user.lockStatus === "U"
                                                                        ? <img
                                                                            src={unLockUser}
                                                                            alt="edit"
                                                                            style={{
                                                                                width: 16,
                                                                                height: 16,
                                                                                // filter: isActive ? 'brightness(0) invert(1)' : 'none',
                                                                                transition: 'filter 0.2s ease',
                                                                            }}
                                                                        />
                                                                        :
                                                                        <img
                                                                            src={lockUser}
                                                                            alt="edit"
                                                                            style={{
                                                                                width: 16,
                                                                                height: 16,
                                                                                // filter: isActive ? 'brightness(0) invert(1)' : 'none',
                                                                                transition: 'filter 0.2s ease',
                                                                            }}
                                                                        />
                                                                    }
                                                                </IconButton>
                                                            </Tooltip>
                                                        );
                                                    })()}

                                                    {user.status === "1" && user.lockStatus === "U" && (() => {
                                                        const [email, phone] = user.contactInfo?.split(' ') || [];

                                                        return (
                                                            <Tooltip
                                                                title="Reset Password"
                                                                onClick={() => openResetModal(email, user.id, phone)}
                                                            >
                                                                <IconButton>
                                                                    <img
                                                                        src={resetPassword}
                                                                        alt="edit"
                                                                        style={{
                                                                            width: 16,
                                                                            height: 16,
                                                                            // filter: isActive ? 'brightness(0) invert(1)' : 'none',
                                                                            transition: 'filter 0.2s ease',
                                                                        }}
                                                                    />
                                                                </IconButton>
                                                            </Tooltip>
                                                        );
                                                    })()}
                                                </Box>}
                                            </TableCell>
                                        </TableRow>
                                    )) :
                                    (!userData || !userData?.length) && !loading && (
                                        <TableRow>
                                            <TableCell colSpan={roleType === "Dealer" ? 8 : 5}>
                                                <Box className="center-text">
                                                    No Data Found
                                                </Box></TableCell>
                                        </TableRow>
                                    ))}
                        </TableBody>
                    </Table>
                </TableContainer>

                <Box className="table-body-bg border-radius-bottom-8" display="flex" justifyContent="space-between" alignItems="end" p={2} px={2.5}>
                    {!!paginationCount && <Pagination
                        className="bg-white"
                        size="medium"
                        count={Math.ceil(paginationCount / limit)}
                        page={page} onChange={(e, v) => setPage(v)}
                        shape="rounded"
                        sx={{
                            float: 'right',
                            ml: "auto",
                            '& .MuiPaginationItem-root': {
                                borderRadius: 3,
                            },
                        }}
                    />}
                </Box>
            </Paper>

            <ResetModal open={open} onClose={onClose} email={email} userId={userId} mobileNo={mobileNo} />

            <ToastContainer autoClose={1000} />

            <LockUserModal lockopen={lockopen} userId={userId} lockonClose={lockonClose} email={email} status={status} />
        </>
    );
}