import { Box, Button, Grid, FormHelperText, TextField, Typography, Divider, Paper, useMediaQuery } from "@mui/material";
import { useEffect, useState } from "react";
import { getUserProfileDetails, updateUserProfile } from "../services/api"
import { useDispatch, useSelector } from "react-redux";
import { ToastContainer, toast } from 'react-toastify';
import { setUserData, setUserName } from "../redux/slices/userSlice";

export default function UserProfile() {
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const userData = useSelector((state) => state.user.loggedData);
    const [isFormValid, setIsFormValid] = useState(false);
    const [editValues, setEditValues] = useState([]);
    const [formErrors, setFormErrors] = useState({});
    const dispatch = useDispatch();

    const [formValues, setFormValues] = useState({
        firstName: "",
        lastName: "",
        contactInfo: "",
        email: "",
        status: "",
        dealer: "",
        location: "",
        role: "",
        manager: "",
    });


    useEffect(() => {
        if (editValues) {
            setFormValues({
                firstName: editValues.first_name || "",
                lastName: editValues.last_name || "",
                contactInfo: editValues.mobile_no || "",
                email: editValues.email_id || "",
                dealer: editValues.dealer_name || "",
                location: editValues.address || "",
                role: editValues.role || "",
                manager: editValues.reportingManager || "",
            });
        }
    }, [editValues]);

    const getUserDetailsEdit = async (id) => {
        const emailId = userData.email;
        try {
            const response = await getUserProfileDetails(id, emailId);
            if (response.statusCode === "200") {
                setEditValues(response.data);
            }
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        getUserDetailsEdit(userData.user_id);
    }, []);


    const validateForm = () => {
        const errors = {};
        if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(formValues.email)) {
            errors.email = "Invalid Email";
        }
        if (!/^\d{10}$/.test(formValues.contactInfo)) errors.contactInfo = "Invalid Mobile No";
        // if (!formValues.dealer) errors.dealer = "Dealer is required";
        // if (!formValues.location) errors.location = "Location is required";
        if (!formValues.firstName.trim().length > 2) errors.firstName = "First Name must be atleast 2 characters long";
        if (!formValues.lastName.trim().length > 3) errors.lastName = "Last Name must be atleast 3 characters long";
        if (!formValues.firstName.trim()) errors.firstName = "First Name is required";
        if (!formValues.lastName.trim()) errors.lastName = "Last Name is required";
        if (!formValues.contactInfo.trim()) errors.contactInfo = "Mobile No is required";
        // if (!formValues.email.trim()) errors.email = "Email is required";
        // if (!formValues.status) errors.status = "Status is required";
        // if (!formValues.role) errors.role = "Role Assignment is required";
        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    }

    // useEffect(() => {
    //     setIsFormValid(validateForm());
    // }, [formValues]);

    const handleSubmit = async () => {
        const isValid = validateForm();
        setIsFormValid(isValid);

        if (!isValid) return;

        const data = {
            "userId": userData.user_id,
            "firstName": formValues.firstName,
            "lastName": formValues.lastName,
            "mobileNo": formValues.contactInfo,
            "emailid": userData.email,
            // "emailid": formValues.email,
            // "dealerCode": formValues.dealer || "",
            // "location": editValues.address || "",
            // "roleID": userData.roleId,
            // "manager": formValues.manager || "",
            // "roleName": formValues.role,
            // "role": formValues.role || editValues.role || "",
        }
        try {
            const response = await updateUserProfile(data);
            if (response.status_code === "200" || response.status_message === "User details updated successfully.") {
                toast.success(response.status_message);
                let userInfo = { ...userData };
                userInfo.firstName = `${formValues.firstName} ${formValues.lastName}`;
                dispatch(setUserData(userInfo));
                const username = formValues.firstName + " " + formValues.lastName
                dispatch(setUserName(username));
            } else if (response.status_code === "304" || response.status_message === "No fields were updated.") {
                toast.error("No fields were updated. Please check the form.");
            }
        } catch (error) {
            console.log(error);
            toast.error(error);
        }

    }

    const handleChange = (field) => async (e) => {
        const value = e.target.value;

        setFormValues((prev) => ({
            ...prev,
            [field]: value,
        }));

        setFormErrors((prev) => ({
            ...prev,
            [field]: "",
        }));
    };

    return (
        <>
            {/* <MarqueeInfo /> */}

            <Paper elevation={0} sx={{
                width: userData?.roleType === 'MIBL' ? "100%" :
                    userData?.roleType !== 'MIBL' && !isMobile ? "85%" :
                        userData?.roleType !== 'MIBL' && isMobile ? "100%" : "",
                borderRadius: 3,
                mx: userData?.roleType === 'MIBL' && !isMobile ? 2.5 : userData?.roleType === 'MIBL' && isMobile ? 1.5 :
                    userData?.roleType !== 'MIBL' && !isMobile ? "auto" : userData?.roleType !== 'MIBL' && isMobile ? 1 : "",
                mt: isMobile ? 1.5 : 2.5
            }}>
                <Box sx={{ borderRadius: 2 }}>
                    <Box display="flex" justifyContent="space-between" alignItems="center" px={2.5} my={2}>
                        <Typography className="georama-SemiBold fs-20">
                            My Profile
                        </Typography>
                    </Box>

                    <Divider sx={{ mb: 2 }} />

                    <Grid container spacing={isMobile ? 1 : 3} px={isMobile ? 2 : 3} mb={2}>
                        <Grid size={{ xs: 12, sm: 6, md: 4, lg: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                First Name <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                className='form-control-input border-radius-8'
                                size="small"
                                fullWidth
                                required
                                placeholder="Enter First Name"
                                value={formValues.firstName}
                                onInput={(e) => {
                                    e.target.value = e.target.value.trimStart().replace(/[^a-zA-Z]/g, '').slice(0, 30);
                                }}
                                onChange={handleChange("firstName")}
                                error={!!formErrors.firstName}
                            />

                            <FormHelperText className="important-fields">{formErrors.firstName}</FormHelperText>
                        </Grid>

                        <Grid size={{ xs: 12, sm: 6, md: 4, lg: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Last Name <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                className='form-control-input border-radius-8'
                                size="small"
                                fullWidth
                                required
                                placeholder="Enter Last Name"
                                value={formValues.lastName}
                                onInput={(e) => {
                                    e.target.value = e.target.value.trimStart().replace(/[^a-zA-Z]/g, '').slice(0, 30);
                                }}
                                onChange={handleChange("lastName")}
                                error={!!formErrors.lastName}
                            />

                            <FormHelperText className="important-fields">{formErrors.lastName}</FormHelperText>
                        </Grid>

                        <Grid size={{ xs: 12, sm: 6, md: 4, lg: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Mobile No <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                fullWidth
                                size="small"
                                className='form-control-input border-radius-8'
                                required
                                placeholder="Enter Mobile No"
                                value={formValues.contactInfo}
                                onInput={(e) => {
                                    e.target.value = e.target.value.replace(/[^0-9]/g, "");
                                }}
                                inputProps={{
                                    inputMode: "numeric",
                                    minLength: 10,
                                    maxLength: 10
                                }}
                                onChange={handleChange("contactInfo")}
                                error={!!formErrors.contactInfo}
                            />

                            <FormHelperText className="important-fields">{formErrors.contactInfo}</FormHelperText>
                        </Grid>

                        <Grid size={{ xs: 12, sm: 6, md: 4, lg: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Email ID <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                size="small"
                                className="disabled-input border-radius-8 cursor-nodrop"
                                disabled={true}
                                fullWidth required
                                value={formValues.email}
                                error={!!formErrors.email}
                            />

                            <FormHelperText className="important-fields">{formErrors.email}</FormHelperText>
                        </Grid>
                    </Grid>

                    <Divider />

                    <Grid container spacing={isMobile ? 1 : 3} px={isMobile ? 2 : 3} mt={2} mb={2}>
                        {formValues?.dealer && formValues.location && <Grid item size={{ xs: 12, sm: 6, md: 6, lg: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Dealer <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                size="small"
                                className="disabled-input border-radius-8 cursor-nodrop"
                                disabled={true}
                                fullWidth required
                                value={formValues.dealer}
                                error={!!formErrors.dealer}
                            />

                            <FormHelperText className="important-fields">{formErrors.dealer}</FormHelperText>
                        </Grid>}

                        {formValues?.dealer && formValues.location && <Grid item size={{ xs: 12, sm: 6, md: 6, lg: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Location <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                size="small"
                                className="disabled-input border-radius-8 cursor-nodrop"
                                disabled={true}
                                fullWidth required
                                value={formValues.location}
                                error={!!formErrors.location}
                            />

                            <FormHelperText className="important-fields">{formErrors.location}</FormHelperText>
                        </Grid>}

                        <Grid item size={{ xs: 12, sm: 6, md: 6, lg: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Role Assignment <span className="important-fields">*</span>
                            </Typography>

                            <TextField
                                size="small"
                                className="disabled-input border-radius-8 cursor-nodrop"
                                disabled={true}
                                fullWidth required
                                value={formValues.role}
                                error={!!formErrors.role}
                            />

                            <FormHelperText className="important-fields">{formErrors.role}</FormHelperText>
                        </Grid>

                        <Grid item size={{ xs: 12, sm: 6, md: 6, lg: 4 }}>
                            <Typography className='text-labels' mb={0.5}>
                                Reporting Manager
                            </Typography>

                            <TextField
                                size="small"
                                className="disabled-input border-radius-8 cursor-nodrop"
                                disabled={true}
                                fullWidth required
                                value={formValues.manager}
                                error={!!formErrors.manager}
                            />
                        </Grid>
                    </Grid>

                    <Box display="flex" pb={1} mx={5} justifyContent="flex-end">
                        <Button className="btn-common-red" onClick={handleSubmit}>
                            Save
                        </Button>
                    </Box>
                </Box>
            </Paper >

            <ToastContainer autoClose={1000} />
        </>
    );
}