import DownloadIcon from "@mui/icons-material/Download";
import { Box, Button, FormControl, Grid, InputLabel, MenuItem, Paper, Select, Typography, useMediaQuery } from "@mui/material";
import { ArcElement, Chart as ChartJS, Tooltip } from "chart.js";
import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import nodata1 from "../assets/images/target/noData3.svg";
import BackdropLoader from "../components/Loader/BackdropLoader";
import GaugeChart from "../components/Targetcharts/GaugeChart";
import NetAddonPremium from "../components/Targetcharts/NetAddonPremium";
import NetODPremium from "../components/Targetcharts/NetODPremium";
import NetTotalPremium from "../components/Targetcharts/NetTotalPremium";
import { setYearList } from "../redux/slices/dashboardSlice";
import { downloadTargetChartData, fetchTargetChart } from "../services/api";
import { encryptRoute } from "../services/encrypt";
import { btnRed } from "../utils/Colors";
// import nodata2 from "../assets/images/target/no-data1";

ChartJS.register(ArcElement, Tooltip);

const ViewCharts = () => {
    const [loading, setLoading] = useState(false);
    const userDetails = useSelector((state) => state.user.loggedData);
    const userBymanager = useSelector((state) => state.user.fetchUserByManager);
    const yearData = useSelector((state) => state.dashboard.yearData);
    const isDesktop = useMediaQuery('(min-width:992px)');
    const isMobile = useMediaQuery('(min-width:320px) and (max-width:625px)');
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [teamData, setTeamData] = useState([]);
    const [monthData, setMonthData] = useState([]);
    // const [chartsData, setChartsData] = useState([]);

    const [selectedSegment, setSelectedSegment] = useState("");
    const [segmentSelectOpen, setSegmentSelectOpen] = useState(false);
    const [selectedYear, setSelectedYear] = useState("");
    const [selectedMonth, setSelectedMonth] = useState("");
    const [yearOpen, setYearOpen] = useState(false);
    const [monthOpen, setMonthOpen] = useState(false);

    const fetchChartData = async ({ segment = selectedSegment, year = selectedYear, month = selectedMonth }) => {
        try {
            setLoading(true);
            const payload = {
                type: "onload",
                dealerCode: userDetails?.dealerCode,
                userId: userDetails?.user_id,
                teamId: segment || "",
                year: year || "",
                month: month || ""
            }

            const response = await fetchTargetChart(payload);
            if (response?.status_code === "200" || response?.status_message === "SUCCESS") {
                if (userBymanager?.length > 0) {
                    setTeamData(response?.result0 || []);
                    // When segment is selected but no year is selected (checked via parameter) - clear charts and show year list
                    if (selectedSegment && !year) {
                        const formattedYears = (response?.result1 || []).map((y) => ({
                            id: y.year,
                            name: y.year
                        }));
                        dispatch(setYearList(formattedYears));
                        setChartsData([]); // Clear charts - show no data
                    }
                    // When both segment and year are selected - show charts
                    else if (selectedSegment && year) {
                        setChartsData(response?.result3 || []);
                        const formattedMonths = (response?.result1 || []).map((m) => m.month);
                        setMonthData(formattedMonths);
                    }
                    // When no segment is selected - show all data
                    // else if (!selectedSegment) {
                    //     if (!selectedYear) {
                    //         console.log("selected segment = ", selectedSegment, "year = ", year, "selected month = ", month, "selected year = ", selectedYear);
                    //         const formattedYears = (response?.result1 || []).map((y) => ({
                    //             id: y.year,
                    //             name: y.year
                    //         }));
                    //         dispatch(setYearList(formattedYears));
                    //         setChartsData(response?.result1 || []);
                    //     }
                    // }
                } else if (userBymanager == null) {
                    if (selectedYear) {
                        setChartsData(response?.result3 || []);
                    }
                    if (!selectedYear) {
                        const formattedYears = (response?.result1 || []).map((y) => ({
                            id: y.year,
                            name: y.year
                        }));
                        dispatch(setYearList(formattedYears));
                    }
                    const formattedMonths = (response?.result1 || []).map((m) => m.month);
                    setMonthData(formattedMonths);
                }
            } else {
                console.error("Failed to fetch dashboard:", response);
            }
        } catch (err) {
            console.error("Error fetching dashboard data:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchChartData({
            segment: selectedSegment,
            year: selectedYear,
            month: selectedMonth
        });
    }, []);

    const downloadTargetChart = async ({ segment = selectedSegment, year = selectedYear, month = selectedMonth }) => {
        try {
            setLoading(true);
            const payload = {
                type: "",
                dealerCode: userDetails?.dealerCode,
                userId: userDetails?.user_id,
                teamId: segment || "",
                year: year || "",
                month: month || ""
            }

            const result = await downloadTargetChartData(payload);

            if (result?.data) {
                const blob = new Blob([result.data], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                });

                const url = window.URL.createObjectURL(blob);
                const link = document.createElement("a");

                link.href = url;
                link.download = "Target_Charts_Data.xlsx";

                document.body.appendChild(link);
                link.click();

                link.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error("Error downloading Excel file:", error);
        } finally {
            setLoading(false);
        }
    };

    const chartsData = [
        {
            "chart_type": "NET_TOTAL_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-01",
            "actual_value": 244022,
            "target_value": 365000
        },
        {
            "chart_type": "NET_TOTAL_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-01",
            "actual_value": 244022,
            "target_value": null
        },
        {
            "chart_type": "NET_TOTAL_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-01",
            "actual_value": 244022,
            "target_value": 1615000
        },
        {
            "chart_type": "NET_TOTAL_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-01",
            "actual_value": 244022,
            "target_value": 165900
        },
        {
            "chart_type": "NET_TOTAL_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-03",
            "actual_value": 143776,
            "target_value": 365000
        },
        {
            "chart_type": "NET_TOTAL_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-03",
            "actual_value": 143776,
            "target_value": null
        },
        {
            "chart_type": "NET_TOTAL_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-03",
            "actual_value": 143776,
            "target_value": 1615000
        },
        {
            "chart_type": "NET_TOTAL_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-03",
            "actual_value": 143776,
            "target_value": 165900
        },
        {
            "chart_type": "NET_ADDON_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-01",
            "actual_value": 84192,
            "target_value": null
        },
        {
            "chart_type": "NET_ADDON_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-01",
            "actual_value": 84192,
            "target_value": 101964610
        },
        {
            "chart_type": "NET_ADDON_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-01",
            "actual_value": 84192,
            "target_value": 1946947915
        },
        {
            "chart_type": "NET_ADDON_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-03",
            "actual_value": 38222,
            "target_value": null
        },
        {
            "chart_type": "NET_ADDON_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-03",
            "actual_value": 38222,
            "target_value": 101964610
        },
        {
            "chart_type": "NET_ADDON_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-03",
            "actual_value": 38222,
            "target_value": 1946947915
        },
        {
            "chart_type": "NET_OD_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-01",
            "actual_value": 159610,
            "target_value": 159610
        },
        {
            "chart_type": "NET_OD_PREMIUM",
            "dealer_code": "D100",
            "period": "2026-03",
            "actual_value": 74075,
            "target_value": 74075
        },
        {
            "chart_type": "CONVERSION RATIO",
            "dealer_code": "D100",
            "period": "",
            "actual_value": 10,
            "target_value": 80
        },
        {
            "chart_type": "RETENTION RATIO",
            "dealer_code": "D100",
            "period": "",
            "actual_value": 61.76,
            "target_value": 10
        }
    ]

    const formatMonth = (period) => {
        if (!period) return "";
        const date = new Date(period);
        return date.toLocaleString("default", { month: "short" });
    };

    const transformChartsData = (data) => {
        const result = {
            NET_TOTAL_PREMIUM: {},
            NET_ADDON_PREMIUM: {},
            NET_OD_PREMIUM: {},
            CONVERSION_RATIO: null,
            RETENTION_RATIO: null,
        };

        const typeDataMap = {};

        data?.forEach((item) => {
            const type = item?.chart_type?.replace(/\s/g, "_");

            if (!typeDataMap[type]) {
                typeDataMap[type] = [];
            }

            typeDataMap[type].push(item);
        });

        Object?.keys(typeDataMap)?.forEach((type) => {
            const items = typeDataMap[type];

            // GAUGE CHART
            if (!items[0].period) {
                const validGauge = items?.find(
                    (i) => i.actual_value != null && i.target_value != null
                );

                result[type] = validGauge
                    ? {
                        current: validGauge.actual_value,
                        target: validGauge.target_value,
                    }
                    : null;

                return;
            }

            // BAR CHART
            items.forEach((item) => {
                const month = formatMonth(item.period);

                result[type][month] = {
                    actual: item.actual_value ?? 0,
                    target: item.target_value ?? 0,
                };
            });
        });

        return result;
    };

    // const transformChartsData = (data) => {
    //     const result = {
    //         NET_TOTAL_PREMIUM: {},
    //         NET_ADDON_PREMIUM: {},
    //         NET_OD_PREMIUM: {},
    //         CONVERSION_RATIO: null,
    //         RETENTION_RATIO: null,
    //     };

    //     const typeDataMap = {}; // ✅ group by type first

    //     // STEP 1: Group data by type
    //     data?.forEach((item) => {
    //         const type = item?.chart_type?.replace(/\s/g, "_");

    //         if (!typeDataMap[type]) {
    //             typeDataMap[type] = [];
    //         }

    //         typeDataMap[type].push(item);
    //     });

    //     // STEP 2: Process each type independently
    //     Object.keys(typeDataMap).forEach((type) => {
    //         const items = typeDataMap[type];

    //         // ❌ If ANY item has null → skip entire type
    //         const hasInvalid = items.some(
    //             (i) => i.actual_value === null || i.target_value === null
    //         );

    //         if (hasInvalid) {
    //             result[type] = null;
    //             return;
    //         }

    //         // ✅ Gauge
    //         if (!items[0].period) {
    //             result[type] = {
    //                 current: items[0].actual_value,
    //                 target: items[0].target_value,
    //             };
    //             return;
    //         }

    //         // ✅ Monthly
    //         items.forEach((item) => {
    //             const month = formatMonth(item.period);

    //             if (!result[type][month]) {
    //                 result[type][month] = {
    //                     actual: 0,
    //                     target: 0,
    //                 };
    //             }

    //             result[type][month].actual = item.actual_value;
    //             result[type][month].target = Math.max(
    //                 result[type][month].target,
    //                 item.target_value
    //             );
    //         });
    //     });

    //     return result;
    // };

    const ALL_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    const buildChartData = (monthlyObj = {}) => {
        return {
            labels: ALL_MONTHS,
            achievement: ALL_MONTHS.map((m) => monthlyObj[m]?.actual ?? 0),
            target: ALL_MONTHS.map((m) => monthlyObj[m]?.target ?? 0),
        };
    };

    // const chartsData = [
    //     {
    //         "chart_type": "NET_TOTAL_PREMIUM",
    //         "dealer_code": "K010801KBS1",
    //         "period": "2025-09",
    //         "actual_value": 414840,
    //         "target_value": 0
    //     },
    //     {
    //         "chart_type": "NET_TOTAL_PREMIUM",
    //         "dealer_code": "K010801KBS1",
    //         "period": "2025-10",
    //         "actual_value": 1067152,
    //         "target_value": null
    //     },
    //     {
    //         "chart_type": "NET_ADDON_PREMIUM",
    //         "dealer_code": "K010801KBS1",
    //         "period": "2025-09",
    //         "actual_value": 0,
    //         "target_value": 0
    //     },
    //     {
    //         "chart_type": "NET_ADDON_PREMIUM",
    //         "dealer_code": "K010801KBS1",
    //         "period": "2025-10",
    //         "actual_value": 205344,
    //         "target_value": null
    //     },
    //     {
    //         "chart_type": "NET_OD_PREMIUM",
    //         "dealer_code": "K010801KBS1",
    //         "period": "2025-09",
    //         "actual_value": 207272,
    //         "target_value": 0
    //     },
    //     {
    //         "chart_type": "NET_OD_PREMIUM",
    //         "dealer_code": "K010801KBS1",
    //         "period": "2025-10",
    //         "actual_value": 459792,
    //         "target_value": null
    //     },
    //     {
    //         "chart_type": "CONVERSION RATIO",
    //         "dealer_code": "K010801KBS1",
    //         "period": null,
    //         "actual_value": 11.43,
    //         "target_value": 0
    //     },
    //     {
    //         "chart_type": "CONVERSION RATIO",
    //         "dealer_code": "K010801KBS1",
    //         "period": null,
    //         "actual_value": 11.43,
    //         "target_value": null
    //     },
    //     {
    //         "chart_type": "RETENTION RATIO",
    //         "dealer_code": "K010801KBS1",
    //         "period": null,
    //         "actual_value": 200,
    //         "target_value": 0
    //     },
    //     {
    //         "chart_type": "RETENTION RATIO",
    //         "dealer_code": "K010801KBS1",
    //         "period": null,
    //         "actual_value": 66.67,
    //         "target_value": null
    //     }
    // ]

    const formatted = useMemo(() => {
        if (chartsData?.length) {
            return transformChartsData(chartsData);
        }

        return {
            NET_TOTAL_PREMIUM: {},
            NET_ADDON_PREMIUM: {},
            NET_OD_PREMIUM: {},
            CONVERSION_RATIO: {},
            RETENTION_RATIO: {},
        };
    }, [chartsData]);

    const hasTotalData = formatted?.NET_TOTAL_PREMIUM && Object.keys(formatted.NET_TOTAL_PREMIUM).length > 0;
    const hasaddOnData = formatted?.NET_ADDON_PREMIUM && Object.keys(formatted.NET_ADDON_PREMIUM).length > 0;
    const hasODData = formatted?.NET_OD_PREMIUM && Object.keys(formatted.NET_OD_PREMIUM).length > 0;

    const conversion = formatted?.CONVERSION_RATIO || {};
    const retention = formatted?.RETENTION_RATIO || {};
    const totalPremium = hasTotalData ? buildChartData(formatted.NET_TOTAL_PREMIUM) : null;
    const addonPremium = hasaddOnData ? buildChartData(formatted.NET_ADDON_PREMIUM) : null;
    const odPremium = hasODData ? buildChartData(formatted.NET_OD_PREMIUM) : null;

    const isNoData = !chartsData || chartsData.length === 0;

    // const isValidGauge = (obj) => {
    //     return obj && obj.current !== null && obj.current !== undefined;
    // };

    const isValidGauge = (obj) => {
        return obj && obj.current != null && obj.target != null;
    };

    const isValidChart = (obj) => {
        return (
            obj &&
            Object.keys(obj).length > 0 &&
            Object.values(obj).some(
                (m) => m.actual != null && m.target != null
            )
        );
    };

    console.log("chartsData = ", chartsData)

    return (
        <>
            <Paper className="body-formbg table-auto-width" elevation={0} sx={{ mx: 2, boxShadow: 'none' }}>
                {/* Header */}
                <Box display={"flex"} justifyContent={"space-between"} alignItems={"center"} my={1.5}>
                    <Typography className="georama-semiBold fs-20">
                        Target Planning
                    </Typography>
                    <Box>
                        <Button
                            className="btn-common-red"
                            onClick={() => {
                                downloadTargetChart({
                                    segment: selectedSegment,
                                    year: selectedYear,
                                    month: selectedMonth
                                });
                            }}
                            endIcon={<DownloadIcon />}
                            sx={{ borderRadius: 20, mx: 1 }}
                        >
                            Download
                        </Button>
                        {userDetails.roleType === "DEALER" && userBymanager?.length > 0 && (
                            <FormControl
                                size="small"
                                sx={{
                                    width: 250,
                                    minWidth: 150,
                                    maxWidth: 150,
                                    backgroundColor: "#ffffff",
                                    borderRadius: 2,
                                    mx: 1
                                }}
                            >
                                <InputLabel id="segment-label" className="dropdown-label">
                                    Team Member
                                </InputLabel>

                                <Select
                                    className="georama-Medium"
                                    labelId="segment-label"
                                    value={selectedSegment || ""}
                                    label="Team Member"
                                    open={segmentSelectOpen}
                                    onOpen={() => setSegmentSelectOpen(true)}
                                    onClose={() => setSegmentSelectOpen(false)}
                                    MenuProps={{
                                        disableAutoFocusItem: true,
                                        disableScrollLock: true,
                                        MenuListProps: {
                                            onMouseDown: (e) => e.stopPropagation()
                                        }
                                    }}
                                    // onClose={(event, reason) => {
                                    //     if (reason === "backdropClick" || reason === "escapeKeyDown") {
                                    //         setSegmentSelectOpen(false);
                                    //     }
                                    // }}
                                    onChange={() => { }}
                                    renderValue={(selected) => {
                                        const selectedItem = teamData?.find(
                                            (seg) => seg.teamMemberId === selected
                                        );
                                        return selectedItem?.teamMemberName || "Select";
                                    }}
                                // MenuProps={{
                                //     disableAutoFocusItem: true,
                                //     disableScrollLock: true,
                                //     MenuListProps: {
                                //         onMouseDown: (e) => e.stopPropagation() // 🔥 prevent close
                                //     },
                                //     PaperProps: {
                                //         sx: {
                                //             maxHeight: 260,
                                //             overflow: "hidden"
                                //         }
                                //     }
                                // }}
                                >
                                    {/* TEAM MEMBER LIST */}
                                    <Box sx={{ maxHeight: 180, overflowY: "auto" }}>
                                        {teamData?.map((seg) => (
                                            <MenuItem
                                                key={seg.teamMemberId}
                                                value={seg.teamMemberId}
                                                disableRipple
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    e.stopPropagation(); // 🔥 CRITICAL

                                                    setSelectedSegment(seg.teamMemberId);
                                                    setSelectedYear("");
                                                    setSelectedMonth("");
                                                }}
                                                sx={{
                                                    backgroundColor:
                                                        selectedSegment === seg.teamMemberId
                                                            ? "#ffe5e5"
                                                            : "transparent",
                                                    borderLeft:
                                                        selectedSegment === seg.teamMemberId
                                                            ? "4px solid #e53935"
                                                            : "4px solid transparent",
                                                }}
                                            >
                                                {seg.teamMemberName}
                                            </MenuItem>
                                        ))}
                                    </Box>

                                    {/* ACTION BUTTONS */}
                                    <Box display="flex" justifyContent="end">

                                        <Button
                                            fullWidth
                                            size="small"
                                            onClick={(e) => {
                                                // e.stopPropagation();
                                                setSelectedSegment("");
                                                fetchChartData({
                                                    segment: "",
                                                    year: "",
                                                    month: ""
                                                });
                                                setSegmentSelectOpen(false);
                                            }}
                                            sx={{
                                                border: "1px solid gray",
                                                borderRadius: 8,
                                                boxShadow: "none",
                                                px: 1,
                                                my: 1,
                                                mx: 1,
                                                color: "black",
                                                backgroundColor: "transparent",
                                            }}
                                        >
                                            Clear
                                        </Button>

                                        <Button
                                            className="btn-common-red"
                                            size="small"
                                            sx={{ mx: 2, my: 1, ...btnRed }}
                                            onClick={(e) => {
                                                // e.stopPropagation();
                                                if (selectedSegment) {
                                                    fetchChartData({
                                                        segment: selectedSegment,
                                                        year: '',
                                                        month: ''
                                                    });
                                                    setSegmentSelectOpen(false);
                                                }
                                            }}
                                        >
                                            Apply
                                        </Button>

                                    </Box>

                                </Select>
                            </FormControl>
                        )}

                        {(userBymanager == null || (selectedSegment && yearData?.length > 0)) && (<FormControl
                            size="small"
                            sx={{
                                mx: 1,
                                width: 120,
                                background: "#fff",
                                borderRadius: 2
                            }}>
                            <InputLabel>Year</InputLabel>
                            <Select
                                disabled={userBymanager?.length > 0 === !selectedSegment}
                                value={selectedYear || ""}
                                open={yearOpen}
                                label="Year"
                                onOpen={() => setYearOpen(true)}
                                onClose={() => setYearOpen(false)}
                                MenuProps={{
                                    disableAutoFocusItem: true,
                                    disableScrollLock: true,
                                    MenuListProps: {
                                        onMouseDown: (e) => e.stopPropagation()
                                    }
                                }}
                                // onClose={(event, reason) => {
                                //     if (reason === "backdropClick" || reason === "escapeKeyDown") {
                                //         setYearOpen(false);
                                //     }
                                onChange={() => { }}
                                renderValue={(selected) => {
                                    const selectedItem = yearData.find(y => y.id === selected);
                                    return selectedItem?.name || "Select";
                                }}
                            // MenuProps={{
                            //     disableAutoFocusItem: true,
                            //     disableScrollLock: true,
                            //     MenuListProps: {
                            //         onMouseDown: (e) => e.stopPropagation()
                            //     },
                            //     PaperProps: {
                            //         sx: {
                            //             maxHeight: 260,
                            //             overflow: "hidden"
                            //         }
                            //     }
                            // }}
                            >
                                {/* YEAR LIST */}
                                <Box sx={{ maxHeight: 180, overflowY: "auto" }}>
                                    {yearData?.map((y) => (
                                        <MenuItem
                                            key={y.id}
                                            value={y.id}
                                            disableRipple
                                            onClick={(e) => {
                                                e.preventDefault();
                                                e.stopPropagation();

                                                setSelectedYear(y.id);
                                                setSelectedMonth("");
                                            }}
                                            sx={{
                                                backgroundColor: selectedYear === y.id ? "#ffe5e5" : "transparent",
                                                borderLeft: selectedYear === y.id
                                                    ? "4px solid #e53935"
                                                    : "4px solid transparent",
                                            }}
                                        >
                                            {y.name}
                                        </MenuItem>
                                    ))}
                                </Box>

                                {/* ACTION BUTTONS */}
                                <Box display="flex" justifyContent="end" px={1}>

                                    <Button
                                        onClick={(e) => {
                                            // e.stopPropagation();
                                            setSelectedYear("");
                                            setYearOpen(false);
                                            fetchChartData({
                                                segment: selectedSegment,
                                                year: "",
                                                month: ""
                                            });
                                        }}
                                        size="small"
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: 'none',
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: 'transparent'
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        variant="contained"
                                        size="small"
                                        className='btn-common-red'
                                        sx={{ width: "50%", mx: 1, my: 1, ...btnRed }}
                                        onClick={(e) => {
                                            // e.stopPropagation();
                                            if (selectedYear) {
                                                fetchChartData({
                                                    segment: selectedSegment,
                                                    year: selectedYear,
                                                    month: ''
                                                }); // ✅ API CALL
                                                setYearOpen(false);
                                            }
                                        }}
                                    >
                                        Apply
                                    </Button>

                                </Box>

                            </Select>
                        </FormControl>)}

                        {((userBymanager == null && selectedYear) || (userBymanager?.length > 0 === (selectedSegment && selectedYear && monthData?.length > 0))) && (<FormControl
                            size="small"
                            sx={{
                                mx: 1,
                                minWidth: 130,
                                maxWidth: 130,
                                background: "#fff",
                                borderRadius: 2
                            }}>
                            <InputLabel id="month-label" className="dropdown-label">
                                Month
                            </InputLabel>
                            <Select
                                disabled={userBymanager?.length > 0 ? (!selectedSegment || !selectedYear && !monthData) : (!selectedYear && !monthData)}
                                value={selectedMonth || ""}
                                open={monthOpen}
                                label="Month"
                                onOpen={() => setMonthOpen(true)}
                                onClose={() => setMonthOpen(false)}
                                MenuProps={{
                                    disableAutoFocusItem: true,
                                    disableScrollLock: true,
                                    MenuListProps: {
                                        onMouseDown: (e) => e.stopPropagation()
                                    }
                                }}
                                // onClose={(event, reason) => {
                                //     if (reason === "backdropClick" || reason === "escapeKeyDown") {
                                //         setMonthOpen(false);
                                //     }
                                // }}
                                onChange={() => { }}
                                renderValue={(selected) => selected || "Select"}
                            // MenuProps={{
                            //     disableAutoFocusItem: true,
                            //     disableScrollLock: true,
                            //     MenuListProps: {
                            //         onMouseDown: (e) => e.stopPropagation()
                            //     },
                            //     PaperProps: {
                            //         sx: {
                            //             maxHeight: 260,
                            //             overflow: "hidden"
                            //         }
                            //     }
                            // }}
                            >
                                {/* MONTH LIST */}
                                <Box sx={{ maxHeight: 180, overflowY: "auto" }}>
                                    {monthData?.map((month) => (
                                        <MenuItem
                                            key={month}
                                            value={month}
                                            disableRipple
                                            onClick={(e) => {
                                                e.preventDefault();
                                                e.stopPropagation();

                                                setSelectedMonth(month);
                                            }}
                                            sx={{
                                                backgroundColor: selectedMonth === month ? "#ffe5e5" : "transparent",
                                                borderLeft: selectedMonth === month
                                                    ? "4px solid #e53935"
                                                    : "4px solid transparent",
                                            }}
                                        >
                                            {month}
                                        </MenuItem>
                                    ))}
                                </Box>

                                {/* ACTION BUTTONS */}
                                <Box display="flex" justifyContent="end" px={1}>
                                    <Button
                                        onClick={(e) => {
                                            // e.stopPropagation();
                                            setSelectedMonth("");
                                            setMonthOpen(false);
                                            fetchChartData({
                                                segment: selectedSegment,
                                                year: selectedYear,
                                                month: ""
                                            });
                                        }}
                                        size="small"
                                        sx={{
                                            width: "50%",
                                            border: "1px solid gray",
                                            borderRadius: 8,
                                            boxShadow: "none",
                                            px: 1,
                                            my: 1,
                                            ml: 1,
                                            color: "black",
                                            backgroundColor: "transparent"
                                        }}
                                    >
                                        Clear
                                    </Button>

                                    <Button
                                        onClick={(e) => {
                                            // e.stopPropagation();
                                            if (selectedMonth) {
                                                fetchChartData({
                                                    segment: selectedSegment,
                                                    year: selectedYear,
                                                    month: selectedMonth
                                                });
                                                setMonthOpen(false);
                                            }
                                        }}
                                        variant="contained"
                                        size="small"
                                        className="btn-common-red"
                                        sx={{ width: "50%", mx: 1, my: 1, ...btnRed }}
                                    >
                                        Apply
                                    </Button>
                                </Box>
                            </Select>
                        </FormControl>)}

                        <Button className="highlight-red text-capitalize" sx={{ mr: 3 }}
                            onClick={() => navigate(`/${encodeURIComponent(encryptRoute('/target'))}`)}>
                            {"<"} Back
                        </Button>
                    </Box>
                </Box>

                {isNoData ? (
                    <Box
                        sx={{
                            position: "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            textAlign: "center"
                        }}
                    >
                        <img width={400} src={nodata1} alt="No Data" />
                    </Box>
                ) : (
                    <Grid container spacing={2}>
                        {isValidGauge(conversion) && (
                            <Grid className="bg-white" size={{ lg: 6, md: 6, sm: 12 }} sx={{ p: 3, borderRadius: 3, position: "relative" }}>
                                {/* {Object.keys(formatted).length > 0 && ( */}
                                <>
                                    <GaugeChart
                                        key={`conversion-${conversion.current}`}
                                        title="Conversion Ratios"
                                        current={conversion.current}
                                        target={conversion.target}
                                        tooltip="(Policy Secured Against Leads Contacted / Leads Contacted) × 100"
                                    />
                                </>
                                {/* )} */}
                            </Grid>
                        )}

                        {isValidGauge(retention) && (
                            <Grid className="bg-white" size={{ lg: 6, md: 6, sm: 12 }} sx={{ p: 3, borderRadius: 3, position: "relative" }}>
                                {/* {Object.keys(formatted).length > 0 && ( */}
                                <>
                                    <GaugeChart
                                        key={`retention-${retention.current}`}
                                        title="Retention Ratios"
                                        current={retention.current}
                                        target={retention.target}
                                        tooltip="(Policies Secured / Eligible Leads) × 100"
                                    />
                                </>
                                {/* )} */}
                            </Grid>
                        )}

                        {totalPremium && (
                            <Grid className="bg-white" size={{ lg: 6, md: 6, sm: 12 }} sx={{ p: 1, borderRadius: 3 }}>
                                <NetTotalPremium data={totalPremium} />
                            </Grid>
                        )}

                        {addonPremium && (
                            <Grid className="bg-white" size={{ lg: 6, md: 6, sm: 12 }} sx={{ p: 1, borderRadius: 3 }}>
                                <NetAddonPremium data={addonPremium} />
                            </Grid>
                        )}

                        {odPremium && (
                            <Grid className="bg-white" size={{ lg: 12, md: 6, sm: 12 }} sx={{ p: 1, borderRadius: 3 }}>
                                <NetODPremium data={odPremium} />
                            </Grid>
                        )}
                    </Grid>
                )}
            </Paper >

            <BackdropLoader loading={loading} />
        </>
    )
}

export default ViewCharts