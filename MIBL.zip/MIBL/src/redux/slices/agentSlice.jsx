import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    dashboardAccess: false,
};

const agentSlice = createSlice({
    name: 'agent',
    initialState,
    reducers: {
        grantAccess: (state) => {
            state.dashboardAccess = true;
        },
        revokeAccess: (state) => {
            state.dashboardAccess = false;
        },
    },
});

export const { grantAccess, revokeAccess } = agentSlice.actions;
export default agentSlice.reducer;
