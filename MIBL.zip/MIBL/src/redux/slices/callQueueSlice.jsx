import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  search: {
    name: '', phoneNumber: '', vinNumber: '', registrationNo: '', policyNo: '', policyTenure: '', policyType: '', make: '', model: '', variant: '', vehicleClass: '', engineNo: ''
  },
  count: 0,
  todayCount: 0,
  miblCount: 0,
  callQueueType: '',
  page: 1,
  selectedFilters: {},
  selectedFilter: '',
  searchType: '',
  callToggle: ['', 'current', 'mibl'],
  filterName: '',
  filters: {},
  activeFilterField: null,
  filterValues: {
    'Renewal Category': [],
    'Expiry Days': '',
    'Recent Updates': [],
    'Status': [],
    'Lead': ['Hot', 'Warm', 'Cold'],
    'EBM': []//['Quote Shared', 'Insurer Selected', 'Declaration Acknowledged', 'CKYC Completed','Proposal Confirmed','Payment Confirmed', 'Policy Issued', 'Policy Booked'],
  },
  sortField: '',
  sortOrder: '',
  ebmColorList: {
    "Quote Shared": "#3498DB",
    "Insurer Selected": "#9B59B6",
    "Declaration Acknowledged": "#F39C12",
    "CKYC Completed": "#2ECC71",
    "Proposal Confirmed": "#F39C12",
    "Payment Completed": "#2ECC71",
    "Policy Issued": "#E74C3C",
    "Policy Booked": "#3498DB"
  },
  fromDate: null,
  toDate: null
};

const callQueueSlice = createSlice({
  name: 'callQueue',
  initialState,
  reducers: {
    setSearch: (state, action) => {
      state.search = action.payload;
    },
    setCount: (state, action) => {
      state.count = action.payload;
    },
    setTodayCount: (state, action) => {
      state.todayCount = action.payload;
    },
    setMIBLcount: (state, action) => {
      state.miblCount = action.payload;
    },
    setCallQueueType: (state, action) => {
      state.callQueueType = action.payload;
      state.page = 1;
    },
    setPage: (state, action) => {
      state.page = action.payload;
    },
    setSelectedFilters: (state, action) => {
      state.selectedFilters = action.payload;
    },
    setSelectedFilter: (state, action) => {
      state.selectedFilter = action.payload;
    },
    setSearchType: (state, action) => {
      state.searchType = action.payload;
    },
    setCallToggle: (state, action) => {
      state.callToggle = action.payload;
    },
    setFilterName: (state, action) => {
      state.filterName = action.payload;
    },
    setFilters: (state, action) => {
      state.filters = action.payload;
    },
    setActiveFilterField: (state, action) => {
      state.activeFilterField = action.payload;
    },
    setFilterValues: (state, action) => {
      state.filterValues = action.payload;
    },
    setSortField: (state, action) => {
      state.sortField = action.payload;
    },
    setSortOrder: (state, action) => {
      state.sortOrder = action.payload;
    },
    setFromDate: (state, action) => {
      state.fromDate = action.payload;
    },
    setToDate: (state, action) => {
      state.toDate = action.payload;
    },
  },
});

export const {
  setSearch,
  setCount,
  setTodayCount,
  setMIBLcount,
  setCallQueueType,
  setPage,
  setSelectedFilters,
  setSelectedFilter,
  setSearchType,
  setCallToggle,
  setFilterName,
  setFilters,
  setActiveFilterField,
  setFilterValues,
  setSortField,
  setSortOrder,
  setFromDate,
  setToDate
} = callQueueSlice.actions;

export default callQueueSlice.reducer;
