import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    leadSummary: [],
    dispositionSummary: [],
    subDispositionSummary: [],
    leadConversiondata: [],
    segmentData: [],
    teamMembersData: [],
    recentlyConverted: [],


    // for admin
    adminLeadStatus: [],
    adminLeadConversion: [],
    zoneList: [],
    stateList: [],
    dealerList: [],
    branchList: [],
    segmentList: [],
    InactiveLeads: [],
    conversionTrendsData: [],
    hasFetched: false,

    // for renewal
    renewaldispositionSummary: [],
    renewalLeadsAssigned: [],
    renewalDailyWeeklyTrends: [],



    // for renewal filter Data
    dealerListData: [],
    agentList: [],
    LeadTypeList: [],
    vehicleType: [],
    segment: [],
    sourceData: [],
    currentDisposition: [],
    conversionStatus: [],


    // Target year data 
    yearData: []
};

const dashboardSlice = createSlice({
    name: 'dashboard',
    initialState,
    reducers: {
        setLeadSummary: (state, action) => {
            state.leadSummary = action.payload;
        },
        setDispositionSummary: (state, action) => {
            state.dispositionSummary = action.payload;
        },
        setSubDispositionSummary: (state, action) => {
            state.subDispositionSummary = action.payload;
        },
        setLeadConversion: (state, action) => {
            state.leadConversiondata = action.payload;
        },
        setSegmentData: (state, action) => {
            state.segmentData = action.payload;
        },
        setTeamMembersData: (state, action) => {
            state.teamMembersData = action.payload;
        },
        setRecentlyConverted: (state, action) => {
            state.recentlyConverted = action.payload;
        },



        // for admin dashboard
        setAdminLeadStatus: (state, action) => {
            state.adminLeadStatus = action.payload;
        },
        setAdminLeadConversion: (state, action) => {
            state.adminLeadConversion = action.payload;
        },
        setZoneList: (state, action) => {
            state.zoneList = action.payload;
        },
        setStateList: (state, action) => {
            state.stateList = action.payload;
        },
        setDealerList: (state, action) => {
            state.dealerList = action.payload;
        },
        setBranchList: (state, action) => {
            state.branchList = action.payload;
        },
        setSegmentList: (state, action) => {
            state.segmentList = action.payload;
        },
        setInactiveLeadsList: (state, action) => {
            state.InactiveLeads = action.payload;
        },
        setConversionTrends: (state, action) => {
            state.conversionTrendsData = action.payload;
        },
        setDashboardFetched: (state) => {
            state.hasFetched = true;
        },



        // renewal dashboard
        setRenewalDisposition: (state, action) => {
            state.renewaldispositionSummary = action.payload;
        },
        setRenewalLeadsAssigned: (state, action) => {
            state.renewalLeadsAssigned = action.payload;
        },
        setDailyWeeklyTrends: (state, action) => {
            state.renewalDailyWeeklyTrends = action.payload;
        },




        // for renewal dashboard filter data
        setDealerListData: (state, action) => {
            state.dealerListData = action.payload;
        },
        setAgentListData: (state, action) => {
            state.agentList = action.payload;
        },
        setLeadTypeListData: (state, action) => {
            state.LeadTypeList = action.payload;
        },
        setvehicleTypeData: (state, action) => {
            state.vehicleType = action.payload;
        },
        setSegmentDataList: (state, action) => {
            state.segment = action.payload;
        },
        setsourceDataList: (state, action) => {
            state.sourceData = action.payload;
        },
        setcurrentDispositionList: (state, action) => {
            state.currentDisposition = action.payload;
        },
        setconversionStatusList: (state, action) => {
            state.conversionStatus = action.payload;
        },

        // target years data
        setYearList: (state, action) => {
            state.yearData = action.payload;
        }
    },
});

export const {
    setLeadSummary,
    setDispositionSummary,
    setSubDispositionSummary,
    setLeadConversion,
    setRecentlyConverted,
    setSegmentData,
    setTeamMembersData,
    setAdminLeadStatus,
    setAdminLeadConversion,
    setRenewalDisposition,
    setRenewalLeadsAssigned,
    setDailyWeeklyTrends,
    setZoneList,
    setStateList,
    setDealerList,
    setBranchList,
    setSegmentList,
    setInactiveLeadsList,
    setConversionTrends,
    setDashboardFetched,
    setDealerListData,
    setAgentListData,
    setLeadTypeListData,
    setvehicleTypeData,
    setSegmentDataList,
    setsourceDataList,
    setcurrentDispositionList,
    setconversionStatusList,
    setYearList
} = dashboardSlice.actions;
export default dashboardSlice.reducer;