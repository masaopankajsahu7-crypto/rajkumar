import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  list: [],
};

const dealerSlice = createSlice({
  name: 'dealers',
  initialState,
  reducers: {
    setDealers: (state, action) => {
      state.list = action.payload;
    },
    clearDealers: (state) => {
      state.list = [];
    },
  },
});

export const { setDealers, clearDealers } = dealerSlice.actions;
export default dealerSlice.reducer;
