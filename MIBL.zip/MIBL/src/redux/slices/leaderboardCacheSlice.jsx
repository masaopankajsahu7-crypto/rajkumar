import { createSlice } from '@reduxjs/toolkit';

const DEFAULT_TTL_MS = 5 * 60 * 1000; // 3 minutes

const initialState = {
    ttlMs: DEFAULT_TTL_MS,
    entries: {}
};

const leaderboardCacheSlice = createSlice({
    name: 'leaderboardCache',
    initialState,
    reducers: {
        setLeaderboardCacheTtl: (state, action) => {
            state.ttlMs = Number(action.payload) || DEFAULT_TTL_MS;
        },
        setLeaderboardCacheEntry: (state, action) => {
            const { key, data, ttlMs } = action.payload || {};
            if (!key) return;

            const effectiveTtl = Number(ttlMs) || state.ttlMs || DEFAULT_TTL_MS;
            state.entries[key] = {
                data,
                createdAt: Date.now(),
                expiresAt: Date.now() + effectiveTtl
            };
        },
        clearLeaderboardCacheEntry: (state, action) => {
            const key = action.payload;
            if (!key) return;
            delete state.entries[key];
        },
        clearLeaderboardCache: (state) => {
            state.entries = {};
        },
        pruneLeaderboardCache: (state) => {
            const now = Date.now();
            Object.keys(state.entries).forEach((key) => {
                if ((state.entries[key]?.expiresAt || 0) <= now) {
                    delete state.entries[key];
                }
            });
        }
    }
});

export const {
    setLeaderboardCacheTtl,
    setLeaderboardCacheEntry,
    clearLeaderboardCacheEntry,
    clearLeaderboardCache,
    pruneLeaderboardCache
} = leaderboardCacheSlice.actions;

export const selectLeaderboardCacheEntryByKey = (state, key) => {
    const entry = state.leaderboardCache?.entries?.[key];
    if (!entry) return null;
    if ((entry.expiresAt || 0) <= Date.now()) return null;
    return entry.data;
};

export default leaderboardCacheSlice.reducer;
