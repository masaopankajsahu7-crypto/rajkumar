import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    mispOutletData: []
};

const mispSlice = createSlice({
    name: 'mispOutlet',
    initialState: initialState,
    reducers: {
        setMISPData(state, action) {
            state.mispOutletData = action.payload;
        },
        
    },
});

export const { setMISPData } = mispSlice.actions;
export default mispSlice.reducer;
