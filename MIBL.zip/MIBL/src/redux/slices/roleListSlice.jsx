import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    search: '',
    page: 1,
    roleType: '',
    roles: [],
    formValues: {
        dealer: '',
        parentCode: '',
    },
};

const roleListSlice = createSlice({
    name: 'roleList',
    initialState,
    reducers: {
        setSearch: (state, action) => {
            state.search = action.payload;
            state.page = 1; // reset page on search
        },
        setPage: (state, action) => {
            state.page = action.payload;
        },
        setRoleType: (state, action) => {
            state.roleType = action.payload;
            state.page = 1; // reset page on change
        },
        setRoles: (state, action) => {
            state.roles = action.payload;
        },
        setFormValues: (state, action) => {
            state.formValues = { ...state.formValues, ...action.payload };
            state.page = 1; // reset page on filter change
        },
        resetRoleListState: () => initialState,
    },
});

export const {
    setSearch,
    setPage,
    setRoleType,
    setRoles,
    setFormValues,
    resetRoleListState,
} = roleListSlice.actions;

export default roleListSlice.reducer;