import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    loggedData: null,
    loggedIn: false,
    token: '',
    featureAccess: [],
    isCaller: 'caller',
    userName: '',
    fetchUserByManager: [],
    credFlag: [],
    inputUser: '',
    faqData: [],
    ebmauthToken: ""
};

const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        setInputUser(state, action) {
            state.inputUser = action.payload;
        },
        setFaqData(state, action) {
            state.faqData = action.payload;
        },
        setLogin(state, action) {
            state.loggedData = action.payload.user;
            state.loggedIn = action.payload.loggedIn;
            state.token = action.payload.token;
            state.featureAccess = action.payload.featureAccess;
        },
        setUserName(state, action) {
            state.userName = action.payload;
        },
        setLogout(state) {
            state.loggedData = null;
            state.loggedIn = false;
            state.token = '';
        },
        setIsCaller(state, action) {
            state.isCaller = action.payload;
        },
        setFetchUserByManager(state, action) {
            state.fetchUserByManager = action.payload;
        },
        setUserData(state, action) {
            state.loggedData = action.payload;
        },
        setCredFlag(state) {
            state.credFlag = true;
        },
        setEbmAuthenToken(state, action) {
            state.ebmauthToken = action.payload;
        }
    },
});

export const { setInputUser, setLogin, setFaqData, setLogout, setUserName, setIsCaller, setFetchUserByManager, setUserData, setCredFlag, setEbmAuthenToken } = userSlice.actions;
export default userSlice.reducer;