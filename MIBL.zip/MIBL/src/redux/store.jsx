import { configureStore } from '@reduxjs/toolkit';
import { persistReducer } from "redux-persist";
import persistStore from 'redux-persist/es/persistStore';
import storage from "redux-persist/lib/storage";
import { combineReducers } from "redux";

import userReducer from './slices/userSlice';
import agentReducer from './slices/agentSlice';
import dealerReducer from './slices/dealerSlice';
import mispReducer from './slices/mispSlice';
import dashboardReducer from './slices/dashboardSlice';
import callQueueReducer from './slices/callQueueSlice';
import roleListReducer from './slices/roleListSlice';
import leaderboardCacheReducer from './slices/leaderboardCacheSlice';

const appReducer = combineReducers({
    user: userReducer,
    agent: agentReducer,
    dealers: dealerReducer,
    mispData: mispReducer,
    dashboard: dashboardReducer,
    callQueue: callQueueReducer,
    roleList: roleListReducer,
    leaderboardCache: leaderboardCacheReducer,
});

// 🔥 Short reset trick
const rootReducer = (state, action) => {
    if (action.type === 'RESET_ALL_STATE') {
        state = undefined; // Reset everything
    }
    return appReducer(state, action);
};

const persistConfig = {
    key: "mahindra-insurance",
    version: 1,
    storage,
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
    reducer: persistedReducer,
});

export const persistor = persistStore(store);

export default store;
