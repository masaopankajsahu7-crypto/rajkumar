export const policyDetails = {
  "statusCode": "0000",
  "statusMessage": "fetch the details successfully ",
  "policyDbColName": [
    {
      "required": "false",
      "columnName": "policy_id",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "dealer_code",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "dealer",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "insurance_company",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "policy_no",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "policy_tenure",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "policy_type",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "insured_name",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "customer_address",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "customer_state",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "customer_city",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "customer_pincode",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "customer_phone",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "customer_email",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "vehicle_reg_no",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "yom",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "ncb_percentage",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "vehicle_class",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "vehicle_sub_class",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "carrier_type",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "policy_effective_date",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "policy_expiry_date",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "make",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "model",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "vehicle_body_type",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "fuel_type",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "variant",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "vin",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "engine_no",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "payment_mode",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "od_discount_percentage",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "total_idv",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "addon_premium_amount",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "net_od_premium_amount",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "third_party_liability",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "pa_cover",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "legal_liability",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "net_liability",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "net_premium",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "imt_23",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "gross_premium",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "rto_display_name",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "previous_policy_no",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "previous_insurance_company",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "podc_start",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "podc_end",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "plc_start",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "plc_end",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "third_party_liability_bifuel_kit",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "trailer_imt30",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "imt_34tp",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "pa_cover_unnamed_persons_imt16",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "geographical_areas_extention_imt1",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "tpgeographical_areas_extention_imt1",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "legal_liability_nfpp_imt37",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "pa_cover_owner_driver",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "oem_code",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "proposal_no",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "plan_type",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "ebm_calls",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "zd",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "bundle_product",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "invoice_date",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "cancellation_flag",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "true",
      "columnName": "reg_no",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "i_date",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "m_date",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "m_user",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "version",
      "dbName": "mmi_audit_policy_data"
    },
    {
      "required": "false",
      "columnName": "cluster_id",
      "dbName": "mmi_audit_policy_data"
    }
  ],
  "claimDbColName": [
    {
      "required": "false",
      "columnName": "policy_id",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "policy_no",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "claim_no",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "claim_intimation_date_time",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "accident_city",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "nature_of_loss",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "insurance_claim_no",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "claim_status",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "false",
      "columnName": "total_estimate_amount",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "false",
      "columnName": "amount_paid",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "workshop_name",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "workshop_state",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "workshop_city",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "last_modified_date",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "chassis_number",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "engine_no",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "reg_no",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "false",
      "columnName": "i_date",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "false",
      "columnName": "m_date",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "false",
      "columnName": "m_user",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "false",
      "columnName": "version",
      "dbName": "mmi_audit_claim_data"
    },
    {
      "required": "true",
      "columnName": "risk_start_date",
      "dbName": "mmi_audit_claim_data"
    }
  ],
  "salesDbColName": [
    {
      "required": "true",
      "columnName": "invoice_number",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "true",
      "columnName": "invoice_date_time",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "true",
      "columnName": "dealer_parent_code",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "true",
      "columnName": "chassis_number",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "true",
      "columnName": "engine_number",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "true",
      "columnName": "dealer_parent_name",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "true",
      "columnName": "dealer_location_code",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "true",
      "columnName": "branch_name",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "false",
      "columnName": "sc_code",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "false",
      "columnName": "sc_name",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "false",
      "columnName": "i_date",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "false",
      "columnName": "m_date",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "false",
      "columnName": "m_user",
      "dbName": "mmi_audit_sales_data"
    },
    {
      "required": "false",
      "columnName": "version",
      "dbName": "mmi_audit_sales_data"
    }
  ],
  "serviceDbColName": [
    {
      "required": "true",
      "columnName": "repair_order_no",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "true",
      "columnName": "ro_date",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "true",
      "columnName": "service_category",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "true",
      "columnName": "service_type",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "true",
      "columnName": "registration_no",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "true",
      "columnName": "chassis_number",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "true",
      "columnName": "engine_number",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "true",
      "columnName": "customer_mobile_no",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "true",
      "columnName": "service_advisor",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "false",
      "columnName": "ro_bill_date_time",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "false",
      "columnName": "ro_status",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "false",
      "columnName": "i_date",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "false",
      "columnName": "m_date",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "false",
      "columnName": "m_user",
      "dbName": "mmi_audit_service_data"
    },
    {
      "required": "false",
      "columnName": "version",
      "dbName": "mmi_audit_service_data"
    }
  ],
  "addOnDbColName": [
    {
      "required": "false",
      "columnName": "policy_id",
      "dbName": "mmi_poladdon_data"
    },
    {
      "required": "false",
      "columnName": "add_on_name",
      "dbName": "mmi_poladdon_data"
    },
    {
      "required": "false",
      "columnName": "bundle_name",
      "dbName": "mmi_poladdon_data"
    },
    {
      "required": "false",
      "columnName": "premium",
      "dbName": "mmi_poladdon_data"
    },
    {
      "required": "false",
      "columnName": "i_date",
      "dbName": "mmi_poladdon_data"
    },
    {
      "required": "false",
      "columnName": "m_date",
      "dbName": "mmi_poladdon_data"
    },
    {
      "required": "false",
      "columnName": "m_user",
      "dbName": "mmi_poladdon_data"
    }
  ],
  "dealerLocations": [
    {
      "searchName": "",
      "dealerId": "1",
      "dealerLocCode": "AGR1",
      "dealerLocName": "MIRZAPUR"
    },
    {
      "searchName": "",
      "dealerId": "1",
      "dealerLocCode": "AGR2",
      "dealerLocName": "SONBHADRA"
    },
    {
      "searchName": "",
      "dealerId": "1",
      "dealerLocCode": "AGR3",
      "dealerLocName": "ANPARA MASP+MDSC"
    }
  ],
  "leadAssign": [
    {
      "id": "1",
      "searchName": "",
      "leadName": "Admin admin"
    },
    {
      "id": "2",
      "searchName": "",
      "leadName": "misp misp"
    },
    {
      "id": "3",
      "searchName": "",
      "leadName": "manager manager"
    },
    {
      "id": "4",
      "searchName": "",
      "leadName": "agent agent"
    }
  ],
  "totalDealerDetails": 0
}