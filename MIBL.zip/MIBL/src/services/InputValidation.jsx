const handleSearchInput = (key, value) => {
    let isValid = false;

    switch (key) {
        case 'name':
            isValid = /^[A-Za-z .]{0,30}$/.test(value);
            if ((value === '' || isValid) && value.length <= 30) {
                setSearch(prev => ({ ...prev, [key]: value }));
            }
            break;

        case 'phoneNumber':
            isValid = /^[0-9]{0,10}$/.test(value);
            if (value === '' || isValid) {
                setSearch(prev => ({ ...prev, [key]: value }));
            }
            break;

        case 'vinNumber':
            isValid = /^[A-Za-z0-9]{0,17}$/.test(value);
            if (value === '' || isValid) {
                setSearch(prev => ({ ...prev, [key]: value }));
            }
            break;

        case 'registrationNo':
            isValid = /^[A-Za-z0-9-]{0,50}$/.test(value);
            if (value === '' || isValid) {
                setSearch(prev => ({ ...prev, [key]: value }));
            }
            break;

        default:
            setSearch(prev => ({ ...prev, [key]: value }));
    }
};
