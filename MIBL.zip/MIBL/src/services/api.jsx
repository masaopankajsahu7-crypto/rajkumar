import axios from 'axios';
import { baseUrl } from '../env/env';
import axiosInstance from './axiosInstance';
import { encryptPayload } from './encryptRequest';

export const login = async ({ checkLoginType, email, password, forceLogin = false }) => {
    try {
        const result = await axios.post(`${baseUrl}/authCheck`, await encryptPayload({
            checkLoginType,
            email,
            password,
        }), {
            headers: { 'Content-Type': 'application/json', forceLogout: forceLogin },
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const otpVerification = async (data) => {
    try {
        const result = await axios.post(`${baseUrl}/otpVerification`, await encryptPayload(data), {
            headers: { 'Content-Type': 'application/json', 'userName': data?.email, 'Authorization': `Bearer ${data?.token}` },
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const sendOTP = async (email) => {
    try {
        const result = await axios.post(`${baseUrl}/sendOTP`, await encryptPayload({
            email
        }), {
            headers: {
                'Content-Type': 'application/json',
                'userName': email,
            },

        });
        return result;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const logout = async (username) => {
    try {
        const result = await axiosInstance.post(`/Logout`, { username }
            , {
                headers: { 'Content-Type': 'application/json' },
            });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const verifyOTP = async (data) => {
    try {
        const result = await axios.post(`${baseUrl}/verifyOTP`, await encryptPayload(data), {
            headers: { 'Content-Type': 'application/json' },

        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const resetPasswordUser = async (data) => {
    try {
        const result = await axios.post(`${baseUrl}/resetPassword`, await encryptPayload(data), {
            headers: { 'Content-Type': 'application/json' },

        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const changePasswordUser = async (data) => {
    try {
        const result = await axios.post(`${baseUrl}/changePassword`, await encryptPayload(data), {
            headers: { 'Content-Type': 'application/json' },

        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const getHeaders = async (data) => {
    try {
        const result = await axiosInstance.post(`/getallcrminputs`, {
            pageId: data.pageId,
            userId: data.user_id,
            accessType: data.accessType,
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const newDealerSetUp = async () => {
    try {
        const result = await axiosInstance.post(`/newDealerSetUp`, {
            type: 'newDealerSetUp',
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const getMISPOutletDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/getalldealerdetails`, {
            limit: data.limit || 10,
            offset: data.page || 1,
            searchName: data.search || '',
            sortField: data.sortField || '',
            sortOrder: data.sortOrder || '',
            type: 'getdealerdetails'
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const editOutletDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/editDealerList`, {
            limit: data.limit || 10,
            offset: data.page || 1,
            searchName: data.search || '',
            sortField: data.sortField || '',
            sortOrder: data.sortOrder || '',
            type: 'editDealerList'
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const getCallQueueDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/getcallqueuedetails`, {
            limit: data.limit || 10,
            offset: data.page || 1,
            userId: data.userId || 1,
            callQueType: data.callQueueType,
            type: "getcallqueuedetails",
            sortField: data.sortField,
            sortOrder: data.sortOrder,
            dealerCode: data.dealerCode
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result;
    } catch (error) {
        return error;
    }
};

export const searchCallQueue = async (data) => {
    try {
        const result = await axiosInstance.post(`/search`, {
            limit: data.limit || 10,
            offset: data.offset || 1,
            userId: data.userId,
            customerName: data.search.name,
            customerPhone: data.search.phoneNumber,
            chassisNo: data.search.vinNumber,
            vehicleRegNo: data.search.registrationNo ? data.search.registrationNo : "",
            policyNo: data.search.policyNo,
            policyTenure: data.search.policyTenure,
            policyType: data.search.policyType,
            make: data.search.make,
            model: data.search.model,
            variant: data.search.variant,
            vehicleClass: data.search.vehicleClass,
            engineNo: data.search.engineNo,
            type: data.type,
            callQueType: data.callQueueType,
            sortField: data.sortField,
            sortOrder: data.sortOrder,
            dealerCode: data.dealerCode
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const customerSearch = async (data) => {
    try {
        const result = await axiosInstance.post(`/search`, {
            customerName: data.search.name,
            customerPhone: data.search.phoneNumber,
            chassisNo: data.search.vinNumber,
            vehicleRegNo: data.search.vehicleRegNo ? data.search.vehicleRegNo : "",
            insuranceCompany: data.search.insuranceCompany,
            fuelType: data.search.fuelType,
            yom: data.search.yom,
            addonName: data.search.addonName,
            policyNo: data.search.policyNo,
            policyTenure: data.search.policyTenure,
            policyType: data.search.policyType,
            make: data.search.make,
            model: data.search.model,
            variant: data.search.variant,
            vehicleClass: data.search.vehicleClass,
            engineNo: data.search.engineNo,
            type: "customersearch",
            historyType: "init",
            // historyType: "overview",
            limit: data.limit || 10,
            offset: data.page || 1,
            userId: data.userId,
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const customerDetail = async (data) => {
    try {
        const result = await axiosInstance.post(`/search`, {
            customerPhone: '',
            policyNo: '',
            policyTenure: '',
            policyType: '',
            make: '',
            model: '',
            variant: '',
            vehicleClass: '',
            engineNo: '',
            customerName: data.customer_name,
            chassisNo: data.chassis_no,
            vehicleRegNo: data.vehicle_reg_no ? data.vehicle_reg_no : "",
            insuranceCompany: "",
            fuelType: "",
            yom: "",
            addonName: "",
            callQueueType: "customersearch",
            type: "customersearch",
            historyType: data.type,
            userId: data.userId,
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const getDealerDetails = async (dealerId, parentId) => {
    try {
        const result = await axiosInstance.post(`/getdealerdetails`, { dealerId: dealerId, parentId: parentId, type: "fetchDealerDetails" }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const dealerList = async (data) => {
    try {
        const result = await axiosInstance.post(`/checkDealerDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const locationList = async (data) => {
    try {
        // const result = await axiosInstance.post(`/checkLocationExists`, data, {
        const result = await axiosInstance.post(`/checkLocationDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const editDealerDetails = async (ebmCode, dealerId, parentId) => {
    try {
        const result = await axiosInstance.post(`/editDealerDetails`, { ebmCode: ebmCode, dealerId: dealerId, parentId: parentId, type: 'editDealerDetails' }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const saveColumnMapping = async (userId, dealerId, parentId, type, dealerLocCode, mapping_dealer_code, mappedColumns, file) => {
    try {
        const formData = new FormData();
        let data = {
            userId, dealerId, parentId, customtype: type.split('_')[0], mappingColumns: mappedColumns, dealerLocCode, mapping_dealer_code
            , type: 'savecolumnmap', template: type
        }
        formData.append('outletmodel', JSON.stringify(data));
        if (file) {
            formData.append('file', file);
        }
        const result = await axiosInstance.post(`/savecolumnmapping`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const saveOutletSetup = async (formData) => {
    try {
        const result = await axiosInstance.post(`/saveoutletsetup`, {
            ...formData, type: 'saveoutletsetup'
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getFilterValue = async () => {
    try {
        const result = await axiosInstance.post(`/getFilterValue`, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getSavedFilter = async (userId, dealerCode) => {
    try {
        const result = await axiosInstance.post(`/getSavedFilterValue`, {
            userId: userId,
            dealerCode: dealerCode
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const applyCQFilter = async (data) => {
    console.log("Filtered Data:", data);
    try {
        const result = await axiosInstance.post(`/filter`, {
            userId: data.userId,
            dealerCode: data.dealerCode,
            limit: data.limit,
            offset: data.page,
            type: data.type,
            saveLeadFilters: data.filters,
            callQueType: data.callQueueType,
            sortField: data.sortField,
            sortOrder: data.sortOrder,
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const saveLeadFilter = async (data) => {
    try {
        const result = await axiosInstance.post(`/saveLeadFilter`, {
            saveLeadFilters: [...data]
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getCustomerDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/getCustomerDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const fetchVehicleDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/fetchVehicleDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getHistory = async (data) => {
    try {
        const result = await axiosInstance.post(`/history/${data.type}`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}
// export const getHistory = async (data) => {
//     try {
//         const result = await axiosInstance.post(`/history/${data.type}`, {
//             vehicleRegNo: data?.vehicleRegNo,
//             chassisNo: data?.chassisNo,
//             leadId: data.leadId,
//             clusterId: data.clusterId,
//             vehicleName: data.vehicleName,
//             type: data.type,
//             policyno: data.policyno
//         }, {
//             headers: { 'Content-Type': 'application/json' }
//         });
//         return result.data;
//     } catch (error) {
//         console.error(error)
//         return error;
//     }
// }

export const addCustomerContactDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/addCustomerContactDetails`, {
            type: data.type,
            clusterId: data.clusterId,
            userId: data.userId,
            dealerCode: data.dealerCode,
            vehicleName: data.vehicleName,
            mobile: data.mobile,
            email: data.email
        }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getLeadAssignDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`${baseUrl}/getAllLeadList`, {
            limit: data.limit || 10,
            pageId: 3,
            offset: data.page || 1,
            roleId: data.roleId,
            dealerCode: data.dealerCode || '',
            flag: data.assignType || '',
            userId: data.userId,
            type: "leadList"
        }, {
            headers: { 'Content-Type': 'application/json' },

        });
        return result;
    } catch (error) {
        console.error(error)
        return error;
    }
};

export const AssignLeads = async (data) => {
    try {
        const result = await axiosInstance.post(`/assignLeads`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const downloadExcel = async (data) => {
    try {
        const result = await axiosInstance.post(
            `/downloadLeadExcel`, data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const downloadLeadReport = async (data) => {
    try {
        const result = await axiosInstance.post(
            `/downloadadminDashboardViewAllExcel`, data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const validateBulkExcel = async (uploadedFile, userId, dealerId) => {
    try {
        let fd = {
            'type': "validateAssignLeads",
            'userId': userId,
            'dealerCode': dealerId
        };
        const formData = new FormData();
        formData.append('outletJson', JSON.stringify(fd));
        formData.append('file', uploadedFile);
        const result = await axiosInstance.post(`/validateBulkExcelUpload`, formData,
            {
                headers: { 'Content-Type': 'multipart/form-data' },
            }
        );
        return result.data;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};
export const downloadErrorExcel = async (data) => {
    try {
        const result = await axiosInstance.post(
            `/downloadBulkErrorExcel`, data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const downloadTemplateExcel = async (data) => {
    try {
        const result = await axiosInstance.post(
            `/downloadCreatedExcel`, data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw { error: "No File Found" };
    }
};

export const saveValidatedExcel = async (uploadedFile, userId) => {
    try {
        let fd = {
            'type': "uploadBulkValidateAssignLeads",
            'userId': userId
        };
        const formData = new FormData();
        formData.append('outletJson', JSON.stringify(fd));
        formData.append('file', uploadedFile);

        const result = await axiosInstance.post(`/uploadBulkValidatedExcel`, formData,
            {
                headers: { 'Content-Type': 'multipart/form-data' },
            }
        );
        return result.data;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const filterLeadList = async (data) => {
    try {
        const result = await axiosInstance.post(
            `/filterLeadList`, data,
            {
                headers: { 'Content-Type': 'application/json' }
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const filterSearch = async (data) => {
    try {
        const result = await axiosInstance.post(
            `/search`, data,
            {
                headers: { 'Content-Type': 'application/json' }
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const getDispositionByFlag = async (data) => {
    try {
        const result = await axiosInstance.post(`/getDispostionDetailsByFlag`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getDispositionByInputs = async (data) => {
    try {
        const result = await axiosInstance.post(`/getDispostionDetailsByInput`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const saveDispostionDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/saveDispostionDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getUserDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/getUserList`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const searchUserDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/search`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const fetchUserCreationValues = async (data) => {
    try {
        const result = await axiosInstance.post(`/fetchUserCreationValues/${data.type}`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const addNewUser = async (data) => {
    try {
        const result = await axiosInstance.post(`/addNewUser`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const updateUserById = async (id, data) => {
    try {
        const result = await axiosInstance.post(`/updateUserById/${id}`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const updateUserProfile = async (data) => {
    try {
        const result = await axiosInstance.post(`/updateUserProfile`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

// User Management Table ---- user edit API ---- 
export const getUserDetailsById = async (id, parentCode) => {
    try {
        const result = await axiosInstance.post(`/getUserDetailsById/${id}`, { "userId": id, parentCode }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getUserProfileDetails = async (id, email) => {
    try {
        const result = await axiosInstance.post(`/getUserProfileDetails`, { "userId": id, emailId: email }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

// Role List table ---- role table API ---- 
export const getMappedDealerRoles = async (data) => {
    try {
        const result = await axiosInstance.post(`/getMappedDealerRoles`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


// Role List table ---- role table API ---- 
export const generateUserPassword = async (puserId, email, mobileNo) => {
    try {
        const result = await axiosInstance.post(`/generateUserPassword`, { puserId, email, mobileNo }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


// Role List table ---- role table API ---- 
export const deactivateUser = async (email) => {
    try {
        const result = await axiosInstance.post(`/deactivateUser`, { email }, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const getNewDealerForRoleMappings = async (data) => {
    try {
        const result = await axiosInstance.post(`/getNewDealerForRoleMappings`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const submitFeatureAccess = async (data) => {
    try {
        const result = await axiosInstance.post(`/submitFeatureAccess`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getRoleFeatureView = async (data) => {
    try {
        const result = await axiosInstance.post(`/getRoleFeatureView`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const downloadInvalidData = async (data) => {
    try {
        const formData = new FormData();
        let fd = { dealerId: data.dealerId, parentId: data.parentId, customtype: data.customtype, flag: data.flag, userId: data.userId }
        fd.missingColumns = data.missingColumns;
        formData.append('dataUpload', JSON.stringify(fd));
        const result = await axiosInstance.post(
            `/downloadInvalidData`, formData,
            { responseType: data.flag === 'downloadInvalidRows' ? 'blob' : 'json' });
        return data.flag === 'downloadInvalidRows' ? result : result.data;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const dataUpload = async (data) => {
    try {
        const formData = new FormData();
        let fd = { dealerId: data.dealerId, parentId: data.parentId, customtype: data.customtype, flag: data.flag, userId: data.userId }
        if (data.flag === 'download') {
            fd.missingColumns = data.missingColumns;
        }
        if (data.flag === 'downloadInvalidRows') {
            fd.invalidRows = data.invalidRows;
        }
        formData.append('dataUpload', JSON.stringify(fd));
        if (data.file) {
            formData.append('file', data.file);
        }
        const result = await axiosInstance.post(
            `/dataUpload`, formData,
            { responseType: data.flag === 'download' || data.flag === 'downloadInvalidRows' ? 'blob' : 'json' });
        return data.flag === 'download' || data.flag === 'downloadInvalidRows' ? result : result.data;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const downloadErrFile = async (data) => {
    try {
        let fd = { caseId: data.caseId, type: data.type, dealerId: data.dealerId, parentId: data.parentId, customtype: data.customtype, flag: data.flag, userId: data.userId }

        const result = await axiosInstance.post(
            // `/downloadErrorData`, formData,
            `/downloadErrorData`, fd,
            { responseType: 'blob', headers: { 'Content-Type': 'application/json' } });
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const getBucketDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/getBucketDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const saveBucketDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/saveBucketDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const getBucketList = async (data) => {
    try {
        const result = await axiosInstance.post(`/getBucketList`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const deleteBucket = async (data, id) => {
    try {
        const result = await axiosInstance.delete(`/deletePreferencesByBucket/${id}`,
            {
                headers: { 'Content-Type': 'application/json' },
                data: data
            }
        );
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const editPreferencesByBucket = async (bucketId, data) => {
    try {
        const result = await axiosInstance.post(`/editPreferencesByBucket/${bucketId}`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const getPreferencesByBucket = async (bucketId, data) => {
    try {
        const result = await axiosInstance.post(`/getPreferencesByBucket/${bucketId}`);
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const getReportingRoleByDealer = async (data) => {
    try {
        const result = await axiosInstance.post(`/getReportingRoleByDealer`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};


export const updateFeatureAccess = async (data) => {
    try {
        const result = await axiosInstance.post(`/updateFeatureAccess`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const fetchDashboard = async (data) => {
    try {
        const result = await axiosInstance.post(`/dashboard`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const downloadDashboardExcel = async (data) => {
    try {
        const result = await axiosInstance.post(`/downloadDashboardExcel`, data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        return error;
    }
};
export const fetchAdminDashboard = async (data) => {
    try {
        const result = await axiosInstance.post(`/adminDashboard`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};
export const fetchLeadAgingData = async (data) => {
    try {
        const result = await axiosInstance.post(`/fetchLeadAgingData`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};
export const fetchAdminDashboardViewAll = async (data) => {
    try {
        const result = await axiosInstance.post(`/adminDashboardViewAll`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};
export const fetchRenewalDashboard = async (data) => {
    try {
        const result = await axiosInstance.post(`/renewalDashboard`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const fetchFilteredDashboard = async (data) => {
    try {
        const result = await axiosInstance.post(`/dashboardFilter`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const filterAdminDashboard = async (data) => {
    try {
        const result = await axiosInstance.post(`/adminDashboardFilter`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};


export const fetchSystemConfiguration = async (data) => {
    try {
        const result = await axiosInstance.post(`/getSystemConfiguration`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const updateSystemConfiguration = async (data) => {
    try {
        const result = await axiosInstance.post(`/updateSystemConfiguration`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error);
        return error;
    }
};

export const reportDownload = async (data) => {
    try {
        const result = await axiosInstance.post(`/reportsDownload`, data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const userAccountLock = async (data) => {
    try {
        const result = await axiosInstance.post(`/lockUnlockUser`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const updateRoleStatus = async (data) => {
    try {
        const result = await axiosInstance.post(`/updateRoleStatus`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const updateUserStatus = async (data) => {
    try {
        const result = await axiosInstance.post(`/updateUserStatus`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const reportsOnLoad = async (data) => {
    try {
        const result = await axiosInstance.post(`/reportsOnLoad`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const downloadReports = async (data) => {
    try {
        const result = await axiosInstance.post('/reportsData', data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const reopenleads = async (data) => {
    try {
        const result = await axiosInstance.post('/reopenLostLeads', data,
            {
                headers: { 'Content-Type': 'application/json' },
            }
        );
        return result.data;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const fetchDealerNames = async () => {
    try {
        const result = await axiosInstance.post('/fetchDataUpload', {
            type: 'fetchDataUpload'
        }, {
            headers: { 'Content-Type': 'application/json' },
        });
        return result.data;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const fetchLocation = async (parentId) => {
    try {
        const result = await axiosInstance.post('/fetchLocation', {
            parentId: parentId.dealerName,
            type: 'fetchLocation'
        }, {
            headers: { 'Content-Type': 'application/json' },
        });
        return result.data;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const fetchRenewalFilterData = async (data) => {
    try {
        const result = await axiosInstance.post(`/renewalDashboardFilter`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const fetchFaq = async () => {
    try {
        const result = await axiosInstance.post(`/getFaqDetails`, "", {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const getQuotationData = async (data) => {
    try {
        const result = await axiosInstance.post(`/getCustomizationCardData`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const getSendQuote = async (data) => {
    try {
        const result = await axiosInstance.post(`/ebmUserCommunicationModes`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const submitSendQuote = async (data) => {
    try {
        const result = await axiosInstance.post(`/ebmCustomizationSendQuote`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const getModifyQuote = async (data) => {
    try {
        // const result = await axios.post(`https://uatebm1.mahindrainsure.com/VISOFMIBLCRMAPIS/api/EBMAuth/GenerateToken`, data, {
        const result = await axiosInstance.post(`/EbmAuthGenerateToken`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const getEBMPolicyAuthectication = async (data) => {
    try {
        // const result = await axios.post("https://uatebm1.mahindrainsure.com/VISOFMIBLCRMAPIS/api/CRMPolicyAuthentication/ebm/user-policy-auth", data, {
        const result = await axiosInstance.post(`/EbmAndPolicyAuth`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const sendQuotePreview = async (data) => {
    try {
        const result = await axiosInstance.post(`/sendQuotePreview`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const fetchTaTData = async (data) => {
    try {
        const result = await axiosInstance.post(`/tatMonitorDashboard`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const filterTaTData = async (data) => {
    try {
        const result = await axiosInstance.post(`/tatMonitorDashboard`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}




export const downloadTATExcel = async (data) => {
    try {
        const result = await axiosInstance.post(
            `/downloadTATEscalationData`, data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const fetchLeaderBoardData = async (data) => {
    try {
        const result = await axiosInstance.post(`/leaderBoardDashboard`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const fetchLeaderBoardBestDealer = async (data) => {
    try {
        const result = await axiosInstance.post(`/leaderBoardBestDealerData`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const fetchPerformanceDashboardData = async (data) => {
    try {
        const result = await axiosInstance.post(`/getPerformanceDashBoardData`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const downloadLeaderBoardExcel = async (data) => {
    try {
        const result = await axiosInstance.post(
            `/downloadLeaderBoardData`, data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const downloadPerformanceExcel = async (data) => {
    try {
        const result = await axiosInstance.post(data?.roleType == "dealer"
            ? "/downloadPerformanceDashboardDealerExcel"
            : "/downloadPerformanceDashboardMiblExcel", data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const downloadTatViewallExcel = async (data) => {
    try {
        const result = await axiosInstance.post("/downloadTATDashboardData", data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};


export const downloadTargetData = async (data) => {
    try {
        const result = await axiosInstance.post("/downloadTargetData", data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};
export const downloadTargetChartData = async (data) => {
    try {
        const result = await axiosInstance.post("/downloadTargetChartData", data,
            {
                headers: { 'Content-Type': 'application/json' },
                responseType: 'blob'
            }
        );
        return result;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};

export const fetchTargetDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/fetchTargetDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const insertTargetDetails = async (data) => {
    try {
        const result = await axiosInstance.post(`/insertTargetDetails`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}
export const updateTargetDetailsById = async (data) => {
    try {
        const result = await axiosInstance.post(`/updateTargetDetailsById`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}

export const fetchTargetDetailsById = async (data) => {
    try {
        const result = await axiosInstance.post(`/fetchTargetDetailsById`, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        return result.data;
    } catch (error) {
        console.error(error)
        return error;
    }
}


export const uploadTargetPlanningDetails = async (formData) => {
    try {
        const result = await axiosInstance.post(
            `/uploadTargetPlanningDetails`,
            formData,
            {
                headers: { 'Content-Type': 'multipart/form-data' },
            }
        );
        return result.data;
    } catch (error) {
        console.error('Error uploading Excel:', error);
        throw error;
    }
};


export const fetchTargetChart = async (data) => {
    try {
        const result = await axiosInstance.post("/fetchTargetChart", data,
            {
                headers: { 'Content-Type': 'application/json' },
            }
        );
        return result.data;
    } catch (error) {
        console.error('Error downloading Excel:', error);
        throw error;
    }
};



// downloadPerformanceDashboardMiblExcel - type: mibl 


