import axios from 'axios';
import { toast } from "react-toastify";
import { baseUrl } from '../env/env';
import store from "../redux/store";
import { encryptPayload } from './encryptRequest';
import { handleSessionExpired } from '../utils/sessionManager';

const axiosInstance = axios.create({
    baseURL: baseUrl
});

axiosInstance.interceptors.request.use(
    async (config) => {
        const token = store.getState().user.token;
        const userData = store.getState().user.loggedData;
        const inputUser = store.getState().user.inputUser;
        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
            // config.headers['userName'] = userData?.email;
            config.headers['userName'] = inputUser;
        }
        // config.withCredentials = true;
        config.withCredentials = false;

        const contentType = config.headers['Content-Type'] || config.headers['content-type'];

        if (config.data && contentType && contentType.includes('application/json')) {
            try {
                console.log("Encrypting request payload...", config.data);

                // const beforeEncryptedData = await encryptPayload(str_payload);
                // console.log("Before encryption:", beforeEncryptedData);

                // const encryptedPayload = "5YT5ryUM4sWgIMzu2Y8uIV85EyUujiOI2k1sONjXmyGUm2mDRRl/RWV2BshKXxwBVfmSq+DEPs+049lrQ2cM1s9Auz1IQKbzQY1Qc8D5jMp7vYHzZw=="
                // const decryptedData = decryptPayload(encryptedPayload);
                // console.log("Decrypted JSON:", decryptedData);

                const encryptedData = await encryptPayload(config.data);
                config.data = encryptedData;
            } catch (err) {
                console.error("Encryption failed:", err);
                throw err; // Prevent sending unencrypted payload
            }
        }

        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

axiosInstance.interceptors.response.use(
    (response) => response,
    async (error) => {
        if (error.response && error.response.status == 401) {
            await handleSessionExpired();

            // navigate('/');

            // setTimeout(() => {
            //     window.location.href = '/';
            // }, 3000);

        }
        return Promise.reject(error);
    }
);

export default axiosInstance;
