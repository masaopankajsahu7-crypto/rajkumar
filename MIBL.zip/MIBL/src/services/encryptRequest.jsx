import forge from "node-forge";

// AES-GCM encryption compatible with Java backend
export async function encryptPayload(data) {
  try {
    //   const aesKeyBase64 = "8Q8ZC3Cejn3OEQpPRm4NLyGcm2CYAhOqhyFlbEPvovY="; // 32-byte key (AES-256)
    //   const ivBase64 = "q8k45pTvhkNwJjWq"; // 12-byte IV
    const aesKeyBase64 = "X5sVk9mC+uC+J7JpqKb8r4F1vEh7U0pFZ+8NQH0p8GQ="; // 32 bytes
    const ivBase64 = "U0VDVVJFQUVTSQ=="; // "SECUREAESI" (12 bytes)

    const json = JSON.stringify(data);

    // Decode Base64 key and IV
    const aesKeyBytes = forge.util.decode64(aesKeyBase64);
    const ivBytes = forge.util.decode64(ivBase64);

    // Create cipher
    const cipher = forge.cipher.createCipher("AES-GCM", aesKeyBytes);
    cipher.start({ iv: ivBytes, tagLength: 128 });
    cipher.update(forge.util.createBuffer(json, "utf8"));
    cipher.finish();

    // Combine ciphertext + tag
    const encryptedBytes =
      cipher.output.getBytes() + cipher.mode.tag.getBytes();
    const encryptedBase64 = forge.util.encode64(encryptedBytes);

    return {
      payload: encryptedBase64,
    };
  } catch (err) {
    console.error("Encryption error:", err);
    throw err;
  }
}




export function decryptPayload(encryptedBase64) {
  try {
    const aesKeyBase64 = "X5sVk9mC+uC+J7JpqKb8r4F1vEh7U0pFZ+8NQH0p8GQ="; // 32 bytes
    const ivBase64 = "U0VDVVJFQUVTSQ=="; // "SECUREAESI" (12 bytes)

    // Decode key and IV
    const aesKeyBytes = forge.util.decode64(aesKeyBase64);
    const ivBytes = forge.util.decode64(ivBase64);

    // Decode encrypted payload
    const encryptedBytes = forge.util.decode64(encryptedBase64);

    // AES-GCM: last 16 bytes = authentication tag (128 bits)
    const tagLength = 16;
    const cipherText = encryptedBytes.slice(
      0,
      encryptedBytes.length - tagLength
    );
    const authTag = encryptedBytes.slice(
      encryptedBytes.length - tagLength
    );

    // Create decipher
    const decipher = forge.cipher.createDecipher("AES-GCM", aesKeyBytes);

    decipher.start({
      iv: ivBytes,
      tag: forge.util.createBuffer(authTag),
      tagLength: 128,
    });

    decipher.update(forge.util.createBuffer(cipherText));
    const success = decipher.finish();

    if (!success) {
      throw new Error("AES-GCM authentication failed");
    }

    const decryptedJson = decipher.output.toString("utf8");
    return JSON.parse(decryptedJson);
  } catch (err) {
    console.error("Decryption error:", err);
    throw err;
  }
}