let navigator;

export const setNavigator = (nav) => {
    navigator = nav;
};

export const navigate = (path) => {
    if (navigator) {
        navigator(path);
    } else {
        window.location.href = path; // fallback
    }
};
