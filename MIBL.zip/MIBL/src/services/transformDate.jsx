import { parseISO, format } from 'date-fns';

export function transformDate(input) {
  const lines = input.trim().split('\n');
  const [status, rawDate] = lines[0].split('|').map(s => s.trim());
  const formattedDate = format(parseISO(rawDate), 'dd MMM yyyy');

  let result = `${status} | ${formattedDate}`;

  if (lines.length > 1 && lines[1]?.split('|')[1]?.trim()) {
    const dateTimeStr = lines[1]?.split('|')?.pop()?.trim();
    const followUpDate = parseISO(dateTimeStr);
    const formattedFollowUp = format(followUpDate, 'dd MMM yyyy : HH:mm');
    result += `\nNext follow up : ${formattedFollowUp}`;
  }

  return result;
}
