import { useSelector } from 'react-redux';

export function useAuth() {
  const token = useSelector((state) => state.user.token);
  const user = useSelector((state) => state.user.loggedData);
  const featureAccess = useSelector((state) => state.user.featureAccess);
  const fetchUserByManager = useSelector((state) => state.user.fetchUserByManager);
  const isLoggedIn = useSelector((state) => state.user.loggedIn);

  return {
    token,
    user,
    fetchUserByManager,
    isLoggedIn,
    featureAccess,
  };
}