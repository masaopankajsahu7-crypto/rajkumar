// src/theme/theme.js

import { createTheme } from "@mui/material/styles";

const theme = createTheme({
    components: {
        MuiPopover: {
            defaultProps: {
                disableScrollLock: true,
            },
        },
        MuiMenu: {
            defaultProps: {
                disableScrollLock: true,
            },
        },
        MuiModal: {
            defaultProps: {
                disableScrollLock: true,
            },
        },
    },
});

export default theme;