export const bgGray100 = { backgroundColor: "rgb(245, 245, 246)" };
export const bgRed = { backgroundColor: "rgb(245, 0, 0)" }
export const borderRed = { borderColor: "rgb(245, 0, 0)", color: "rgb(245, 0, 0)" }
export const cursorpointer = { cursor: "pointer" }
export const checkBoxRed = { color: "rgb(245, 0, 0)" }
export const btnRed = { bgcolor: bgRed, color: 'white', borderColor: 'transparent', borderRadius: 2, textTransform: 'capitalize' }
export const colorRed = { color: "rgb(245, 0, 0)" }
export const bgGray500 = { backgroundColor: "#D9D9D9" }
export const bgRed700 = { backgroundColor: "rgba(227, 24, 55, 1)" }
export const bgGreen100 = { backgroundColor: "rgba(65, 189, 91, 1)" }
export const bgOrange300 = { backgroundColor: "rgba(229, 178, 68, 1)" }
export const bgGray200 = { backgroundColor: "rgba(228, 229, 229, 1)" }
export const bgRed500 = { backgroundColor: "rgba(237, 81, 81, 1)" }
export const secondaryGray = { backgroundColor: "rgba(77, 77, 79, 1)" }
export const borderLight = { border: "1px solid rgb(228, 224, 224)" }
export const colorDanger = { backgroundColor: "rgba(190, 0, 29, 1)" }
export const tabselectedColor = { color: "#E31837 !important" };
export const tabselectedBg = { backgroundColor: "#E31837 !important" };
export const selectedTabCount = { backgroundColor: "#9698A3" }
export const selectedTabText = { backgroundColor: "#9698A3" }

// Status colors on callQueue
export const orangebg = { backgroundColor: "rgba(248, 167, 74, 1)" }
export const greenbg = { backgroundColor: "rgba(55, 194, 115, 1)" }
export const bluebg = { backgroundColor: "rgba(30, 177, 245, 1)" }
export const pinkbg = { backgroundColor: "rgba(246, 93, 93, 1)" }

// Action colors on callQueue
export const callbg = { backgroundColor: "rgba(221, 226, 245, 1)" }
export const messagebg = { backgroundColor: "rgba(221, 247, 236, 1)" }
export const dispositionbg = { backgroundColor: "rgba(255, 242, 228, 1)" }
export const communicationbg = { backgroundColor: "rgba(211, 244, 252, 1)" }