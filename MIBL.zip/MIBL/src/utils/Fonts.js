export const fonts = {
    GeoramaRegular: {
        fontFamily: 'Georama-Regular !important',
        fontWeight: '400 !important',
        fontSize: '14px',
        lineHeight: '22px',
        letterSpacing: '0.2px',
        verticalAlign: 'middle'
    },
    GeoramaMedium: {
        fontFamily: 'Georama-Medium',
        fontWeight: '500 !important',
        fontSize: '14px',
        lineHeight: '22px',
        letterSpacing: '0.2px',
        verticalAlign: 'middle'
    },
    GeoramaBold: {
        fontFamily: 'Georama-Bold',
    },
}