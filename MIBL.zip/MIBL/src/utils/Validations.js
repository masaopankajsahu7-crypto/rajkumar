export const validateEmail = (email) => {
    if (!email) {
        return "Email is required";
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return "Enter a valid email address";
    }
    return "";  
};