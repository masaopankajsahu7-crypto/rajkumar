import { queryClient } from '../clientApp/lib/queryClient';
import store, { persistor } from '../redux/store';
import { toast } from 'react-toastify';

export const SESSION_LOGOUT_EVENT_KEY = 'mibl-session-logout-event';

let sessionExpiryInProgress = false;

export const clearSessionState = async ({ broadcast = false } = {}) => {
  queryClient.clear();
  store.dispatch({ type: 'RESET_ALL_STATE' });
  persistor.pause();
  await persistor.flush();
  await persistor.purge();
  persistor.persist();

  if (broadcast && typeof localStorage !== 'undefined') {
    localStorage.setItem(SESSION_LOGOUT_EVENT_KEY, String(Date.now()));
  }
};

const redirectToLogin = () => {
  if (typeof window === 'undefined' || window.location.pathname === '/') return;

  window.history.pushState({}, '', '/');
  window.dispatchEvent(new PopStateEvent('popstate'));
};

export const handleSessionExpired = async () => {
  if (sessionExpiryInProgress) return;
  sessionExpiryInProgress = true;

  toast.dismiss();
  toast.error('Session expired');
  await clearSessionState({ broadcast: true });
  redirectToLogin();

  window.setTimeout(() => {
    sessionExpiryInProgress = false;
  }, 1000);
};
