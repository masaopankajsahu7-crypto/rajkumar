// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react'

// // https://vite.dev/config/
// // vite.config.js
// export default defineConfig({
//   plugins: [react()],
//   server: {
//     host: '0.0.0.0',
//     port: 8080
//   }
// });

import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [
    react(),
    {
      name: "spa-fallback",
      configureServer(server) {
        server.middlewares.use((req, res, next) => {
          if (
            req.method === "GET" &&
            !req.url.startsWith("/@") &&
            !req.url.includes(".")
          ) {
            req.url = "/index.html";
          }
          next();
        });
      },
    },
  ],
  server: {
    host: "0.0.0.0",
    port: 8080,
    proxy: {
      // Frontend calls same-origin /CRM/*; Vite forwards it server-side to UAT
      // for local testing without browser CORS.
      "/CRM": {
        target: "https://mibluat.mahindrainsurancebrokers.com",
        changeOrigin: true,
        secure: false,
      },
      // Frontend calls same-origin /client-service/*; Vite forwards it server-side to UAT
      // for local testing without browser CORS.
      "/client-service": {
        target: "https://mibluat.mahindrainsurancebrokers.com",
        changeOrigin: true,
        secure: false,
      },
      // Master-service serves all dropdown (kds) data. Same-origin relative path -> proxied
      // server-side to UAT for local testing without browser CORS.
      "/master-service": {
        target: "https://mibluat.mahindrainsurancebrokers.com",
        changeOrigin: true,
        secure: false,
      },
      // App-service owns opportunity workflow APIs. Same-origin relative path -> proxied
      // server-side to UAT for local testing without browser CORS.
      "/app-service": {
        target: "https://mibluat.mahindrainsurancebrokers.com",
        changeOrigin: true,
        secure: false,
      },
    },
  },
  build: {
    chunkSizeWarningLimit: 4000,
  },
});
